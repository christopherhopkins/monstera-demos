/**
 * "Got it" on the demo brief band: tell the site, take the band away, and
 * put focus on the page so keyboard and screen-reader users are not left in
 * a gap. No framework; the button carries the endpoint and the nonce.
 */
( function () {
	const button = document.querySelector( '[data-brief-dismiss]' );
	if ( ! button ) {
		return;
	}
	button.addEventListener( 'click', function () {
		const band = button.closest( '.m-brief' );
		button.disabled = true;
		fetch( button.dataset.endpoint, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'X-WP-Nonce': button.dataset.nonce },
		} )
			.catch( function () {} )
			.finally( function () {
				if ( band ) {
					band.remove();
				}
				const main = document.getElementById( 'monstera-main' );
				const target =
					( main && main.querySelector( 'h1' ) ) ||
					main ||
					document.querySelector( 'h1' );
				if ( target ) {
					if ( ! target.hasAttribute( 'tabindex' ) ) {
						target.setAttribute( 'tabindex', '-1' );
					}
					target.focus( { preventScroll: false } );
				}
			} );
	} );
} )();
