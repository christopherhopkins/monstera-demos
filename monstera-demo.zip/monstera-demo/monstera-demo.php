<?php
/**
 * Plugin Name:       Monstera Demo
 * Plugin URI:        https://monstera.plugin
 * Description:       The companion for Monstera's live demos: seeds a program for one use case, signs the visitor in as a persona and shows them a brief. Nothing for a production site.
 * Version:           1.0.0-alpha
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Requires Plugins:  monstera
 * Author:            Monstera
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       monstera-demo
 *
 * Two ways in: a demo site installs this directory as a plugin beside
 * Monstera; a dev-mode site (wp-now, wp-env) has Monstera require this file
 * from its own demo/ folder. Either way the companion waits for
 * `monstera/booted` and does nothing when Monstera never boots.
 *
 * @package MonsteraDemo
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

if ( defined( 'MONSTERA_DEMO_DIR' ) ) {
	return;
}

const MONSTERA_DEMO_VERSION = '1.0.0-alpha';
const MONSTERA_DEMO_FILE    = __FILE__;
define( 'MONSTERA_DEMO_DIR', plugin_dir_path( __FILE__ ) );
define( 'MONSTERA_DEMO_URL', plugin_dir_url( __FILE__ ) );

// Monstera\Demo\ lives in demo/src/. Monstera's own autoloader looks for the
// namespace under src/Demo/, finds nothing and returns, so this one follows.
spl_autoload_register(
	static function ( string $className ): void {
		$prefix = 'Monstera\\Demo\\';
		if ( ! str_starts_with( $className, $prefix ) ) {
			return;
		}
		$path = MONSTERA_DEMO_DIR . 'src/' . str_replace( '\\', '/', substr( $className, strlen( $prefix ) ) ) . '.php';
		if ( is_file( $path ) ) {
			require_once $path;
		}
	}
);

// Monstera's hook named as a string, not Monstera\Core\Hooks::BOOTED: this file
// can load while Monstera is inactive, and naming the constant would then fail.
add_action( 'monstera/booted', [ Monstera\Demo\Plugin::class, 'boot' ] );
