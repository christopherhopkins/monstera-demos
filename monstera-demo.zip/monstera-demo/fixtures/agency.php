<?php
/**
 * Program: an agency with clients. Northwind & Co runs the program; Acme
 * Coffee Roasters and Riverside Wellness are its clients, with projects in
 * every status, deliverables, alerts and a few support requests.
 *
 * @package MonsteraDemo
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

return [
	'use_case'   => 'agency',
	'orgs'       => [ 'acme-coffee', 'riverside-wellness' ],
	'standalone' => false,
	'users'      => [],
	'content'    => [],
	'support'    => [
		[
			'ref'      => 'NW4A21C7',
			'member'   => 'sasha',
			'project'  => 'subscription-onboarding',
			'subject'  => 'Discovery form will not submit on a phone',
			'body'     => 'On my phone the Submit discovery button does nothing after I fill in the timeline question. Works on my laptop. Screenshots on request.',
			'priority' => 'high',
			'status'   => 'open',
			'days_ago' => 2,
		],
		[
			'ref'               => 'NW9E0B33',
			'member'            => 'sam',
			'project'           => 'inventory-sync-square',
			'subject'           => 'Where is the Square inventory runbook?',
			'body'              => 'The handover said there would be a runbook for the inventory bridge. I can find the architecture note but not the runbook.',
			'priority'          => 'normal',
			'status'            => 'resolved',
			'days_ago'          => 8,
			'resolved_days_ago' => 5,
		],
		[
			'ref'      => 'NW77D1F0',
			'member'   => 'mei',
			'project'  => null,
			'subject'  => 'Add our new studio manager to the portal',
			'body'     => 'Jonah starts Monday and will own the booking project day to day. Can he get access before then?',
			'priority' => 'normal',
			'status'   => 'open',
			'days_ago' => 1,
		],
	],
];
