<?php
/**
 * Program: an agency with clients. Northwind & Co runs the program; Acme
 * Coffee Roasters and Riverside Wellness are its clients, with projects in
 * every status, deliverables, alerts and a few support requests: one
 * that has gone back and forth and waits on the agency again (with a
 * screenshot; the admin persona is asked to answer it), one its member
 * resolved, one answered and waiting on its member.
 *
 * A request's `status` and `priority` are where it stands now. `thread` is
 * what happened since it was opened, each step so many `hours` after: a
 * `reply` (which moves the status as replies do), a `priority`, or a
 * `status` someone chose. `opened_priority` is what it was sent at, when
 * that has changed. `files` come with the opening message or a reply.
 *
 * @package MonsteraDemo
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

return [
	'use_case'   => 'agency',
	'orgs'       => [ 'acme-coffee', 'riverside-wellness' ],
	'standalone' => false,
	'users'      => [],
	'content'    => [],
	'support'    => [
		[
			'ref'             => 'NW4A21C7',
			'member'          => 'sasha',
			'project'         => 'subscription-onboarding',
			'subject'         => 'Discovery form will not submit on a phone',
			'body'            => "On my phone (iPhone 15, Safari) the discovery form scrolls back to the top when I tap Submit, and nothing is saved. It works on my laptop.\n\nThe screenshot shows where it stops: the button is right at the bottom edge.",
			'priority'        => 'high',
			'status'          => 'open',
			'days_ago'        => 2,
			'opened_priority' => 'normal',
			'files'           => [ 'screenshot' => 'discovery-submit-iphone.png' ],
			'thread'          => [
				[
					'hours'    => 2,
					'by'       => 'sasha',
					'priority' => 'high',
				],
				[
					'hours' => 20,
					'by'    => 'avery',
					'reply' => "Thanks Sasha, the screenshot made it clear. On smaller phones Safari's bottom bar covered the Submit button, so your tap landed on the page instead.\n\nWe've moved the button clear of the bar on staging. Could you try once more from your phone? If it goes through, mark this resolved. The checklist we ran is attached.",
					'files' => [ 'pdf' => 'staging-checks.pdf' ],
				],
				[
					'hours' => 43,
					'by'    => 'sasha',
					'reply' => 'Tried it on my phone this morning and it went through. One odd thing: my answer to the budget question now shows twice on the project page.',
				],
			],
		],
		[
			'ref'               => 'NW9E0B33',
			'member'            => 'sam',
			'project'           => 'inventory-sync-square',
			'subject'           => 'Where is the Square inventory runbook?',
			'body'              => 'The handover said there would be a runbook for the inventory bridge. I can find the architecture note but not the runbook.',
			'priority'          => 'normal',
			'status'            => 'resolved',
			'days_ago'          => 8,
			'resolved_days_ago' => 5,
			'thread'            => [
				[
					'hours' => 3,
					'by'    => 'avery',
					'reply' => "Hi Sam. The runbook is filed with the project's deliverables as \"Inventory bridge runbook\"; the architecture note links to it from its last section. I've also pinned it to the top of the project page so it is easier to find.",
				],
				[
					'hours' => 46,
					'by'    => 'sam',
					'reply' => 'Found it, and the pin helps. Thank you.',
				],
				[
					'hours'  => 72,
					'by'     => 'sam',
					'status' => 'resolved',
				],
			],
		],
		[
			'ref'      => 'NW77D1F0',
			'member'   => 'mei',
			'project'  => null,
			'subject'  => 'Add our new studio manager to the portal',
			'body'     => 'Jonah starts Monday and will own the booking project day to day. Can he get access before then?',
			'priority' => 'normal',
			'status'   => 'pending',
			'days_ago' => 1,
			'thread'   => [
				[
					'hours' => 4,
					'by'    => 'avery',
					'reply' => "Happy to. Send us Jonah's work email and the day he starts, and we'll have his invitation waiting. He will see the booking project as soon as he signs in.",
				],
			],
		],
	],
];
