<?php
/**
 * Program: individual members, no organizations. River and Iris from the
 * shared set, two more people so the directory has a page, content sent to
 * everyone, the renewal form, one support request.
 *
 * @package MonsteraDemo
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

return [
	'use_case'   => 'standalone',
	'orgs'       => [],
	'standalone' => true,
	'users'      => [
		[
			'login'      => 'noor',
			'first'      => 'Noor',
			'last'       => 'Haddad',
			'email'      => 'noor@example.org',
			'role'       => 'monstera_member_standalone',
			'org'        => null,
			'position'   => 'Facilitator',
			'bio'        => 'Runs community workshops on cooperative governance.',
			'expires_in' => '+5 months',
		],
		[
			'login'      => 'felix',
			'first'      => 'Felix',
			'last'       => 'Brandt',
			'email'      => 'felix@example.org',
			'role'       => 'monstera_member_standalone',
			'org'        => null,
			'position'   => 'Archivist',
			'bio'        => 'Keeps the program archive and writes the member letter.',
			'expires_in' => '+11 months',
		],
	],
	// Sent to everyone: no organization, every member may open it.
	'content'    => [
		[
			'slug'     => 'program-handbook-2026',
			'title'    => 'Program handbook · 2026',
			'days_ago' => 3,
			'summary'  => 'How the program works: membership, renewals, what you can ask for and who answers.',
			'body'     => '<p>Membership runs a year from the day you join. Renewal opens thirty days before it ends. Support answers within two working days.</p>',
		],
		[
			'slug'     => 'member-letter-september',
			'title'    => 'Member letter · September',
			'days_ago' => 9,
			'summary'  => 'What changed this month, who joined, and the dates worth writing down.',
			'body'     => '<p>Four people joined in September. The autumn workshop series opens for sign-up on the 12th.</p>',
		],
		[
			'slug'     => 'member-survey-results',
			'title'    => 'Member survey results',
			'days_ago' => 21,
			'summary'  => 'What sixty-one members said about the program, and what changes as a result.',
			'body'     => '<p>Most asked for a directory and shorter letters. The directory is on; the letters are shorter.</p>',
		],
	],
	'support'    => [
		[
			'ref'      => 'SA3C88E1',
			'member'   => 'river',
			'project'  => null,
			'subject'  => 'Renewal link asks me to sign in again',
			'body'     => 'The renewal form link in the member letter sends me to a sign-in page even though I am already signed in. The forms page opens fine.',
			'priority' => 'normal',
			'status'   => 'open',
			'days_ago' => 3,
			// Answered once, and back with the program (see agency.php for the shape).
			'thread'   => [
				[
					'hours' => 6,
					'by'    => 'avery',
					'reply' => "Thanks River. The link in the letter pointed at the form's old address, which asks for a fresh sign-in. We've corrected the letter. Could you try the link again and tell us it opens?",
				],
				[
					'hours' => 30,
					'by'    => 'river',
					'reply' => 'The new link opens on my laptop. On my phone it still asks me to sign in first.',
				],
			],
		],
	],
];
