<?php
/**
 * The shared fixture set every program draws from: five organizations, the
 * people in them and the team, sub-groups, projects with one intake, content,
 * forms and alerts. A program picks the organizations it holds; the seeder
 * filters the rest by organization. Program `all` takes everything, as the
 * dev seed did.
 *
 * @package MonsteraDemo
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$orgs_spec = [
	[
		'slug'         => 'highline-capital',
		'title'        => 'Highline Capital Partners',
		'content'      => 'A board-governed investment association serving institutional members across North America.',
		'tier'         => 'Premium',
		'seat_limit'   => 50,
		'expires_in'   => '+1 year',
		'location'     => 'Vancouver, BC',
		'description'  => 'A board-governed investment association serving institutional members across North America since 2009.',
		// The association's organizations are led by Avery, the Team manager
		// who runs every program: nobody else of the team knows them, so the
		// seed assigns Avery before naming them (At-a-glance track, FR9).
		'account_lead' => 'avery',
	],
	[
		'slug'         => 'cascadia-growers',
		'title'        => 'Cascadia Growers\' Cooperative',
		'content'      => 'A 40-member agricultural cooperative based in the Willamette Valley. Vineyards, orchards, and specialty crop producers.',
		'tier'         => 'Standard',
		'seat_limit'   => 80,
		'expires_in'   => '+10 months',
		'location'     => 'Salem, OR',
		'description'  => 'A 40-member agricultural cooperative based in the Willamette Valley. Wine, orchard, and specialty crop producers sharing infrastructure since 2015.',
		'account_lead' => 'avery',
	],
	[
		'slug'         => 'pacific-library',
		'title'        => 'Pacific Library Network',
		'content'      => 'Consortium of public and academic libraries pooling acquisitions, ILS infrastructure, and member training.',
		'tier'         => 'Institutional',
		'seat_limit'   => 120,
		'expires_in'   => '+2 years',
		'location'     => 'Seattle, WA',
		'description'  => 'Consortium of 38 public and academic libraries pooling acquisitions, ILS infrastructure, and member training across the Pacific Northwest.',
		'account_lead' => 'avery',
	],
	[
		'slug'         => 'acme-coffee',
		'title'        => 'Acme Coffee Roasters',
		'content'      => 'Specialty single-origin importer & roaster headquartered in Portland.',
		'tier'         => 'Client',
		'seat_limit'   => 0,
		'expires_in'   => '+6 months',
		'location'     => 'Portland, OR',
		'description'  => 'Specialty single-origin importer & roaster headquartered in Portland. Client of Northwind & Co. since 2023.',
		// Rowan, the Team member assigned to Acme, runs the account day to day.
		'account_lead' => 'rowan',
	],
	[
		'slug'         => 'riverside-wellness',
		'title'        => 'Riverside Wellness Studio',
		'content'      => 'Yoga, breathwork, and somatic-therapy studio expanding to a second location.',
		'tier'         => 'Client',
		'seat_limit'   => 0,
		'expires_in'   => '+9 months',
		'location'     => 'Bend, OR',
		'description'  => 'Yoga, breathwork, and somatic-therapy studio expanding from a single Bend location to two by Q3 2026.',
		// The account lead (At-a-glance track, FR4): one of the staff assigned
		// to the organization, the person its people reach first. Avery is
		// assigned to Riverside by leading its projects.
		'account_lead' => 'avery',
	],
];

// Each person's 'orgs' are their rows of the memberships table, in the order
// they began: organization slug => tier (admin, manager or member), or
// 'staff' for one of the team who is assigned to a client (People-model
// track, FR1 and FR3). The 'role' is the WordPress role those rows derive:
// an admin or manager anywhere is an organization manager, members alone are
// members, and the team keeps its team role whatever it is assigned to. A
// program seeds a person when it holds one of their organizations; the team
// with no organization named is seeded by every program.
$users_spec = [
	// The team: a Team manager who runs the program, and a Team member
	// (agency program) who knows one client and leads one of its projects.
	[
		'login'    => 'avery',
		'first'    => 'Avery',
		'last'     => 'Lin',
		'email'    => 'avery@monstera.example',
		'role'     => 'monstera_admin',
		'orgs'     => [],
		'position' => 'Platform Administrator',
		'bio'      => 'Keeps the gears turning across every org. Coffee, calm dashboards, and a soft spot for typography.',
	],
	[
		'login'    => 'rowan',
		'first'    => 'Rowan',
		'last'     => 'Blake',
		'email'    => 'rowan@monstera.example',
		'role'     => 'monstera_team_member',
		'orgs'     => [ 'acme-coffee' => 'staff' ],
		'position' => 'Project Manager',
		'bio'      => 'Runs the Acme account day to day: stand-ups, status and the next deliverable.',
	],
	// Highline (association): two organization admins, a manager who also
	// belongs to Pacific Library, and a member.
	[
		'login'    => 'marcus',
		'first'    => 'Marcus',
		'last'     => 'Webb',
		'email'    => 'marcus@highline.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [ 'highline-capital' => 'admin' ],
		'position' => 'Managing Director',
		'bio'      => 'Twenty years in fixed income. Chair of the Investment Committee.',
	],
	[
		'login'    => 'priya',
		'first'    => 'Priya',
		'last'     => 'Shah',
		'email'    => 'priya@highline.example',
		'role'     => 'monstera_member',
		'orgs'     => [ 'highline-capital' => 'member' ],
		'position' => 'Senior Analyst',
		'bio'      => 'Quantitative analysis lead. Currency hedging and emerging markets.',
	],
	[
		'login'    => 'diane',
		'first'    => 'Diane',
		'last'     => 'Okafor',
		'email'    => 'diane@highline.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [ 'highline-capital' => 'admin' ],
		'position' => 'Board Chair',
		'bio'      => 'Former pension fund CIO. Now serves on three boards in the Pacific Northwest.',
	],
	[
		'login'    => 'nadia',
		'first'    => 'Nadia',
		'last'     => 'Rahman',
		'email'    => 'nadia@highline.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [
			'highline-capital' => 'manager',
			'pacific-library'  => 'member',
		],
		'position' => 'Chief of Staff',
		'bio'      => 'Keeps Highline\'s roster, calendar and board papers in order. Sits on the Pacific Library Network\'s advisory board.',
	],
	// Cascadia (association)
	[
		'login'    => 'theo',
		'first'    => 'Theo',
		'last'     => 'Kim',
		'email'    => 'theo@cascadia.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [ 'cascadia-growers' => 'admin' ],
		'position' => 'Cooperative Manager',
		'bio'      => 'Runs operations for the co-op. Background in produce logistics and sustainable supply chain.',
	],
	[
		'login'    => 'linnea',
		'first'    => 'Linnea',
		'last'     => 'Carter',
		'email'    => 'linnea@cascadia.example',
		'role'     => 'monstera_member',
		'orgs'     => [ 'cascadia-growers' => 'member' ],
		'position' => 'Orchardist',
		'bio'      => 'Third-generation pear and apple grower. Sits on the Annual Festival Planning sub-group.',
	],
	[
		'login'    => 'ben',
		'first'    => 'Ben',
		'last'     => 'Mahoney',
		'email'    => 'ben@cascadia.example',
		'role'     => 'monstera_member',
		'orgs'     => [ 'cascadia-growers' => 'member' ],
		'position' => 'Winemaker',
		'bio'      => 'Pinot noir and chardonnay. Member of the Steering Committee.',
	],
	// Pacific Library (association)
	[
		'login'    => 'helena',
		'first'    => 'Helena',
		'last'     => 'Vasquez',
		'email'    => 'helena@paclib.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [ 'pacific-library' => 'admin' ],
		'position' => 'Network Director',
		'bio'      => 'Library systems veteran. Spearheading the ILS migration this year.',
	],
	[
		'login'    => 'kwame',
		'first'    => 'Kwame',
		'last'     => 'Adjei',
		'email'    => 'kwame@paclib.example',
		'role'     => 'monstera_member',
		'orgs'     => [ 'pacific-library' => 'member' ],
		'position' => 'Cataloging Standards Lead',
		'bio'      => 'RDA, BIBFRAME, and a deep respect for the OPAC.',
	],
	// Acme (agency client)
	[
		'login'    => 'sasha',
		'first'    => 'Sasha',
		'last'     => 'Reyes',
		'email'    => 'sasha@acme.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [ 'acme-coffee' => 'admin' ],
		'position' => 'Operations Lead',
		'bio'      => 'Coffee, code, and capacity planning.',
	],
	[
		'login'    => 'sam',
		'first'    => 'Sam',
		'last'     => 'Patel',
		'email'    => 'sam@acme.example',
		'role'     => 'monstera_member',
		'orgs'     => [ 'acme-coffee' => 'member' ],
		'position' => 'Production Manager',
		'bio'      => 'Manages roast scheduling and wholesale fulfillment.',
	],
	[
		'login'    => 'jordan',
		'first'    => 'Jordan',
		'last'     => 'Tate',
		'email'    => 'jordan@acme.example',
		'role'     => 'monstera_member',
		'orgs'     => [ 'acme-coffee' => 'member' ],
		'position' => 'Marketing Coordinator',
		'bio'      => 'Owns the storefront content calendar and the brand voice.',
	],
	// Riverside (agency client)
	[
		'login'    => 'mei',
		'first'    => 'Mei',
		'last'     => 'Chen',
		'email'    => 'mei@riverside.example',
		'role'     => 'monstera_org_manager',
		'orgs'     => [ 'riverside-wellness' => 'admin' ],
		'position' => 'Studio Owner',
		'bio'      => 'Yoga teacher of 15 years. Opening a second location in 2026.',
	],
	// Standalone members
	[
		'login'    => 'river',
		'first'    => 'River',
		'last'     => 'Cole',
		'email'    => 'river@example.org',
		'role'     => 'monstera_member_standalone',
		'orgs'     => [],
		'position' => 'Independent Consultant',
		'bio'      => 'Independent advisor to small co-ops on infrastructure and digital strategy.',
	],
	[
		'login'    => 'iris',
		'first'    => 'Iris',
		'last'     => 'Park',
		'email'    => 'iris@example.org',
		'role'     => 'monstera_member_standalone',
		'orgs'     => [],
		'position' => 'Researcher',
		'bio'      => 'Climate adaptation and food systems researcher.',
	],
];

$subgroups_spec = [
	// Highline
	[
		'slug'    => 'investment-committee',
		'title'   => 'Investment Committee',
		'org'     => 'highline-capital',
		'leader'  => 'marcus',
		'private' => false,
		'cadence' => 'Quarterly',
		'formed'  => '2023-01-15',
		'members' => [ 'marcus', 'priya', 'diane' ],
	],
	[
		'slug'    => 'audit-committee',
		'title'   => 'Audit Committee',
		'org'     => 'highline-capital',
		'leader'  => 'diane',
		'private' => true,
		'cadence' => 'Semi-annual',
		'formed'  => '2023-04-01',
		'members' => [ 'diane', 'priya' ],
	],
	[
		'slug'    => 'member-outreach',
		'title'   => 'Member Outreach',
		'org'     => 'highline-capital',
		'leader'  => 'priya',
		'private' => false,
		'cadence' => 'Monthly',
		'formed'  => '2024-09-12',
		'members' => [ 'priya' ],
	],
	// Cascadia
	[
		'slug'    => 'steering-committee',
		'title'   => 'Steering Committee',
		'org'     => 'cascadia-growers',
		'leader'  => 'theo',
		'private' => false,
		'cadence' => 'Monthly',
		'formed'  => '2022-03-01',
		'members' => [ 'theo', 'ben' ],
	],
	[
		'slug'    => 'festival-planning',
		'title'   => 'Annual Festival Planning',
		'org'     => 'cascadia-growers',
		'leader'  => 'linnea',
		'private' => false,
		'cadence' => 'As needed',
		'formed'  => '2024-11-01',
		'members' => [ 'linnea', 'theo' ],
	],
	// Pacific Library
	[
		'slug'    => 'tech-working-group',
		'title'   => 'Technology Working Group',
		'org'     => 'pacific-library',
		'leader'  => 'helena',
		'private' => false,
		'cadence' => 'Bi-weekly',
		'formed'  => '2024-02-01',
		'members' => [ 'helena', 'kwame' ],
	],
	[
		'slug'    => 'cataloging-standards',
		'title'   => 'Cataloging Standards',
		'org'     => 'pacific-library',
		'leader'  => 'kwame',
		'private' => false,
		'cadence' => 'Monthly',
		'formed'  => '2023-06-01',
		'members' => [ 'kwame' ],
	],
	// Acme
	[
		'slug'    => 'leadership-team',
		'title'   => 'Leadership Team',
		'org'     => 'acme-coffee',
		'leader'  => 'sasha',
		'private' => true,
		'cadence' => 'Weekly',
		'formed'  => '2023-08-15',
		'members' => [ 'sasha', 'sam', 'jordan' ],
	],
	// Riverside
	[
		'slug'    => 'studio-operations',
		'title'   => 'Studio Operations',
		'org'     => 'riverside-wellness',
		'leader'  => 'mei',
		'private' => false,
		'cadence' => 'Weekly',
		'formed'  => '2024-05-01',
		'members' => [ 'mei' ],
	],
];

// Each project names the client's people on it ('members', the first of whom
// is its client contact) and the one of the team who leads it ('lead'): a
// staff login, never one of the members. Rowan, the Team member, leads the
// Acme project in progress; Avery, the Team manager, the rest.
$projects_spec = [
	// Acme
	[
		'slug'        => 'headless-commerce',
		'title'       => 'Headless commerce migration',
		'org'         => 'acme-coffee',
		'status'      => 'discovery',
		'due_days'    => 45,
		'started_ago' => 30,
		'excerpt'     => 'Moving the storefront from the legacy WooCommerce monolith to a headless setup with Next.js front end.',
		'scope'       => "Phase 1: catalog + product detail.\nPhase 2: cart + checkout.\nPhase 3: account + subscription management.",
		'members'     => [ 'sasha', 'sam' ],
		'lead'        => 'avery',
		// What the client is asked to do next, and in how many days (the
		// At-a-glance track's next step): on the projects under way. The
		// Riverside booking project, at Discovery with no answers yet, has
		// none written, so the portal shows the discovery step on its own.
		'next_step'   => [ 'Answer the two follow-up questions on hosting and the catalogue size.', 10 ],
	],
	[
		'slug'        => 'subscription-onboarding',
		'title'       => 'Subscription onboarding redesign',
		'org'         => 'acme-coffee',
		'status'      => 'in_progress',
		'due_days'    => 28,
		'started_ago' => 60,
		'excerpt'     => 'Three-step signup flow with address-aware fulfillment estimates. Replaces a 2018 Gravity Forms implementation.',
		'scope'       => 'Replace the existing signup form with a 3-step React-driven flow. Carry over address validation and ZIP-based shipping estimates.',
		'members'     => [ 'sasha', 'jordan' ],
		'lead'        => 'rowan',
		'next_step'   => [ 'Approve the plan chooser copy on staging.', 5 ],
	],
	[
		'slug'        => 'brand-refresh-phase-1',
		'title'       => 'Brand refresh · Phase 1',
		'org'         => 'acme-coffee',
		'status'      => 'review',
		'due_days'    => 7,
		'started_ago' => 90,
		'excerpt'     => 'Tightened typography pairing, new palette tokens, and a refreshed primary mark. Phase 2 covers packaging.',
		'scope'       => 'Typography pairing, palette tokens, primary mark refinement. Phase 2 (packaging) is out of scope.',
		'members'     => [ 'sasha', 'jordan' ],
		'lead'        => 'avery',
		'next_step'   => [ 'Sign off the final mark and palette.', 3 ],
	],
	[
		'slug'        => 'inventory-sync-square',
		'title'       => 'Inventory sync with Square POS',
		'org'         => 'acme-coffee',
		'status'      => 'completed',
		'due_days'    => -30,
		'started_ago' => 120,
		'ended_ago'   => 30,
		'excerpt'     => 'Bridge inventory between WooCommerce and Square Retail.',
		'scope'       => 'Implement a webhook-based bridge so inventory stays in sync between WooCommerce and Square POS in the cafe.',
		'members'     => [ 'sasha', 'sam' ],
		'lead'        => 'avery',
	],
	[
		'slug'        => 'loyalty-pilot',
		'title'       => 'Member loyalty pilot',
		'org'         => 'acme-coffee',
		'status'      => 'proposed',
		'due_days'    => 0,
		'started_ago' => 0,
		'excerpt'     => 'Punch-card replacement, integration with subscription output. Pending discovery before scoping.',
		'scope'       => 'Replace paper punch cards with a digital loyalty layer. Define MVP scope after discovery.',
		'members'     => [ 'sasha' ],
		'lead'        => 'avery',
	],
	// Riverside
	[
		'slug'        => 'riverside-brand-identity',
		'title'       => 'Riverside brand identity refresh',
		'org'         => 'riverside-wellness',
		'status'      => 'in_progress',
		'due_days'    => 35,
		'started_ago' => 45,
		'excerpt'     => 'New mark, palette, and signage system to carry the brand across two locations.',
		'scope'       => 'Primary mark, palette, type system, signage spec, and a basic brand book.',
		'members'     => [ 'mei' ],
		'lead'        => 'avery',
		'next_step'   => [ 'Choose a colour direction from the three boards.', 7 ],
	],
	[
		'slug'        => 'riverside-booking',
		'title'       => 'Online class booking system',
		'org'         => 'riverside-wellness',
		'status'      => 'discovery',
		'due_days'    => 60,
		'started_ago' => 14,
		'excerpt'     => 'Replace MindBody with a lighter, self-hosted booking flow tied to the new brand.',
		'scope'       => 'Class catalog + booking + cancellation + waitlist + member account. Out of scope: payroll, retail.',
		'members'     => [ 'mei' ],
		'lead'        => 'avery',
	],
	[
		'slug'        => 'riverside-relaunch-event',
		'title'       => 'Studio relaunch event',
		'org'         => 'riverside-wellness',
		'status'      => 'proposed',
		'due_days'    => 90,
		'started_ago' => 0,
		'excerpt'     => 'Two-day open house at the second location once it opens. Marketing, signage, RSVP flow.',
		'scope'       => 'Two-day open house. Marketing assets, signage, RSVP flow, post-event survey.',
		'members'     => [ 'mei' ],
		'lead'        => 'avery',
	],
];

// Discovery responses on the headless-commerce project, given by sasha.
$intake_spec = [
	'headless-commerce' => [
		'by'      => 'sasha',
		'answers' => [
			'goal'     => 'Replace the monolithic WooCommerce front end with a faster, more flexible Next.js storefront while keeping WooCommerce as the order management spine.',
			'audience' => 'Existing wholesale and DTC customers across web and mobile.',
			'timeline' => 'Pilot for the gift season; full cutover by end of Q1 2026.',
			'success'  => 'TTI under 1.5s on 3G, parity feature coverage for Q4 sales, no cart-recovery regression.',
		],
	],
];

$content_spec = [
	// Highline
	[
		'slug'     => 'q4-board-package-2025',
		'org'      => 'highline-capital',
		'subgroup' => 'investment-committee',
		'title'    => 'Q4 board package · November 2025',
		'days_ago' => 2,
		'summary'  => 'Quarterly performance review, capital deployment plan, and resolutions for the November 14 meeting.',
		'body'     => "<p>The fourth quarter closed with continued discipline on the deployment side. Three new positions were initiated against the framework approved in August.</p>\n<h2>Performance, plainly</h2>\n<p>The portfolio returned 4.1 percent net for the quarter against a benchmark of 3.6 percent.</p>",
	],
	[
		'slug'     => 'fy26-budget-proposal',
		'org'      => 'highline-capital',
		'subgroup' => 'investment-committee',
		'title'    => 'FY26 budget proposal',
		'days_ago' => 14,
		'summary'  => 'Draft budget for fiscal year 2026 with the rationale for headcount and infrastructure adjustments.',
		'body'     => '<p>Headcount holds at thirty-two with two new junior analyst hires. Infrastructure budget increases on the data side.</p>',
	],
	[
		'slug'     => 'member-welcome-letter',
		'org'      => 'highline-capital',
		'title'    => 'Member welcome letter (2026)',
		'days_ago' => 6,
		'summary'  => 'The annual welcome letter sent to every member at calendar-year start.',
		'body'     => '<p>Welcome to another year of measured analysis and quiet conviction.</p>',
	],
	[
		'slug'     => '2025-annual-report',
		'org'      => 'highline-capital',
		'title'    => '2025 annual report',
		'days_ago' => 30,
		'summary'  => 'A comprehensive look at the year — portfolio performance, governance, and outlook.',
		'body'     => '<p>The 2025 fiscal year saw continued discipline and three new positions established against the framework.</p>',
	],
	[
		'slug'     => 'audit-findings-q3',
		'org'      => 'highline-capital',
		'subgroup' => 'audit-committee',
		'title'    => 'Audit findings · Q3',
		'days_ago' => 21,
		'summary'  => 'Quarterly audit summary. Two findings, both resolved before close.',
		'body'     => '<p>Two minor findings, both resolved before quarter close. Full work papers attached.</p>',
	],

	// Cascadia
	[
		'slug'     => '2026-grower-agreements',
		'org'      => 'cascadia-growers',
		'title'    => '2026 grower agreements',
		'days_ago' => 12,
		'summary'  => 'Updated cooperative agreements for the 2026 growing season. Includes the new dispute resolution clause.',
		'body'     => '<p>Signing window opens January 15, 2026. Please review the dispute resolution section carefully.</p>',
	],
	[
		'slug'     => 'crop-diversification-study',
		'org'      => 'cascadia-growers',
		'title'    => 'Crop diversification study',
		'days_ago' => 18,
		'summary'  => 'OSU extension findings on diversification strategies for small-orchard members.',
		'body'     => '<p>OSU extension service findings, with recommendations specific to our region and member scale.</p>',
	],
	[
		'slug'     => 'festival-ops-playbook',
		'org'      => 'cascadia-growers',
		'subgroup' => 'festival-planning',
		'title'    => 'Festival operations playbook',
		'days_ago' => 7,
		'summary'  => 'Day-by-day ops playbook for the spring festival. Vendor map, logistics, and contact directory.',
		'body'     => '<p>Updated for the 2026 festival. New vendor map and updated logistics contacts inside.</p>',
	],
	[
		'slug'     => 'q3-dividend-breakdown',
		'org'      => 'cascadia-growers',
		'title'    => 'Q3 cooperative dividend breakdown',
		'days_ago' => 24,
		'summary'  => 'Per-member dividend distribution, the formula used, and the audit trail.',
		'body'     => '<p>Distributions reflect the updated formula approved at the August steering meeting.</p>',
	],

	// Pacific Library
	[
		'slug'     => 'ils-migration-plan',
		'org'      => 'pacific-library',
		'subgroup' => 'tech-working-group',
		'title'    => 'ILS migration plan',
		'days_ago' => 5,
		'summary'  => 'Phase-by-phase plan to migrate the consortium ILS to FOLIO over 14 months.',
		'body'     => '<p>Phase 1 covers data normalization. Phase 2, parallel operation. Phase 3, cutover.</p>',
	],
	[
		'slug'     => 'member-roster-2025',
		'org'      => 'pacific-library',
		'title'    => 'Member library roster · 2025',
		'days_ago' => 40,
		'summary'  => 'The current roster, with contacts and ILS endpoint information.',
		'body'     => '<p>Thirty-eight member libraries, contacts, ILS endpoints, and emergency rollover.</p>',
	],
	[
		'slug'     => 'cataloging-reform-proposal',
		'org'      => 'pacific-library',
		'subgroup' => 'cataloging-standards',
		'title'    => 'Cataloging standards reform proposal',
		'days_ago' => 9,
		'summary'  => 'Proposed update from RDA to a BIBFRAME-influenced hybrid for the next ILS generation.',
		'body'     => '<p>Hybrid approach: RDA for legacy materials, BIBFRAME for new acquisitions.</p>',
	],

	// Acme
	[
		'slug'     => 'headless-catalog-architecture-v2',
		'org'      => 'acme-coffee',
		'project'  => 'headless-commerce',
		'title'    => 'Headless catalog architecture · draft v2',
		'days_ago' => 4,
		'summary'  => 'Architecture diagrams and the data-fetching rationale for the headless migration. Two open questions for your team in section 4.',
		'body'     => "<p>Updated diagrams and the data-fetching layer rationale.</p>\n<blockquote>We are positioned to do less, more carefully, in 2026.</blockquote>",
	],
	[
		'slug'     => 'q3-brand-workshop-notes',
		'org'      => 'acme-coffee',
		'project'  => 'brand-refresh-phase-1',
		'title'    => 'Q3 brand workshop notes',
		'days_ago' => 28,
		'summary'  => 'Outputs from the September brand workshop. Mood, voice, and the matrix of design directions explored.',
		'body'     => '<p>Three directions explored. Direction B was selected for further development.</p>',
	],
	[
		'slug'     => 'analytics-november-2025',
		'org'      => 'acme-coffee',
		'title'    => 'Site analytics · November 2025',
		'days_ago' => 3,
		'summary'  => 'Top pages, conversion funnel, and traffic source summary for the month.',
		'body'     => '<p>Storefront traffic up nineteen percent month-over-month. Cart abandonment improved 2.4 points.</p>',
	],
	[
		'slug'     => 'operations-runbook-2026',
		'org'      => 'acme-coffee',
		'title'    => 'Operations runbook · 2026 edition',
		'days_ago' => 10,
		'summary'  => 'Day-to-day operations runbook covering hosting, integrations, and on-call rotation.',
		'body'     => '<p>Quarterly review cadence. Lists each integration and the on-call rotation for the year.</p>',
	],

	// Riverside
	[
		'slug'     => 'studio-launch-playbook',
		'org'      => 'riverside-wellness',
		'title'    => 'Second-studio launch playbook',
		'days_ago' => 6,
		'summary'  => 'Day-by-day plan for the second studio opening — staffing, marketing, soft-launch period.',
		'body'     => '<p>Eight-week ramp from build-out completion to community open house.</p>',
	],
	[
		'slug'     => 'membership-renewal-flow',
		'org'      => 'riverside-wellness',
		'title'    => 'Membership renewal flow documentation',
		'days_ago' => 19,
		'summary'  => 'Walkthrough of the renewal flow and the operational handoffs at each stage.',
		'body'     => '<p>End-to-end renewal flow with operational handoffs documented per role.</p>',
	],
];

// Guides are written in the block editor, so their bodies are block markup.
$paragraph = static fn ( string $html ): string => "<!-- wp:paragraph -->\n<p>$html</p>\n<!-- /wp:paragraph -->";
$heading   = static fn ( string $text ): string => "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">$text</h2>\n<!-- /wp:heading -->";
$list      = static fn ( array $items ): string => "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . implode( '', array_map( static fn ( string $item ): string => "<!-- wp:list-item -->\n<li>$item</li>\n<!-- /wp:list-item -->", $items ) ) . "</ul>\n<!-- /wp:list -->";
$blocks    = static fn ( string ...$parts ): string => implode( "\n\n", $parts );

/*
 * The library (Forms-and-resources track, FR12): links, files and guides.
 * 'orgs' names who it reaches; none reaches the individuals of a program
 * without organizations. A file is the sample PDF or a spreadsheet written
 * from its rows. Every program holds three links, files (the PDF and a
 * spreadsheet) and a guide.
 */
$resources_spec = [
	// Acme Coffee Roasters (agency)
	[
		'slug'  => 'brand-asset-request',
		'orgs'  => [ 'acme-coffee' ],
		'title' => 'Brand asset request',
		'kind'  => 'link',
		'desc'  => 'Need a logo variant or color swatch? Use this Airtable form.',
		'url'   => 'https://airtable.com/example/brand',
	],
	[
		'slug'  => 'file-upload-portal',
		'orgs'  => [ 'acme-coffee' ],
		'title' => 'Large-file upload portal',
		'kind'  => 'link',
		'desc'  => 'Drop hi-res assets and packaging artwork here. Auto-categorized.',
		'url'   => 'https://example.org/upload',
	],
	[
		'slug'  => 'acme-brand-guidelines',
		'orgs'  => [ 'acme-coffee' ],
		'title' => 'Acme brand guidelines · 2026',
		'kind'  => 'file',
		'desc'  => 'Logo use, color and type for anything that carries the Acme name.',
		'file'  => 'pdf',
	],
	[
		'slug'  => 'storefront-content-calendar',
		'orgs'  => [ 'acme-coffee' ],
		'title' => 'Storefront content calendar',
		'kind'  => 'file',
		'desc'  => 'The quarter\'s posts and promotions, a row a week. Copy it before you edit.',
		'file'  => [
			'name' => 'storefront-content-calendar.csv',
			'rows' => [
				[ 'Week of', 'Channel', 'Post', 'Owner', 'Status' ],
				[ 'Jan 5', 'Newsletter', 'Winter blend launch', 'Jordan', 'Scheduled' ],
				[ 'Jan 12', 'Instagram', 'Roastery tour reel', 'Jordan', 'Drafting' ],
				[ 'Jan 19', 'Storefront banner', 'Subscription 15% off', 'Sam', 'Approved' ],
				[ 'Jan 26', 'Newsletter', 'Meet the growers: Huila', 'Jordan', 'Idea' ],
			],
		],
	],
	[
		'slug'  => 'working-with-northwind',
		'orgs'  => [ 'acme-coffee' ],
		'title' => 'Working with Northwind: requests, reviews and sign-off',
		'kind'  => 'guide',
		'desc'  => 'How a request becomes a deliverable, and what we need from you at each step.',
		'body'  => $blocks(
			$paragraph( 'Every piece of work we do for Acme starts as a request and ends with your sign-off. This guide walks through the steps in between, so you always know whose move it is.' ),
			$heading( 'Asking for something' ),
			$paragraph( 'Send a support request from the portal, or raise it on the project it belongs to. Say what you need and by when; a screenshot or a file helps us get it right the first time.' ),
			$heading( 'Reviewing a deliverable' ),
			$list(
				[
					'Open the deliverable from its project page.',
					'Put your comments in one reply, not several.',
					'Tell us who else at Acme needs to see it before it is final.',
				]
			),
			$heading( 'Signing off' ),
			$paragraph( 'When it is right, say so on the request or the project. We move the project on and start the next step the same day.' )
		),
	],
	// Riverside Wellness Studio (agency)
	[
		'slug'  => 'class-booking-settings',
		'orgs'  => [ 'riverside-wellness' ],
		'title' => 'Class booking settings',
		'kind'  => 'link',
		'desc'  => 'Where the studio\'s schedule, class sizes and cancellation window are set.',
		'url'   => 'https://example.org/riverside/booking',
	],
	// Highline Capital Partners (association)
	[
		'slug'  => 'membership-application',
		'orgs'  => [ 'highline-capital' ],
		'title' => 'Membership application',
		'kind'  => 'file',
		'desc'  => 'New-member application form. Submit to the secretariat after signing.',
		'file'  => 'pdf',
	],
	[
		'slug'  => 'highline-events-calendar',
		'orgs'  => [ 'highline-capital' ],
		'title' => 'Member events calendar',
		'kind'  => 'link',
		'desc'  => 'Briefings, committee meetings and the annual dinner, with the dial-in for each.',
		'url'   => 'https://example.org/highline/events',
	],
	// Every member organization of the association
	[
		'slug'  => 'filing-your-annual-disclosure',
		'orgs'  => [ 'highline-capital', 'cascadia-growers', 'pacific-library' ],
		'title' => 'Filing your annual disclosure',
		'kind'  => 'guide',
		'desc'  => 'What counts as a related-party holding, and how to declare one in five minutes.',
		'body'  => $blocks(
			$paragraph( 'Once a year, every member declares any holding that could be seen as a conflict with the association\'s work. Most people have nothing to declare. If that is you, say so on the form and you are done.' ),
			$heading( 'What counts' ),
			$list(
				[
					'A seat on the board of, or a trusteeship at, an organization the association does business with.',
					'Shares you or your household hold in such an organization, at any size.',
					'Paid advisory work for one, current or in the last twelve months.',
				]
			),
			$heading( 'How to declare' ),
			$paragraph( 'Open the Annual member disclosure under Forms, name each holding, and give the date your figures are taken from. A supporting statement is welcome but not required.' ),
			$paragraph( 'The secretariat reads every disclosure and writes back only if something needs a closer look.' )
		),
	],
	// Cascadia Growers' Cooperative (association)
	[
		'slug'  => 'crop-report-template',
		'orgs'  => [ 'cascadia-growers' ],
		'title' => 'Crop report template (Q4)',
		'kind'  => 'file',
		'desc'  => 'Quarterly crop reporting template for member growers.',
		'file'  => [
			'name' => 'crop-report-q4.csv',
			'rows' => [
				[ 'Grower', 'Crop', 'Acres planted', 'Acres harvested', 'Yield (tons)', 'Notes' ],
				[ 'Example Orchards', 'Pears', '40', '38', '612', 'Two acres lost to hail in August' ],
				[ '', '', '', '', '', '' ],
			],
		],
	],
	[
		'slug'  => 'grower-agreement-2026',
		'orgs'  => [ 'cascadia-growers' ],
		'title' => '2026 grower agreement (signable)',
		'kind'  => 'link',
		'desc'  => 'Click through to the signing portal. Replaces last year\'s paper form.',
		'url'   => 'https://example.org/sign/grower-2026',
	],
	// Pacific Library Network (association)
	[
		'slug'  => 'ils-checklist',
		'orgs'  => [ 'pacific-library' ],
		'title' => 'ILS migration readiness checklist',
		'kind'  => 'file',
		'desc'  => 'Pre-migration checklist your library should complete by phase 1 cutoff.',
		'file'  => 'pdf',
	],
	[
		'slug'  => 'consortium-cataloging-wiki',
		'orgs'  => [ 'pacific-library' ],
		'title' => 'Consortium cataloging wiki',
		'kind'  => 'link',
		'desc'  => 'The network\'s shared cataloging decisions and the RDA quick reference.',
		'url'   => 'https://example.org/paclib/wiki',
	],
	// Individual members (standalone)
	[
		'slug'  => 'program-events-calendar',
		'orgs'  => [],
		'title' => 'Program events calendar',
		'kind'  => 'link',
		'desc'  => 'Workshops, socials and the annual meet-up, with a link to book each.',
		'url'   => 'https://example.org/program/events',
	],
	[
		'slug'  => 'members-forum',
		'orgs'  => [],
		'title' => 'Members\' forum',
		'kind'  => 'link',
		'desc'  => 'Ask the other members, share what worked, find a study partner.',
		'url'   => 'https://example.org/program/forum',
	],
	[
		'slug'  => 'partner-discounts',
		'orgs'  => [],
		'title' => 'Partner discounts',
		'kind'  => 'link',
		'desc'  => 'What your membership saves you with the program\'s partners, and the codes to use.',
		'url'   => 'https://example.org/program/discounts',
	],
	[
		'slug'  => 'member-welcome-pack',
		'orgs'  => [],
		'title' => 'Member welcome pack',
		'kind'  => 'file',
		'desc'  => 'Everything your membership includes, on four pages.',
		'file'  => 'pdf',
	],
	[
		'slug'  => 'volunteer-hours-log',
		'orgs'  => [],
		'title' => 'Volunteer hours log',
		'kind'  => 'file',
		'desc'  => 'Keep your volunteering hours here and attach it to your renewal if you want them counted.',
		'file'  => [
			'name' => 'volunteer-hours-log.csv',
			'rows' => [
				[ 'Date', 'Activity', 'Hours', 'Notes' ],
				[ '2026-01-10', 'Mentoring session', '2', 'First-year member' ],
				[ '2026-02-07', 'Meet-up set-up', '3', '' ],
			],
		],
	],
	[
		'slug'  => 'getting-started-as-a-member',
		'orgs'  => [],
		'title' => 'Getting started as a member',
		'kind'  => 'guide',
		'desc'  => 'Your first week in the program: your profile, what to read and who to ask.',
		'body'  => $blocks(
			$paragraph( 'Welcome. Nobody set this portal up for you, so here is the short version of what it is for and where to start.' ),
			$heading( 'Your first week' ),
			$list(
				[
					'Finish your profile, so other members can find you in the directory.',
					'Read the Program handbook under Content.',
					'Look through the events calendar and book one thing.',
				]
			),
			$heading( 'When something is not right' ),
			$paragraph( 'Send a support request from the portal. The program answers every one, usually the same day.' )
		),
	],
];

/*
 * Forms built in Monstera (Forms-and-resources track, FR12): four questions,
 * one of each kind the portal asks, due a few weeks ahead, once per member,
 * and two submissions from people who are not the demo's personas. A date
 * answer is days from today; a file answer names the sample it is made of.
 * No program had an embedded form, so none is seeded.
 */
$forms_spec = [
	[
		'slug'         => 'annual-disclosure',
		'orgs'         => [ 'highline-capital', 'cascadia-growers', 'pacific-library' ],
		'title'        => 'Annual member disclosure',
		'desc'         => 'Declare related-party holdings once a year. Most members have nothing to declare.',
		'intro'        => $blocks(
			$paragraph( 'Every member declares, once a year, any holding that could be seen as a conflict with the association\'s work. If you have nothing to declare, choose that and send.' ),
			$paragraph( 'Unsure what counts? <a href="{resource:filing-your-annual-disclosure}">Filing your annual disclosure</a>, under Resources, explains it.' )
		),
		'due_in'       => 21,
		'confirmation' => 'Thanks, we have your disclosure. You can read it here at any time.',
		'emails'       => [ 'avery@monstera.example' ],
		'fields'       => [
			[
				'key'      => 'holdings',
				'label'    => 'Holdings to declare',
				'type'     => 'text',
				'required' => true,
				'help'     => 'Name each one, or write None.',
			],
			[
				'key'      => 'relationship',
				'label'    => 'Your relationship to them',
				'type'     => 'select',
				'options'  => [ 'Nothing to declare', 'Director or trustee', 'Shareholder', 'Through a family member' ],
				'required' => true,
				'help'     => '',
			],
			[
				'key'      => 'as_of',
				'label'    => 'Figures as of',
				'type'     => 'date',
				'required' => true,
				'help'     => 'The day your figures are taken from.',
			],
			[
				'key'      => 'statement',
				'label'    => 'Supporting statement',
				'type'     => 'file',
				'required' => false,
				'help'     => 'A PDF or a spreadsheet, if you have one.',
			],
		],
		'sent'         => [
			[
				'login'    => 'diane',
				'days_ago' => 4,
				'answers'  => [
					'holdings'     => 'Board seat, Cedar Ridge Pension Trust',
					'relationship' => 'Director or trustee',
					'as_of'        => -34,
				],
				'files'    => [ 'statement' => [ 'pdf' => 'Okafor holdings statement.pdf' ] ],
			],
			[
				'login'    => 'linnea',
				'days_ago' => 2,
				'answers'  => [
					'holdings'     => 'None',
					'relationship' => 'Nothing to declare',
					'as_of'        => -2,
				],
			],
		],
	],
	[
		'slug'         => 'standalone-renewal',
		'orgs'         => [],
		'title'        => 'Annual renewal form',
		'desc'         => 'Renew your membership for another year. Four questions, two minutes.',
		'intro'        => $blocks(
			$paragraph( 'Renew before your membership ends and nothing changes: your access, your directory entry and your history carry on.' ),
			$paragraph( 'On the student plan? Attach a photo of your student card.' )
		),
		'due_in'       => 30,
		'confirmation' => 'Thanks, your renewal is in. We will confirm the new dates by email.',
		'emails'       => [ 'avery@monstera.example' ],
		'fields'       => [
			[
				'key'      => 'card_name',
				'label'    => 'Name on your membership card',
				'type'     => 'text',
				'required' => true,
				'help'     => '',
			],
			[
				'key'      => 'plan',
				'label'    => 'Plan',
				'type'     => 'select',
				'options'  => [ 'Individual', 'Individual plus partner', 'Student' ],
				'required' => true,
				'help'     => '',
			],
			[
				'key'      => 'renew_from',
				'label'    => 'Renew from',
				'type'     => 'date',
				'required' => true,
				'help'     => 'Usually the day your membership ends.',
			],
			[
				'key'      => 'student_card',
				'label'    => 'Student card',
				'type'     => 'file',
				'required' => false,
				'help'     => 'For the student plan only.',
			],
		],
		'sent'         => [
			[
				'login'    => 'iris',
				'days_ago' => 3,
				'answers'  => [
					'card_name'  => 'Iris Park',
					'plan'       => 'Student',
					'renew_from' => 45,
				],
				'files'    => [ 'student_card' => [ 'screenshot' => 'student-card.png' ] ],
			],
			[
				'login'    => 'noor',
				'days_ago' => 1,
				'answers'  => [
					'card_name'  => 'Noor Haddad',
					'plan'       => 'Individual',
					'renew_from' => 150,
				],
			],
		],
	],
];

$alerts_spec = [
	[
		'slug'         => 'staging-maintenance-window',
		'title'        => 'Scheduled maintenance · staging environment',
		'excerpt'      => 'Friday 2:00–4:00am UTC. Production unaffected.',
		'body'         => 'We will be applying a database engine update to the staging environment. Production traffic remains unaffected. No action required.',
		'severity'     => 'warning',
		'audience_all' => true,
		'expires_in'   => '+3 days',
	],
	[
		'slug'         => 'new-reports-feature',
		'title'        => 'New: Sub-group engagement reports',
		'excerpt'      => 'See logins and content views per sub-group in the admin dashboard.',
		'body'         => 'The Reports page now includes per-sub-group engagement data — useful for understanding which committees and working groups are most active.',
		'severity'     => 'info',
		'audience_all' => true,
		'expires_in'   => '+14 days',
	],
	[
		'slug'         => 'highline-renewal-window',
		'title'        => 'Highline · membership renewal opens January 15',
		'excerpt'      => 'Renewal window opens January 15 and closes February 28.',
		'body'         => 'Annual membership renewals open January 15 and close February 28. Renew via the portal — no paper paperwork this year.',
		'severity'     => 'info',
		'audience_all' => false,
		'org_slug'     => 'highline-capital',
		'expires_in'   => '+30 days',
	],
	[
		'slug'         => 'acme-deploy-window',
		'title'        => 'Acme · production deploy Tuesday',
		'excerpt'      => 'Subscription onboarding ships to production Tuesday at 8am PT.',
		'body'         => 'The subscription onboarding flow ships to production Tuesday 8am PT. We\'ll monitor for 24h before standing down.',
		'severity'     => 'critical',
		'audience_all' => false,
		'org_slug'     => 'acme-coffee',
		'expires_in'   => '+2 days',
	],
];

return [
	'orgs'      => $orgs_spec,
	'users'     => $users_spec,
	'subgroups' => $subgroups_spec,
	'projects'  => $projects_spec,
	'intake'    => $intake_spec,
	'content'   => $content_spec,
	'resources' => $resources_spec,
	'forms'     => $forms_spec,
	'alerts'    => $alerts_spec,
];
