<?php
/**
 * Program: an association whose members are organizations. Highline Capital
 * Partners, Cascadia Growers' Cooperative and Pacific Library Network, with
 * their sub-groups, reports, forms and alerts. No projects.
 *
 * @package MonsteraDemo
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

return [
	'use_case'   => 'association',
	'orgs'       => [ 'highline-capital', 'cascadia-growers', 'pacific-library' ],
	'standalone' => false,
	'users'      => [],
	'content'    => [],
	'support'    => [],
];
