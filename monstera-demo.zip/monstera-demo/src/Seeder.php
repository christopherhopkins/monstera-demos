<?php
/**
 * Seeds a program: the organizations, people, sub-groups, projects, content,
 * forms, alerts, support requests and activity one kind of Monstera install
 * would hold, with that use case's preset applied.
 *
 * Programs: `all` is the local development dataset, everything at once with
 * the legacy `both` use case, and produces exactly what dev/seed.php did.
 * `agency`, `association` and `standalone` each hold one use case's slice of
 * the shared fixtures (demo/fixtures/shared.php) plus what their own fixture
 * file adds, and apply that preset the way Settings does.
 *
 * Idempotent per row: every organization, person and post is found by slug or
 * login before it is created, every join row is looked up before it is
 * inserted, and the activity generator only fills a window that is emptier
 * than it should be.
 */

declare(strict_types=1);

namespace Monstera\Demo;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\UseCase;
use Monstera\Support\Files as SupportFiles;
use Monstera\Support\Repository as SupportRepository;
use Monstera\Support\Thread;

defined( 'ABSPATH' ) || exit;

final class Seeder {

	/** Bumped when the fixtures grow, so a site can tell what it has. */
	public const VERSION = 6;

	public const ALL      = 'all';
	public const PROGRAMS = [ self::ALL, UseCase::AGENCY, UseCase::ASSOCIATION, UseCase::STANDALONE ];

	private const STANDALONE_EXPIRIES = [
		'river' => '+8 months',
		'iris'  => '+45 days',
	];

	/** @var array<string, mixed> */
	private array $shared;
	/** @var array<string, mixed> */
	private array $program;
	private string $name;

	/** @var array<string, int> */
	private array $orgIds = [];
	/** @var array<string, int> */
	private array $userIds = [];
	/** @var array<string, int> */
	private array $subgroupIds = [];
	/** @var array<string, int> */
	private array $projectIds = [];
	/** @var array<string, int> */
	private array $contentIds = [];
	/** @var array<int, array<string, mixed>> */
	private array $contentSpecs = [];
	private int $formCount      = 0;
	private int $alertCount     = 0;

	private function __construct( string $program ) {
		if ( ! in_array( $program, self::PROGRAMS, true ) ) {
			throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown seed program "%s"; one of %s.', $program, implode( ', ', self::PROGRAMS ) ) ) );
		}
		$this->name   = $program;
		$this->shared = require MONSTERA_DEMO_DIR . 'fixtures/shared.php';

		if ( self::ALL === $program ) {
			$this->program = [
				'use_case'   => 'both',
				'orgs'       => array_column( $this->shared['orgs'], 'slug' ),
				'standalone' => true,
				'users'      => [],
				'content'    => [],
				'support'    => [],
			];
		} else {
			$this->program = require MONSTERA_DEMO_DIR . 'fixtures/' . $program . '.php';
		}
	}

	/**
	 * Seeds the program and returns what it holds.
	 *
	 * @return array<string, int> Counts: orgs, users, subgroups, projects, content, forms, alerts.
	 */
	public static function run( string $program = self::ALL ): array {
		$seeder = new self( $program );
		return $seeder->seed();
	}

	/** @return array<string, int> */
	private function seed(): array {
		$this->configure();
		$this->organizations();
		$this->users();
		$this->subgroups();
		$this->projects();
		$this->content();
		$this->forms();
		$this->alerts();
		$this->support();
		$this->activity();

		flush_rewrite_rules( false );

		update_option( 'monstera_demo_seed_version', self::VERSION );
		update_option( 'monstera_demo_program', $this->name );
		// The legacy flag older code paths and the CLI read.
		update_option( 'monstera_demo_seeded', '1' );

		$counts = [
			'orgs'      => count( $this->orgIds ),
			'users'     => count( $this->userIds ),
			'subgroups' => count( $this->subgroupIds ),
			'projects'  => count( $this->projectIds ),
			'content'   => count( $this->contentIds ),
			'forms'     => $this->formCount,
			'alerts'    => $this->alertCount,
		];

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::log(
				sprintf(
					'Monstera demo data seeded (program %s, version %d): %d orgs · %d users · %d sub-groups · %d projects · %d content · %d forms · %d alerts.',
					$this->name,
					self::VERSION,
					$counts['orgs'],
					$counts['users'],
					$counts['subgroups'],
					$counts['projects'],
					$counts['content'],
					$counts['forms'],
					$counts['alerts']
				)
			);
		}

		return $counts;
	}

	// -----------------------------------------------------------------------
	// 1. Plugin configuration
	// -----------------------------------------------------------------------

	private function configure(): void {
		if ( self::ALL === $this->name ) {
			// The development dataset turns every v1 module on and keeps the
			// legacy "both" use case, which is no longer offered but still honoured.
			update_option( 'monstera_active_modules', [ 'projects', 'alerts', 'support', 'forms', 'reporting' ] );
			update_option( 'monstera_use_case', 'both' );
			update_option( 'monstera_onboarding_complete', '1' );
		} else {
			UseCase::apply( (string) $this->program['use_case'] );
		}
		update_option( 'monstera_portal_prefix', 'portal' );
	}

	// -----------------------------------------------------------------------
	// 2. Helpers
	// -----------------------------------------------------------------------

	private function holdsOrg( ?string $slug ): bool {
		return null !== $slug && in_array( $slug, $this->program['orgs'], true );
	}

	private function holdsStandalone(): bool {
		return ! empty( $this->program['standalone'] );
	}

	/** @param array<string, mixed> $args */
	private function findOrCreatePost( string $type, string $slug, array $args ): int {
		$existing = get_page_by_path( $slug, OBJECT, $type );
		if ( $existing ) {
			return (int) $existing->ID;
		}
		$args['post_type']   = $type;
		$args['post_name']   = $slug;
		$args['post_status'] = $args['post_status'] ?? 'publish';
		$id                  = wp_insert_post( $args, true );
		return is_wp_error( $id ) ? 0 : (int) $id;
	}

	/** @param array<string, mixed> $args */
	private function findOrCreateUser( string $login, array $args ): int {
		$existing = get_user_by( 'login', $login );
		if ( $existing ) {
			return (int) $existing->ID;
		}
		$args['user_login'] = $login;
		$args['user_pass']  = $args['user_pass'] ?? 'password';
		$id                 = wp_insert_user( $args );
		return is_wp_error( $id ) ? 0 : (int) $id;
	}

	/**
	 * Inserts a join row unless one with the same keys exists.
	 *
	 * @param array<string, int>    $where
	 * @param array<string, mixed>  $row
	 * @param string[]              $formats
	 */
	private function joinInsert( string $table, array $where, array $row, array $formats ): void {
		global $wpdb;
		$conds  = [];
		$params = [];
		foreach ( $where as $column => $value ) {
			$conds[]  = "`{$column}` = %d";
			$params[] = (int) $value;
		}
		$sql    = "SELECT id FROM `{$wpdb->prefix}{$table}` WHERE " . implode( ' AND ', $conds );
		$exists = (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared -- seed join rows; the column names are the fixture's own.
		if ( ! $exists ) {
			$wpdb->insert( $wpdb->prefix . $table, $row, $formats ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed join rows.
		}
	}

	/**
	 * The one sample PDF every PDF-type form points at, made from the
	 * base64 in fixtures/sample-pdf.php and registered as an attachment.
	 */
	private function samplePdfId(): int {
		$existing = get_posts(
			[
				'post_type'      => 'attachment',
				'post_status'    => 'any',
				'meta_key'       => '_monstera_sample_pdf', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one lookup, seed time.
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);
		if ( $existing ) {
			return (int) $existing[0];
		}

		$bytes = base64_decode( (string) require MONSTERA_DEMO_DIR . 'fixtures/sample-pdf.php', true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- a committed one-page PDF, encoded so no binary ships.
		if ( ! $bytes ) {
			return 0;
		}

		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) ) {
			return 0;
		}
		$path = trailingslashit( $uploads['path'] ) . 'monstera-sample.pdf';
		if ( false === file_put_contents( $path, $bytes ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- writing one fixture file into uploads at seed time.
			return 0;
		}

		$attachmentId = wp_insert_attachment(
			[
				'post_mime_type' => 'application/pdf',
				'post_title'     => 'Monstera sample PDF',
				'post_content'   => '',
				'post_status'    => 'inherit',
			],
			$path
		);
		if ( ! $attachmentId ) {
			return 0;
		}

		update_post_meta( $attachmentId, '_monstera_sample_pdf', '1' );

		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}
		wp_update_attachment_metadata( $attachmentId, wp_generate_attachment_metadata( $attachmentId, $path ) );

		return (int) $attachmentId;
	}

	// -----------------------------------------------------------------------
	// 3. Organizations
	// -----------------------------------------------------------------------

	private function organizations(): void {
		foreach ( $this->shared['orgs'] as $spec ) {
			if ( ! $this->holdsOrg( $spec['slug'] ) ) {
				continue;
			}
			$id = $this->findOrCreatePost(
				'monstera_org',
				$spec['slug'],
				[
					'post_title'   => $spec['title'],
					'post_content' => $spec['content'],
				]
			);
			if ( ! $id ) {
				continue;
			}
			update_post_meta( $id, 'monstera_status', 'active' );
			update_post_meta( $id, 'monstera_seat_limit', (int) $spec['seat_limit'] );
			update_post_meta( $id, 'monstera_membership_expires', gmdate( 'Y-m-d', (int) strtotime( $spec['expires_in'] ) ) );
			update_post_meta( $id, 'monstera_location', $spec['location'] );
			update_post_meta( $id, 'monstera_description', $spec['description'] );

			$term = term_exists( $spec['tier'], 'monstera_org_tier' );
			if ( ! $term ) {
				$term = wp_insert_term( $spec['tier'], 'monstera_org_tier' );
			}
			if ( is_array( $term ) ) {
				wp_set_post_terms( $id, [ (int) $term['term_id'] ], 'monstera_org_tier' );
			}

			$this->orgIds[ $spec['slug'] ] = $id;
		}
	}

	// -----------------------------------------------------------------------
	// 4. Users
	// -----------------------------------------------------------------------

	private function users(): void {
		$specs = array_merge( $this->shared['users'], $this->program['users'] );
		foreach ( $specs as $u ) {
			$standalone = 'monstera_member_standalone' === $u['role'];
			$admin      = 'monstera_admin' === $u['role'];
			if ( ! $admin && ! ( $standalone ? $this->holdsStandalone() : $this->holdsOrg( $u['org'] ) ) ) {
				continue;
			}
			$id = $this->findOrCreateUser(
				$u['login'],
				[
					'user_email'   => $u['email'],
					'first_name'   => $u['first'],
					'last_name'    => $u['last'],
					'display_name' => $u['first'] . ' ' . $u['last'],
					'role'         => $u['role'],
				]
			);
			if ( ! $id ) {
				continue;
			}

			// The role holds even on a re-seed of a user who existed with a stub role.
			$user = get_user_by( 'id', $id );
			if ( $user && ! in_array( $u['role'], (array) $user->roles, true ) ) {
				$user->set_role( $u['role'] );
			}

			if ( ! empty( $u['org'] ) && isset( $this->orgIds[ $u['org'] ] ) ) {
				update_user_meta( $id, 'monstera_associated_org', $this->orgIds[ $u['org'] ] );
			}
			update_user_meta( $id, 'monstera_position', $u['position'] );
			update_user_meta( $id, 'monstera_bio', $u['bio'] );
			update_user_meta( $id, 'monstera_show_in_directory', '1' );

			// Staggered last sign-ins so the directory looks lived-in.
			update_user_meta( $id, 'monstera_last_login', gmdate( 'Y-m-d H:i:s', time() - random_int( 60 * 30, 7 * DAY_IN_SECONDS ) ) );

			$this->userIds[ $u['login'] ] = $id;
		}

		// Individual members each carry a membership expiry of their own.
		$expiries = self::STANDALONE_EXPIRIES;
		foreach ( $this->program['users'] as $u ) {
			if ( ! empty( $u['expires_in'] ) ) {
				$expiries[ $u['login'] ] = $u['expires_in'];
			}
		}
		foreach ( $expiries as $login => $expiresIn ) {
			if ( isset( $this->userIds[ $login ] ) ) {
				update_user_meta( $this->userIds[ $login ], 'monstera_membership_expires', gmdate( 'Y-m-d', (int) strtotime( $expiresIn ) ) );
			}
		}
	}

	// -----------------------------------------------------------------------
	// 5. Sub-groups
	// -----------------------------------------------------------------------

	private function subgroups(): void {
		foreach ( $this->shared['subgroups'] as $sg ) {
			if ( ! $this->holdsOrg( $sg['org'] ) ) {
				continue;
			}
			$id = $this->findOrCreatePost(
				'monstera_subgroup',
				$sg['slug'],
				[
					'post_title'   => $sg['title'],
					'post_content' => $sg['title'] . ' — ' . ( $sg['cadence'] ?? 'meets as needed' ) . '.',
				]
			);
			if ( ! $id ) {
				continue;
			}
			update_post_meta( $id, 'monstera_subgroup_org_id', $this->orgIds[ $sg['org'] ] ?? 0 );
			update_post_meta( $id, 'monstera_subgroup_formed_on', $sg['formed'] );
			update_post_meta( $id, 'monstera_subgroup_is_private', $sg['private'] );
			update_post_meta( $id, 'monstera_subgroup_cadence', $sg['cadence'] );

			if ( ! empty( $sg['leader'] ) && isset( $this->userIds[ $sg['leader'] ] ) ) {
				update_post_meta( $id, 'monstera_subgroup_leader_id', $this->userIds[ $sg['leader'] ] );
			}

			foreach ( (array) $sg['members'] as $memberLogin ) {
				$memberId = $this->userIds[ $memberLogin ] ?? 0;
				if ( ! $memberId ) {
					continue;
				}
				$this->joinInsert(
					'monstera_subgroup_members',
					[
						'subgroup_id' => $id,
						'member_id'   => $memberId,
					],
					[
						'subgroup_id'   => $id,
						'member_id'     => $memberId,
						'role_in_group' => $memberLogin === $sg['leader'] ? 'Chair' : 'Member',
						'joined_on'     => $sg['formed'] . ' 00:00:00',
					],
					[ '%d', '%d', '%s', '%s' ]
				);
			}

			$this->subgroupIds[ $sg['slug'] ] = $id;
		}
	}

	// -----------------------------------------------------------------------
	// 6. Projects and the one intake
	// -----------------------------------------------------------------------

	private function projects(): void {
		global $wpdb;

		foreach ( $this->shared['projects'] as $spec ) {
			if ( ! $this->holdsOrg( $spec['org'] ) ) {
				continue;
			}
			$pid = $this->findOrCreatePost(
				'monstera_project',
				$spec['slug'],
				[
					'post_title'   => $spec['title'],
					'post_excerpt' => $spec['excerpt'],
					'post_content' => $spec['excerpt'],
				]
			);
			if ( ! $pid ) {
				continue;
			}
			update_post_meta( $pid, 'monstera_project_status', $spec['status'] );
			update_post_meta( $pid, 'monstera_project_org_id', $this->orgIds[ $spec['org'] ] ?? 0 );
			update_post_meta( $pid, 'monstera_project_scope', $spec['scope'] );

			if ( $spec['started_ago'] ) {
				update_post_meta( $pid, 'monstera_project_started_on', gmdate( 'Y-m-d', (int) strtotime( "-{$spec['started_ago']} days" ) ) );
			}
			if ( $spec['due_days'] ) {
				update_post_meta( $pid, 'monstera_project_due_on', gmdate( 'Y-m-d', (int) strtotime( ( $spec['due_days'] > 0 ? '+' : '' ) . $spec['due_days'] . ' days' ) ) );
			}
			if ( ! empty( $spec['ended_ago'] ) ) {
				update_post_meta( $pid, 'monstera_project_ended_on', gmdate( 'Y-m-d', (int) strtotime( "-{$spec['ended_ago']} days" ) ) );
			}

			foreach ( (array) $spec['members'] as $login ) {
				$memberId = $this->userIds[ $login ] ?? 0;
				if ( ! $memberId ) {
					continue;
				}
				$this->joinInsert(
					'monstera_project_members',
					[
						'project_id' => $pid,
						'member_id'  => $memberId,
					],
					[
						'project_id'      => $pid,
						'member_id'       => $memberId,
						'role_in_project' => $login === $spec['members'][0] ? 'Client lead' : 'Team member',
						'joined_on'       => current_time( 'mysql', true ),
					],
					[ '%d', '%d', '%s', '%s' ]
				);
			}

			$this->projectIds[ $spec['slug'] ] = $pid;
		}

		$table = Schema::tableName( Schema::TABLE_PROJECT_INTAKE );
		foreach ( $this->shared['intake'] as $slug => $intake ) {
			$pid = $this->projectIds[ $slug ] ?? 0;
			$by  = $this->userIds[ $intake['by'] ] ?? 0;
			if ( ! $pid || ! $by ) {
				continue;
			}
			foreach ( $intake['answers'] as $key => $value ) {
				$exists = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE project_id = %d AND field_key = %s', $table, $pid, $key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
				if ( $exists ) {
					continue;
				}
				$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
					$table,
					[
						'project_id'   => $pid,
						'field_key'    => $key,
						'field_value'  => $value,
						'submitted_by' => $by,
						'submitted_at' => current_time( 'mysql', true ),
					],
					[ '%d', '%s', '%s', '%d', '%s' ]
				);
			}
		}
	}

	// -----------------------------------------------------------------------
	// 7. Content
	// -----------------------------------------------------------------------

	private function content(): void {
		foreach ( $this->shared['content'] as $spec ) {
			if ( $this->holdsOrg( $spec['org'] ) ) {
				$this->contentItem( $spec );
			}
		}
		foreach ( $this->program['content'] as $spec ) {
			$this->contentItem(
				$spec + [
					'org'      => null,
					'everyone' => true,
				]
			);
		}
	}

	/** @param array<string, mixed> $spec */
	private function contentItem( array $spec ): void {
		$when = gmdate( 'Y-m-d H:i:s', time() - ( (int) $spec['days_ago'] ) * DAY_IN_SECONDS );
		$cid  = $this->findOrCreatePost(
			'monstera_content',
			$spec['slug'],
			[
				'post_title'    => $spec['title'],
				'post_excerpt'  => $spec['summary'],
				'post_content'  => $spec['body'],
				'post_date'     => $when,
				'post_date_gmt' => $when,
			]
		);
		if ( ! $cid ) {
			return;
		}
		update_post_meta( $cid, 'monstera_visibility', 'published' );
		update_post_meta( $cid, 'monstera_summary', $spec['summary'] );
		update_post_meta( $cid, 'monstera_click_behavior', 'post' );
		if ( ! empty( $spec['org'] ) && isset( $this->orgIds[ $spec['org'] ] ) ) {
			update_post_meta( $cid, 'monstera_associated_orgs', [ (int) $this->orgIds[ $spec['org'] ] ] );
		}
		if ( ! empty( $spec['everyone'] ) ) {
			update_post_meta( $cid, 'monstera_audience_everyone', true );
		}

		if ( ! empty( $spec['subgroup'] ) && isset( $this->subgroupIds[ $spec['subgroup'] ] ) ) {
			$sgId = $this->subgroupIds[ $spec['subgroup'] ];
			$this->joinInsert(
				'monstera_content_subgroups',
				[
					'content_id'  => $cid,
					'subgroup_id' => $sgId,
				],
				[
					'content_id'  => $cid,
					'subgroup_id' => $sgId,
				],
				[ '%d', '%d' ]
			);
		}
		if ( ! empty( $spec['project'] ) && isset( $this->projectIds[ $spec['project'] ] ) ) {
			$prId = $this->projectIds[ $spec['project'] ];
			$this->joinInsert(
				'monstera_content_projects',
				[
					'content_id' => $cid,
					'project_id' => $prId,
				],
				[
					'content_id' => $cid,
					'project_id' => $prId,
				],
				[ '%d', '%d' ]
			);
		}

		$this->contentIds[ $spec['slug'] ] = $cid;
		$this->contentSpecs[]              = $spec;
	}

	// -----------------------------------------------------------------------
	// 8. Forms and resources
	// -----------------------------------------------------------------------

	private function forms(): void {
		$specs = array_values(
			array_filter(
				$this->shared['forms'],
				fn ( array $spec ): bool => empty( $spec['org'] ) ? $this->holdsStandalone() : $this->holdsOrg( $spec['org'] )
			)
		);
		if ( ! $specs ) {
			return;
		}

		$standaloneIds = [];
		foreach ( array_merge( $this->shared['users'], $this->program['users'] ) as $u ) {
			if ( 'monstera_member_standalone' === $u['role'] && isset( $this->userIds[ $u['login'] ] ) ) {
				$standaloneIds[] = $this->userIds[ $u['login'] ];
			}
		}

		// One shared attachment so every PDF form has a real download.
		$pdfAttachmentId = $this->samplePdfId();

		foreach ( $specs as $spec ) {
			$fid = $this->findOrCreatePost(
				'monstera_form',
				$spec['slug'],
				[
					'post_title'   => $spec['title'],
					'post_excerpt' => $spec['desc'],
				]
			);
			if ( ! $fid ) {
				continue;
			}
			update_post_meta( $fid, 'monstera_form_type', $spec['type'] );
			update_post_meta( $fid, 'monstera_form_description', $spec['desc'] );
			if ( 'external' === $spec['type'] && $spec['url'] ) {
				update_post_meta( $fid, 'monstera_form_external_url', $spec['url'] );
			}
			if ( 'pdf' === $spec['type'] && $pdfAttachmentId ) {
				update_post_meta( $fid, 'monstera_form_pdf_id', $pdfAttachmentId );
			}
			if ( ! empty( $spec['org'] ) && isset( $this->orgIds[ $spec['org'] ] ) ) {
				update_post_meta( $fid, 'monstera_form_allowed_orgs', [ (int) $this->orgIds[ $spec['org'] ] ] );
			} else {
				update_post_meta( $fid, 'monstera_form_allowed_standalone_members', $standaloneIds );
			}
			++$this->formCount;
		}
	}

	// -----------------------------------------------------------------------
	// 9. Alerts
	// -----------------------------------------------------------------------

	private function alerts(): void {
		foreach ( $this->shared['alerts'] as $spec ) {
			if ( empty( $spec['audience_all'] ) && ! $this->holdsOrg( $spec['org_slug'] ?? null ) ) {
				continue;
			}
			$aid = $this->findOrCreatePost(
				'monstera_alert',
				$spec['slug'],
				[
					'post_title'   => $spec['title'],
					'post_excerpt' => $spec['excerpt'],
					'post_content' => $spec['body'],
				]
			);
			if ( ! $aid ) {
				continue;
			}
			update_post_meta( $aid, 'monstera_alert_severity', $spec['severity'] );
			update_post_meta( $aid, 'monstera_alert_audience_all', ! empty( $spec['audience_all'] ) );
			update_post_meta( $aid, 'monstera_alert_expires_at', gmdate( 'Y-m-d H:i:s', (int) strtotime( $spec['expires_in'] ) ) );
			update_post_meta( $aid, 'monstera_alert_dismissible', true );
			// The legacy scope mirror the older visibleTo() path reads.
			update_post_meta( $aid, 'monstera_alert_scope', $spec['audience_all'] ? 'all' : 'org' );

			if ( ! empty( $spec['org_slug'] ) && isset( $this->orgIds[ $spec['org_slug'] ] ) ) {
				update_post_meta( $aid, 'monstera_alert_audience_org_ids', [ (int) $this->orgIds[ $spec['org_slug'] ] ] );
				update_post_meta( $aid, 'monstera_alert_scope_ids', [ (int) $this->orgIds[ $spec['org_slug'] ] ] );
			}
			++$this->alertCount;
		}
	}

	// -----------------------------------------------------------------------
	// 10. Support requests (program fixtures only)
	// -----------------------------------------------------------------------

	private function support(): void {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		foreach ( $this->program['support'] as $spec ) {
			$memberId = $this->userIds[ $spec['member'] ] ?? 0;
			if ( ! $memberId ) {
				continue;
			}
			$talks   = ! empty( $spec['thread'] ) || ! empty( $spec['files'] );
			$orgId   = (int) get_user_meta( $memberId, 'monstera_associated_org', true );
			$created = time() - ( (int) $spec['days_ago'] ) * DAY_IN_SECONDS;
			$exists  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE ref = %s', $table, $spec['ref'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
			if ( $exists ) {
				// A site seeded before requests were conversations gains them once.
				$said = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE request_id = %d', Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ), $exists ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed gate.
				if ( $talks && 0 === $said ) {
					$this->supportThread( $exists, $spec, $memberId, $orgId, (int) strtotime( (string) $wpdb->get_var( $wpdb->prepare( 'SELECT created_at FROM %i WHERE id = %d', $table, $exists ) ) . ' UTC' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
				}
				continue;
			}
			$resolved = isset( $spec['resolved_days_ago'] ) ? time() - ( (int) $spec['resolved_days_ago'] ) * DAY_IN_SECONDS : null;
			$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows; Support\Repository::create() would also email the agency.
				$table,
				[
					'ref'              => $spec['ref'],
					'member_id'        => $memberId,
					'org_id'           => $orgId ?: null,
					'project_id'       => ! empty( $spec['project'] ) ? ( $this->projectIds[ $spec['project'] ] ?? null ) : null,
					'subject'          => $spec['subject'],
					'body'             => $spec['body'],
					'priority'         => $spec['priority'],
					'status'           => $spec['status'],
					'attachment_id'    => null,
					'created_at'       => gmdate( 'Y-m-d H:i:s', $created ),
					'resolved_at'      => $resolved ? gmdate( 'Y-m-d H:i:s', $resolved ) : null,
					// A request last moved when its member sent it, until its thread says otherwise.
					'last_activity_at' => gmdate( 'Y-m-d H:i:s', $created ),
					'last_side'        => Thread::SIDE_MEMBER,
				],
				[ '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' ]
			);
			$this->supportThread( (int) $wpdb->insert_id, $spec, $memberId, $orgId, $created );
		}
	}

	/**
	 * What has happened to a request since it was opened, written as the
	 * plugin would have written it, at the times the fixture gives: each
	 * reply and each change of status or priority in the thread, the files
	 * in secure storage, a row of activity for each, and the request left
	 * where its thread ends. A reply moves the status as replies do (staff
	 * leave it waiting on the member, the member's opens it again), so a
	 * fixture only names the statuses someone chose.
	 *
	 * @param array<string, mixed> $spec The request's fixture.
	 */
	private function supportThread( int $requestId, array $spec, int $memberId, int $orgId, int $created ): void {
		global $wpdb;
		$requests = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		$row      = [
			'id'  => $requestId,
			'ref' => (string) $spec['ref'],
		];
		$steps    = (array) ( $spec['thread'] ?? [] );
		$status   = $steps ? SupportRepository::STATUS_OPEN : (string) $spec['status'];
		$priority = (string) ( $spec['opened_priority'] ?? $spec['priority'] );
		$resolved = null;
		$last     = $created;
		$lastSide = Thread::SIDE_MEMBER;

		$this->supportActivity( 'support_request_opened', $requestId, $memberId, $orgId, $row['ref'], $created );
		$this->supportFiles( $row, null, (array) ( $spec['files'] ?? [] ), $memberId );

		foreach ( $steps as $step ) {
			$actor = $this->userIds[ $step['by'] ] ?? 0;
			if ( ! $actor ) {
				continue;
			}
			$side = $actor === $memberId ? Thread::SIDE_MEMBER : Thread::SIDE_STAFF;
			$when = $created + (int) round( (float) $step['hours'] * HOUR_IN_SECONDS );
			$from = $status;

			if ( isset( $step['reply'] ) ) {
				$messageId = $this->supportEntry( $requestId, Thread::KIND_MESSAGE, $actor, $side, $when, (string) $step['reply'] );
				$this->supportFiles( $row, $messageId, (array) ( $step['files'] ?? [] ), $actor );
				$this->supportActivity( 'support_replied', $requestId, $actor, $orgId, $row['ref'], $when, [ 'side' => $side ] );
				$status = Thread::SIDE_STAFF === $side ? SupportRepository::STATUS_PENDING : SupportRepository::STATUS_OPEN;
				if ( $status !== $from ) {
					$this->supportEntry( $requestId, Thread::KIND_EVENT, $actor, $side, $when, '', [ Thread::EVENT_STATUS, $from, $status, Thread::CAUSE_REPLY ] );
				}
			} elseif ( isset( $step['priority'] ) && $step['priority'] !== $priority ) {
				$this->supportEntry( $requestId, Thread::KIND_EVENT, $actor, $side, $when, '', [ Thread::EVENT_PRIORITY, $priority, (string) $step['priority'], Thread::CAUSE_MANUAL ] );
				$this->supportActivity(
					'support_priority_changed',
					$requestId,
					$actor,
					$orgId,
					$row['ref'],
					$when,
					[
						'from' => $priority,
						'to'   => (string) $step['priority'],
					]
				);
				$priority = (string) $step['priority'];
			} elseif ( isset( $step['status'] ) && $step['status'] !== $status ) {
				$status = (string) $step['status'];
				$this->supportEntry( $requestId, Thread::KIND_EVENT, $actor, $side, $when, '', [ Thread::EVENT_STATUS, $from, $status, Thread::CAUSE_MANUAL ] );
				$this->supportActivity(
					'support_status_changed',
					$requestId,
					$actor,
					$orgId,
					$row['ref'],
					$when,
					[
						'from' => $from,
						'to'   => $status,
						'side' => $side,
					]
				);
			} else {
				continue;
			}
			if ( $status !== $from ) {
				$resolved = SupportRepository::STATUS_RESOLVED === $status ? $when : null;
			}
			$last     = $when;
			$lastSide = $side;
		}

		if ( ! $steps ) {
			return;
		}
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
			$requests,
			[
				'status'           => $status,
				'priority'         => $priority,
				'resolved_at'      => $resolved ? gmdate( 'Y-m-d H:i:s', $resolved ) : null,
				'last_activity_at' => gmdate( 'Y-m-d H:i:s', $last ),
				'last_side'        => $lastSide,
			],
			[ 'id' => $requestId ]
		);
	}

	/**
	 * One entry in a request's thread, at a time in the past.
	 *
	 * @param array{0: string, 1: string, 2: string, 3: string}|null $event Type, from, to and cause, for an event.
	 * @return int The entry's id.
	 */
	private function supportEntry( int $requestId, string $kind, int $authorId, string $side, int $when, string $body, ?array $event = null ): int {
		global $wpdb;
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows; Support\Thread stamps the present.
			Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ),
			[
				'request_id' => $requestId,
				'kind'       => $kind,
				'author_id'  => $authorId,
				'side'       => $side,
				'body'       => $body,
				'event_data' => $event ? (string) wp_json_encode(
					[
						'type'  => $event[0],
						'from'  => $event[1],
						'to'    => $event[2],
						'cause' => $event[3],
					]
				) : null,
				'created_at' => gmdate( 'Y-m-d H:i:s', $when ),
			],
			[ '%d', '%s', '%d', '%s', '%s', '%s', '%s' ]
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * A message's files, put through the plugin's own store so they are
	 * checked, kept in secure storage and registered as a member's upload
	 * would be. The bytes are the fixtures' sample screenshot and PDF.
	 *
	 * @param array{id: int, ref: string} $row   The request.
	 * @param array<string, string>       $files Sample ("screenshot" or "pdf") => the name it is kept under.
	 */
	private function supportFiles( array $row, ?int $messageId, array $files, int $userId ): void {
		if ( ! $files ) {
			return;
		}
		$copy = static fn ( $moved, string $from, string $to ): bool => copy( $from, $to );
		// A file written here was not uploaded in this request, so it is copied in, not moved.
		add_filter( Hooks::FILTER_SECURE_FILE_MOVE, $copy, 10, 3 );
		foreach ( $files as $sample => $name ) {
			$bytes = base64_decode( (string) require MONSTERA_DEMO_DIR . 'fixtures/sample-' . ( 'screenshot' === $sample ? 'screenshot' : 'pdf' ) . '.php', true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- a committed sample, encoded so the demo ships no binary.
			$path  = wp_tempnam( $name );
			if ( false === $bytes || ! $path || false === file_put_contents( $path, $bytes ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- a temporary file handed to the secure store.
				continue;
			}
			try {
				( new SupportFiles() )->store(
					$row,
					$messageId,
					[
						[
							'name'     => $name,
							'type'     => 'application/octet-stream',
							'tmp_name' => $path,
							'error'    => 0,
							'size'     => strlen( $bytes ),
						],
					],
					$userId
				);
			} catch ( \Throwable $failure ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- refused or not stored: a demo without the file is still a demo.
			}
			wp_delete_file( $path );
		}
		remove_filter( Hooks::FILTER_SECURE_FILE_MOVE, $copy, 10 );
	}

	/**
	 * A row of activity about a request, at a time in the past, in the shape
	 * Support\Activity records.
	 *
	 * @param array<string, string> $more What the event adds to the context.
	 */
	private function supportActivity( string $event, int $requestId, int $actorId, int $orgId, string $ref, int $when, array $more = [] ): void {
		global $wpdb;
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows; ActivityLog::record() stamps the present.
			Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
			[
				'user_id'     => $actorId,
				'event_type'  => $event,
				'object_type' => 'support_request',
				'object_id'   => $requestId,
				'org_id'      => $orgId ?: null,
				'occurred_at' => gmdate( 'Y-m-d H:i:s', $when ),
				'ip_hash'     => '',
				'context'     => (string) wp_json_encode(
					[
						'org_id' => $orgId,
						'ref'    => $ref,
					] + $more
				),
			],
			[ '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s' ]
		);
	}

	// -----------------------------------------------------------------------
	// 11. Activity log: enough signal for the reports charts
	// -----------------------------------------------------------------------

	private function activity(): void {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );

		// Only events inside the visible chart window (the last seven calendar
		// days, UTC) count towards the gates, so old rows on a long-lived demo
		// install never suppress fresh fixtures.
		$windowStart       = gmdate( 'Y-m-d 00:00:00', (int) strtotime( gmdate( 'Y-m-d' ) . ' -6 days' ) );
		$existingLogins    = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE event_type = %s AND occurred_at >= %s', $table, 'login', $windowStart ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed gate.
		$existingDownloads = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE event_type = %s AND occurred_at >= %s', $table, 'download', $windowStart ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed gate.
		$existingPublishes = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE event_type = %s', $table, 'publish' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed gate.

		$now        = time();
		$allUsers   = array_values( $this->userIds );
		$allContent = array_values( $this->contentIds );

		mt_srand( 24601 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_seeding_mt_srand -- a fixed seed keeps the demo's charts the same on every install.

		// Sign-ins spread over the last six days so every chart bar lights up.
		if ( $allUsers && $existingLogins < ( count( $allUsers ) * 2 ) ) {
			foreach ( $allUsers as $uid ) {
				$loginCount = mt_rand( 3, 8 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand -- seeded above, deterministic on purpose.
				for ( $i = 0; $i < $loginCount; $i++ ) {
					$when = $now - mt_rand( 60 * 5, 6 * DAY_IN_SECONDS ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand -- seeded above.
					$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
						$table,
						[
							'user_id'     => $uid,
							'event_type'  => 'login',
							'object_type' => '',
							'object_id'   => null,
							'occurred_at' => gmdate( 'Y-m-d H:i:s', $when ),
							'ip_hash'     => hash( 'sha256', "demo-$uid-$i" . wp_salt( 'auth' ) ),
							'context'     => null,
						],
						[ '%d', '%s', '%s', '%d', '%s', '%s', '%s' ]
					);
				}
			}
		}

		// Downloads power Most-viewed content and the sub-group view counts.
		if ( $allUsers && $allContent && $existingDownloads < ( count( $allContent ) * 2 ) ) {
			foreach ( $allContent as $cid ) {
				$dlCount = mt_rand( 2, 12 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand -- seeded above.
				for ( $i = 0; $i < $dlCount; $i++ ) {
					$uid  = $allUsers[ array_rand( $allUsers ) ];
					$when = $now - mt_rand( 60 * 5, 6 * DAY_IN_SECONDS ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand -- seeded above.
					$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
						$table,
						[
							'user_id'     => $uid,
							'event_type'  => 'download',
							'object_type' => 'content',
							'object_id'   => $cid,
							'occurred_at' => gmdate( 'Y-m-d H:i:s', $when ),
							'ip_hash'     => hash( 'sha256', "demo-dl-$uid-$cid-$i" . wp_salt( 'auth' ) ),
							'context'     => wp_json_encode( [ 'user_id' => $uid ] ),
						],
						[ '%d', '%s', '%s', '%d', '%s', '%s', '%s' ]
					);
				}
			}
		}

		// One publish per content item, dated to match it.
		if ( $allContent && $existingPublishes < count( $this->contentSpecs ) ) {
			foreach ( $this->contentSpecs as $spec ) {
				if ( ! isset( $this->contentIds[ $spec['slug'] ] ) ) {
					continue;
				}
				$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- seed rows.
					$table,
					[
						'user_id'     => $this->userIds['avery'] ?? 0,
						'event_type'  => 'publish',
						'object_type' => 'content',
						'object_id'   => $this->contentIds[ $spec['slug'] ],
						'occurred_at' => gmdate( 'Y-m-d H:i:s', $now - ( (int) $spec['days_ago'] ) * DAY_IN_SECONDS ),
						'ip_hash'     => '',
						'context'     => null,
					],
					[ '%d', '%s', '%s', '%d', '%s', '%s', '%s' ]
				);
			}
		}
	}
}
