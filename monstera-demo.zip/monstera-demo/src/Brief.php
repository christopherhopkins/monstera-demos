<?php
/**
 * The brief band: on a demo site, the first thing the signed-in persona sees.
 * Who they are, one line of context, three things to try, and "Got it".
 *
 * Renders only when MONSTERA_DEMO_PERSONA names a persona from personas.json
 * and the signed-in user is that persona; dismissing it stores user meta so
 * it never returns for them. A production site never defines the constant.
 */

declare(strict_types=1);

namespace Monstera\Demo;

use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use WP_REST_Request;
use WP_REST_Response;

final class Brief {

	public const CONSTANT       = 'MONSTERA_DEMO_PERSONA';
	public const META_DISMISSED = 'monstera_demo_brief_dismissed';
	public const REST_NAMESPACE = 'monstera-demo/v1';
	public const HANDLE         = 'monstera-demo-brief';

	public static function register(): void {
		if ( '' === self::personaId() ) {
			return;
		}
		add_action( Hooks::PORTAL_SHELL_BEFORE_NOTICES, [ self::class, 'renderPortal' ] );
		add_action( Hooks::ADMIN_SHELL_BEFORE_ROOT, [ self::class, 'renderAdmin' ] );
		add_action( 'rest_api_init', [ self::class, 'registerRoutes' ] );
		// After Monstera's own stylesheets (priority 10), so the band's rules win ties.
		add_action( 'wp_enqueue_scripts', [ self::class, 'enqueuePortal' ], 20 );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueueAdmin' ], 20 );
	}

	/** The persona id the site was booted with, or '' on a site that is not a demo. */
	public static function personaId(): string {
		return defined( self::CONSTANT ) ? (string) constant( self::CONSTANT ) : '';
	}

	/** @return array<string, mixed>|null */
	public static function persona(): ?array {
		$id = self::personaId();
		return '' === $id ? null : Personas::find( $id );
	}

	/**
	 * The band shows to the persona alone: the constant names a persona, the
	 * visitor is signed in as that login, and they have not dismissed it.
	 */
	public static function shouldRender( int $userId = 0 ): bool {
		$persona = self::persona();
		if ( ! $persona ) {
			return false;
		}
		$userId = $userId ?: get_current_user_id();
		if ( ! $userId ) {
			return false;
		}
		$user = get_user_by( 'id', $userId );
		if ( ! $user || $user->user_login !== $persona['login'] ) {
			return false;
		}
		return '1' !== (string) get_user_meta( $userId, self::META_DISMISSED, true );
	}

	public static function renderPortal(): void {
		self::render( 'portal' );
	}

	public static function renderAdmin(): void {
		self::render( 'admin' );
	}

	public static function enqueuePortal(): void {
		self::enqueue( 'monstera-portal' );
	}

	public static function enqueueAdmin(): void {
		self::enqueue( 'monstera-admin' );
	}

	private static function enqueue( string $after ): void {
		if ( ! self::shouldRender() ) {
			return;
		}
		$deps = wp_style_is( $after, 'enqueued' ) || wp_style_is( $after, 'registered' ) ? [ $after ] : [];
		wp_enqueue_style( self::HANDLE, MONSTERA_DEMO_URL . 'assets/brief.css', $deps, MONSTERA_DEMO_VERSION );
		wp_enqueue_script(
			self::HANDLE,
			MONSTERA_DEMO_URL . 'assets/brief.js',
			[],
			MONSTERA_DEMO_VERSION,
			[
				'in_footer' => true,
				'strategy'  => 'defer',
			]
		);
	}

	/** Prints the band for the current user, or nothing. */
	public static function render( string $surface ): void {
		if ( ! self::shouldRender() ) {
			return;
		}
		$persona = self::persona();
		if ( ! $persona ) {
			return;
		}
		$tries = [];
		foreach ( (array) ( $persona['try'] ?? [] ) as $try ) {
			$tries[] = [
				'text' => (string) $try['text'],
				'url'  => self::targetUrl( (array) ( $try['target'] ?? [] ), $surface ),
			];
		}
		?>
		<aside class="m-brief" aria-labelledby="m-brief-who" data-demo-brief data-persona="<?php echo esc_attr( (string) $persona['id'] ); ?>">
			<div class="m-brief__inner">
				<span class="m-brief__eyebrow"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M4 16c0-7 4-11 12-12-1 8-5 12-12 12Z"/><path d="M4 16 13 7"/></svg><?php esc_html_e( 'Demo site', 'monstera-demo' ); ?></span>
				<p class="m-brief__who" id="m-brief-who"><?php echo esc_html( (string) $persona['who'] ); ?></p>
				<p class="m-brief__context"><?php echo esc_html( (string) $persona['context'] ); ?></p>
				<?php if ( $tries ) : ?>
					<div class="m-brief__try">
						<span class="m-brief__try-label" id="m-brief-try"><?php esc_html_e( 'Try', 'monstera-demo' ); ?></span>
						<ul aria-labelledby="m-brief-try">
							<?php foreach ( $tries as $try ) : ?>
								<li>
									<?php if ( '' !== $try['url'] ) : ?>
										<a href="<?php echo esc_url( $try['url'] ); ?>"><?php echo esc_html( $try['text'] ); ?></a>
									<?php else : ?>
										<span><?php echo esc_html( $try['text'] ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
				<div class="m-brief__foot">
					<p class="m-brief__note"><?php esc_html_e( 'A throwaway site in your browser. Nothing here is saved or emailed; close the tab and it is gone.', 'monstera-demo' ); ?></p>
					<button
						class="m-btn"
						data-intent="secondary"
						data-size="sm"
						type="button"
						data-brief-dismiss
						data-endpoint="<?php echo esc_url( rest_url( self::REST_NAMESPACE . '/brief/dismiss' ) ); ?>"
						data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
					><?php esc_html_e( 'Got it', 'monstera-demo' ); ?></button>
				</div>
			</div>
		</aside>
		<?php
	}

	/**
	 * Where a "try" points on the given surface. An entity target opens its
	 * portal page for a portal persona and its admin detail for an admin one;
	 * a route is a portal route; an admin target is an admin page.
	 *
	 * @param array<string, mixed> $target
	 */
	public static function targetUrl( array $target, string $surface ): string {
		$type  = (string) ( $target['type'] ?? '' );
		$admin = 'admin' === $surface;

		switch ( $type ) {
			case 'route':
				return Routing::url( (string) $target['route'] );
			case 'admin':
				return admin_url( 'admin.php?page=' . rawurlencode( (string) $target['page'] ) );
			case 'user':
				$user = get_user_by( 'login', (string) $target['login'] );
				if ( ! $user ) {
					return '';
				}
				return $admin
					? admin_url( 'admin.php?page=monstera-members&id=' . (int) $user->ID )
					: Routing::url( Routing::ROUTE_DIRECTORY );
			case 'support':
				return $admin ? admin_url( 'admin.php?page=monstera-support' ) : Routing::url( Routing::ROUTE_SUPPORT );
		}

		$postTypes = [
			'org'      => [ 'monstera_org', 'monstera-organizations' ],
			'project'  => [ 'monstera_project', 'monstera-projects' ],
			'content'  => [ 'monstera_content', 'monstera-content' ],
			'form'     => [ 'monstera_form', 'monstera-forms' ],
			'subgroup' => [ 'monstera_subgroup', 'monstera-subgroups' ],
		];
		if ( ! isset( $postTypes[ $type ] ) ) {
			return '';
		}
		[ $postType, $page ] = $postTypes[ $type ];
		$post                = get_page_by_path( (string) ( $target['slug'] ?? '' ), OBJECT, $postType );
		if ( ! $post ) {
			return '';
		}
		if ( $admin ) {
			return admin_url( 'admin.php?page=' . $page . '&id=' . (int) $post->ID );
		}
		switch ( $type ) {
			case 'org':
				$url = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $post->post_name ] );
				return empty( $target['tab'] ) ? $url : add_query_arg( 'tab', sanitize_key( (string) $target['tab'] ), $url );
			case 'project':
				return Routing::url( Routing::ROUTE_PROJECT, [ 'id' => (int) $post->ID ] );
			case 'content':
				return Routing::url( Routing::ROUTE_CONTENT, [ 'id' => (int) $post->ID ] );
			case 'form':
				return Routing::url( Routing::ROUTE_FORMS );
			default: // subgroup
				$org = get_post( (int) get_post_meta( $post->ID, 'monstera_subgroup_org_id', true ) );
				return $org
					? add_query_arg( 'tab', 'subgroups', Routing::url( Routing::ROUTE_ORG, [ 'slug' => $org->post_name ] ) )
					: Routing::url( Routing::ROUTE_DASHBOARD );
		}
	}

	public static function registerRoutes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/brief/dismiss',
			[
				'methods'             => 'POST',
				'permission_callback' => static fn (): bool => is_user_logged_in(),
				'callback'            => [ self::class, 'dismiss' ],
			]
		);
	}

	/** Remembers the dismissal for the signed-in user; the band never returns for them. */
	public static function dismiss( WP_REST_Request $request ): WP_REST_Response { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- the REST callback signature.
		update_user_meta( get_current_user_id(), self::META_DISMISSED, '1' );
		return new WP_REST_Response( [ 'dismissed' => true ], 200 );
	}
}
