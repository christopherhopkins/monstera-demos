<?php
/**
 * Reads demo/personas.json, the one source for who a demo visitor is: the
 * programs, and for each persona its program, login, landing surface, the
 * brief's copy and the things to try with their targets.
 */

declare(strict_types=1);

namespace Monstera\Demo;

final class Personas {

	/** @var array<string, mixed>|null */
	private static ?array $data = null;

	/**
	 * @return array<string, array{label: string, description: string}>
	 */
	public static function programs(): array {
		return self::data()['programs'];
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function all(): array {
		return self::data()['personas'];
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function forProgram( string $program ): array {
		return array_values( array_filter( self::all(), static fn ( array $p ): bool => $p['program'] === $program ) );
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public static function find( string $id ): ?array {
		foreach ( self::all() as $persona ) {
			if ( $persona['id'] === $id ) {
				return $persona;
			}
		}
		return null;
	}

	public static function file(): string {
		return MONSTERA_DEMO_DIR . 'personas.json';
	}

	/**
	 * @return array{programs: array<string, array{label: string, description: string}>, personas: array<int, array<string, mixed>>}
	 */
	private static function data(): array {
		if ( null === self::$data ) {
			$raw  = file_get_contents( self::file() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- the companion's own file.
			$data = json_decode( (string) $raw, true );
			if ( ! is_array( $data ) || ! isset( $data['programs'], $data['personas'] ) ) {
				throw new \RuntimeException( 'demo/personas.json is missing or malformed.' );
			}
			self::$data = $data;
		}
		return self::$data;
	}
}
