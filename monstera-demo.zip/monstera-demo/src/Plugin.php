<?php
/**
 * The companion's orchestrator: boots once Monstera has, and owns what the
 * demo adds (the seeder and its programs, the brief band).
 */

declare(strict_types=1);

namespace Monstera\Demo;

final class Plugin {

	/** Fired once the companion has booted. */
	public const BOOTED = 'monstera_demo/booted';

	private static bool $booted = false;

	/**
	 * Runs on `monstera/booted`, so every Monstera module is registered by
	 * the time the companion hooks in. Booting twice is a no-op.
	 */
	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		// The brief band hooks in only when the site was booted with a persona.
		Brief::register();

		do_action( self::BOOTED );
	}

	public static function isBooted(): bool {
		return self::$booted;
	}

	/** The companion's directory, with a trailing slash. */
	public static function dir(): string {
		return MONSTERA_DEMO_DIR;
	}
}
