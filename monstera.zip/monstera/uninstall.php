<?php
/**
 * Fires when the plugin is removed via wp-admin "Delete."
 *
 * Drops all Monstera-owned tables, deletes plugin options, removes roles
 * and the capabilities given to administrators, unschedules cron, and
 * clears Monstera's user meta. Organizations, content and the other Monstera
 * posts stay in the posts table with their meta, as any plugin's posts do;
 * Tools > Erase data removes them first for a site that wants them gone.
 * Files in
 * /wp-content/uploads/mp-secure/ are NOT removed automatically — that
 * directory may contain irreplaceable user uploads; admins must opt in
 * via the Tools → Erase data action before uninstalling.
 */

declare(strict_types=1);

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

$tables = [
	'monstera_subgroup_members',
	'monstera_content_subgroups',
	'monstera_secure_files',
	'monstera_notification_log',
	'monstera_activity_log',
	'monstera_project_members',
	'monstera_content_projects',
	'monstera_project_intake',
	'monstera_support_requests',
	'monstera_support_messages',
	'monstera_alert_dismissals',
	'monstera_org_members',
];

foreach ( $tables as $name ) {
	$table = $wpdb->prefix . $name;
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- removing Monstera's own tables at uninstall.
}

$options = [
	'monstera_version',
	'monstera_db_version',
	'monstera_settings',
	'monstera_notification_templates',
	'monstera_active_modules',
	'monstera_rate_table',
	'monstera_renewal_window',
	'monstera_retention_days',
	'monstera_portal_prefix',
	'monstera_use_case',
	'monstera_content_labels',
	'monstera_support_recipients',
	'monstera_support_email',
	'monstera_onboarding_complete',
	'monstera_onboarding_skipped',
	'monstera_settings_saved',
	'monstera_tool_runs',
	'monstera_a11y_contact_email',
	'monstera_a11y_known_limitations',
	'monstera_a11y_last_reviewed',
	'monstera_caps_version',
	'monstera_demo_seeded',
	'monstera_demo_seed_version',
	'monstera_rewrites_flushed_for',
	'monstera_secure_usage',
	'monstera_daily_sync_last',
];
foreach ( $options as $option ) {
	delete_option( $option );
}

// Remove every Monstera role and the capabilities activation mirrors onto
// WordPress's administrators. The Capabilities class is required directly
// (no autoloader runs at uninstall) so the list can never drift from the one
// install() registers; UninstallGuardTest holds this file to that.
require_once __DIR__ . '/src/Core/Capabilities.php';
\Monstera\Core\Capabilities::uninstall();

// Clear every Monstera cron event. We reuse the canonical hook list from the
// Cron class (required directly — the plugin's autoloader isn't registered
// during uninstall) so this can never drift from what Activator scheduled.
require_once __DIR__ . '/src/BackgroundSync/Cron.php';
\Monstera\BackgroundSync\Cron::clear();

// The one-organization key the People-model track retired when DB version 8
// moved who belongs where into monstera_org_members. No build registers or
// reads it any more, and NoAssociatedOrgTest keeps src/, demo/, tests/ and
// scripts/ free of its name, so uninstall.php is the one place it is still
// spelled: for the rows a site that ran an earlier build still carries.
$wpdb->delete( $wpdb->usermeta, [ 'meta_key' => 'monstera_associated_org' ], [ '%s' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- sweeping a retired key's rows at uninstall.
delete_metadata( 'user', 0, 'monstera_position', '', true );
delete_metadata( 'user', 0, 'monstera_bio', '', true );
delete_metadata( 'user', 0, 'monstera_profile_photo', '', true );
delete_metadata( 'user', 0, 'monstera_show_in_directory', '', true );
delete_metadata( 'user', 0, 'monstera_membership_expires', '', true );
delete_metadata( 'user', 0, 'monstera_last_login', '', true );
delete_metadata( 'user', 0, 'monstera_theme', '', true );
delete_metadata( 'user', 0, 'monstera_saved', '', true );
delete_metadata( 'user', 0, 'monstera_stood_alone', '', true );
delete_metadata( 'user', 0, 'monstera_invited_account', '', true );
delete_metadata( 'user', 0, 'monstera_columns', '', true );
delete_metadata( 'user', 0, 'monstera_expiry_notices', '', true );
