<?php
/**
 * Plugin Name:       Monstera
 * Plugin URI:        https://monstera.plugin
 * Description:       Member & client portals for WordPress. Organizations, projects, gated content, sub-groups, alerts, support requests, custom roles. Serves both association membership portals and agency client portals. No third-party plugin dependencies. Distinctive botanical identity.
 * Version:           1.0.0-alpha
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Author:            Monstera
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       monstera
 * Domain Path:       /languages
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

if ( defined( 'MONSTERA_VERSION' ) ) {
	return;
}

const MONSTERA_VERSION  = '1.0.0-alpha';
const MONSTERA_DB_VERSION = '6';
const MONSTERA_FILE     = __FILE__;
define( 'MONSTERA_DIR', plugin_dir_path( __FILE__ ) );
define( 'MONSTERA_URL', plugin_dir_url( __FILE__ ) );
define( 'MONSTERA_BASENAME', plugin_basename( __FILE__ ) );

if ( ! version_compare( PHP_VERSION, '8.1', '>=' ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html__( 'Monstera requires PHP 8.1 or higher. The plugin is inactive.', 'monstera' )
			);
		}
	);
	return;
}

require_once MONSTERA_DIR . 'src/autoload.php';

register_activation_hook( __FILE__, [ \Monstera\Activator::class, 'activate' ] );
register_deactivation_hook( __FILE__, [ \Monstera\Deactivator::class, 'deactivate' ] );

add_action(
	'plugins_loaded',
	static function (): void {
		\Monstera\Plugin::instance()->boot();
	},
	5
);
