=== Monstera — Member & Client Portals ===
Contributors: monstera
Tags: membership, members, portal, gated content, client portal, projects, agency
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.0-alpha
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A native WordPress portal toolkit that serves both association membership portals and agency client portals. One plugin, one identity, modular features. No third-party plugin dependencies. Distinctive botanical visual identity.

== Description ==

Monstera powers portals between an organization and the people connected to it — whether that's an association serving its member orgs or an agency serving its clients. One codebase, one visual identity, modules you toggle based on what you're running.

Try it first: the live demos at https://christopherhopkins.github.io/monstera-demos/ boot a throwaway site in your browser, signed in as an agency admin, a client's main contact, a member of an association, an individual with no organization and more, each with a note at the top saying what to try.

For associations: organizations, members, committees as sub-groups, gated content (reports, board packages), renewals, member directory.

For agencies: client organizations, stakeholders, projects with lifecycle and discovery, deliverables, broadcast alerts (outages, status, downtime), support requests, resource library.

Core capabilities:

* Organizations as a custom post type, with seat limits, tiers, status lifecycle (Active / Suspended / Archived)
* Four custom roles spanning both use cases: Admin, Organization Manager, Member, Standalone
* Gated content with a 6-rule visibility engine, inspectable from a "Why can't they see this?" admin wizard
* Sub-groups (committees, departments) and Projects (with lifecycle and discovery) as first-class entities
* Secure file storage outside /uploads/, signed-URL downloads with a 5-minute window
* Broadcast alerts with severity (info / warning / critical), scope (all / org / project), expiry, dismissal
* Front-end support requests with reference numbers and admin inbox
* Daily background reconciliation: orphans, expirations, auto-suspension, activity purge
* Notifications via wp_mail(), token-replaced templates, SMTP plugin auto-detection
* Organization self-service: org admins invite/remove members (within their seat limit) and renew membership from the portal
* Membership renewal sets expiry to one year from payment (no pro-rating on early renewal); billing plugs in via a payment hook
* WP-CLI: wp monstera sync, wp monstera export members, wp monstera renew, more

Visual identity:

Botanical and considered — deep leaf greens, warm light surfaces, editorial typography (Fraunces + Inter), hand-drawn leaf motifs. Light theme by default with member-controlled dark mode. Custom React admin shell, not stock WP chrome.

== Installation ==

1. Upload to /wp-content/plugins/monstera/ and activate.
2. On first visit to the Monstera Settings page, pick your use case — Association, Agency, or Both — to pre-enable the right modules.
3. Visit Settings → Permalinks once to flush rewrite rules.
4. Add your first organization at Monstera → Organizations.

For nginx servers, see docs/NGINX.md for the secure-storage deny rule.

== Frequently Asked Questions ==

= A client/member says they can't see something =

Open the content edit screen, click "Test visibility", enter their user ID. The wizard walks the 6 visibility rules (post status, org association, visibility meta, sub-group gate, project gate, org active) and tells you which one failed.

= Does Monstera require Stripe / Gravity Forms / WooCommerce? =

No. Monstera is built without third-party plugin dependencies. Payments, GF, WC, bbPress are all optional and detected at runtime.

= Can I switch from association mode to agency mode later? =

Yes. Use-case selection just toggles which modules are enabled and which labels are set. You can change either at any time in Settings → Modules.

== Changelog ==

= Unreleased =
* People model: who belongs where now lives in a memberships table of its own, one row per person and organization, each with a tier (Organization admin, Manager or Member). A person can belong to several organizations and switches between them from the portal's top bar; their WordPress role follows the highest tier they hold. The people who run the program are the Team, with two roles: Team manager and Team member. A project's lead is one of the Team. Removing someone who never signed in ends their invitation, and an account the invitation made is removed with it. Database version 10: a site at database version 7 or older is reset on upgrade, not migrated.
* At a glance: the admin rail is in groups, People and Work each under a heading every screen reader reads and the rest at its foot. The organization list says how many projects are under way and who the account lead is, and each person picks the columns they read. The organization field of the member, staff, project and sub-group details and the Members list is a searchable combobox that marks a suspended or archived organization and offers only active ones where a save needs one. An organization's Active is WordPress's Published and its Suspended and Archived are drafts, so a draft made in WordPress reads as suspended; one that is not active takes no one new and no team until it is reactivated, which its detail offers where the invite card and Assign were. An organization in the trash grants its members nothing until it is restored, and a refusal names a person only to the team and to someone who shares an organization with them. Each organization can have an account lead, chosen from the staff assigned to it and named to its people in the portal with an email link. Detail pages carry a summary of their organization, and content rows name their project. The portal's project page opens with whom to ask and says the client's next step and by when, which staff write on the project. Sub-groups are named only to the people they concern; a client author's save never changes who an item reaches once staff shared it further; and membership and organization dates count the site's day, not UTC's.
* Member activation: new members now receive a working set-password link in the welcome email (previously a plain login link with an unknowable random password, so they couldn't sign in).
* Capabilities are now enforced as real checks: view_projects, submit_intake, submit_support, view_directory, and download_content gate their REST endpoints, portal navigation, and the secure download handler (admins always pass via manage_monstera).
* Organization self-service: org admins can invite members (respecting seat limits), remove members, edit their org profile, and renew membership — all from the portal. A removed member who has signed in keeps their account as a standalone member; an invited person who never signed in has the invitation ended, and an account the invitation made is removed.
* Block editor: a body written without block markup (the demo content, an import, a REST write) opens as paragraphs, headings and the rest, in the admin and in the portal's editor. It opened as WordPress's Classic block, which needs the classic editor these pages do not load: on WordPress 6.5 it failed with "This block has encountered an error", and on 7.1 it showed the body read-only. The first edit saves the body as block markup. The Classic block is no longer offered in the inserter, and paragraphs and headings in the editor no longer carry ARIA attributes their role does not allow. The inserter opens under its Block button with room for its blocks: on WordPress 7.1, with the button low in the window, it opened over the page's heading, and on 6.5 it was too short to show a block. On 6.5 its blocks were also a third of their width, their names broken letter by letter; they now fill its columns. On WordPress 7.1 the editor drew without WordPress's own block editor styles, its inserter among them; they load again. "Skip to the selected block", at the foot of the block settings, now shows when it has keyboard focus; it stayed off the page.
* Expiry reminders after a manual change: moving an organization's expiry by hand (the admin's "Renews on", or any other write of the date) now starts the new term's 30, 14, 7 and 1-day reminders and its expired notice. Only a renewal did before, so a term extended by hand had its reminders skipped as already sent. A save that leaves the date as it was sends nothing again.
* Membership renewal: renewing sets expiry to one year from the payment date with no pro-rating on early renewal, clears the expiry reminders, and reactivates an org that was auto-suspended for expiry. Online billing plugs in via the monstera/payment_completed seam; Stripe lands in the Payments module.
* Forms now honor standalone-member audience targeting, matching the content visibility engine.
* Support requests gained pending/closed transitions and a status endpoint; resolving a missing request now returns 404 instead of a misleading success.
* Member profile photos can be set from the admin member editor and the self-service profile endpoint (the meta was read in several places but never written).
* "Test visibility" wizard now shows the project-gate rule and the docblock reads 6 rules (the engine was already 6; the wizard listed 5).
* New WP-CLI command: wp monstera renew <org_id>, or wp monstera renew --member=<user_id> for a standalone member (exercises the renewal mechanics without a payment provider).
* A standalone member's portal pauses when their own membership ends, as an ended organization's does: the Portal, their projects and items say the membership has ended and offer the renewal, their downloads wait, and the resources, the directory and the notices hold back until it is renewed.
* A standalone member is told before their own membership ends, 30, 14, 7 and 1 days out, and the day after it has, as an organization's admins and managers are told of theirs, in two emails of their own that name no organization (Settings › Notifications: "Standalone membership expiring soon" and "Standalone membership expired"). A renewal, or a date the team moves by hand, starts the reminders for the new date.
* Test visibility: a fix saved while another member was chosen, or after "Try another member", no longer shows the first member's verdict; the rules run for the member chosen when the save answers, on the item as saved, and no other fix is offered until it has.
* Developers: monstera/org_created fires when an organization is created in the admin, with its id, once it is saved whole (its fields, first members and renewal date). It was documented and never fired.
* The portal's download panel says "Visible to N members" of the reader's own organizations: their people who can see the item, its sub-group and project limits counted, never another client's; an item for everyone counts theirs too, and the line is left out where none of their organizations reaches the item. The team reads the whole count, as the admin gives it.
* An organization in the trash is named nowhere: not in the line that lists a person's organizations, the profile, the expired page or the words for a person in several; not in the shell, whose nav no longer leads to its closed hub; not as an item's audience to a client author, in a refusal or on a support request's row; not in an email, a download note or a welcome that falls to a person's first organization; and the alert composer's reach counts neither it nor its people.

= 1.0.0-alpha =
* Initial release. Organizations, members, content with the 6-rule visibility engine, sub-groups, projects with discovery, access control, secure file handler, notifications, background sync, forms library, reporting, alerts, support requests, custom admin shell, member/client portal with Interactivity API.
