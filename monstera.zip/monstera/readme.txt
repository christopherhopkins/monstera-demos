=== Monstera — Member & Client Portals ===
Contributors: monstera
Tags: membership, members, portal, gated content, client portal, projects, agency
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.0-alpha
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A native WordPress portal toolkit that serves both association membership portals and agency client portals. One plugin, one identity, modular features. No third-party plugin dependencies. Distinctive botanical visual identity.

== Description ==

Monstera powers portals between an organization and the people connected to it — whether that's an association serving its member orgs or an agency serving its clients. One codebase, one visual identity, modules you toggle based on what you're running.

Try it first: the live demos at https://christopherhopkins.github.io/monstera-demos/ boot a throwaway site in your browser, signed in as an agency admin, a client's main contact, a member of an association, an individual with no organization and more, each with a note at the top saying what to try.

For associations: organizations, members, committees as sub-groups, gated content (reports, board packages), renewals, member directory.

For agencies: client organizations, stakeholders, projects with lifecycle and discovery, deliverables, broadcast alerts (outages, status, downtime), support requests, resource library.

Core capabilities:

* Organizations as a custom post type, with seat limits, tiers, status lifecycle (Active / Suspended / Archived)
* Four custom roles spanning both use cases: Admin, Organization Manager, Member, Standalone
* Gated content with a 6-rule visibility engine, inspectable from a "Why can't they see this?" admin wizard
* Sub-groups (committees, departments) and Projects (with lifecycle and discovery) as first-class entities
* Secure file storage outside /uploads/, signed-URL downloads with a 5-minute window
* Broadcast alerts with severity (info / warning / critical), scope (all / org / project), expiry, dismissal
* Front-end support requests with reference numbers and admin inbox
* Daily background reconciliation: orphans, expirations, auto-suspension, activity purge
* Notifications via wp_mail(), token-replaced templates, SMTP plugin auto-detection
* Organization self-service: org admins invite/remove members (within their seat limit) and renew membership from the portal
* Membership renewal sets expiry to one year from payment (no pro-rating on early renewal); billing plugs in via a payment hook
* WP-CLI: wp monstera sync, wp monstera export members, wp monstera renew, more

Visual identity:

Botanical and considered — deep leaf greens, warm light surfaces, editorial typography (Fraunces + Inter), hand-drawn leaf motifs. Light theme by default with member-controlled dark mode. Custom React admin shell, not stock WP chrome.

== Installation ==

1. Upload to /wp-content/plugins/monstera/ and activate.
2. On first visit to the Monstera Settings page, pick your use case — Association, Agency, or Both — to pre-enable the right modules.
3. Visit Settings → Permalinks once to flush rewrite rules.
4. Add your first organization at Monstera → Organizations.

For nginx servers, see docs/NGINX.md for the secure-storage deny rule.

== Frequently Asked Questions ==

= A client/member says they can't see something =

Open the content edit screen, click "Test visibility", enter their user ID. The wizard walks the 6 visibility rules (post status, org association, visibility meta, sub-group gate, project gate, org active) and tells you which one failed.

= Does Monstera require Stripe / Gravity Forms / WooCommerce? =

No. Monstera is built without third-party plugin dependencies. Payments, GF, WC, bbPress are all optional and detected at runtime.

= Can I switch from association mode to agency mode later? =

Yes. Use-case selection just toggles which modules are enabled and which labels are set. You can change either at any time in Settings → Modules.

== Changelog ==

= Unreleased =
* Member activation: new members now receive a working set-password link in the welcome email (previously a plain login link with an unknowable random password, so they couldn't sign in).
* Capabilities are now enforced as real checks: view_projects, submit_intake, submit_support, view_directory, and download_content gate their REST endpoints, portal navigation, and the secure download handler (admins always pass via manage_monstera).
* Organization self-service: org admins can invite members (respecting seat limits), remove members (kept as standalone accounts, not deleted), edit their org profile, and renew membership — all from the portal.
* Membership renewal: renewing sets expiry to one year from the payment date with no pro-rating on early renewal, clears the expiry reminders, and reactivates an org that was auto-suspended for expiry. Online billing plugs in via the monstera/payment_completed seam; Stripe lands in the Payments module.
* Forms now honor standalone-member audience targeting, matching the content visibility engine.
* Support requests gained pending/closed transitions and a status endpoint; resolving a missing request now returns 404 instead of a misleading success.
* Member profile photos can be set from the admin member editor and the self-service profile endpoint (the meta was read in several places but never written).
* "Test visibility" wizard now shows the project-gate rule and the docblock reads 6 rules (the engine was already 6; the wizard listed 5).
* New WP-CLI command: wp monstera renew <org_id> (exercises the renewal mechanics without a payment provider).

= 1.0.0-alpha =
* Initial release. Organizations, members, content with the 6-rule visibility engine, sub-groups, projects with discovery, access control, secure file handler, notifications, background sync, forms library, reporting, alerts, support requests, custom admin shell, member/client portal with Interactivity API.
