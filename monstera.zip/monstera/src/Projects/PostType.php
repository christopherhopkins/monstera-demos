<?php
declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

final class PostType {

	public const SLUG = 'monstera_project';

	public static function register(): void {
		register_post_type(
			self::SLUG,
			[
				'labels'          => [
					'name'               => __( 'Projects', 'monstera' ),
					'singular_name'      => __( 'Project', 'monstera' ),
					'menu_name'          => __( 'Projects', 'monstera' ),
					'add_new'            => __( 'Add project', 'monstera' ),
					'add_new_item'       => __( 'Add project', 'monstera' ),
					'edit_item'          => __( 'Edit project', 'monstera' ),
					'view_item'          => __( 'View project', 'monstera' ),
					'search_items'       => __( 'Search projects', 'monstera' ),
					'not_found'          => __( 'No projects yet.', 'monstera' ),
					'not_found_in_trash' => __( 'No projects in trash.', 'monstera' ),
				],
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				'show_in_rest'    => true,
				'rest_base'       => 'projects',
				'supports'        => [ 'title', 'editor', 'excerpt', 'custom-fields', 'revisions' ],
				'has_archive'     => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'capabilities'    => [
					'edit_posts'         => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'  => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}
}
