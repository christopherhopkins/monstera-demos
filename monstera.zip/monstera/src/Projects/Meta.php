<?php
declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\Forms\Fields;

defined( 'ABSPATH' ) || exit;

final class Meta {

	public const STATUS_PROPOSED    = 'proposed';
	public const STATUS_DISCOVERY   = 'discovery';
	public const STATUS_IN_PROGRESS = 'in_progress';
	public const STATUS_REVIEW      = 'review';
	public const STATUS_ON_HOLD     = 'on_hold';
	public const STATUS_COMPLETED   = 'completed';
	public const STATUS_ARCHIVED    = 'archived';

	public const KEY_STATUS               = 'monstera_project_status';
	public const KEY_ORG_ID               = 'monstera_project_org_id';
	public const KEY_STANDALONE_MEMBER_ID = 'monstera_project_standalone_member_id';
	public const KEY_SUBGROUP_IDS         = 'monstera_project_subgroup_ids';
	public const KEY_STARTED_ON           = 'monstera_project_started_on';
	public const KEY_ENDED_ON             = 'monstera_project_ended_on';
	public const KEY_DUE_ON               = 'monstera_project_due_on';
	public const KEY_BUDGET_REF           = 'monstera_project_budget_ref';
	public const KEY_PRIMARY_CONTACT      = 'monstera_project_primary_contact';
	public const KEY_LEAD                 = 'monstera_project_lead_id';
	/** The next step for the client: one sentence and an optional Y-m-d date (At-a-glance track, FR8). */
	public const KEY_NEXT_STEP     = 'monstera_project_next_step';
	public const KEY_NEXT_STEP_BY  = 'monstera_project_next_step_by';
	public const KEY_SCOPE         = 'monstera_project_scope';
	public const KEY_INTAKE_SCHEMA = 'monstera_project_intake_schema';

	/**
	 * Canonical status order (used for sorting and pipeline displays).
	 *
	 * @return string[]
	 */
	public static function statusOrder(): array {
		return [
			self::STATUS_PROPOSED,
			self::STATUS_DISCOVERY,
			self::STATUS_IN_PROGRESS,
			self::STATUS_REVIEW,
			self::STATUS_ON_HOLD,
			self::STATUS_COMPLETED,
			self::STATUS_ARCHIVED,
		];
	}

	public static function statusLabel( string $status ): string {
		return match ( $status ) {
			self::STATUS_PROPOSED    => __( 'Proposed', 'monstera' ),
			self::STATUS_DISCOVERY   => __( 'Discovery', 'monstera' ),
			self::STATUS_IN_PROGRESS => __( 'In progress', 'monstera' ),
			self::STATUS_REVIEW      => __( 'In review', 'monstera' ),
			self::STATUS_ON_HOLD     => __( 'On hold', 'monstera' ),
			self::STATUS_COMPLETED   => __( 'Completed', 'monstera' ),
			self::STATUS_ARCHIVED    => __( 'Archived', 'monstera' ),
			default                  => ucfirst( str_replace( '_', ' ', $status ) ),
		};
	}

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_STATUS,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::STATUS_PROPOSED,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => in_array( $v, self::statusOrder(), true ) ? $v : self::STATUS_PROPOSED,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ORG_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBER_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SUBGROUP_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STARTED_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ENDED_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_DUE_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_BUDGET_REF,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_PRIMARY_CONTACT,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
			]
		);

		// The lead is one of the team, a staff account, and so is named here
		// and not by a row among the project's members, who are the client's
		// people (People-model track, FR4). A project with no lead has no value.
		register_post_meta(
			PostType::SLUG,
			self::KEY_LEAD,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
			]
		);

		// What the client is asked to do next, and by when: staff write it on
		// the project detail, the portal shows it on the project page and its
		// rows. Only Repository::setNextStep() writes either (At-a-glance
		// track); the auth callback refuses every other door, which
		// update_post_meta() does not consult.
		register_post_meta(
			PostType::SLUG,
			self::KEY_NEXT_STEP,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => '__return_false',
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_NEXT_STEP_BY,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => '__return_false',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SCOPE,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'wp_kses_post',
			]
		);

		// Intake schema: stored as JSON-encoded string. Shape:
		//   [{ key, label, type: text|textarea|select|date|file, options?, required, help }]
		register_post_meta(
			PostType::SLUG,
			self::KEY_INTAKE_SCHEMA,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => self::sanitizeSchema( (string) $v ),
			]
		);
	}

	private static function sanitizeSchema( string $raw ): string {
		// Tidied by the rule a form's questions follow (Forms\Fields).
		return (string) wp_json_encode( Fields::tidy( json_decode( $raw, true ) ) );
	}
}
