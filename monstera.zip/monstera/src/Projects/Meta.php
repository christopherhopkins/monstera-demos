<?php
declare(strict_types=1);

namespace Monstera\Projects;

final class Meta {

	public const STATUS_PROPOSED    = 'proposed';
	public const STATUS_DISCOVERY   = 'discovery';
	public const STATUS_IN_PROGRESS = 'in_progress';
	public const STATUS_REVIEW      = 'review';
	public const STATUS_ON_HOLD     = 'on_hold';
	public const STATUS_COMPLETED   = 'completed';
	public const STATUS_ARCHIVED    = 'archived';

	public const KEY_STATUS               = 'monstera_project_status';
	public const KEY_ORG_ID               = 'monstera_project_org_id';
	public const KEY_STANDALONE_MEMBER_ID = 'monstera_project_standalone_member_id';
	public const KEY_SUBGROUP_IDS         = 'monstera_project_subgroup_ids';
	public const KEY_STARTED_ON           = 'monstera_project_started_on';
	public const KEY_ENDED_ON             = 'monstera_project_ended_on';
	public const KEY_DUE_ON               = 'monstera_project_due_on';
	public const KEY_BUDGET_REF           = 'monstera_project_budget_ref';
	public const KEY_PRIMARY_CONTACT      = 'monstera_project_primary_contact';
	public const KEY_SCOPE                = 'monstera_project_scope';
	public const KEY_INTAKE_SCHEMA        = 'monstera_project_intake_schema';

	/**
	 * Canonical status order (used for sorting and pipeline displays).
	 *
	 * @return string[]
	 */
	public static function statusOrder(): array {
		return [
			self::STATUS_PROPOSED,
			self::STATUS_DISCOVERY,
			self::STATUS_IN_PROGRESS,
			self::STATUS_REVIEW,
			self::STATUS_ON_HOLD,
			self::STATUS_COMPLETED,
			self::STATUS_ARCHIVED,
		];
	}

	public static function statusLabel( string $status ): string {
		return match ( $status ) {
			self::STATUS_PROPOSED    => __( 'Proposed', 'monstera' ),
			self::STATUS_DISCOVERY   => __( 'Discovery', 'monstera' ),
			self::STATUS_IN_PROGRESS => __( 'In progress', 'monstera' ),
			self::STATUS_REVIEW      => __( 'In review', 'monstera' ),
			self::STATUS_ON_HOLD     => __( 'On hold', 'monstera' ),
			self::STATUS_COMPLETED   => __( 'Completed', 'monstera' ),
			self::STATUS_ARCHIVED    => __( 'Archived', 'monstera' ),
			default                  => ucfirst( str_replace( '_', ' ', $status ) ),
		};
	}

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_STATUS,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::STATUS_PROPOSED,
				'show_in_rest'      => [
					'schema' => [ 'enum' => self::statusOrder() ],
				],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, self::statusOrder(), true ) ? $v : self::STATUS_PROPOSED,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ORG_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBER_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SUBGROUP_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STARTED_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ENDED_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_DUE_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_BUDGET_REF,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_PRIMARY_CONTACT,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SCOPE,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'wp_kses_post',
			]
		);

		// Intake schema: stored as JSON-encoded string. Shape:
		//   [{ key, label, type: text|textarea|select|date|file, options?, required, help }]
		register_post_meta(
			PostType::SLUG,
			self::KEY_INTAKE_SCHEMA,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => self::sanitizeSchema( (string) $v ),
			]
		);
	}

	private static function sanitizeSchema( string $raw ): string {
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return '[]';
		}
		$cleaned = [];
		foreach ( $decoded as $field ) {
			if ( ! is_array( $field ) || empty( $field['key'] ) ) {
				continue;
			}
			$cleaned[] = [
				'key'      => sanitize_key( (string) $field['key'] ),
				'label'    => sanitize_text_field( (string) ( $field['label'] ?? $field['key'] ) ),
				'type'     => in_array( $field['type'] ?? 'text', [ 'text', 'textarea', 'select', 'date', 'file', 'number' ], true ) ? $field['type'] : 'text',
				'options'  => array_map( 'sanitize_text_field', (array) ( $field['options'] ?? [] ) ),
				'required' => ! empty( $field['required'] ),
				'help'     => sanitize_text_field( (string) ( $field['help'] ?? '' ) ),
			];
		}
		return (string) wp_json_encode( $cleaned );
	}
}
