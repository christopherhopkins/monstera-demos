<?php
/**
 * The files a discovery file question holds.
 *
 * What a client sends at discovery (contracts, brand assets, current
 * screens) is as confidential as a deliverable, so a file answer is a secure
 * file, never a Media Library attachment: stored under
 * mp-secure/projects/<project id>/, recorded in the secure-file registry with
 * the project's question as its owner and who uploaded it, and served only
 * through the Downloader. A question holds at most maxCount() files of at
 * most maxBytes() each, of the types secure files may be.
 *
 * The question's row in the intake table stays its "answered" marker: it
 * exists while the question holds a file, and names the latest upload's
 * who and when.
 */

declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\Content\SecureFiles;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\SecureStorage;
use Monstera\Members\UserMeta;

final class IntakeFiles {

	/** 50 MB, or the server's upload limit when that is lower. */
	private const DEFAULT_MAX_BYTES = 52428800;

	private const DEFAULT_MAX_COUNT = 10;

	/**
	 * The largest file a question takes: the filter's value, never more than
	 * the server's upload limit, since PHP refuses a larger file before the
	 * plugin sees it.
	 */
	public static function maxBytes(): int {
		$wanted = max( 1, (int) apply_filters( Hooks::FILTER_INTAKE_FILE_MAX_BYTES, self::DEFAULT_MAX_BYTES ) );
		$server = (int) wp_max_upload_size();
		return $server > 0 ? min( $wanted, $server ) : $wanted;
	}

	public static function maxCount(): int {
		return max( 1, (int) apply_filters( Hooks::FILTER_INTAKE_FILE_MAX_COUNT, self::DEFAULT_MAX_COUNT ) );
	}

	/** The limits in words, under the picker (comp 97). */
	public static function limitsLine(): string {
		return sprintf(
			/* translators: 1: the largest file allowed, e.g. "50 MB", 2: how many files a question takes */
			__( 'PDF, Office, CSV, zip or images · %1$s each · up to %2$d', 'monstera' ),
			size_format( self::maxBytes() ),
			self::maxCount()
		);
	}

	/**
	 * Who sent a file and when, as its row writes it: "Sasha Reyes · Oct 1",
	 * in the site's language and time zone.
	 *
	 * @param array{uploaded_by: string, uploaded_at: string} $file
	 */
	public static function sentBy( array $file ): string {
		$when = $file['uploaded_at'] ? (string) wp_date( 'M j', (int) strtotime( $file['uploaded_at'] ) ) : '';
		return implode( ' · ', array_filter( [ (string) $file['uploaded_by'], $when ] ) );
	}

	/**
	 * size_format() of one of each unit, B to TB, for the sizes the browser
	 * writes while a file uploads: the site's own unit words.
	 *
	 * @return list<string>
	 */
	public static function sizeUnits(): array {
		return array_map( static fn ( int $power ): string => (string) size_format( 1024 ** $power ), range( 0, 4 ) );
	}

	/** The extensions the file picker offers, for its accept attribute. */
	public static function accept(): string {
		$extensions = [];
		foreach ( array_keys( SecureFiles::types() ) as $pattern ) {
			foreach ( explode( '|', (string) $pattern ) as $extension ) {
				$extensions[] = '.' . $extension;
			}
		}
		return implode( ',', $extensions );
	}

	/**
	 * What an activity row about one of a project's intake files records:
	 * the file, its name and the question it answers, by key and by label
	 * (as asked when the row was written).
	 *
	 * @param array{id: int, name: string, field_key?: string} $file
	 * @return array{file_id: int, name: string, field_key: string, label: string}
	 */
	public static function activityContext( int $projectId, array $file, string $key ): array {
		$label = '';
		foreach ( Discovery::schema( $projectId ) as $question ) {
			if ( (string) $question['key'] === $key ) {
				$label = (string) $question['label'];
			}
		}
		return [
			'file_id'   => (int) $file['id'],
			'name'      => (string) $file['name'],
			'field_key' => $key,
			'label'     => $label,
		];
	}

	/**
	 * Why an upload cannot be added to a question, in words a member can
	 * act on, or null. The question comes first (a question that takes no
	 * files, or is full, refuses any upload), then the upload itself.
	 *
	 * @param array<string, mixed>|null $upload One entry of the request's files.
	 */
	public static function refusal( int $projectId, string $key, ?array $upload ): ?string {
		if ( ! in_array( $key, Discovery::fileKeys( $projectId ), true ) ) {
			return __( 'That question does not take files.', 'monstera' );
		}
		if ( count( ( new self() )->forQuestion( $projectId, $key ) ) >= self::maxCount() ) {
			return self::sayFull();
		}
		$error = (int) ( $upload['error'] ?? UPLOAD_ERR_NO_FILE );
		// PHP refused the size before WordPress saw the file.
		if ( in_array( $error, [ UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ], true ) || ( $upload && (int) ( $upload['size'] ?? 0 ) > self::maxBytes() ) ) {
			return self::sayTooBig();
		}
		if ( ! $upload || UPLOAD_ERR_OK !== $error || empty( $upload['tmp_name'] ) || ! is_file( (string) $upload['tmp_name'] ) ) {
			return __( 'Choose a file to add.', 'monstera' );
		}
		if ( '' === SecureFiles::checkedType( $upload ) ) {
			return self::sayWrongType();
		}
		return null;
	}

	/** The refusal for a question that holds its most files. */
	public static function sayFull(): string {
		return sprintf(
			/* translators: %d: how many files a question holds at most */
			_n( 'This question already has %d file. Remove it to add another.', 'This question already has %d files. Remove one to add another.', self::maxCount(), 'monstera' ),
			self::maxCount()
		);
	}

	/** The refusal for a file over the limit. */
	public static function sayTooBig(): string {
		/* translators: %s: the largest file allowed, e.g. "50 MB" */
		return sprintf( __( 'That file is over %s.', 'monstera' ), size_format( self::maxBytes() ) );
	}

	/**
	 * Whether the length a browser declared is over post_max_size, past which
	 * PHP discards the whole body. A post_max_size of 0 is no limit.
	 */
	public static function bodyTooLarge( int $declared, string $postMaxSize ): bool {
		$limit = wp_convert_hr_to_bytes( $postMaxSize );
		return $limit > 0 && $declared > $limit;
	}

	/** The refusal for a type off the allowlist. */
	public static function sayWrongType(): string {
		return __( "That kind of file can't be added. Use a PDF, an Office document, a CSV or text file, a zip or an image.", 'monstera' );
	}

	/**
	 * Store an upload refusal() let through as the question's newest file.
	 * Two uploads can pass refusal() together for the question's last place;
	 * the one that finds the question over its limit once stored takes its
	 * file back.
	 *
	 * @param array{name:string, tmp_name:string, size:int, type?:string} $upload
	 * @return array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}
	 * @throws \OverflowException When the question was filled meanwhile; the message is sayFull().
	 */
	public function store( int $projectId, string $key, array $upload, int $userId ): array {
		$fileId = ( new SecureFiles() )->put(
			SecureStorage::rootPath() . '/projects/' . $projectId,
			$upload,
			[
				'content_id'    => 0,
				'project_id'    => $projectId,
				'field_key'     => $key,
				'uploaded_by'   => $userId,
				'original_name' => self::displayName( (string) $upload['name'] ),
				'mime_type'     => SecureFiles::checkedType( $upload ),
			]
		);
		if ( count( $this->forQuestion( $projectId, $key ) ) > self::maxCount() ) {
			( new SecureFiles() )->delete( $fileId );
			throw new \OverflowException( esc_html( self::sayFull() ) );
		}
		$this->syncAnswer( $projectId, $key );
		return (array) $this->find( $fileId );
	}

	/**
	 * Remove a file from disk and the registry; the question's answer
	 * follows what is left.
	 */
	public function remove( int $fileId ): void {
		$row = $this->row( $fileId );
		if ( ! $row ) {
			return;
		}
		( new SecureFiles() )->delete( $fileId );
		$this->syncAnswer( (int) $row['project_id'], (string) $row['field_key'] );
	}

	/**
	 * One intake file as callers see it, or null when the id is not an
	 * intake file (a content item's file is not one).
	 *
	 * @return array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string, project_id: int, field_key: string}|null
	 */
	public function find( int $fileId ): ?array {
		$row = $this->row( $fileId );
		return $row ? self::describe( $row ) + [
			'project_id' => (int) $row['project_id'],
			'field_key'  => (string) $row['field_key'],
		] : null;
	}

	/**
	 * A question's files, oldest first.
	 *
	 * @return list<array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}>
	 */
	public function forQuestion( int $projectId, string $key ): array {
		return $this->forProject( $projectId )[ $key ] ?? [];
	}

	/**
	 * Every file of a project's intake by question key, each list oldest
	 * first.
	 *
	 * @return array<string, list<array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}>>
	 */
	public function forProject( int $projectId ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE content_id = 0 AND project_id = %d ORDER BY created_at ASC, id ASC',
				Schema::tableName( Schema::TABLE_SECURE_FILES ),
				$projectId
			),
			ARRAY_A
		);
		$out  = [];
		foreach ( $rows as $row ) {
			$out[ (string) $row['field_key'] ][] = self::describe( $row );
		}
		return $out;
	}

	/**
	 * A registry row as callers see it: never its path or storage name.
	 *
	 * @param array<string, mixed> $row
	 * @return array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}
	 */
	private static function describe( array $row ): array {
		$userId = (int) ( $row['uploaded_by'] ?? 0 );
		$user   = $userId ? get_userdata( $userId ) : false;
		return [
			'id'             => (int) $row['id'],
			'name'           => (string) $row['original_name'],
			'size'           => (int) $row['filesize'],
			'type'           => (string) $row['mime_type'],
			'uploaded_by'    => $user ? UserMeta::fullName( $user ) : '',
			'uploaded_by_id' => $userId,
			'uploaded_at'    => $row['created_at'] ? gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['created_at'] . ' UTC' ) ) : '',
		];
	}

	/**
	 * @return array<string, mixed>|null The registry row, when it is an intake file.
	 */
	private function row( int $fileId ): ?array {
		$row = ( new SecureFiles() )->findById( $fileId );
		return $row && 0 === (int) $row['content_id'] && (int) $row['project_id'] > 0 ? $row : null;
	}

	/**
	 * A file's name as people see it: its base name as sent, without control
	 * characters or line breaks. Every reader escapes it for where it goes,
	 * so a "%20" or a "<" stays as the client wrote it.
	 */
	private static function displayName( string $name ): string {
		$name = (string) preg_replace( '/[\p{Cc}\s]+/u', ' ', wp_check_invalid_utf8( wp_basename( $name ), true ) );
		return mb_substr( trim( $name ), 0, 255 ) ?: 'file';
	}

	/**
	 * The question's intake row follows its files: present while it holds
	 * one, naming the latest upload's who and when, gone when it holds none.
	 */
	private function syncAnswer( int $projectId, string $key ): void {
		global $wpdb;
		$table  = Schema::tableName( Schema::TABLE_PROJECT_INTAKE );
		$files  = $this->forQuestion( $projectId, $key );
		$latest = end( $files );
		if ( ! $latest ) {
			$wpdb->delete(
				$table,
				[
					'project_id' => $projectId,
					'field_key'  => $key,
				],
				[ '%d', '%s' ]
			);
			return;
		}
		$wpdb->replace(
			$table,
			[
				'project_id'   => $projectId,
				'field_key'    => $key,
				// The count, so the answer is never blank; the files themselves
				// are the answer.
				'field_value'  => (string) count( $files ),
				'submitted_by' => $latest['uploaded_by_id'],
				'submitted_at' => gmdate( 'Y-m-d H:i:s', (int) strtotime( $latest['uploaded_at'] ) ),
			],
			[ '%d', '%s', '%s', '%d', '%s' ]
		);
	}
}
