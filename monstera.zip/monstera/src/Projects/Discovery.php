<?php
/**
 * Project intake / discovery form handling.
 *
 * Each project carries a schema in post meta (KEY_INTAKE_SCHEMA, JSON). The
 * client fills it out from the project portal page; responses store in
 * wp_monstera_project_intake, one row per field, keyed (project_id, field_key).
 *
 * Schema is intentionally simple: text / textarea / select / date / file /
 * number. Custom field types can be added by filtering the rendered output.
 */

declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;

final class Discovery {

	/**
	 * @return array<int, array{key: string, label: string, type?: string, options?: array<int|string, string>, required?: bool, help?: string}>
	 */
	public static function schema( int $projectId ): array {
		$raw = (string) get_post_meta( $projectId, Meta::KEY_INTAKE_SCHEMA, true );
		if ( ! $raw ) {
			return self::defaultSchema();
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) || ! $decoded ) {
			return self::defaultSchema();
		}
		return $decoded;
	}

	/**
	 * @return array<int, array{key: string, label: string, type?: string, options?: array<int|string, string>, required?: bool, help?: string}>
	 */
	public static function defaultSchema(): array {
		return [
			[
				'key'      => 'goal',
				'label'    => __( 'What is the goal of this project?', 'monstera' ),
				'type'     => 'textarea',
				'options'  => [],
				'required' => true,
				'help'     => __( 'One short paragraph.', 'monstera' ),
			],
			[
				'key'      => 'audience',
				'label'    => __( 'Who is the audience?', 'monstera' ),
				'type'     => 'textarea',
				'options'  => [],
				'required' => false,
				'help'     => '',
			],
			[
				'key'      => 'timeline',
				'label'    => __( 'Hard deadlines', 'monstera' ),
				'type'     => 'text',
				'options'  => [],
				'required' => false,
				'help'     => __( 'Anything immovable.', 'monstera' ),
			],
			[
				'key'      => 'success',
				'label'    => __( 'How will we know it worked?', 'monstera' ),
				'type'     => 'textarea',
				'options'  => [],
				'required' => false,
				'help'     => '',
			],
			[
				'key'      => 'risks',
				'label'    => __( 'Known risks or constraints', 'monstera' ),
				'type'     => 'textarea',
				'options'  => [],
				'required' => false,
				'help'     => '',
			],
		];
	}

	/** The kinds of question the intake asks; `select` is the one with options. */
	public const TYPES = [ 'text', 'textarea', 'select', 'date', 'file', 'number' ];

	/**
	 * The keys of the project's file questions, whose answers are secure
	 * files rather than values in the intake table.
	 *
	 * @return list<string>
	 */
	public static function fileKeys( int $projectId ): array {
		$keys = [];
		foreach ( self::schema( $projectId ) as $question ) {
			if ( 'file' === ( $question['type'] ?? '' ) ) {
				$keys[] = (string) $question['key'];
			}
		}
		return $keys;
	}

	/**
	 * A schema checked and tidied for saving, or why it cannot be saved, in
	 * words that name the question ("Question 2, “Budget band”: …"). Each
	 * question needs a label and a known type; a choice (select) needs at
	 * least one option; required is true or false; keys are unique, and a
	 * new question without one gets one from its label.
	 *
	 * @param mixed $schema The schema as the request sent it.
	 * @return list<array{key: string, label: string, type: string, options: list<string>, required: bool, help: string}>|string
	 */
	public static function validate( mixed $schema ): array|string {
		if ( ! is_array( $schema ) || ! $schema ) {
			return __( 'The intake needs at least one question.', 'monstera' );
		}
		$out  = [];
		$seen = [];
		foreach ( array_values( $schema ) as $index => $question ) {
			$number = $index + 1;
			$label  = is_array( $question ) ? trim( sanitize_text_field( (string) ( $question['label'] ?? '' ) ) ) : '';
			$named  = '' !== $label
				/* translators: 1: the question's number, 2: its text */
				? sprintf( __( 'Question %1$d, “%2$s”', 'monstera' ), $number, $label )
				/* translators: %d: the question's number */
				: sprintf( __( 'Question %d', 'monstera' ), $number );
			if ( '' === $label ) {
				/* translators: %s: which question, e.g. "Question 3" */
				return sprintf( __( '%s: write the question.', 'monstera' ), $named );
			}
			$type = (string) ( $question['type'] ?? 'text' );
			if ( ! in_array( $type, self::TYPES, true ) ) {
				/* translators: %s: which question, e.g. "Question 3, “Budget”" */
				return sprintf( __( '%s: choose a type from the list.', 'monstera' ), $named );
			}
			$required = $question['required'] ?? false;
			if ( ! is_bool( $required ) ) {
				/* translators: %s: which question */
				return sprintf( __( '%s: required must be on or off.', 'monstera' ), $named );
			}
			$options = [];
			if ( 'select' === $type ) {
				foreach ( (array) ( $question['options'] ?? [] ) as $option ) {
					$option = trim( sanitize_text_field( (string) $option ) );
					if ( '' !== $option ) {
						$options[] = $option;
					}
				}
				$options = array_values( array_unique( $options ) );
				if ( ! $options ) {
					/* translators: %s: which question */
					return sprintf( __( '%s: give a choice at least one option.', 'monstera' ), $named );
				}
			}
			// At most 128 characters, the width of the answers' field_key column.
			$key = substr( sanitize_key( (string) ( $question['key'] ?? '' ) ), 0, 128 );
			if ( '' === $key ) {
				// A new question: a key from its label, numbered past any clash.
				$base = substr( str_replace( '-', '_', sanitize_title( $label ) ), 0, 120 ) ?: 'question';
				$key  = $base;
				for ( $n = 2; isset( $seen[ $key ] ); $n++ ) {
					$key = $base . '_' . $n;
				}
			} elseif ( isset( $seen[ $key ] ) ) {
				/* translators: %s: which question */
				return sprintf( __( '%s: another question already uses its key.', 'monstera' ), $named );
			}
			$seen[ $key ] = true;
			$out[]        = [
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'options'  => $options,
				'required' => $required,
				'help'     => sanitize_text_field( (string) ( $question['help'] ?? '' ) ),
			];
		}
		return $out;
	}

	/**
	 * Store a validated schema. Answers stay keyed to their questions: a kept
	 * question keeps its answers, and a removed one takes its answers with it
	 * (the editor confirms that first). A question that stops taking files,
	 * removed or retyped, takes its files with it; one that starts taking
	 * files drops the typed answer it had, since files are its only answer.
	 *
	 * @param list<array{key: string, type?: string}> $schema From validate().
	 */
	public static function saveSchema( int $projectId, array $schema ): void {
		$before = array_column( self::schema( $projectId ), 'type', 'key' );
		$after  = array_column( $schema, 'type', 'key' );
		update_post_meta( $projectId, Meta::KEY_INTAKE_SCHEMA, wp_slash( (string) wp_json_encode( $schema ) ) );

		$intake = new IntakeFiles();
		foreach ( $intake->forProject( $projectId ) as $key => $files ) {
			if ( 'file' !== ( $after[ $key ] ?? null ) ) {
				foreach ( $files as $file ) {
					$intake->remove( $file['id'] );
				}
			}
		}
		// As strings: PHP turns an array key made of digits into an integer,
		// and a question keyed "2025" once lost its answers to a strict compare.
		$kept = array_map( 'strval', array_column( $schema, 'key' ) );
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_INTAKE );
		foreach ( array_map( 'strval', array_keys( self::responses( $projectId ) ) ) as $key ) {
			$becameFile = 'file' === ( $after[ $key ] ?? null ) && 'file' !== ( $before[ $key ] ?? null );
			if ( ! in_array( $key, $kept, true ) || $becameFile ) {
				$wpdb->delete(
					$table,
					[
						'project_id' => $projectId,
						'field_key'  => $key,
					],
					[ '%d', '%s' ]
				);
			}
		}
	}

	/**
	 * Each answer with who gave it and when, for "Open the N responses".
	 *
	 * @return array<string, array{value: string, submitted_by: string, submitted_by_id: int, submitted_at: string}>
	 */
	public static function answers( int $projectId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_INTAKE );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT field_key, field_value, submitted_by, submitted_at FROM %i WHERE project_id = %d', $table, $projectId ), ARRAY_A );
		$out   = [];
		foreach ( (array) $rows as $row ) {
			// submit() stores every question; a blank one is not an answer.
			if ( '' === trim( (string) $row['field_value'] ) ) {
				continue;
			}
			$user                              = get_userdata( (int) $row['submitted_by'] );
			$out[ (string) $row['field_key'] ] = [
				'value'           => (string) $row['field_value'],
				'submitted_by'    => $user ? UserMeta::fullName( $user ) : '',
				'submitted_by_id' => (int) $row['submitted_by'],
				'submitted_at'    => $row['submitted_at'] ? gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['submitted_at'] . ' UTC' ) ) : '',
			];
		}
		return $out;
	}

	/**
	 * @return array<string, string>  key => stored value
	 */
	public static function responses( int $projectId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_INTAKE );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT field_key, field_value FROM %i WHERE project_id = %d', $table, $projectId ), ARRAY_A );
		$out   = [];
		foreach ( $rows as $row ) {
			$out[ (string) $row['field_key'] ] = (string) $row['field_value'];
		}
		return $out;
	}

	/**
	 * Whether the intake still takes answers: while the project is Proposed
	 * or in Discovery, as the portal's form shows it.
	 */
	public static function isOpen( int $projectId ): bool {
		return in_array( ( new Repository() )->status( $projectId ), [ Meta::STATUS_PROPOSED, Meta::STATUS_DISCOVERY ], true );
	}

	/**
	 * Store the answers a submission carries. A question it does not name
	 * keeps its answer, and an answer that has not changed keeps who gave it
	 * and when; a number left blank is no answer, not 0.
	 *
	 * @param array<int|string, mixed> $values As the request sent them.
	 */
	public static function submit( int $projectId, array $values, int $userId ): void {
		$schema = self::schema( $projectId );
		$stored = self::responses( $projectId );

		global $wpdb;
		$table   = Schema::tableName( Schema::TABLE_PROJECT_INTAKE );
		$changed = [];

		foreach ( $schema as $field ) {
			$key = (string) $field['key'];
			// A file question is answered by its files (IntakeFiles), never by
			// a value: a form posted whole sends the input's fake path.
			if ( ! array_key_exists( $key, $values ) || 'file' === ( $field['type'] ?? '' ) ) {
				continue;
			}
			$value = is_scalar( $values[ $key ] ) ? trim( (string) $values[ $key ] ) : '';
			$value = match ( $field['type'] ?? 'text' ) {
				'textarea' => wp_kses_post( $value ),
				'date'     => sanitize_text_field( $value ),
				'number'   => is_numeric( $value ) ? (string) (float) $value : '',
				default    => sanitize_text_field( $value ),
			};
			if ( ( $stored[ $key ] ?? '' ) === $value ) {
				continue;
			}
			$wpdb->replace(
				$table,
				[
					'project_id'   => $projectId,
					'field_key'    => $key,
					'field_value'  => $value,
					'submitted_by' => $userId,
					'submitted_at' => current_time( 'mysql', true ),
				],
				[ '%d', '%s', '%s', '%d', '%s' ]
			);
			$changed[] = $key;
		}

		// The fourth argument names the questions whose answers changed, so a
		// listener can tell the agency what is new.
		do_action( Hooks::PROJECT_INTAKE_SUBMITTED, $projectId, $userId, array_keys( $values ), $changed );

		// Auto-advance the project from Discovery to In Progress when the
		// required fields are all submitted. Agencies can disable via filter.
		if ( apply_filters( Hooks::FILTER_AUTO_ADVANCE_AFTER_INTAKE, true, $projectId ) ) {
			$repo = new Repository();
			if ( Meta::STATUS_DISCOVERY === $repo->status( $projectId ) ) {
				$repo->setStatus( $projectId, Meta::STATUS_IN_PROGRESS );
			}
		}
	}
}
