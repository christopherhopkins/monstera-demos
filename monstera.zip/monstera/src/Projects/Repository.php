<?php
declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\SiteDay;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use WP_Error;
use WP_Post;
use WP_Query;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function find( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/**
	 * Whether a user may view a single project: an admin, a team member, the
	 * named standalone client, or a member of the project's organization,
	 * whichever of their organizations that is (People-model track, FR8).
	 * Single source of truth shared by the portal template and PortalGuard so
	 * the two can never drift. The org match requires a real org on the
	 * project: one with no org has KEY_ORG_ID = 0, and nobody is a member of
	 * organization 0.
	 *
	 * Only a published project is anyone's but the team's. A draft is not
	 * shared with its client yet, and one in the trash was taken away: the
	 * admin's Delete trashes, which keeps the organization and the members
	 * rows, so without this its address would go on opening the whole page.
	 * The lists (forOrg(), forMember(), forStandalone()) show published
	 * projects alone, and this is the same line for the one page. A project
	 * of an organization in the trash closes with it, to its team too (the
	 * review of the At-a-glance track, 2026-10-19).
	 */
	public function userCanAccess( int $userId, int $projectId ): bool {
		$project = $this->find( $projectId );
		if ( ! $project ) {
			return false;
		}
		if ( user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return true;
		}
		if ( 'publish' !== $project->post_status ) {
			return false;
		}
		$projectOrg = (int) get_post_meta( $projectId, Meta::KEY_ORG_ID, true );
		if ( $projectOrg > 0 && ! OrgRepository::isOnSite( $projectOrg ) ) {
			return false;
		}
		if ( in_array( $userId, $this->memberIds( $projectId ), true ) ) {
			return true;
		}
		$standaloneId = (int) get_post_meta( $projectId, Meta::KEY_STANDALONE_MEMBER_ID, true );
		if ( $standaloneId > 0 && $standaloneId === $userId ) {
			return true;
		}
		return $projectOrg > 0 && Roster::isMemberOf( $userId, $projectOrg );
	}

	/**
	 * The ones of these projects the person may open, judged as
	 * userCanAccess() judges each, from reads that do not grow with the
	 * list: the posts and their meta at once, the person's project teams in
	 * one read, their memberships from the Roster's memo. For a page that
	 * names many projects (the content rows, At-a-glance track FR6), where
	 * asking each one would be two reads a project. ProjectOpenableTest
	 * holds the two to the same answers.
	 *
	 * @param array<int, mixed> $projectIds
	 * @return list<int> In the order given, each once.
	 */
	public function openableBy( int $userId, array $projectIds ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $projectIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $ids ) {
			return [];
		}
		_prime_post_caches( $ids, false, true );
		$manager = user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA );
		$teams   = null;
		$onSite  = null;
		$out     = [];
		foreach ( $ids as $id ) {
			$project = $this->find( $id );
			if ( ! $project ) {
				continue;
			}
			if ( $manager ) {
				$out[] = $id;
				continue;
			}
			if ( 'publish' !== $project->post_status ) {
				continue;
			}
			$projectOrg = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
			// Their organizations read together, as userCanAccess() asks each.
			$onSite ??= array_flip( OrgRepository::onSite( array_map( static fn ( int $one ): int => (int) get_post_meta( $one, Meta::KEY_ORG_ID, true ), $ids ) ) );
			if ( $projectOrg > 0 && ! isset( $onSite[ $projectOrg ] ) ) {
				continue;
			}
			$teams      ??= array_flip( $this->projectsForMember( $userId ) );
			$standaloneId = (int) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, true );
			if (
				isset( $teams[ $id ] )
				|| ( $standaloneId > 0 && $standaloneId === $userId )
				|| ( $projectOrg > 0 && Roster::isMemberOf( $userId, $projectOrg ) )
			) {
				$out[] = $id;
			}
		}
		return $out;
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forOrg( int $orgId, array $args = [] ): array {
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'meta_query'     => [
						[
							'key'   => Meta::KEY_ORG_ID,
							'value' => $orgId,
						],
					],
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * The projects of several organizations from one query, newest first
	 * across all of them: a person in six organizations costs the pages that
	 * span them (the dashboard, the projects list) what a person in two does,
	 * and the order is the one each organization's own list has, so a second
	 * organization's newest project is not kept behind everything the first
	 * holds. One organization is asked as forOrg() asks it.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return WP_Post[]
	 */
	public function forOrgs( array $orgIds ): array {
		$orgIds = array_values( array_unique( array_filter( array_map( 'intval', $orgIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( count( $orgIds ) < 2 ) {
			return $orgIds ? $this->forOrg( $orgIds[0] ) : [];
		}
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'posts_per_page' => -1,
				'meta_query'     => [
					[
						'key'     => Meta::KEY_ORG_ID,
						'value'   => $orgIds,
						'compare' => 'IN',
					],
				],
				'no_found_rows'  => true,
			]
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * Projects assigned to this user as a standalone client (the individual
	 * analogue of forOrg(): a project that belongs to a person, not an org).
	 *
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forStandalone( int $userId, array $args = [] ): array {
		if ( $userId <= 0 ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'meta_query'     => [
						[
							'key'   => Meta::KEY_STANDALONE_MEMBER_ID,
							'value' => $userId,
						],
					],
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forMember( int $memberId, array $args = [] ): array {
		$projectIds = $this->projectsForMember( $memberId );
		if ( ! $projectIds ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post__in'       => $projectIds,
					'orderby'        => 'post__in',
					'posts_per_page' => -1,
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @return int[]
	 */
	public function memberIds( int $projectId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT member_id FROM %i WHERE project_id = %d', $table, $projectId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * @return int[]
	 */
	public function projectsForMember( int $memberId ): array {
		global $wpdb;
		// Each one's organization with it, for ofOrgsOnSite().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pmb.project_id, pm.meta_value AS org_id FROM %i pmb LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = pmb.project_id AND pm.meta_key = %s WHERE pmb.member_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- the core table's name.
				Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ),
				Meta::KEY_ORG_ID,
				$memberId
			),
			ARRAY_A
		);
		return self::keepOrgs( $rows );
	}

	/**
	 * @return int[]
	 */
	public function projectsForContent( int $contentId ): array {
		global $wpdb;
		// Each one's organization with it, for ofOrgsOnSite().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT cp.project_id, pm.meta_value AS org_id FROM %i cp LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = cp.project_id AND pm.meta_key = %s WHERE cp.content_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- the core table's name.
				Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
				Meta::KEY_ORG_ID,
				$contentId
			),
			ARRAY_A
		);
		return self::keepOrgs( $rows );
	}

	/**
	 * The projects gating each of many content items, from one read: for a
	 * page that judges a list of items (the dashboard's feed and its bands'
	 * counts), where asking item by item is a read apiece. An item with no
	 * gate is in the answer with none, so the caller knows it was asked.
	 *
	 * @param array<int, mixed> $contentIds
	 * @return array<int, int[]> Project ids by content id, oldest project first.
	 */
	public function projectsForContents( array $contentIds ): array {
		$contentIds = array_values( array_unique( array_filter( array_map( 'intval', $contentIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		$out        = array_fill_keys( $contentIds, [] );
		if ( ! $contentIds ) {
			return $out;
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $contentIds ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $contentIds ); every id goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT cp.content_id, cp.project_id, pm.meta_value AS org_id FROM %i cp LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = cp.project_id AND pm.meta_key = %s WHERE cp.content_id IN ($marks) ORDER BY cp.content_id, cp.project_id", Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ), Meta::KEY_ORG_ID, ...$contentIds ),
			ARRAY_A
		);
		// phpcs:enable
		foreach ( $rows as $row ) {
			if ( ! in_array( (int) $row['project_id'], $out[ (int) $row['content_id'] ], true ) ) {
				$out[ (int) $row['content_id'] ][] = (int) $row['project_id'];
			}
		}
		// Each one's organization with it, for ofOrgsOnSite().
		self::keepOrgs( $rows );
		return $out;
	}

	/**
	 * Published content items gated to a project, newest first: the
	 * project's deliverables as the portal lists them.
	 *
	 * @return int[] Content post ids.
	 */
	public function contentForProject( int $projectId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_CONTENT_PROJECTS );
		$rows  = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT cp.content_id FROM %i cp INNER JOIN {$wpdb->posts} p ON p.ID = cp.content_id WHERE cp.project_id = %d AND p.post_status = 'publish' ORDER BY p.post_date DESC",
				$table,
				$projectId
			)
		);
		return array_map( 'intval', $rows );
	}

	/**
	 * The project's lead, or 0. The lead is one of the team, a staff account
	 * (People-model track, FR4), and is named in the project's own meta: the
	 * members table holds the client's people, and everything that reads it
	 * (who may open the project, whom a project's content reaches, "3 on
	 * team") means them. A lead kept there would be counted and listed as a
	 * client, and could not also be a member of the project when the same
	 * person is both.
	 */
	public function leadId( int $projectId ): int {
		return (int) get_post_meta( $projectId, Meta::KEY_LEAD, true );
	}

	/**
	 * Name the project's lead, or nobody (0). Who may lead is the caller's to
	 * check; this only writes it.
	 */
	public function setLead( int $projectId, int $userId ): void {
		if ( $userId > 0 ) {
			update_post_meta( $projectId, Meta::KEY_LEAD, $userId );
		} else {
			delete_post_meta( $projectId, Meta::KEY_LEAD );
		}
	}

	/**
	 * Leave no project naming this person as its lead: for someone who has
	 * left the team, and for an account that no longer exists. One write for
	 * every project they led.
	 */
	public function forgetLead( int $userId ): void {
		if ( $userId > 0 ) {
			delete_metadata( 'post', 0, Meta::KEY_LEAD, $userId, true );
		}
	}

	/**
	 * Everyone some project names as its lead, each once, whatever has
	 * become of the project or of the account: the daily sweep asks whether
	 * each is still one of the team (Organizations\Roster::sweepOrphans()).
	 * One read however many projects there are.
	 *
	 * @return list<int>
	 */
	public function leadIds(): array {
		global $wpdb;
		$ids = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT meta_value FROM %i WHERE meta_key = %s', $wpdb->postmeta, Meta::KEY_LEAD ) );
		return array_values( array_filter( array_map( 'intval', $ids ), static fn ( int $id ): bool => $id > 0 ) );
	}

	/**
	 * The projects these people lead, by title: the ones the Projects list
	 * shows (published and draft), whatever their stage, since a finished
	 * project still names who led it. Only one organization's when one is
	 * given. One read of the projects and one of their meta however many
	 * there are, so the caller asks each one's lead (leadId()), organization
	 * and stage of what is already loaded: the staff detail lists them and
	 * counts them per organization without a query for either. A caller that
	 * only counts asks ledCountsIn(), which loads none of it.
	 *
	 * @param array<int, mixed> $userIds
	 * @param int               $orgId   The organization, or 0 for every one.
	 * @return WP_Post[]
	 */
	public function ledBy( array $userIds, int $orgId = 0 ): array {
		$userIds = array_values( array_unique( array_filter( array_map( 'intval', $userIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		// The meta query drops an empty list of values and would then find
		// every project that has a lead.
		if ( ! $userIds ) {
			return [];
		}
		$named = [
			[
				'key'     => Meta::KEY_LEAD,
				'value'   => $userIds,
				'compare' => 'IN',
			],
		];
		if ( $orgId > 0 ) {
			$named[] = [
				'key'   => Meta::KEY_ORG_ID,
				'value' => $orgId,
			];
		}
		$query = new WP_Query(
			[
				'post_type'              => PostType::SLUG,
				'post_status'            => [ 'publish', 'draft' ],
				'posts_per_page'         => -1,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'meta_query'             => $named, // phpcs:ignore WordPress.DB.SlowDBQuery -- the lead lives in post meta by design; read once per Team route.
			]
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * How many of an organization's projects each of these people leads, by
	 * person: the projects ledBy() would list for it, counted and not
	 * loaded. A count needs nothing a project holds, and a project's meta
	 * holds its intake questions and its scope, so this is one grouped read
	 * of the two keys that say whose project it is. Someone who leads none
	 * is not in the answer.
	 *
	 * @param array<int, mixed> $userIds
	 * @return array<int, int> Projects led, by person.
	 */
	public function ledCountsIn( int $orgId, array $userIds ): array {
		$userIds = array_values( array_unique( array_filter( array_map( 'intval', $userIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $userIds || $orgId <= 0 ) {
			return [];
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $userIds ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $userIds ); every id goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT lead.meta_value AS lead_id, COUNT(DISTINCT p.ID) AS led FROM {$wpdb->posts} p
			   JOIN {$wpdb->postmeta} lead ON lead.post_id = p.ID AND lead.meta_key = %s
			   JOIN {$wpdb->postmeta} org ON org.post_id = p.ID AND org.meta_key = %s
			  WHERE p.post_type = %s AND p.post_status IN ('publish','draft')
			    AND org.meta_value = %d AND lead.meta_value IN ($marks)
			  GROUP BY lead.meta_value",
				Meta::KEY_LEAD,
				Meta::KEY_ORG_ID,
				PostType::SLUG,
				$orgId,
				...$userIds
			),
			ARRAY_A
		);
		// phpcs:enable
		$counts = [];
		foreach ( $rows as $row ) {
			$counts[ (int) $row['lead_id'] ] = ( $counts[ (int) $row['lead_id'] ] ?? 0 ) + (int) $row['led'];
		}
		return $counts;
	}

	/**
	 * How many projects each organization has under way: published, and at
	 * one of the stages the rail counts as in flight (RailCounts::IN_FLIGHT:
	 * Discovery, In progress, Review; neither Proposed nor a project with no
	 * stage chosen, which is Proposed). One definition with the rail's count
	 * and the organization's "projects in flight" fact, one grouped read for
	 * the whole page of organizations, for the list's Projects column and
	 * the summary block (At-a-glance track, FR2); an organization with none
	 * is not in the answer.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return array<int, int> Projects under way, by organization.
	 */
	public function inFlightCountsFor( array $orgIds ): array {
		$orgIds = array_values( array_unique( array_filter( array_map( 'intval', $orgIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $orgIds ) {
			return [];
		}
		global $wpdb;
		$orgMarks    = implode( ',', array_fill( 0, count( $orgIds ), '%d' ) );
		$statusMarks = implode( ',', array_fill( 0, count( \Monstera\Admin\RailCounts::IN_FLIGHT ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- the marks are lists of %d and %s built from the counts; every value goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT org.meta_value AS org_id, COUNT(DISTINCT p.ID) AS under_way FROM {$wpdb->posts} p
			   JOIN {$wpdb->postmeta} org ON org.post_id = p.ID AND org.meta_key = %s
			   JOIN {$wpdb->postmeta} stage ON stage.post_id = p.ID AND stage.meta_key = %s
			  WHERE p.post_type = %s AND p.post_status = 'publish'
			    AND org.meta_value IN ($orgMarks)
			    AND stage.meta_value IN ($statusMarks)
			  GROUP BY org.meta_value",
				Meta::KEY_ORG_ID,
				Meta::KEY_STATUS,
				PostType::SLUG,
				...$orgIds,
				...\Monstera\Admin\RailCounts::IN_FLIGHT
			),
			ARRAY_A
		);
		// phpcs:enable
		$counts = [];
		foreach ( $rows as $row ) {
			$counts[ (int) $row['org_id'] ] = (int) $row['under_way'];
		}
		return $counts;
	}

	/**
	 * The projects in front of a client that nobody leads, by title, for the
	 * dashboard's health row: published, and not yet Completed or Archived.
	 * A draft is not shared with its client yet and finished work needs no
	 * lead, so neither is asked about. One query however many there are: the
	 * row names each by its title, so nothing else of theirs is loaded, and a
	 * project's meta holds its intake questions and its scope.
	 *
	 * @return WP_Post[]
	 */
	public function withoutLead(): array {
		$query = new WP_Query(
			[
				'post_type'              => PostType::SLUG,
				'post_status'            => 'publish',
				'posts_per_page'         => -1,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_query'             => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- the lead and the stage live in post meta by design; read once per dashboard load.
					'relation' => 'AND',
					[
						'key'     => Meta::KEY_LEAD,
						'compare' => 'NOT EXISTS',
					],
					[
						'relation' => 'OR',
						// A project made in the admin has no stage until one is chosen, and is Proposed.
						[
							'key'     => Meta::KEY_STATUS,
							'compare' => 'NOT EXISTS',
						],
						[
							'key'     => Meta::KEY_STATUS,
							'value'   => [ Meta::STATUS_COMPLETED, Meta::STATUS_ARCHIVED ],
							'compare' => 'NOT IN',
						],
					],
				],
			]
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/** Gate a content item to a project's team (the content detail's project gate). */
	public function assignContent( int $projectId, int $contentId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
			[
				'project_id' => $projectId,
				'content_id' => $contentId,
			],
			[ '%d', '%d' ]
		);
	}

	public function unassignContent( int $projectId, int $contentId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
			[
				'project_id' => $projectId,
				'content_id' => $contentId,
			],
			[ '%d', '%d' ]
		);
	}

	/**
	 * Puts one of the client's people on the project. The project's two
	 * named people, its lead and its client contact, are kept in its meta
	 * (setLead(), Meta::KEY_PRIMARY_CONTACT), not on the row.
	 */
	public function addMember( int $projectId, int $memberId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ),
			[
				'project_id' => $projectId,
				'member_id'  => $memberId,
				'joined_on'  => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s' ]
		);
	}

	public function removeMember( int $projectId, int $memberId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ),
			[
				'project_id' => $projectId,
				'member_id'  => $memberId,
			],
			[ '%d', '%d' ]
		);
	}

	/**
	 * The projects a person can see, de-duped by id: those of every
	 * organization they belong to (or of the one organization given, for its
	 * hub), those they are on the team of, and those assigned to them as a
	 * standalone client. The canonical "projects this user can see" query for
	 * portal surfaces. Their organizations' projects come first, newest first
	 * across all of them, from one read however many they belong to.
	 *
	 * @param int|null $orgId One organization to list instead of all of theirs; 0 lists none of them.
	 * @return WP_Post[]
	 */
	public function forUser( int $userId, ?int $orgId = null ): array {
		$orgIds       = OrgRepository::onSite( null === $orgId ? Roster::orgIdsOf( $userId ) : ( $orgId > 0 ? [ $orgId ] : [] ) );
		$byOrg        = $this->forOrgs( $orgIds );
		$byMember     = $this->forMember( $userId );
		$byStandalone = $this->forStandalone( $userId );

		$seen = [];
		$out  = [];
		foreach ( array_merge( $byOrg, $byMember, $byStandalone ) as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$id = (int) $post->ID;
			if ( isset( $seen[ $id ] ) ) {
				continue;
			}
			$seen[ $id ] = true;
			$out[]       = $post;
		}
		// A project of an organization in the trash closes with it, to its
		// team too (userCanAccess()); the organizations are read together.
		$orgOf = [];
		foreach ( $out as $post ) {
			$orgOf[ (int) $post->ID ] = (int) get_post_meta( $post->ID, Meta::KEY_ORG_ID, true );
		}
		$onSite = array_flip( OrgRepository::onSite( array_values( $orgOf ) ) );
		return array_values( array_filter( $out, static fn ( WP_Post $post ): bool => $orgOf[ (int) $post->ID ] <= 0 || isset( $onSite[ $orgOf[ (int) $post->ID ] ] ) ) );
	}

	/**
	 * The projects the portal lists for a person on the pages that span
	 * every organization (the dashboard, the projects list): forUser(), less
	 * the projects of an organization whose membership has ended for anyone
	 * but staff. The guard answers "Membership ended" on each of those
	 * pages, whichever way the person reaches the project (its organization
	 * or its team), so a list that stays open for a person with another
	 * live organization would otherwise lead them there row after row. The
	 * second answer names the organizations held back, so the list can say
	 * what it left out.
	 *
	 * @return array{0: WP_Post[], 1: list<int>} The projects to list, then the ended organizations whose projects were left out.
	 */
	public function listedFor( WP_User $user ): array {
		$projects = $this->forUser( (int) $user->ID );
		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return [ $projects, [] ];
		}
		// Each project's organization is asked whether its membership has
		// ended: their end dates are read together, not one organization at a
		// time (those the guard or the shell has read already cost nothing).
		$orgOf = [];
		foreach ( $projects as $project ) {
			$orgOf[ (int) $project->ID ] = (int) get_post_meta( $project->ID, Meta::KEY_ORG_ID, true );
		}
		update_postmeta_cache( array_values( array_unique( array_filter( $orgOf ) ) ) );
		$listed = [];
		$ended  = [];
		foreach ( $projects as $project ) {
			$orgId = $orgOf[ (int) $project->ID ];
			if ( $orgId > 0 && PortalGuard::membershipExpired( $orgId ) ) {
				$ended[ $orgId ] = $orgId;
				continue;
			}
			$listed[] = $project;
		}
		// Held back in the person's membership order, whichever organization's
		// project is the newest; one they reach only through a team comes after.
		$mine = Roster::orgIdsOf( (int) $user->ID );
		return [ $listed, array_merge( array_values( array_intersect( $mine, $ended ) ), array_values( array_diff( $ended, $mine ) ) ) ];
	}

	/** @var array<string, bool> Per-request memo for userHasAnyProject(), keyed "user:org", or "user:any" for every organization of theirs. */
	private static array $anyProjectCache = [];

	/** @var array<int, int> Per-request memo: each project's organization, as the reads of the gates and of a person's projects found it (ofOrgsOnSite()). */
	private static array $orgOf = [];

	/** Forget the memo — only needed in tests, where user ids are reused across rolled-back transactions. */
	public static function flushCache(): void {
		self::$anyProjectCache = [];
		self::$orgOf           = [];
	}

	/**
	 * The ones among these projects whose organization is on the site, or
	 * that have none: a project of an organization in the trash closes
	 * with it, to its team too (userCanAccess(); the fix's review, 2026-10-19).
	 * Each one's organization is what the read of the gates or of the
	 * person's projects found with it (projectsForContent(),
	 * projectsForContents(), projectsForMember()), so asking costs no read
	 * of its own however a list falls; any other is read here, together.
	 *
	 * @param array<int, mixed> $projectIds
	 * @return list<int> In the order given.
	 */
	public static function ofOrgsOnSite( array $projectIds ): array {
		$ids = array_values( array_filter( array_map( 'intval', $projectIds ), static fn ( int $id ): bool => $id > 0 ) );
		if ( ! $ids ) {
			return [];
		}
		$unknown = array_values( array_filter( $ids, static fn ( int $id ): bool => ! isset( self::$orgOf[ $id ] ) ) );
		if ( $unknown ) {
			update_postmeta_cache( $unknown );
			foreach ( $unknown as $id ) {
				self::$orgOf[ $id ] = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
			}
		}
		$onSite = array_flip( OrgRepository::onSite( array_map( static fn ( int $id ): int => self::$orgOf[ $id ], $ids ) ) );
		return array_values( array_filter( $ids, static fn ( int $id ): bool => self::$orgOf[ $id ] <= 0 || isset( $onSite[ self::$orgOf[ $id ] ] ) ) );
	}

	/**
	 * The project ids of rows that read each one's organization with it,
	 * kept for ofOrgsOnSite().
	 *
	 * @param array<int, array<string, mixed>> $rows Each with `project_id` and `org_id`.
	 * @return list<int> The projects, in the rows' order.
	 */
	private static function keepOrgs( array $rows ): array {
		$ids = [];
		foreach ( $rows as $row ) {
			$id = (int) $row['project_id'];
			// A second row for one (a second meta row for its organization,
			// written past update_post_meta()) adds nothing.
			if ( isset( $ids[ $id ] ) ) {
				continue;
			}
			self::$orgOf[ $id ] = (int) ( $row['org_id'] ?? 0 );
			$ids[ $id ]         = $id;
		}
		return array_values( $ids );
	}

	/**
	 * A write to a project's organization: what ofOrgsOnSite() kept of it is
	 * forgotten, so a project moved in this request is judged by where it is
	 * now. On WordPress's added_, updated_ and deleted_post_meta.
	 *
	 * @param mixed $metaIds WordPress's meta id or ids.
	 */
	public static function forgetOrg( mixed $metaIds, int $objectId, string $metaKey ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundBeforeLastUsed -- WordPress passes the meta ids first; the post and the key are what matter.
		if ( Meta::KEY_ORG_ID === $metaKey ) {
			unset( self::$orgOf[ $objectId ] );
		}
	}

	/**
	 * Lightweight check used by nav gating: whether forUser() would list
	 * anything, without loading it. Like forUser(), it counts every
	 * organization the person belongs to unless one is given, so the top
	 * bar's Projects item and the list it leads to cannot disagree: a member
	 * of A (no projects) and B (three) has the item. Caches per-request so
	 * callers (shell header, dashboard) don't trigger duplicate queries.
	 *
	 * @param int|null $orgId One organization to ask about instead of all of theirs; 0 asks about none of them.
	 */
	public function userHasAnyProject( int $userId, ?int $orgId = null ): bool {
		$cache = &self::$anyProjectCache;
		$key   = $userId . ':' . ( $orgId ?? 'any' );
		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}
		// Cheap path: any join-table row for this member, on a project of an
		// organization on the site.
		if ( self::ofOrgsOnSite( $this->projectsForMember( $userId ) ) ) {
			$cache[ $key ] = true;
			return true;
		}
		// Standalone-client path: any project assigned to this user individually.
		global $wpdb;
		$standalone = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->postmeta} pm
			   JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			  WHERE pm.meta_key = %s AND pm.meta_value = %d
			    AND p.post_type = %s AND p.post_status IN ('publish','draft')
			  LIMIT 1",
				Meta::KEY_STANDALONE_MEMBER_ID,
				$userId,
				PostType::SLUG
			)
		);
		if ( $standalone ) {
			$cache[ $key ] = true;
			return true;
		}
		// Org-scoped path: any project of the organization asked about, or of
		// any of theirs, in one query however many they belong to.
		$orgIds = OrgRepository::onSite( null === $orgId ? Roster::orgIdsOf( $userId ) : ( $orgId > 0 ? [ $orgId ] : [] ) );
		if ( $orgIds ) {
			$marks = implode( ',', array_fill( 0, count( $orgIds ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $orgIds ); every id goes through prepare().
			$exists = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->postmeta} pm
				   JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				  WHERE pm.meta_key = %s
				    AND p.post_type = %s AND p.post_status IN ('publish','draft')
				    AND pm.meta_value IN ($marks)
				  LIMIT 1",
					Meta::KEY_ORG_ID,
					PostType::SLUG,
					...$orgIds
				)
			);
			// phpcs:enable
			if ( $exists ) {
				$cache[ $key ] = true;
				return true;
			}
		}
		$cache[ $key ] = false;
		return false;
	}

	public function status( int $projectId ): string {
		return (string) ( get_post_meta( $projectId, Meta::KEY_STATUS, true ) ?: Meta::STATUS_PROPOSED );
	}

	public function setStatus( int $projectId, string $status ): void {
		$old = $this->status( $projectId );
		if ( $old === $status ) {
			return;
		}
		update_post_meta( $projectId, Meta::KEY_STATUS, $status );
		do_action( \Monstera\Core\Hooks::PROJECT_STATUS_CHANGED, $projectId, $status, $old );
	}

	// ---- The next step for the client (At-a-glance track, FR8) ----------------

	/** The most a next step may say: one sentence. */
	public const NEXT_STEP_MAX = 160;

	/**
	 * The most bytes a next step is read at before it is judged: room for
	 * NEXT_STEP_MAX characters of any width with space pasted around them,
	 * and a bound on the work of trimming what no field sends.
	 */
	private const NEXT_STEP_BYTES = 4096;

	/**
	 * What staff wrote for the client to do next, or null with nothing
	 * written. Kept whatever the project's stage; clientStep() says whether
	 * the portal shows it.
	 *
	 * @return array{sentence: string, by: string}|null `by` is Y-m-d or ''.
	 */
	public function nextStep( int $projectId ): ?array {
		$stored   = (string) get_post_meta( $projectId, Meta::KEY_NEXT_STEP, true );
		$sentence = self::spaceTrimmed( $stored ) ?? trim( $stored );
		if ( '' === $sentence ) {
			return null;
		}
		return [
			'sentence' => self::asTyped( $sentence ),
			'by'       => (string) get_post_meta( $projectId, Meta::KEY_NEXT_STEP_BY, true ),
		];
	}

	/**
	 * A sentence without the space at either end, of any kind: the no-break
	 * space a sentence pasted from a mail or a document carries is space to
	 * the admin's field (JavaScript's trim()), so it is space here too, and a
	 * sentence of it alone is no sentence. PHP's trim() and
	 * sanitize_text_field() know ASCII space alone.
	 *
	 * Null for text past NEXT_STEP_BYTES, or that the pattern cannot read:
	 * never an empty sentence, which would clear the step. The trailing run
	 * is matched from the character after the last that is not space, so a
	 * long run inside the sentence costs one pass, not one per position.
	 */
	private static function spaceTrimmed( string $text ): ?string {
		if ( strlen( $text ) > self::NEXT_STEP_BYTES ) {
			return null;
		}
		$trimmed = preg_replace( '/^[\s\p{Z}\x{FEFF}]+|(?<![\s\p{Z}\x{FEFF}])[\s\p{Z}\x{FEFF}]+$/u', '', $text );
		return is_string( $trimmed ) ? $trimmed : null;
	}

	/**
	 * A stored sentence as the staff typed it. sanitize_text_field() keeps a
	 * stray "<" as text by escaping it, and with it (wp_pre_kses_less_than())
	 * the run that follows up to the next "<" or the end, so an apostrophe,
	 * a quote or an "&" after it are entities too; the one change it makes
	 * to plain text, undone here so every reader (the admin's input, the
	 * portal's esc_html()) sees "<" and not "&lt;". A sentence with no
	 * escaped "<" was never touched and is left alone. A "<" that opened a
	 * tag went with the tag.
	 */
	private static function asTyped( string $stored ): string {
		if ( ! str_contains( $stored, '&lt;' ) ) {
			return $stored;
		}
		$typed = wp_specialchars_decode( $stored, ENT_QUOTES );
		// Entities a person typed ("&lt;img …&gt;") decode into a tag, which
		// the stored text never held: it is kept as it is, so no reader is
		// handed markup however it prints the sentence.
		return preg_match( '/<[a-z!\/?]/i', $typed ) ? $stored : $typed;
	}

	/**
	 * The one writer for the next step. One plain sentence of at most
	 * NEXT_STEP_MAX characters, trimmed, with markup stripped and a stray
	 * "<" kept as text (sanitize_text_field() escapes it in the store and
	 * nextStep() reads it back as typed); the date,
	 * when given, a real calendar day as Y-m-d. An empty sentence clears
	 * both: a date alone is nothing to show. The same values again write
	 * nothing. The sentence is slashed for the meta API, which unslashes
	 * what it is given, so a backslash the staff typed is kept. Who may
	 * write is the caller's to check.
	 *
	 * @return bool|WP_Error True when something changed; false for a no-op;
	 *                       `monstera_next_step_long` or `monstera_next_step_date`
	 *                       (422, naming the field) for a refusal.
	 */
	public function setNextStep( int $projectId, string $sentence, string $by = '' ): bool|WP_Error {
		$by      = trim( $by );
		$refusal = self::nextStepRefusal( $sentence, $by );
		if ( $refusal ) {
			return $refusal;
		}
		// Judged readable and within the limit above.
		$sentence = self::spaceTrimmed( sanitize_text_field( $sentence ) ) ?? '';
		if ( '' === $sentence ) {
			$by = '';
		}
		// Compared as stored, since the new sentence is in that form too.
		$raw      = (string) get_post_meta( $projectId, Meta::KEY_NEXT_STEP, true );
		$stored   = self::spaceTrimmed( $raw ) ?? trim( $raw );
		$storedBy = '' === $stored ? '' : (string) get_post_meta( $projectId, Meta::KEY_NEXT_STEP_BY, true );
		if ( $stored === $sentence && $storedBy === $by ) {
			return false;
		}
		if ( '' === $sentence ) {
			delete_post_meta( $projectId, Meta::KEY_NEXT_STEP );
			delete_post_meta( $projectId, Meta::KEY_NEXT_STEP_BY );
			return true;
		}
		update_post_meta( $projectId, Meta::KEY_NEXT_STEP, wp_slash( $sentence ) );
		if ( '' === $by ) {
			delete_post_meta( $projectId, Meta::KEY_NEXT_STEP_BY );
		} else {
			update_post_meta( $projectId, Meta::KEY_NEXT_STEP_BY, $by );
		}
		return true;
	}

	/**
	 * Why a next step cannot be saved, or null: the one judgement
	 * setNextStep() makes and a route asks before its first write, so a
	 * refused save changes nothing (the controllers' rule). The sentence is
	 * judged trimmed and sanitised, and counted as the staff typed it: a
	 * stray "<" is the one character it is, not its escaped four.
	 */
	public static function nextStepRefusal( string $sentence, string $by ): ?WP_Error {
		// Far past the limit, it is judged long before it is read.
		$sentence = strlen( $sentence ) > self::NEXT_STEP_BYTES ? null : self::spaceTrimmed( sanitize_text_field( $sentence ) );
		if ( null === $sentence || mb_strlen( self::asTyped( $sentence ) ) > self::NEXT_STEP_MAX ) {
			return new WP_Error(
				'monstera_next_step_long',
				sprintf(
					/* translators: %d: the most characters a next step may have */
					__( 'Keep the next step to %d characters.', 'monstera' ),
					self::NEXT_STEP_MAX
				),
				[
					'status' => 422,
					'field'  => 'next_step',
				]
			);
		}
		$by = trim( $by );
		if ( '' !== $by && ! self::isCalendarDay( $by ) ) {
			return new WP_Error(
				'monstera_next_step_date',
				__( 'Give the date as a day on the calendar, or leave it empty.', 'monstera' ),
				[
					'status' => 422,
					'field'  => 'next_step_by',
				]
			);
		}
		return null;
	}

	/**
	 * Every content item gated to the project, whatever its status: the
	 * admin content list filtered by project shows drafts and pending items
	 * as it shows them unfiltered (contentForProject() is the portal's,
	 * published only). Newest first, as the list orders.
	 *
	 * @return int[] Content post ids.
	 */
	public function gatedContentIds( int $projectId ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one read of this plugin's own gate table, once per list load.
			$wpdb->prepare(
				"SELECT cp.content_id FROM %i cp INNER JOIN {$wpdb->posts} p ON p.ID = cp.content_id WHERE cp.project_id = %d ORDER BY p.post_date DESC",
				Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
				$projectId
			)
		);
		return array_map( 'intval', $rows );
	}

	/**
	 * The step the portal shows the client: the staff-written one when
	 * there is one; otherwise, on the project page alone ($withDiscovery),
	 * while the project is at the Discovery stage and no answer has been
	 * stored, the discovery step with the project's due date, which the
	 * template words; otherwise nothing. A completed or archived project
	 * asks nothing of anyone, whatever is written. The rows (the Portal,
	 * the hub's Projects tab, the list) pass false: they show what is set
	 * (FR7) and read primed meta only, where the discovery step would cost
	 * a query a row.
	 *
	 * @return array{sentence: string, by: string, discovery: bool}|null
	 */
	public function clientStep( int $projectId, bool $withDiscovery = true ): ?array {
		$status = $this->status( $projectId );
		if ( in_array( $status, [ Meta::STATUS_COMPLETED, Meta::STATUS_ARCHIVED ], true ) ) {
			return null;
		}
		$written = $this->nextStep( $projectId );
		if ( $written ) {
			return $written + [ 'discovery' => false ];
		}
		if ( ! $withDiscovery || Meta::STATUS_DISCOVERY !== $status || Discovery::responses( $projectId ) ) {
			return null;
		}
		return [
			'sentence'  => '',
			'by'        => self::calendarDay( (string) get_post_meta( $projectId, Meta::KEY_DUE_ON, true ) ),
			'discovery' => true,
		];
	}

	/**
	 * A stored date as Y-m-d: as it is when it already is one, else what
	 * strtotime() makes of it (the due date is stored as typed), else ''.
	 */
	private static function calendarDay( string $value ): string {
		if ( self::isCalendarDay( $value ) ) {
			return $value;
		}
		$ts = '' !== $value ? strtotime( $value ) : false;
		return false === $ts ? '' : gmdate( 'Y-m-d', $ts );
	}

	/** A Y-m-d string that is a day on the calendar. */
	private static function isCalendarDay( string $value ): bool {
		return SiteDay::isDay( $value );
	}
}
