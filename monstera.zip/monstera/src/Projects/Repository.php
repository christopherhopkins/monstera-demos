<?php
declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Members\UserMeta;
use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function find( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/**
	 * Whether a user may view a single project: an admin, a team member, the
	 * named standalone client, or a member of the project's organization.
	 * Single source of truth shared by the portal template and PortalGuard so
	 * the two can never drift. The org match requires a real org on both sides
	 * (a project with no org has KEY_ORG_ID = 0 and must not match a standalone
	 * member whose associatedOrg is also 0).
	 */
	public function userCanAccess( int $userId, int $projectId ): bool {
		if ( ! $this->find( $projectId ) ) {
			return false;
		}
		if ( user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return true;
		}
		if ( in_array( $userId, $this->memberIds( $projectId ), true ) ) {
			return true;
		}
		$standaloneId = (int) get_post_meta( $projectId, Meta::KEY_STANDALONE_MEMBER_ID, true );
		if ( $standaloneId > 0 && $standaloneId === $userId ) {
			return true;
		}
		$myOrg      = UserMeta::associatedOrg( $userId );
		$projectOrg = (int) get_post_meta( $projectId, Meta::KEY_ORG_ID, true );
		return $myOrg > 0 && $myOrg === $projectOrg;
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forOrg( int $orgId, array $args = [] ): array {
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'meta_query'     => [
						[
							'key'   => Meta::KEY_ORG_ID,
							'value' => $orgId,
						],
					],
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * Projects assigned to this user as a standalone client (the individual
	 * analogue of forOrg(): a project that belongs to a person, not an org).
	 *
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forStandalone( int $userId, array $args = [] ): array {
		if ( $userId <= 0 ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'meta_query'     => [
						[
							'key'   => Meta::KEY_STANDALONE_MEMBER_ID,
							'value' => $userId,
						],
					],
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forMember( int $memberId, array $args = [] ): array {
		$projectIds = $this->projectsForMember( $memberId );
		if ( ! $projectIds ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post__in'       => $projectIds,
					'orderby'        => 'post__in',
					'posts_per_page' => -1,
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @return int[]
	 */
	public function memberIds( int $projectId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT member_id FROM %i WHERE project_id = %d', $table, $projectId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * @return int[]
	 */
	public function projectsForMember( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT project_id FROM %i WHERE member_id = %d', $table, $memberId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * @return int[]
	 */
	public function projectsForContent( int $contentId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_CONTENT_PROJECTS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT project_id FROM %i WHERE content_id = %d', $table, $contentId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * Published content items gated to a project, newest first: the
	 * project's deliverables as the portal lists them.
	 *
	 * @return int[] Content post ids.
	 */
	public function contentForProject( int $projectId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_CONTENT_PROJECTS );
		$rows  = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT cp.content_id FROM %i cp INNER JOIN {$wpdb->posts} p ON p.ID = cp.content_id WHERE cp.project_id = %d AND p.post_status = 'publish' ORDER BY p.post_date DESC",
				$table,
				$projectId
			)
		);
		return array_map( 'intval', $rows );
	}

	/** The team member whose role on the project is lead, or 0. */
	public function leadId( int $projectId ): int {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT member_id FROM %i WHERE project_id = %d AND role_in_project = %s LIMIT 1',
				Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ),
				$projectId,
				'lead'
			)
		);
	}

	/**
	 * Make one team member the lead (0 for none); whoever led before goes
	 * back to the team.
	 */
	public function setLead( int $projectId, int $memberId ): void {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_PROJECT_MEMBERS );
		$wpdb->update(
			$table,
			[ 'role_in_project' => '' ],
			[
				'project_id'      => $projectId,
				'role_in_project' => 'lead',
			],
			[ '%s' ],
			[ '%d', '%s' ]
		);
		if ( $memberId > 0 ) {
			$wpdb->update(
				$table,
				[ 'role_in_project' => 'lead' ],
				[
					'project_id' => $projectId,
					'member_id'  => $memberId,
				],
				[ '%s' ],
				[ '%d', '%d' ]
			);
		}
	}

	/** Gate a content item to a project's team (the content detail's project gate). */
	public function assignContent( int $projectId, int $contentId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
			[
				'project_id' => $projectId,
				'content_id' => $contentId,
			],
			[ '%d', '%d' ]
		);
	}

	public function unassignContent( int $projectId, int $contentId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
			[
				'project_id' => $projectId,
				'content_id' => $contentId,
			],
			[ '%d', '%d' ]
		);
	}

	public function addMember( int $projectId, int $memberId, string $roleInProject = '' ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ),
			[
				'project_id'      => $projectId,
				'member_id'       => $memberId,
				'role_in_project' => $roleInProject,
				'joined_on'       => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s', '%s' ]
		);
	}

	public function removeMember( int $projectId, int $memberId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ),
			[
				'project_id' => $projectId,
				'member_id'  => $memberId,
			],
			[ '%d', '%d' ]
		);
	}

	/**
	 * Returns the union of "projects assigned to this user's org", "projects
	 * this user is a team member of", and "projects assigned to this user as a
	 * standalone client" — de-duped by ID. The canonical "projects this user
	 * can see" query for portal surfaces.
	 *
	 * @return WP_Post[]
	 */
	public function forUser( int $userId, ?int $orgId = null ): array {
		$byOrg        = ( $orgId && $orgId > 0 ) ? $this->forOrg( $orgId ) : [];
		$byMember     = $this->forMember( $userId );
		$byStandalone = $this->forStandalone( $userId );

		$seen = [];
		$out  = [];
		foreach ( array_merge( $byOrg, $byMember, $byStandalone ) as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$id = (int) $post->ID;
			if ( isset( $seen[ $id ] ) ) {
				continue;
			}
			$seen[ $id ] = true;
			$out[]       = $post;
		}
		return $out;
	}

	/** @var array<string, bool> Per-request memo for userHasAnyProject(), keyed "user:org". */
	private static array $anyProjectCache = [];

	/** Forget the memo — only needed in tests, where user ids are reused across rolled-back transactions. */
	public static function flushCache(): void {
		self::$anyProjectCache = [];
	}

	/**
	 * Lightweight check used by nav gating. Caches per-request so callers
	 * (shell header, dashboard) don't trigger duplicate queries.
	 */
	public function userHasAnyProject( int $userId, ?int $orgId = null ): bool {
		$cache = &self::$anyProjectCache;
		$key   = $userId . ':' . (int) $orgId;
		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}
		// Cheap path: any join-table row for this member.
		if ( $this->projectsForMember( $userId ) ) {
			$cache[ $key ] = true;
			return true;
		}
		// Standalone-client path: any project assigned to this user individually.
		global $wpdb;
		$standalone = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->postmeta} pm
			   JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			  WHERE pm.meta_key = %s AND pm.meta_value = %d
			    AND p.post_type = %s AND p.post_status IN ('publish','draft')
			  LIMIT 1",
				Meta::KEY_STANDALONE_MEMBER_ID,
				$userId,
				PostType::SLUG
			)
		);
		if ( $standalone ) {
			$cache[ $key ] = true;
			return true;
		}
		// Org-scoped path: any project with this org's meta.
		if ( $orgId && $orgId > 0 ) {
			$exists = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->postmeta} pm
				   JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				  WHERE pm.meta_key = %s AND pm.meta_value = %d
				    AND p.post_type = %s AND p.post_status IN ('publish','draft')
				  LIMIT 1",
					Meta::KEY_ORG_ID,
					$orgId,
					PostType::SLUG
				)
			);
			if ( $exists ) {
				$cache[ $key ] = true;
				return true;
			}
		}
		$cache[ $key ] = false;
		return false;
	}

	public function status( int $projectId ): string {
		return (string) ( get_post_meta( $projectId, Meta::KEY_STATUS, true ) ?: Meta::STATUS_PROPOSED );
	}

	public function setStatus( int $projectId, string $status ): void {
		$old = $this->status( $projectId );
		if ( $old === $status ) {
			return;
		}
		update_post_meta( $projectId, Meta::KEY_STATUS, $status );
		do_action( \Monstera\Core\Hooks::PROJECT_STATUS_CHANGED, $projectId, $status, $old );
	}
}
