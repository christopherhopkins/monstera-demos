<?php
declare(strict_types=1);

namespace Monstera\Projects;

use Monstera\Core\Hooks;
use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class ProjectsModule implements Module {

	public function slug(): string {
		return 'projects';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		add_action( 'transition_post_status', [ $this, 'onTransition' ], 10, 3 );
		// A project moved to another organization is judged by its new one at
		// once (Repository::ofOrgsOnSite()).
		foreach ( [ 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ] as $hook ) {
			add_action( $hook, [ Repository::class, 'forgetOrg' ], 10, 3 );
		}
	}

	public function registerPostTypes(): void {
		PostType::register();
	}

	public function onTransition( string $newStatus, string $oldStatus, \WP_Post $post ): void {
		if ( PostType::SLUG !== $post->post_type ) {
			return;
		}
		if ( 'publish' === $newStatus && 'publish' !== $oldStatus ) {
			do_action( Hooks::PROJECT_CREATED, $post->ID );
		}
	}
}
