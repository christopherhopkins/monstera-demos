<?php
declare(strict_types=1);

namespace Monstera\Integrations;

defined( 'ABSPATH' ) || exit;

/**
 * Runtime integration detection.
 *
 * Never declares any third-party plugin as a dependency. Each check inspects
 * known fingerprints (class names, function names, constants) and reports
 * the result so the Settings → Integrations tab can show a status line.
 */
final class Detector {

	/**
	 * @return array<int, array{key:string, label:string, detected:bool, message:string}>
	 */
	public function report(): array {
		return [
			$this->row(
				'acf',
				__( 'ACF Pro', 'monstera' ),
				class_exists( 'ACF' ) && function_exists( 'acf_add_options_page' ),
				__( 'When present, Monstera exposes notification templates and meta groups as ACF field groups for nicer editing.', 'monstera' )
			),
			$this->row(
				'gravity_forms',
				__( 'Gravity Forms', 'monstera' ),
				class_exists( 'GFForms' ),
				__( 'Bridge planned: read dues entries from a configured GF form instead of using the built-in form.', 'monstera' )
			),
			$this->row(
				'woocommerce',
				__( 'WooCommerce', 'monstera' ),
				class_exists( 'WooCommerce' ),
				__( 'Bridge planned: memberships as WC product type with subscription support.', 'monstera' )
			),
			$this->row(
				'bbpress',
				__( 'bbPress', 'monstera' ),
				class_exists( 'bbPress' ),
				__( 'Bridge planned: defer forum surface to bbPress and layer ACL on top.', 'monstera' )
			),
			$this->row(
				'wp_mail_smtp',
				__( 'WP Mail SMTP', 'monstera' ),
				defined( 'WPMS_PLUGIN_VER' ) || class_exists( '\\WPMailSMTP\\Core' ),
				__( 'Detected — wp_mail() delivery should be reliable.', 'monstera' )
			),
			$this->row(
				'fluent_smtp',
				__( 'FluentSMTP', 'monstera' ),
				function_exists( 'FluentMail' ) || defined( 'FLUENTMAIL_PLUGIN_VERSION' ),
				__( 'Detected — wp_mail() delivery should be reliable.', 'monstera' )
			),
			$this->row(
				'post_smtp',
				__( 'Post SMTP', 'monstera' ),
				class_exists( 'PostmanWpMail' ),
				__( 'Detected — wp_mail() delivery should be reliable.', 'monstera' )
			),
		];
	}

	/**
	 * Login-protection plugins the dashboard's health row recognises, by
	 * main plugin file. Monstera has no lockout feature of its own.
	 */
	private const LOGIN_PROTECTION = [
		'wordfence/wordfence.php'                   => 'Wordfence',
		'limit-login-attempts-reloaded/limit-login-attempts-reloaded.php' => 'Limit Login Attempts Reloaded',
		'loginizer/loginizer.php'                   => 'Loginizer',
		'better-wp-security/better-wp-security.php' => 'Solid Security',
		'all-in-one-wp-security-and-firewall/wp-security.php' => 'All-In-One Security',
		'wp-cerber/wp-cerber.php'                   => 'WP Cerber',
		'wp-simple-firewall/icwp-wpsf.php'          => 'Shield Security',
		'jetpack-protect/jetpack-protect.php'       => 'Jetpack Protect',
	];

	/**
	 * The name of the first active login-protection plugin, or '' when none
	 * is active (network-activated plugins count on multisite).
	 */
	public function loginProtection(): string {
		$active = (array) get_option( 'active_plugins', [] );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) ) );
		}
		foreach ( self::LOGIN_PROTECTION as $file => $name ) {
			if ( in_array( $file, $active, true ) ) {
				return $name;
			}
		}
		return '';
	}

	/**
	 * @return array{key: string, label: string, detected: bool, message: string}
	 */
	private function row( string $key, string $label, bool $detected, string $message ): array {
		return [
			'key'      => $key,
			'label'    => $label,
			'detected' => $detected,
			'message'  => $message,
		];
	}
}
