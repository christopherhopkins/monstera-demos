<?php
declare(strict_types=1);

namespace Monstera\Integrations;

use Monstera\Core\Module;

final class IntegrationsModule implements Module {

	public function slug(): string {
		return 'integrations';
	}

	public function boot(): void {
		// Bridge plugins are loaded lazily inside Detector::isActive checks.
	}

	public function registerPostTypes(): void {}
}
