<?php
declare(strict_types=1);

namespace Monstera\Rest;

use Monstera\Core\SiteDay;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * The refusal of a day that is not one (the Phase 5 review, 2026-10-17): a
 * membership's expiry was stored as typed, so "31/03/2027" never ended and
 * "2027-03-31T00:00:00+13:00" ended a day early, read through strtotime()
 * in UTC; so were a project's dates and a sub-group's formed day. The
 * admin's date fields always send Y-m-d. A write past the routes (the
 * Custom Fields box, WP-CLI) is not refused.
 */
final class DayField {

	/** A 422 naming the field when the request sends a value that is no day, or null. */
	public static function refusal( WP_REST_Request $request, string $field ): ?WP_Error {
		if ( ! $request->has_param( $field ) ) {
			return null;
		}
		$value = trim( (string) $request[ $field ] );
		if ( '' === $value || SiteDay::isDay( $value ) ) {
			return null;
		}
		return new WP_Error(
			'monstera_invalid_day',
			__( 'Give the date as a day on the calendar, or leave it empty.', 'monstera' ),
			[
				'status' => 422,
				'field'  => $field,
			]
		);
	}
}
