<?php
declare(strict_types=1);

namespace Monstera\Rest;

use Monstera\Core\Hooks;
use Monstera\Core\Module;
use Monstera\Core\Modules;

defined( 'ABSPATH' ) || exit;

final class RestModule implements Module {

	public function slug(): string {
		return 'rest';
	}

	public function boot(): void {
		add_action( 'rest_api_init', [ $this, 'register' ] );
	}

	public function registerPostTypes(): void {}

	public function register(): void {
		$namespace = (string) apply_filters( Hooks::FILTER_REST_NAMESPACE, 'monstera/v1' );

		// Always-on controllers — these mirror the core modules.
		( new Controllers\OrganizationsController( $namespace ) )->register();
		( new Controllers\MembersController( $namespace ) )->register();
		( new Controllers\ContentController( $namespace ) )->register();
		( new Controllers\SubgroupsController( $namespace ) )->register();
		( new Controllers\SettingsController( $namespace ) )->register();
		( new Controllers\SyncController( $namespace ) )->register();
		( new Controllers\ProfileController( $namespace ) )->register();
		( new Controllers\DashboardController( $namespace ) )->register();
		( new Controllers\ToolsController( $namespace ) )->register();
		( new Controllers\OrgMembersController( $namespace ) )->register();

		// Module-gated controllers — their routes only exist when the
		// corresponding Settings → Modules toggle is on.
		if ( Modules::isActive( Modules::FORMS ) ) {
			( new Controllers\FormsController( $namespace ) )->register();
		}
		if ( Modules::isActive( Modules::REPORTING ) ) {
			( new Controllers\ReportsController( $namespace ) )->register();
		}
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			( new Controllers\ProjectsController( $namespace ) )->register();
		}
		if ( Modules::isActive( Modules::ALERTS ) ) {
			( new Controllers\AlertsController( $namespace ) )->register();
		}
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			( new Controllers\SupportController( $namespace ) )->register();
		}
	}
}
