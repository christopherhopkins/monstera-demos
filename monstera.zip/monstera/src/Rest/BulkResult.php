<?php
declare(strict_types=1);

namespace Monstera\Rest;

defined( 'ABSPATH' ) || exit;

/**
 * Per-id outcome of a bulk action. Every id gets a row; one failure never
 * hides the others.
 */
final class BulkResult {

	/** @var list<array{id: int, ok: bool, message: string}> */
	private array $rows = [];

	private int $updated = 0;

	private int $skipped = 0;

	public function __construct( private string $action ) {}

	public function done( int $id, string $message ): void {
		$this->rows[] = [
			'id'      => $id,
			'ok'      => true,
			'message' => $message,
		];
		++$this->updated;
	}

	public function skip( int $id, string $message ): void {
		$this->rows[] = [
			'id'      => $id,
			'ok'      => false,
			'message' => $message,
		];
		++$this->skipped;
	}

	/**
	 * @return array{action: string, results: list<array{id: int, ok: bool, message: string}>, updated: int, skipped: int}
	 */
	public function toArray(): array {
		return [
			'action'  => $this->action,
			'results' => $this->rows,
			'updated' => $this->updated,
			'skipped' => $this->skipped,
		];
	}
}
