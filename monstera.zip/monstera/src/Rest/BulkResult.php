<?php
declare(strict_types=1);

namespace Monstera\Rest;

defined( 'ABSPATH' ) || exit;

/**
 * Per-id outcome of a bulk action. Every id gets a row; one failure never
 * hides the others. An action that has more to say than the two counts (how
 * many people were already members, say, or how many of those removed were
 * only invited) names the reason as it skips an id, or the kind as it does
 * one, and gives the answer one sentence at the end.
 */
final class BulkResult {

	/** @var list<array{id: int, ok: bool, message: string}> */
	private array $rows = [];

	private int $updated = 0;

	private int $skipped = 0;

	/** @var array<string, int> How many ids were skipped for each reason an action named. */
	private array $reasons = [];

	/** @var array<string, int> How many ids were done in each way an action named. */
	private array $kinds = [];

	private string $sentence = '';

	public function __construct( private string $action ) {}

	/**
	 * @param string $kind A key the action counts by, when its sentence tells one way of doing an id from another.
	 */
	public function done( int $id, string $message, string $kind = '' ): void {
		$this->rows[] = [
			'id'      => $id,
			'ok'      => true,
			'message' => $message,
		];
		++$this->updated;
		if ( '' !== $kind ) {
			$this->kinds[ $kind ] = ( $this->kinds[ $kind ] ?? 0 ) + 1;
		}
	}

	/**
	 * @param string $reason A key the action counts by, when its sentence tells one kind of skip from another.
	 */
	public function skip( int $id, string $message, string $reason = '' ): void {
		$this->rows[] = [
			'id'      => $id,
			'ok'      => false,
			'message' => $message,
		];
		++$this->skipped;
		if ( '' !== $reason ) {
			$this->reasons[ $reason ] = ( $this->reasons[ $reason ] ?? 0 ) + 1;
		}
	}

	/** How many ids were done: in the way named, or in all. */
	public function updated( string $kind = '' ): int {
		return '' === $kind ? $this->updated : ( $this->kinds[ $kind ] ?? 0 );
	}

	/** How many ids were skipped: for the reason named, or in all. */
	public function skipped( string $reason = '' ): int {
		return '' === $reason ? $this->skipped : ( $this->reasons[ $reason ] ?? 0 );
	}

	/** The one line that says what the action did, for the list's outcome notice. */
	public function summarise( string $sentence ): void {
		$this->sentence = $sentence;
	}

	/**
	 * @return array{action: string, results: list<array{id: int, ok: bool, message: string}>, updated: int, skipped: int, message?: string}
	 */
	public function toArray(): array {
		$answer = [
			'action'  => $this->action,
			'results' => $this->rows,
			'updated' => $this->updated,
			'skipped' => $this->skipped,
		];
		// Only an action with a sentence of its own answers one; the others
		// answer what they always did, and the list words the counts.
		if ( '' !== $this->sentence ) {
			$answer['message'] = $this->sentence;
		}
		return $answer;
	}
}
