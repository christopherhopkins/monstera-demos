<?php
/**
 * Shared REST-side authorization for delegated portal authors.
 *
 * A thin bridge onto Monstera\Portal\AuthorScope (the single source of truth for
 * who-may-do-what). Mixed into BaseController so every controller inherits it
 * exactly as it inherits canManage(). Keeps the org-/sub-group-clamp and
 * author-ownership rules out of the individual controllers — they call these
 * helpers rather than re-deriving the policy.
 *
 * A scope is for the organization named (People-model track, FR2). A person
 * may manage several organizations, or manage one and lead a sub-group in
 * another, so no write is worked from the scope asked about none: a create
 * takes the organization the request names (authoringScope()), and an edit,
 * a delete or any other act on an item that exists takes the item's own
 * (itemScope(), which requireOwned() judges by). The reads that name an
 * organization are held to the same check as a create: the alert composer's
 * reach numbers (authoringScope()) and a list narrowed to one organization
 * (ownAuthorQueryArgs()).
 */

declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Portal\AuthorScope;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

trait AuthorizesPortalActors {

	/**
	 * The caller's scope in the organization named. Asked about none, the
	 * scope settles on the first organization they manage (or a sub-group
	 * they lead): enough to say whether they are staff or author anywhere,
	 * never where a write belongs.
	 */
	protected function scope( int $orgId = 0 ): AuthorScope {
		// AuthorScope::forUser() already memoizes per user and organization per
		// request, so there's no need for a second instance-level cache here.
		return AuthorScope::forCurrentUser( $orgId );
	}

	/**
	 * The scope a create is written in, or why there is none. Staff keep the
	 * unnamed admin scope and the audience they propose (hubOfStaffCreate()
	 * covers a create that proposes none). Anyone else names the organization
	 * the item is for (org_id) and must author there: a manager or admin of
	 * it by tier, or the leader of a sub-group under it. A request that names
	 * none still works for a caller who authors in exactly one organization,
	 * which is then the one meant; a caller who authors in several is asked
	 * which (422 on org_id).
	 *
	 * A read that is held to the same check (the alert composer's reach
	 * numbers) says so with `$reading`, and a caller it turns away is told
	 * what they may see, not what they may create.
	 */
	protected function authoringScope( WP_REST_Request $request, bool $reading = false ): AuthorScope|WP_Error {
		$scope = $this->scope();
		if ( $scope->isAdmin ) {
			return $scope;
		}

		$orgId = absint( $request['org_id'] ?? 0 );
		if ( 0 === $orgId ) {
			$orgIds = AuthorScope::orgIdsFor( $scope->userId );
			if ( count( $orgIds ) > 1 ) {
				return $this->invalidField( 'org_id', __( 'Say which organization this is for.', 'monstera' ) );
			}
			$orgId = $orgIds[0] ?? 0;
		}

		return $this->scopeWhereAuthoring( $orgId, $reading );
	}

	/**
	 * The caller's scope in one organization, or the refusal for one they
	 * do not author in: they hold the admin or manager tier there, or lead
	 * a sub-group under it. One answer for a create and for the reads that
	 * name an organization (a list, the alert composer's reach numbers), so
	 * a read never tells someone about an organization a create would turn
	 * them away from. The answer is one, the sentence is the caller's own:
	 * someone who asked to list or to count is refused in words about seeing,
	 * since they tried to create nothing.
	 */
	private function scopeWhereAuthoring( int $orgId, bool $reading = false ): AuthorScope|WP_Error {
		$scope = $this->scope( $orgId );
		if ( $orgId <= 0 || ! $scope->canAuthor() || $scope->orgId !== $orgId ) {
			return new WP_Error(
				'monstera_forbidden',
				$reading
					? __( 'You can only see this for an organization you manage or a sub-group you lead there.', 'monstera' )
					: __( 'You can only create items for an organization you manage or a sub-group you lead there.', 'monstera' ),
				[ 'status' => 403 ]
			);
		}
		return $scope;
	}

	/**
	 * The organization a staff create is for when it comes from a hub's
	 * Manage tab, or 0. The tab says everything created there is for that
	 * organization, and its forms name the hub (org_id) and no audience of
	 * their own, so the item is stored for the hub and not for what its kind
	 * falls back on (an alert with no audience is for everyone). A request
	 * that names an audience keeps it, and the admin shell always does and
	 * never sends org_id to these routes, so its saves are as they were.
	 */
	protected function hubOfStaffCreate( WP_REST_Request $request, AuthorScope $scope ): int {
		if ( ! $scope->isAdmin ) {
			return 0;
		}
		foreach ( [ 'org_ids', 'standalone_member_ids', 'audience_all', 'audience_everyone' ] as $ownAudience ) {
			if ( $request->has_param( $ownAudience ) ) {
				return 0;
			}
		}
		$orgId = absint( $request['org_id'] ?? 0 );
		return $orgId > 0 && OrgPostType::SLUG === get_post_type( $orgId ) ? $orgId : 0;
	}

	/**
	 * The caller's scope on an item that exists: theirs in the item's own
	 * organization, whatever the request names. A save clamped with it keeps
	 * the item in that organization.
	 */
	protected function itemScope( int $id ): AuthorScope {
		return AuthorScope::forItem( get_current_user_id(), $id );
	}

	/**
	 * Ownership guard for edit/delete callbacks. Assumes the caller has already
	 * confirmed the post exists and is the right type (controllers keep their
	 * own specific 404 messages); this only enforces "non-admins may only touch
	 * what they authored, in an organization they still author in": the tier
	 * is read in the item's own organization, so someone removed from it or
	 * demoted there is refused though they manage another. Returns a WP_Error
	 * to short-circuit, or null to pass.
	 */
	protected function requireOwned( int $id ): ?WP_Error {
		$scope = $this->itemScope( $id );
		if ( $scope->canEdit( $id ) ) {
			return null;
		}
		$authored = $id > 0 && (int) get_post_field( 'post_author', $id ) === $scope->userId;
		return new WP_Error(
			'monstera_forbidden',
			$authored
				? __( 'You no longer manage the organization this belongs to.', 'monstera' )
				: __( 'You can only manage items you created.', 'monstera' ),
			[ 'status' => 403 ]
		);
	}

	/**
	 * WP_Query args that restrict a listing to the current user's own posts.
	 * Empty for admins (they see everything, whatever organization the
	 * request names), `author => uid` for delegated authors so their lists
	 * only show what they own. A request that names an organization (org_id)
	 * narrows a delegated author's list to what they wrote for it, and is
	 * refused for one they do not author in, as a create is; one that names
	 * none lists what they wrote for every organization of theirs, as it
	 * always did.
	 *
	 * The organization's items are found first and handed to the list by id.
	 * Each kind keeps its organizations in meta its own way, most as a stored
	 * list no query can match on, and the list's own limit then counts that
	 * organization's items alone, where a limit counted first would let
	 * newer items written for another organization crowd them out.
	 *
	 * @param string $postType The kind the route lists.
	 * @return array<string, mixed>|WP_Error
	 */
	protected function ownAuthorQueryArgs( WP_REST_Request $request, string $postType ): array|WP_Error {
		$scope = $this->scope();
		if ( $scope->isAdmin ) {
			return [];
		}
		$own   = [ 'author' => $scope->userId ];
		$orgId = absint( $request['org_id'] ?? 0 );
		if ( 0 === $orgId ) {
			return $own;
		}
		$refusal = $this->scopeWhereAuthoring( $orgId, true );
		if ( $refusal instanceof WP_Error ) {
			return $refusal;
		}

		$written = get_posts(
			[
				'post_type'      => $postType,
				'post_status'    => 'any',
				'posts_per_page' => -1,
			] + $own
		);
		$ids     = [];
		foreach ( $written as $post ) {
			if ( in_array( $orgId, AuthorScope::orgIdsOfItem( (int) $post->ID ), true ) ) {
				$ids[] = (int) $post->ID;
			}
		}
		// An empty post__in lists everything, so with nothing written for the
		// organization the list is asked for a post that cannot exist.
		return $own + [ 'post__in' => $ids ? $ids : [ 0 ] ];
	}
}
