<?php
/**
 * Shared REST-side authorization for delegated portal authors.
 *
 * A thin bridge onto Monstera\Portal\AuthorScope (the single source of truth for
 * who-may-do-what). Mixed into BaseController so every controller inherits it
 * exactly as it inherits canManage(). Keeps the org-/sub-group-clamp and
 * author-ownership rules out of the individual controllers — they call these
 * helpers rather than re-deriving the policy.
 */

declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Portal\AuthorScope;
use WP_Error;

defined( 'ABSPATH' ) || exit;

trait AuthorizesPortalActors {

	protected function scope(): AuthorScope {
		// AuthorScope::forUser() already memoizes per user per request, so there's
		// no need for a second instance-level cache here.
		return AuthorScope::forCurrentUser();
	}

	/**
	 * Ownership guard for edit/delete callbacks. Assumes the caller has already
	 * confirmed the post exists and is the right type (controllers keep their
	 * own specific 404 messages); this only enforces "non-admins may only touch
	 * what they authored." Returns a WP_Error to short-circuit, or null to pass.
	 */
	protected function requireOwned( int $id ): ?WP_Error {
		if ( $this->scope()->canEdit( $id ) ) {
			return null;
		}
		return new WP_Error(
			'monstera_forbidden',
			__( 'You can only manage items you created.', 'monstera' ),
			[ 'status' => 403 ]
		);
	}

	/**
	 * WP_Query args that restrict a listing to the current user's own posts.
	 * Empty for admins (they see everything), `author => uid` for delegated
	 * authors so the portal Manage lists only show what they own.
	 *
	 * @return array<string, int>
	 */
	protected function ownAuthorQueryArgs(): array {
		return $this->scope()->isAdmin ? [] : [ 'author' => $this->scope()->userId ];
	}
}
