<?php
/**
 * Organization self-service.
 *
 * Lets an organization's admins and managers (their tier there, under the
 * monstera_org_manager role ceiling) manage it without full manage_monstera:
 * invite/add members (respecting the seat limit), change a member's tier,
 * remove members (the WP account is preserved, and so are their other
 * memberships; only an invitation nobody signed in to ends with the account
 * it made), edit the org's own profile fields, and renew the membership.
 * Standalone members can renew themselves.
 *
 * Every route is gated twice: a capability (permissionCap) decides "may this
 * kind of user do this at all", and actsWithinOwnOrg() decides "may they do it
 * to THIS org". Admins pass both. Renewals only set the expiry date via the
 * payment seam (Membership / Hooks::PAYMENT_COMPLETED) — this controller just
 * initiates them.
 *
 * The roster's writes are gated a third time, by the who-may-do-what table
 * of the People-model track (FR2), on the caller's tier in THIS org: its
 * organization admins invite at any tier, change tiers and remove anyone; a
 * manager invites and removes plain members and changes no tier; the team
 * (manage_monstera: both staff roles and a WordPress administrator) does
 * everything. The one thing an organization admin may not do is leave the
 * organization without an admin by demoting or removing themselves; the team
 * may. The table is Organizations\RosterPolicy's, which the portal's roster
 * asks too, so the page offers what these routes answer. Each refusal by it
 * is a 403 with the sentence that says who may; the last admin's is a 409,
 * the state refusing the change. Both are decided before anything is
 * written, and each change is the Roster's to write: it re-derives the
 * person's role and files the one activity row.
 */

declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Members\Provisioning;
use Monstera\Members\Repository as MembersRepository;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Organizations\RosterPolicy;
use Monstera\Portal\Flash;
use WP_Error;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class OrgMembersController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/membership',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_RENEW_OWN ),
				'callback'            => [ $this, 'membership' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/members',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'roster' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_INVITE_MEMBERS ),
					'callback'            => [ $this, 'invite' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/members/(?P<member>\d+)',
			[
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'changeTier' ],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'remove' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/members/(?P<member>\d+)/resend',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
				'callback'            => [ $this, 'resend' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)',
			[
				'methods'             => 'PUT',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
				'callback'            => [ $this, 'updateOwn' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/renew',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_RENEW_OWN ),
				'callback'            => [ $this, 'renew' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/me/renew',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_RENEW_OWN ),
				'callback'            => [ $this, 'renewSelf' ],
			]
		);
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function membership( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		$repo = new OrgRepository();
		return [
			'org_id'       => $orgId,
			'name'         => get_the_title( $orgId ),
			'status'       => $repo->status( $orgId ),
			'expires'      => (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ),
			'seat_limit'   => (int) get_post_meta( $orgId, OrgMeta::KEY_SEAT_LIMIT, true ),
			'member_count' => $repo->memberCount( $orgId ),
			'renewal_open' => Membership::renewalOpen( $orgId ),
		];
	}

	/**
	 * The roster, each row with what the caller may do to that person
	 * (`can`: a tier, a removal, the invitation again, each a plain yes or
	 * no). It is the policy's offer for the row, the one the portal's Members
	 * tab draws its controls by and the writes below refuse by, so a page
	 * that reads the roster again learns which of its rows offer something
	 * the caller may no longer do, or lack something they now may. The
	 * answer is for this caller: a manager and an organization admin are
	 * told different things of the same row.
	 *
	 * The team is told one thing more of each row (`removes_account`):
	 * whether taking the person off would remove their account, which it
	 * does for someone who never signed in, invited here and nowhere else,
	 * whose account the invitation made (Roster::accountsEndingWith()). The
	 * organization detail's roster says so in its question, before the
	 * click. The organization's own people are not told: it would say
	 * whether an address they invited was known before (remove()).
	 *
	 * @return array{items: array<int, array<string, mixed>>}|WP_Error
	 */
	public function roster( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		// The memberships table: everyone who belongs here, whichever of
		// their organizations this is, each with their tier in this one and
		// the day they joined it. One read gives every row both.
		$users = ( new MembersRepository() )->byOrg( $orgId );
		$ids   = array_map( static fn ( WP_User $u ): int => (int) $u->ID, $users );
		Roster::prime( $ids );
		$policy = $this->policy( $orgId );
		$going  = $this->canManage() ? Roster::accountsEndingWith( $orgId, $ids ) : null;
		$out    = [];
		foreach ( $users as $u ) {
			$row = self::row( $u, $orgId ) + [ 'can' => RosterPolicy::rowCan( $policy->rowOffer( (int) $u->ID ) ) ];
			if ( null !== $going ) {
				$row['removes_account'] = in_array( (int) $u->ID, $going, true );
			}
			$out[] = $row;
		}
		return [ 'items' => $out ];
	}

	/**
	 * One person's row of the roster. The role beside the tier is what that
	 * tier amounts to here, never the account's own: that one is the ceiling
	 * over every organization of theirs, and would tell a manager of this
	 * one that a plain member here manages another. Since is the day this
	 * membership began, in ISO 8601 (UTC), and says nothing of any other.
	 *
	 * Signed in says whether the person has ever signed in, a yes or a no
	 * and never when: someone who has not is still an invitation, which the
	 * organization detail's roster reads as "Invited" and offers to send
	 * again (resend() refuses it for anyone who has). The organization's own
	 * managers learn nothing new by it: the portal's roster marks the same
	 * people.
	 *
	 * @return array{id: int, name: string, email: string, role: string, tier: string, since: string, signed_in: bool}
	 */
	private static function row( WP_User $user, int $orgId ): array {
		$tier  = (string) Roster::roleOf( (int) $user->ID, $orgId );
		$since = (string) Roster::sinceOf( (int) $user->ID, $orgId );
		return [
			'id'        => (int) $user->ID,
			'name'      => UserMeta::fullName( $user ),
			'email'     => (string) $user->user_email,
			'role'      => self::roleOfTier( $tier ),
			'tier'      => $tier,
			'since'     => '' !== $since ? gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $since . ' UTC' ) ) : '',
			'signed_in' => UserMeta::hasSignedIn( (int) $user->ID ),
		];
	}

	/** The role a tier amounts to in its own organization. */
	private static function roleOfTier( string $tier ): string {
		return in_array( $tier, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true ) ? Capabilities::ROLE_ORG_MANAGER : Capabilities::ROLE_MEMBER;
	}

	/**
	 * Invite an email address into this organization at a tier (member when
	 * none is given). An organization admin and the team invite at any tier;
	 * a manager invites plain members. A new address becomes an account with
	 * the welcome email; an address that already has an account is attached
	 * and welcomed to this organization alone (Roster::invite()).
	 *
	 * The two get the same answer, so the caller cannot learn from it whether
	 * the address was known: it is made of what was asked (the address, the
	 * name typed, the tier) and of nothing the account holds, its id
	 * included, which would tell an attached address from a new one by its
	 * size. Neither client reads an id from it.
	 *
	 * Either way the address is written to, and an attached person can be
	 * removed and invited again, so the same caller invites the same address
	 * here once in five minutes; the team is not counted.
	 *
	 * Nobody is invited into an organization that is in the trash or still
	 * a draft, by its own people or by the team: its rows stay, so its
	 * manager is still its manager, but its hub does not open and every
	 * other door that puts a person in an organization answers that there is
	 * none (BaseController::isPublishedOrg()). The roster's other routes
	 * still answer for it, so someone can be taken off it.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function invite( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		if ( ! $this->isPublishedOrg( $orgId ) ) {
			return self::orgNotFound();
		}
		$tier = $this->tierAsked( $request['tier'] ?? Roster::TIER_MEMBER );
		if ( $tier instanceof WP_Error ) {
			return $tier;
		}
		// Who manages the organization is its admins' to say.
		$refusal = $this->policy( $orgId )->inviteRefusal( $tier );
		if ( $refusal ) {
			return $refusal;
		}

		// Before the address is looked at, so a full roster turns a known
		// address and a new one away alike.
		if ( ! Roster::fits( $orgId, count( Roster::memberIds( $orgId ) ) + 1 ) ) {
			return new WP_Error(
				'monstera_seat_limit_reached',
				__( 'This organization has reached its seat limit. Remove a member or raise the limit first.', 'monstera' ),
				[ 'status' => 422 ]
			);
		}

		// Counted on the address as it was typed, before anyone looks whether
		// it has an account, so a known address and a new one are told to wait
		// alike. Something that is not an address is the Roster's to refuse,
		// and is not counted.
		$email   = (string) ( $request['email'] ?? '' );
		$address = strtolower( sanitize_email( $email ) );
		if ( ! $this->canManage() && is_email( $address ) && $this->overLimit( 'invite_' . $orgId . '_' . $address, 1, 5 * MINUTE_IN_SECONDS ) ) {
			return $this->tooMany( __( 'You tried that address a moment ago. Wait five minutes before inviting it again.', 'monstera' ) );
		}

		// An invite from here joins the organization the route names, and no
		// other.
		$first = sanitize_text_field( (string) ( $request['first_name'] ?? '' ) );
		$last  = sanitize_text_field( (string) ( $request['last_name'] ?? '' ) );
		$user  = Roster::invite(
			$orgId,
			[
				'email'      => $email,
				'first_name' => $first,
				'last_name'  => $last,
				'tier'       => $tier,
			]
		);
		if ( is_wp_error( $user ) ) {
			return $user;
		}
		// For the page that comes back to say "Invitation sent.": said once,
		// to whoever sent it, and not to anyone who types the address.
		Flash::leave( Flash::INVITED, $orgId );

		$email  = sanitize_email( $email );
		$answer = [
			'ok'    => true,
			'name'  => trim( $first . ' ' . $last ) ?: $email,
			'email' => $email,
			'role'  => self::roleOfTier( $tier ),
			'tier'  => $tier,
		];
		// The team reads the account's id, as it reads everything about the
		// person; an organization's own admins and managers do not, since a
		// known account's id would be smaller than any the request could make.
		if ( $this->canManage() ) {
			$answer['id'] = (int) $user->ID;
		}
		return $answer;
	}

	/**
	 * Move a member to another tier of this organization: its organization
	 * admins and the team may, a manager may not. The same tier again is
	 * answered as done and writes nothing.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function changeTier( WP_REST_Request $request ): array|WP_Error {
		$orgId  = (int) $request['id'];
		$member = (int) $request['member'];
		$guard  = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		// Who may at all comes first, so a manager is told that whatever
		// tier and person they name.
		$policy  = $this->policy( $orgId );
		$refusal = $policy->tiersRefusal();
		if ( $refusal ) {
			return $refusal;
		}
		$tier = $this->tierAsked( $request['tier'] ?? null );
		if ( $tier instanceof WP_Error ) {
			return $tier;
		}
		$user = $this->rosterMember( $member, $orgId );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$refusal = $policy->tierRefusal( $member, $tier );
		if ( $refusal ) {
			return $refusal;
		}

		Roster::setRole( $orgId, $member, $tier );
		return [ 'ok' => true ] + self::row( $user, $orgId );
	}

	/**
	 * Take someone off this organization's roster. For someone who never
	 * signed in it is the invitation that ends with their last membership,
	 * and the account with it when the invitation made it (Roster::remove()).
	 *
	 * The team is told whether the account went (`account_removed`), so the
	 * organization detail's roster can say so. The organization's own
	 * admins and managers are answered as for anyone they remove, and the
	 * portal's roster says only what is true either way: an invitation never
	 * tells them whether its address was known already (FR7), and whether
	 * the account went would, since only an account the invitation made
	 * does. Nothing is read of the person once the Roster has answered:
	 * there may be nobody to read.
	 *
	 * @return array{ok: bool, account_removed?: bool}|WP_Error
	 */
	public function remove( WP_REST_Request $request ): array|WP_Error {
		$orgId  = (int) $request['id'];
		$member = (int) $request['member'];
		$guard  = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		$user = $this->rosterMember( $member, $orgId );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		// A manager removes plain members; anyone above is the admins' to
		// remove, and its only admin does not leave.
		$refusal = $this->policy( $orgId )->removalRefusal( $member );
		if ( $refusal ) {
			return $refusal;
		}

		// This one membership goes: the WP account and their other memberships
		// are preserved (standalone only when none remain), and this
		// organization's groups and teams let go. For someone who never signed
		// in it is the invitation that ends with the last one: the account
		// when the invitation made it, and otherwise the link and the client
		// role it gave.
		$ended  = Roster::remove( $orgId, $member );
		$answer = [ 'ok' => true ];
		if ( $this->canManage() ) {
			$answer['account_removed'] = Roster::INVITATION_ACCOUNT === $ended;
		}
		return $answer;
	}

	/**
	 * Send the welcome email again to a member of this org who has never
	 * signed in (the roster's "Resend"). It is the welcome with its
	 * set-password link whichever way they came to be here, a new account or
	 * one that was attached: someone who has never signed in has no password
	 * yet. And it speaks for this organization, whose roster asked: the
	 * email and both rows of the record name it, not the one the person
	 * joined first (Provisioning::resendWelcome()).
	 *
	 * A member who has signed in has nothing to resend, so that is a 422
	 * rather than a second welcome. That holds for someone attached with an
	 * account they already use: they have a password, the roster does not
	 * list them as invited, and the email that told them they were added is
	 * a notice, not a link that lapses, so sending it again would only write
	 * to them twice on a manager's word.
	 *
	 * @return array{ok: bool}|WP_Error
	 */
	public function resend( WP_REST_Request $request ): array|WP_Error {
		$orgId  = (int) $request['id'];
		$member = (int) $request['member'];
		$guard  = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}

		$user = $this->rosterMember( $member, $orgId );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$refusal = $this->policy( $orgId )->resendRefusal( $member );
		if ( $refusal ) {
			return $refusal;
		}
		// Each resend replaces the link in the one before it.
		if ( ! $this->canManage() && $this->overLimit( 'resend_welcome_' . $member, 1, 5 * MINUTE_IN_SECONDS ) ) {
			return $this->tooMany( __( 'The invitation was sent a moment ago. Wait five minutes before sending it again.', 'monstera' ) );
		}
		if ( ! Provisioning::resendWelcome( $member, [ 'org_id' => $orgId ] ) ) {
			return new WP_Error( 'monstera_no_email', __( 'That member has no email address on file.', 'monstera' ), [ 'status' => 422 ] );
		}
		return [ 'ok' => true ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function updateOwn( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		// Profile fields only — status / suspension / seat_limit stay manage_monstera.
		if ( $request->has_param( 'description' ) ) {
			update_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, wp_kses_post( (string) $request['description'] ) );
		}
		if ( $request->has_param( 'location' ) ) {
			update_post_meta( $orgId, OrgMeta::KEY_LOCATION, sanitize_text_field( (string) $request['location'] ) );
		}
		return [
			'ok'          => true,
			'description' => (string) get_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, true ),
			'location'    => (string) get_post_meta( $orgId, OrgMeta::KEY_LOCATION, true ),
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function renew( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		// The one route an ended organization's admin and manager still use.
		$guard = $this->requireOwnOrg( $orgId, true );
		if ( $guard ) {
			return $guard;
		}
		if ( ! Membership::renewalOpen( $orgId ) && ! $this->canManage() ) {
			return new WP_Error( 'monstera_renewal_not_open', __( 'Renewal isn\'t open yet for this membership.', 'monstera' ), [ 'status' => 422 ] );
		}
		// Hand off to payment. The Payments module returns a checkout URL via the
		// filter and later fires Hooks::PAYMENT_COMPLETED, which applies the
		// renewal. Until that module exists the URL is empty (see `wp monstera
		// renew` for a test path).
		$context  = [
			'type'    => 'renewal',
			'org_id'  => $orgId,
			'user_id' => 0,
		];
		$checkout = (string) apply_filters( Hooks::FILTER_RENEWAL_CHECKOUT_URL, '', $context );
		return [
			'ok'               => true,
			'payment_required' => true,
			'checkout_url'     => $checkout,
			'expires'          => (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ),
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	public function renewSelf( WP_REST_Request $request ): array {
		$userId   = get_current_user_id();
		$context  = [
			'type'    => 'renewal',
			'org_id'  => 0,
			'user_id' => $userId,
		];
		$checkout = (string) apply_filters( Hooks::FILTER_RENEWAL_CHECKOUT_URL, '', $context );
		return [
			'ok'               => true,
			'payment_required' => true,
			'checkout_url'     => $checkout,
			'expires'          => (string) get_user_meta( $userId, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ),
		];
	}

	/**
	 * Null when the caller may work this organization's roster: the team,
	 * or one of its own admins and managers while its membership runs. Once
	 * the membership has ended (People-model track, FR5 as built) the portal
	 * answers "Membership ended" for every page of theirs and offers them
	 * one thing, the renewal, so every route here but renew() refuses them
	 * in the blocked page's words: an invitation into an ended organization
	 * would write to a stranger on the word of someone who cannot open the
	 * organization's hub. The team is held to none of this.
	 *
	 * @param bool $toRenew Whether the route is the renewal, which an ended organization's admin and manager keep.
	 */
	private function requireOwnOrg( int $orgId, bool $toRenew = false ): ?WP_Error {
		// Whose it is comes first, so the answer to someone outside is the
		// same for an organization that exists and one that does not.
		if ( ! $this->actsWithinOwnOrg( $orgId ) ) {
			return RosterPolicy::notTheirs();
		}
		if ( ! ( new OrgRepository() )->findById( $orgId ) ) {
			return self::orgNotFound();
		}
		if ( ! $toRenew && ! $this->canManage() && PortalGuard::membershipExpired( $orgId ) ) {
			return self::membershipEnded( $orgId );
		}
		return null;
	}

	private static function orgNotFound(): WP_Error {
		return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
	}

	/**
	 * FR2's table for the caller in this organization. requireOwnOrg() has
	 * already let the organization's managers in; the policy draws the line
	 * between them and its admins, and holds its only admin to staying one.
	 */
	private function policy( int $orgId ): RosterPolicy {
		return RosterPolicy::of( wp_get_current_user(), $orgId );
	}

	/**
	 * The account of someone in this organization, or the 404 every roster
	 * route answers for anyone who is not: a member of another organization,
	 * staff assigned to this one, nobody at all.
	 */
	private function rosterMember( int $member, int $orgId ): WP_User|WP_Error {
		$user = get_user_by( 'id', $member );
		if ( ! $user instanceof WP_User || ! Roster::isMemberOf( $member, $orgId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'That member is not in this organization.', 'monstera' ), [ 'status' => 404 ] );
		}
		return $user;
	}
}
