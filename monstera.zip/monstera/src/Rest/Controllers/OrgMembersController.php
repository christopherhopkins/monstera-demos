<?php
/**
 * Organization self-service.
 *
 * Lets an org admin (monstera_org_manager) manage their own organization without
 * full manage_monstera: invite/add members (respecting the seat limit), remove
 * members (unassign — the WP account is preserved), edit the org's own profile
 * fields, and renew the membership. Standalone members can renew themselves.
 *
 * Every route is gated twice: a capability (permissionCap) decides "may this
 * kind of user do this at all", and actsWithinOwnOrg() decides "may they do it
 * to THIS org". Admins pass both. Renewals only set the expiry date via the
 * payment seam (Membership / Hooks::PAYMENT_COMPLETED) — this controller just
 * initiates them.
 */

declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use WP_Error;
use WP_REST_Request;
use WP_User;

final class OrgMembersController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/membership',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_RENEW_OWN ),
				'callback'            => [ $this, 'membership' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/members',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'roster' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_INVITE_MEMBERS ),
					'callback'            => [ $this, 'invite' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/members/(?P<member>\d+)',
			[
				'methods'             => 'DELETE',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
				'callback'            => [ $this, 'remove' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/members/(?P<member>\d+)/resend',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
				'callback'            => [ $this, 'resend' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)',
			[
				'methods'             => 'PUT',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
				'callback'            => [ $this, 'updateOwn' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/renew',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_RENEW_OWN ),
				'callback'            => [ $this, 'renew' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/me/renew',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_RENEW_OWN ),
				'callback'            => [ $this, 'renewSelf' ],
			]
		);
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function membership( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		$repo = new OrgRepository();
		return [
			'org_id'       => $orgId,
			'name'         => get_the_title( $orgId ),
			'status'       => $repo->status( $orgId ),
			'expires'      => (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ),
			'seat_limit'   => (int) get_post_meta( $orgId, OrgMeta::KEY_SEAT_LIMIT, true ),
			'member_count' => $repo->memberCount( $orgId ),
			'renewal_open' => Membership::renewalOpen( $orgId ),
		];
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}|WP_Error
	 */
	public function roster( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		$users = get_users(
			[
				'meta_key' => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
			'meta_value'   => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
			'number'       => -1,
			'fields'       => 'all',
			]
		);
		$out   = [];
		foreach ( $users as $u ) {
			$out[] = [
				'id'    => (int) $u->ID,
				'name'  => UserMeta::fullName( $u ),
				'email' => (string) $u->user_email,
				'role'  => $u->roles[0] ?? '',
			];
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function invite( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}

		if ( ! Roster::fits( $orgId, count( Roster::memberIds( $orgId ) ) + 1 ) ) {
			return new WP_Error(
				'monstera_seat_limit_reached',
				__( 'This organization has reached its seat limit. Remove a member or raise the limit first.', 'monstera' ),
				[ 'status' => 422 ]
			);
		}

		// Org admins can only mint plain members, always inside their own org.
		$user = Roster::invite(
			$orgId,
			[
				'email'      => (string) ( $request['email'] ?? '' ),
				'first_name' => (string) ( $request['first_name'] ?? '' ),
				'last_name'  => (string) ( $request['last_name'] ?? '' ),
			]
		);
		if ( is_wp_error( $user ) ) {
			return $user;
		}

		return [
			'ok'    => true,
			'id'    => (int) $user->ID,
			'name'  => UserMeta::fullName( $user ),
			'email' => (string) $user->user_email,
			'role'  => Capabilities::ROLE_MEMBER,
		];
	}

	/**
	 * @return array{ok: bool}|WP_Error
	 */
	public function remove( WP_REST_Request $request ): array|WP_Error {
		$orgId  = (int) $request['id'];
		$member = (int) $request['member'];
		$guard  = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}

		$user = get_user_by( 'id', $member );
		if ( ! $user instanceof WP_User || UserMeta::associatedOrg( $member ) !== $orgId ) {
			return new WP_Error( 'monstera_not_found', __( 'That member is not in this organization.', 'monstera' ), [ 'status' => 404 ] );
		}

		// Unassign — the WP account is preserved (the member becomes
		// standalone), and the organization's groups and teams let go.
		Roster::remove( $orgId, $member );
		return [ 'ok' => true ];
	}

	/**
	 * Send the welcome email again to a member of this org who has never
	 * signed in (the portal roster's "Resend"). A member who has signed in
	 * has nothing to resend, so that is a 422 rather than a second welcome.
	 *
	 * @return array{ok: bool}|WP_Error
	 */
	public function resend( WP_REST_Request $request ): array|WP_Error {
		$orgId  = (int) $request['id'];
		$member = (int) $request['member'];
		$guard  = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}

		$user = get_user_by( 'id', $member );
		if ( ! $user instanceof WP_User || UserMeta::associatedOrg( $member ) !== $orgId ) {
			return new WP_Error( 'monstera_not_found', __( 'That member is not in this organization.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( '' !== (string) get_user_meta( $member, UserMeta::KEY_LAST_LOGIN, true ) ) {
			return new WP_Error( 'monstera_already_signed_in', __( 'That member has already signed in, so there is no invitation to resend.', 'monstera' ), [ 'status' => 422 ] );
		}
		// Each resend replaces the link in the one before it.
		if ( ! $this->canManage() && $this->overLimit( 'resend_welcome_' . $member, 1, 5 * MINUTE_IN_SECONDS ) ) {
			return $this->tooMany( __( 'The invitation was sent a moment ago. Wait five minutes before sending it again.', 'monstera' ) );
		}
		if ( ! Provisioning::resendWelcome( $member, [ 'org_id' => $orgId ] ) ) {
			return new WP_Error( 'monstera_no_email', __( 'That member has no email address on file.', 'monstera' ), [ 'status' => 422 ] );
		}
		return [ 'ok' => true ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function updateOwn( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		// Profile fields only — status / suspension / seat_limit stay manage_monstera.
		if ( $request->has_param( 'description' ) ) {
			update_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, wp_kses_post( (string) $request['description'] ) );
		}
		if ( $request->has_param( 'location' ) ) {
			update_post_meta( $orgId, OrgMeta::KEY_LOCATION, sanitize_text_field( (string) $request['location'] ) );
		}
		return [
			'ok'          => true,
			'description' => (string) get_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, true ),
			'location'    => (string) get_post_meta( $orgId, OrgMeta::KEY_LOCATION, true ),
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function renew( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		$guard = $this->requireOwnOrg( $orgId );
		if ( $guard ) {
			return $guard;
		}
		if ( ! Membership::renewalOpen( $orgId ) && ! $this->canManage() ) {
			return new WP_Error( 'monstera_renewal_not_open', __( 'Renewal isn\'t open yet for this membership.', 'monstera' ), [ 'status' => 422 ] );
		}
		// Hand off to payment. The Payments module returns a checkout URL via the
		// filter and later fires Hooks::PAYMENT_COMPLETED, which applies the
		// renewal. Until that module exists the URL is empty (see `wp monstera
		// renew` for a test path).
		$context  = [
			'type'    => 'renewal',
			'org_id'  => $orgId,
			'user_id' => 0,
		];
		$checkout = (string) apply_filters( Hooks::FILTER_RENEWAL_CHECKOUT_URL, '', $context );
		return [
			'ok'               => true,
			'payment_required' => true,
			'checkout_url'     => $checkout,
			'expires'          => (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ),
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	public function renewSelf( WP_REST_Request $request ): array {
		$userId   = get_current_user_id();
		$context  = [
			'type'    => 'renewal',
			'org_id'  => 0,
			'user_id' => $userId,
		];
		$checkout = (string) apply_filters( Hooks::FILTER_RENEWAL_CHECKOUT_URL, '', $context );
		return [
			'ok'               => true,
			'payment_required' => true,
			'checkout_url'     => $checkout,
			'expires'          => (string) get_user_meta( $userId, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ),
		];
	}

	private function requireOwnOrg( int $orgId ): ?WP_Error {
		// Whose it is comes first, so the answer to someone outside is the
		// same for an organization that exists and one that does not.
		if ( ! $this->actsWithinOwnOrg( $orgId ) ) {
			return new WP_Error( 'monstera_forbidden', __( 'You can only manage your own organization.', 'monstera' ), [ 'status' => 403 ] );
		}
		if ( ! ( new OrgRepository() )->findById( $orgId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return null;
	}
}
