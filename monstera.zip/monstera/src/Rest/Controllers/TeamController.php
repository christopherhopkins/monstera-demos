<?php
/**
 * The internal team (People-model track, FR3 and FR11).
 *
 * The team is every staff account: a Team manager, a Team member, and a
 * WordPress administrator, who is a Team manager for every purpose. These
 * routes list it, read one person whole for the staff detail, add to it,
 * save a person's name, address and photo, move someone between its two
 * roles, remove someone from it, and keep the record of who on it knows
 * which client organization.
 *
 * Reading is the whole team's (manage_monstera), so a Team member sees the
 * Team page and the staff detail. Writing is a Team manager's
 * (monstera_manage_team), and a Team member who tries is told so in a
 * sentence. The one write that is anyone's on the team is their own name,
 * address and photo: the name and the address they could as well change on
 * their WordPress profile, and the photo on their portal profile (POST
 * profile/me, which any signed-in account may call).
 *
 * Three rules hold whoever asks. Nobody changes their own team role or
 * removes themselves: there is then always someone else who can manage the
 * team, so it cannot lock itself out, and no "last manager" rule is needed.
 * A WordPress administrator is WordPress's to manage: these routes never
 * change or remove one, nor save their name, address or photo, as the
 * Members routes never touch one. And a client member is never put on the
 * team by their address, because the staff role wins over every tier they
 * hold.
 *
 * An assignment is a row of the memberships table that says a staff person
 * knows an organization, and nothing is filtered by it. Every one is
 * written through Organizations\Roster, which fires its hook once per real
 * change and files the sentence under the organization, so nothing about an
 * assignment is recorded here. The team's own three changes (added, role
 * changed, removed) are about no organization and are recorded here, one
 * row each.
 *
 * A lead is not an assignment. Choosing a lead assigns them (the Projects
 * routes), but ending the assignment leaves them the lead: who leads a
 * project is changed from the project. So that nobody is unassigned
 * unawares, each row that can be unassigned says how many projects the
 * person leads in that organization, and the answer to an unassignment
 * names the projects they still lead there.
 *
 * What a person held as one of the team, their assignments and the
 * projects they led, ends with their last team role, whichever door it
 * leaves by: the Roster listens for the role going (Roster::
 * onRoleRemoved()), so removal here takes the role and nothing else, and a
 * role changed in WordPress's Users screen leaves nothing behind either.
 */

declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Reporting\ActivityFeed;
use Monstera\Reporting\ActivityLog;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class TeamController extends BaseController {

	/**
	 * The two roles these routes give, as the Team page offers them. The
	 * key a row carries is the role's slug, the one the admin's role labels
	 * are keyed by.
	 *
	 * @var list<string>
	 */
	private const TEAM_ROLES = [ Capabilities::ROLE_TEAM_MEMBER, Capabilities::ROLE_ADMIN ];

	/**
	 * What the staff detail's Identity section saves beside the role (comp
	 * 128): the two parts of the name, the address and the photo.
	 *
	 * @var list<string>
	 */
	private const IDENTITY = [ 'first_name', 'last_name', 'email', 'profile_photo' ];

	public function register(): void {
		$manage = $this->managers();
		$assign = $this->permissionManagers( Capabilities::CAP_MANAGE_TEAM, __( 'Only a Team manager can assign the team to organizations.', 'monstera' ) );

		register_rest_route(
			$this->restNamespace,
			'/team',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $manage,
					'callback'            => [ $this, 'add' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/team/(?P<user>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'show' ],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionSave(),
					'callback'            => [ $this, 'update' ],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $manage,
					'callback'            => [ $this, 'remove' ],
				],
			]
		);

		// One person's assignments, for the staff detail's Assigned
		// organizations (comp 128): the whole list, replaced.
		register_rest_route(
			$this->restNamespace,
			'/team/(?P<user>\d+)/orgs',
			[
				'methods'             => 'PUT',
				'permission_callback' => $assign,
				'callback'            => [ $this, 'replaceAssignments' ],
			]
		);

		// The same record from the organization's side, for the Team section
		// of the organization detail (comp 120): one person at a time.
		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/team',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'orgTeam' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $assign,
					'callback'            => [ $this, 'assign' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/orgs/(?P<id>\d+)/team/(?P<user>\d+)',
			[
				'methods'             => 'DELETE',
				'permission_callback' => $assign,
				'callback'            => [ $this, 'unassign' ],
			]
		);
	}

	/**
	 * The team, by name. Like the Members list, it answers every row at
	 * once under `items` and leaves paging and sorting to the admin's Table,
	 * which does both in the browser; `search` (a name or an email address)
	 * and `role` (a team role's slug) narrow what is sent. The team is read
	 * whole and narrowed here, because a WordPress administrator counts as a
	 * Team manager and a name is two meta fields, neither of which a user
	 * query can ask for; the cost is the same for thirty people as for
	 * three (rows()).
	 *
	 * @return array{items: list<array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$search = trim( (string) $request->get_param( 'search' ) );
		$role   = (string) $request->get_param( 'role' );
		$team   = get_users(
			[
				'role__in' => [ 'administrator', Capabilities::ROLE_ADMIN, Capabilities::ROLE_TEAM_MEMBER ],
				'number'   => -1,
				'fields'   => 'all',
			]
		);
		$listed = [];
		foreach ( $team as $user ) {
			if ( '' !== $role && Capabilities::teamRole( $user ) !== $role ) {
				continue;
			}
			if ( '' !== $search && ! self::matches( $user, $search ) ) {
				continue;
			}
			$listed[] = $user;
		}
		usort( $listed, static fn ( WP_User $a, WP_User $b ): int => strnatcasecmp( UserMeta::fullName( $a ), UserMeta::fullName( $b ) ) );
		return [ 'items' => self::rows( $listed ) ];
	}

	/**
	 * "Add to team": an email address and a role. A new address becomes an
	 * account with that role and is sent the team's welcome, which carries
	 * the one-time link that sets a password (Provisioning::createMember();
	 * the dispatcher picks the welcome for a staff account). An address that
	 * already has an account is given the role beside whatever WordPress
	 * roles it holds, keeps its own name and is sent nothing: it has a
	 * password already. Whose address is turned away is refusedForTeam()'s
	 * to say.
	 *
	 * The caller is a Team manager, who can see every account, so the answer
	 * says which of the two happened (`created`).
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function add( WP_REST_Request $request ): array|WP_Error {
		$role = $this->roleAsked( $request['role'] ?? null );
		if ( $role instanceof WP_Error ) {
			return $role;
		}
		$email = sanitize_email( (string) ( $request['email'] ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return $this->invalidField( 'email', __( 'Enter an email address, like name@example.com.', 'monstera' ) );
		}

		$user    = get_user_by( 'email', $email );
		$created = ! $user instanceof WP_User;
		if ( $user instanceof WP_User ) {
			$refused = $this->refusedForTeam( $user );
			if ( $refused ) {
				return $refused;
			}
			$user->add_role( $role );
		} else {
			[ $first, $last ] = self::nameAsked( $request );
			$user             = Provisioning::createMember(
				[
					'email'      => $email,
					'first_name' => $first,
					'last_name'  => $last,
					'role'       => $role,
				]
			);
			if ( $user instanceof WP_Error ) {
				return $user;
			}
		}

		ActivityLog::record(
			'team_added',
			'user',
			(int) $user->ID,
			[
				'org_id' => 0,
				'role'   => $role,
			]
		);
		return [
			'ok'      => true,
			'created' => $created,
		] + self::rows( [ $user ] )[0];
	}

	/**
	 * One of the team, for the staff detail (comp 128). Anyone on the team
	 * is answered for, a WordPress administrator among them; an account that
	 * is not staff has no staff detail, whatever else it is.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$user = self::onTeam( (int) $request['user'] );
		return $user ? $this->detail( $user ) : self::notOnTeam();
	}

	/**
	 * Save what the staff detail's form holds, or the one field the list's
	 * row action sends: the role, the two parts of the name, the address and
	 * the photo, each only when the request names it. A save that names
	 * nothing at all is asked for the role, as it was when the role was all
	 * this route took.
	 *
	 * The role moves between the two team roles. The same role again is
	 * answered as done and writes nothing, which is what lets the detail
	 * send its whole form; any role that is not Monstera's (the site's
	 * editor, say) stays beside the new one. Nobody changes their own role
	 * here. The role the caller already holds, sent beside their own name as
	 * that whole form sends it, asks for no change and is passed over
	 * (asksForRole()); sent alone it is a save that names nothing, and is
	 * refused as any change of one's own role is.
	 *
	 * The photo is an image in the media library, or none (0).
	 *
	 * Every refusal comes before the first write, so a refused save changes
	 * nothing: a name is not saved beside an address that was turned away.
	 * The answer is the detail as it reads after the save, which the list
	 * reads as its row.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id          = (int) $request['user'];
		$changesRole = self::changesRole( $request );
		$user        = $this->teammate( $id, $changesRole ? self::ownRole() : null );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$role = null;
		if ( $changesRole ) {
			$role = $this->roleAsked( $request['role'] ?? null );
			if ( $role instanceof WP_Error ) {
				return $role;
			}
		}
		$core = [];
		if ( $request->has_param( 'first_name' ) ) {
			$core['first_name'] = sanitize_text_field( (string) $request['first_name'] );
		}
		if ( $request->has_param( 'last_name' ) ) {
			$core['last_name'] = sanitize_text_field( (string) $request['last_name'] );
		}
		if ( $request->has_param( 'email' ) ) {
			$email = $this->checkedEmail( is_string( $request['email'] ) ? $request['email'] : '', $id );
			if ( $email instanceof WP_Error ) {
				return $email;
			}
			// The address the account already has, sent back with the whole
			// form, is no change. Another one is, and for a teammate who also
			// works in WordPress by a role that is not the team's it is a
			// WordPress administrator's to make (signInRefusal()).
			$moved = $email !== (string) $user->user_email ? $this->signInRefusal( $user, 'email' ) : null;
			if ( $moved ) {
				return $moved;
			}
			$core['user_email'] = $email;
		}
		$photo = $this->checkedPhoto( $request );
		if ( $photo instanceof WP_Error ) {
			return $photo;
		}

		$written = false;
		if ( $core ) {
			$updated = wp_update_user( [ 'ID' => $id ] + $core );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
			$written = true;
		}
		if ( null !== $photo ) {
			update_user_meta( $id, UserMeta::KEY_PROFILE_PHOTO, $photo );
			$written = true;
		}
		$from = Capabilities::teamRole( $user );
		if ( null !== $role && $from !== $role ) {
			// Given before the other is taken, so the account is never without a
			// team role between the two writes.
			$user->add_role( $role );
			foreach ( array_diff( self::TEAM_ROLES, [ $role ] ) as $other ) {
				$user->remove_role( $other );
			}
			ActivityLog::record(
				'team_role_changed',
				'user',
				$id,
				[
					'org_id' => 0,
					'from'   => $from,
					'to'     => $role,
				]
			);
			$written = true;
		}
		if ( $written ) {
			$this->stampAccountSaved( $id );
		}
		// Read again, so the answer carries the name and the role as saved.
		return [ 'ok' => true ] + $this->detail( get_user_by( 'id', $id ) ?: $user );
	}

	/**
	 * Remove someone from the team. The WordPress account is kept, with
	 * every role that is not the team's; one that held nothing else is left
	 * with no role at all. Taking the role is all this route does about
	 * what they held: the Roster hears the last team role go and ends their
	 * assignments, one unassigned hook each, and their leads, so the
	 * projects they led read "No project lead" (Roster::onRoleRemoved()), exactly as
	 * it would had the role been taken in WordPress's Users screen.
	 *
	 * Someone who also belongs to a client organization keeps that
	 * membership, which was never the team's to end, and the Roster gives
	 * them the client role its tier implies as the team role goes, unless
	 * the account still works in wp-admin by another role
	 * (Roster::onRoleRemoved() says why). That is the Roster's too, and not
	 * done here, so the two doors cannot come to differ: a role taken in
	 * WordPress leaves the person exactly where this route does.
	 *
	 * @return array{ok: bool}|WP_Error
	 */
	public function remove( WP_REST_Request $request ): array|WP_Error {
		$user = $this->teammate( (int) $request['user'], __( 'You cannot remove yourself from the team. Ask another Team manager.', 'monstera' ) );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$id   = (int) $user->ID;
		$role = Capabilities::teamRole( $user );

		foreach ( self::TEAM_ROLES as $held ) {
			$user->remove_role( $held );
		}

		ActivityLog::record(
			'team_removed',
			'user',
			$id,
			[
				'org_id' => 0,
				'role'   => $role,
			]
		);
		return [ 'ok' => true ];
	}

	/**
	 * Make one person's assignments exactly the organizations named: the
	 * ones left out are unassigned and the new ones assigned, each through
	 * the Roster, so each real change fires its hook once and one already
	 * held fires nothing. Every refusal comes before the first write, so a
	 * refused list changes nothing. A new organization must be on the site
	 * and active; one the person is already assigned to is kept as it is,
	 * whatever has become of it since.
	 *
	 * Anyone on the team can be assigned, a WordPress administrator and the
	 * caller among them: who knows a client is not a role.
	 *
	 * An organization whose projects the person leads is ended like any
	 * other and they stay the lead (see unassign()); the answer names the
	 * projects they still lead in the organizations this save ended
	 * (`leads`), beside the person as the list shows them.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function replaceAssignments( WP_REST_Request $request ): array|WP_Error {
		$user = self::onTeam( (int) $request['user'] );
		if ( ! $user ) {
			return self::notOnTeam();
		}
		$id    = (int) $user->ID;
		$asked = $request['org_ids'] ?? null;
		if ( ! is_array( $asked ) ) {
			return $this->invalidField( 'org_ids', __( 'Send the organizations to assign as a list.', 'monstera' ) );
		}
		$wanted  = array_values( array_unique( array_map( 'absint', $asked ) ) );
		$current = Roster::assignedOrgIdsOf( $id );
		$new     = array_values( array_diff( $wanted, $current ) );
		_prime_post_caches( $new, false, false );
		foreach ( $new as $orgId ) {
			if ( ! $this->isOrgOnSite( $orgId ) ) {
				return $this->invalidField( 'org_ids', __( 'One of the selected organizations does not exist.', 'monstera' ) );
			}
			$closed = $this->notActiveRefusal( $orgId, 'org_ids' );
			if ( $closed ) {
				return $closed;
			}
			$member = $this->refusedAsMember( $user, $orgId, 'org_ids' );
			if ( $member ) {
				return $member;
			}
		}

		$ended = array_values( array_diff( $current, $wanted ) );
		foreach ( $ended as $orgId ) {
			Roster::unassign( $orgId, $id );
		}
		foreach ( $new as $orgId ) {
			Roster::assign( $orgId, $id );
		}
		// What they still lead in the organizations this save ended, read only
		// when it ended one.
		$leads = array_filter(
			$ended ? ( new ProjectRepository() )->ledBy( [ $id ] ) : [],
			static fn ( WP_Post $project ): bool => in_array( (int) get_post_meta( $project->ID, ProjectMeta::KEY_ORG_ID, true ), $ended, true )
		);
		return [
			'ok'    => true,
			'leads' => self::leads( $leads ),
		] + self::rows( [ $user ] )[0];
	}

	/**
	 * The staff assigned to an organization, oldest assignment first. The
	 * Roster ends a person's assignments when their last team role goes
	 * (Roster::onRoleRemoved()), so a row for someone who is no longer staff
	 * is one a write straight to the database left behind. They are not
	 * staff, so they are not listed; unassign() clears the row, and so does
	 * the daily sweep (Roster::sweepOrphans()).
	 *
	 * Each row says how many of the organization's projects the person
	 * leads, for the sentence that confirms an unassignment: one grouped
	 * read for the whole list, which loads no project
	 * (Projects\Repository::ledCountsIn()).
	 *
	 * @return array{items: list<array<string, mixed>>}|WP_Error
	 */
	public function orgTeam( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		if ( ! ( new OrgRepository() )->findById( $orgId ) ) {
			return self::orgNotFound();
		}
		$ids = Roster::staffIds( $orgId );
		// An empty include would mean everyone to the user query.
		$assigned = $ids
			? get_users(
				[
					'include' => $ids,
					'orderby' => 'include',
					'number'  => -1,
					'fields'  => 'all',
				]
			)
			: [];
		$led      = ( new ProjectRepository() )->ledCountsIn( $orgId, $ids );
		// The Team block marks the account lead's row (At-a-glance track, FR4).
		$leadId = ( new OrgRepository() )->accountLeadId( $orgId );
		$items  = [];
		UserMeta::primePhotos( $ids );
		foreach ( $assigned as $user ) {
			if ( Capabilities::isStaff( $user ) ) {
				$items[] = self::person( $user ) + [
					'projects_led'    => $led[ (int) $user->ID ] ?? 0,
					'is_account_lead' => (int) $user->ID === $leadId,
				];
			}
		}
		return [ 'items' => $items ];
	}

	/**
	 * Assign a staff person to the organization. Someone already assigned
	 * is answered as done: the Roster leaves the row that exists alone, so
	 * there is no second row, hook or sentence. The answer is the person as
	 * orgTeam() lists them, the projects they already lead here counted:
	 * someone unassigned while leading is still the lead when they return.
	 *
	 * Nobody named is a field left empty (422). Someone named who is not on
	 * the team is someone the route does not have (404), as every Team
	 * route answers of anyone not on it: a page that still offers them was
	 * behind, and reads the team again (memberships.js leftBehindThePage()).
	 * An organization that is suspended or archived takes no team until it
	 * is reactivated (409).
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function assign( WP_REST_Request $request ): array|WP_Error {
		$orgId = (int) $request['id'];
		if ( ! $this->isOrgOnSite( $orgId ) ) {
			return self::orgNotFound();
		}
		$closed = $this->notActiveRefusal( $orgId );
		if ( $closed ) {
			return $closed;
		}
		$userId = absint( $request['user_id'] ?? 0 );
		$user   = self::onTeam( $userId );
		if ( ! $user ) {
			return $userId > 0
				? self::notOnTeam()
				: $this->invalidField( 'user_id', __( 'Choose someone from the team.', 'monstera' ) );
		}
		$member = $this->refusedAsMember( $user, $orgId, 'user_id' );
		if ( $member ) {
			return $member;
		}
		Roster::assign( $orgId, (int) $user->ID );
		return [ 'ok' => true ] + self::person( $user ) + [
			'projects_led'    => ( new ProjectRepository() )->ledCountsIn( $orgId, [ (int) $user->ID ] )[ (int) $user->ID ] ?? 0,
			'is_account_lead' => ( new OrgRepository() )->accountLeadId( $orgId ) === (int) $user->ID,
		];
	}

	/**
	 * End one assignment. Whether the account is still staff is not asked,
	 * so a row left by someone who has gone from the team can be cleared; a
	 * membership is not an assignment and is never ended here.
	 *
	 * Someone who leads projects of the organization is unassigned like
	 * anyone else and stays their lead. The answer names those projects
	 * (`leads`), so the page can say that they still lead them and where to
	 * change it.
	 *
	 * @return array{ok: bool, leads: list<array{id: int, title: string}>}|WP_Error
	 */
	public function unassign( WP_REST_Request $request ): array|WP_Error {
		$orgId  = (int) $request['id'];
		$userId = (int) $request['user'];
		if ( ! Roster::isAssignedTo( $userId, $orgId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'That person is not assigned to this organization.', 'monstera' ), [ 'status' => 404 ] );
		}
		Roster::unassign( $orgId, $userId );
		return [
			'ok'    => true,
			'leads' => self::leads( ( new ProjectRepository() )->ledBy( [ $userId ], $orgId ) ),
		];
	}

	// ---- Who may, and whom ----------------------------------------------------

	/**
	 * The gate on adding to the team, saving a record and removing from the
	 * team: a Team manager's and a WordPress administrator's, and a Team
	 * member reads who may (BaseController::permissionManagers()).
	 */
	private function managers(): callable {
		return $this->permissionManagers( Capabilities::CAP_MANAGE_TEAM, __( 'Only a Team manager can change who is on the team.', 'monstera' ) );
	}

	/**
	 * The gate on PUT team/{user}. A save is a Team manager's, like every
	 * other write here (managers()), with one exception: anyone on the team
	 * saves their own name, address and photo, as the staff detail shows a
	 * Team member their own record (comp 128) and as they could elsewhere:
	 * the name and the address on their WordPress profile, the photo on
	 * their portal profile. A save that asks for a role is never that
	 * exception, so a Team member who asks for one reads who may give one.
	 * The answer is gateRefusal()'s, which the staff detail asks as well.
	 */
	private function permissionSave(): callable {
		return fn ( WP_REST_Request $request ): bool|WP_Error => $this->gateRefusal( (int) $request['user'], self::changesRole( $request ) ) ?? true;
	}

	/**
	 * Why the gate turns a save of a record away, or null when it lets it
	 * through: the one answer for a request (permissionSave()) and for what
	 * the staff detail tells its reader beforehand (saveRefusal()).
	 *
	 * @param bool $changesRole Whether the save is one of the role (changesRole()).
	 */
	private function gateRefusal( int $id, bool $changesRole ): ?WP_Error {
		if ( ! $changesRole && $this->canManage() && get_current_user_id() === $id ) {
			return null;
		}
		$managers = ( $this->managers() )();
		return $managers instanceof WP_Error ? $managers : null;
	}

	/**
	 * Why the caller may not save a record, or null when they may: the
	 * gate's answer, then the handler's, in the order a request meets them
	 * (permissionSave(), teammate()). Asked for the staff detail, so the
	 * page offers a field exactly where the route would take it, and shows
	 * the route's sentence where it would not.
	 *
	 * @param bool $changesRole Whether it is the role that would be saved, or the name, the address and the photo.
	 */
	private function saveRefusal( WP_User $user, bool $changesRole ): ?WP_Error {
		return $this->gateRefusal( (int) $user->ID, $changesRole )
			?? self::refusalAbout( $user, $changesRole ? self::ownRole() : null );
	}

	/**
	 * Whether a save is one of the role: it asks for one (asksForRole()), or
	 * it names nothing at all and is asked for the role, as it was when the
	 * role was all the route took. The gate and the handler both ask here,
	 * so a save is the same kind to both.
	 */
	private static function changesRole( WP_REST_Request $request ): bool {
		return self::asksForRole( $request ) || ! self::namesIdentity( $request );
	}

	/** What the caller is told about a change of their own role. */
	private static function ownRole(): string {
		return __( 'You cannot change your own team role. Ask another Team manager.', 'monstera' );
	}

	/**
	 * Whether a save asks for a role. One that names a role does, with one
	 * exception: the role the caller already holds, named on their own
	 * record. The staff detail sends its whole form, the role select with
	 * it, and on the reader's own record that would read as a change of
	 * their own role when it asks for none.
	 */
	private static function asksForRole( WP_REST_Request $request ): bool {
		if ( ! $request->has_param( 'role' ) ) {
			return false;
		}
		$caller = wp_get_current_user();
		$held   = Capabilities::teamRole( $caller );
		return (int) $caller->ID !== (int) $request['user'] || '' === $held || $request['role'] !== $held;
	}

	/** Whether a save names any of the Identity section's fields. */
	private static function namesIdentity( WP_REST_Request $request ): bool {
		foreach ( self::IDENTITY as $field ) {
			if ( $request->has_param( $field ) ) {
				return true;
			}
		}
		return false;
	}

	/** The account, when it is on the team. */
	private static function onTeam( int $id ): ?WP_User {
		$user = $id > 0 ? get_user_by( 'id', $id ) : false;
		return $user instanceof WP_User && Capabilities::isStaff( $user ) ? $user : null;
	}

	private static function notOnTeam(): WP_Error {
		return new WP_Error( 'monstera_not_found', __( 'That person is not on the team.', 'monstera' ), [ 'status' => 404 ] );
	}

	private static function orgNotFound(): WP_Error {
		return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
	}

	/**
	 * The person a save or a removal is about, or why it may not be made:
	 * they are not on the team (404), they are the caller (409, the state
	 * refusing the change, as for an organization's last admin), or they are
	 * a WordPress administrator (422), whose role, name and address are all
	 * WordPress's and whose record these routes leave whole, the photo with
	 * it. The caller is asked about first, so an administrator changing
	 * their own role reads the sentence about themselves. A save of the
	 * name, the address or the photo alone is one the caller may make of
	 * their own record, and passes no sentence.
	 *
	 * @param string|null $own What the caller is told about acting on themselves; null when they may.
	 */
	private function teammate( int $id, ?string $own ): WP_User|WP_Error {
		$user = self::onTeam( $id );
		if ( ! $user ) {
			return self::notOnTeam();
		}
		return self::refusalAbout( $user, $own ) ?? $user;
	}

	/**
	 * teammate()'s two refusals about someone who is on the team, or null
	 * when the change may be made: they are the caller (409), or a WordPress
	 * administrator (422). Apart from the lookup, so the staff detail can
	 * ask them of the person it has already read (saveRefusal()).
	 *
	 * @param string|null $own What the caller is told about acting on themselves; null when they may.
	 */
	private static function refusalAbout( WP_User $user, ?string $own ): ?WP_Error {
		if ( null !== $own && get_current_user_id() === (int) $user->ID ) {
			return new WP_Error( 'monstera_own_team_role', $own, [ 'status' => 409 ] );
		}
		if ( in_array( 'administrator', (array) $user->roles, true ) ) {
			return new WP_Error( 'monstera_wp_administrator', __( 'WordPress administrators are managed in WordPress, under Users.', 'monstera' ), [ 'status' => 422 ] );
		}
		return null;
	}

	/**
	 * Why an account that exists may not be given a team role by its
	 * address, or null when it may. Someone already on the team is a
	 * conflict: adding them again is not the way to change their role. A
	 * client member (Provisioning::isClientMember()) is refused on the
	 * field, naming their first organization when they have one, which the
	 * team can see anyway.
	 */
	private function refusedForTeam( WP_User $user ): ?WP_Error {
		if ( Capabilities::isStaff( $user ) ) {
			return new WP_Error( 'monstera_already_on_team', __( 'That address is already on the team.', 'monstera' ), [ 'status' => 409 ] );
		}
		if ( ! Provisioning::isClientMember( $user ) ) {
			return null;
		}
		$orgId = Roster::primaryOrgOf( (int) $user->ID );
		return $this->invalidField(
			'email',
			$orgId > 0
				/* translators: %s: an organization's name */
				? sprintf( __( 'That address belongs to a member of %s, and a client member cannot be added to the team: use another address.', 'monstera' ), self::orgName( $orgId ) )
				: __( 'That address belongs to a standalone member, and a client member cannot be added to the team: use another address.', 'monstera' )
		);
	}

	/**
	 * Why a staff person cannot be assigned to an organization they belong
	 * to, or null when they do not. The table holds one row for a person
	 * and an organization, and the Roster leaves a row that exists alone:
	 * nothing would be written, and an answer of "assigned" would lie.
	 *
	 * @param string $field The request parameter the refusal names.
	 */
	private function refusedAsMember( WP_User $user, int $orgId, string $field ): ?WP_Error {
		if ( ! Roster::isMemberOf( (int) $user->ID, $orgId ) ) {
			return null;
		}
		return $this->invalidField(
			$field,
			/* translators: 1: a person's name, 2: an organization's name */
			sprintf( __( '%1$s is a member of %2$s, so they cannot also be assigned to it.', 'monstera' ), UserMeta::fullName( $user ), self::orgName( $orgId ) )
		);
	}

	/** The team role a request names, or the refusal on the field for anything else. */
	private function roleAsked( mixed $asked ): string|WP_Error {
		if ( is_string( $asked ) && in_array( $asked, self::TEAM_ROLES, true ) ) {
			return $asked;
		}
		return $this->invalidField( 'role', __( 'Choose a role: Team member or Team manager.', 'monstera' ) );
	}

	/**
	 * The name for a new account: the two fields the Team page's form sends,
	 * or one whole name split at its first space.
	 *
	 * @return array{0: string, 1: string}
	 */
	private static function nameAsked( WP_REST_Request $request ): array {
		$first = sanitize_text_field( (string) ( $request['first_name'] ?? '' ) );
		$last  = sanitize_text_field( (string) ( $request['last_name'] ?? '' ) );
		if ( '' === $first . $last ) {
			$whole = explode( ' ', sanitize_text_field( (string) ( $request['name'] ?? '' ) ), 2 );
			$first = $whole[0];
			$last  = $whole[1] ?? '';
		}
		return [ $first, $last ];
	}

	/** Whether a name as the list shows it, or an email address, holds what was typed. */
	private static function matches( WP_User $user, string $search ): bool {
		return false !== stripos( UserMeta::fullName( $user ), $search )
			|| false !== stripos( (string) $user->user_email, $search );
	}

	// ---- Shapes ---------------------------------------------------------------

	/**
	 * The rows of the Team list. Each names the organizations the person is
	 * assigned to: one read of the memberships for everyone and one of the
	 * organizations they name, not one per row or per organization.
	 *
	 * @param list<WP_User> $users
	 * @return list<array<string, mixed>>
	 */
	private static function rows( array $users ): array {
		$ids = array_map( static fn ( WP_User $user ): int => (int) $user->ID, $users );
		Roster::prime( $ids );
		UserMeta::primePhotos( $ids );
		$orgIds = [];
		foreach ( $users as $user ) {
			foreach ( Roster::assignedOrgIdsOf( (int) $user->ID ) as $orgId ) {
				$orgIds[ $orgId ] = $orgId;
			}
		}
		_prime_post_caches( array_values( $orgIds ), false, false );

		$rows = [];
		foreach ( $users as $user ) {
			$id            = (int) $user->ID;
			$organizations = [];
			foreach ( Roster::assignedOrgIdsOf( $id ) as $orgId ) {
				$organizations[] = [
					'id'   => $orgId,
					'name' => get_the_title( $orgId ),
				];
			}
			$rows[] = self::person( $user ) + [
				// Marked because these routes never change or remove one.
				'is_administrator' => in_array( 'administrator', (array) $user->roles, true ),
				// The reader's own row, which the list marks "You" (comp 112) and
				// on which nobody changes their role or removes themselves.
				'is_self'          => get_current_user_id() === $id,
				'organizations'    => $organizations,
				'last_login'       => (string) get_user_meta( $id, UserMeta::KEY_LAST_LOGIN, true ),
				'registered'       => (string) $user->user_registered,
				'edit_url'         => admin_url( 'admin.php?page=monstera-team&id=' . $id ),
			];
		}
		return $rows;
	}

	/**
	 * One of the team as the staff detail shows them (comp 128): the list's
	 * row, then the parts of the name and the photo for the Identity
	 * section, the projects they lead, the save bar's stamp and the
	 * sidebar's recent activity in the shape every detail reads
	 * (Reporting\ActivityFeed). Each assigned organization carries more here
	 * than in the list: its status for the chip, when the assignment began,
	 * and how many projects the person leads there, for the sentence that
	 * confirms an unassignment. A led project is listed whether or not they
	 * are still assigned to its organization.
	 *
	 * The cost is the same for eight organizations and projects as for two:
	 * the projects led are one read with their meta, and every organization
	 * named, an assigned one or a led project's, is read with its status in
	 * one more.
	 *
	 * It also says what this reader may do to the record (`can`, with the
	 * refusal's sentence in `why_not`): save the name, the address and the
	 * photo (`save`), change the address (`email`), choose the role (`role`)
	 * and have the welcome sent again (`resend`). Each is the answer its
	 * route would give, the gate's and then the handler's (saveRefusal()
	 * here, the Members route the detail's Resend welcome calls), so the
	 * page keeps no copy of the rule: it shows a fact where the route would
	 * refuse a field, and leaves the button out. An address is part of a
	 * save, so whoever may not save may not change it; beyond that, the
	 * address of a teammate who also works in WordPress by another role is
	 * a WordPress administrator's to change, and so is their welcome
	 * (BaseController::signInRefusal()). The Members route answers for no
	 * WordPress administrator, so the welcome of one is refused here in the
	 * sentence that says whose the account is.
	 *
	 * @return array<string, mixed>
	 */
	private function detail( WP_User $user ): array {
		$id          = (int) $user->ID;
		$assignments = Roster::assignmentsOf( $id );
		$projects    = new ProjectRepository();
		$led         = $projects->ledBy( [ $id ] );
		$orgOf       = [];
		foreach ( $led as $project ) {
			$orgOf[ $project->ID ] = (int) get_post_meta( $project->ID, ProjectMeta::KEY_ORG_ID, true );
		}
		$ledIn = array_count_values( $orgOf );
		_prime_post_caches( array_values( array_unique( array_merge( array_column( $assignments, 'org_id' ), array_values( $orgOf ) ) ) ), false, true );

		$orgs          = new OrgRepository();
		$organizations = [];
		foreach ( $assignments as $held ) {
			$organizations[] = [
				'id'              => $held['org_id'],
				'name'            => get_the_title( $held['org_id'] ),
				'status'          => $orgs->status( $held['org_id'] ),
				'since'           => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $held['since'] . ' UTC' ) ),
				'projects_led'    => $ledIn[ $held['org_id'] ] ?? 0,
				// The chip says "Account lead" where they are (At-a-glance
				// track, FR4): from the meta primed above, no read a chip.
				'is_account_lead' => $orgs->accountLeadId( (int) $held['org_id'] ) === $id,
			];
		}
		$rows = [];
		foreach ( $led as $project ) {
			$orgId  = $orgOf[ $project->ID ];
			$stage  = $projects->status( $project->ID );
			$rows[] = [
				'id'           => $project->ID,
				'title'        => get_the_title( $project ),
				'org_id'       => $orgId,
				'org_name'     => $orgId > 0 ? get_the_title( $orgId ) : '',
				'status'       => $stage,
				'status_label' => ProjectMeta::statusLabel( $stage ),
				'due_on'       => (string) get_post_meta( $project->ID, ProjectMeta::KEY_DUE_ON, true ),
				'edit_url'     => admin_url( 'admin.php?page=monstera-projects&id=' . $project->ID ),
			];
		}
		$photoId = (int) get_user_meta( $id, UserMeta::KEY_PROFILE_PHOTO, true );
		$save    = $this->saveRefusal( $user, false );

		return array_replace( self::rows( [ $user ] )[0], [ 'organizations' => $organizations ] ) + [
			'first_name'        => (string) $user->first_name,
			'last_name'         => (string) $user->last_name,
			'profile_photo'     => $photoId,
			'profile_photo_url' => $photoId ? (string) wp_get_attachment_image_url( $photoId, 'thumbnail' ) : '',
			'projects'          => $rows,
			'saved'             => $this->accountSavedStamp( $id ),
			'activity'          => ActivityFeed::shape( ActivityLog::forUser( $id, 5 ) ),
		] + self::permissions(
			[
				'save'   => $save,
				'email'  => $save ?? $this->signInRefusal( $user, 'email' ),
				'role'   => $this->saveRefusal( $user, true ),
				'resend' => self::refusalAbout( $user, null ) ?? $this->resendRefusal( $user ),
			]
		);
	}

	/**
	 * Projects as the answer to an unassignment names them: enough for a
	 * sentence and a link.
	 *
	 * @param WP_Post[] $projects
	 * @return list<array{id: int, title: string}>
	 */
	private static function leads( array $projects ): array {
		return array_map(
			static fn ( WP_Post $project ): array => [
				'id'    => (int) $project->ID,
				'title' => get_the_title( $project ),
			],
			array_values( $projects )
		);
	}

	/**
	 * One of the team as every answer here names them. The role is the team
	 * role's slug, the Team manager's for a WordPress administrator. The
	 * avatar is the photo they uploaded, or null for the leaf (never
	 * Gravatar's silhouette: UserMeta::photoUrl()).
	 *
	 * @return array{id: int, name: string, email: string, avatar: ?string, role: string}
	 */
	private static function person( WP_User $user ): array {
		$id = (int) $user->ID;
		return [
			'id'     => $id,
			'name'   => UserMeta::fullName( $user ),
			'email'  => (string) $user->user_email,
			'avatar' => UserMeta::photoUrl( $id ),
			'role'   => Capabilities::teamRole( $user ),
		];
	}

	/** An organization's name as plain text, for a sentence. */
	private static function orgName( int $orgId ): string {
		return html_entity_decode( (string) get_post_field( 'post_title', $orgId, 'raw' ), ENT_QUOTES, 'UTF-8' );
	}
}
