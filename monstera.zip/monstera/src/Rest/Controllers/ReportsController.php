<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Reporting\ActivityLog;
use Monstera\Subgroups\PostType as SubgroupPostType;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class ReportsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/reports/overview',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'overview' ],
			]
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	public function overview(): array {
		$loginsWeek     = ActivityLog::loginsThisWeek();
		$downloadsWeek  = ActivityLog::downloadsThisWeek();
		$loginsByDay    = ActivityLog::loginsByDay();
		$downloadsByDay = ActivityLog::downloadsByDay();
		$topContent     = ActivityLog::topContent();
		// The same seven days as the charts, so the page can say which
		// sub-groups were quiet "this week" and mean it.
		$subgroupEng = ActivityLog::subgroupEngagement( null, 7 );

		$out = [
			'has_activity'        => $loginsWeek > 0 || $downloadsWeek > 0 || ! empty( $topContent ),
			'logins_this_week'    => $loginsWeek,
			'logins_last_week'    => ActivityLog::loginsLastWeek(),
			'logins_by_day'       => $loginsByDay,
			'downloads_this_week' => $downloadsWeek,
			'downloads_last_week' => ActivityLog::downloadsLastWeek(),
			'downloads_by_day'    => $downloadsByDay,
			'top_content'         => $topContent,
			'subgroup_engagement' => $subgroupEng,
		];
		// Resource opens and Form submissions (Forms-and-resources track,
		// FR8), each with its module.
		if ( \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::RESOURCES ) ) {
			$out['resource_opens_this_week'] = ActivityLog::resourceOpensThisWeek();
			$out['resource_opens_last_week'] = ActivityLog::resourceOpensLastWeek();
			$out['resource_opens_by_day']    = ActivityLog::resourceOpensByDay();
			$out['has_activity']             = $out['has_activity'] || $out['resource_opens_this_week'] > 0;
		}
		if ( \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::FORMS ) ) {
			$out['form_submissions_this_week'] = ActivityLog::formSubmissionsThisWeek();
			$out['form_submissions_last_week'] = ActivityLog::formSubmissionsLastWeek();
			$out['form_submissions_by_day']    = ActivityLog::formSubmissionsByDay();
			$out['has_activity']               = $out['has_activity'] || $out['form_submissions_this_week'] > 0;
		}
		return $out;
	}
}
