<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Capabilities;
use Monstera\Core\ToolRuns;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Reporting\ActivityLog;
use Monstera\Reporting\Exporters\ActivityLogExporter;
use Monstera\Reporting\Exporters\MembersExporter;
use Monstera\Reporting\Exporters\OrgListExporter;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * What the Tools page reads and runs: each tool's last run, the first-email
 * reset and the three exports. The sync it runs is SyncController's.
 *
 * Tools are a Team manager's and a WordPress administrator's (People-model
 * track, FR2), so what only the Tools page calls asks for
 * monstera_manage_settings: the status, the reset and the members export. A
 * Team member is told who may in a sentence.
 *
 * The other two exports are not the Tools page's alone. The Organizations
 * list offers the organizations export, whole or for a selection, and the
 * Reports page the activity log, and a Team member works in both, so those
 * two stay with the whole team (manage_monstera).
 */
final class ToolsController extends BaseController {

	public function register(): void {
		// The sync's route says the same sentence (SyncController).
		$managers = $this->permissionManagers( Capabilities::CAP_MANAGE_SETTINGS, __( 'Only a Team manager can run tools.', 'monstera' ) );

		register_rest_route(
			$this->restNamespace,
			'/tools/status',
			[
				'methods'             => 'GET',
				'permission_callback' => $managers,
				'callback'            => [ $this, 'status' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/reset-first-email',
			[
				'methods'             => 'POST',
				'permission_callback' => $managers,
				'callback'            => [ $this, 'resetFirstEmail' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/export/members',
			[
				'methods'             => 'GET',
				'permission_callback' => $managers,
				'callback'            => [ $this, 'exportMembers' ],
			]
		);

		// The next two are also the Reports page's and the Organizations
		// list's, so the whole team keeps them (see the class comment).
		register_rest_route(
			$this->restNamespace,
			'/tools/export/activity',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'exportActivity' ],
				'args'                => [
					'since_days' => [
						'type'    => 'integer',
						'default' => 90,
						'minimum' => 1,
						'maximum' => 3650,
					],
					'event'      => [ 'type' => 'string' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/export/orgs',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'exportOrgs' ],
				'args'                => [
					'status' => [
						'type' => 'string',
						'enum' => [ 'active', 'suspended', 'archived' ],
					],
					'ids'    => [
						'type'        => 'string',
						'description' => __( 'Comma-separated organization ids to limit the export to a selection (at most 200).', 'monstera' ),
					],
				],
			]
		);
	}

	/**
	 * The Tools page's facts: each tool's last run and the row counts the
	 * export cards show.
	 *
	 * @return array{runs: array<string, array<string, mixed>>, counts: array<string, int>}
	 */
	public function status(): array {
		return [
			'runs'   => $this->runs(),
			'counts' => $this->counts(),
		];
	}

	/**
	 * Clears the "first email sent" flag on every content item, so the next
	 * publish of each sends a "new" notification again.
	 *
	 * @return array{reset: int, runs: array<string, array<string, mixed>>}
	 */
	public function resetFirstEmail(): array {
		$ids = $this->itemsWithFirstEmailSent();
		foreach ( $ids as $id ) {
			delete_post_meta( $id, ContentMeta::KEY_PUBLISHED_NOTIFIED );
		}
		$count = count( $ids );
		ToolRuns::record(
			'reset',
			'ok',
			/* translators: %d: number of content items whose flag was cleared */
			sprintf( _n( '%d item', '%d items', $count, 'monstera' ), $count )
		);
		return [
			'reset' => $count,
			'runs'  => $this->runs(),
		];
	}

	/**
	 * @return array<string, array{at: string, outcome: string, detail: string, by: string}>
	 */
	private function runs(): array {
		$out = [];
		// The option is written by ToolRuns alone, but it is stored data, so a
		// record from an earlier shape must not take the page down.
		/** @var array<string, mixed> $run */
		foreach ( ToolRuns::all() as $tool => $run ) {
			$user         = get_userdata( (int) ( $run['user_id'] ?? 0 ) );
			$out[ $tool ] = [
				'at'      => (string) ( $run['at'] ?? '' ),
				'outcome' => (string) ( $run['outcome'] ?? '' ),
				'detail'  => (string) ( $run['detail'] ?? '' ),
				'by'      => $user ? UserMeta::fullName( $user ) : '',
			];
		}
		return $out;
	}

	/**
	 * The export cards say "N rows", so each figure is its file's row count:
	 * for members, one per membership and one per standalone member, not one
	 * per account.
	 *
	 * @return array<string, int>
	 */
	private function counts(): array {
		return [
			'members'          => ( new MembersExporter() )->rowCount(),
			// The rows the export writes: every one on the site, in any status.
			'orgs'             => OrgRepository::countOnSite(),
			'activity'         => ActivityLog::eventsSince( 90 ),
			'first_email_sent' => count( $this->itemsWithFirstEmailSent() ),
		];
	}

	/**
	 * @return int[]
	 */
	private function itemsWithFirstEmailSent(): array {
		$ids = get_posts(
			[
				'post_type'      => ContentPostType::SLUG,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => ContentMeta::KEY_PUBLISHED_NOTIFIED, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- a maintenance count over one flag.
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
			]
		);
		return array_map( 'intval', (array) $ids );
	}

	public function exportMembers(): void {
		// Recorded first: streamCsv() ends the request with exit, so nothing after it runs.
		ToolRuns::record( 'export_members', 'ok' );
		( new MembersExporter() )->streamCsv();
	}

	public function exportActivity( WP_REST_Request $request ): void {
		// Recorded first: streamCsv() ends the request with exit, so nothing after it runs.
		ToolRuns::record( 'export_activity', 'ok' );
		( new ActivityLogExporter() )->streamCsv(
			[
				'since_days' => (int) $request->get_param( 'since_days' ),
				'event'      => (string) $request->get_param( 'event' ),
			]
		);
	}

	public function exportOrgs( WP_REST_Request $request ): void {
		// Recorded first: streamCsv() ends the request with exit, so nothing after it runs.
		ToolRuns::record( 'export_orgs', 'ok' );
		( new OrgListExporter() )->streamCsv(
			[
				'status' => (string) $request->get_param( 'status' ),
				'ids'    => (string) $request->get_param( 'ids' ),
			]
		);
	}
}
