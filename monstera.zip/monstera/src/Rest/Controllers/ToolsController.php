<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Capabilities;
use Monstera\Core\ToolRuns;
use Monstera\Members\UserMeta;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Reporting\ActivityLog;
use Monstera\Reporting\Exporters\ActivityLogExporter;
use Monstera\Reporting\Exporters\MembersExporter;
use Monstera\Reporting\Exporters\OrgListExporter;
use WP_REST_Request;

final class ToolsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/tools/status',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'status' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/reset-first-email',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'resetFirstEmail' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/export/members',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'exportMembers' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/export/activity',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'exportActivity' ],
				'args'                => [
					'since_days' => [
						'type'    => 'integer',
						'default' => 90,
						'minimum' => 1,
						'maximum' => 3650,
					],
					'event'      => [ 'type' => 'string' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/tools/export/orgs',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'exportOrgs' ],
				'args'                => [
					'status' => [
						'type' => 'string',
						'enum' => [ 'active', 'suspended', 'archived' ],
					],
					'ids'    => [
						'type'        => 'string',
						'description' => __( 'Comma-separated organization ids to limit the export to a selection (at most 200).', 'monstera' ),
					],
				],
			]
		);
	}

	/**
	 * The Tools page's facts: each tool's last run and the row counts the
	 * export cards show.
	 *
	 * @return array{runs: array<string, array<string, mixed>>, counts: array<string, int>}
	 */
	public function status(): array {
		return [
			'runs'   => $this->runs(),
			'counts' => $this->counts(),
		];
	}

	/**
	 * Clears the "first email sent" flag on every content item, so the next
	 * publish of each sends a "new" notification again.
	 *
	 * @return array{reset: int, runs: array<string, array<string, mixed>>}
	 */
	public function resetFirstEmail(): array {
		$ids = $this->itemsWithFirstEmailSent();
		foreach ( $ids as $id ) {
			delete_post_meta( $id, ContentMeta::KEY_PUBLISHED_NOTIFIED );
		}
		$count = count( $ids );
		ToolRuns::record(
			'reset',
			'ok',
			/* translators: %d: number of content items whose flag was cleared */
			sprintf( _n( '%d item', '%d items', $count, 'monstera' ), $count )
		);
		return [
			'reset' => $count,
			'runs'  => $this->runs(),
		];
	}

	/**
	 * @return array<string, array{at: string, outcome: string, detail: string, by: string}>
	 */
	private function runs(): array {
		$out = [];
		// The option is written by ToolRuns alone, but it is stored data, so a
		// record from an earlier shape must not take the page down.
		/** @var array<string, mixed> $run */
		foreach ( ToolRuns::all() as $tool => $run ) {
			$user         = get_userdata( (int) ( $run['user_id'] ?? 0 ) );
			$out[ $tool ] = [
				'at'      => (string) ( $run['at'] ?? '' ),
				'outcome' => (string) ( $run['outcome'] ?? '' ),
				'detail'  => (string) ( $run['detail'] ?? '' ),
				'by'      => $user ? UserMeta::fullName( $user ) : '',
			];
		}
		return $out;
	}

	/**
	 * @return array<string, int>
	 */
	private function counts(): array {
		$users   = count_users();
		$members = 0;
		foreach ( [ Capabilities::ROLE_ADMIN, Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ] as $role ) {
			$members += (int) ( $users['avail_roles'][ $role ] ?? 0 );
		}
		return [
			'members'          => $members,
			'orgs'             => (int) ( wp_count_posts( OrgPostType::SLUG )->publish ?? 0 ),
			'activity'         => ActivityLog::eventsSince( 90 ),
			'first_email_sent' => count( $this->itemsWithFirstEmailSent() ),
		];
	}

	/**
	 * @return int[]
	 */
	private function itemsWithFirstEmailSent(): array {
		$ids = get_posts(
			[
				'post_type'      => ContentPostType::SLUG,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => ContentMeta::KEY_PUBLISHED_NOTIFIED, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- a maintenance count over one flag.
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
			]
		);
		return array_map( 'intval', (array) $ids );
	}

	public function exportMembers(): void {
		// Recorded first: streamCsv() ends the request with exit, so nothing after it runs.
		ToolRuns::record( 'export_members', 'ok' );
		( new MembersExporter() )->streamCsv();
	}

	public function exportActivity( WP_REST_Request $request ): void {
		// Recorded first: streamCsv() ends the request with exit, so nothing after it runs.
		ToolRuns::record( 'export_activity', 'ok' );
		( new ActivityLogExporter() )->streamCsv(
			[
				'since_days' => (int) $request->get_param( 'since_days' ),
				'event'      => (string) $request->get_param( 'event' ),
			]
		);
	}

	public function exportOrgs( WP_REST_Request $request ): void {
		// Recorded first: streamCsv() ends the request with exit, so nothing after it runs.
		ToolRuns::record( 'export_orgs', 'ok' );
		( new OrgListExporter() )->streamCsv(
			[
				'status' => (string) $request->get_param( 'status' ),
				'ids'    => (string) $request->get_param( 'ids' ),
			]
		);
	}
}
