<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Organizations\Roster;
use Monstera\Rest\BulkRequest;
use Monstera\Rest\BulkResult;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

abstract class BaseController {

	use AuthorizesPortalActors;

	public function __construct( protected string $restNamespace ) {}

	abstract public function register(): void;

	protected function canManage(): bool {
		return current_user_can( Capabilities::CAP_MANAGE_MONSTERA );
	}

	/**
	 * "manage OR cap": admins (manage_monstera) always pass, otherwise the
	 * specific portal capability is required. Encoded once here because
	 * manage_monstera is the only cap mirrored onto the WP administrator role —
	 * a bare cap check would lock admins out of the surface.
	 */
	protected function userCan( string $cap ): bool {
		return $this->canManage() || current_user_can( $cap );
	}

	/**
	 * Whether the current user may act within a given organization: staff
	 * (manage_monstera) in any organization, anyone else only where they
	 * hold the admin or manager tier (People-model track, FR2). The WordPress
	 * role is a ceiling, never the answer here: a person may manage one
	 * organization and be a plain member of another, and the role says only
	 * that they manage somewhere, so the tier in THIS organization decides.
	 * A plain member of it, and a manager of another one, are refused. Backs
	 * the org self-service endpoints (invite / remove / edit-own-org / renew)
	 * and the sub-group routes. A caller this admits must then act on that
	 * same organization, never on scope()->orgId: asked about no
	 * organization, the scope settles on the first one the caller manages,
	 * which may be another.
	 */
	protected function actsWithinOwnOrg( int $orgId ): bool {
		if ( $this->canManage() ) {
			return true;
		}
		return in_array( Roster::roleOf( get_current_user_id(), $orgId ), [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true );
	}

	/** 401 when logged out so the client knows to authenticate; 403 otherwise. */
	protected function permissionManage(): callable {
		return function () {
			return $this->canManage()
				? true
				: new \WP_Error(
					'monstera_forbidden',
					__( 'You do not have permission.', 'monstera' ),
					[ 'status' => is_user_logged_in() ? 403 : 401 ]
				);
		};
	}

	/**
	 * Permission callback for what is a Team manager's and a WordPress
	 * administrator's alone (People-model track, FR2), by the capability
	 * that says so: monstera_manage_settings for the routes the Settings and
	 * Tools pages call, reads as well as writes, and monstera_manage_team
	 * for every write to the team. One gate for both, so the two cannot come
	 * to refuse differently. A Team member is on the team, so they are told
	 * who may in a sentence; anyone else reads what every other route says,
	 * since the team's own sentence is for the team. 401 when logged out.
	 *
	 * @param string $capability The capability only the team's managers hold.
	 * @param string $sentence   What a Team member reads: who may, in one sentence.
	 */
	protected function permissionManagers( string $capability, string $sentence ): callable {
		return function () use ( $capability, $sentence ) {
			if ( current_user_can( $capability ) ) {
				return true;
			}
			return new WP_Error(
				'monstera_forbidden',
				$this->canManage() ? $sentence : __( 'You do not have permission.', 'monstera' ),
				[ 'status' => is_user_logged_in() ? 403 : 401 ]
			);
		};
	}

	/**
	 * Permission callback for "manage OR cap". 401 when logged out so the
	 * client knows to authenticate; 403 when logged in but lacking the cap.
	 */
	protected function permissionCap( string $cap ): callable {
		return function () use ( $cap ) {
			// Authoring is within an organization. The role is only a ceiling:
			// someone made a manager by role who belongs to no organization yet
			// holds the capability with nowhere to author, and may not, or the
			// audience they are clamped to would be empty, which alerts and
			// forms once read as everyone. This is the coarse gate,
			// "an author somewhere": which organization a write is for, and the
			// caller's tier there, is the handler's to check (authoringScope()
			// for a create, requireOwned() for an item that exists).
			$allowed = $this->userCan( $cap )
				&& ( Capabilities::CAP_AUTHOR_PORTAL !== $cap || $this->scope()->canAuthor() );
			return $allowed
				? true
				: new \WP_Error(
					'monstera_forbidden',
					__( 'You do not have permission.', 'monstera' ),
					[ 'status' => is_user_logged_in() ? 403 : 401 ]
				);
		};
	}

	/**
	 * Register POST <base>/bulk for an admin list screen. The handler runs once per
	 * id with the validated request and the shared result; the route validates the
	 * action and id list, and always answers with per-id rows (see BulkResult).
	 *
	 * @param list<string>                                  $actions   Actions this list supports.
	 * @param callable(BulkRequest, int, BulkResult): void $handler   Applies one action to one id.
	 * @param callable(BulkRequest): ?WP_Error|null           $validate  Rejects the whole request (422) when its params are wrong for every id.
	 * @param callable(BulkRequest, BulkResult): string|null  $summarise Says in one sentence what the action did, once every id has been through; empty for an action with nothing to add to the counts.
	 */
	protected function registerBulkRoute( string $base, array $actions, callable $handler, ?callable $validate = null, ?callable $summarise = null ): void {
		register_rest_route(
			$this->restNamespace,
			$base . '/bulk',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => static function ( WP_REST_Request $request ) use ( $actions, $handler, $validate, $summarise ): array|WP_Error {
					$bulk = BulkRequest::fromRequest( $request, $actions );
					if ( $bulk instanceof WP_Error ) {
						return $bulk;
					}
					$invalid = $validate ? $validate( $bulk ) : null;
					if ( $invalid instanceof WP_Error ) {
						return $invalid;
					}
					$result = new BulkResult( $bulk->action );
					foreach ( $bulk->ids as $id ) {
						$handler( $bulk, $id, $result );
					}
					if ( $summarise ) {
						$result->summarise( $summarise( $bulk, $result ) );
					}
					return $result->toArray();
				},
				'args'                => [
					'action' => [
						'type'        => 'string',
						'description' => __( 'One of the actions this list supports.', 'monstera' ),
					],
					'ids'    => [
						'type'        => 'array',
						'description' => __( 'Distinct positive ids, at most 200.', 'monstera' ),
					],
					'params' => [
						'type'        => 'object',
						'description' => __( 'Action-specific parameters.', 'monstera' ),
					],
				],
			]
		);
	}

	/**
	 * The refusal for a client person whose organization's membership has
	 * ended (People-model track, FR5 as built): the sentence the blocked
	 * page heads every page of theirs with, so a route behind such a page
	 * answers in the page's words. The roster's routes answer it to the
	 * organization's own admins and managers for everything but a renewal,
	 * and the intake routes to a member of a project whose organization has
	 * ended. The team is never answered this way.
	 */
	protected static function membershipEnded( int $orgId ): WP_Error {
		return new WP_Error(
			'monstera_membership_ended',
			/* translators: %s: organization name */
			sprintf( __( 'The membership of %s has ended.', 'monstera' ), html_entity_decode( (string) get_the_title( $orgId ), ENT_QUOTES, 'UTF-8' ) ),
			[ 'status' => 403 ]
		);
	}

	/**
	 * The one answer for a field the request got wrong: 422, with the field
	 * named in the error data, so a detail page's save bar can say which
	 * field and link to it (and the field can show the message beside it).
	 *
	 * @param string $field   The request parameter, as the form names it.
	 * @param string $message One sentence: what is wrong and what to do.
	 */
	protected function invalidField( string $field, string $message ): WP_Error {
		return new WP_Error(
			'monstera_invalid_field',
			$message,
			[
				'status' => 422,
				'field'  => $field,
			]
		);
	}

	/**
	 * The tier a caller named, or the refusal on the field for anything that
	 * is not one of the three; a staff assignment is not a tier. One check
	 * for every route that takes a tier (an organization's roster, the
	 * team's memberships routes, the Members list's bulk action), so they
	 * cannot come to accept different words. The caller passes its own
	 * default for a request that names none: member for an invitation, and
	 * none for a tier change, which has to say.
	 */
	protected function tierAsked( mixed $asked ): string|WP_Error {
		if ( is_string( $asked ) && in_array( $asked, Roster::TIERS, true ) ) {
			return $asked;
		}
		return $this->invalidField( 'tier', __( 'Choose a tier: Member, Manager or Organization admin.', 'monstera' ) );
	}

	/**
	 * The email as it will be stored, or a 422 naming the field when it is
	 * not an address or another account has it. One check for every route
	 * that saves an account's address (a member's, one of the team's).
	 *
	 * @param int $selfId The account the address is for, whose own address is no conflict; 0 for one not made yet.
	 */
	protected function checkedEmail( string $raw, int $selfId ): string|WP_Error {
		$email = sanitize_email( $raw );
		if ( '' === $email || ! is_email( $email ) ) {
			return $this->invalidField( 'email', __( 'Enter an email address, like name@example.com.', 'monstera' ) );
		}
		$owner = email_exists( $email );
		if ( $owner && (int) $owner !== $selfId ) {
			return $this->invalidField( 'email', __( 'Another account already uses that email.', 'monstera' ) );
		}
		return $email;
	}

	/**
	 * Why the caller may not change how an account signs in, or null when
	 * they may: its email address, and the set-password link a welcome
	 * email carries to it. An account can hold a role of the site's beside
	 * its Monstera one, the site's editor who is also a member or one of the
	 * team (Provisioning::worksInAdminBesideMonstera()), and its address is
	 * the way into everything that role can do: changed, and a link sent to
	 * it or asked for at the sign-in screen, the account is whoever changed
	 * it. That is more than manage_monstera gives either team role, so it is
	 * left to edit_users, a WordPress administrator, who could do as much in
	 * WordPress's Users screen. Anyone changes their own address. The name,
	 * the photo and the profile fields are not asked about: they open
	 * nothing.
	 *
	 * One rule for every route by which the team writes an address or sends
	 * the link on its own word (a member's save, a teammate's, the welcome
	 * sent again from the Members list to one person or to a selection), so
	 * none of them is the door the others closed. An organization's roster
	 * sends the welcome too, when its Resend sends an invitation again and
	 * when its invite reaches an address whose account has never signed in
	 * (Provisioning::attachMember()), and is not asked for either: it
	 * reaches only someone who has never signed in, at the address already
	 * on file, which nobody it lets in can change.
	 *
	 * @param string|null $field The request parameter the refusal names, for a save; none for a send.
	 */
	protected function signInRefusal( WP_User $target, ?string $field = null ): ?WP_Error {
		if ( current_user_can( 'edit_users' )
			|| get_current_user_id() === (int) $target->ID
			|| ! Provisioning::worksInAdminBesideMonstera( $target )
		) {
			return null;
		}
		$data = [ 'status' => 403 ];
		if ( null !== $field ) {
			$data['field'] = $field;
		}
		return new WP_Error(
			'monstera_forbidden',
			__( 'This account also holds a WordPress role that lets it edit the site. Only a WordPress administrator can change its email address or resend its welcome.', 'monstera' ),
			$data
		);
	}

	/**
	 * Why the caller may not write to the account of someone on the team, or
	 * null when they may. The Members routes gate on manage_monstera, which
	 * both team roles hold, and the team itself is its managers'
	 * (People-model track, FR2): a Team member who could change a Team
	 * manager's address and have the set-password link sent to it would hold
	 * that account. So an account on the team is a Team manager's to write
	 * to there (monstera_manage_team, which a WordPress administrator holds
	 * too), and otherwise only its own: anyone edits their own record, and
	 * changes no role by it. A client's account is not asked about. The bulk
	 * resend skips whoever this refuses, so it reaches nobody the single
	 * route would not.
	 */
	protected static function teammateRefusal( WP_User $target ): ?WP_Error {
		if ( ! Capabilities::isStaff( $target )
			|| current_user_can( Capabilities::CAP_MANAGE_TEAM )
			|| get_current_user_id() === (int) $target->ID
		) {
			return null;
		}
		return new WP_Error( 'monstera_forbidden', __( 'Only a Team manager can change the account of someone on the team.', 'monstera' ), [ 'status' => 403 ] );
	}

	/**
	 * Why the caller may not have an account's welcome sent again, or null
	 * when they may: a teammate's is a Team manager's to send
	 * (teammateRefusal()), and the link it carries is a way into the account
	 * (signInRefusal()). The one answer for the Members routes that send it,
	 * to one person and to a selection, and for the two details that offer
	 * the button (the member's and the staff's, which both send through the
	 * Members route), so neither offers what the route would refuse.
	 */
	protected function resendRefusal( WP_User $target ): ?WP_Error {
		return self::teammateRefusal( $target ) ?? $this->signInRefusal( $target );
	}

	/**
	 * What a detail tells its reader they may do, from the refusals its
	 * write routes would answer: each action as a plain yes or no (`can`),
	 * and, for a no, the route's own sentence (`why_not`), which the screen
	 * shows where the control would be. Built from the routes' checks so a
	 * screen never has a second copy of a rule to keep in step.
	 *
	 * `why_not` is an object, not an array: with nothing refused an array
	 * would be sent as an empty list, and the field would be a list in one
	 * answer and a map in the next.
	 *
	 * @param array<string, WP_Error|null> $refusals What each action's route would refuse with; null where it would not.
	 * @return array{can: array<string, bool>, why_not: object}
	 */
	protected static function permissions( array $refusals ): array {
		$can   = [];
		$whyNo = [];
		foreach ( $refusals as $action => $refusal ) {
			$can[ $action ] = null === $refusal;
			if ( null !== $refusal ) {
				$whyNo[ $action ] = $refusal->get_error_message();
			}
		}
		return [
			'can'     => $can,
			'why_not' => (object) $whyNo,
		];
	}

	/**
	 * The profile photo a save names: an image in the media library, none
	 * (0) to take the photo off, or null when the request names no photo.
	 * Anything else, a file that is not an image, a post that is not a file
	 * or an id of nothing, is a 422 on the field. One check for every admin
	 * route that saves an account's photo (a member's, one of the team's),
	 * so neither stores what the portal would then fail to draw; the portal
	 * profile keeps its own, stricter one, which also asks whose upload it
	 * is. Asked before the first write, so a refused save changes nothing.
	 */
	protected function checkedPhoto( WP_REST_Request $request ): int|WP_Error|null {
		if ( ! $request->has_param( 'profile_photo' ) ) {
			return null;
		}
		$photo = absint( $request['profile_photo'] );
		if ( $photo && ! wp_attachment_is_image( $photo ) ) {
			return $this->invalidField( 'profile_photo', __( 'Choose an image from the media library.', 'monstera' ) );
		}
		return $photo;
	}

	/**
	 * Whether the id is an organization people can be put in or assigned
	 * to: one that exists and is published. The routes that name an
	 * organization for a person (a membership, an assignment) ask here.
	 */
	protected function isPublishedOrg( int $orgId ): bool {
		$org = get_post( $orgId );
		return $org instanceof WP_Post
			&& OrgPostType::SLUG === $org->post_type
			&& 'publish' === $org->post_status;
	}

	/** Note who saved a record, as WordPress's own editor does. */
	protected function stampEditor( int $postId ): void {
		update_post_meta( $postId, '_edit_last', get_current_user_id() );
	}

	/**
	 * When a record was last saved and by whom, for the save bar's "Last
	 * saved <date> by <name>" line.
	 *
	 * @return array{at: string, by: string}
	 */
	protected function savedStamp( int $postId ): array {
		$editor = get_userdata( (int) get_post_meta( $postId, '_edit_last', true ) );
		return [
			'at' => (string) get_post_modified_time( 'c', true, $postId ),
			'by' => $editor ? UserMeta::fullName( $editor ) : '',
		];
	}

	/**
	 * Note when an account was saved from the admin and by whom. WordPress
	 * keeps no such note for a user as it does for a post, so it is a meta
	 * key of Monstera's own.
	 */
	protected function stampAccountSaved( int $userId ): void {
		update_user_meta(
			$userId,
			UserMeta::KEY_SAVED,
			[
				'at' => gmdate( 'c' ),
				'by' => get_current_user_id(),
			]
		);
	}

	/**
	 * When an account was last saved from the admin and by whom, for the
	 * save bar of the member detail and of the staff detail. Both empty for
	 * one never saved there.
	 *
	 * @return array{at: string, by: string}
	 */
	protected function accountSavedStamp( int $userId ): array {
		$saved  = get_user_meta( $userId, UserMeta::KEY_SAVED, true );
		$editor = is_array( $saved ) ? get_userdata( (int) ( $saved['by'] ?? 0 ) ) : false;
		return [
			'at' => is_array( $saved ) ? (string) ( $saved['at'] ?? '' ) : '',
			'by' => $editor ? UserMeta::fullName( $editor ) : '',
		];
	}

	/**
	 * A fact that a module feeds: its count while the module is on, null
	 * while it is off (what it would have counted is unknown, not zero, and
	 * the page leaves the fact out).
	 *
	 * @param callable(): int $count
	 */
	protected function factOf( string $module, callable $count ): ?int {
		return \Monstera\Core\Modules::isActive( $module ) ? $count() : null;
	}

	/**
	 * A switch as a request sends it. JSON sends true or false; a form sends
	 * words, and "false" cast to a boolean is true.
	 */
	protected static function flag( mixed $value ): bool {
		return is_bool( $value ) ? $value : rest_sanitize_boolean( (string) ( is_scalar( $value ) ? $value : '' ) );
	}

	/**
	 * Whether the caller has used an action more than $limit times in the
	 * last $seconds, counting this use. For the routes that send email on a
	 * member's or a manager's word.
	 */
	protected function overLimit( string $action, int $limit, int $seconds ): bool {
		$key  = 'monstera_rate_' . md5( $action . '|' . get_current_user_id() );
		$used = (int) get_transient( $key );
		if ( $used >= $limit ) {
			return true;
		}
		set_transient( $key, $used + 1, $seconds );
		return false;
	}

	/** The answer to a caller who is over a limit. */
	protected function tooMany( string $message ): WP_Error {
		return new WP_Error( 'monstera_too_many', $message, [ 'status' => 429 ] );
	}

	protected function permissionLoggedIn(): callable {
		return function () {
			return is_user_logged_in()
				? true
				: new \WP_Error( 'monstera_forbidden', __( 'Sign in required.', 'monstera' ), [ 'status' => 401 ] );
		};
	}
}
