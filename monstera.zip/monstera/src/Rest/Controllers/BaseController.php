<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Rest\BulkRequest;
use Monstera\Rest\BulkResult;
use WP_Error;
use WP_REST_Request;

abstract class BaseController {

	use AuthorizesPortalActors;

	public function __construct( protected string $restNamespace ) {}

	abstract public function register(): void;

	protected function canManage(): bool {
		return current_user_can( Capabilities::CAP_MANAGE_MONSTERA );
	}

	/**
	 * "manage OR cap": admins (manage_monstera) always pass, otherwise the
	 * specific portal capability is required. Encoded once here because
	 * manage_monstera is the only cap mirrored onto the WP administrator role —
	 * a bare cap check would lock admins out of the surface.
	 */
	protected function userCan( string $cap ): bool {
		return $this->canManage() || current_user_can( $cap );
	}

	/**
	 * Whether the current user may act within a given organization: admins on
	 * any org, otherwise only on the org they belong to. Backs the org
	 * self-service endpoints (invite / remove / edit-own-org / renew).
	 */
	protected function actsWithinOwnOrg( int $orgId ): bool {
		if ( $this->canManage() ) {
			return true;
		}
		$own = UserMeta::associatedOrg( get_current_user_id() );
		return $own > 0 && $own === $orgId;
	}

	/** 401 when logged out so the client knows to authenticate; 403 otherwise. */
	protected function permissionManage(): callable {
		return function () {
			return $this->canManage()
				? true
				: new \WP_Error(
					'monstera_forbidden',
					__( 'You do not have permission.', 'monstera' ),
					[ 'status' => is_user_logged_in() ? 403 : 401 ]
				);
		};
	}

	/**
	 * Permission callback for "manage OR cap". 401 when logged out so the
	 * client knows to authenticate; 403 when logged in but lacking the cap.
	 */
	protected function permissionCap( string $cap ): callable {
		return function () use ( $cap ) {
			// Authoring is within an organization. Someone taken out of theirs
			// keeps the role, and a leadership can outlive a move; neither may
			// author, or the audience they are clamped to would be empty, which
			// alerts and forms once read as everyone.
			$allowed = $this->userCan( $cap )
				&& ( Capabilities::CAP_AUTHOR_PORTAL !== $cap || $this->scope()->canAuthor() );
			return $allowed
				? true
				: new \WP_Error(
					'monstera_forbidden',
					__( 'You do not have permission.', 'monstera' ),
					[ 'status' => is_user_logged_in() ? 403 : 401 ]
				);
		};
	}

	/**
	 * Register POST <base>/bulk for an admin list screen. The handler runs once per
	 * id with the validated request and the shared result; the route validates the
	 * action and id list, and always answers with per-id rows (see BulkResult).
	 *
	 * @param list<string>                                  $actions  Actions this list supports.
	 * @param callable(BulkRequest, int, BulkResult): void $handler  Applies one action to one id.
	 * @param callable(BulkRequest): ?WP_Error|null           $validate Rejects the whole request (422) when its params are wrong for every id.
	 */
	protected function registerBulkRoute( string $base, array $actions, callable $handler, ?callable $validate = null ): void {
		register_rest_route(
			$this->restNamespace,
			$base . '/bulk',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => static function ( WP_REST_Request $request ) use ( $actions, $handler, $validate ): array|WP_Error {
					$bulk = BulkRequest::fromRequest( $request, $actions );
					if ( $bulk instanceof WP_Error ) {
						return $bulk;
					}
					$invalid = $validate ? $validate( $bulk ) : null;
					if ( $invalid instanceof WP_Error ) {
						return $invalid;
					}
					$result = new BulkResult( $bulk->action );
					foreach ( $bulk->ids as $id ) {
						$handler( $bulk, $id, $result );
					}
					return $result->toArray();
				},
				'args'                => [
					'action' => [
						'type'        => 'string',
						'description' => __( 'One of the actions this list supports.', 'monstera' ),
					],
					'ids'    => [
						'type'        => 'array',
						'description' => __( 'Distinct positive ids, at most 200.', 'monstera' ),
					],
					'params' => [
						'type'        => 'object',
						'description' => __( 'Action-specific parameters.', 'monstera' ),
					],
				],
			]
		);
	}

	/**
	 * The one answer for a field the request got wrong: 422, with the field
	 * named in the error data, so a detail page's save bar can say which
	 * field and link to it (and the field can show the message beside it).
	 *
	 * @param string $field   The request parameter, as the form names it.
	 * @param string $message One sentence: what is wrong and what to do.
	 */
	protected function invalidField( string $field, string $message ): WP_Error {
		return new WP_Error(
			'monstera_invalid_field',
			$message,
			[
				'status' => 422,
				'field'  => $field,
			]
		);
	}

	/** Note who saved a record, as WordPress's own editor does. */
	protected function stampEditor( int $postId ): void {
		update_post_meta( $postId, '_edit_last', get_current_user_id() );
	}

	/**
	 * When a record was last saved and by whom, for the save bar's "Last
	 * saved <date> by <name>" line.
	 *
	 * @return array{at: string, by: string}
	 */
	protected function savedStamp( int $postId ): array {
		$editor = get_userdata( (int) get_post_meta( $postId, '_edit_last', true ) );
		return [
			'at' => (string) get_post_modified_time( 'c', true, $postId ),
			'by' => $editor ? UserMeta::fullName( $editor ) : '',
		];
	}

	/**
	 * A fact that a module feeds: its count while the module is on, null
	 * while it is off (what it would have counted is unknown, not zero, and
	 * the page leaves the fact out).
	 *
	 * @param callable(): int $count
	 */
	protected function factOf( string $module, callable $count ): ?int {
		return \Monstera\Core\Modules::isActive( $module ) ? $count() : null;
	}

	/**
	 * A switch as a request sends it. JSON sends true or false; a form sends
	 * words, and "false" cast to a boolean is true.
	 */
	protected static function flag( mixed $value ): bool {
		return is_bool( $value ) ? $value : rest_sanitize_boolean( (string) ( is_scalar( $value ) ? $value : '' ) );
	}

	/**
	 * Whether the caller has used an action more than $limit times in the
	 * last $seconds, counting this use. For the routes that send email on a
	 * member's or a manager's word.
	 */
	protected function overLimit( string $action, int $limit, int $seconds ): bool {
		$key  = 'monstera_rate_' . md5( $action . '|' . get_current_user_id() );
		$used = (int) get_transient( $key );
		if ( $used >= $limit ) {
			return true;
		}
		set_transient( $key, $used + 1, $seconds );
		return false;
	}

	/** The answer to a caller who is over a limit. */
	protected function tooMany( string $message ): WP_Error {
		return new WP_Error( 'monstera_too_many', $message, [ 'status' => 429 ] );
	}

	protected function permissionLoggedIn(): callable {
		return function () {
			return is_user_logged_in()
				? true
				: new \WP_Error( 'monstera_forbidden', __( 'Sign in required.', 'monstera' ), [ 'status' => 401 ] );
		};
	}
}
