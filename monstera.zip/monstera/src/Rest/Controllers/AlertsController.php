<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use DateTimeImmutable;
use DateTimeZone;
use Monstera\Alerts\Expiry;
use Monstera\Alerts\Meta;
use Monstera\Alerts\PostType;
use Monstera\Alerts\Repository;
use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Reporting\ActivityLog;
use WP_Error;
use WP_Query;
use WP_REST_Request;

final class AlertsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/alerts',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/alerts/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/alerts/reach',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
				'callback'            => [ $this, 'reach' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/alerts/(?P<id>\d+)/end',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
				'callback'            => [ $this, 'end' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/alerts/mine',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'mine' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/alerts/(?P<id>\d+)/dismiss',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'dismiss' ],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index(): array {
		$q   = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft' ],
					'posts_per_page' => 100,
					'orderby'        => 'date',
					'order'          => 'DESC',
				],
				$this->ownAuthorQueryArgs()
			)
		);
		$out = [];
		foreach ( $q->posts as $post ) {
			$out[] = $this->summarize( $post );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Alert not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'An alert needs a title.', 'monstera' ) );
		}
		$posting = 'publish' === sanitize_key( (string) ( $request['status'] ?? 'draft' ) );
		$refusal = $this->refusal( 0, $request, $posting, $posting );
		if ( $refusal ) {
			return $refusal;
		}

		// Inserted as a draft and posted once its audience is saved: posting
		// sends the email, which reads the audience.
		$id = wp_insert_post(
			[
				'post_type'    => PostType::SLUG,
				'post_title'   => $title,
				'post_status'  => 'draft',
				'post_content' => wp_kses_post( (string) ( $request['body'] ?? '' ) ),
				'post_author'  => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$this->applyMutations( (int) $id, $request );
		if ( $posting ) {
			wp_update_post(
				[
					'ID'          => (int) $id,
					'post_status' => 'publish',
				]
			);
		}
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Alert not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'An alert needs a title.', 'monstera' ) );
			}
		}
		if ( $request->has_param( 'body' ) ) {
			$core['post_content'] = wp_kses_post( (string) $request['body'] );
		}
		if ( $request->has_param( 'status' ) ) {
			$status = sanitize_key( (string) $request['status'] );
			if ( in_array( $status, [ 'publish', 'draft' ], true ) ) {
				$core['post_status'] = $status;
			}
		}
		$live    = 'publish' === ( $core['post_status'] ?? $post->post_status );
		$refusal = $this->refusal( $id, $request, $live, $live && 'publish' !== $post->post_status );
		if ( $refusal ) {
			return $refusal;
		}
		// The audience and the email switch are saved before the status, so
		// posting from here emails the audience as saved.
		$this->applyMutations( $id, $request );
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}
		return $this->shape( $id );
	}

	/**
	 * Why a save cannot go through, checked before anything is written: an
	 * expiry that is not a date and time, a live alert with nobody to reach,
	 * or one posted with an expiry already behind it.
	 *
	 * @param int  $id      The alert, or 0 for a new one.
	 * @param bool $live    Whether the save leaves the alert live.
	 * @param bool $posting Whether the save is what posts it.
	 */
	private function refusal( int $id, WP_REST_Request $request, bool $live, bool $posting ): ?WP_Error {
		$typed  = $request->has_param( 'expires_at' ) ? trim( sanitize_text_field( (string) $request['expires_at'] ) ) : null;
		$expiry = null === $typed ? (string) ( $id ? get_post_meta( $id, Meta::KEY_EXPIRES_AT, true ) : '' ) : Expiry::fromInput( $typed );
		if ( null !== $typed && '' !== $typed && '' === $expiry ) {
			return $this->invalidField( 'expires_at', __( 'Enter the expiry as a date and a time, or leave it empty.', 'monstera' ) );
		}
		if ( $live && ( $posting || null !== $typed ) && Expiry::hasPassed( $expiry ) ) {
			return $this->invalidField( 'expires_at', __( 'That time has passed. Choose a later one, or clear it so the alert stays up until you dismiss it.', 'monstera' ) );
		}
		if ( $live && Repository::isEmpty( $this->audienceAfter( $id, $request ) ) ) {
			return $this->invalidField( 'audience', __( 'Choose who sees this alert, or send it to every organization.', 'monstera' ) );
		}
		return null;
	}

	/**
	 * The audience a save would leave: what the request names, over what is
	 * stored. A delegated author's is always their own organization.
	 *
	 * @return array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]}
	 */
	private function audienceAfter( int $id, WP_REST_Request $request ): array {
		$scope = $this->scope();
		if ( ! $scope->isAdmin ) {
			return [
				'all'          => false,
				'org_ids'      => $scope->clampOrgIds( [] ),
				'member_ids'   => [],
				'subgroup_ids' => [],
			];
		}
		$stored = $id
			? Repository::audienceOf( $id )
			: [
				// The registered default: an alert made with no audience keys is for everyone.
				'all'          => true,
				'org_ids'      => [],
				'member_ids'   => [],
				'subgroup_ids' => [],
			];
		$list   = static fn ( string $param, array $kept ): array => $request->has_param( $param )
			? array_values( array_filter( array_map( 'absint', (array) $request[ $param ] ) ) )
			: $kept;
		return [
			'all'          => $request->has_param( 'audience_all' ) ? self::flag( $request['audience_all'] ) : $stored['all'],
			'org_ids'      => $list( 'org_ids', $stored['org_ids'] ),
			'member_ids'   => $list( 'standalone_member_ids', $stored['member_ids'] ),
			'subgroup_ids' => $list( 'subgroup_ids', $stored['subgroup_ids'] ),
		];
	}

	private function applyMutations( int $id, WP_REST_Request $request ): void {
		if ( $request->has_param( 'severity' ) ) {
			$sev = (string) $request['severity'];
			if ( in_array( $sev, [ Meta::SEVERITY_INFO, Meta::SEVERITY_WARNING, Meta::SEVERITY_CRITICAL ], true ) ) {
				update_post_meta( $id, Meta::KEY_SEVERITY, $sev );
			}
		}
		$this->applyAudience( $id, $request );
		if ( $request->has_param( 'expires_at' ) ) {
			update_post_meta( $id, Meta::KEY_EXPIRES_AT, Expiry::fromInput( sanitize_text_field( (string) $request['expires_at'] ) ) );
		}
		if ( $request->has_param( 'link_url' ) ) {
			update_post_meta( $id, Meta::KEY_LINK_URL, esc_url_raw( (string) $request['link_url'] ) );
		}
		if ( $request->has_param( 'link_label' ) ) {
			update_post_meta( $id, Meta::KEY_LINK_LABEL, sanitize_text_field( (string) $request['link_label'] ) );
		}
		if ( $request->has_param( 'dismissible' ) ) {
			update_post_meta( $id, Meta::KEY_DISMISSIBLE, self::flag( $request['dismissible'] ) );
		}
		if ( $request->has_param( 'notify_by_email' ) ) {
			update_post_meta( $id, Meta::KEY_NOTIFY_BY_EMAIL, self::flag( $request['notify_by_email'] ) );
		}
	}

	/**
	 * Alerts carry an explicit "everyone" flag plus org / standalone / sub-group
	 * lists. Admins broadcast freely; delegated authors are pinned to their own
	 * org (no "everyone", no standalone targeting) with sub-group gating clamped —
	 * a leader's alert always lands on their one sub-group.
	 */
	private function applyAudience( int $id, WP_REST_Request $request ): void {
		$scope = $this->scope();

		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'audience_all' ) ) {
				update_post_meta( $id, Meta::KEY_AUDIENCE_ALL, self::flag( $request['audience_all'] ) );
			}
			if ( $request->has_param( 'org_ids' ) ) {
				update_post_meta( $id, Meta::KEY_ORG_IDS, array_values( array_map( 'absint', (array) $request['org_ids'] ) ) );
			}
			if ( $request->has_param( 'standalone_member_ids' ) ) {
				update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, array_values( array_map( 'absint', (array) $request['standalone_member_ids'] ) ) );
			}
			if ( $request->has_param( 'subgroup_ids' ) ) {
				$proposed = array_map( 'absint', (array) $request['subgroup_ids'] );
				$orgIds   = array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_ORG_IDS, true ) );
				$memIds   = array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, true ) );
				$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgIds, $memIds );
				update_post_meta( $id, Meta::KEY_SUBGROUP_IDS, array_values( $valid ) );
			}
			return;
		}

		$orgIds = $scope->clampOrgIds( [] );
		update_post_meta( $id, Meta::KEY_AUDIENCE_ALL, false );
		update_post_meta( $id, Meta::KEY_ORG_IDS, $orgIds );
		update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, [] );

		if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
			$proposed = $scope->clampSubgroupIds( (array) ( $request['subgroup_ids'] ?? [] ) );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgIds, [] );
			update_post_meta( $id, Meta::KEY_SUBGROUP_IDS, array_values( $valid ) );
		}
	}

	/**
	 * How far an audience would reach, for the composer's save bar. The
	 * audience is clamped the way a save would clamp it, so a delegated
	 * author sees their own organization's numbers.
	 *
	 * @return array{organizations: int, members: int}
	 */
	public function reach( WP_REST_Request $request ): array {
		$scope     = $this->scope();
		$subgroups = wp_parse_id_list( $request['subgroup_ids'] ?? [] );

		if ( $scope->isAdmin ) {
			$orgIds  = wp_parse_id_list( $request['org_ids'] ?? [] );
			$members = wp_parse_id_list( $request['standalone_member_ids'] ?? [] );
			$all     = self::flag( $request['audience_all'] ?? false );
		} else {
			$orgIds    = $scope->clampOrgIds( [] );
			$members   = [];
			$all       = false;
			$subgroups = $scope->isLeader() || $subgroups ? $scope->clampSubgroupIds( $subgroups ) : [];
		}

		return ( new Repository() )->reach(
			[
				'all'          => (bool) $all,
				'org_ids'      => $orgIds,
				'member_ids'   => $members,
				'subgroup_ids' => array_values( ContentController::filterSubgroupsByAudience( $subgroups, $orgIds, $members ) ),
			]
		);
	}

	/**
	 * Ends a live alert for everyone at once and posts one note to activity
	 * ("Resolved" in each member's feed). No email.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function end( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Alert not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		if ( 'publish' !== $post->post_status ) {
			return new WP_Error( 'monstera_alert_not_live', __( 'This alert is not live.', 'monstera' ), [ 'status' => 409 ] );
		}

		wp_update_post(
			[
				'ID'          => $id,
				'post_status' => 'draft',
			]
		);
		update_post_meta( $id, Meta::KEY_ENDED_AT, current_time( 'mysql', true ) );
		ActivityLog::record( 'alert_ended', 'alert', $id );
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Alert not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function mine(): array {
		$user = wp_get_current_user();
		$repo = new Repository();
		$out  = [];
		foreach ( $repo->visibleTo( $user ) as $post ) {
			$out[] = $this->banner( $post );
		}
		return [ 'items' => $out ];
	}

	/**
	 * Only an alert the member has in front of them, and may dismiss, can be
	 * dismissed: the route takes any id.
	 *
	 * @return array{ok: bool}|WP_Error
	 */
	public function dismiss( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$repo = new Repository();
		$seen = array_map( static fn ( \WP_Post $post ): int => $post->ID, $repo->visibleTo( wp_get_current_user() ) );
		if ( ! in_array( $id, $seen, true ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Alert not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! (bool) get_post_meta( $id, Meta::KEY_DISMISSIBLE, true ) ) {
			return new WP_Error( 'monstera_forbidden', __( 'This alert stays until it ends.', 'monstera' ), [ 'status' => 403 ] );
		}
		$repo->dismiss( $id, get_current_user_id() );
		return [ 'ok' => true ];
	}

	/**
	 * An alert as the member it reached may know it: the banner, and nothing
	 * about who else it went to, who posted it or how many emails went out.
	 *
	 * @return array<string, mixed>
	 */
	private function banner( \WP_Post $post ): array {
		return [
			'id'          => $post->ID,
			'title'       => get_the_title( $post ),
			'body'        => wpautop( wp_kses_post( $post->post_content ) ),
			'severity'    => (string) ( get_post_meta( $post->ID, Meta::KEY_SEVERITY, true ) ?: Meta::SEVERITY_INFO ),
			'link_url'    => (string) get_post_meta( $post->ID, Meta::KEY_LINK_URL, true ),
			'link_label'  => (string) get_post_meta( $post->ID, Meta::KEY_LINK_LABEL, true ),
			'expires_at'  => Expiry::forInput( (string) get_post_meta( $post->ID, Meta::KEY_EXPIRES_AT, true ) ),
			'dismissible' => (bool) get_post_meta( $post->ID, Meta::KEY_DISMISSIBLE, true ),
			'posted_at'   => get_post_time( 'c', true, $post ),
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function summarize( \WP_Post $post ): array {
		$audienceAll = Repository::audienceOf( $post->ID )['all'];
		$orgIds      = self::ids( get_post_meta( $post->ID, Meta::KEY_ORG_IDS, true ) );
		$memIds      = self::ids( get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBER_IDS, true ) );
		$sgIds       = self::ids( get_post_meta( $post->ID, Meta::KEY_SUBGROUP_IDS, true ) );
		$scopeNames  = array_values(
			array_filter(
				array_merge(
					array_map( 'get_the_title', $orgIds ),
					array_map( 'get_the_title', $sgIds )
				)
			)
		);
		if ( ! $scopeNames && $memIds ) {
			/* translators: %d: number of standalone members the alert targets */
			$scopeNames[] = sprintf( _n( '%d member', '%d members', count( $memIds ), 'monstera' ), count( $memIds ) );
		}
		$scope = 'targeted';
		if ( $audienceAll ) {
			$scope = 'all';
		} elseif ( ! $orgIds && ! $memIds && ! $sgIds ) {
			$scope = 'none';
		}
		$scopeLabel = implode( ', ', $scopeNames );
		if ( 'all' === $scope ) {
			$scopeLabel = (string) __( 'Everyone', 'monstera' );
		} elseif ( 'none' === $scope ) {
			$scopeLabel = (string) __( 'Nobody yet', 'monstera' );
		}
		$expires  = (string) get_post_meta( $post->ID, Meta::KEY_EXPIRES_AT, true );
		$postedAt = (string) get_post_meta( $post->ID, Meta::KEY_POSTED_AT, true );
		$postedBy = get_userdata( (int) get_post_meta( $post->ID, Meta::KEY_POSTED_BY, true ) ?: (int) $post->post_author );
		$sent     = get_post_meta( $post->ID, Meta::KEY_EMAIL_SENT, true );
		return [
			'id'                    => $post->ID,
			'title'                 => get_the_title( $post ),
			// Alerts are short admin-authored notices, already wp_kses_post'd on
			// save. Render with wpautop only — deliberately NOT the_content, to
			// avoid executing shortcodes/embeds in member-facing output.
			'body'                  => wpautop( wp_kses_post( $post->post_content ) ),
			// The list's sub-line and scope cell.
			'excerpt'               => wp_trim_words( wp_strip_all_tags( $post->post_content ), 18 ),
			'scope_label'           => $scopeLabel,
			'modified'              => get_post_modified_time( 'c', true, $post ),
			'severity'              => (string) ( get_post_meta( $post->ID, Meta::KEY_SEVERITY, true ) ?: Meta::SEVERITY_INFO ),
			// Sub-groups on their own are an audience too: Alerts\Repository shows
			// such an alert to that sub-group and nobody else. "Everyone" turned
			// off with nothing chosen is nobody.
			'scope'                 => $scope,
			'audience_all'          => $audienceAll,
			'org_ids'               => $orgIds,
			'standalone_member_ids' => $memIds,
			'subgroup_ids'          => $sgIds,
			'link_url'              => (string) get_post_meta( $post->ID, Meta::KEY_LINK_URL, true ),
			'link_label'            => (string) get_post_meta( $post->ID, Meta::KEY_LINK_LABEL, true ),
			// The site's local time, for the date field; `expired` compares it.
			'expires_at'            => Expiry::forInput( $expires ),
			'expired'               => Expiry::hasPassed( $expires ),
			'dismissible'           => (bool) get_post_meta( $post->ID, Meta::KEY_DISMISSIBLE, true ),
			// Posted at least once; alerts from before the stamp count when live.
			'posted'                => '' !== $postedAt || 'publish' === $post->post_status,
			'posted_at'             => $postedAt ? self::utcIso( $postedAt ) : get_post_time( 'c', true, $post ),
			'posted_by_name'        => $postedBy ? UserMeta::fullName( $postedBy ) : '',
			// How many emails the first post sent; null when it sent none.
			'email_sent'            => '' === $sent || false === $sent ? null : (int) $sent,
			'ended_at'              => self::utcIso( (string) get_post_meta( $post->ID, Meta::KEY_ENDED_AT, true ) ),
			'status'                => $post->post_status,
			'edit_url'              => admin_url( 'admin.php?page=monstera-alerts&id=' . $post->ID ),
		];
	}

	/** A UTC 'Y-m-d H:i:s' as ISO 8601, or '' when there is none. */
	private static function utcIso( string $utc ): string {
		if ( '' === $utc ) {
			return '';
		}
		try {
			return ( new DateTimeImmutable( $utc, new DateTimeZone( 'UTC' ) ) )->format( 'c' );
		} catch ( \Exception ) {
			return '';
		}
	}

	/**
	 * An audience list as stored. A list that was never written reads back as
	 * '', and its sanitizer turns '' into [0]; either would otherwise count as
	 * one member with id 0.
	 *
	 * @return int[]
	 */
	private static function ids( mixed $meta ): array {
		return array_values( array_filter( array_map( 'intval', (array) $meta ) ) );
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		$post = get_post( $id );
		return array_merge(
			$this->summarize( $post ),
			[
				// As stored: the composer saves it back (the list's is texturized).
				'title'           => (string) get_post_field( 'post_title', $id, 'raw' ),
				'body_raw'        => (string) $post->post_content,
				'notify_by_email' => (bool) get_post_meta( $id, Meta::KEY_NOTIFY_BY_EMAIL, true ),
			]
		);
	}
}
