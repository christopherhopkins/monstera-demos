<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Content\Meta;
use Monstera\Content\PostType;
use Monstera\Content\Readers;
use Monstera\Content\SecureFiles;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Notifications\TemplateEngine;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\AudienceShown;
use Monstera\Portal\AuthorScope;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Error;
use WP_Query;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class ContentController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/content-items',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
					'args'                => [
						// The list narrowed to one project's items (the
						// Project column's filter, At-a-glance track); 0 is none.
						'project_id' => [
							'type'    => 'integer',
							'default' => 0,
							'minimum' => 0,
						],
					],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/content-items/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/content-items/(?P<id>\d+)/visibility',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'visibilityCheck' ],
				'args'                => [
					'user_id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/content-items/(?P<id>\d+)/readers',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'readers' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/content-items/(?P<id>\d+)/file',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'uploadFile' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/content-items/(?P<id>\d+)/resend',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'resendNotification' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}|WP_Error
	 */
	public function index( WP_REST_Request $request ): array|WP_Error {
		// Delegated authors only ever list what they authored, for the
		// organization the request names when it names one; admins see all.
		$own = $this->ownAuthorQueryArgs( $request, PostType::SLUG );
		if ( $own instanceof WP_Error ) {
			return $own;
		}
		$projectId = absint( $request['project_id'] ?? 0 );
		if ( $projectId > 0 ) {
			// Only the project's items, and of those only what the author
			// may list: the narrower of the two sets, or a post that cannot
			// exist when they share nothing (an empty post__in lists everything).
			$gated = ( new ProjectRepository() )->gatedContentIds( $projectId );
			if ( isset( $own['post__in'] ) ) {
				$gated = array_values( array_intersect( $gated, (array) $own['post__in'] ) );
			}
			$own['post__in'] = $gated ? $gated : [ 0 ];
		}
		$q = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft', 'pending' ],
					'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- deliberate 200-item cap for the admin content table.
					'orderby'        => 'date',
					'order'          => 'DESC',
				],
				$own
			)
		);

		// Every row's projects from one read of the gates for the page and
		// one of the projects named (At-a-glance track, FR6); with Projects
		// off, none and no read, as every module-fed fact.
		$gates = [];
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			$gates = ( new ProjectRepository() )->projectsForContents( wp_list_pluck( $q->posts, 'ID' ) );
			$named = array_values( array_unique( array_merge( [], ...array_values( $gates ) ) ) );
			if ( $named ) {
				_prime_post_caches( $named, false, false );
			}
		}
		// Every row's sub-groups from one read. A client author is told of
		// their own part of each audience alone (Portal\AudienceShown), each
		// sub-group and project asked of them all at once.
		$sgGates = ( new SubgroupRepository() )->subgroupsForContents( wp_list_pluck( $q->posts, 'ID' ) );
		$caller  = wp_get_current_user();
		$told    = static fn ( array $ids, array $shown ): array => array_values( array_filter( array_map( 'intval', $ids ), static fn ( int $id ): bool => isset( $shown[ $id ] ) ) );
		$sgShown = array_fill_keys( AudienceShown::subgroups( $caller, $sgGates ? array_merge( ...array_values( $sgGates ) ) : [] ), true );
		$pShown  = array_fill_keys( AudienceShown::projects( $caller, $gates ? array_merge( ...array_values( $gates ) ) : [] ), true );

		$files = new SecureFiles();
		$out   = [];
		foreach ( $q->posts as $post ) {
			// Ids and names side by side (the list filters by id), leaving out
			// organizations that no longer exist.
			$orgIds   = array_values(
				array_filter(
					AudienceShown::orgs( $caller, (array) get_post_meta( $post->ID, Meta::KEY_ORG_IDS, true ) ),
					static fn ( int $orgId ): bool => '' !== get_the_title( $orgId )
				)
			);
			$orgNames = array_map( 'get_the_title', $orgIds );
			$file     = $files->findByContent( $post->ID );
			$author   = get_userdata( (int) $post->post_author );
			$out[]    = [
				'id'            => $post->ID,
				'title'         => get_the_title( $post ),
				'visibility'    => (string) ( get_post_meta( $post->ID, Meta::KEY_VISIBILITY, true ) ?: 'published' ),
				'org_ids'       => $orgIds,
				'org_names'     => array_values( $orgNames ),
				// The sub-groups it is scoped to, for the list's filter (the
				// sub-group detail links to the list filtered with ?subgroup=).
				'subgroups'     => $this->subgroupRefs( $told( $sgGates[ $post->ID ] ?? [], $sgShown ) ),
				// And the projects it is gated to (the project detail links
				// here with ?project=, and the column filters with project_id).
				'projects'      => $this->projectRefs( $told( $gates[ $post->ID ] ?? [], $pShown ) ),
				'date'          => get_post_modified_time( 'M j, Y', false, $post ),
				'modified'      => get_post_modified_time( 'c', true, $post ),
				'status'        => $post->post_status,
				// The list's sub-line: the file's kind and size, and who wrote
				// it (a delegated author writes from the portal).
				'file'          => $file ? [
					'type' => strtoupper( pathinfo( (string) ( $file['original_name'] ?? '' ), PATHINFO_EXTENSION ) ) ?: __( 'File', 'monstera' ),
					'size' => (int) ( $file['filesize'] ?? 0 ),
				] : null,
				'author_name'   => $author ? UserMeta::fullName( $author ) : '',
				'author_portal' => $author ? ! user_can( $author, Capabilities::CAP_MANAGE_MONSTERA ) : false,
				'edit_url'      => admin_url( 'admin.php?page=monstera-content&id=' . $post->ID ),
			];
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Content item not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		// The organization the item is for, and the caller's tier there.
		$scope = $this->authoringScope( $request );
		if ( $scope instanceof WP_Error ) {
			return $scope;
		}
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'Give the item a title.', 'monstera' ) );
		}

		$status = sanitize_key( (string) ( $request['status'] ?? 'publish' ) );
		$status = in_array( $status, [ 'publish', 'draft', 'pending' ], true ) ? $status : 'publish';

		// Created as a draft and given its audience first, then moved to the
		// status asked for: the first-publish notification reads the audience
		// at that moment, and created straight as published it found none,
		// emailed nobody and was marked sent.
		$id = wp_insert_post(
			[
				'post_type'    => PostType::SLUG,
				'post_title'   => $title,
				'post_status'  => 'draft',
				'post_content' => wp_kses_post( (string) ( $request['content'] ?? '' ) ),
				'post_author'  => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		// A staff create from a hub's Manage tab is for that hub.
		$hub = $this->hubOfStaffCreate( $request, $scope );
		if ( $hub > 0 ) {
			update_post_meta( (int) $id, Meta::KEY_ORG_IDS, [ $hub ] );
		}
		$this->applyMutations( (int) $id, $request, $scope );
		$this->stampEditor( (int) $id );
		if ( 'draft' !== $status ) {
			wp_update_post(
				[
					'ID'          => (int) $id,
					'post_status' => $status,
				]
			);
		}
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Content item not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'Give the item a title.', 'monstera' ) );
			}
		}
		if ( $request->has_param( 'content' ) ) {
			$core['post_content'] = wp_kses_post( (string) $request['content'] );
		}
		if ( $request->has_param( 'status' ) ) {
			$status = sanitize_key( (string) $request['status'] );
			if ( in_array( $status, [ 'publish', 'draft', 'pending' ], true ) ) {
				$core['post_status'] = $status;
			}
		}
		// The audience first, then the post: a save that publishes (or
		// updates a published item) notifies the audience it leaves behind.
		// Written in the item's own organization, so a save never moves it.
		$this->applyMutations( $id, $request, $this->itemScope( $id ) );
		$this->stampEditor( $id );
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}
		return $this->shape( $id );
	}

	/**
	 * Writes the fields a save carries. The scope is the caller's in the
	 * organization the save acts on: the one a create names, an existing
	 * item's own.
	 */
	private function applyMutations( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		if ( $request->has_param( 'summary' ) ) {
			update_post_meta( $id, Meta::KEY_SUMMARY, wp_kses_post( (string) $request['summary'] ) );
		}
		if ( $request->has_param( 'visibility' ) ) {
			$v = (string) $request['visibility'];
			if ( in_array( $v, [ Meta::VISIBILITY_PUBLISHED, Meta::VISIBILITY_PENDING, Meta::VISIBILITY_HIDDEN ], true ) ) {
				update_post_meta( $id, Meta::KEY_VISIBILITY, $v );
			}
		}
		if ( $request->has_param( 'click_behavior' ) ) {
			$cb = (string) $request['click_behavior'];
			if ( in_array( $cb, [ Meta::CLICK_FILE, Meta::CLICK_POST ], true ) ) {
				update_post_meta( $id, Meta::KEY_CLICK_BEHAVIOR, $cb );
			}
		}
		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'audience_everyone' ) ) {
				update_post_meta( $id, Meta::KEY_AUDIENCE_EVERYONE, (bool) rest_sanitize_boolean( (string) $request['audience_everyone'] ) );
			}
			if ( $request->has_param( 'org_ids' ) ) {
				update_post_meta( $id, Meta::KEY_ORG_IDS, array_values( array_map( 'absint', (array) $request['org_ids'] ) ) );
			}
			if ( $request->has_param( 'standalone_member_ids' ) ) {
				update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, array_values( array_map( 'absint', (array) $request['standalone_member_ids'] ) ) );
			}
			if ( $request->has_param( 'project_ids' ) ) {
				$this->syncProjects( $id, array_map( 'absint', (array) $request['project_ids'] ) );
			}
			// A sub-group no picker shows stays unless the save lifts the
			// limit (gateAfterSave()).
			$lift = self::liftsDeletedGate( $request );
			if ( $request->has_param( 'subgroup_ids' ) || $lift ) {
				$proposed = array_map( 'absint', (array) ( $request['subgroup_ids'] ?? [] ) );
				$orgIds   = array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_ORG_IDS, true ) );
				$memIds   = array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, true ) );
				// A sub-group narrows the audience it belongs to. Sent to
				// everyone, any sub-group can narrow that; the save once dropped
				// the gate and the item reached every member.
				$valid = (bool) get_post_meta( $id, Meta::KEY_AUDIENCE_EVERYONE, true )
					? self::existingSubgroups( $proposed )
					: self::filterSubgroupsByAudience( $proposed, $orgIds, $memIds );
				$this->syncSubgroups( $id, self::gateAfterSave( ( new SubgroupRepository() )->subgroupsForContent( $id ), $valid, $lift, $request->has_param( 'subgroup_ids' ) ) );
			}
		} elseif ( ! $scope->isSharedFurther( $id ) ) {
			// Delegated authors can never widen their audience: org is forced to
			// the scope's own, standalone targeting is denied, and sub-group
			// gating is clamped (a leader is held to the sub-groups they lead
			// there). Org/standalone are re-asserted on every write of an item
			// that is theirs alone; sub-groups
			// only when the manager sends them, so a title-only edit doesn't
			// wipe their selection, and on a leader's every write, to what they
			// sent or else to the gate the item has (AuthorScope::subgroupIdsForSave()).
			// An item staff shared beyond their part keeps its audience whole
			// through the author's saves (AuthorScope::isSharedFurther()), and a
			// sub-group their form cannot show stays (gateAfterSave()).
			$orgIds = $scope->clampOrgIds( [] );
			update_post_meta( $id, Meta::KEY_ORG_IDS, $orgIds );
			update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, [] );
			update_post_meta( $id, Meta::KEY_AUDIENCE_EVERYONE, false );

			if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
				$proposed = $scope->subgroupIdsForSave( $id, $request->has_param( 'subgroup_ids' ) ? (array) $request['subgroup_ids'] : null );
				$valid    = self::filterSubgroupsByAudience( $proposed, $orgIds, [] );
				$this->syncSubgroups( $id, self::gateAfterSave( ( new SubgroupRepository() )->subgroupsForContent( $id ), $valid, false ) );
			}
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Content item not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * The sub-groups an item keeps after a save. The pickers list published
	 * sub-groups, and one deleted or in the trash lets nobody but staff in
	 * (the owner's call, 2026-10-18), so a save never drops one they cannot
	 * show: dropping it would open the item to its whole audience unseen.
	 * When those are all the item is limited to, choosing sub-groups replaces
	 * them; beside ones the picker shows they stay, so a restored sub-group
	 * lets its members back, unless the save clears every one it shows,
	 * which opens the item as the field says. Lifting the limit
	 * (`lift_deleted_subgroups`, staff's) drops them and keeps the rest.
	 *
	 * @param array<int, int> $current The item's sub-groups now.
	 * @param array<int, int> $valid   What the save chose, checked against the audience.
	 * @param bool            $lift    Whether the save lifts the limit.
	 * @param bool            $sent    Whether the save named sub-groups; one that did not keeps the shown ones.
	 * @return list<int>
	 */
	public static function gateAfterSave( array $current, array $valid, bool $lift, bool $sent = true ): array {
		$current = array_values( array_unique( array_map( 'intval', $current ) ) );
		$valid   = array_values( array_unique( array_map( 'intval', $valid ) ) );
		if ( $lift ) {
			$kept = $sent ? $valid : $current;
			return array_values( array_diff( $kept, SubgroupRepository::unavailableAmong( $kept ) ) );
		}
		// Only a sub-group a picker can show is a choice: one sent back as it
		// was handed, hidden, is none (the Phase 5 review).
		$hidden = SubgroupRepository::unavailableAmong( $current );
		$chosen = array_values( array_diff( $valid, SubgroupRepository::unavailableAmong( $valid ) ) );
		if ( ! array_diff( $current, $hidden ) ) {
			return $chosen ? $chosen : $current;
		}
		return $chosen ? array_values( array_unique( array_merge( $chosen, $hidden ) ) ) : [];
	}

	/**
	 * How many sub-groups no picker shows an item is limited to, when they are
	 * all it is limited to: its detail then says the limit holds and offers
	 * to lift it. 0 while one it is limited to can be shown, which says so.
	 *
	 * @param array<int, int> $ids
	 */
	public static function unavailableGate( array $ids ): int {
		$ids    = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		$hidden = SubgroupRepository::unavailableAmong( $ids );
		return $ids && ! array_diff( $ids, $hidden ) ? count( $hidden ) : 0;
	}

	/** Whether a staff save asks to lift a deleted sub-group's gate. */
	public static function liftsDeletedGate( WP_REST_Request $request ): bool {
		return true === filter_var( $request['lift_deleted_subgroups'] ?? false, FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * The proposed ids that are sub-groups at all, for an audience of
	 * everyone, which any sub-group can narrow.
	 *
	 * @param array<int, mixed> $proposed
	 * @return int[]
	 */
	public static function existingSubgroups( array $proposed ): array {
		return array_values(
			array_filter(
				array_unique( array_map( 'absint', $proposed ) ),
				static fn ( int $id ): bool => $id > 0 && \Monstera\Subgroups\PostType::SLUG === get_post_type( $id )
			)
		);
	}

	/**
	 * Drop any sub-group ID whose parent org / standalone member isn't part
	 * of the entity's audience. Sub-groups are scoped to one parent and
	 * cannot be assigned across audiences they don't belong to.
	 *
	 * @param array<int, mixed> $proposed
	 * @param int[]             $orgIds
	 * @param int[]             $standaloneMemberIds
	 * @return int[]
	 */
	public static function filterSubgroupsByAudience( array $proposed, array $orgIds, array $standaloneMemberIds ): array {
		if ( ! $proposed ) {
			return [];
		}
		$orgIds              = array_map( 'intval', $orgIds );
		$standaloneMemberIds = array_map( 'intval', $standaloneMemberIds );
		$out                 = [];
		foreach ( $proposed as $sgId ) {
			$sgId = (int) $sgId;
			if ( $sgId <= 0 ) {
				continue;
			}
			$sgOrg    = (int) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_ORG_ID, true );
			$sgMem    = (int) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_STANDALONE_MEMBER_ID, true );
			$orgMatch = $sgOrg > 0 && in_array( $sgOrg, $orgIds, true );
			$memMatch = $sgMem > 0 && in_array( $sgMem, $standaloneMemberIds, true );
			if ( $orgMatch || $memMatch ) {
				$out[] = $sgId;
			}
		}
		return $out;
	}

	/**
	 * The sub-groups an item is scoped to, as id and name, leaving out any
	 * that no longer exist.
	 *
	 * @param int[] $subgroupIds The ones the caller is told of.
	 * @return list<array{id: int, name: string}>
	 */
	private function subgroupRefs( array $subgroupIds ): array {
		$out = [];
		foreach ( $subgroupIds as $groupId ) {
			$name = get_the_title( (int) $groupId );
			if ( '' !== $name ) {
				$out[] = [
					'id'   => (int) $groupId,
					'name' => $name,
				];
			}
		}
		return $out;
	}

	/**
	 * The projects an item is gated to, as id and name, leaving out any
	 * that no longer exist. The ids come from one read of the gates for the
	 * whole page (index()), the names from the post cache primed there.
	 *
	 * @param int[] $projectIds
	 * @return list<array{id: int, name: string}>
	 */
	private function projectRefs( array $projectIds ): array {
		$out = [];
		foreach ( $projectIds as $projectId ) {
			$name = get_the_title( (int) $projectId );
			if ( '' !== $name ) {
				$out[] = [
					'id'   => (int) $projectId,
					'name' => $name,
				];
			}
		}
		return $out;
	}

	/**
	 * @param array<int, int> $wanted
	 */
	private function syncSubgroups( int $contentId, array $wanted ): void {
		$repo    = new SubgroupRepository();
		$current = $repo->subgroupsForContent( $contentId );
		$wanted  = array_values( array_unique( array_filter( $wanted ) ) );

		foreach ( array_diff( $current, $wanted ) as $sgId ) {
			$repo->unassignContent( (int) $sgId, $contentId );
		}
		foreach ( array_diff( $wanted, $current ) as $sgId ) {
			$repo->assignContent( (int) $sgId, $contentId );
		}
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		// A client author is told of their own part of the audience alone
		// (Portal\AudienceShown); staff of all of it.
		$caller = wp_get_current_user();
		$post   = get_post( $id );
		$orgIds = AudienceShown::orgs( $caller, (array) get_post_meta( $id, Meta::KEY_ORG_IDS, true ) );
		$memIds = AudienceShown::members( $caller, (array) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_IDS, true ) );
		$sgAll  = ( new SubgroupRepository() )->subgroupsForContent( $id );
		// A picker is handed the published ones (AudienceShown::subgroups()),
		// and a save keeps the rest (gateAfterSave()).
		$sgIds = AudienceShown::subgroups( $caller, $sgAll );

		return [
			'id'                    => $id,
			// As stored: the detail saves it back, and get_the_title() would
			// turn straight quotes curly (and into entities) on the way.
			'title'                 => (string) get_post_field( 'post_title', $id, 'raw' ),
			'content'               => (string) $post?->post_content,
			'summary'               => (string) get_post_meta( $id, Meta::KEY_SUMMARY, true ),
			'status'                => (string) $post?->post_status,
			'visibility'            => (string) ( get_post_meta( $id, Meta::KEY_VISIBILITY, true ) ?: Meta::VISIBILITY_PUBLISHED ),
			'click_behavior'        => (string) ( get_post_meta( $id, Meta::KEY_CLICK_BEHAVIOR, true ) ?: Meta::CLICK_FILE ),
			'audience_everyone'     => (bool) get_post_meta( $id, Meta::KEY_AUDIENCE_EVERYONE, true ),
			'org_ids'               => $orgIds,
			'standalone_member_ids' => $memIds,
			'subgroup_ids'          => $sgIds,
			// Sub-groups no picker shows that are all it is limited to: the
			// detail says the limit holds and offers to lift it (staff's).
			'subgroups_unavailable' => AudienceShown::whole( $caller ) ? self::unavailableGate( $sgAll ) : 0,
			'project_ids'           => AudienceShown::projects( $caller, ( new ProjectRepository() )->projectsForContent( $id ) ),
			// Whether staff shared it beyond the caller's part, so the portal's
			// editor says who chooses its audience instead of offering it.
			'shared_further'        => AuthorScope::forItem( (int) $caller->ID, $id )->isSharedFurther( $id ),
			'file'                  => $this->fileFacts( $id ),
			// How many its email reached, and below how many read and
			// downloaded it, count everyone it reached: staff's alone (the
			// review of the At-a-glance track, 2026-10-19).
			'notified'              => AudienceShown::whole( $caller ) ? $this->lastNotified( $id ) : null,
			// The head and the sidebar (comp 122).
			// The kind, capitalised for the head's meta line ("Report").
			'noun'                  => PostType::singular( PostType::label() ),
			'author_name'           => $this->authorName( (int) $post?->post_author ),
			'portal_url'            => Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $id ] ),
			'published'             => 'publish' === $post?->post_status ? (string) get_post_time( 'c', true, $id ) : '',
			'facts'                 => AudienceShown::whole( $caller ) ? $this->contentFacts( $id ) : null,
			'saved'                 => $this->savedStamp( $id ),
			'date'                  => get_post_modified_time( 'M j, Y', false, $id ),
			'edit_url'              => admin_url( 'admin.php?page=monstera-content&id=' . $id ),
		];
	}

	/**
	 * Attach or replace the item's secure file (comp 122's .m-filepick): a
	 * multipart `file`, checked against the size limit and the type
	 * allowlist, stored through SecureFiles::store() (never the Media
	 * Library). A replaced file leaves disk and registry once the new one is
	 * in.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function uploadFile( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Content item not found.', 'monstera' ), [ 'status' => 404 ] );
		}

		$upload  = $request->get_file_params()['file'] ?? null;
		$upload  = is_array( $upload ) ? $upload : null;
		$refusal = SecureFiles::refusal( $upload );
		if ( null !== $refusal || null === $upload ) {
			return $this->invalidField( 'file', $refusal ?? __( 'Choose a file to attach.', 'monstera' ) );
		}

		$files    = new SecureFiles();
		$previous = $files->findByContent( $id );
		$orgIds   = array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_ORG_IDS, true ) );
		try {
			$files->store(
				$id,
				$orgIds[0] ?? 0,
				[
					'name'     => sanitize_file_name( (string) $upload['name'] ),
					'tmp_name' => (string) $upload['tmp_name'],
					'size'     => (int) $upload['size'],
					'type'     => SecureFiles::checkedType( $upload ),
				]
			);
		} catch ( \RuntimeException $e ) {
			return new WP_Error( 'monstera_file_not_stored', __( 'The file could not be stored. Try again.', 'monstera' ), [ 'status' => 500 ] );
		}
		if ( $previous ) {
			$files->delete( (int) $previous['id'] );
		}
		return $this->shape( $id );
	}

	/**
	 * Make the item's project gate exactly these projects, keeping only ids
	 * that are projects.
	 *
	 * @param array<int, int> $wanted
	 */
	private function syncProjects( int $contentId, array $wanted ): void {
		$wanted  = array_values(
			array_filter(
				array_unique( array_filter( $wanted ) ),
				static fn ( int $projectId ): bool => ProjectPostType::SLUG === get_post_type( $projectId )
			)
		);
		$repo    = new ProjectRepository();
		$current = $repo->projectsForContent( $contentId );
		foreach ( array_diff( $current, $wanted ) as $projectId ) {
			$repo->unassignContent( (int) $projectId, $contentId );
		}
		foreach ( array_diff( $wanted, $current ) as $projectId ) {
			$repo->assignContent( (int) $projectId, $contentId );
		}
	}

	/**
	 * When "new content" last went out for the item and to how many people
	 * (the notifications line, comp 122), or null when it never went. One
	 * send is the rows logged within five minutes of the latest.
	 *
	 * @return array{at: string, recipients: int, delivered: int}|null
	 */
	private function lastNotified( int $contentId ): ?array {
		global $wpdb;
		$table  = Schema::tableName( Schema::TABLE_NOTIFICATION_LOG );
		$latest = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one value from Monstera's own log, read once per detail load.
			$wpdb->prepare( 'SELECT MAX(sent_at) FROM %i WHERE content_id = %d AND event_type = %s', $table, $contentId, TemplateEngine::EVENT_NEW_CONTENT )
		);
		if ( ! $latest ) {
			return null;
		}
		$at    = (int) strtotime( $latest . ' UTC' );
		$batch = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- counts from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT COUNT(DISTINCT member_id) AS recipients, COUNT(DISTINCT CASE WHEN delivered = 1 OR delivered IS NULL THEN member_id END) AS delivered FROM %i WHERE content_id = %d AND event_type = %s AND sent_at >= %s',
				$table,
				$contentId,
				TemplateEngine::EVENT_NEW_CONTENT,
				gmdate( 'Y-m-d H:i:s', $at - 5 * MINUTE_IN_SECONDS )
			),
			ARRAY_A
		);
		return [
			'at'         => gmdate( 'Y-m-d\TH:i:s\Z', $at ),
			'recipients' => (int) ( $batch['recipients'] ?? 0 ),
			'delivered'  => (int) ( $batch['delivered'] ?? 0 ),
		];
	}

	/**
	 * "Who can see this" (comp 122): the readers the visibility engine
	 * allows among the item's candidates (Content\Readers: every member for
	 * content for everyone; otherwise the audience organizations' members
	 * and the standalone members listed; and the staff), the first 50 by
	 * name, the total, and how many are members rather than staff, which is
	 * the head's "Visible to N members" and what staff read in the portal's
	 * download panel. A person is listed once, with every organization of
	 * theirs.
	 *
	 * @return array{total: int, members: int, readers: list<array{id: int, name: string, org: string}>}|WP_Error
	 */
	public function readers( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Content item not found.', 'monstera' ), [ 'status' => 404 ] );
		}

		$readers = Readers::allowed( $id, new Visibility( new SubgroupRepository(), new ProjectRepository() ) );
		usort( $readers, static fn ( WP_User $a, WP_User $b ): int => strcasecmp( UserMeta::fullName( $a ), UserMeta::fullName( $b ) ) );
		$members = count( array_filter( $readers, static fn ( WP_User $user ): bool => ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) );

		return [
			'total'   => count( $readers ),
			'members' => $members,
			'readers' => array_map(
				static function ( WP_User $user ): array {
					$org = __( 'Standalone member', 'monstera' );
					if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
						$org = __( 'Team', 'monstera' );
					} else {
						$names = array_map(
							static fn ( int $orgId ): string => html_entity_decode( get_the_title( $orgId ), ENT_QUOTES, 'UTF-8' ),
							Roster::orgIdsOf( (int) $user->ID )
						);
						if ( $names ) {
							// Membership order, joined as the chips join them.
							$org = implode( ' · ', $names );
						}
					}
					return [
						'id'   => (int) $user->ID,
						'name' => UserMeta::fullName( $user ),
						'org'  => $org,
					];
				},
				array_slice( $readers, 0, 50 )
			),
		];
	}

	private function authorName( int $userId ): string {
		$user = $userId ? get_userdata( $userId ) : false;
		return $user ? UserMeta::fullName( $user ) : '';
	}

	/**
	 * The sidebar's counts (comp 122): views in the last 7 days and
	 * downloads, from the activity log.
	 *
	 * @return array{views_7d: int|null, downloads: int}
	 */
	private function contentFacts( int $id ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- counts from Monstera's own log, read once per detail load.
		// Views are logged while Reporting is on; a download always is.
		$views     = $this->factOf(
			Modules::REPORTING,
			static fn (): int => (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE object_type = %s AND object_id = %d AND event_type = %s AND occurred_at >= %s',
					$table,
					'content',
					$id,
					'content_viewed',
					gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS )
				)
			)
		);
		$downloads = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE object_type = %s AND object_id = %d AND event_type = %s',
				$table,
				'content',
				$id,
				'download'
			)
		);
		// phpcs:enable
		return [
			'views_7d'  => $views,
			'downloads' => $downloads,
		];
	}

	/**
	 * The item's secure file, for the detail's file picker, or null.
	 *
	 * @return array{id: int, name: string, size: int, mime: string, sha256: string}|null
	 */
	private function fileFacts( int $id ): ?array {
		$row = ( new SecureFiles() )->findByContent( $id );
		if ( ! $row ) {
			return null;
		}
		return [
			'id'     => (int) $row['id'],
			'name'   => (string) $row['original_name'],
			'size'   => (int) $row['filesize'],
			'mime'   => (string) $row['mime_type'],
			'sha256' => (string) $row['sha256'],
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function visibilityCheck( WP_REST_Request $request ): array|WP_Error {
		$id     = (int) $request['id'];
		$userId = (int) $request['user_id'];
		$user   = get_user_by( 'id', $userId );
		if ( ! $user ) {
			return new WP_Error( 'monstera_user_not_found', __( 'User not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$visibility = new Visibility( new SubgroupRepository(), new ProjectRepository() );
		$orgIds     = OrgRepository::onSite( Roster::orgIdsOf( $userId ) );
		$orgNames   = array_map( static fn ( int $orgId ): string => get_the_title( $orgId ), $orgIds );
		// Who was checked, for the wizard's verdict sentence and its fixes
		// ("Add <organization>", "Add <member>"): every organization of theirs
		// in membership order, one "Add" fix each, and the primary alone as
		// org_id/org_name for the sentence that names one. One in the trash
		// grants nothing, so adding it would fix nothing.
		return $visibility->evaluate( $user, $id )->toArray() + [
			'member' => [
				'id'         => $userId,
				'name'       => UserMeta::fullName( $user ),
				'first_name' => (string) ( $user->first_name ?: UserMeta::fullName( $user ) ),
				'org_id'     => $orgIds[0] ?? 0,
				'org_name'   => $orgNames[0] ?? '',
				'org_ids'    => $orgIds,
				'org_names'  => $orgNames,
				// How many of theirs are in the trash, which the verdict says.
				'in_trash'   => count( Roster::orgIdsOf( $userId ) ) - count( $orgIds ),
			],
		];
	}

	/**
	 * Clears the "first publish notified" flag and re-fires the published hook,
	 * so the Notifications Dispatcher sends a fresh "new content" email rather
	 * than the "updated" variant. Used by the "Resend as new" admin action.
	 * @return array<string, mixed>|WP_Error
	 */
	public function resendNotification( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Content item not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( 'publish' !== $post->post_status ) {
			return new WP_Error( 'monstera_not_published', __( 'Content must be published before its notification can be resent.', 'monstera' ), [ 'status' => 422 ] );
		}

		// Straight to the sender: the item was published once, and stays so.
		// (Firing the publish hook again logged a second "published" and
		// cleared the flag that tells a later re-publish from the first.)
		( new \Monstera\Notifications\Dispatcher( new TemplateEngine() ) )->onContentPublished( $id );

		return [
			'ok'      => true,
			'message' => __( 'Resent to everyone with access as a new publication.', 'monstera' ),
		];
	}
}
