<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\BackgroundSync\BackgroundSyncModule;
use Monstera\Core\ToolRuns;

final class SyncController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/sync/run',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'run' ],
			]
		);
	}

	/**
	 * @return array{message: string, results: array<string, array<string, int>>}
	 */
	public function run(): array {
		$results = BackgroundSyncModule::runAll();
		$changes = 0;
		foreach ( $results as $task ) {
			// The relationship task also reports how many items it left with no
			// organization. That counts what remains, not what the run changed.
			unset( $task['orphans'] );
			$changes += (int) array_sum( array_map( 'intval', (array) $task ) );
		}
		ToolRuns::record(
			'sync',
			'ok',
			/* translators: %d: number of rows the sync changed */
			sprintf( _n( '%d change', '%d changes', $changes, 'monstera' ), $changes )
		);
		return [
			'message' => __( 'Sync complete.', 'monstera' ),
			'results' => $results,
		];
	}
}
