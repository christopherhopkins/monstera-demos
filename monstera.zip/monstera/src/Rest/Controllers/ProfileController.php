<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Admin\ColumnSets;
use Monstera\Members\UserMeta;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

final class ProfileController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/profile/me',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'updateMe' ],
			]
		);

		// The columns a staff person reads on a list (Admin\ColumnSets;
		// At-a-glance track, FR2): their own choice, for one list at a time.
		register_rest_route(
			$this->restNamespace,
			'/profile/me/columns',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'setColumns' ],
				'args'                => [
					'list'    => [
						'type'     => 'string',
						'required' => true,
					],
					'columns' => [
						'type'     => 'array',
						'required' => true,
						'items'    => [ 'type' => 'string' ],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/profile/me/theme',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'setTheme' ],
				// The portal's theme group and the admin app bar's toggle
				// send one of two words; anything else is refused, not
				// quietly saved as light.
				'args'                => [
					'theme' => [
						'type'     => 'string',
						'enum'     => [ 'light', 'dark' ],
						'required' => true,
					],
				],
			]
		);
	}

	/**
	 * @return array{ok: bool}|\WP_Error
	 */
	public function updateMe( WP_REST_Request $request ): array|\WP_Error {
		$userId = get_current_user_id();
		$data   = $request->get_json_params() ?: $request->get_params();

		// Refused before anything is written: the photo is an image the member
		// uploaded, never another person's or another kind of file.
		$photo = array_key_exists( 'profile_photo', $data ) ? absint( $data['profile_photo'] ) : 0;
		if ( $photo > 0 ) {
			$file = get_post( $photo );
			if ( ! $file || 'attachment' !== $file->post_type || (int) $file->post_author !== $userId || ! wp_attachment_is_image( $photo ) ) {
				return $this->invalidField( 'profile_photo', __( 'Choose an image you uploaded.', 'monstera' ) );
			}
		}

		if ( isset( $data['first_name'] ) ) {
			wp_update_user(
				[
					'ID'         => $userId,
					'first_name' => sanitize_text_field( (string) $data['first_name'] ),
				]
			);
		}
		if ( isset( $data['last_name'] ) ) {
			wp_update_user(
				[
					'ID'        => $userId,
					'last_name' => sanitize_text_field( (string) $data['last_name'] ),
				]
			);
		}
		if ( isset( $data['position'] ) ) {
			update_user_meta( $userId, UserMeta::KEY_POSITION, sanitize_text_field( (string) $data['position'] ) );
		}
		if ( isset( $data['bio'] ) ) {
			update_user_meta( $userId, UserMeta::KEY_BIO, wp_kses_post( (string) $data['bio'] ) );
		}
		if ( array_key_exists( 'show_in_directory', $data ) ) {
			update_user_meta( $userId, UserMeta::KEY_SHOW_IN_DIRECTORY, self::flag( $data['show_in_directory'] ) );
		}
		if ( array_key_exists( 'profile_photo', $data ) ) {
			// Attachment ID (0 clears the photo). The directory + profile views
			// already read this meta; this is the writer they were missing.
			update_user_meta( $userId, UserMeta::KEY_PROFILE_PHOTO, absint( $data['profile_photo'] ) );
		}

		return [ 'ok' => true ];
	}

	/**
	 * Keep the caller's column set for one list. A list with no chooser,
	 * and a column the list does not have, are refused on their field;
	 * the answer is the set as stored, in the list's order.
	 *
	 * @return array{list: string, columns: list<string>}|\WP_Error
	 */
	public function setColumns( WP_REST_Request $request ): array|\WP_Error {
		$listKey = sanitize_key( (string) $request['list'] );
		if ( null === ColumnSets::choosable( $listKey ) ) {
			return $this->invalidField( 'list', __( 'That list has no columns to choose.', 'monstera' ) );
		}
		$columns = ColumnSets::sanitize( $listKey, (array) $request['columns'] );
		if ( null === $columns ) {
			return $this->invalidField( 'columns', __( 'Choose columns the list has.', 'monstera' ) );
		}
		ColumnSets::save( get_current_user_id(), $listKey, $columns );
		return [
			'list'    => $listKey,
			'columns' => $columns,
		];
	}

	/**
	 * @return array{theme: string}
	 */
	public function setTheme( WP_REST_Request $request ): array {
		$theme = (string) $request->get_param( 'theme' );
		$theme = in_array( $theme, [ 'light', 'dark' ], true ) ? $theme : 'light';
		update_user_meta( get_current_user_id(), UserMeta::KEY_THEME, $theme );
		return [ 'theme' => $theme ];
	}
}
