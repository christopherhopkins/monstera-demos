<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Routing;
use Monstera\Resources\Files;
use Monstera\Resources\Meta;
use Monstera\Resources\PostType;
use Monstera\Members\UserMeta;
use Monstera\Portal\AudienceShown;
use Monstera\Portal\AuthorScope;
use WP_Error;
use WP_Query;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * The resources routes (Forms-and-resources track, FR10): the library's
 * CRUD, which the forms routes carried until 2026-10-26, and the file
 * upload. A guide's body travels as `body`, block markup the editor saves.
 */
final class ResourcesController extends BaseController {

	use SaysAudience;

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/resources',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/resources/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/resources/(?P<id>\d+)/file',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
				'callback'            => [ $this, 'uploadFile' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}|WP_Error
	 */
	public function index( WP_REST_Request $request ): array|WP_Error {
		$own = $this->ownAuthorQueryArgs( $request, PostType::SLUG );
		if ( $own instanceof WP_Error ) {
			return $own;
		}
		$q = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft' ],
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				],
				$own
			)
		);
		// A client author is told of their own part of each audience alone
		// (Portal\AudienceShown), by name; staff of all of it. How far it
		// reaches is counted whole, numbers naming nobody, so a summary never
		// reads "All members" for a resource shared with others.
		$caller = wp_get_current_user();
		$whole  = AudienceShown::whole( $caller );
		// How often each was opened in 30 days, read for the whole list at
		// once (comp 134's column); null with Reporting off.
		// Staff alone: a count takes in everyone it reached, the people of an
		// organization staff shared it with too (AudienceShown's rule).
		$opens = $whole && \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::REPORTING ) ? $this->opensLast30DaysOf( wp_list_pluck( $q->posts, 'ID' ) ) : null;
		// The rows' files, authors and organizations, each read once for the
		// list (Forms-and-resources track, NFR Query cost).
		Files::prime( $q->posts );
		self::primeAuthorsAndOrgs( $q->posts, Meta::KEY_ORGS, Meta::KEY_SUBGROUPS );
		$out = [];
		foreach ( $q->posts as $post ) {
			$allOrgs  = self::ids( get_post_meta( $post->ID, Meta::KEY_ORGS, true ) );
			$allMems  = self::ids( get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBERS, true ) );
			$orgIds   = AudienceShown::orgs( $caller, $allOrgs );
			$orgNames = array_values( array_filter( array_map( 'get_the_title', $orgIds ) ) );
			$fileId   = Meta::KIND_FILE === Meta::kindOf( (int) $post->ID ) ? (int) get_post_meta( $post->ID, Meta::KEY_FILE_ID, true ) : 0;
			$path     = $fileId ? (string) get_attached_file( $fileId ) : '';
			$author   = get_userdata( (int) $post->post_author );
			$out[]    = [
				'id'             => $post->ID,
				'title'          => get_the_title( $post ),
				'kind'           => Meta::kindOf( (int) $post->ID ),
				'access_summary' => $this->summarizeAccess( $allOrgs, $allMems ),
				// In words for staff, by name (comp 134); a client author is
				// told the counts, which name nobody.
				'audience'       => $whole ? $this->audienceInWords( self::ids( get_post_meta( $post->ID, Meta::KEY_SUBGROUPS, true ) ), $allOrgs, $allMems ) : $this->summarizeAccess( $allOrgs, $allMems ),
				'opens_30d'      => null === $opens ? null : ( $opens[ (int) $post->ID ] ?? 0 ),
				'file_ext'       => $path ? strtoupper( (string) pathinfo( $path, PATHINFO_EXTENSION ) ) : '',
				'status'         => $post->post_status,
				// The list's sub-line: where it comes from (the organizations
				// it targets, else the site), the file's size or the link's
				// host, and who wrote it (a manager writes from the portal).
				'source'         => $orgNames ? implode( ', ', $orgNames ) : (string) get_bloginfo( 'name' ),
				'file_size'      => $path && file_exists( $path ) ? (int) filesize( $path ) : 0,
				'external_url'   => (string) get_post_meta( $post->ID, Meta::KEY_EXTERNAL_URL, true ),
				'modified'       => get_post_modified_time( 'c', true, $post ),
				'author_name'    => $author ? UserMeta::fullName( $author ) : '',
				'author_portal'  => $author ? ! user_can( $author, Capabilities::CAP_MANAGE_MONSTERA ) : false,
				'edit_url'       => admin_url( 'admin.php?page=monstera-resources&id=' . $post->ID ),
			];
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Resource not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		// The organization the resource is for, and the caller's tier there.
		$scope = $this->authoringScope( $request );
		if ( $scope instanceof WP_Error ) {
			return $scope;
		}
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'Give the resource a title.', 'monstera' ) );
		}
		$refusal = $this->fileRefusal( 0, $request );
		if ( $refusal ) {
			return $refusal;
		}
		$status = sanitize_key( (string) ( $request['status'] ?? 'publish' ) );

		$id = wp_insert_post(
			[
				'post_type'   => PostType::SLUG,
				'post_title'  => $title,
				'post_status' => in_array( $status, [ 'publish', 'draft' ], true ) ? $status : 'draft',
				'post_author' => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		// A staff create from a hub's Manage tab is for that hub.
		$hub = $this->hubOfStaffCreate( $request, $scope );
		if ( $hub > 0 ) {
			update_post_meta( (int) $id, Meta::KEY_ORGS, [ $hub ] );
		}
		$this->applyMutations( (int) $id, $request, $scope );
		$this->stampEditor( (int) $id );
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Resource not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'Give the resource a title.', 'monstera' ) );
			}
		}
		$refusal = $this->fileRefusal( $id, $request );
		if ( $refusal ) {
			return $refusal;
		}
		if ( $request->has_param( 'status' ) ) {
			$status = sanitize_key( (string) $request['status'] );
			if ( in_array( $status, [ 'publish', 'draft' ], true ) ) {
				$core['post_status'] = $status;
			}
		}
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}

		// Written in the resource's own organization, so a save never moves it.
		$this->applyMutations( $id, $request, $this->itemScope( $id ) );
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/**
	 * Attach a file to a resource (multipart `file`). The file is sideloaded
	 * into the Media Library, attached to the resource, and the resource
	 * becomes a file resource. Resources are the low-sensitivity library by
	 * design (product.md), so the Media Library is their home; gated
	 * deliverables go through the secure-files flow instead.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function uploadFile( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Resource not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}

		$files = $request->get_file_params();
		$file  = is_array( $files['file'] ?? null ) ? $files['file'] : null;
		// Any type the site's uploader allows, at the site's limit (Resources\Files).
		$refusal = Files::refusal( $file );
		if ( null !== $refusal || null === $file ) {
			return $this->invalidField( 'file', $refusal ?? __( 'Choose a file to upload.', 'monstera' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachmentId = media_handle_sideload(
			[
				'name'     => sanitize_file_name( (string) $file['name'] ),
				'tmp_name' => (string) $file['tmp_name'],
				'type'     => Files::checkedType( $file ),
				'size'     => (int) ( $file['size'] ?? 0 ),
			],
			$id
		);
		if ( is_wp_error( $attachmentId ) ) {
			$attachmentId->add_data( [ 'status' => 422 ] );
			return $attachmentId;
		}

		// A resource has one file. The one this upload supersedes was sideloaded
		// for this resource (its parent) and goes with it, unless another
		// resource picked it from the Media Library since; a file this one
		// picked from the library has another parent and stays.
		$previous = (int) get_post_meta( $id, Meta::KEY_FILE_ID, true );
		if ( $previous > 0 && $previous !== (int) $attachmentId && (int) get_post_field( 'post_parent', $previous ) === $id && ! $this->fileUsedElsewhere( $previous, $id ) ) {
			wp_delete_attachment( $previous, true );
		}

		update_post_meta( $id, Meta::KEY_FILE_ID, (int) $attachmentId );
		update_post_meta( $id, Meta::KEY_KIND, Meta::KIND_FILE );
		// The link an external resource had would otherwise linger in its details.
		delete_post_meta( $id, Meta::KEY_EXTERNAL_URL );
		// An upload is a save: "Last saved" and "Updated" move with it.
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/** Where a member sees the resource, or '' for a draft (see shape()). */
	private function viewUrl( int $id, string $status ): string {
		if ( 'publish' !== $status ) {
			return '';
		}
		return Meta::KIND_GUIDE === Meta::kindOf( $id ) ? Routing::url( Routing::ROUTE_RESOURCE, [ 'id' => $id ] ) : Routing::url( Routing::ROUTE_RESOURCES );
	}

	/** Whether a resource other than this one names the attachment as its file. */
	private function fileUsedElsewhere( int $attachmentId, int $id ): bool {
		return (bool) get_posts(
			[
				'post_type'    => PostType::SLUG,
				// 'any' leaves the trash out, and a trashed one restored
				// would have lost its file.
				'post_status'  => [ 'publish', 'draft', 'pending', 'private', 'future', 'trash' ],
				'fields'       => 'ids',
				'numberposts'  => 1,
				'post__not_in' => [ $id ],
				'meta_key'     => Meta::KEY_FILE_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one indexed key, read on a replacing upload only.
				'meta_value'   => (string) $attachmentId, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
			]
		);
	}

	/**
	 * Why the file the request names cannot be the resource's file, or null.
	 * It must be a Media Library attachment; a delegated author may only
	 * name one that was uploaded to this resource, so another person's file
	 * (or its name and size) is never theirs to publish.
	 *
	 * @param int $id The resource, or 0 for a new one.
	 */
	private function fileRefusal( int $id, WP_REST_Request $request ): ?WP_Error {
		$fileId = $request->has_param( 'file_id' ) ? absint( $request['file_id'] ) : 0;
		if ( 0 === $fileId || ( $id > 0 && (int) get_post_meta( $id, Meta::KEY_FILE_ID, true ) === $fileId ) ) {
			return null;
		}
		$file = get_post( $fileId );
		$mine = $this->scope()->isAdmin || ( $id > 0 && $file && (int) $file->post_parent === $id );
		if ( ! $file || 'attachment' !== $file->post_type || ! $mine ) {
			return $this->invalidField( 'file', __( 'Choose a file uploaded to this resource.', 'monstera' ) );
		}
		return null;
	}

	/**
	 * An audience list as stored. One that was never written reads back as
	 * '', which would otherwise count as one organization with id 0.
	 *
	 * @return int[]
	 */
	private static function ids( mixed $meta ): array {
		return array_values( array_filter( array_map( 'intval', (array) $meta ) ) );
	}

	/**
	 * Writes the fields a save carries. The scope is the caller's in the
	 * organization the save acts on: the one a create names, an existing
	 * resource's own.
	 */
	private function applyMutations( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		if ( $request->has_param( 'kind' ) ) {
			$kind = (string) $request['kind'];
			if ( in_array( $kind, Meta::KINDS, true ) ) {
				update_post_meta( $id, Meta::KEY_KIND, $kind );
			}
		}
		if ( $request->has_param( 'description' ) ) {
			update_post_meta( $id, Meta::KEY_DESCRIPTION, wp_kses_post( (string) $request['description'] ) );
		}
		if ( $request->has_param( 'file_id' ) ) {
			update_post_meta( $id, Meta::KEY_FILE_ID, absint( $request['file_id'] ) );
		}
		// A guide's body: block markup, filtered as a post an editor may save
		// and slashed, since wp_update_post() unslashes what it is handed and
		// the serializer's escapes in a block's attribute JSON would go with
		// the slashes. A kind change leaves what the old kind kept (a body,
		// a file) in place and unread, as the admin's edit does.
		if ( $request->has_param( 'body' ) ) {
			wp_update_post(
				[
					'ID'           => $id,
					'post_content' => wp_slash( $this->bodyFrom( (string) $request['body'] ) ),
				]
			);
			$this->stampBody( $id );
		}
		if ( $request->has_param( 'external_url' ) ) {
			update_post_meta( $id, Meta::KEY_EXTERNAL_URL, esc_url_raw( (string) $request['external_url'] ) );
		}
		// Whose roles it reaches is part of who it reaches: held, with the rest
		// of the audience, while staff have shared it beyond the author's part.
		if ( $request->has_param( 'allowed_roles' ) && ( $scope->isAdmin || ! $scope->isSharedFurther( $id ) ) ) {
			update_post_meta( $id, Meta::KEY_ROLES, array_values( array_map( 'sanitize_key', (array) $request['allowed_roles'] ) ) );
		}

		$this->applyAudience( $id, $request, $scope );
	}

	/**
	 * Resources store audience as post-meta arrays. Admins write whatever they send;
	 * delegated authors are forced to the scope's organization (no standalone
	 * targeting) and their sub-group selection is clamped (a leader to the
	 * sub-group they lead there). One staff shared beyond that part keeps its
	 * audience through their saves.
	 */
	private function applyAudience( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'org_ids' ) ) {
				update_post_meta( $id, Meta::KEY_ORGS, array_values( array_map( 'absint', (array) $request['org_ids'] ) ) );
			}
			if ( $request->has_param( 'standalone_member_ids' ) ) {
				update_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, array_values( array_map( 'absint', (array) $request['standalone_member_ids'] ) ) );
			}
			// A sub-group no picker shows stays unless the save lifts the
			// limit (ContentController::gateAfterSave()).
			$lift = ContentController::liftsDeletedGate( $request );
			if ( $request->has_param( 'subgroup_ids' ) || $lift ) {
				$proposed = array_map( 'absint', (array) ( $request['subgroup_ids'] ?? [] ) );
				$orgIds   = self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) );
				$memIds   = self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) );
				// A sub-group narrows the audience it belongs to. With nobody
				// listed the resource is for every member, and any sub-group can
				// narrow that.
				$valid = $orgIds || $memIds
					? ContentController::filterSubgroupsByAudience( $proposed, $orgIds, $memIds )
					: ContentController::existingSubgroups( $proposed );
				update_post_meta( $id, Meta::KEY_SUBGROUPS, ContentController::gateAfterSave( self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) ), $valid, $lift, $request->has_param( 'subgroup_ids' ) ) );
			}
			return;
		}

		// A resource staff shared beyond the author's part keeps its audience
		// whole through the author's saves (AuthorScope::isSharedFurther()).
		if ( $scope->isSharedFurther( $id ) ) {
			return;
		}
		$orgIds = $scope->clampOrgIds( [] );
		update_post_meta( $id, Meta::KEY_ORGS, $orgIds );
		update_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, [] );

		if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
			$proposed = $scope->subgroupIdsForSave( $id, $request->has_param( 'subgroup_ids' ) ? (array) $request['subgroup_ids'] : null );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgIds, [] );
			// A sub-group their form cannot show stays (gateAfterSave()).
			update_post_meta( $id, Meta::KEY_SUBGROUPS, ContentController::gateAfterSave( self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) ), $valid, false ) );
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Resource not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		// A client author is told of their own part of the audience alone
		// (Portal\AudienceShown); staff of all of it.
		$caller = wp_get_current_user();
		$post   = get_post( $id );
		$orgIds = AudienceShown::orgs( $caller, self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) ) );
		$memIds = AudienceShown::members( $caller, self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) ) );
		$sgAll  = self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) );
		// A picker is handed the published ones (AudienceShown::subgroups()),
		// and a save keeps the rest (ContentController::gateAfterSave()).
		$sgIds  = AudienceShown::subgroups( $caller, $sgAll );
		$author = $post ? get_userdata( (int) $post->post_author ) : false;

		return [
			'id'                    => $id,
			// As stored: the detail saves it back.
			'title'                 => (string) get_post_field( 'post_title', $id, 'raw' ),
			'status'                => (string) $post?->post_status,
			'kind'                  => Meta::kindOf( $id ),
			'description'           => (string) get_post_meta( $id, Meta::KEY_DESCRIPTION, true ),
			'file_id'               => (int) get_post_meta( $id, Meta::KEY_FILE_ID, true ),
			'external_url'          => (string) get_post_meta( $id, Meta::KEY_EXTERNAL_URL, true ),
			// A guide's body, block markup as the editor saves it.
			'body'                  => (string) get_post_field( 'post_content', $id, 'raw' ),
			'org_ids'               => $orgIds,
			'standalone_member_ids' => $memIds,
			'subgroup_ids'          => $sgIds,
			// Sub-groups no picker shows that are all it is limited to: the
			// detail says the limit holds and offers to lift it (staff's).
			'subgroups_unavailable' => AudienceShown::whole( $caller ) ? ContentController::unavailableGate( $sgAll ) : 0,
			'allowed_roles'         => array_values( array_filter( array_map( 'sanitize_key', (array) get_post_meta( $id, Meta::KEY_ROLES, true ) ) ) ),
			'edit_url'              => admin_url( 'admin.php?page=monstera-resources&id=' . $id ),
			// The head and the sidebar (comp 135).
			'modified'              => (string) get_post_modified_time( 'c', true, $id ),
			'author_name'           => $author ? UserMeta::fullName( $author ) : '',
			// A delegated author (an organization manager) adds resources from
			// the portal's Manage tab; an admin adds them here.
			'from_portal'           => $author && ! user_can( $author, Capabilities::CAP_MANAGE_MONSTERA ),
			'portal_url'            => Routing::url( Routing::ROUTE_RESOURCES ),
			// "View in portal" (comp 135): a live guide has a page of its own,
			// a live link or file is seen on the Resources page, and a draft
			// is nowhere a member looks yet.
			'view_url'              => $this->viewUrl( $id, (string) $post?->post_status ),
			'org_names'             => array_values( array_filter( array_map( static fn ( int $orgId ): string => (string) get_the_title( $orgId ), $orgIds ) ) ),
			'file'                  => $this->fileFacts( (int) get_post_meta( $id, Meta::KEY_FILE_ID, true ) ),
			// Opens are logged while Reporting is on.
			// Staff alone: the count takes in everyone it reached.
			'facts'                 => [ 'opens_30d' => AudienceShown::whole( $caller ) ? $this->factOf( \Monstera\Core\Modules::REPORTING, fn (): int => $this->opensLast30Days( $id ) ) : null ],
			'saved'                 => $this->savedStamp( $id ),
		];
	}

	/**
	 * The attached file's name, kind and size, for the file picker, or null.
	 *
	 * @return array{id: int, name: string, ext: string, size: int, label: string}|null
	 */
	private function fileFacts( int $attachmentId ): ?array {
		return Files::facts( $attachmentId );
	}

	/**
	 * How many times members opened each resource in the last 30 days, in
	 * one read of the log.
	 *
	 * @param array<int, int|string> $ids
	 * @return array<int, int> By resource id; those never opened are absent.
	 */
	private function opensLast30DaysOf( array $ids ): array {
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids ) {
			return [];
		}
		global $wpdb;
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- counts from Monstera's own log, one read per list load.
			$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per id, spread in below.
				'SELECT object_id, COUNT(*) AS n FROM %i WHERE object_type = %s AND event_type IN (%s, %s) AND occurred_at >= %s AND object_id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ') GROUP BY object_id', // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- one %d per id, spread in below.
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				'resource',
				// A link or a file is opened through the Opener; a guide is read
				// on its own page (Reporting\Tracking).
				'resource_opened',
				'guide_viewed',
				gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ),
				...$ids
			),
			ARRAY_A
		);
		$out = [];
		foreach ( $rows as $row ) {
			$out[ (int) $row['object_id'] ] = (int) $row['n'];
		}
		return $out;
	}

	/** How many times members opened the resource in the last 30 days. */
	private function opensLast30Days( int $id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a count from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE object_type = %s AND object_id = %d AND event_type IN (%s, %s) AND occurred_at >= %s',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				'resource',
				$id,
				'resource_opened',
				'guide_viewed',
				gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS )
			)
		);
	}

	/**
	 * @param array<int, int> $memIds
	 * @param array<int, int> $orgIds
	 */
	private function summarizeAccess( array $orgIds, array $memIds ): string {
		$parts = [];
		if ( $orgIds ) {
			$parts[] = sprintf(
				/* translators: %d count */
				_n( '%d org', '%d orgs', count( $orgIds ), 'monstera' ),
				count( $orgIds )
			);
		}
		if ( $memIds ) {
			$parts[] = sprintf(
				/* translators: %d count */
				_n( '%d standalone member', '%d standalone members', count( $memIds ), 'monstera' ),
				count( $memIds )
			);
		}
		return $parts ? implode( ' + ', $parts ) : (string) __( 'All members', 'monstera' );
	}
}
