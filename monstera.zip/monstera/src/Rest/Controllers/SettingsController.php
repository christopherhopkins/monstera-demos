<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Admin\Menu;
use Monstera\Admin\Onboarding;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\UseCase;
use Monstera\Integrations\Detector;
use Monstera\Members\UserMeta;
use Monstera\Notifications\TemplateEngine;
use Monstera\Support\Inbox;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * What the Settings page reads and saves, and the first-run question on the
 * dashboard, which chooses a preset or skips.
 *
 * Settings are a Team manager's and a WordPress administrator's (People-model
 * track, FR2), so every route here asks for monstera_manage_settings, the
 * reads with the writes: nothing outside the Settings page and the first-run
 * question calls them. The one setting the other pages ask about, which
 * modules are on, they are handed with the page (Core\Assets). A Team member
 * is told who may in a sentence.
 */
final class SettingsController extends BaseController {

	public function register(): void {
		$managers = $this->permissionManagers( Capabilities::CAP_MANAGE_SETTINGS, __( 'Only a Team manager can change settings.', 'monstera' ) );

		register_rest_route(
			$this->restNamespace,
			'/settings/general',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'getGeneral' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'saveGeneral' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/settings/modules',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'listModules' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'saveModules' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/settings/integrations',
			[
				'methods'             => 'GET',
				'permission_callback' => $managers,
				'callback'            => [ $this, 'integrations' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/settings/notifications',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'getNotifications' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'saveNotifications' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/settings/use-case',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'getUseCase' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $managers,
					'callback'            => [ $this, 'setUseCase' ],
					'args'                => [
						'use_case' => [
							'type'     => 'string',
							'enum'     => self::USE_CASES,
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/settings/onboarding/skip',
			[
				'methods'             => 'POST',
				'permission_callback' => $managers,
				'callback'            => [ $this, 'skipOnboarding' ],
			]
		);
	}

	/** The presets onboarding and Settings offer (comp 92). */
	private const USE_CASES = [ 'agency', 'association', 'standalone' ];

	/**
	 * Every save records who saved and when, for the page's "Saved <date>
	 * by <name>" line.
	 */
	private function stamp(): void {
		// Only the Settings page reads it, so it stays out of the autoloaded options.
		update_option(
			'monstera_settings_saved',
			[
				'at'      => gmdate( 'c' ),
				'user_id' => get_current_user_id(),
			],
			false
		);
	}

	/**
	 * @return array{at: string, by: string}|array{}
	 */
	private function saved(): array {
		$stamp = get_option( 'monstera_settings_saved' );
		if ( ! is_array( $stamp ) || empty( $stamp['at'] ) ) {
			return [];
		}
		$user = get_userdata( (int) ( $stamp['user_id'] ?? 0 ) );
		return [
			'at' => (string) $stamp['at'],
			'by' => $user ? UserMeta::fullName( $user ) : '',
		];
	}

	/**
	 * What members call content, from the labels option the Content post
	 * type reads; '' means the default.
	 */
	private function contentLabel(): string {
		$labels = get_option( 'monstera_content_labels', [] );
		return is_array( $labels ) ? trim( (string) ( $labels['name'] ?? '' ) ) : '';
	}

	/**
	 * Whether a content label would repeat another page's name: in the admin
	 * rail, or in the portal's tabs and navigation, where Resources is the
	 * forms library. The rail's group headings ("People", "Work") count too,
	 * or the Work heading would sit over a page called Work. Every page
	 * counts, including one whose module is off
	 * today, since switching it on later would bring the clash back. Names
	 * are compared in the saving admin's language, the site's and English
	 * (people read the rail and the portal in their own), case-blind and
	 * singular or plural alike.
	 */
	private function namesAnotherPage( string $label ): bool {
		$fold  = static fn ( string $name ): string => rtrim( mb_strtolower( $name ), 's' );
		$taken = [];
		foreach ( array_unique( [ determine_locale(), get_locale(), 'en_US' ] ) as $locale ) {
			$switched = switch_to_locale( $locale );
			$names    = array_merge(
				array_column( array_diff_key( Menu::pages( true ), [ 'monstera-content' => true ] ), 'title' ),
				array_filter( array_map( [ Menu::class, 'groupLabel' ], Menu::GROUPS ) ),
				[
					__( 'Resources', 'monstera' ),
					__( 'Directory', 'monstera' ),
					__( 'Manage', 'monstera' ),
					__( 'Profile', 'monstera' ),
					__( 'Members', 'monstera' ),
				]
			);
			if ( $switched ) {
				restore_previous_locale();
			}
			foreach ( $names as $name ) {
				$taken[] = $fold( (string) $name );
			}
		}
		return in_array( $fold( $label ), $taken, true );
	}

	/**
	 * @return array<string, mixed>
	 */
	public function getGeneral(): array {
		return [
			'portal_prefix'          => (string) get_option( 'monstera_portal_prefix', 'portal' ),
			'retention_days'         => (int) get_option( 'monstera_retention_days', 90 ),
			'renewal_window'         => (int) get_option( 'monstera_renewal_window', 60 ),
			// Accessibility statement (EAA): site-specific parts of /portal/accessibility/.
			'a11y_contact_email'     => (string) get_option( 'monstera_a11y_contact_email', (string) get_option( 'admin_email' ) ),
			'a11y_known_limitations' => (string) get_option( 'monstera_a11y_known_limitations', '' ),
			'a11y_last_reviewed'     => (string) get_option( 'monstera_a11y_last_reviewed', '' ),
			'content_label'          => $this->contentLabel(),
			// Where support reaches staff by email, and what the portal shows
			// under "Prefer email?": the address in use, the one someone chose
			// (empty when nobody has) and the admin email that stands in.
			'support_email'          => Inbox::email(),
			'support_email_custom'   => sanitize_email( (string) get_option( Inbox::EMAIL_OPTION, '' ) ),
			'support_email_default'  => (string) get_option( 'admin_email' ),
			'saved'                  => $this->saved(),
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function saveGeneral( WP_REST_Request $request ): array|WP_Error {
		$data = $request->get_json_params();
		if ( isset( $data['content_label'] ) ) {
			// Any run of spaces, a no-break one included, is one space.
			$label = trim( (string) preg_replace( '/[\s\p{Z}]+/u', ' ', mb_substr( sanitize_text_field( (string) $data['content_label'] ), 0, 40 ) ) );
			if ( '' !== $label && $this->namesAnotherPage( $label ) ) {
				return $this->invalidField(
					'content_label',
					sprintf(
						/* translators: %s: the label the admin typed, e.g. "Reports" */
						__( '“%s” already names a page in the menu or the portal, so choose another word.', 'monstera' ),
						$label
					)
				);
			}
			if ( '' === $label ) {
				delete_option( 'monstera_content_labels' );
			} else {
				update_option( 'monstera_content_labels', [ 'name' => $label ] );
			}
		}
		if ( isset( $data['support_email'] ) && ! Inbox::setEmail( (string) $data['support_email'] ) ) {
			return $this->invalidField( 'support_email', __( 'That is not an email address. Leave it empty to use the site\'s admin email.', 'monstera' ) );
		}
		if ( isset( $data['portal_prefix'] ) ) {
			// A prefix with nothing left of it as a slug would take the portal
			// off its address; the one in use stays.
			$prefix = sanitize_title( (string) $data['portal_prefix'] );
			if ( '' !== $prefix ) {
				update_option( 'monstera_portal_prefix', $prefix );
			}
		}
		if ( isset( $data['retention_days'] ) ) {
			update_option( 'monstera_retention_days', max( 7, (int) $data['retention_days'] ) );
		}
		if ( isset( $data['renewal_window'] ) ) {
			update_option( 'monstera_renewal_window', max( 7, (int) $data['renewal_window'] ) );
		}
		if ( isset( $data['a11y_contact_email'] ) ) {
			$email = sanitize_email( (string) $data['a11y_contact_email'] );
			if ( '' !== $email && is_email( $email ) ) {
				update_option( 'monstera_a11y_contact_email', $email );
			}
		}
		if ( isset( $data['a11y_known_limitations'] ) ) {
			update_option( 'monstera_a11y_known_limitations', sanitize_textarea_field( (string) $data['a11y_known_limitations'] ) );
		}
		if ( isset( $data['a11y_last_reviewed'] ) ) {
			$date = trim( (string) $data['a11y_last_reviewed'] );
			if ( '' === $date ) {
				delete_option( 'monstera_a11y_last_reviewed' );
			} elseif ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) && wp_checkdate( (int) substr( $date, 5, 2 ), (int) substr( $date, 8, 2 ), (int) substr( $date, 0, 4 ), $date ) ) {
				update_option( 'monstera_a11y_last_reviewed', $date );
			}
		}
		$this->stamp();
		return $this->getGeneral();
	}

	/**
	 * @return array<int, array<string, bool|string>>
	 */
	public function listModules(): array {
		$active = (array) get_option( 'monstera_active_modules', [ 'forms', 'reporting', 'projects', 'alerts', 'support' ] );
		return [
			[
				'key'         => 'projects',
				'available'   => true,
				'label'       => __( 'Projects', 'monstera' ),
				'description' => __( 'First-class projects with status, dates, team, deliverables, and an intake/discovery form. Centerpiece of the agency use case.', 'monstera' ),
				'enabled'     => in_array( 'projects', $active, true ),
				'core'        => false,
			],
			[
				'key'         => 'alerts',
				'available'   => true,
				'label'       => __( 'Alerts', 'monstera' ),
				'description' => __( 'Post broadcast banners across portals for outages, downtime, status changes. Optional email blast.', 'monstera' ),
				'enabled'     => in_array( 'alerts', $active, true ),
				'core'        => false,
			],
			[
				'key'         => 'support',
				'available'   => true,
				'label'       => __( 'Support requests', 'monstera' ),
				'description' => __( 'Members open requests in the portal, with screenshots and files, and follow the conversation there; staff reply from the admin, and each side is told by email. A conversation, not a helpdesk: no assignment, internal notes or SLAs.', 'monstera' ),
				'enabled'     => in_array( 'support', $active, true ),
				'core'        => false,
			],
			[
				'key'         => 'forms',
				'available'   => true,
				'label'       => __( 'Forms Library', 'monstera' ),
				'description' => __( 'Resource library with PDF, shortcode-embed, or external-link items.', 'monstera' ),
				'enabled'     => in_array( 'forms', $active, true ),
				'core'        => false,
			],
			[
				'key'         => 'reporting',
				'available'   => true,
				'label'       => __( 'Reporting', 'monstera' ),
				'description' => __( 'Activity log, dashboard widgets, CSV exporters, sub-group engagement.', 'monstera' ),
				'enabled'     => in_array( 'reporting', $active, true ),
				'core'        => false,
			],
			[
				'key'         => 'bills',
				'available'   => false,
				'label'       => __( 'Bills (view-only)', 'monstera' ),
				'description' => __( 'Read-only invoice list. Manual or webhook-driven status updates. Ships in a future release.', 'monstera' ),
				'enabled'     => false,
				'core'        => false,
			],
			[
				'key'         => 'payments',
				'available'   => false,
				'label'       => __( 'Payments (Stripe)', 'monstera' ),
				'description' => __( 'Dues forms, renewals, Stripe webhooks. Ships in a future release.', 'monstera' ),
				'enabled'     => false,
				'core'        => false,
			],
			[
				'key'         => 'forum',
				'available'   => false,
				'label'       => __( 'Forum & Messaging', 'monstera' ),
				'description' => __( 'Thread/reply forum + one-on-one DMs. Ships in a future release.', 'monstera' ),
				'enabled'     => false,
				'core'        => false,
			],
		];
	}

	/**
	 * The stored use case, whether onboarding is still pending, and the three
	 * presets with the modules each switches on and the content label it
	 * sets. A site that chose the old "both" keeps it; it is no longer offered.
	 *
	 * @return array<string, mixed>
	 */
	public function getUseCase(): array {
		return [
			'use_case'   => UseCase::current(),
			'onboarding' => Onboarding::isPending(),
			'available'  => UseCase::presets(),
		];
	}

	/**
	 * Applies a preset: its modules, its content label, and onboarding done.
	 * The route's enum refuses anything but the three presets.
	 *
	 * @return array<string, mixed>
	 */
	public function setUseCase( WP_REST_Request $request ): array {
		$useCase = (string) $request['use_case'];
		$modules = UseCase::apply( $useCase );
		$this->stamp();

		return [
			'use_case' => $useCase,
			'modules'  => $modules,
			'saved'    => $this->saved(),
		];
	}

	/**
	 * "Skip for now": remembered, so the dashboard stops asking.
	 *
	 * @return array{skipped: bool}
	 */
	public function skipOnboarding(): array {
		Onboarding::skip();
		return [ 'skipped' => true ];
	}

	/**
	 * @return array<string, mixed>
	 */
	public function saveModules( WP_REST_Request $request ): array {
		$data = $request->get_json_params();
		// Only a module that has shipped can be on: the list offers no switch
		// for the others, and a request that names one is not taken at its word.
		$shipped = array_column( array_filter( $this->listModules(), static fn ( array $module ): bool => true === $module['available'] ), 'key' );
		$asked   = array_map( 'sanitize_key', (array) ( $data['modules'] ?? [] ) );
		$mods    = array_values( array_filter( $asked, static fn ( string $key ): bool => in_array( $key, $shipped, true ) ) );
		update_option( 'monstera_active_modules', $mods );
		// Clear the per-request cache so any code that reads module state
		// later in the same request (e.g. the listModules response) sees
		// the change immediately.
		Modules::invalidateCache();
		$this->stamp();
		return [
			'modules' => $mods,
			'saved'   => $this->saved(),
		];
	}

	/**
	 * @return array<int, array{key: string, label: string, detected: bool, message: string}>
	 */
	public function integrations(): array {
		return ( new Detector() )->report();
	}

	/**
	 * Notification template editor backing data.
	 *
	 * Returns one entry per known event with: current subject/body, the
	 * default subject/body (so the UI can show "Reset to default"), the
	 * tokens available for this event, and a human label/help line.
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function getNotifications(): array {
		$overrides = (array) get_option( 'monstera_notification_templates', [] );

		$events = [
			TemplateEngine::EVENT_NEW_CONTENT             => [
				'label'  => __( 'Content published', 'monstera' ),
				'help'   => __( 'Sent the first time a content item is published to a member who can see it.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'content_title', 'content_url', 'summary', 'portal_url' ],
			],
			TemplateEngine::EVENT_UPDATED_CONTENT         => [
				'label'  => __( 'Content updated', 'monstera' ),
				'help'   => __( 'Sent when a content item is updated after the initial publish.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'content_title', 'content_url', 'summary' ],
			],
			TemplateEngine::EVENT_CONTENT_UNLOCKED        => [
				'label'  => __( 'Content unlocked', 'monstera' ),
				'help'   => __( 'Sent when a member becomes eligible to see content that was previously gated from them.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'content_title', 'content_url' ],
			],
			TemplateEngine::EVENT_WELCOME                 => [
				'label'  => __( 'Welcome to a new member', 'monstera' ),
				'help'   => __( 'Sent on first account creation. Includes a password-reset link.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'portal_url', 'login_url' ],
			],
			TemplateEngine::EVENT_ADDED_TO_ORG            => [
				'label'  => __( 'Added to an organization', 'monstera' ),
				'help'   => __( 'Sent when someone who already has an account is invited into another organization. It names that organization only.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'user_company', 'site_name', 'portal_url', 'login_url' ],
			],
			TemplateEngine::EVENT_TEAM_WELCOME            => [
				'label'  => __( 'Welcome to the team', 'monstera' ),
				'help'   => __( 'Sent when a new account is added to the team, and when a welcome is resent to someone on it. Includes a link to set a password.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'team_role', 'site_name', 'set_password_url', 'admin_url', 'login_url' ],
			],
			TemplateEngine::EVENT_EXPIRY_WARNING          => [
				'label'  => __( 'Membership expiring soon', 'monstera' ),
				'help'   => __( 'Sent at 30/14/7/1 day(s) before expiry per the daily expiration sweep.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'user_company', 'site_name', 'expiry_date', 'portal_url' ],
			],
			TemplateEngine::EVENT_EXPIRED                 => [
				'label'  => __( 'Membership expired', 'monstera' ),
				'help'   => __( 'Sent on the day membership expires.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'user_company', 'site_name', 'expiry_date', 'portal_url' ],
			],
			TemplateEngine::EVENT_STANDALONE_EXPIRY_WARNING => [
				'label'  => __( 'Standalone membership expiring soon', 'monstera' ),
				'help'   => __( 'Sent to a standalone member 30, 14, 7 and 1 day(s) before their own membership expires, by the daily expiration sweep. It names no organization.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'expiry_date', 'profile_url', 'portal_url' ],
			],
			TemplateEngine::EVENT_STANDALONE_EXPIRED      => [
				'label'  => __( 'Standalone membership expired', 'monstera' ),
				'help'   => __( 'Sent to a standalone member the day after the last day of their own membership, when their portal pauses until it is renewed. It names no organization.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'expiry_date', 'profile_url', 'portal_url' ],
			],
			TemplateEngine::EVENT_ORG_SUSPENDED           => [
				'label'  => __( 'Organization suspended', 'monstera' ),
				'help'   => __( 'Sent to all members of an org when its status flips to Suspended.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'user_company', 'site_name' ],
			],
			TemplateEngine::EVENT_ALERT_POSTED            => [
				'label'  => __( 'Alert posted', 'monstera' ),
				'help'   => __( 'Sent once, when an alert is first posted with "Also send by email" on, to each member it reaches.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'alert_title', 'alert_body', 'portal_url' ],
			],
			TemplateEngine::EVENT_INTAKE_SUBMITTED        => [
				'label'  => __( 'Discovery submitted', 'monstera' ),
				'help'   => __( 'Sent to the site\'s admin email when a client submits discovery answers that changed or adds files. The monstera/intake_recipients filter changes who receives it.', 'monstera' ),
				'tokens' => [ 'site_name', 'project_title', 'submitter_name', 'changes', 'project_url' ],
			],
			TemplateEngine::EVENT_SUPPORT_RECEIVED        => [
				'label'  => __( 'Support: request received', 'monstera' ),
				'help'   => __( 'Sent to a member when they open a support request.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'request_ref', 'request_subject', 'request_url', 'support_email', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_REPLIED         => [
				'label'  => __( 'Support: staff replied', 'monstera' ),
				'help'   => __( 'Sent to the member each time staff reply on their request. The reply is in the email; its files are named, not attached.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'staff_name', 'request_ref', 'request_subject', 'reply', 'reply_files', 'request_url', 'support_email', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_RESOLVED        => [
				'label'  => __( 'Support: resolved by staff', 'monstera' ),
				'help'   => __( 'Sent to the member when staff mark their request resolved.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'staff_name', 'request_ref', 'request_subject', 'request_url', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_CLOSED          => [
				'label'  => __( 'Support: closed by staff', 'monstera' ),
				'help'   => __( 'Sent to the member when staff close their request.', 'monstera' ),
				'tokens' => [ 'user_first_name', 'site_name', 'request_ref', 'request_subject', 'request_url', 'support_url', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_NEW             => [
				'label'  => __( 'Support inbox: new request', 'monstera' ),
				'help'   => __( 'Sent to the Support email when a member opens a request. The monstera/support_recipients filter changes who receives it.', 'monstera' ),
				'tokens' => [ 'site_name', 'member_name', 'member_email', 'request_ref', 'request_subject', 'request_priority', 'request_context', 'message', 'message_files', 'admin_url', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_MEMBER_REPLIED  => [
				'label'  => __( 'Support inbox: member replied', 'monstera' ),
				'help'   => __( 'Sent to the Support email each time a member replies on their request.', 'monstera' ),
				'tokens' => [ 'site_name', 'member_name', 'request_ref', 'request_subject', 'message', 'message_files', 'admin_url', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_MEMBER_RESOLVED => [
				'label'  => __( 'Support inbox: resolved by the member', 'monstera' ),
				'help'   => __( 'Sent to the Support email when a member marks their own request resolved.', 'monstera' ),
				'tokens' => [ 'site_name', 'member_name', 'request_ref', 'request_subject', 'admin_url', 'user_company' ],
			],
			TemplateEngine::EVENT_SUPPORT_PRIORITY_RAISED => [
				'label'  => __( 'Support inbox: priority raised', 'monstera' ),
				'help'   => __( 'Sent to the Support email when a member makes their request more urgent. A lowered priority sends nothing.', 'monstera' ),
				'tokens' => [ 'site_name', 'member_name', 'request_ref', 'request_subject', 'old_priority', 'request_priority', 'admin_url', 'user_company' ],
			],
		];

		$defaults = self::templateDefaults();

		$items = [];
		foreach ( $events as $key => $meta ) {
			$override = is_array( $overrides[ $key ] ?? null ) ? $overrides[ $key ] : [];
			$items[]  = [
				'key'             => $key,
				'label'           => $meta['label'],
				'help'            => $meta['help'],
				'tokens'          => $meta['tokens'],
				'subject'         => isset( $override['subject'] ) ? (string) $override['subject'] : (string) $defaults[ $key ]['subject'],
				'body'            => isset( $override['body'] ) ? (string) $override['body'] : (string) $defaults[ $key ]['body'],
				'default_subject' => (string) $defaults[ $key ]['subject'],
				'default_body'    => (string) $defaults[ $key ]['body'],
				'overridden'      => isset( $override['subject'] ) || isset( $override['body'] ),
			];
		}

		return [ 'items' => $items ];
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function saveNotifications( WP_REST_Request $request ): array {
		$data     = (array) $request->get_json_params();
		$incoming = (array) ( $data['templates'] ?? [] );
		$defaults = self::templateDefaults();
		$override = (array) get_option( 'monstera_notification_templates', [] );

		foreach ( $incoming as $entry ) {
			if ( ! is_array( $entry ) || empty( $entry['key'] ) ) {
				continue;
			}
			$key = sanitize_key( (string) $entry['key'] );
			if ( ! isset( $defaults[ $key ] ) ) {
				continue;
			}

			$reset = ! empty( $entry['reset'] );
			if ( $reset ) {
				unset( $override[ $key ] );
				continue;
			}

			$subject = isset( $entry['subject'] ) ? sanitize_text_field( (string) $entry['subject'] ) : '';
			$body    = isset( $entry['body'] ) ? wp_kses_post( (string) $entry['body'] ) : '';
			// Empty fields fall back to the default — store override only when at least one differs.
			if ( '' === $subject && '' === $body ) {
				unset( $override[ $key ] );
				continue;
			}
			$override[ $key ] = [
				'subject' => '' !== $subject ? $subject : $defaults[ $key ]['subject'],
				'body'    => '' !== $body ? $body : $defaults[ $key ]['body'],
			];
		}

		update_option( 'monstera_notification_templates', $override );
		$this->stamp();
		return array_merge( $this->getNotifications(), [ 'saved' => $this->saved() ] );
	}

	/**
	 * @return array<string, array{subject:string, body:string}>
	 */
	private static function templateDefaults(): array {
		return TemplateEngine::defaults();
	}
}
