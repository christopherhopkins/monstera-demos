<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\AccessControl\PortalGuard;
use Monstera\Content\Downloader;
use Monstera\Core\ToolRuns;
use Monstera\Forms\Accepts;
use Monstera\Forms\AlreadySent;
use Monstera\Forms\AnswersRefused;
use Monstera\Forms\Fields;
use Monstera\Forms\FilesRefused;
use Monstera\Forms\Meta;
use Monstera\Forms\PostType;
use Monstera\Forms\Repository;
use Monstera\Forms\Submissions;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Roster;
use Monstera\Reporting\Exporters\FormSubmissionsExporter;
use Monstera\Support\Files as Uploads;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * The submissions routes (Forms-and-resources track, FR10). A member sends
 * a built form as one multipart request, the answers as fields by question
 * key and a file question's files under its key, and is answered the
 * form's confirmation; the form refuses with the word its page uses (FR3:
 * closed, past due, already sent), is not found when it does not reach
 * them, and sends the answers back by field when one does not do, nothing
 * stored. Reading follows FR6: staff read every submission in full, an
 * organization's admins and managers read those sent through it (`?org=`)
 * in full for a form the organization built and as who-and-when for
 * staff's, and a member reads their own (`?mine=1`). One submission is
 * read by the same rule, the Downloader's (mayReadSubmission()), so the
 * answers and the files they name open to the same people. The CSV export
 * (FR8) is the full listing as a file, for staff and the leads who read
 * the answers, recorded in monstera_tool_runs as the other exports are.
 */
final class FormSubmissionsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/forms/(?P<id>\d+)/submissions',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionLoggedIn(),
					'callback'            => [ $this, 'index' ],
					'args'                => [
						'id'       => [
							'type'     => 'integer',
							'required' => true,
						],
						'org'      => [ 'type' => 'integer' ],
						'mine'     => [ 'type' => 'string' ],
						// The admin's section asks in pages (FR8): without
						// per_page the whole list, as before.
						'per_page' => [
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						],
						'page'     => [
							'type'    => 'integer',
							'minimum' => 1,
						],
						'search'   => [ 'type' => 'string' ],
					],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionLoggedIn(),
					'callback'            => [ $this, 'create' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/forms/(?P<id>\d+)/submissions/export',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'export' ],
				'args'                => [
					'id'  => [
						'type'     => 'integer',
						'required' => true,
					],
					'org' => [ 'type' => 'integer' ],
				],
			]
		);
		// The export's body is the file itself, not a JSON string of it.
		if ( ! has_filter( 'rest_pre_serve_request', [ self::class, 'serveCsv' ] ) ) {
			add_filter( 'rest_pre_serve_request', [ self::class, 'serveCsv' ], 10, 3 );
		}

		register_rest_route(
			$this->restNamespace,
			'/forms/(?P<id>\d+)/submissions/(?P<sid>\d+)',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'show' ],
				'args'                => [
					'id'  => [
						'type'     => 'integer',
						'required' => true,
					],
					'sid' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);
	}

	/**
	 * Send a form. 201 with the confirmation and the submission as stored.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function create( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$formId = (int) $request['id'];
		if ( ! self::isForm( $formId ) ) {
			return self::notFound();
		}
		$user   = wp_get_current_user();
		$accept = Accepts::for( $user, $formId );
		if ( Accepts::OK !== $accept ) {
			return self::refusedBecause( $accept );
		}

		// The answers: the body's fields, a JSON body's members, by question
		// key; the files under their question's key, as the page posts them.
		$values  = array_merge( (array) $request->get_json_params(), (array) $request->get_body_params() );
		$uploads = [];
		$posted  = $request->get_file_params();
		foreach ( Fields::fileKeys( Meta::fieldsOf( $formId ) ) as $key ) {
			$uploads[ $key ] = Uploads::normalise( $posted[ $key ] ?? null );
		}
		$dropped = Submissions::droppedForSize( Meta::fieldsOf( $formId ), $values || array_filter( $uploads ), (int) $request->get_header( 'content_length' ) );
		if ( $dropped ) {
			return self::invalidFields( $dropped );
		}
		// Each send emails the form's addresses: a member's are held to ten
		// in ten minutes (Submissions::sendLimitReached()).
		if ( Submissions::sendLimitReached( $user ) ) {
			return $this->tooMany( Submissions::saySendLimit() );
		}

		try {
			$row = Submissions::create( $formId, $user, $values, $uploads );
			Submissions::recordSend( $user );
		} catch ( AnswersRefused $refused ) {
			return self::invalidFields( $refused->errors );
		} catch ( FilesRefused $refused ) {
			return self::invalidFields( [ $refused->field() => $refused->reason() ] );
		} catch ( AlreadySent $twice ) {
			return self::refusedBecause( Accepts::ALREADY_SENT );
		} catch ( \RuntimeException $failure ) {
			return new WP_Error( 'monstera_not_stored', __( 'Your answers could not be stored. Try again.', 'monstera' ), [ 'status' => 500 ] );
		}

		return new WP_REST_Response(
			[
				'ok'           => true,
				'confirmation' => Meta::confirmationOf( $formId ),
				'submission'   => $this->row( $row, true ),
			],
			201
		);
	}

	/**
	 * The submissions to a form: all of them for staff, an organization's
	 * for its leads (`?org=`), the caller's own (`?mine=1`).
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function index( WP_REST_Request $request ): array|WP_Error {
		$formId = (int) $request['id'];
		if ( ! self::isForm( $formId ) ) {
			return self::notFound();
		}
		$user  = wp_get_current_user();
		$staff = $this->canManage();
		// Someone with no part in the form hears what a missing one says.
		if ( ! $staff && ! self::hasPart( $user, $formId ) ) {
			return self::notFound();
		}

		if ( self::flag( $request['mine'] ?? false ) ) {
			// Their own, on a form that reaches them: one that does not is
			// not theirs to know of, as the send route says.
			if ( ! $staff && ! self::reaches( $user, $formId ) ) {
				return self::notFound();
			}
			return $this->listing( $formId, Submissions::mine( $formId, (int) $user->ID ), true, $request );
		}

		$orgId = absint( $request['org'] ?? 0 );
		if ( $orgId > 0 ) {
			if ( ! $this->actsWithinOwnOrg( $orgId ) ) {
				return self::forbidden();
			}
			$ended = $staff ? null : $this->leadRefusal( $orgId );
			if ( $ended ) {
				return $ended;
			}
			// A form that does not reach the organization is not its leads'
			// to know of: not even its questions (the Manage page's rule).
			if ( ! $staff && ! self::reachesOrg( $formId, $orgId ) ) {
				return self::notFound();
			}
			return $this->listing( $formId, Submissions::forFormAndOrg( $formId, $orgId ), $staff || self::answersOpenToLeads( $formId ), $request );
		}

		if ( ! $staff ) {
			return self::forbidden();
		}
		return $this->listing( $formId, Submissions::forForm( $formId ), true, $request );
	}

	/**
	 * One submission: in full for those who may read it (the Downloader's
	 * rule), who-and-when for a lead of the organization it was sent
	 * through when the form is staff's.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$formId     = (int) $request['id'];
		$submission = self::isForm( $formId ) ? Submissions::find( (int) $request['sid'] ) : null;
		if ( ! $submission || (int) $submission['form_id'] !== $formId ) {
			return self::notFound();
		}
		$user = wp_get_current_user();
		if ( Downloader::mayReadSubmission( $user, $submission ) ) {
			return $this->row( $submission, true );
		}
		// A lead of the organization it was sent through, on a form that
		// reaches it, as the list has it.
		if ( (int) $submission['org_id'] > 0 && $this->actsWithinOwnOrg( (int) $submission['org_id'] ) && self::reachesOrg( $formId, (int) $submission['org_id'] ) ) {
			return $this->leadRefusal( (int) $submission['org_id'] ) ?? $this->row( $submission, false );
		}
		// Someone with no part in it is not told that it exists.
		return self::notFound();
	}

	/**
	 * The submissions as a CSV file (FR8): every one for staff, an
	 * organization's for a lead who reads the answers (`?org=`, a form
	 * the organization built). Recorded as a tool run with its row count.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function export( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$formId = (int) $request['id'];
		if ( ! self::isForm( $formId ) ) {
			return self::notFound();
		}
		$orgId = absint( $request['org'] ?? 0 );
		$staff = $this->canManage();
		if ( ! $staff && ! self::hasPart( wp_get_current_user(), $formId ) ) {
			return self::notFound();
		}
		if ( ! $staff && ( $orgId <= 0 || ! $this->actsWithinOwnOrg( $orgId ) || ! self::answersOpenToLeads( $formId ) ) ) {
			return self::forbidden();
		}
		$ended = $staff ? null : $this->leadRefusal( $orgId );
		if ( $ended ) {
			return $ended;
		}
		if ( ! $staff && ! self::reachesOrg( $formId, $orgId ) ) {
			return self::notFound();
		}

		$exporter    = new FormSubmissionsExporter();
		$submissions = $exporter->submissions( $formId, $orgId > 0 ? [ 'org' => $orgId ] : [] );
		$count       = count( $submissions );
		// The Tools page's record is staff's: a lead's export of their own
		// organization's rows would stand in for the site's (Phase 5 review).
		if ( $staff ) {
			/* translators: %d: how many rows the file holds */
			ToolRuns::record( 'export_form_submissions', 'ok', sprintf( _n( '%d row', '%d rows', $count, 'monstera' ), $count ) );
		}

		$response = new WP_REST_Response( $exporter->csvFor( $formId, $submissions ) );
		$response->header( 'Content-Type', 'text/csv; charset=utf-8' );
		$response->header( 'Content-Disposition', 'attachment; filename="' . $exporter->fileName( $formId ) . '"' );
		return $response;
	}

	/**
	 * Serves the export as the file it is: the REST server would otherwise
	 * JSON-encode the body as one string. Only this route's response, by
	 * its route and its type; every other response is left to the server.
	 */
	public static function serveCsv( bool $served, \WP_HTTP_Response $response, WP_REST_Request $request ): bool {
		if ( $served
			|| ! preg_match( '#/forms/\d+/submissions/export$#', (string) $request->get_route() )
			|| ! str_starts_with( (string) ( $response->get_headers()['Content-Type'] ?? '' ), 'text/csv' ) ) {
			return $served;
		}
		nocache_headers();
		echo (string) $response->get_data(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a CSV body, its cells neutralised by Reporting\Exporters\Csv; not HTML.
		return true;
	}

	/**
	 * Why an organization's lead reads nothing of it, or null: one in the
	 * trash is no organization of theirs, and one whose membership has
	 * ended answers as its Manage page does (BaseController::membershipEnded()).
	 */
	private function leadRefusal( int $orgId ): ?WP_Error {
		if ( ! $this->isOrgOnSite( $orgId ) ) {
			return self::notFound();
		}
		return PortalGuard::membershipExpired( $orgId ) ? self::membershipEnded( $orgId ) : null;
	}

	/**
	 * Whether the organization's leads read the answers: for a form one of
	 * its people built (not staff), as Downloader::mayReadSubmission() has it.
	 */
	private static function answersOpenToLeads( int $formId ): bool {
		return Meta::openToLeads( $formId );
	}

	/**
	 * Whether a built form reaches the organization (Reach::formOrgs()), so
	 * its leads may ask after what their members sent to it.
	 */
	private static function reachesOrg( int $formId, int $orgId ): bool {
		return Meta::KIND_BUILT === Meta::kindOf( $formId ) && in_array( $orgId, Reach::formOrgs( $formId ), true );
	}

	/**
	 * Whether the person has a part in the form: it reaches them, or they
	 * lead an organization it reaches. Anyone else is not told it exists.
	 */
	private static function hasPart( WP_User $user, int $formId ): bool {
		if ( self::reaches( $user, $formId ) ) {
			return true;
		}
		foreach ( Roster::orgIdsOf( (int) $user->ID ) as $orgId ) {
			if ( in_array( Roster::roleOf( (int) $user->ID, (int) $orgId ), [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true ) && self::reachesOrg( $formId, (int) $orgId ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether the form is among those the person can open: none for an
	 * account the portal is not for (AudienceList::listedFor()).
	 */
	private static function reaches( WP_User $user, int $formId ): bool {
		foreach ( ( new Repository() )->visibleTo( $user ) as $post ) {
			if ( (int) $post->ID === $formId ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The list, with what a sheet needs to lay the answers out: the
	 * questions as they are now and the keys of removed ones that still
	 * have answers (shown last). Who-and-when rows carry neither.
	 *
	 * @param list<array<string, mixed>> $rows
	 * @return array<string, mixed>
	 */
	private function listing( int $formId, array $rows, bool $full, ?WP_REST_Request $request = null ): array {
		$peopleOf = static fn ( array $listed ): array => array_values( array_unique( array_map( static fn ( array $row ): int => (int) $row['user_id'], $listed ) ) );
		// Removed questions with answers, from every row: a page or a search
		// leaves none of them out of the sheet.
		$removed = $full ? Submissions::removedKeys( $formId, $rows ) : [];
		$all     = count( $rows );
		// By name, and by address for a reader who is told the addresses
		// (a who-and-when reader is not).
		$search = $request ? mb_strtolower( trim( (string) ( $request['search'] ?? '' ) ) ) : '';
		if ( '' !== $search ) {
			// The search reads every sender's name: the people once, together.
			cache_users( $peopleOf( $rows ) );
			$rows = array_values(
				array_filter(
					$rows,
					static function ( array $row ) use ( $search, $full ): bool {
						$sender = get_userdata( (int) $row['user_id'] );
						if ( ! $sender ) {
							return false;
						}
						return str_contains( mb_strtolower( UserMeta::fullName( $sender ) ), $search )
							|| ( $full && str_contains( mb_strtolower( (string) $sender->user_email ), $search ) );
					}
				)
			);
		}
		$total   = count( $rows );
		$perPage = $request && $request->has_param( 'per_page' ) ? max( 1, min( 100, (int) $request['per_page'] ) ) : 0;
		if ( $perPage > 0 ) {
			$page = max( 1, (int) ( $request['page'] ?? 1 ) );
			$rows = array_slice( $rows, ( $page - 1 ) * $perPage, $perPage );
		}
		// The page's people and organizations once (Forms-and-resources
		// track, NFR Query cost). The list is paged here rather than in SQL:
		// the search by name and the removed questions' keys read every row,
		// and every read below is the page's alone.
		cache_users( $peopleOf( $rows ) );
		_prime_post_caches( array_values( array_unique( array_filter( array_map( static fn ( array $row ): int => (int) $row['org_id'], $rows ) ) ) ), false, false );
		// The page's files in one read (the Phase 3 review's note).
		$files = $full ? Submissions::filesOfMany( array_map( static fn ( array $row ): int => (int) $row['id'], $rows ) ) : [];
		$out   = [
			'items'     => array_map( fn ( array $row ): array => $this->row( $row, $full, $files[ (int) $row['id'] ] ?? [] ), $rows ),
			'full'      => $full,
			// What the search found, and the list before it (the export's).
			'total'     => $total,
			'total_all' => $all,
		];
		if ( $full ) {
			$out['fields']       = Meta::fieldsOf( $formId );
			$out['removed_keys'] = $removed;
		}
		return $out;
	}

	/**
	 * A submission as the reader may see it: who sent it, through which
	 * organization and when; in full, the answers by question key and the
	 * files by question, each with a link signed for the reader.
	 *
	 * @param array<string, mixed>                           $row     Submissions::find()'s shape.
	 * @param array<string, list<array<string, mixed>>>|null $filesOf Its files when the list read them, else read here.
	 * @return array<string, mixed>
	 */
	private function row( array $row, bool $full, ?array $filesOf = null ): array {
		$sender = get_userdata( (int) $row['user_id'] );
		$orgId  = (int) $row['org_id'];
		$out    = [
			'id'           => (int) $row['id'],
			'form_id'      => (int) $row['form_id'],
			'user_id'      => (int) $row['user_id'],
			'user_name'    => $sender ? UserMeta::fullName( $sender ) : '',
			'org_id'       => $orgId,
			'org_name'     => $orgId > 0 ? (string) get_the_title( $orgId ) : '',
			'submitted_at' => (string) $row['submitted_at'],
		];
		if ( ! $full ) {
			return $out;
		}
		// Who sent it, to write back to (comp 125's member column).
		$out['user_email'] = $sender ? (string) $sender->user_email : '';
		$files             = [];
		foreach ( $filesOf ?? Submissions::filesOf( (int) $row['id'] ) as $key => $list ) {
			foreach ( $list as $file ) {
				$files[ $key ][] = $file + [
					'size_label'   => (string) size_format( (int) $file['size'] ),
					'download_url' => Downloader::signedUrl( (int) $file['id'], get_current_user_id() ),
				];
			}
		}
		$out['answers'] = (object) $row['answers'];
		// An empty PHP array would read as a list.
		$out['files'] = (object) $files;
		return $out;
	}

	private static function isForm( int $id ): bool {
		$post = $id > 0 ? get_post( $id ) : null;
		return $post && PostType::SLUG === $post->post_type;
	}

	private static function notFound(): WP_Error {
		return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
	}

	private static function forbidden(): WP_Error {
		return new WP_Error( 'monstera_forbidden', __( 'Those submissions are not yours to read.', 'monstera' ), [ 'status' => 403 ] );
	}

	/** 409 with the word the form page uses (Forms\Accepts), or 404 when the form does not reach them. */
	private static function refusedBecause( string $why ): WP_Error {
		return match ( $why ) {
			Accepts::CLOSED       => new WP_Error( 'monstera_form_closed', __( 'This form is closed.', 'monstera' ), [ 'status' => 409 ] ),
			Accepts::DUE_PASSED   => new WP_Error( 'monstera_form_due_passed', __( 'This form\'s due date has passed.', 'monstera' ), [ 'status' => 409 ] ),
			Accepts::ALREADY_SENT => new WP_Error( 'monstera_form_already_sent', __( 'You have already sent this form.', 'monstera' ), [ 'status' => 409 ] ),
			default               => self::notFound(),
		};
	}

	/**
	 * 422 with every field's complaint, by question key, and the first as
	 * the message, for a client that places one.
	 *
	 * @param array<string, string> $errors
	 */
	private static function invalidFields( array $errors ): WP_Error {
		return new WP_Error(
			'monstera_invalid_fields',
			(string) reset( $errors ),
			[
				'status' => 422,
				'field'  => (string) array_key_first( $errors ),
				'errors' => $errors,
			]
		);
	}
}
