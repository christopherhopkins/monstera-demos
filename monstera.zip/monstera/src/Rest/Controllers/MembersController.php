<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Notifications\TemplateEngine;
use Monstera\Organizations\Roster;
use Monstera\Reporting\ActivityFeed;
use Monstera\Reporting\ActivityLog;
use Monstera\Rest\BulkRequest;
use Monstera\Rest\BulkResult;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Error;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class MembersController extends BaseController {

	/**
	 * The roles the Members list shows and whose accounts its routes may
	 * touch: every Monstera role, both staff roles among them. A WordPress
	 * administrator is deliberately absent: manage_monstera is not
	 * edit_users, so a Team manager must never be able to make one, become
	 * one, or take one over. Bulk actions reach no one else either.
	 *
	 * @var list<string>
	 */
	private const MEMBER_ROLES = [
		Capabilities::ROLE_ADMIN,
		Capabilities::ROLE_TEAM_MEMBER,
		Capabilities::ROLE_ORG_MANAGER,
		Capabilities::ROLE_MEMBER,
		Capabilities::ROLE_MEMBER_STANDALONE,
	];

	/**
	 * The roles these routes assign: the client roles. Neither team role is
	 * among them. They are the Team routes' to give and to take (People-model
	 * track, FR3), where a Team manager alone may and each change is
	 * recorded, while these routes gate on manage_monstera, which a Team
	 * member holds too: a team role assignable here would let a Team member
	 * make a Team manager (roleRefusal()).
	 *
	 * @var list<string>
	 */
	private const ASSIGNABLE_ROLES = [
		Capabilities::ROLE_ORG_MANAGER,
		Capabilities::ROLE_MEMBER,
		Capabilities::ROLE_MEMBER_STANDALONE,
	];

	// The Members list's two bulk actions on memberships. Each acts on one
	// organization and leaves every other membership alone; the action that
	// once moved people to an organization (reassign_org) is gone, and its
	// key is refused like any other the route does not know.
	private const BULK_ADD    = 'add_to_org';
	private const BULK_REMOVE = 'remove_from_org';

	/** The error code, and the bulk action's reason, for someone who already belongs to the organization. */
	private const ALREADY_MEMBER = 'monstera_already_member';

	/** How the bulk removal counts someone whose invitation ended with it, account and all. */
	private const UNINVITED = 'uninvited';

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/members',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/members/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/members/(?P<id>\d+)/resend',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'resend' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		// One person's memberships, for the member detail's Memberships
		// section (comp 121): add one, change its tier, end it. The team's
		// routes, both staff roles alike; an organization's own admins and
		// managers reach their roster through orgs/{id}/members instead.
		register_rest_route(
			$this->restNamespace,
			'/members/(?P<id>\d+)/memberships',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'addMembership' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/members/(?P<id>\d+)/memberships/(?P<org>\d+)',
			[
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'changeMembership' ],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'removeMembership' ],
				],
			]
		);

		$this->registerBulkRoute( '/members', [ self::BULK_ADD, self::BULK_REMOVE, 'resend_welcome' ], [ $this, 'bulkAction' ], [ $this, 'validateBulk' ], [ $this, 'bulkSummary' ] );
	}

	/**
	 * "Resend welcome" on the member detail (comp 121): the bulk action's
	 * path for one person, answering when it went.
	 *
	 * @return array{ok: bool, welcome_sent: array{at: string, delivered: bool}|null}|WP_Error
	 */
	public function resend( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$user = self::listed( $id );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$refused = $this->resendRefusal( $user );
		if ( $refused ) {
			return $refused;
		}
		if ( ! Provisioning::resendWelcome( $id, [ 'org_id' => Roster::primaryOrgOf( $id ) ] ) ) {
			return $this->invalidField( 'email', __( 'This member has no email address to send to.', 'monstera' ) );
		}
		return [
			'ok'           => true,
			'welcome_sent' => self::welcomeSent( $id ),
		];
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$standaloneOnly = (bool) $request->get_param( 'standalone_only' );

		$args = [
			'role__in' => self::MEMBER_ROLES,
			'number'   => -1,
			'fields'   => 'all',
		];

		// Whom the list shows is whom the single routes answer for and the
		// bulk actions reach: an account that holds administrator beside one
		// of these roles is WordPress's, and a row for it would open a detail
		// that says "not found". The query restates listed() and must change
		// with it; no row asks listed() itself.
		//
		// A detail page's picker reads this route for its options and says so
		// (picker=1). It is offered that account too, as it was before the
		// list left it out: a member made an administrator since is still on
		// the roster, in the sub-groups and on the project teams they joined,
		// and a picker that was not offered someone it holds would show them
		// without a name, or drop them and have the next save take them off.
		if ( ! $request->get_param( 'picker' ) ) {
			$args['role__not_in'] = [ 'administrator' ];
		}

		if ( $standaloneOnly ) {
			// Standalone is a role, not an absence to query for: the role
			// ceiling (Roster::syncRole()) gives it to a client person with
			// no membership and takes it back with their first, so the role
			// alone names everyone the memberships table has nothing on. A
			// staff account with no membership is not standalone.
			$args['role__in'] = [ Capabilities::ROLE_MEMBER_STANDALONE ];
		}

		// One organization's people: the sub-group detail's members picker
		// offers only the parent organization's (comp 123), and the project
		// detail's does the same. Everyone who belongs to it, whichever
		// organization came first for them. An empty include means everyone
		// to WP_User_Query, so an organization with nobody answers before the
		// query is built.
		$orgId = absint( $request->get_param( 'org_id' ) );
		if ( $orgId > 0 ) {
			$memberIds = Roster::memberIds( $orgId );
			if ( ! $memberIds ) {
				return [ 'items' => [] ];
			}
			$args['include'] = $memberIds;
		}

		$users = get_users( $args );
		// Every row names the person's organizations: one query for all the
		// memberships and one for all the organizations, not one per row or
		// per organization. Their photos the same.
		$ids = array_map( static fn ( WP_User $u ): int => (int) $u->ID, $users );
		Roster::prime( $ids );
		UserMeta::primePhotos( $ids );
		$orgIds = [];
		foreach ( $users as $u ) {
			foreach ( Roster::orgIdsOf( (int) $u->ID ) as $held ) {
				$orgIds[ $held ] = $held;
			}
		}
		_prime_post_caches( array_values( $orgIds ), false, false );
		$out = [];
		foreach ( $users as $u ) {
			$out[] = $this->shapeRow( $u );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$user = self::listed( (int) $request['id'] );
		return $user instanceof WP_Error ? $user : $this->shape( $user );
	}

	/**
	 * "Add to organization" on the member detail: one more membership for
	 * someone who has an account, at the tier named. With no tier named they
	 * join as a member, by the rule every writer that names none shares
	 * (Provisioning::tierImpliedByUser(): a manager made by role who belongs
	 * nowhere yet joins their first organization as its manager). The answer
	 * is the new membership as the detail lists it.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function addMembership( WP_REST_Request $request ): array|WP_Error {
		$user = self::listed( (int) $request['id'] );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$id    = (int) $user->ID;
		$orgId = absint( $request['org_id'] ?? 0 );
		// A request that names no organization got a field wrong, and is
		// told which, as POST members is (firstOrgError()); one that names an
		// organization there is not reads as not found.
		if ( $orgId <= 0 ) {
			return $this->invalidField( 'org_id', __( 'Say which organization this is for.', 'monstera' ) );
		}
		if ( ! $this->isPublishedOrg( $orgId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$tier = $this->tierAsked( $request['tier'] ?? Provisioning::tierImpliedByUser( $id ) );
		if ( $tier instanceof WP_Error ) {
			return $tier;
		}
		$refused = $this->join( $user, $orgId, $tier );
		if ( $refused ) {
			return $refused;
		}
		return [ 'ok' => true ] + self::membership( $id, $orgId );
	}

	/**
	 * The tier select of a membership row on the member detail: move the
	 * person to another tier of that one organization. The same tier again
	 * is answered as done and writes nothing. The team is not held to the
	 * rule that keeps an organization's last admin in place: it may leave an
	 * organization without one, being who can name the next.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function changeMembership( WP_REST_Request $request ): array|WP_Error {
		$id    = (int) $request['id'];
		$orgId = (int) $request['org'];
		$user  = self::memberIn( $id, $orgId );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		$tier = $this->tierAsked( $request['tier'] ?? null );
		if ( $tier instanceof WP_Error ) {
			return $tier;
		}
		Roster::setRole( $orgId, $id, $tier );
		return [ 'ok' => true ] + self::membership( $id, $orgId );
	}

	/**
	 * "Remove" on a membership row: that one membership ends. The account
	 * and every other membership stay, the organization's sub-groups and
	 * project teams let go of the person, and with none left they are a
	 * standalone member (the Roster derives the role). Someone who never
	 * signed in was only invited, and with none left the invitation ends
	 * instead. An account the invitation made is removed altogether, and
	 * the answer says so (`account_removed`): the page that asked is about
	 * a person who no longer exists, and goes back to the list to say what
	 * happened. An account that was there before stays: its link stops
	 * working, and one the invitation gave its client role to keeps none, so
	 * these routes no longer find it (Roster::remove(); the record's
	 * `invitation` says which beforehand). Nothing is read of the person
	 * after the Roster has answered. The team may remove an organization's
	 * last admin, as it may demote them.
	 *
	 * @return array{ok: bool, account_removed: bool}|WP_Error
	 */
	public function removeMembership( WP_REST_Request $request ): array|WP_Error {
		$id    = (int) $request['id'];
		$orgId = (int) $request['org'];
		$user  = self::memberIn( $id, $orgId );
		if ( $user instanceof WP_Error ) {
			return $user;
		}
		return [
			'ok'              => true,
			'account_removed' => Roster::INVITATION_ACCOUNT === Roster::remove( $orgId, $id ),
		];
	}

	/**
	 * Add someone to an organization on the team's word, or say why not.
	 * Who may be added is the rule an invitation of an existing account
	 * goes by (Provisioning::attachRefusal()), worded here for a caller who
	 * named the person: someone already there is a conflict, and the team's
	 * own accounts are assigned to organizations, never added. The seat
	 * limit holds for the team as it does on the organization detail's
	 * roster (Roster::joinRefusal()): they raise the limit first, they do
	 * not go over it.
	 *
	 * Nothing is sent. None of the team's ways of adding someone they name
	 * (this route, the bulk action, a new organization's first members)
	 * emails the person, and they are kept alike; the email that welcomes
	 * someone to an organization goes with an invitation by address, a
	 * client's from the portal or the team's from the organization detail
	 * (Provisioning::attachMember()). The Roster files the one activity row,
	 * credited to the caller, so none is recorded here.
	 *
	 * Nothing is answered as done that was not: the Roster says whether it
	 * wrote the membership. When it did not, a row another request wrote
	 * between the checks above and the write is answered as it would have
	 * been a moment later (already there, or the team's), and a write the
	 * database refused is an error, never {ok: true} with no membership in
	 * it.
	 */
	private function join( WP_User $user, int $orgId, string $tier ): ?WP_Error {
		$userId  = (int) $user->ID;
		$refused = self::joinRefused( Provisioning::attachRefusal( $orgId, $user ) );
		if ( $refused ) {
			return $refused;
		}
		$full = Roster::joinRefusal( $orgId, $userId );
		if ( null !== $full ) {
			return $this->invalidField( 'org_id', $full );
		}
		// Someone who has not signed in yet is a member in their own right
		// here, the list showing nobody else: noted, so a removal leaves them
		// one (Roster::endInvitation()).
		Roster::keepStanding( $userId );
		if ( Roster::add( $orgId, $userId, $tier ) ) {
			return null;
		}
		return self::joinRefused( Provisioning::attachRefusal( $orgId, $user ) ) ?? Provisioning::notWritten();
	}

	/**
	 * Provisioning::attachRefusal()'s answer in the words of a caller who
	 * named the person, or null when there is none.
	 *
	 * @param Provisioning::REFUSED_*|null $refusal
	 */
	private static function joinRefused( ?string $refusal ): ?WP_Error {
		if ( Provisioning::REFUSED_ALREADY === $refusal ) {
			return new WP_Error( self::ALREADY_MEMBER, __( 'Already in that organization.', 'monstera' ), [ 'status' => 409 ] );
		}
		if ( null !== $refusal ) {
			return new WP_Error( 'monstera_team_account', __( 'The team is assigned to organizations, not added to them.', 'monstera' ), [ 'status' => 422 ] );
		}
		return null;
	}

	/**
	 * An account the Members list shows, by its id, or the 404 for any
	 * other: a WordPress administrator's email, roles, sign-ins and
	 * memberships are not Monstera's to read or to change, whatever role
	 * the account holds beside that one. The one guard for whom these routes
	 * reach: the detail, the resend and the memberships routes answer the
	 * 404, and every bulk action skips the person. The list leaves the
	 * account out by its query, which restates this rule (index()) and must
	 * be changed with it, so none of them disagrees with another. Two things
	 * differ, each for its own reason: a picker's options name the account
	 * (index(), picker=1), since it may be on a roster already, and a save
	 * keeps its own rule (canEdit()): a WordPress administrator may still
	 * write to an account by its id, which no screen here opens.
	 */
	private static function listed( int $id ): WP_User|WP_Error {
		$user = self::member( $id );
		if ( ! $user instanceof WP_User || in_array( 'administrator', $user->roles, true ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Member not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return $user;
	}

	/**
	 * The person a membership route names, when they belong to the
	 * organization it names. Anything else is a 404, a membership that does
	 * not exist: changing a tier never adds someone, and ending a
	 * membership twice is not done twice.
	 */
	private static function memberIn( int $id, int $orgId ): WP_User|WP_Error {
		$user = self::listed( $id );
		if ( $user instanceof WP_User && ! Roster::isMemberOf( $id, $orgId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'That member is not in this organization.', 'monstera' ), [ 'status' => 404 ] );
		}
		return $user;
	}

	/**
	 * A person's memberships as the admin screens read them, oldest first:
	 * the organization and its name, the tier they hold there and the day
	 * the membership began, in ISO 8601 (UTC) as an organization's roster
	 * gives it. Empty for a standalone member, and for someone on the team
	 * who is assigned to organizations: an assignment is not a membership.
	 *
	 * @return list<array{org: int, name: string, tier: string, since: string}>
	 */
	private static function memberships( int $userId ): array {
		$out = [];
		foreach ( Roster::membershipsOf( $userId ) as $held ) {
			$out[] = [
				'org'   => $held['org_id'],
				'name'  => get_the_title( $held['org_id'] ),
				'tier'  => $held['tier'],
				'since' => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $held['since'] . ' UTC' ) ),
			];
		}
		return $out;
	}

	/**
	 * One of them: the person's membership of the organization.
	 *
	 * @return array{org: int, name: string, tier: string, since: string}|array{}
	 */
	private static function membership( int $userId, int $orgId ): array {
		foreach ( self::memberships( $userId ) as $held ) {
			if ( $held['org'] === $orgId ) {
				return $held;
			}
		}
		return [];
	}

	/**
	 * A new account, with its first organization when one is named. An
	 * account not made yet has no membership to add to, so this is the one
	 * route beside the memberships routes that takes an organization: the
	 * person joins it at the tier named, or at the one their role implies
	 * when none is (Provisioning::tierImpliedBy()), and the role then
	 * follows the tier. A tier is a tier in an organization: named with no
	 * organization it is still checked, so a wrong one is refused, and then
	 * has nothing to apply to. Every other organization is added from the
	 * detail (addMembership()). Each refusal comes before the account is
	 * made; the photo is checked here for that reason and stored with the
	 * other profile fields once the account exists (applyMutations()).
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$email = $this->checkedEmail( (string) ( $request['email'] ?? '' ), 0 );
		if ( $email instanceof WP_Error ) {
			return $this->heldOutsideMembers( (string) ( $request['email'] ?? '' ) ) ?? $email;
		}
		$orgErr = $this->firstOrgError( $request );
		if ( $orgErr ) {
			return $orgErr;
		}
		$tier = null;
		if ( $request->has_param( 'tier' ) ) {
			$tier = $this->tierAsked( $request['tier'] );
			if ( $tier instanceof WP_Error ) {
				return $tier;
			}
		}
		$photo = $this->checkedPhoto( $request );
		if ( $photo instanceof WP_Error ) {
			return $photo;
		}

		$first = sanitize_text_field( (string) ( $request['first_name'] ?? '' ) );
		$last  = sanitize_text_field( (string) ( $request['last_name'] ?? '' ) );
		$login = sanitize_user( (string) ( $request['username'] ?? $email ), true );

		$role    = (string) ( $request['role'] ?? '' ) ?: Capabilities::ROLE_MEMBER;
		$refused = self::roleRefusal( $role );
		if ( $refused ) {
			return $refused;
		}

		// The organization, when one is given, is joined through the roster as
		// the account is registered, ahead of the welcome email, so the email
		// can name it.
		$id = Provisioning::insertUser(
			[
				'user_login' => $login,
				'user_email' => $email,
				'user_pass'  => wp_generate_password( 20, true, true ),
				'first_name' => $first,
				'last_name'  => $last,
				'role'       => $role,
			],
			absint( $request['org_id'] ?? 0 ),
			$tier
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$user = get_user_by( 'id', (int) $id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'monstera_create_failed', __( 'User created but could not be loaded.', 'monstera' ), [ 'status' => 500 ] );
		}

		$this->applyMutations( $user, $request );
		return $this->shape( $user );
	}

	/**
	 * The refusal for a new member's address when the account that uses it
	 * is one the Members list does not show and an invitation would take: an
	 * address whose invitation ended with a removal (Roster::remove()), or
	 * an account from outside Monstera. Null for any other address.
	 *
	 * This route makes accounts and never takes one over, so the address is
	 * refused either way. But "another account uses it" sends the team to
	 * look for a person no list or picker shows, so this says where the
	 * address is taken back: an organization's invitation, which attaches
	 * the account and welcomes it (Provisioning::attachMember()).
	 */
	private function heldOutsideMembers( string $raw ): ?WP_Error {
		$holder = get_user_by( 'email', sanitize_email( $raw ) );
		if ( ! $holder instanceof WP_User || null !== self::member( (int) $holder->ID ) || null !== Provisioning::attachRefusal( 0, $holder ) ) {
			return null;
		}
		return $this->invalidField( 'email', __( 'An account that is not in Members already uses that email. Invite the address from an organization to add it.', 'monstera' ) );
	}

	/**
	 * A save of the member detail: the account's name and address, the
	 * profile fields, the expiry and the sub-groups. It reads no
	 * organization. The detail's Memberships section adds, changes and ends
	 * a membership through the memberships routes, which check who may join
	 * and how many fit (join()); a save that could also join through the
	 * Roster directly was a second door with fewer checks. An org_id sent
	 * all the same is not read, like any parameter the route does not know.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$user = get_user_by( 'id', $id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'monstera_not_found', __( 'Member not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$refused = $this->saveRefusal( $user );
		if ( $refused ) {
			return $refused;
		}
		$role = self::roleToAssign( $user, $request );
		if ( $role instanceof WP_Error ) {
			return $role;
		}
		// A role to assign is a client role by now, and the person is not on
		// the team (roleRefusal()). Chosen for someone who belongs to an
		// organization, it is a word about their tier there, not a role to
		// write (see tierFor()).
		$tier    = null;
		$follows = false;
		if ( null !== $role && Roster::orgIdsOf( $id ) ) {
			$tier = $this->tierFor( $user, $role );
			if ( $tier instanceof WP_Error ) {
				return $tier;
			}
			$follows = true;
			$role    = null;
		}
		$groupErr = $this->foreignSubgroupError( $id, $request );
		if ( $groupErr ) {
			return $groupErr;
		}
		$photo = $this->checkedPhoto( $request );
		if ( $photo instanceof WP_Error ) {
			return $photo;
		}
		// Checked with the other refusals, before anything is written.
		$email = null;
		if ( $request->has_param( 'email' ) ) {
			$email = $this->checkedEmail( (string) $request['email'], $id );
			if ( $email instanceof WP_Error ) {
				return $email;
			}
			// The detail sends its whole form, the address the account already
			// has with it; only another address is a change, and whose it is
			// to make is signInRefusal()'s to say.
			$moved = $email !== (string) $user->user_email ? $this->signInRefusal( $user, 'email' ) : null;
			if ( $moved ) {
				return $moved;
			}
		}

		// The role is not among the account's fields: wp_update_user() would
		// write it with set_role(), which replaces every role the account
		// holds, the site's editor role with them. It is swapped below.
		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'first_name' ) ) {
			$core['first_name'] = sanitize_text_field( (string) $request['first_name'] );
		}
		if ( $request->has_param( 'last_name' ) ) {
			$core['last_name'] = sanitize_text_field( (string) $request['last_name'] );
		}
		if ( null !== $email ) {
			$core['user_email'] = $email;
		}
		if ( $request->has_param( 'display_name' ) ) {
			$core['display_name'] = sanitize_text_field( (string) $request['display_name'] );
		}

		if ( count( $core ) > 1 ) {
			$updated = wp_update_user( $core );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}
		if ( null !== $role ) {
			// A client role for someone who belongs to no organization: one
			// client role for another, as the ceiling swaps them, and every
			// other role the account holds stays (Roster::swapClientRole()).
			Roster::swapClientRole( $user, $role );
		}
		if ( null !== $tier ) {
			// Their tier in the one organization they belong to (tierFor()
			// refuses the role of someone in several). The same tier again
			// writes nothing.
			Roster::setRole( Roster::primaryOrgOf( $id ), $id, $tier );
		}

		$this->applyMutations( $user, $request );
		if ( $follows ) {
			// The role the ceiling makes of the tiers they hold now, for the
			// saves above that wrote no membership: a role that had drifted
			// from a tier that did not move.
			Roster::syncRole( $id );
		}
		$this->stampAccountSaved( $id );
		// Re-fetch so any role / display name changes are reflected.
		$fresh = get_user_by( 'id', $id ) ?: $user;
		return $this->shape( $fresh );
	}

	/**
	 * Whether the caller may write to this account. edit_users or
	 * promote_users (a WordPress administrator) reaches anyone; a
	 * manage_monstera holder reaches only the accounts the Members list
	 * shows (the bulk route's rule), and never a WordPress administrator.
	 * Reaching an account is not the whole of it: the address of one that
	 * also works in WordPress by a role that is not Monstera's is asked
	 * about again where it is written, and where the welcome is sent
	 * (BaseController::signInRefusal()).
	 */
	private static function canEdit( WP_User $target ): bool {
		if ( current_user_can( 'edit_users' ) || current_user_can( 'promote_users' ) ) {
			return true;
		}
		return null !== self::member( (int) $target->ID )
			&& ! in_array( 'administrator', $target->roles, true );
	}

	/**
	 * Why the caller may not save this account, or null when they may: it is
	 * one they cannot reach at all (canEdit()), or a teammate's, which is a
	 * Team manager's to write to (BaseController::teammateRefusal()). The one
	 * answer for the save itself and for what the detail tells its reader
	 * beforehand (allowed()), so the screen offers a Save exactly where the
	 * route would take one.
	 */
	private function saveRefusal( WP_User $target ): ?WP_Error {
		if ( ! self::canEdit( $target ) ) {
			return new WP_Error( 'monstera_forbidden', __( 'You cannot edit this account.', 'monstera' ), [ 'status' => 403 ] );
		}
		return self::teammateRefusal( $target );
	}

	/**
	 * What the reader may do to the account the detail shows: save it, change
	 * its address, send its welcome again. Each is asked of the check its own
	 * route makes (update(), resend()), never worked out a second time, so
	 * the member detail leaves out a control exactly where the route would
	 * answer 403, and shows the route's sentence in its place. An address is
	 * part of a save, so whoever may not save may not change it either.
	 *
	 * @return array{can: array<string, bool>, why_not: object}
	 */
	private function allowed( WP_User $user ): array {
		$save = $this->saveRefusal( $user );
		return self::permissions(
			[
				'save'   => $save,
				'email'  => $save ?? $this->signInRefusal( $user, 'email' ),
				'resend' => $this->resendRefusal( $user ),
			]
		);
	}

	/**
	 * The role the update assigns, or null when the request names none or
	 * the one the user already holds (the admin shell sends the whole form).
	 * Nobody changes their own role (403), and only a client role can be
	 * assigned, to someone who is not on the team (roleRefusal(), 422). A
	 * client role for someone who belongs to an organization is then
	 * answered by tierFor(), not written (see update()).
	 */
	private static function roleToAssign( WP_User $user, WP_REST_Request $request ): string|WP_Error|null {
		if ( ! $request->has_param( 'role' ) ) {
			return null;
		}
		$role = (string) $request['role'];
		if ( in_array( $role, $user->roles, true ) ) {
			return null;
		}
		if ( get_current_user_id() === (int) $user->ID ) {
			return new WP_Error( 'monstera_own_role', __( 'You cannot change your own role.', 'monstera' ), [ 'status' => 403 ] );
		}
		return self::roleRefusal( $role, $user ) ?? $role;
	}

	/**
	 * Why a role cannot be assigned here, or null when it can. Only a client
	 * role can (ASSIGNABLE_ROLES). A team role is refused on the field, in
	 * the sentence that says where one is given, and so is a client role for
	 * someone on the team: it would take them off the team, which is the
	 * Team routes' to do, where a Team manager alone may, the removal is
	 * recorded, and nobody removes themselves or a WordPress administrator.
	 * Any other role, a WordPress administrator's above all, is one these
	 * routes never assign.
	 *
	 * @param WP_User|null $holder The account the role is for; none for one not made yet.
	 */
	private static function roleRefusal( string $role, ?WP_User $holder = null ): ?WP_Error {
		$assignable = in_array( $role, self::ASSIGNABLE_ROLES, true );
		if ( Capabilities::isStaffRole( $role ) || ( $assignable && $holder && Capabilities::isStaff( $holder ) ) ) {
			return new WP_Error(
				'monstera_invalid_role',
				__( 'Team roles are given and changed on the Team page.', 'monstera' ),
				[
					'status' => 422,
					'field'  => 'role',
				]
			);
		}
		return $assignable ? null : self::invalidRole();
	}

	private static function invalidRole(): WP_Error {
		return new WP_Error( 'monstera_invalid_role', __( 'That role cannot be assigned here.', 'monstera' ), [ 'status' => 422 ] );
	}

	/**
	 * What a newly chosen client role asks of someone who already belongs to
	 * an organization. Their role is a ceiling the Roster derives from the
	 * tiers they hold (People-model track, FR2): written on its own it
	 * grants nothing, because the organization's routes ask the tier, and
	 * the next roster write takes it back. So the answer is a tier in the
	 * one organization they belong to, and the ceiling makes the role of
	 * it: the manager role leaves an organization admin an admin and makes
	 * anyone else a manager, the member role makes them a member. The
	 * detail no longer offers a role (its Memberships section sets each
	 * tier through changeMembership()); this is what the route still does
	 * for a caller that names one.
	 *
	 * Nobody on the team comes here: a role for one of them is refused
	 * before (roleRefusal()), and leaving the team is the Team routes',
	 * which leave a person at the tiers they hold.
	 *
	 * Refused, naming the field: the standalone role while a membership
	 * remains, since it is true only of someone with none (their
	 * memberships end one by one, through removeMembership(), and the role
	 * follows); and any role for a person in several organizations, where
	 * one role cannot say which tier is meant. It is decided before
	 * anything is written, so a refusal writes nothing.
	 */
	private function tierFor( WP_User $user, string $role ): string|WP_Error {
		$id = (int) $user->ID;
		if ( Capabilities::ROLE_MEMBER_STANDALONE === $role ) {
			return $this->invalidField( 'role', __( 'Remove them from their organizations first.', 'monstera' ) );
		}
		if ( count( Roster::orgIdsOf( $id ) ) > 1 ) {
			return $this->invalidField( 'role', __( 'This person belongs to several organizations. Their role follows the tier they hold in each one.', 'monstera' ) );
		}
		if ( Capabilities::ROLE_MEMBER === $role ) {
			return Roster::TIER_MEMBER;
		}
		$held = Roster::roleOf( $id, Roster::primaryOrgOf( $id ) );
		return Roster::TIER_ADMIN === $held ? $held : Roster::TIER_MANAGER;
	}

	/**
	 * Why the first organization a new account names cannot be theirs: it
	 * does not exist, or its roster has no seat for one more. Null when the
	 * request names none. Checked before the account is made, so a refusal
	 * leaves no account behind.
	 */
	private function firstOrgError( WP_REST_Request $request ): ?WP_Error {
		$orgId = absint( $request['org_id'] ?? 0 );
		if ( $orgId <= 0 ) {
			return null;
		}
		if ( ! $this->isPublishedOrg( $orgId ) ) {
			return $this->invalidField( 'org_id', __( 'The selected organization does not exist.', 'monstera' ) );
		}
		$full = Roster::joinRefusal( $orgId );
		return null === $full ? null : $this->invalidField( 'org_id', $full );
	}

	/**
	 * The profile fields and the sub-groups of a save or of a new account.
	 * No organization: a new account has joined its first by now
	 * (create()), and an existing one's memberships are the memberships
	 * routes'.
	 */
	private function applyMutations( WP_User $user, WP_REST_Request $request ): void {
		$id = (int) $user->ID;

		if ( $request->has_param( 'position' ) ) {
			update_user_meta( $id, UserMeta::KEY_POSITION, sanitize_text_field( (string) $request['position'] ) );
		}
		if ( $request->has_param( 'bio' ) ) {
			update_user_meta( $id, UserMeta::KEY_BIO, wp_kses_post( (string) $request['bio'] ) );
		}
		if ( $request->has_param( 'show_in_directory' ) ) {
			update_user_meta( $id, UserMeta::KEY_SHOW_IN_DIRECTORY, self::flag( $request['show_in_directory'] ) );
		}
		if ( $request->has_param( 'profile_photo' ) ) {
			update_user_meta( $id, UserMeta::KEY_PROFILE_PHOTO, absint( $request['profile_photo'] ) );
		}
		if ( $request->has_param( 'membership_expires' ) ) {
			update_user_meta( $id, UserMeta::KEY_MEMBERSHIP_EXPIRES, sanitize_text_field( (string) $request['membership_expires'] ) );
		}
		if ( $request->has_param( 'subgroup_ids' ) ) {
			// Any of the member's organizations may parent a sub-group of
			// theirs (FR8), and the detail's picker offers the sub-groups of
			// them all, so the list is exact for them all.
			$proposed = array_map( 'absint', (array) $request['subgroup_ids'] );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, Roster::orgIdsOf( $id ), [] );
			$this->syncSubgroups( $id, $valid );
		}
	}

	/**
	 * Make the person's sub-groups within their organizations exactly the
	 * ones posted: the detail lists the sub-groups of every organization
	 * they belong to, so a group left off the list was taken off it. A
	 * membership of any other group (one parented to a standalone member)
	 * is not the picker's to offer, so no list says anything about it, and
	 * it stays.
	 *
	 * @param array<int, int> $subgroupIds Already checked against the person's organizations.
	 */
	private function syncSubgroups( int $userId, array $subgroupIds ): void {
		$repo   = new SubgroupRepository();
		$wanted = array_values( array_unique( array_filter( $subgroupIds ) ) );

		foreach ( array_diff( self::subgroupsWithinOrgs( $userId ), $wanted ) as $sgId ) {
			$repo->removeMember( (int) $sgId, $userId );
		}
		// addMember() replaces the row, so someone already in a group is not added again.
		foreach ( array_diff( $wanted, $repo->subgroupsForMember( $userId ) ) as $sgId ) {
			$repo->addMember( (int) $sgId, $userId );
		}
	}

	/**
	 * The person's sub-groups that belong to an organization of theirs: the
	 * ones the detail's picker offers, so the ones the detail shows and the
	 * only ones a save may remove.
	 *
	 * @return list<int>
	 */
	private static function subgroupsWithinOrgs( int $userId ): array {
		$orgIds = Roster::orgIdsOf( $userId );
		if ( ! $orgIds ) {
			return [];
		}
		return array_values(
			array_filter(
				array_map( 'intval', ( new SubgroupRepository() )->subgroupsForMember( $userId ) ),
				static fn ( int $groupId ): bool => in_array( (int) get_post_meta( $groupId, \Monstera\Subgroups\Meta::KEY_ORG_ID, true ), $orgIds, true )
			)
		);
	}

	/**
	 * The organizations a person is the only admin of. Removing them there,
	 * or lowering their tier, leaves the organization with no admin, which
	 * the team may do (changeMembership(), removeMembership()). The detail
	 * says so: in the question Remove asks before it is done, and for a tier,
	 * which applies the moment it is chosen, in what came of the change.
	 *
	 * @return list<int>
	 */
	private static function soleAdminOf( int $userId ): array {
		$out = [];
		foreach ( Roster::membershipsOf( $userId ) as $held ) {
			if ( Roster::TIER_ADMIN === $held['tier'] && Roster::memberIds( $held['org_id'], [ Roster::TIER_ADMIN ] ) === [ $userId ] ) {
				$out[] = $held['org_id'];
			}
		}
		return $out;
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( WP_User $u ): array {
		$id = (int) $u->ID;
		// memberships[] is every organization, and the only word on them: a
		// first organization beside it said one where there may be several.
		// The sub-groups are those of all of them, which the form's picker
		// offers together and a save makes exact.
		$photoId = (int) get_user_meta( $id, UserMeta::KEY_PROFILE_PHOTO, true );

		return [
			'id'                 => $id,
			'name'               => UserMeta::fullName( $u ),
			'first_name'         => (string) $u->first_name,
			'last_name'          => (string) $u->last_name,
			'display_name'       => (string) $u->display_name,
			'email'              => (string) $u->user_email,
			'avatar'             => UserMeta::photoUrl( $id ),
			'role'               => Capabilities::listedRole( $u ),
			'position'           => (string) get_user_meta( $id, UserMeta::KEY_POSITION, true ),
			'bio'                => (string) get_user_meta( $id, UserMeta::KEY_BIO, true ),
			'profile_photo'      => $photoId,
			'profile_photo_url'  => $photoId ? (string) wp_get_attachment_image_url( $photoId, 'thumbnail' ) : '',
			'show_in_directory'  => (bool) get_user_meta( $id, UserMeta::KEY_SHOW_IN_DIRECTORY, true ),
			'membership_expires' => (string) get_user_meta( $id, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ),
			'memberships'        => self::memberships( $id ),
			'sole_admin_of'      => self::soleAdminOf( $id ),
			'subgroup_ids'       => self::subgroupsWithinOrgs( $id ),
			'last_login'         => (string) get_user_meta( $id, UserMeta::KEY_LAST_LOGIN, true ),
			// What removing their last membership would end beside it, for the
			// question Remove asks: '' for someone who has signed in, and
			// 'account' when the account itself would go, which no other
			// value means.
			'invitation'         => Roster::invitationOf( $u ),
			'edit_url'           => admin_url( 'admin.php?page=monstera-members&id=' . $id ),
			// The sidebar (comp 121).
			'joined'             => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $u->user_registered . ' UTC' ) ),
			'welcome_sent'       => self::welcomeSent( $id ),
			// Sign-ins are logged while Reporting is on; a download always is.
			'signins_30d'        => $this->factOf( \Monstera\Core\Modules::REPORTING, static fn (): int => self::eventsInLast30Days( $id, 'login' ) ),
			'downloads_30d'      => self::eventsInLast30Days( $id, 'download' ),
			'saved'              => $this->accountSavedStamp( $id ),
			'activity'           => ActivityFeed::shape( ActivityLog::forUser( $id, 5 ) ),
			// `can` and `why_not`: what this reader may do to the account.
		] + $this->allowed( $u );
	}

	/**
	 * A member's sub-groups come from their organizations (the picker offers
	 * no others): a 422 naming the field when a save adds one from outside
	 * them, the sub-group of a membership that has since ended among them.
	 * A group they are already in is left alone.
	 */
	private function foreignSubgroupError( int $userId, WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'subgroup_ids' ) ) {
			return null;
		}
		$orgIds = Roster::orgIdsOf( $userId );
		$added  = array_diff(
			array_values( array_filter( array_map( 'absint', (array) $request['subgroup_ids'] ) ) ),
			( new SubgroupRepository() )->subgroupsForMember( $userId )
		);
		foreach ( $added as $groupId ) {
			if ( ! in_array( (int) get_post_meta( (int) $groupId, \Monstera\Subgroups\Meta::KEY_ORG_ID, true ), $orgIds, true ) ) {
				return $this->invalidField(
					'subgroup_ids',
					count( $orgIds ) > 1
						? __( 'Choose sub-groups from the member\'s organizations.', 'monstera' )
						: __( 'Choose sub-groups from the member\'s own organization.', 'monstera' )
				);
			}
		}
		return null;
	}

	/**
	 * The latest welcome email the notification log holds for someone, or
	 * null when none went. Either welcome counts: an account on the team is
	 * sent the team's (Dispatcher::sendWelcome()), and this list shows staff
	 * too.
	 *
	 * @return array{at: string, delivered: bool|null}|null
	 */
	private static function welcomeSent( int $userId ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one row from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT sent_at, delivered FROM %i WHERE member_id = %d AND event_type IN ( %s, %s ) ORDER BY sent_at DESC, id DESC LIMIT 1',
				Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
				$userId,
				TemplateEngine::EVENT_WELCOME,
				TemplateEngine::EVENT_TEAM_WELCOME
			),
			ARRAY_A
		);
		if ( ! $row ) {
			return null;
		}
		return [
			'at'        => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['sent_at'] . ' UTC' ) ),
			// A row from before deliveries were recorded has no answer; it is
			// not a failure.
			'delivered' => null === $row['delivered'] ? null : (bool) (int) $row['delivered'],
		];
	}

	/** How many times someone did one thing in the last 30 days. */
	private static function eventsInLast30Days( int $userId, string $event ): int {
		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a count from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE user_id = %d AND event_type = %s AND occurred_at >= %s',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$userId,
				$event,
				gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS )
			)
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shapeRow( WP_User $u ): array {
		$id = (int) $u->ID;
		return [
			'id'          => $id,
			'name'        => UserMeta::fullName( $u ),
			'email'       => (string) $u->user_email,
			// The photo they uploaded, or null for the leaf (UserMeta::photoUrl()).
			'avatar'      => UserMeta::photoUrl( $id ),
			// Every organization, the first one first: the list's column, its
			// filter and its search all read these.
			'memberships' => self::memberships( $id ),
			'role'        => Capabilities::listedRole( $u ),
			'last_login'  => (string) get_user_meta( $id, UserMeta::KEY_LAST_LOGIN, true ),
			'registered'  => (string) $u->user_registered,
			'edit_url'    => admin_url( 'admin.php?page=monstera-members&id=' . $id ),
		];
	}
	/**
	 * One id of a bulk request. Each action reuses the single-item write path so
	 * the audit trail matches; skipped ids carry the reason.
	 */
	public function bulkAction( BulkRequest $bulk, int $id, BulkResult $result ): void {
		match ( $bulk->action ) {
			self::BULK_ADD    => $this->bulkAddToOrg( $id, $bulk, $result ),
			self::BULK_REMOVE => $this->bulkRemoveFromOrg( $id, absint( $bulk->params['org_id'] ?? 0 ), $result ),
			'resend_welcome'  => $this->bulkResendWelcome( $id, $result ),
			default           => $result->skip( $id, __( 'Unknown bulk action.', 'monstera' ) ),
		};
	}

	/**
	 * A target org that is missing or unpublished is wrong for every id, and
	 * so is a tier that is not one, so the whole request is refused before
	 * anyone is added or removed.
	 */
	public function validateBulk( BulkRequest $bulk ): ?WP_Error {
		if ( ! in_array( $bulk->action, [ self::BULK_ADD, self::BULK_REMOVE ], true ) ) {
			return null;
		}
		$orgId = absint( $bulk->params['org_id'] ?? 0 );
		if ( $orgId <= 0 || ! $this->isPublishedOrg( $orgId ) ) {
			return new WP_Error( 'monstera_invalid_org', __( 'The selected organization does not exist.', 'monstera' ), [ 'status' => 422 ] );
		}
		if ( self::BULK_ADD === $bulk->action && isset( $bulk->params['tier'] ) ) {
			$tier = $this->tierAsked( $bulk->params['tier'] );
			if ( $tier instanceof WP_Error ) {
				return $tier;
			}
		}
		return null;
	}

	/**
	 * What a bulk action on memberships did, in one sentence for the list's
	 * outcome notice: how many people were added or removed, then, of those
	 * removed, how many were only invited and went with their accounts, then
	 * how many were left because they were already members, or were not
	 * members at all, then how many could not be added. The rows say why for
	 * each person. The other actions have nothing to add to the two counts.
	 */
	public function bulkSummary( BulkRequest $bulk, BulkResult $result ): string {
		if ( ! in_array( $bulk->action, [ self::BULK_ADD, self::BULK_REMOVE ], true ) ) {
			return '';
		}
		$org  = html_entity_decode( get_the_title( absint( $bulk->params['org_id'] ?? 0 ) ), ENT_QUOTES, 'UTF-8' );
		$done = $result->updated();

		if ( self::BULK_REMOVE === $bulk->action ) {
			// Nobody is refused a removal, so everyone skipped was not a
			// member: of this organization, or of Monstera at all.
			$absent = $result->skipped();
			$said   = [
				0 === $done
					/* translators: %s: an organization's name */
					? sprintf( __( 'Nobody was removed from %s.', 'monstera' ), $org )
					/* translators: 1: number of people, 2: an organization's name */
					: sprintf( _n( '%1$d person removed from %2$s.', '%1$d people removed from %2$s.', $done, 'monstera' ), $done, $org ),
			];
			// Someone who had not signed in and belonged nowhere else was only
			// invited: the account the invitation made went with it, and the
			// list no longer shows them.
			$uninvited = $result->updated( self::UNINVITED );
			if ( $uninvited > 0 ) {
				/* translators: %d: number of invitations */
				$said[] = sprintf( _n( '%d invitation ended and its account was removed.', '%d invitations ended and their accounts were removed.', $uninvited, 'monstera' ), $uninvited );
			}
			if ( $absent > 0 ) {
				/* translators: %d: number of people */
				$said[] = sprintf( _n( '%d was not a member.', '%d were not members.', $absent, 'monstera' ), $absent );
			}
			return implode( ' ', $said );
		}

		$already = $result->skipped( self::ALREADY_MEMBER );
		$refused = $result->skipped() - $already;
		$said    = [
			0 === $done
				/* translators: %s: an organization's name */
				? sprintf( __( 'Nobody was added to %s.', 'monstera' ), $org )
				/* translators: 1: number of people, 2: an organization's name */
				: sprintf( _n( '%1$d person added to %2$s.', '%1$d people added to %2$s.', $done, 'monstera' ), $done, $org ),
		];
		if ( $already > 0 ) {
			/* translators: %d: number of people */
			$said[] = sprintf( _n( '%d was already a member.', '%d were already members.', $already, 'monstera' ), $already );
		}
		if ( $refused > 0 ) {
			/* translators: %d: number of people */
			$said[] = sprintf( _n( '%d could not be added.', '%d could not be added.', $refused, 'monstera' ), $refused );
		}
		return implode( ' ', $said );
	}

	/**
	 * An account that holds one of the roles the Members list is about. An
	 * administrator who holds one beside their own passes here, so this is
	 * only half of whom the routes reach: the single reads and every bulk
	 * action ask listed(), which turns that account away too, the list's
	 * query says the same in its own terms (index()), and a save asks
	 * canEdit().
	 */
	private static function member( int $id ): ?WP_User {
		$user = get_user_by( 'id', $id );
		if ( ! $user instanceof WP_User || ! array_intersect( $user->roles, self::MEMBER_ROLES ) ) {
			return null;
		}
		return $user;
	}

	/**
	 * One person of an "Add to organization" selection, by the single
	 * route's rules (listed(), then join()): they are added and stay
	 * wherever else they belong, never moved. Someone already there is
	 * skipped and counted apart, for the answer's sentence; anyone else who
	 * cannot join (one of the team, one more than the seats) is skipped with
	 * the reason, and an account the single route would not find is not a
	 * member.
	 *
	 * At the tier the request names for everyone, or with none named, the
	 * one Provisioning::tierImpliedByUser() gives each person: a manager made
	 * by role joins their first organization as its manager, and everyone
	 * else joins as a member, someone who already manages another
	 * organization among them. The role ceiling then makes a standalone
	 * member a member.
	 */
	private function bulkAddToOrg( int $id, BulkRequest $bulk, BulkResult $result ): void {
		$user = self::listed( $id );
		if ( $user instanceof WP_Error ) {
			$result->skip( $id, __( 'Not a member.', 'monstera' ) );
			return;
		}
		$asked   = $bulk->params['tier'] ?? null;
		$refused = $this->join( $user, absint( $bulk->params['org_id'] ?? 0 ), is_string( $asked ) ? $asked : Provisioning::tierImpliedByUser( $id ) );
		if ( $refused ) {
			$result->skip( $id, $refused->get_error_message(), (string) $refused->get_error_code() );
			return;
		}
		$result->done( $id, __( 'Added.', 'monstera' ) );
	}

	/**
	 * One person of a "Remove from organization" selection: their
	 * membership of that organization ends, and no other. Someone who was
	 * not in it is skipped, and so is an account the single route would not
	 * find (listed()). Through the roster, as the single route does it: the
	 * account stays, the organization's sub-groups and project teams let go,
	 * and the Roster files the one activity row. Someone who was only
	 * invited goes with their account, as by the single route, and their
	 * line says so and is counted apart for the answer's sentence.
	 */
	private function bulkRemoveFromOrg( int $id, int $orgId, BulkResult $result ): void {
		if ( self::listed( $id ) instanceof WP_Error ) {
			$result->skip( $id, __( 'Not a member.', 'monstera' ) );
			return;
		}
		if ( ! Roster::isMemberOf( $id, $orgId ) ) {
			$result->skip( $id, __( 'Not in that organization.', 'monstera' ) );
			return;
		}
		if ( Roster::INVITATION_ACCOUNT === Roster::remove( $orgId, $id ) ) {
			$result->done( $id, __( 'Removed. Their invitation ended and their account was removed.', 'monstera' ), self::UNINVITED );
			return;
		}
		$result->done( $id, __( 'Removed.', 'monstera' ) );
	}

	private function bulkResendWelcome( int $id, BulkResult $result ): void {
		$user = self::listed( $id );
		if ( $user instanceof WP_Error ) {
			$result->skip( $id, __( 'Not a member.', 'monstera' ) );
			return;
		}
		$refused = $this->resendRefusal( $user );
		if ( $refused ) {
			$result->skip( $id, $refused->get_error_message() );
			return;
		}
		if ( ! Provisioning::resendWelcome( $id ) ) {
			$result->skip( $id, __( 'No email address on file.', 'monstera' ) );
			return;
		}
		$result->done( $id, __( 'Welcome email sent.', 'monstera' ) );
	}
}
