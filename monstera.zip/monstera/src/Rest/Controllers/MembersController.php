<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Notifications\TemplateEngine;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Organizations\Roster;
use Monstera\Reporting\ActivityFeed;
use Monstera\Reporting\ActivityLog;
use Monstera\Rest\BulkRequest;
use Monstera\Rest\BulkResult;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_User;

final class MembersController extends BaseController {

	/**
	 * The roles the Members list shows, and the only roles its routes assign.
	 * A WordPress administrator is deliberately absent: manage_monstera is not
	 * edit_users, so a Monstera admin must never be able to make one, become
	 * one, or take one over. Bulk actions reach no one else either.
	 *
	 * @var list<string>
	 */
	private const MEMBER_ROLES = [
		Capabilities::ROLE_ADMIN,
		Capabilities::ROLE_ORG_MANAGER,
		Capabilities::ROLE_MEMBER,
		Capabilities::ROLE_MEMBER_STANDALONE,
	];

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/members',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/members/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/members/(?P<id>\d+)/resend',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'resend' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		$this->registerBulkRoute( '/members', [ 'reassign_org', 'resend_welcome' ], [ $this, 'bulkAction' ], [ $this, 'validateBulk' ] );
	}

	/**
	 * "Resend welcome" on the member detail (comp 121): the bulk action's
	 * path for one person, answering when it went.
	 *
	 * @return array{ok: bool, welcome_sent: array{at: string, delivered: bool}|null}|WP_Error
	 */
	public function resend( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$user = self::member( $id );
		if ( ! $user || ! self::canEdit( $user ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Member not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! Provisioning::resendWelcome( $id, [ 'org_id' => UserMeta::associatedOrg( $id ) ] ) ) {
			return $this->invalidField( 'email', __( 'This member has no email address to send to.', 'monstera' ) );
		}
		return [
			'ok'           => true,
			'welcome_sent' => self::welcomeSent( $id ),
		];
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$standaloneOnly = (bool) $request->get_param( 'standalone_only' );

		$args = [
			'role__in' => self::MEMBER_ROLES,
			'number'   => -1,
			'fields'   => 'all',
		];

		if ( $standaloneOnly ) {
			// Standalone = user with no associated org. Includes the dedicated
			// 'monstera_member_standalone' role plus any user whose org meta is
			// empty (covers admins or org-managers that are managing nothing).
			$args['role__in']   = [ Capabilities::ROLE_MEMBER_STANDALONE ];
			$args['meta_query'] = [
				'relation' => 'OR',
				[
					'key'     => UserMeta::KEY_ASSOCIATED_ORG,
					'compare' => 'NOT EXISTS',
				],
				[
					'key'     => UserMeta::KEY_ASSOCIATED_ORG,
					'value'   => 0,
					'compare' => '=',
				],
			];
		}

		// One organization's people: the sub-group detail's members picker
		// offers only the parent organization's (comp 123).
		$orgId = absint( $request->get_param( 'org_id' ) );
		if ( $orgId > 0 ) {
			$args['meta_key']   = UserMeta::KEY_ASSOCIATED_ORG; // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
			$args['meta_value'] = (string) $orgId; // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
		}

		$users = get_users( $args );
		$out   = [];
		foreach ( $users as $u ) {
			$out[] = $this->shapeRow( $u );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		// The accounts the Members list shows, and no other: a WordPress
		// administrator's email, roles and sign-ins are not Monstera's to read.
		$user = self::member( (int) $request['id'] );
		if ( ! $user instanceof WP_User || in_array( 'administrator', $user->roles, true ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Member not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return $this->shape( $user );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$email = $this->checkedEmail( (string) ( $request['email'] ?? '' ), 0 );
		if ( $email instanceof WP_Error ) {
			return $email;
		}
		$orgErr = $this->invalidOrgError( $request, 0 );
		if ( $orgErr ) {
			return $orgErr;
		}

		$first = sanitize_text_field( (string) ( $request['first_name'] ?? '' ) );
		$last  = sanitize_text_field( (string) ( $request['last_name'] ?? '' ) );
		$login = sanitize_user( (string) ( $request['username'] ?? $email ), true );

		$role = (string) ( $request['role'] ?? '' ) ?: Capabilities::ROLE_MEMBER;
		if ( ! in_array( $role, self::MEMBER_ROLES, true ) ) {
			return self::invalidRole();
		}

		$id = wp_insert_user(
			[
				'user_login' => $login,
				'user_email' => $email,
				'user_pass'  => wp_generate_password( 20, true, true ),
				'first_name' => $first,
				'last_name'  => $last,
				'role'       => $role,
				// With the account, so the welcome user_register sends can name it.
				'meta_input' => absint( $request['org_id'] ?? 0 ) > 0
					? [ UserMeta::KEY_ASSOCIATED_ORG => absint( $request['org_id'] ) ]
					: [],
			]
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$user = get_user_by( 'id', (int) $id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'monstera_create_failed', __( 'User created but could not be loaded.', 'monstera' ), [ 'status' => 500 ] );
		}

		$this->applyMutations( $user, $request );
		return $this->shape( $user );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$user = get_user_by( 'id', $id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'monstera_not_found', __( 'Member not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! self::canEdit( $user ) ) {
			return new WP_Error( 'monstera_forbidden', __( 'You cannot edit this account.', 'monstera' ), [ 'status' => 403 ] );
		}
		$role = self::roleToAssign( $user, $request );
		if ( $role instanceof WP_Error ) {
			return $role;
		}
		$orgErr = $this->invalidOrgError( $request, $id );
		if ( $orgErr ) {
			return $orgErr;
		}
		$groupErr = $this->foreignSubgroupError( $id, $request );
		if ( $groupErr ) {
			return $groupErr;
		}
		// Checked with the other refusals, before anything is written.
		$email = null;
		if ( $request->has_param( 'email' ) ) {
			$email = $this->checkedEmail( (string) $request['email'], $id );
			if ( $email instanceof WP_Error ) {
				return $email;
			}
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'first_name' ) ) {
			$core['first_name'] = sanitize_text_field( (string) $request['first_name'] );
		}
		if ( $request->has_param( 'last_name' ) ) {
			$core['last_name'] = sanitize_text_field( (string) $request['last_name'] );
		}
		if ( null !== $email ) {
			$core['user_email'] = $email;
		}
		if ( $request->has_param( 'display_name' ) ) {
			$core['display_name'] = sanitize_text_field( (string) $request['display_name'] );
		}
		if ( null !== $role ) {
			$core['role'] = $role;
		}

		if ( count( $core ) > 1 ) {
			$updated = wp_update_user( $core );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		$this->applyMutations( $user, $request );
		update_user_meta(
			$id,
			UserMeta::KEY_SAVED,
			[
				'at' => gmdate( 'c' ),
				'by' => get_current_user_id(),
			]
		);
		// Re-fetch so any role / display name changes are reflected.
		$fresh = get_user_by( 'id', $id ) ?: $user;
		return $this->shape( $fresh );
	}

	/**
	 * Whether the caller may write to this account. edit_users or
	 * promote_users (a WordPress administrator) reaches anyone; a
	 * manage_monstera holder reaches only the accounts the Members list
	 * shows (the bulk route's rule), and never a WordPress administrator.
	 */
	private static function canEdit( WP_User $target ): bool {
		if ( current_user_can( 'edit_users' ) || current_user_can( 'promote_users' ) ) {
			return true;
		}
		return null !== self::member( (int) $target->ID )
			&& ! in_array( 'administrator', $target->roles, true );
	}

	/**
	 * The role the update assigns, or null when the request names none or
	 * the one the user already holds (the admin shell sends the whole form).
	 * Only a Monstera role can be assigned (422 otherwise), and nobody
	 * changes their own role (403).
	 */
	private static function roleToAssign( WP_User $user, WP_REST_Request $request ): string|WP_Error|null {
		if ( ! $request->has_param( 'role' ) ) {
			return null;
		}
		$role = (string) $request['role'];
		if ( in_array( $role, $user->roles, true ) ) {
			return null;
		}
		if ( ! in_array( $role, self::MEMBER_ROLES, true ) ) {
			return self::invalidRole();
		}
		if ( get_current_user_id() === (int) $user->ID ) {
			return new WP_Error( 'monstera_own_role', __( 'You cannot change your own role.', 'monstera' ), [ 'status' => 403 ] );
		}
		return $role;
	}

	private static function invalidRole(): WP_Error {
		return new WP_Error( 'monstera_invalid_role', __( 'That role cannot be assigned here.', 'monstera' ), [ 'status' => 422 ] );
	}

	/**
	 * Validate the org_id param refers to a real published organization.
	 * Returns a WP_Error to short-circuit the request, or null when the param
	 * is absent, an explicit unassign (0), or a valid org. Called BEFORE any
	 * writes so a bad id can't half-apply other mutations.
	 */
	/**
	 * Why the organization the request names cannot be this person's: it
	 * does not exist, or its roster has no seat for one more.
	 *
	 * @param int $userId The person, or 0 for an account not made yet.
	 */
	private function invalidOrgError( WP_REST_Request $request, int $userId ): ?WP_Error {
		if ( ! $request->has_param( 'org_id' ) ) {
			return null;
		}
		$orgId = absint( $request['org_id'] );
		if ( $orgId > 0 && ! $this->isPublishedOrg( $orgId ) ) {
			return $this->invalidField( 'org_id', __( 'The selected organization does not exist.', 'monstera' ) );
		}
		$full = Roster::joinRefusal( $orgId, $userId );
		return null === $full ? null : $this->invalidField( 'org_id', $full );
	}

	/**
	 * The email as it will be stored, or a 422 naming the field when it is
	 * not an address or another account has it.
	 */
	private function checkedEmail( string $raw, int $selfId ): string|WP_Error {
		$email = sanitize_email( $raw );
		if ( '' === $email || ! is_email( $email ) ) {
			return $this->invalidField( 'email', __( 'Enter an email address, like name@example.com.', 'monstera' ) );
		}
		$owner = email_exists( $email );
		if ( $owner && (int) $owner !== $selfId ) {
			return $this->invalidField( 'email', __( 'Another account already uses that email.', 'monstera' ) );
		}
		return $email;
	}

	private function isPublishedOrg( int $orgId ): bool {
		$org = get_post( $orgId );
		return $org instanceof WP_Post
			&& OrgPostType::SLUG === $org->post_type
			&& 'publish' === $org->post_status;
	}

	private function applyMutations( WP_User $user, WP_REST_Request $request ): void {
		$id = (int) $user->ID;

		if ( $request->has_param( 'position' ) ) {
			update_user_meta( $id, UserMeta::KEY_POSITION, sanitize_text_field( (string) $request['position'] ) );
		}
		if ( $request->has_param( 'bio' ) ) {
			update_user_meta( $id, UserMeta::KEY_BIO, wp_kses_post( (string) $request['bio'] ) );
		}
		if ( $request->has_param( 'show_in_directory' ) ) {
			update_user_meta( $id, UserMeta::KEY_SHOW_IN_DIRECTORY, self::flag( $request['show_in_directory'] ) );
		}
		if ( $request->has_param( 'profile_photo' ) ) {
			update_user_meta( $id, UserMeta::KEY_PROFILE_PHOTO, absint( $request['profile_photo'] ) );
		}
		if ( $request->has_param( 'membership_expires' ) ) {
			update_user_meta( $id, UserMeta::KEY_MEMBERSHIP_EXPIRES, sanitize_text_field( (string) $request['membership_expires'] ) );
		}
		if ( $request->has_param( 'org_id' ) ) {
			// Through the roster, as the organization's own page does: leaving
			// one takes the person out of its sub-groups and project teams.
			$orgId = absint( $request['org_id'] );
			if ( $orgId > 0 ) {
				Roster::add( $orgId, $id );
			} else {
				Roster::remove( UserMeta::associatedOrg( $id ), $id );
			}
		}
		if ( $request->has_param( 'subgroup_ids' ) ) {
			$proposed = array_map( 'absint', (array) $request['subgroup_ids'] );
			$orgId    = UserMeta::associatedOrg( $id );
			$valid    = ContentController::filterSubgroupsByAudience(
				$proposed,
				$orgId ? [ $orgId ] : [],
				[]
			);
			$this->syncSubgroups( $id, $valid, $orgId );
		}
	}

	/**
	 * Make the person's sub-groups within their organization exactly these.
	 * A membership of any other group (one parented to a standalone member)
	 * is not the picker's to offer, so it is not this save's to remove.
	 *
	 * @param array<int, int> $subgroupIds
	 */
	private function syncSubgroups( int $userId, array $subgroupIds, int $orgId ): void {
		$repo    = new SubgroupRepository();
		$current = self::subgroupsWithin( $userId, $orgId );
		$wanted  = array_values( array_unique( array_filter( $subgroupIds ) ) );

		foreach ( array_diff( $current, $wanted ) as $sgId ) {
			$repo->removeMember( (int) $sgId, $userId );
		}
		foreach ( array_diff( $wanted, $current ) as $sgId ) {
			$repo->addMember( (int) $sgId, $userId );
		}
	}

	/**
	 * The person's sub-groups that belong to this organization: the ones
	 * the detail's picker offers, so the ones the detail shows and saves.
	 *
	 * @return array<int, int>
	 */
	private static function subgroupsWithin( int $userId, int $orgId ): array {
		if ( $orgId <= 0 ) {
			return [];
		}
		return array_values(
			array_filter(
				array_map( 'intval', ( new SubgroupRepository() )->subgroupsForMember( $userId ) ),
				static fn ( int $groupId ): bool => (int) get_post_meta( $groupId, \Monstera\Subgroups\Meta::KEY_ORG_ID, true ) === $orgId
			)
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( WP_User $u ): array {
		$id          = (int) $u->ID;
		$orgId       = UserMeta::associatedOrg( $id );
		$subgroupIds = self::subgroupsWithin( $id, $orgId );
		$photoId     = (int) get_user_meta( $id, UserMeta::KEY_PROFILE_PHOTO, true );

		return [
			'id'                 => $id,
			'name'               => UserMeta::fullName( $u ),
			'first_name'         => (string) $u->first_name,
			'last_name'          => (string) $u->last_name,
			'display_name'       => (string) $u->display_name,
			'email'              => (string) $u->user_email,
			'avatar'             => get_avatar_url( $id, [ 'size' => 96 ] ),
			'role'               => $u->roles[0] ?? '',
			'position'           => (string) get_user_meta( $id, UserMeta::KEY_POSITION, true ),
			'bio'                => (string) get_user_meta( $id, UserMeta::KEY_BIO, true ),
			'profile_photo'      => $photoId,
			'profile_photo_url'  => $photoId ? (string) wp_get_attachment_image_url( $photoId, 'thumbnail' ) : '',
			'show_in_directory'  => (bool) get_user_meta( $id, UserMeta::KEY_SHOW_IN_DIRECTORY, true ),
			'membership_expires' => (string) get_user_meta( $id, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ),
			'org_id'             => $orgId,
			'org_name'           => $orgId ? get_the_title( $orgId ) : '',
			'subgroup_ids'       => $subgroupIds,
			'last_login'         => (string) get_user_meta( $id, UserMeta::KEY_LAST_LOGIN, true ),
			'allowed_roles'      => self::MEMBER_ROLES,
			'edit_url'           => admin_url( 'admin.php?page=monstera-members&id=' . $id ),
			// The sidebar (comp 121).
			'joined'             => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $u->user_registered . ' UTC' ) ),
			'welcome_sent'       => self::welcomeSent( $id ),
			// Sign-ins are logged while Reporting is on; a download always is.
			'signins_30d'        => $this->factOf( \Monstera\Core\Modules::REPORTING, static fn (): int => self::eventsInLast30Days( $id, 'login' ) ),
			'downloads_30d'      => self::eventsInLast30Days( $id, 'download' ),
			'saved'              => self::savedBy( $id ),
			'activity'           => ActivityFeed::shape( ActivityLog::forUser( $id, 5 ) ),
		];
	}

	/**
	 * A member's sub-groups come from their own organization (the picker
	 * offers no others): a 422 naming the field when a save adds one from
	 * outside it. A group they are already in is left alone.
	 */
	private function foreignSubgroupError( int $userId, WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'subgroup_ids' ) ) {
			return null;
		}
		$orgId = $request->has_param( 'org_id' ) ? absint( $request['org_id'] ) : UserMeta::associatedOrg( $userId );
		$added = array_diff(
			array_values( array_filter( array_map( 'absint', (array) $request['subgroup_ids'] ) ) ),
			( new SubgroupRepository() )->subgroupsForMember( $userId )
		);
		foreach ( $added as $groupId ) {
			if ( $orgId <= 0 || (int) get_post_meta( (int) $groupId, \Monstera\Subgroups\Meta::KEY_ORG_ID, true ) !== $orgId ) {
				return $this->invalidField( 'subgroup_ids', __( 'Choose sub-groups from the member\'s own organization.', 'monstera' ) );
			}
		}
		return null;
	}

	/**
	 * When the member was last saved from the admin and by whom.
	 *
	 * @return array{at: string, by: string}
	 */
	private static function savedBy( int $userId ): array {
		$saved  = get_user_meta( $userId, UserMeta::KEY_SAVED, true );
		$editor = is_array( $saved ) ? get_userdata( (int) ( $saved['by'] ?? 0 ) ) : false;
		return [
			'at' => is_array( $saved ) ? (string) ( $saved['at'] ?? '' ) : '',
			'by' => $editor ? UserMeta::fullName( $editor ) : '',
		];
	}

	/**
	 * The latest welcome email the notification log holds for someone, or
	 * null when none went.
	 *
	 * @return array{at: string, delivered: bool|null}|null
	 */
	private static function welcomeSent( int $userId ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one row from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT sent_at, delivered FROM %i WHERE member_id = %d AND event_type = %s ORDER BY sent_at DESC, id DESC LIMIT 1',
				Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
				$userId,
				TemplateEngine::EVENT_WELCOME
			),
			ARRAY_A
		);
		if ( ! $row ) {
			return null;
		}
		return [
			'at'        => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['sent_at'] . ' UTC' ) ),
			// A row from before deliveries were recorded has no answer; it is
			// not a failure.
			'delivered' => null === $row['delivered'] ? null : (bool) (int) $row['delivered'],
		];
	}

	/** How many times someone did one thing in the last 30 days. */
	private static function eventsInLast30Days( int $userId, string $event ): int {
		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a count from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE user_id = %d AND event_type = %s AND occurred_at >= %s',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$userId,
				$event,
				gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS )
			)
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shapeRow( WP_User $u ): array {
		$id    = (int) $u->ID;
		$orgId = UserMeta::associatedOrg( $id );
		return [
			'id'         => $id,
			'name'       => UserMeta::fullName( $u ),
			'email'      => (string) $u->user_email,
			'avatar'     => get_avatar_url( $id, [ 'size' => 64 ] ),
			'org_id'     => $orgId,
			'org_name'   => $orgId ? get_the_title( $orgId ) : '',
			'role'       => $u->roles[0] ?? '',
			'last_login' => (string) get_user_meta( $id, UserMeta::KEY_LAST_LOGIN, true ),
			'registered' => (string) $u->user_registered,
			'edit_url'   => admin_url( 'admin.php?page=monstera-members&id=' . $id ),
		];
	}
	/**
	 * One id of a bulk request. Each action reuses the single-item write path so
	 * the audit trail matches; skipped ids carry the reason.
	 */
	public function bulkAction( BulkRequest $bulk, int $id, BulkResult $result ): void {
		match ( $bulk->action ) {
			'reassign_org'   => $this->bulkReassignOrg( $id, absint( $bulk->params['org_id'] ?? 0 ), $result ),
			'resend_welcome' => $this->bulkResendWelcome( $id, $result ),
			default          => $result->skip( $id, __( 'Unknown bulk action.', 'monstera' ) ),
		};
	}

	/**
	 * A target org that is missing or unpublished is wrong for every id, so the
	 * whole request is refused before any member moves.
	 */
	public function validateBulk( BulkRequest $bulk ): ?WP_Error {
		if ( 'reassign_org' !== $bulk->action ) {
			return null;
		}
		$orgId = absint( $bulk->params['org_id'] ?? 0 );
		if ( $orgId <= 0 || ! $this->isPublishedOrg( $orgId ) ) {
			return new WP_Error( 'monstera_invalid_org', __( 'The selected organization does not exist.', 'monstera' ), [ 'status' => 422 ] );
		}
		return null;
	}

	/**
	 * A user the Members list would show. Any other account — a WordPress
	 * administrator above all — is out of reach for bulk actions, so a
	 * manage_monstera holder cannot mail it a set-password link or write
	 * org meta onto it.
	 */
	private static function member( int $id ): ?WP_User {
		$user = get_user_by( 'id', $id );
		if ( ! $user instanceof WP_User || ! array_intersect( $user->roles, self::MEMBER_ROLES ) ) {
			return null;
		}
		return $user;
	}

	private function bulkReassignOrg( int $id, int $orgId, BulkResult $result ): void {
		if ( ! self::member( $id ) ) {
			$result->skip( $id, __( 'Not a member.', 'monstera' ) );
			return;
		}
		if ( UserMeta::associatedOrg( $id ) === $orgId ) {
			$result->skip( $id, __( 'Already in that organization.', 'monstera' ) );
			return;
		}
		$full = Roster::joinRefusal( $orgId, $id );
		if ( null !== $full ) {
			$result->skip( $id, $full );
			return;
		}
		// Through the roster: the move takes them out of the old
		// organization's sub-groups and project teams. Roles are untouched.
		Roster::add( $orgId, $id );
		ActivityLog::record( 'member_org_changed', 'user', $id, [ 'org_id' => $orgId ] );
		$result->done( $id, __( 'Moved.', 'monstera' ) );
	}

	private function bulkResendWelcome( int $id, BulkResult $result ): void {
		if ( ! self::member( $id ) ) {
			$result->skip( $id, __( 'Not a member.', 'monstera' ) );
			return;
		}
		if ( ! Provisioning::resendWelcome( $id ) ) {
			$result->skip( $id, __( 'No email address on file.', 'monstera' ) );
			return;
		}
		$result->done( $id, __( 'Welcome email sent.', 'monstera' ) );
	}
}
