<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Routing;
use Monstera\Forms\Meta;
use Monstera\Forms\PostType;
use Monstera\Members\UserMeta;
use WP_Error;
use WP_Query;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

final class FormsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/forms',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/forms/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/forms/(?P<id>\d+)/pdf',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
				'callback'            => [ $this, 'uploadPdf' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index(): array {
		$q   = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft' ],
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				],
				$this->ownAuthorQueryArgs()
			)
		);
		$out = [];
		foreach ( $q->posts as $post ) {
			$orgIds   = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_ORGS, true ) ) );
			$memIds   = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBERS, true ) ) );
			$orgNames = array_values( array_filter( array_map( 'get_the_title', $orgIds ) ) );
			$fileId   = (int) get_post_meta( $post->ID, Meta::KEY_PDF_FILE_ID, true );
			$path     = $fileId ? (string) get_attached_file( $fileId ) : '';
			$author   = get_userdata( (int) $post->post_author );
			$out[]    = [
				'id'             => $post->ID,
				'title'          => get_the_title( $post ),
				'form_type'      => (string) ( get_post_meta( $post->ID, Meta::KEY_FORM_TYPE, true ) ?: Meta::TYPE_PDF ),
				'access_summary' => $this->summarizeAccess( $orgIds, $memIds ),
				'status'         => $post->post_status,
				// The list's sub-line: where it comes from (the organizations
				// it targets, else the site), the file's size or the link's
				// host, and who wrote it (a manager writes from the portal).
				'source'         => $orgNames ? implode( ', ', $orgNames ) : (string) get_bloginfo( 'name' ),
				'file_size'      => $path && file_exists( $path ) ? (int) filesize( $path ) : 0,
				'external_url'   => (string) get_post_meta( $post->ID, Meta::KEY_EXTERNAL_URL, true ),
				'modified'       => get_post_modified_time( 'c', true, $post ),
				'author_name'    => $author ? UserMeta::fullName( $author ) : '',
				'author_portal'  => $author ? ! user_can( $author, Capabilities::CAP_MANAGE_MONSTERA ) : false,
				'edit_url'       => admin_url( 'admin.php?page=monstera-forms&id=' . $post->ID ),
			];
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'Give the resource a title.', 'monstera' ) );
		}
		$refusal = $this->pdfRefusal( 0, $request );
		if ( $refusal ) {
			return $refusal;
		}
		$status = sanitize_key( (string) ( $request['status'] ?? 'publish' ) );

		$id = wp_insert_post(
			[
				'post_type'   => PostType::SLUG,
				'post_title'  => $title,
				'post_status' => in_array( $status, [ 'publish', 'draft' ], true ) ? $status : 'draft',
				'post_author' => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$this->applyMutations( (int) $id, $request );
		$this->stampEditor( (int) $id );
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'Give the resource a title.', 'monstera' ) );
			}
		}
		$refusal = $this->pdfRefusal( $id, $request );
		if ( $refusal ) {
			return $refusal;
		}
		if ( $request->has_param( 'status' ) ) {
			$status = sanitize_key( (string) $request['status'] );
			if ( in_array( $status, [ 'publish', 'draft' ], true ) ) {
				$core['post_status'] = $status;
			}
		}
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}

		$this->applyMutations( $id, $request );
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/**
	 * Attach a PDF to a resource from the portal Manage tab (multipart
	 * `pdf_file`). The file is sideloaded into the Media Library, attached to
	 * the resource, and the resource becomes a PDF resource. Forms are the
	 * low-sensitivity library by design, so the Media Library is their home;
	 * gated deliverables go through the secure-files flow instead.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function uploadPdf( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}

		$files = $request->get_file_params();
		$file  = $files['pdf_file'] ?? null;
		if ( ! is_array( $file ) || empty( $file['tmp_name'] ) || ! empty( $file['error'] ) ) {
			return $this->invalidField( 'pdf_file', __( 'Choose a PDF to upload.', 'monstera' ) );
		}
		if ( (int) ( $file['size'] ?? 0 ) > 25 * MB_IN_BYTES ) {
			return $this->invalidField( 'pdf_file', __( 'That PDF is over 25 MB. Choose a smaller one.', 'monstera' ) );
		}
		$check = wp_check_filetype_and_ext( (string) $file['tmp_name'], (string) $file['name'] );
		if ( 'pdf' !== $check['ext'] || 'application/pdf' !== $check['type'] ) {
			return $this->invalidField( 'pdf_file', __( 'Only a PDF can be attached to a resource.', 'monstera' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachmentId = media_handle_sideload(
			[
				'name'     => sanitize_file_name( (string) $file['name'] ),
				'tmp_name' => (string) $file['tmp_name'],
				'type'     => 'application/pdf',
				'size'     => (int) ( $file['size'] ?? 0 ),
			],
			$id
		);
		if ( is_wp_error( $attachmentId ) ) {
			$attachmentId->add_data( [ 'status' => 422 ] );
			return $attachmentId;
		}

		// A resource has one PDF. The one this upload supersedes was sideloaded
		// for this resource (its parent), so nothing else points at it; a file
		// picked from the Media Library has another parent and stays.
		$previous = (int) get_post_meta( $id, Meta::KEY_PDF_FILE_ID, true );
		if ( $previous > 0 && $previous !== (int) $attachmentId && (int) get_post_field( 'post_parent', $previous ) === $id ) {
			wp_delete_attachment( $previous, true );
		}

		update_post_meta( $id, Meta::KEY_PDF_FILE_ID, (int) $attachmentId );
		update_post_meta( $id, Meta::KEY_FORM_TYPE, Meta::TYPE_PDF );
		// The link an external resource had would otherwise linger in its details.
		delete_post_meta( $id, Meta::KEY_EXTERNAL_URL );
		return $this->shape( $id );
	}

	/**
	 * Why the file the request names cannot be the resource's PDF, or null.
	 * It must be a PDF in the Media Library; a delegated author may only
	 * name one that was uploaded to this resource, so another person's file
	 * (or its name and size) is never theirs to publish.
	 *
	 * @param int $id The resource, or 0 for a new one.
	 */
	private function pdfRefusal( int $id, WP_REST_Request $request ): ?WP_Error {
		$fileId = $request->has_param( 'pdf_file_id' ) ? absint( $request['pdf_file_id'] ) : 0;
		if ( 0 === $fileId || ( $id > 0 && (int) get_post_meta( $id, Meta::KEY_PDF_FILE_ID, true ) === $fileId ) ) {
			return null;
		}
		$file = get_post( $fileId );
		$mine = $this->scope()->isAdmin || ( $id > 0 && $file && (int) $file->post_parent === $id );
		if ( ! $file || 'attachment' !== $file->post_type || 'application/pdf' !== $file->post_mime_type || ! $mine ) {
			return $this->invalidField( 'pdf_file', __( 'Choose a PDF uploaded to this resource.', 'monstera' ) );
		}
		return null;
	}

	/**
	 * An audience list as stored. One that was never written reads back as
	 * '', which would otherwise count as one organization with id 0.
	 *
	 * @return int[]
	 */
	private static function ids( mixed $meta ): array {
		return array_values( array_filter( array_map( 'intval', (array) $meta ) ) );
	}

	private function applyMutations( int $id, WP_REST_Request $request ): void {
		$isAdmin = $this->scope()->isAdmin;

		if ( $request->has_param( 'form_type' ) ) {
			$t = (string) $request['form_type'];
			// Shortcode forms can execute arbitrary code, so delegated authors are
			// limited to PDF and external-URL forms.
			$allowedTypes = $isAdmin
				? [ Meta::TYPE_PDF, Meta::TYPE_SHORTCODE, Meta::TYPE_EXTERNAL ]
				: [ Meta::TYPE_PDF, Meta::TYPE_EXTERNAL ];
			if ( in_array( $t, $allowedTypes, true ) ) {
				update_post_meta( $id, Meta::KEY_FORM_TYPE, $t );
			}
		}
		if ( $request->has_param( 'description' ) ) {
			update_post_meta( $id, Meta::KEY_DESCRIPTION, wp_kses_post( (string) $request['description'] ) );
		}
		if ( $request->has_param( 'pdf_file_id' ) ) {
			update_post_meta( $id, Meta::KEY_PDF_FILE_ID, absint( $request['pdf_file_id'] ) );
		}
		// Only admins may set a shortcode body (code execution surface).
		if ( $isAdmin && $request->has_param( 'shortcode' ) ) {
			update_post_meta( $id, Meta::KEY_SHORTCODE, wp_kses_post( (string) $request['shortcode'] ) );
		}
		if ( $request->has_param( 'external_url' ) ) {
			update_post_meta( $id, Meta::KEY_EXTERNAL_URL, esc_url_raw( (string) $request['external_url'] ) );
		}
		if ( $request->has_param( 'allowed_roles' ) ) {
			update_post_meta( $id, Meta::KEY_ROLES, array_values( array_map( 'sanitize_key', (array) $request['allowed_roles'] ) ) );
		}

		$this->applyAudience( $id, $request );
	}

	/**
	 * Forms store audience as post-meta arrays. Admins write whatever they send;
	 * delegated authors are forced to their own org (no standalone targeting) and
	 * their sub-group selection is clamped (a leader to their one sub-group).
	 */
	private function applyAudience( int $id, WP_REST_Request $request ): void {
		$scope = $this->scope();
		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'org_ids' ) ) {
				update_post_meta( $id, Meta::KEY_ORGS, array_values( array_map( 'absint', (array) $request['org_ids'] ) ) );
			}
			if ( $request->has_param( 'standalone_member_ids' ) ) {
				update_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, array_values( array_map( 'absint', (array) $request['standalone_member_ids'] ) ) );
			}
			if ( $request->has_param( 'subgroup_ids' ) ) {
				$proposed = array_map( 'absint', (array) $request['subgroup_ids'] );
				$orgIds   = self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) );
				$memIds   = self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) );
				// A sub-group narrows the audience it belongs to. With nobody
				// listed the resource is for every member, and any sub-group can
				// narrow that.
				$valid = $orgIds || $memIds
					? ContentController::filterSubgroupsByAudience( $proposed, $orgIds, $memIds )
					: ContentController::existingSubgroups( $proposed );
				update_post_meta( $id, Meta::KEY_SUBGROUPS, array_values( $valid ) );
			}
			return;
		}

		$orgIds = $scope->clampOrgIds( [] );
		update_post_meta( $id, Meta::KEY_ORGS, $orgIds );
		update_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, [] );

		if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
			$proposed = $scope->clampSubgroupIds( (array) ( $request['subgroup_ids'] ?? [] ) );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgIds, [] );
			update_post_meta( $id, Meta::KEY_SUBGROUPS, array_values( $valid ) );
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		$post   = get_post( $id );
		$orgIds = self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) );
		$memIds = self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) );
		$sgIds  = self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) );
		$author = $post ? get_userdata( (int) $post->post_author ) : false;

		return [
			'id'                    => $id,
			// As stored: the detail saves it back.
			'title'                 => (string) get_post_field( 'post_title', $id, 'raw' ),
			'status'                => (string) $post?->post_status,
			'form_type'             => (string) ( get_post_meta( $id, Meta::KEY_FORM_TYPE, true ) ?: Meta::TYPE_PDF ),
			'description'           => (string) get_post_meta( $id, Meta::KEY_DESCRIPTION, true ),
			'pdf_file_id'           => (int) get_post_meta( $id, Meta::KEY_PDF_FILE_ID, true ),
			'shortcode'             => (string) get_post_meta( $id, Meta::KEY_SHORTCODE, true ),
			'external_url'          => (string) get_post_meta( $id, Meta::KEY_EXTERNAL_URL, true ),
			'org_ids'               => $orgIds,
			'standalone_member_ids' => $memIds,
			'subgroup_ids'          => $sgIds,
			'allowed_roles'         => array_values( array_filter( array_map( 'sanitize_key', (array) get_post_meta( $id, Meta::KEY_ROLES, true ) ) ) ),
			'edit_url'              => admin_url( 'admin.php?page=monstera-forms&id=' . $id ),
			// The head and the sidebar (comp 125).
			'modified'              => (string) get_post_modified_time( 'c', true, $id ),
			'author_name'           => $author ? UserMeta::fullName( $author ) : '',
			// A delegated author (an organization manager) adds resources from
			// the portal's Manage tab; an admin adds them here.
			'from_portal'           => $author && ! user_can( $author, Capabilities::CAP_MANAGE_MONSTERA ),
			'portal_url'            => Routing::url( Routing::ROUTE_FORMS ),
			'org_names'             => array_values( array_filter( array_map( static fn ( int $orgId ): string => (string) get_the_title( $orgId ), $orgIds ) ) ),
			'pdf_file'              => $this->pdfFacts( (int) get_post_meta( $id, Meta::KEY_PDF_FILE_ID, true ) ),
			// Opens are logged while Reporting is on.
			'facts'                 => [ 'opens_30d' => $this->factOf( \Monstera\Core\Modules::REPORTING, fn (): int => $this->opensLast30Days( $id ) ) ],
			'saved'                 => $this->savedStamp( $id ),
		];
	}

	/**
	 * The attached PDF's name and size, for the file picker, or null.
	 *
	 * @return array{id: int, name: string, size: int}|null
	 */
	private function pdfFacts( int $attachmentId ): ?array {
		$path = $attachmentId ? get_attached_file( $attachmentId ) : false;
		if ( ! $path ) {
			return null;
		}
		return [
			'id'   => $attachmentId,
			'name' => wp_basename( $path ),
			'size' => is_file( $path ) ? (int) filesize( $path ) : 0,
		];
	}

	/** How many times members opened the resource in the last 30 days. */
	private function opensLast30Days( int $id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a count from Monstera's own log, read once per detail load.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE object_type = %s AND object_id = %d AND event_type = %s AND occurred_at >= %s',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				'form',
				$id,
				'form_opened',
				gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS )
			)
		);
	}

	/**
	 * @param array<int, int> $memIds
	 * @param array<int, int> $orgIds
	 */
	private function summarizeAccess( array $orgIds, array $memIds ): string {
		$parts = [];
		if ( $orgIds ) {
			$parts[] = sprintf(
				/* translators: %d count */
				_n( '%d org', '%d orgs', count( $orgIds ), 'monstera' ),
				count( $orgIds )
			);
		}
		if ( $memIds ) {
			$parts[] = sprintf(
				/* translators: %d count */
				_n( '%d standalone member', '%d standalone members', count( $memIds ), 'monstera' ),
				count( $memIds )
			);
		}
		return $parts ? implode( ' + ', $parts ) : (string) __( 'All members', 'monstera' );
	}
}
