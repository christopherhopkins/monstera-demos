<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Forms\Fields;
use Monstera\Forms\Meta;
use Monstera\Forms\PostType;
use Monstera\Forms\Submissions;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Roster;
use Monstera\Portal\AudienceShown;
use Monstera\Portal\AuthorScope;
use WP_Error;
use WP_Query;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * The forms routes (Forms-and-resources track, FR10): a form built here or
 * embedding a shortcode, its questions and settings, its audience. Until
 * 2026-10-26 these routes carried the library, which ResourcesController
 * has now. FormSubmissionsController carries the submissions routes.
 */
final class FormsController extends BaseController {

	use SaysAudience;

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/forms',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/forms/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}|WP_Error
	 */
	public function index( WP_REST_Request $request ): array|WP_Error {
		$own = $this->ownAuthorQueryArgs( $request, PostType::SLUG );
		if ( $own instanceof WP_Error ) {
			return $own;
		}
		$q = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft' ],
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				],
				$own
			)
		);
		// A client author is told of their own part of each audience alone
		// (Portal\AudienceShown), by name; staff of all of it.
		$caller = wp_get_current_user();
		$whole  = AudienceShown::whole( $caller );
		// Each form's submissions counted in one grouped read, and the
		// authors and organizations read once (Forms-and-resources track, NFR
		// Query cost; the Phase 5 review's note). A client author counts their
		// own organizations' (Phase 5 review): a form staff shared further
		// reaches others too.
		$counts = Submissions::countsFor( array_map( static fn ( \WP_Post $post ): int => (int) $post->ID, $q->posts ), $whole ? null : Roster::orgIdsOf( (int) $caller->ID ) );
		self::primeAuthorsAndOrgs( $q->posts, Meta::KEY_ORGS, Meta::KEY_SUBGROUPS );
		$out = [];
		foreach ( $q->posts as $post ) {
			$id       = (int) $post->ID;
			$allOrgs  = self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) );
			$allMems  = self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) );
			$orgIds   = AudienceShown::orgs( $caller, $allOrgs );
			$orgNames = array_values( array_filter( array_map( 'get_the_title', $orgIds ) ) );
			$author   = get_userdata( (int) $post->post_author );
			$out[]    = [
				'id'             => $id,
				'title'          => get_the_title( $post ),
				'kind'           => Meta::kindOf( $id ),
				'access_summary' => $this->summarizeAccess( $allOrgs, $allMems ),
				// In words for staff, by name (comp 105); the counts for a
				// client author.
				'audience'       => $whole ? $this->audienceInWords( self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) ), $allOrgs, $allMems ) : $this->summarizeAccess( $allOrgs, $allMems ),
				// An embed's sub-line; a shortcode is staff's to read.
				'shortcode'      => $whole && Meta::KIND_EMBED === Meta::kindOf( $id ) ? (string) get_post_meta( $id, Meta::KEY_SHORTCODE, true ) : '',
				'status'         => $post->post_status,
				'source'         => $orgNames ? implode( ', ', $orgNames ) : (string) get_bloginfo( 'name' ),
				'questions'      => count( Meta::fieldsOf( $id ) ),
				'accepting'      => Meta::accepting( $id ),
				'due_on'         => Meta::dueOn( $id ),
				'once_only'      => Meta::onceOnly( $id ),
				'submissions'    => $counts[ $id ],
				'modified'       => get_post_modified_time( 'c', true, $post ),
				'author_name'    => $author ? UserMeta::fullName( $author ) : '',
				'author_portal'  => ! Meta::builtByTeam( $id ),
				'edit_url'       => admin_url( 'admin.php?page=monstera-forms&id=' . $id ),
			];
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		// The builder's facts and warnings (comp 125): staff's, with a read;
		// they count every organization's submissions.
		$shape = $this->shape( $id );
		if ( AudienceShown::whole( wp_get_current_user() ) ) {
			$shape['answered'] = (object) Submissions::answerCounts( $id );
		}
		return $shape;
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		// The organization the form is for, and the caller's tier there.
		$scope = $this->authoringScope( $request );
		if ( $scope instanceof WP_Error ) {
			return $scope;
		}
		// A sub-group's leader builds no form: the organization's admins and
		// managers build them and read the answers (AuthorScope, FR6).
		if ( ! $scope->canCreate( AuthorScope::ENTITY_FORM ) ) {
			return new WP_Error( 'monstera_forbidden', __( 'Only the organization’s admins and managers build forms.', 'monstera' ), [ 'status' => 403 ] );
		}
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'Give the form a title.', 'monstera' ) );
		}
		$refusal = $this->refusal( $request, $scope );
		if ( $refusal ) {
			return $refusal;
		}
		$status = sanitize_key( (string) ( $request['status'] ?? 'publish' ) );

		$id = wp_insert_post(
			[
				'post_type'   => PostType::SLUG,
				'post_title'  => $title,
				'post_status' => in_array( $status, [ 'publish', 'draft' ], true ) ? $status : 'draft',
				'post_author' => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		// A staff create from a hub's Manage tab is for that hub.
		$hub = $this->hubOfStaffCreate( $request, $scope );
		if ( $hub > 0 ) {
			update_post_meta( (int) $id, Meta::KEY_ORGS, [ $hub ] );
		}
		$this->applyMutations( (int) $id, $request, $scope );
		$this->stampEditor( (int) $id );
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		// Written in the form's own organization, so a save never moves it.
		$scope   = $this->itemScope( $id );
		$refusal = $this->refusal( $request, $scope, $id );
		if ( $refusal ) {
			return $refusal;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'Give the form a title.', 'monstera' ) );
			}
		}
		if ( $request->has_param( 'status' ) ) {
			$status = sanitize_key( (string) $request['status'] );
			if ( in_array( $status, [ 'publish', 'draft' ], true ) ) {
				$core['post_status'] = $status;
			}
		}
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}

		$this->applyMutations( $id, $request, $scope );
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/**
	 * Why a save cannot be taken as sent, or null: a kind that is not one,
	 * an embed from someone who is not staff (a shortcode runs code), a
	 * question list that does not validate, a due day that is no day.
	 */
	private function refusal( WP_REST_Request $request, AuthorScope $scope, int $id = 0 ): ?WP_Error {
		if ( $request->has_param( 'kind' ) ) {
			$kind = (string) $request['kind'];
			if ( ! in_array( $kind, Meta::KINDS, true ) ) {
				return $this->invalidField( 'kind', __( 'A form is built here or embedded.', 'monstera' ) );
			}
			if ( Meta::KIND_EMBED === $kind && ! $scope->isAdmin ) {
				return $this->invalidField( 'kind', __( 'Only the team embeds another plugin\'s form.', 'monstera' ) );
			}
		}
		// The questions of a form built here; an embed asks none of its own
		// (the kind sent, else the form's, else built for a new one).
		$kind = $request->has_param( 'kind' ) ? (string) $request['kind'] : ( $id > 0 ? Meta::kindOf( $id ) : Meta::KIND_BUILT );
		if ( Meta::KIND_BUILT === $kind && $request->has_param( 'fields' ) ) {
			$valid = Fields::validate( self::fieldsSent( $request ) );
			if ( is_string( $valid ) ) {
				return $this->invalidField( 'fields', $valid );
			}
		}
		// The addresses each send emails, as typed in Manage or listed in the
		// admin; either way the refusal names the field both show, `emails`.
		$listed = $request->has_param( 'emails' )
			? (array) preg_split( '/[,\s]+/', (string) $request['emails'], -1, PREG_SPLIT_NO_EMPTY )
			: (array) ( ( (array) ( $request['recipients'] ?? [] ) )['emails'] ?? [] );
		if ( count( self::distinctAddresses( $listed ) ) > Meta::MAX_EMAILS ) {
			return $this->invalidField(
				'emails',
				sprintf(
					/* translators: %d: the most addresses a form emails */
					__( 'A form emails at most %d addresses. The organization\'s admins and managers have their own switch.', 'monstera' ),
					Meta::MAX_EMAILS
				)
			);
		}
		if ( $request->has_param( 'due_on' ) ) {
			$due = trim( (string) $request['due_on'] );
			if ( '' !== $due && ! \Monstera\Core\SiteDay::isDay( $due ) ) {
				return $this->invalidField( 'due_on', __( 'Write the due day as a date.', 'monstera' ) );
			}
		}
		return null;
	}

	/**
	 * The valid addresses in a list, each once, as Meta::tidyRecipients()
	 * reads them before it keeps the first ten.
	 *
	 * @param array<int|string, mixed> $emails
	 * @return list<string>
	 */
	private static function distinctAddresses( array $emails ): array {
		$out = [];
		foreach ( $emails as $email ) {
			$email = strtolower( trim( sanitize_email( (string) $email ) ) );
			if ( '' !== $email && is_email( $email ) ) {
				$out[ $email ] = true;
			}
		}
		return array_keys( $out );
	}

	/**
	 * An audience list as stored. One that was never written reads back as
	 * '', which would otherwise count as one organization with id 0.
	 *
	 * @return int[]
	 */
	private static function ids( mixed $meta ): array {
		return array_values( array_filter( array_map( 'intval', (array) $meta ) ) );
	}

	/**
	 * The questions as sent: a list, or the JSON the portal's builder writes
	 * into the Manage form's field (anything else is no list, which
	 * Fields::validate() names).
	 */
	private static function fieldsSent( WP_REST_Request $request ): mixed {
		$fields = $request['fields'];
		return is_string( $fields ) ? json_decode( $fields, true ) : $fields;
	}

	/**
	 * Writes the fields a save carries, refusal() having passed them. The
	 * scope is the caller's in the organization the save acts on: the one a
	 * create names, an existing form's own.
	 */
	private function applyMutations( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		if ( $request->has_param( 'kind' ) ) {
			update_post_meta( $id, Meta::KEY_KIND, (string) $request['kind'] );
		}
		if ( $request->has_param( 'description' ) ) {
			update_post_meta( $id, Meta::KEY_DESCRIPTION, sanitize_text_field( (string) $request['description'] ) );
		}
		// The intro: block markup, filtered as a post an editor may save.
		if ( $request->has_param( 'intro' ) ) {
			wp_update_post(
				[
					'ID'           => $id,
					'post_content' => wp_slash( $this->bodyFrom( (string) $request['intro'] ) ),
				]
			);
			$this->stampBody( $id );
		}
		// The questions: as a list, or as the JSON the portal's builder writes
		// into the Manage form's field.
		if ( $request->has_param( 'fields' ) ) {
			$valid = Fields::validate( self::fieldsSent( $request ), Fields::MAX, array_keys( Submissions::answerCounts( $id ) ) );
			if ( is_array( $valid ) ) {
				Meta::saveFields( $id, $valid );
			}
		}
		// Only staff set a shortcode (code execution surface).
		if ( $scope->isAdmin && $request->has_param( 'shortcode' ) ) {
			update_post_meta( $id, Meta::KEY_SHORTCODE, wp_kses_post( (string) $request['shortcode'] ) );
		}
		// The recipients: as one value, or as the Manage form's own two
		// fields, the leads switch and the addresses typed with commas.
		if ( $request->has_param( 'emails' ) || $request->has_param( 'org_leads' ) ) {
			$was = Meta::recipientsOf( $id );
			update_post_meta(
				$id,
				Meta::KEY_RECIPIENTS,
				Meta::tidyRecipients(
					[
						'emails'    => $request->has_param( 'emails' ) ? preg_split( '/[,\s]+/', (string) $request['emails'], -1, PREG_SPLIT_NO_EMPTY ) : $was['emails'],
						'org_leads' => $request->has_param( 'org_leads' ) ? $request['org_leads'] : $was['org_leads'],
					]
				)
			);
		} elseif ( $request->has_param( 'recipients' ) ) {
			update_post_meta( $id, Meta::KEY_RECIPIENTS, Meta::tidyRecipients( $request['recipients'] ) );
		}
		foreach ( [
			'accepting' => Meta::KEY_ACCEPTING,
			'once_only' => Meta::KEY_ONCE_ONLY,
			'remind'    => Meta::KEY_REMIND,
		] as $param => $key ) {
			if ( $request->has_param( $param ) ) {
				update_post_meta( $id, $key, Meta::truthy( $request[ $param ] ) ? '1' : '0' );
			}
		}
		foreach ( [
			'closed_message' => Meta::KEY_CLOSED_MESSAGE,
			'confirmation'   => Meta::KEY_CONFIRMATION,
		] as $param => $key ) {
			if ( $request->has_param( $param ) ) {
				update_post_meta( $id, $key, sanitize_text_field( (string) $request[ $param ] ) );
			}
		}
		if ( $request->has_param( 'due_on' ) ) {
			update_post_meta( $id, Meta::KEY_DUE_ON, trim( (string) $request['due_on'] ) );
		}
		// Whose roles it reaches is part of who it reaches: held, with the rest
		// of the audience, while staff have shared it beyond the author's part.
		if ( $request->has_param( 'allowed_roles' ) && ( $scope->isAdmin || ! $scope->isSharedFurther( $id ) ) ) {
			update_post_meta( $id, Meta::KEY_ROLES, array_values( array_map( 'sanitize_key', (array) $request['allowed_roles'] ) ) );
		}

		$this->applyAudience( $id, $request, $scope );
	}

	/**
	 * Forms store audience as post-meta arrays. Admins write whatever they
	 * send; delegated authors are forced to the scope's organization (no
	 * standalone targeting) and their sub-group selection is clamped (a
	 * leader to the sub-group they lead there). One staff shared beyond that
	 * part keeps its audience through their saves.
	 */
	private function applyAudience( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'org_ids' ) ) {
				update_post_meta( $id, Meta::KEY_ORGS, array_values( array_map( 'absint', (array) $request['org_ids'] ) ) );
			}
			if ( $request->has_param( 'standalone_member_ids' ) ) {
				update_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, array_values( array_map( 'absint', (array) $request['standalone_member_ids'] ) ) );
			}
			// A sub-group no picker shows stays unless the save lifts the
			// limit (ContentController::gateAfterSave()).
			$lift = ContentController::liftsDeletedGate( $request );
			if ( $request->has_param( 'subgroup_ids' ) || $lift ) {
				$proposed = array_map( 'absint', (array) ( $request['subgroup_ids'] ?? [] ) );
				$orgIds   = self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) );
				$memIds   = self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) );
				// A sub-group narrows the audience it belongs to. With nobody
				// listed the form is for every member, and any sub-group can
				// narrow that.
				$valid = $orgIds || $memIds
					? ContentController::filterSubgroupsByAudience( $proposed, $orgIds, $memIds )
					: ContentController::existingSubgroups( $proposed );
				update_post_meta( $id, Meta::KEY_SUBGROUPS, ContentController::gateAfterSave( self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) ), $valid, $lift, $request->has_param( 'subgroup_ids' ) ) );
			}
			return;
		}

		// A form staff shared beyond the author's part keeps its audience
		// whole through the author's saves (AuthorScope::isSharedFurther()).
		if ( $scope->isSharedFurther( $id ) ) {
			return;
		}
		$orgIds = $scope->clampOrgIds( [] );
		update_post_meta( $id, Meta::KEY_ORGS, $orgIds );
		update_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, [] );

		if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
			$proposed = $scope->subgroupIdsForSave( $id, $request->has_param( 'subgroup_ids' ) ? (array) $request['subgroup_ids'] : null );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgIds, [] );
			// A sub-group their form cannot show stays (gateAfterSave()).
			update_post_meta( $id, Meta::KEY_SUBGROUPS, ContentController::gateAfterSave( self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) ), $valid, false ) );
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Form not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		// A client author is told of their own part of the audience alone
		// (Portal\AudienceShown); staff of all of it.
		$caller = wp_get_current_user();
		$post   = get_post( $id );
		$orgIds = AudienceShown::orgs( $caller, self::ids( get_post_meta( $id, Meta::KEY_ORGS, true ) ) );
		$memIds = AudienceShown::members( $caller, self::ids( get_post_meta( $id, Meta::KEY_STANDALONE_MEMBERS, true ) ) );
		$sgAll  = self::ids( get_post_meta( $id, Meta::KEY_SUBGROUPS, true ) );
		// A picker is handed the published ones (AudienceShown::subgroups()),
		// and a save keeps the rest (ContentController::gateAfterSave()).
		$sgIds  = AudienceShown::subgroups( $caller, $sgAll );
		$author = $post ? get_userdata( (int) $post->post_author ) : false;

		return [
			'id'                     => $id,
			// As stored: the detail saves it back.
			'title'                  => (string) get_post_field( 'post_title', $id, 'raw' ),
			'status'                 => (string) $post?->post_status,
			'kind'                   => Meta::kindOf( $id ),
			'description'            => (string) get_post_meta( $id, Meta::KEY_DESCRIPTION, true ),
			'intro'                  => (string) get_post_field( 'post_content', $id, 'raw' ),
			'fields'                 => Meta::fieldsOf( $id ),
			'shortcode'              => $this->scope()->isAdmin ? (string) get_post_meta( $id, Meta::KEY_SHORTCODE, true ) : '',
			'recipients'             => Meta::recipientsOf( $id ),
			'accepting'              => Meta::accepting( $id ),
			// The form's own words as stored ('' for none), and what is said
			// without them, for a placeholder: a save never stores a default.
			'closed_message'         => trim( (string) get_post_meta( $id, Meta::KEY_CLOSED_MESSAGE, true ) ),
			'closed_message_default' => __( 'This form is closed.', 'monstera' ),
			'confirmation'           => trim( (string) get_post_meta( $id, Meta::KEY_CONFIRMATION, true ) ),
			'confirmation_default'   => __( 'Thanks, we have your answers.', 'monstera' ),
			'once_only'              => Meta::onceOnly( $id ),
			'due_on'                 => Meta::dueOn( $id ),
			// As set (on unless turned off): they go while a due day is set.
			'remind'                 => Meta::remindWanted( $id ),
			// How many were sent and when the last came (FR8's columns).
			'submissions'            => Submissions::countFor( $id, AudienceShown::whole( $caller ) ? null : Roster::orgIdsOf( (int) $caller->ID ) ),
			'org_ids'                => $orgIds,
			'standalone_member_ids'  => $memIds,
			'subgroup_ids'           => $sgIds,
			// Sub-groups no picker shows that are all it is limited to: the
			// detail says the limit holds and offers to lift it (staff's).
			'subgroups_unavailable'  => AudienceShown::whole( $caller ) ? ContentController::unavailableGate( $sgAll ) : 0,
			'allowed_roles'          => array_values( array_filter( array_map( 'sanitize_key', (array) get_post_meta( $id, Meta::KEY_ROLES, true ) ) ) ),
			'edit_url'               => admin_url( 'admin.php?page=monstera-forms&id=' . $id ),
			// The head and the sidebar (comp 125).
			'modified'               => (string) get_post_modified_time( 'c', true, $id ),
			'author_name'            => $author ? UserMeta::fullName( $author ) : '',
			// A delegated author (an organization manager) builds forms from
			// the portal's Manage tab; the team builds them here.
			'from_portal'            => ! Meta::builtByTeam( $id ),
			'portal_url'             => Routing::url( Routing::ROUTE_FORMS ),
			// "View in portal" (comp 125): a live form's own page; a draft is
			// nowhere a member looks yet.
			'view_url'               => 'publish' === (string) $post?->post_status ? Routing::url( Routing::ROUTE_FORM, [ 'id' => $id ] ) : '',
			'org_names'              => array_values( array_filter( array_map( static fn ( int $orgId ): string => (string) get_the_title( $orgId ), $orgIds ) ) ),
			'saved'                  => $this->savedStamp( $id ),
		];
	}

	/**
	 * @param array<int, int> $memIds
	 * @param array<int, int> $orgIds
	 */
	private function summarizeAccess( array $orgIds, array $memIds ): string {
		$parts = [];
		if ( $orgIds ) {
			$parts[] = sprintf(
				/* translators: %d count */
				_n( '%d org', '%d orgs', count( $orgIds ), 'monstera' ),
				count( $orgIds )
			);
		}
		if ( $memIds ) {
			$parts[] = sprintf(
				/* translators: %d count */
				_n( '%d standalone member', '%d standalone members', count( $memIds ), 'monstera' ),
				count( $memIds )
			);
		}
		return $parts ? implode( ' + ', $parts ) : (string) __( 'All members', 'monstera' );
	}
}
