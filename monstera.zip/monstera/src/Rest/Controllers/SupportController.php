<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Support\Repository;
use WP_Error;
use WP_REST_Request;

final class SupportController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/support/requests',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_SUPPORT ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/mine',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'mine' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/(?P<id>\d+)/resolve',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'resolve' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/(?P<id>\d+)/status',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'setStatus' ],
				'args'                => [
					'status' => [
						'type'     => 'string',
						'required' => true,
						'enum'     => [ Repository::STATUS_OPEN, Repository::STATUS_PENDING, Repository::STATUS_RESOLVED, Repository::STATUS_CLOSED ],
					],
				],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$repo = new Repository();
		$rows = $repo->inbox(
			[
				'status'     => (string) $request->get_param( 'status' ),
				'project_id' => absint( $request->get_param( 'project_id' ) ),
			]
		);
		return [ 'items' => array_map( [ $this, 'decorate' ], $rows ) ];
	}

	/**
	 * The names behind a request's ids, for the list's sub-line: who asked,
	 * their organization and the project it is about.
	 *
	 * @param array<string, mixed> $row
	 * @return array<string, mixed>
	 */
	private function decorate( array $row ): array {
		$member               = get_userdata( (int) ( $row['member_id'] ?? 0 ) );
		$row['member_name']   = $member ? UserMeta::fullName( $member ) : '';
		$row['org_name']      = ! empty( $row['org_id'] ) ? (string) get_the_title( (int) $row['org_id'] ) : '';
		$row['project_title'] = ! empty( $row['project_id'] ) ? (string) get_the_title( (int) $row['project_id'] ) : '';
		return $row;
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function mine(): array {
		return [ 'items' => ( new Repository() )->listForMember( get_current_user_id() ) ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$data = $request->get_json_params() ?: $request->get_params();

		$userId  = get_current_user_id();
		$subject = sanitize_text_field( (string) ( $data['subject'] ?? '' ) );
		$body    = wp_kses_post( (string) ( $data['body'] ?? '' ) );
		if ( '' === $subject ) {
			return $this->invalidField( 'subject', __( 'Give the request a subject.', 'monstera' ) );
		}
		if ( '' === trim( wp_strip_all_tags( $body ) ) ) {
			return $this->invalidField( 'body', __( 'Describe what you need.', 'monstera' ) );
		}
		// A request is about a project the member can open and carries a file
		// they uploaded; the ids arrive from the page and are not taken on trust.
		$projectId = absint( $data['project_id'] ?? 0 );
		if ( $projectId > 0 && ! ( new \Monstera\Projects\Repository() )->userCanAccess( $userId, $projectId ) ) {
			return $this->invalidField( 'project_id', __( 'Choose one of your own projects.', 'monstera' ) );
		}
		$fileId = absint( $data['attachment_id'] ?? 0 );
		$file   = $fileId > 0 ? get_post( $fileId ) : null;
		if ( $fileId > 0 && ( ! $file || 'attachment' !== $file->post_type || (int) $file->post_author !== $userId ) ) {
			return $this->invalidField( 'attachment_id', __( 'Attach a file you uploaded.', 'monstera' ) );
		}
		// Each request emails the support inbox.
		if ( ! $this->canManage() && $this->overLimit( 'support_request', 5, 10 * MINUTE_IN_SECONDS ) ) {
			return $this->tooMany( __( 'That is several requests in a few minutes. Wait ten minutes, then send the next one.', 'monstera' ) );
		}

		$row = ( new Repository() )->create(
			$userId,
			$subject,
			$body,
			sanitize_key( (string) ( $data['priority'] ?? Repository::PRIORITY_NORMAL ) ),
			$projectId ?: null,
			$fileId ?: null
		);

		return [
			'ok'        => true,
			'reference' => $row['ref'] ?? '',
			'id'        => (int) ( $row['id'] ?? 0 ),
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function resolve( WP_REST_Request $request ): array|WP_Error {
		$ok = ( new Repository() )->resolve( (int) $request['id'], get_current_user_id() );
		if ( ! $ok ) {
			return new \WP_Error( 'monstera_not_found', __( 'Support request not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return [ 'ok' => true ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function setStatus( WP_REST_Request $request ): array|WP_Error {
		$status = (string) $request->get_param( 'status' );
		$ok     = ( new Repository() )->setStatus( (int) $request['id'], $status, get_current_user_id() );
		if ( ! $ok ) {
			return new \WP_Error( 'monstera_not_found', __( 'Support request not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return [
			'ok'     => true,
			'status' => $status,
		];
	}
}
