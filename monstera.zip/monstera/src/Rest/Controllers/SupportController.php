<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Content\Downloader;
use Monstera\Content\SecureFiles;
use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Projects\IntakeFiles;
use Monstera\Reporting\ActivityFeed;
use Monstera\Reporting\ActivityLog;
use Monstera\Support\ClosedRequest;
use Monstera\Support\Files;
use Monstera\Support\FilesRefused;
use Monstera\Support\Repository;
use Monstera\Support\Thread;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || exit;

final class SupportController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/support/requests',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_SUPPORT ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/mine',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'mine' ],
			]
		);

		foreach ( [
			'reply'    => 'mineReply',
			'priority' => 'minePriority',
			'resolve'  => 'mineResolve',
		] as $action => $method ) {
			register_rest_route(
				$this->restNamespace,
				'/support/requests/mine/(?P<id>\d+)/' . $action,
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_SUPPORT ),
					'callback'            => [ $this, $method ],
				]
			);
		}

		register_rest_route(
			$this->restNamespace,
			'/support/requests/mine/(?P<id>\d+)/files',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionLoggedIn(),
				'callback'            => [ $this, 'mineFiles' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/(?P<id>\d+)',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'show' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/(?P<id>\d+)/messages',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'reply' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/(?P<id>\d+)/resolve',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'resolve' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/support/requests/(?P<id>\d+)/status',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'setStatus' ],
				'args'                => [
					'status' => [
						'type'     => 'string',
						'required' => true,
						'enum'     => Repository::STATUSES,
					],
				],
			]
		);
	}

	/**
	 * The inbox, latest activity first.
	 *
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$repo = new Repository();
		$rows = $repo->inbox(
			[
				'status'     => (string) $request->get_param( 'status' ),
				'project_id' => absint( $request->get_param( 'project_id' ) ),
			]
		);
		$last = ( new Thread() )->lastActors( array_map( 'intval', array_column( $rows, 'id' ) ) );
		return [
			'items' => array_map(
				fn ( array $row ): array => $this->decorate( $row, $last[ (int) $row['id'] ] ?? (int) ( $row['member_id'] ?? 0 ) ),
				$rows
			),
		];
	}

	/**
	 * The names behind a request's ids, for the list's sub-line and its last
	 * activity: who asked, their organization, the project it is about, and
	 * who acted last.
	 *
	 * @param array<string, mixed> $row
	 * @param int                  $lastActorId Whoever wrote or changed something last; the member when nobody has since.
	 * @return array<string, mixed>
	 */
	private function decorate( array $row, int $lastActorId ): array {
		$row['member_name']   = $this->person( (int) ( $row['member_id'] ?? 0 ) )['name'];
		$row['org_name']      = ! empty( $row['org_id'] ) ? (string) get_the_title( (int) $row['org_id'] ) : '';
		$row['project_title'] = ! empty( $row['project_id'] ) ? (string) get_the_title( (int) $row['project_id'] ) : '';
		// The list's Last activity column has room for a first name.
		$actor                   = $this->person( $lastActorId );
		$row['last_actor']       = $actor['name'];
		$row['last_actor_first'] = $actor['first'];
		return $row;
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function mine(): array {
		return [ 'items' => ( new Repository() )->listForMember( get_current_user_id() ) ];
	}

	/**
	 * One request, whole: what staff read on its detail page.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		return $this->detail( (int) $request['id'] ) ?? $this->notFound();
	}

	/**
	 * A staff reply, with files. It leaves the request waiting on its
	 * member; the answer is the request as it now reads.
	 */
	public function reply( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$id   = (int) $request['id'];
		$repo = new Repository();
		if ( ! $repo->find( $id ) ) {
			return $this->notFound();
		}
		$message = $this->messageFrom( $request );
		if ( $message instanceof WP_Error ) {
			return $message;
		}
		try {
			$repo->reply( $id, get_current_user_id(), Thread::SIDE_STAFF, $message['body'], $message['uploads'] );
		} catch ( FilesRefused $refused ) {
			return $this->invalidField( 'files', $refused->reason() );
		} catch ( \RuntimeException $failure ) {
			return $this->notStored();
		}
		return new WP_REST_Response( $this->detail( $id ), 201 );
	}

	/**
	 * What a side sent as a message: its words and its files. A message
	 * needs words; files alone are not one.
	 *
	 * @return array{body: string, uploads: list<array{name: string, type: string, tmp_name: string, error: int, size: int}>}|WP_Error
	 */
	private function messageFrom( WP_REST_Request $request ): array|WP_Error {
		$body    = self::plainText( (string) $request->get_param( 'body' ) );
		$uploads = Files::normalise( $request->get_file_params()['files'] ?? null );
		if ( '' === $body && ! $uploads && self::bodyDropped( $request ) ) {
			return $this->tooLarge();
		}
		if ( '' === $body ) {
			return $this->invalidField( 'body', __( 'Write a reply before you send it.', 'monstera' ) );
		}
		return [
			'body'    => $body,
			'uploads' => $uploads,
		];
	}

	/**
	 * A request as its detail reads it: the opening message, the thread
	 * with each entry's author and files, every file with a link signed for
	 * the reader (never a path), the facts and the recent activity.
	 *
	 * @return array<string, mixed>|null Null when the request does not exist.
	 */
	private function detail( int $id ): ?array {
		$repo = new Repository();
		$row  = $repo->find( $id );
		if ( ! $row ) {
			return null;
		}
		$reader = get_current_user_id();
		$files  = ( new Files() )->forRequest( $id );
		$linked = static fn ( array $file ): array => [
			'id'       => (int) $file['id'],
			'name'     => (string) $file['name'],
			'size'     => (int) $file['size'],
			'type'     => (string) $file['type'],
			'is_image' => (bool) $file['is_image'],
			'url'      => Downloader::signedUrl( (int) $file['id'], $reader ),
		];

		$thread   = [];
		$messages = 1;
		$lastId   = (int) ( $row['member_id'] ?? 0 );
		foreach ( $repo->thread( $id ) as $entry ) {
			$messages += Thread::KIND_MESSAGE === $entry['kind'] ? 1 : 0;
			$lastId    = $entry['author_id'];
			$thread[]  = [
				'id'         => $entry['id'],
				'kind'       => $entry['kind'],
				'side'       => $entry['side'],
				'author'     => $this->person( $entry['author_id'] ),
				'body'       => $entry['body'],
				'event'      => $entry['event'],
				'created_at' => $entry['created_at'],
				'files'      => array_map( $linked, $files[ $entry['id'] ] ?? [] ),
			];
		}

		return [
			'id'               => (int) $row['id'],
			'ref'              => (string) $row['ref'],
			'subject'          => (string) $row['subject'],
			'body'             => (string) $row['body'],
			'priority'         => (string) $row['priority'],
			'status'           => (string) $row['status'],
			'created_at'       => self::utc( (string) $row['created_at'] ),
			'resolved_at'      => empty( $row['resolved_at'] ) ? null : self::utc( (string) $row['resolved_at'] ),
			'last_activity_at' => self::utc( (string) ( $row['last_activity_at'] ?: $row['created_at'] ) ),
			'last_side'        => (string) $row['last_side'],
			'last_actor'       => $this->person( $lastId )['name'],
			'last_actor_first' => $this->person( $lastId )['first'],
			'member'           => $this->person( (int) ( $row['member_id'] ?? 0 ) ),
			'org'              => empty( $row['org_id'] ) ? null : [
				'id'   => (int) $row['org_id'],
				'name' => (string) get_the_title( (int) $row['org_id'] ),
			],
			'project'          => empty( $row['project_id'] ) ? null : [
				'id'    => (int) $row['project_id'],
				'title' => (string) get_the_title( (int) $row['project_id'] ),
			],
			'files'            => array_map( $linked, $files[0] ?? [] ),
			'thread'           => $thread,
			'facts'            => [
				'messages' => $messages,
				'files'    => (int) array_sum( array_map( 'count', $files ) ),
			],
			'activity'         => ActivityFeed::shape( ActivityLog::forObject( 'support_request', $id, 8 ) ),
			// What a reply can carry, and the words for a file that cannot go,
			// so the composer checks before the send as the portal's picker does.
			'limits'           => [
				'max_bytes'  => Files::maxBytes(),
				'max_count'  => Files::maxCount(),
				'max_total'  => Files::maxTotal(),
				'accept'     => SecureFiles::accept(),
				'line'       => Files::limitsLine(),
				'too_big'    => Files::sayTooBig(),
				'wrong_type' => Files::sayWrongType(),
				'too_many'   => Files::sayTooMany(),
			],
		];
	}

	/**
	 * A person by id as a response names them, in full and by first name
	 * (for a sentence: "after Avery's reply"); nobody (id 0, no name) once
	 * their account is gone.
	 *
	 * @return array{id: int, name: string, first: string}
	 */
	private function person( int $userId ): array {
		$user = $userId > 0 ? get_userdata( $userId ) : false;
		return [
			'id'    => $user ? $userId : 0,
			'name'  => $user ? UserMeta::fullName( $user ) : '',
			'first' => $user ? (string) ( $user->first_name ?: $user->display_name ) : '',
		];
	}

	/** A stored UTC time as ISO 8601. */
	private static function utc( string $stored ): string {
		return gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $stored . ' UTC' ) );
	}

	private function notFound(): WP_Error {
		return new WP_Error( 'monstera_not_found', __( 'Support request not found.', 'monstera' ), [ 'status' => 404 ] );
	}

	private function notStored(): WP_Error {
		return new WP_Error( 'monstera_file_not_stored', __( 'The files could not be stored, so nothing was sent. Try again.', 'monstera' ), [ 'status' => 500 ] );
	}

	/**
	 * Open a request, with files. The portal's form posts fields and
	 * files[]; a client without files may post JSON.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$data = $request->get_json_params() ?: $request->get_params();

		$userId  = get_current_user_id();
		$subject = sanitize_text_field( (string) ( $data['subject'] ?? '' ) );
		$body    = self::plainText( (string) ( $data['body'] ?? '' ) );
		$uploads = Files::normalise( $request->get_file_params()['files'] ?? null );
		if ( '' === $subject && '' === $body && ! $uploads && self::bodyDropped( $request ) ) {
			return $this->tooLarge();
		}
		if ( '' === $subject ) {
			return $this->invalidField( 'subject', __( 'Give the request a subject.', 'monstera' ) );
		}
		if ( '' === $body ) {
			return $this->invalidField( 'body', __( 'Describe what you need.', 'monstera' ) );
		}
		// A request is about a project the member can open; the id arrives
		// from the page and is not taken on trust.
		$projectId = absint( $data['project_id'] ?? 0 );
		if ( $projectId > 0 && ! ( new \Monstera\Projects\Repository() )->userCanAccess( $userId, $projectId ) ) {
			return $this->invalidField( 'project_id', __( 'Choose one of your own projects.', 'monstera' ) );
		}
		// Before the limit: a refused file is not an attempt.
		$refusal = $uploads ? Files::refusal( $uploads ) : null;
		if ( null !== $refusal ) {
			return $this->invalidField( 'files', $refusal );
		}
		// Each request emails the support inbox.
		if ( ! $this->canManage() && $this->overLimit( 'support_request', 5, 10 * MINUTE_IN_SECONDS ) ) {
			return $this->tooMany( __( 'That is several requests in a few minutes. Wait ten minutes, then send the next one.', 'monstera' ) );
		}

		try {
			$row = ( new Repository() )->create(
				$userId,
				$subject,
				$body,
				sanitize_key( (string) ( $data['priority'] ?? Repository::PRIORITY_NORMAL ) ),
				$projectId ?: null,
				$uploads
			);
		} catch ( FilesRefused $refused ) {
			return $this->invalidField( 'files', $refused->reason() );
		} catch ( \RuntimeException $failure ) {
			return $this->notStored();
		}

		return [
			'ok'        => true,
			'reference' => $row['ref'] ?? '',
			'id'        => (int) ( $row['id'] ?? 0 ),
			// The request's own page, where the portal goes next.
			'url'       => $row ? Repository::portalUrl( $row ) : '',
		];
	}

	/**
	 * The requester's reply, with files. On a request that was waiting on
	 * them, resolved or closed, it opens the request again.
	 */
	public function mineReply( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$row = $this->ownRequest( (int) $request['id'], false );
		if ( $row instanceof WP_Error ) {
			return $row;
		}
		$message = $this->messageFrom( $request );
		if ( $message instanceof WP_Error ) {
			return $message;
		}
		// Before the limit: a refused file is not an attempt.
		$refusal = $message['uploads'] ? Files::refusal( $message['uploads'] ) : null;
		if ( null !== $refusal ) {
			return $this->invalidField( 'files', $refusal );
		}
		$limited = $this->limitedWrite();
		if ( $limited ) {
			return $limited;
		}
		$id   = (int) $row['id'];
		$repo = new Repository();
		try {
			$messageId = $repo->reply( $id, get_current_user_id(), Thread::SIDE_MEMBER, $message['body'], $message['uploads'] );
		} catch ( FilesRefused $refused ) {
			return $this->invalidField( 'files', $refused->reason() );
		} catch ( \RuntimeException $failure ) {
			return $this->notStored();
		}
		return new WP_REST_Response(
			[
				'ok'         => true,
				'status'     => (string) ( $repo->find( $id )['status'] ?? '' ),
				'message_id' => (int) $messageId,
			],
			201
		);
	}

	/**
	 * The requester says how urgent it is now.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function minePriority( WP_REST_Request $request ): array|WP_Error {
		$row = $this->ownRequest( (int) $request['id'] );
		if ( $row instanceof WP_Error ) {
			return $row;
		}
		$priority = sanitize_key( (string) $request->get_param( 'priority' ) );
		if ( ! in_array( $priority, Repository::PRIORITIES, true ) ) {
			return $this->invalidField( 'priority', __( 'Choose low, normal, high or urgent.', 'monstera' ) );
		}
		$limited = $this->limitedWrite();
		if ( $limited ) {
			return $limited;
		}
		try {
			( new Repository() )->setPriority( (int) $row['id'], $priority, get_current_user_id() );
		} catch ( ClosedRequest $closed ) {
			return $this->closed();
		}
		return [
			'ok'       => true,
			'priority' => $priority,
		];
	}

	/**
	 * The requester says it is resolved. A reply later opens it again.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function mineResolve( WP_REST_Request $request ): array|WP_Error {
		$row = $this->ownRequest( (int) $request['id'] );
		if ( $row instanceof WP_Error ) {
			return $row;
		}
		$limited = $this->limitedWrite();
		if ( $limited ) {
			return $limited;
		}
		try {
			( new Repository() )->setStatus( (int) $row['id'], Repository::STATUS_RESOLVED, get_current_user_id(), Thread::SIDE_MEMBER );
		} catch ( ClosedRequest $closed ) {
			return $this->closed();
		}
		return [
			'ok'     => true,
			'status' => Repository::STATUS_RESOLVED,
		];
	}

	/**
	 * Fresh links to a request's files, for its page left open past the
	 * five minutes a link lasts. A closed request is still read.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function mineFiles( WP_REST_Request $request ): array|WP_Error {
		$row = $this->ownRequest( (int) $request['id'], false );
		if ( $row instanceof WP_Error ) {
			return $row;
		}
		$reader = get_current_user_id();
		$links  = [];
		foreach ( ( new Files() )->forRequest( (int) $row['id'] ) as $files ) {
			foreach ( $files as $file ) {
				$links[] = [
					'id'  => (int) $file['id'],
					'url' => Downloader::signedUrl( (int) $file['id'], $reader ),
				];
			}
		}
		return [ 'files' => $links ];
	}

	/**
	 * The current user's own request, or the refusal. A request that is
	 * someone else's answers exactly as one that does not exist, so an id
	 * cannot be probed; staff use their own routes, so they are refused
	 * here too.
	 *
	 * @param bool $toWrite Refuse a closed request too: its priority and "resolved" wait until a reply has opened it.
	 * @return array<string, mixed>|WP_Error
	 */
	private function ownRequest( int $id, bool $toWrite = true ): array|WP_Error {
		$row = ( new Repository() )->find( $id );
		if ( ! $row || get_current_user_id() !== (int) $row['member_id'] ) {
			return new WP_Error( 'monstera_forbidden', __( 'That is not one of your requests.', 'monstera' ), [ 'status' => 403 ] );
		}
		return $toWrite && Repository::STATUS_CLOSED === $row['status'] ? $this->closed() : $row;
	}

	private function closed(): WP_Error {
		return new WP_Error( 'monstera_request_closed', __( 'This request is closed. Reply on it to open it again.', 'monstera' ), [ 'status' => 409 ] );
	}

	/**
	 * A member's replies, priority changes and "resolved" each email the
	 * support inbox, so together they are limited, apart from new requests.
	 */
	private function limitedWrite(): ?WP_Error {
		if ( ! $this->canManage() && $this->overLimit( 'support_thread', 10, 10 * MINUTE_IN_SECONDS ) ) {
			return $this->tooMany( __( 'That is a lot in a few minutes. Wait ten minutes, then send the next one.', 'monstera' ) );
		}
		return null;
	}

	/**
	 * A message as written: plain text, with its line breaks as newlines and
	 * nothing a terminal would act on. It is escaped where it is shown, so a
	 * "<" or an "&" a member typed stays what they typed.
	 */
	private static function plainText( string $written ): string {
		$text = str_replace( [ "\r\n", "\r" ], "\n", wp_check_invalid_utf8( $written, true ) );
		return trim( (string) preg_replace( '/[^\P{Cc}\n\t]+/u', '', $text ) );
	}

	/**
	 * Whether PHP discarded the request's body for its size: over
	 * post_max_size neither fields nor files arrive, only the length the
	 * browser declared.
	 */
	private static function bodyDropped( WP_REST_Request $request ): bool {
		return IntakeFiles::bodyTooLarge( (int) $request->get_header( 'content_length' ), (string) ini_get( 'post_max_size' ) );
	}

	private function tooLarge(): WP_Error {
		return $this->invalidField( 'files', __( 'That is too large to send at once. Send fewer or smaller files.', 'monstera' ) );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function resolve( WP_REST_Request $request ): array|WP_Error {
		$ok = ( new Repository() )->resolve( (int) $request['id'], get_current_user_id() );
		if ( ! $ok ) {
			return $this->notFound();
		}
		return [ 'ok' => true ];
	}

	/**
	 * A status staff chose. The change is an event in the request's thread.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function setStatus( WP_REST_Request $request ): array|WP_Error {
		$status = (string) $request->get_param( 'status' );
		$ok     = ( new Repository() )->setStatus( (int) $request['id'], $status, get_current_user_id() );
		if ( ! $ok ) {
			return $this->notFound();
		}
		return [
			'ok'     => true,
			'status' => $status,
		];
	}
}
