<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Content\Downloader;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Notifications\Dispatcher;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Portal\AudienceShown;
use Monstera\Portal\AuthorScope;
use Monstera\Projects\Discovery;
use Monstera\Projects\IntakeFiles;
use Monstera\Projects\Meta;
use Monstera\Projects\PostType;
use Monstera\Projects\Repository;
use Monstera\Reporting\ActivityLog;
use Monstera\Rest\DayField;
use Monstera\Support\Repository as SupportRepository;
use WP_Error;
use WP_Query;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || exit;

final class ProjectsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/projects',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/mine',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_VIEW_PROJECTS ),
				'callback'            => [ $this, 'mine' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_VIEW_PROJECTS ),
					'callback'            => [ $this, 'getIntake' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_INTAKE ),
					'callback'            => [ $this, 'submitIntake' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake/files',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_INTAKE ),
				'callback'            => [ $this, 'addIntakeFile' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake/files/(?P<file>\d+)',
			[
				'methods'             => 'DELETE',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_INTAKE ),
				'callback'            => [ $this, 'removeIntakeFile' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake/schema',
			[
				'methods'             => 'PUT',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'saveIntakeSchema' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/status',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'setStatus' ],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}|WP_Error
	 */
	public function index( WP_REST_Request $request ): array|WP_Error {
		$own = $this->ownAuthorQueryArgs( $request, PostType::SLUG );
		if ( $own instanceof WP_Error ) {
			return $own;
		}
		$q   = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft' ],
					'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- deliberate 200-item cap for the admin projects table.
					'orderby'        => 'modified',
					'order'          => 'DESC',
				],
				$own
			)
		);
		$out = [];
		foreach ( $q->posts as $post ) {
			$out[] = $this->summarize( $post );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		// The organization the project is for, and the caller's tier there.
		$scope = $this->authoringScope( $request );
		if ( $scope instanceof WP_Error ) {
			return $scope;
		}
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'Give the project a name.', 'monstera' ) );
		}
		// The team is checked against the organization the project is being
		// made for, before anything is written, as a save checks it.
		$refused = $this->refusedTeam( 0, $request, $scope ) ?? $this->refusedLead( $request ) ?? $this->refusedContact( 0, $request ) ?? $this->refusedNextStep( 0, $request ) ?? $this->refusedDays( $request );
		if ( $refused ) {
			return $refused;
		}

		$id = wp_insert_post(
			[
				'post_type'   => PostType::SLUG,
				'post_title'  => $title,
				'post_status' => 'draft' === sanitize_key( (string) ( $request['status_post'] ?? 'publish' ) ) ? 'draft' : 'publish',
				'post_author' => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$this->applyMutations( (int) $id, $request, $scope );
		$this->stampEditor( (int) $id );
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		// Judged and written in the project's own organization, so a save
		// never moves it to another one the caller manages.
		$scope = $this->itemScope( $id );
		$guard = $this->requireOwned( $id ) ?? $this->refusedStatus( $request ) ?? $this->refusedTeam( $id, $request, $scope ) ?? $this->refusedLead( $request ) ?? $this->refusedContact( $id, $request ) ?? $this->refusedNextStep( $id, $request ) ?? $this->refusedDays( $request );
		if ( $guard ) {
			return $guard;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'Give the project a title.', 'monstera' ) );
			}
		}
		if ( $request->has_param( 'description' ) ) {
			$core['post_content'] = wp_kses_post( (string) $request['description'] );
		}
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}

		$this->applyMutations( $id, $request, $scope );
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/**
	 * The next step for the client as the save would leave it (At-a-glance
	 * track, FR8): a sentence over the limit or a date that is not a day on
	 * the calendar, named as the field it is, before anything is written.
	 * A save that names one of the two is judged with the other as stored.
	 *
	 * @return array{0: string, 1: string}|null The sentence and the date the save asks for, or null when it names neither.
	 */
	private function nextStepAsked( int $id, WP_REST_Request $request ): ?array {
		if ( ! $request->has_param( 'next_step' ) && ! $request->has_param( 'next_step_by' ) ) {
			return null;
		}
		$current = ( $id > 0 ? ( new Repository() )->nextStep( $id ) : null ) ?? [
			'sentence' => '',
			'by'       => '',
		];
		return [
			$request->has_param( 'next_step' ) ? (string) $request['next_step'] : $current['sentence'],
			$request->has_param( 'next_step_by' ) ? (string) $request['next_step_by'] : $current['by'],
		];
	}

	/**
	 * A 422 for a project date that is not a day written Y-m-d (Rest\DayField):
	 * each is a day on the site's calendar, stored as typed until the Phase
	 * 5 review. The admin's and the Manage form's date fields send one.
	 */
	private function refusedDays( WP_REST_Request $request ): ?WP_Error {
		foreach ( [ 'started_on', 'ended_on', 'due_on' ] as $field ) {
			$refused = DayField::refusal( $request, $field );
			if ( $refused ) {
				return $refused;
			}
		}
		return null;
	}

	private function refusedNextStep( int $id, WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'next_step' ) && ! $request->has_param( 'next_step_by' ) ) {
			return null;
		}
		// Staff write it (FR8): a delegated author who may save a project
		// from the portal may not put words in the team's mouth.
		if ( ! $this->canManage() ) {
			return new WP_Error(
				'monstera_forbidden',
				sprintf(
					/* translators: %s: the site's name */
					__( 'The %s team writes the next step.', 'monstera' ),
					Audience::siteName()
				),
				[ 'status' => 403 ]
			);
		}
		// One sentence and one date, as text: the response's next_step is an
		// object, which a client sending it back whole must not store as "Array".
		foreach ( [ 'next_step', 'next_step_by' ] as $param ) {
			if ( $request->has_param( $param ) && ! is_null( $request[ $param ] ) && ! is_scalar( $request[ $param ] ) ) {
				return $this->invalidField( $param, __( 'Send the next step as text.', 'monstera' ) );
			}
		}
		$asked = $this->nextStepAsked( $id, $request );
		return $asked ? Repository::nextStepRefusal( $asked[0], $asked[1] ) : null;
	}

	/** A stage the pipeline does not have, named as the field it is. */
	private function refusedStatus( WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'status' ) || in_array( (string) $request['status'], Meta::statusOrder(), true ) ) {
			return null;
		}
		return $this->invalidField( 'status', __( 'Choose a stage from the pipeline.', 'monstera' ) );
	}

	/**
	 * The project's members come from the project's organization (the picker
	 * offers nobody else), any of its members whichever of their
	 * organizations it is (People-model track, FR8): a 422 naming the field
	 * when a save adds someone from outside it, for an admin as for anyone.
	 * People already on the project stay, so account staff put there before
	 * are not turned away. A create is held to the same rule (the project is
	 * 0 and nobody is on it yet), against the organization it is being made
	 * for. A project with no organization, a standalone client's, has no
	 * roster to check them against and is let through either way.
	 *
	 * The sentence is shown on the admin's "Project members" field, beside
	 * "Project lead (your team)", so it says "project members" and never "the team",
	 * which there means the internal team (FR4).
	 */
	private function refusedTeam( int $id, WP_REST_Request $request, AuthorScope $scope ): ?WP_Error {
		if ( ! $request->has_param( 'member_ids' ) ) {
			return null;
		}
		$orgId = $scope->isAdmin
			? ( $request->has_param( 'org_id' ) ? absint( $request['org_id'] ) : ( $id ? (int) get_post_meta( $id, Meta::KEY_ORG_ID, true ) : 0 ) )
			: $scope->orgId;
		if ( $orgId <= 0 ) {
			return null;
		}
		$current = $id ? ( new Repository() )->memberIds( $id ) : [];
		$wanted  = array_values( array_filter( array_map( 'absint', (array) $request['member_ids'] ) ) );
		$added   = array_diff( $wanted, $current );
		// One read of the memberships for everyone added, not one each.
		Roster::prime( $added );
		foreach ( $added as $userId ) {
			if ( ! Roster::isMemberOf( (int) $userId, $orgId ) ) {
				return $this->invalidField(
					'member_ids',
					sprintf(
						/* translators: 1: a person's name, 2: an organization's name */
						__( '%1$s is not in %2$s. Choose the project members from its roster.', 'monstera' ),
						$this->refusedName( (int) $userId ),
						html_entity_decode( (string) get_post_field( 'post_title', $orgId, 'raw' ), ENT_QUOTES, 'UTF-8' )
					)
				);
			}
		}
		return null;
	}

	/**
	 * The lead is one of the team: any staff account, whichever client the
	 * project is for (People-model track, FR4). A 422 naming the field for
	 * anyone else, one of the project's own members among them; 0 names
	 * nobody and clears the lead. The lead is not one of the project's
	 * members, so refusedTeam() is never asked about them.
	 *
	 * Choosing the lead is the team's alone. A save that chooses one assigns
	 * them to the project's organization (assignLead()), and assigning the
	 * team is never a client's to do (FR2), so an organization's manager who
	 * sends the field is refused whoever it names. Anyone on the team may
	 * choose: the assignment follows from the lead, and is not a change made
	 * on the Team page, which only a Team manager makes.
	 */
	private function refusedLead( WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'lead_id' ) ) {
			return null;
		}
		if ( ! $this->canManage() ) {
			return new WP_Error(
				'monstera_forbidden',
				/* translators: %s: the site's name */
				sprintf( __( 'The %s team chooses the project lead.', 'monstera' ), Audience::siteName() ),
				[ 'status' => 403 ]
			);
		}
		$leadId = absint( $request['lead_id'] );
		$lead   = $leadId > 0 ? get_userdata( $leadId ) : false;
		if ( 0 === $leadId || ( $lead && Capabilities::isStaff( $lead ) ) ) {
			return null;
		}
		return $this->invalidField( 'lead_id', __( 'Choose the project lead from your team.', 'monstera' ) );
	}

	/**
	 * The client contact is one of the project's members, checked against
	 * the members the save leaves, and one of the client's people: a staff
	 * account among the members, put there before the lead came from the
	 * team, speaks for the team and not for the client. A 422 naming the
	 * field otherwise; 0 names nobody.
	 */
	private function refusedContact( int $id, WP_REST_Request $request ): ?WP_Error {
		$contactId = $request->has_param( 'primary_contact_id' ) ? absint( $request['primary_contact_id'] ) : 0;
		if ( 0 === $contactId ) {
			return null;
		}
		$members = $request->has_param( 'member_ids' )
			? array_values( array_map( 'absint', (array) $request['member_ids'] ) )
			: ( $id ? ( new Repository() )->memberIds( $id ) : [] );
		if ( ! in_array( $contactId, $members, true ) ) {
			return $this->invalidField( 'primary_contact_id', __( 'Choose the client contact from the project members.', 'monstera' ) );
		}
		$contact = get_userdata( $contactId );
		if ( $contact && Capabilities::isStaff( $contact ) ) {
			return $this->invalidField(
				'primary_contact_id',
				/* translators: %s: a person's name */
				sprintf( __( '%s is on your team. Choose one of the client\'s people as the contact.', 'monstera' ), UserMeta::fullName( $contact ) )
			);
		}
		return null;
	}

	/**
	 * Note that the project's lead knows its organization: a lead who is not
	 * assigned there yet is assigned (People-model track, FR4). A save that
	 * changes who leads, or which organization the project is for, asks
	 * once it has settled both, so a project that moves takes its lead to
	 * the new organization as choosing them there would. A save that leaves
	 * both as they were does not ask (applyMutations()): the project detail
	 * sends the lead and the organization with every save, and an
	 * assignment a Team manager ended on the Team page would otherwise come
	 * back with the next change of a due date, under the name of whoever
	 * changed it. The Roster leaves a row that exists alone and fires its
	 * hook only for one it wrote, so a lead already assigned, or one who
	 * belongs to the organization, changes nothing there. Whoever led before
	 * stays assigned, and so does the lead to an organization the project
	 * has left: they still know the client, and ending an assignment is the
	 * Team page's to do. With no lead or no organization there is nobody to
	 * assign.
	 *
	 * Only the team's saves assign: a client's save names the organization
	 * too, and assigning the team is never a client's to do (FR2). And only
	 * one of the team is assigned, which a save that moves the project has
	 * not checked, since it did not name the lead.
	 */
	private function assignLead( int $id ): void {
		if ( ! $this->canManage() ) {
			return;
		}
		$lead  = get_userdata( ( new Repository() )->leadId( $id ) );
		$orgId = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		// The organizations the Team routes assign to: ones on the site and
		// active (a suspended or archived one takes no team).
		if ( $lead && Capabilities::isStaff( $lead ) && $orgId > 0 && $this->isOrgOnSite( $orgId ) && null === $this->notActiveRefusal( $orgId ) ) {
			Roster::assign( $orgId, (int) $lead->ID );
		}
	}

	/**
	 * The lead as the detail names them: who, and whether they are assigned
	 * to the project's organization (never, for a project that has none).
	 * Null for a project with no lead. The lead picker's choices are the
	 * whole team, which GET team lists with the organizations each person
	 * is assigned to, so no second list of the team is sent from here.
	 *
	 * Assigned means an assignment and nothing else. One of the team who
	 * belongs to the organization holds a membership there, the one row a
	 * person has per organization, and reads unassigned here as on GET
	 * team, where the Team routes refuse to assign them: an answer of
	 * "assigned" would name a row that does not exist.
	 *
	 * @return array{id: int, name: string, assigned: bool}|null
	 */
	private function leadShape( int $leadId, int $orgId ): ?array {
		$lead = $leadId > 0 ? get_userdata( $leadId ) : false;
		if ( ! $lead ) {
			return null;
		}
		return [
			'id'       => $leadId,
			'name'     => UserMeta::fullName( $lead ),
			'assigned' => $orgId > 0 && Roster::isAssignedTo( $leadId, $orgId ),
		];
	}

	/**
	 * The client contact as the detail names them, or null for a project
	 * with none, or one whose account is gone. The sidebar's fact speaks for
	 * the saved project, so the record names the person as it names the
	 * lead: the form's own list of people follows the organization chosen in
	 * it, which is not the saved one once the select has moved, and may not
	 * load at all.
	 *
	 * @return array{id: int, name: string}|null
	 */
	private function contactShape( int $contactId ): ?array {
		$contact = $contactId > 0 ? get_userdata( $contactId ) : false;
		if ( ! $contact ) {
			return null;
		}
		return [
			'id'   => $contactId,
			'name' => UserMeta::fullName( $contact ),
		];
	}

	/**
	 * Writes the fields a save carries. The scope is the caller's in the
	 * organization the save acts on: the one a create names, an existing
	 * project's own.
	 */
	private function applyMutations( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		// Who led and where, before anything is written: a save assigns the
		// lead only when it changes one of the two (see below).
		$ledBefore = ( new Repository() )->leadId( $id );
		$orgBefore = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );

		if ( $request->has_param( 'status' ) ) {
			$status = (string) $request['status'];
			if ( in_array( $status, Meta::statusOrder(), true ) ) {
				( new Repository() )->setStatus( $id, $status );
			}
		}

		$this->applyAudience( $id, $request, $scope );

		if ( $request->has_param( 'member_ids' ) ) {
			// Anyone from outside the organization was refused by refusedTeam()
			// before this save began; otherwise an outsider would gain the
			// project's intake data.
			$this->syncMembers( $id, array_map( 'absint', (array) $request['member_ids'] ) );
		}

		foreach ( [
			'started_on' => Meta::KEY_STARTED_ON,
			'ended_on'   => Meta::KEY_ENDED_ON,
			'due_on'     => Meta::KEY_DUE_ON,
			'budget_ref' => Meta::KEY_BUDGET_REF,
		] as $param => $metaKey ) {
			if ( $request->has_param( $param ) ) {
				update_post_meta( $id, $metaKey, sanitize_text_field( (string) $request[ $param ] ) );
			}
		}

		if ( $request->has_param( 'primary_contact_id' ) ) {
			update_post_meta( $id, Meta::KEY_PRIMARY_CONTACT, absint( $request['primary_contact_id'] ) );
		}
		if ( $request->has_param( 'lead_id' ) ) {
			// Nobody (0) clears the lead.
			( new Repository() )->setLead( $id, absint( $request['lead_id'] ) );
		}
		// The organization is settled above (applyAudience()). Naming the lead
		// or the organization is not choosing them: the project detail sends
		// both with every save. Only a save that leaves a different lead, or
		// the project in a different organization, assigns; a new project
		// had neither, so the lead it is made with is assigned.
		$led = ( new Repository() )->leadId( $id );
		$org = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		if ( $led !== $ledBefore || $org !== $orgBefore ) {
			$this->assignLead( $id );
		}
		// Someone who leaves the project's members stops being its contact.
		// The lead is not one of them, and stays whoever the members are.
		$team = ( new Repository() )->memberIds( $id );
		if ( ! in_array( (int) get_post_meta( $id, Meta::KEY_PRIMARY_CONTACT, true ), $team, true ) ) {
			delete_post_meta( $id, Meta::KEY_PRIMARY_CONTACT );
		}
		if ( $request->has_param( 'scope' ) ) {
			update_post_meta( $id, Meta::KEY_SCOPE, wp_kses_post( (string) $request['scope'] ) );
		}
		// Judged before the first write (refusedNextStep()); the repository
		// is the one writer (At-a-glance track, FR8).
		$step = $this->nextStepAsked( $id, $request );
		if ( $step ) {
			( new Repository() )->setNextStep( $id, $step[0], $step[1] );
		}
	}

	/**
	 * Projects carry a single parent — org OR standalone member, mutually
	 * exclusive. Admins choose either; delegated authors are pinned to the
	 * scope's organization (standalone targeting denied) with sub-group gating
	 * clamped. A project that reaches beyond the author's part (a leader's, in
	 * a sub-group of their organization they do not lead) keeps who it
	 * reaches through their saves (AuthorScope::isSharedFurther()).
	 */
	private function applyAudience( int $id, WP_REST_Request $request, AuthorScope $scope ): void {
		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'org_id' ) ) {
				$orgId = absint( $request['org_id'] );
				if ( $orgId > 0 ) {
					update_post_meta( $id, Meta::KEY_ORG_ID, $orgId );
					delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
				} else {
					delete_post_meta( $id, Meta::KEY_ORG_ID );
				}
			}
			if ( $request->has_param( 'standalone_member_id' ) ) {
				$mid = absint( $request['standalone_member_id'] );
				if ( $mid > 0 ) {
					update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, $mid );
					delete_post_meta( $id, Meta::KEY_ORG_ID );
				} else {
					delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
				}
			}
			if ( $request->has_param( 'subgroup_ids' ) ) {
				$proposed = array_map( 'absint', (array) $request['subgroup_ids'] );
				$orgId    = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
				$memId    = (int) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, true );
				$valid    = ContentController::filterSubgroupsByAudience(
					$proposed,
					$orgId ? [ $orgId ] : [],
					$memId ? [ $memId ] : []
				);
				update_post_meta( $id, Meta::KEY_SUBGROUP_IDS, array_values( $valid ) );
			}
			return;
		}

		if ( $scope->isSharedFurther( $id ) ) {
			return;
		}
		$orgId = $scope->orgId;
		if ( $orgId > 0 ) {
			update_post_meta( $id, Meta::KEY_ORG_ID, $orgId );
		}
		delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );

		if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
			$proposed = $scope->subgroupIdsForSave( $id, $request->has_param( 'subgroup_ids' ) ? (array) $request['subgroup_ids'] : null );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgId ? [ $orgId ] : [], [] );
			update_post_meta( $id, Meta::KEY_SUBGROUP_IDS, array_values( $valid ) );
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * @param array<int, int> $wanted
	 */
	private function syncMembers( int $projectId, array $wanted ): void {
		$repo    = new Repository();
		$current = $repo->memberIds( $projectId );
		$wanted  = array_values( array_unique( array_filter( $wanted ) ) );

		foreach ( array_diff( $current, $wanted ) as $userId ) {
			$repo->removeMember( $projectId, (int) $userId );
		}
		foreach ( array_diff( $wanted, $current ) as $userId ) {
			$repo->addMember( $projectId, (int) $userId );
		}
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function mine(): array {
		$repo = new Repository();
		$user = wp_get_current_user();
		$mine = $repo->forMember( $user->ID );
		$out  = [];
		foreach ( $mine as $post ) {
			$out[] = $this->summarize( $post );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function getIntake( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];

		// Permission: one of the project's members, or staff. Mirrors
		// submitIntake(): the GET is just as sensitive as the POST because
		// it returns other clients' submitted discovery answers.
		$repo      = new Repository();
		$user      = wp_get_current_user();
		$onProject = in_array( $user->ID, $repo->memberIds( $projectId ), true );
		if ( ! $onProject && ! $this->canManage() ) {
			return $this->notOnProject();
		}
		$ended = $this->intakeEnded( $user, $projectId );
		if ( $ended ) {
			return $ended;
		}

		return [
			'schema'    => Discovery::schema( $projectId ),
			'responses' => Discovery::responses( $projectId ),
			// Who answered each question and when (the detail's responses).
			'answers'   => Discovery::answers( $projectId ),
			// A file question's answer is its files, each with a link signed
			// for the reader.
			'files'     => $this->intakeFilesShape( $projectId ),
		];
	}

	/**
	 * Save the discovery intake's questions (comp 124's intake editor):
	 * validated as a whole, refused with a 422 that names the question, and
	 * stored with the answers to kept questions intact.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function saveIntakeSchema( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		$post      = get_post( $projectId );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$schema = Discovery::validate( $request['schema'] ?? null );
		if ( is_string( $schema ) ) {
			return $this->invalidField( 'schema', $schema );
		}
		Discovery::saveSchema( $projectId, $schema );
		return [
			'schema'    => Discovery::schema( $projectId ),
			'responses' => Discovery::responses( $projectId ),
			'answers'   => Discovery::answers( $projectId ),
			'files'     => $this->intakeFilesShape( $projectId ),
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function submitIntake( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		$values    = (array) $request->get_json_params();

		// Permission: one of the project's members, or staff.
		$repo      = new Repository();
		$user      = wp_get_current_user();
		$onProject = in_array( $user->ID, $repo->memberIds( $projectId ), true );
		if ( ! $onProject && ! $this->canManage() ) {
			return $this->notOnProject();
		}
		$ended = $this->intakeEnded( $user, $projectId );
		if ( $ended ) {
			return $ended;
		}
		// The portal shows the form while the project is Proposed or in
		// Discovery; the route holds the same line.
		if ( ! Discovery::isOpen( $projectId ) ) {
			return new WP_Error( 'monstera_intake_closed', __( 'This project is past discovery, so its answers are closed. Ask your account team to change one.', 'monstera' ), [ 'status' => 409 ] );
		}

		Discovery::submit( $projectId, $values, $user->ID );
		return [
			'ok'       => true,
			'project'  => $this->summarize( get_post( $projectId ) ),
			// Whether the agency was emailed: the portal says so only then.
			'notified' => Dispatcher::intakeNotified( $projectId ),
		];
	}

	/**
	 * Add one file to a discovery file question (comp 97): a multipart `file`
	 * and the question's `field_key`. A project member or an admin, while
	 * discovery is open; 201 with the file's facts, or 422 naming what was
	 * refused.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function addIntakeFile( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$projectId = (int) $request['id'];
		$refused   = $this->refuseIntakeChange( $projectId );
		if ( $refused ) {
			return $refused;
		}
		if ( ! Discovery::isOpen( $projectId ) ) {
			return $this->intakeFilesClosed();
		}

		$upload = $request->get_file_params()['file'] ?? null;
		$upload = is_array( $upload ) ? $upload : null;
		// Over post_max_size PHP discards the whole body, so neither the file
		// nor the question arrives: only the length the browser declared.
		if ( ! $upload && IntakeFiles::bodyTooLarge( (int) $request->get_header( 'content_length' ), (string) ini_get( 'post_max_size' ) ) ) {
			return $this->invalidField( 'file', IntakeFiles::sayTooBig() );
		}

		$key     = sanitize_key( (string) $request->get_param( 'field_key' ) );
		$refusal = IntakeFiles::refusal( $projectId, $key, $upload );
		if ( null !== $refusal || null === $upload ) {
			$onQuestion = ! in_array( $key, Discovery::fileKeys( $projectId ), true );
			return $this->invalidField( $onQuestion ? 'field_key' : 'file', $refusal ?? __( 'Choose a file to add.', 'monstera' ) );
		}

		try {
			$file = ( new IntakeFiles() )->store(
				$projectId,
				$key,
				[
					'name'     => (string) $upload['name'],
					'tmp_name' => (string) $upload['tmp_name'],
					'size'     => (int) $upload['size'],
				],
				get_current_user_id()
			);
		} catch ( \OverflowException $e ) {
			// Another upload took the question's last place meanwhile.
			return $this->invalidField( 'file', IntakeFiles::sayFull() );
		} catch ( \RuntimeException $e ) {
			return new WP_Error( 'monstera_file_not_stored', __( 'The file could not be stored. Try again.', 'monstera' ), [ 'status' => 500 ] );
		}
		ActivityLog::record( 'intake_file_added', 'project', $projectId, IntakeFiles::activityContext( $projectId, $file, $key ) );
		return new WP_REST_Response( [ 'file' => $this->intakeFileShape( $file ) ], 201 );
	}

	/**
	 * Remove one of a project's intake files: a project member while
	 * discovery is open, an admin at any time.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function removeIntakeFile( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		// Who may change the project's files comes first, so someone who is
		// not on the project learns nothing about which file ids are its own.
		$refused = $this->refuseIntakeChange( $projectId );
		if ( $refused ) {
			return $refused;
		}
		$files = new IntakeFiles();
		$file  = $files->find( (int) $request['file'] );
		if ( ! $file || $file['project_id'] !== $projectId ) {
			return new WP_Error( 'monstera_not_found', __( 'File not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! $this->canManage() && ! Discovery::isOpen( $projectId ) ) {
			return $this->intakeFilesClosed();
		}
		$files->remove( $file['id'] );
		ActivityLog::record( 'intake_file_removed', 'project', $projectId, IntakeFiles::activityContext( $projectId, $file, $file['field_key'] ) );
		return [
			'ok'      => true,
			'removed' => $file['id'],
		];
	}

	/**
	 * Null when the current user may change the project's intake files: a
	 * project that exists, and one of its members or staff.
	 */
	private function refuseIntakeChange( int $projectId ): ?WP_Error {
		if ( PostType::SLUG !== get_post_type( $projectId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! $this->canManage() && ! in_array( get_current_user_id(), ( new Repository() )->memberIds( $projectId ), true ) ) {
			return $this->notOnProject();
		}
		return $this->intakeEnded( wp_get_current_user(), $projectId );
	}

	/**
	 * The refusal for one of the project's members once its organization's
	 * membership has ended, or null while it runs or for staff. The portal
	 * answers "Membership ended" for the project's page and holds its files
	 * back (Content\Downloader::intakeAccess(), which says ended before
	 * suspended); the intake's read, its answers and its files hold the same
	 * line, in the blocked page's words. A suspended organization is not
	 * refused here: its people still read and answer, and only the downloads
	 * wait.
	 */
	private function intakeEnded( \WP_User $user, int $projectId ): ?WP_Error {
		if ( Downloader::ACCESS_ENDED !== Downloader::intakeAccess( $user, $projectId ) ) {
			return null;
		}
		return self::membershipEnded( (int) get_post_meta( $projectId, Meta::KEY_ORG_ID, true ) );
	}

	/**
	 * The refusal for someone who is not on the project. Its client people
	 * are its project members; "the team" is the internal team (People-model
	 * track, Vocabulary), so the sentence does not call them one.
	 */
	private function notOnProject(): WP_Error {
		return new WP_Error( 'monstera_forbidden', __( 'You are not one of this project\'s members.', 'monstera' ), [ 'status' => 403 ] );
	}

	private function intakeFilesClosed(): WP_Error {
		return new WP_Error( 'monstera_intake_closed', __( 'This project is past discovery, so its files can no longer change.', 'monstera' ), [ 'status' => 409 ] );
	}

	/**
	 * An intake file as the browser sees it: its facts and a download link
	 * signed for the reader, never where it is stored.
	 *
	 * @param array<string, mixed> $file From IntakeFiles.
	 * @return array<string, mixed>
	 */
	private function intakeFileShape( array $file ): array {
		return [
			'id'             => (int) $file['id'],
			'name'           => (string) $file['name'],
			'size'           => (int) $file['size'],
			'type'           => (string) $file['type'],
			'uploaded_by'    => (string) $file['uploaded_by'],
			'uploaded_by_id' => (int) $file['uploaded_by_id'],
			'uploaded_at'    => (string) $file['uploaded_at'],
			// The portal's row in the site's words and time zone.
			'size_label'     => (string) size_format( (int) $file['size'] ),
			'sent_by'        => IntakeFiles::sentBy( $file ),
			'download_url'   => Downloader::signedUrl( (int) $file['id'], get_current_user_id() ),
		];
	}

	/**
	 * A project's intake files by question, as the browser sees them: a JSON
	 * object keyed by question, `{}` when none holds a file (an empty PHP
	 * array would read as a list).
	 */
	private function intakeFilesShape( int $projectId ): object {
		return (object) array_map(
			fn ( array $files ): array => array_map( [ $this, 'intakeFileShape' ], $files ),
			( new IntakeFiles() )->forProject( $projectId )
		);
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function setStatus( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		$status    = (string) $request->get_param( 'status' );
		if ( ! in_array( $status, Meta::statusOrder(), true ) ) {
			return $this->invalidField( 'status', __( 'Choose a stage from the pipeline.', 'monstera' ) );
		}
		( new Repository() )->setStatus( $projectId, $status );
		return [
			'ok'     => true,
			'status' => $status,
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function summarize( ?\WP_Post $post ): array {
		if ( ! $post ) {
			return [];
		}
		// A client is told of the project's organization when it is one of
		// theirs, and of its standalone client when that is them: an author
		// lists what they wrote, which staff may have moved to another client
		// since (Portal\AudienceShown). Staff are told both.
		$caller     = wp_get_current_user();
		$orgId      = AudienceShown::orgs( $caller, [ (int) get_post_meta( $post->ID, Meta::KEY_ORG_ID, true ) ] )[0] ?? 0;
		$memId      = (int) get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBER_ID, true );
		$memId      = AudienceShown::whole( $caller ) || $memId === (int) $caller->ID ? $memId : 0;
		$standalone = $memId ? get_userdata( $memId ) : null;
		$status     = (string) ( get_post_meta( $post->ID, Meta::KEY_STATUS, true ) ?: Meta::STATUS_PROPOSED );
		$dueOn      = (string) get_post_meta( $post->ID, Meta::KEY_DUE_ON, true );
		$repo       = new Repository();

		return [
			'id'                     => $post->ID,
			'title'                  => get_the_title( $post ),
			'status'                 => $status,
			'status_label'           => Meta::statusLabel( $status ),
			'org_id'                 => $orgId,
			'org_name'               => $orgId ? get_the_title( $orgId ) : '',
			'standalone_member_id'   => $memId,
			'standalone_member_name' => $standalone ? $standalone->display_name : '',
			'started_on'             => (string) get_post_meta( $post->ID, Meta::KEY_STARTED_ON, true ),
			'ended_on'               => (string) get_post_meta( $post->ID, Meta::KEY_ENDED_ON, true ),
			'due_on'                 => $dueOn,
			'team_size'              => count( $repo->memberIds( $post->ID ) ),
			'updated'                => get_post_modified_time( 'c', true, $post ),
			'edit_url'               => admin_url( 'admin.php?page=monstera-projects&id=' . $post->ID ),
		];
	}

	/**
	 * The sidebar's counts (comp 124): content gated to the project (as the
	 * Content list shows it) and its open support requests.
	 *
	 * @return array{content: int, support_open: int}
	 */
	private function projectFacts( int $id ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- counts from Monstera's own tables, read once per detail load.
		$content = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i cp INNER JOIN {$wpdb->posts} p ON p.ID = cp.content_id WHERE cp.project_id = %d AND p.post_status IN ('publish', 'draft', 'pending')",
				Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
				$id
			)
		);
		// phpcs:enable
		return [
			'content'      => $content,
			// Null with Support off: the page leaves the fact out.
			'support_open' => $this->factOf(
				\Monstera\Core\Modules::SUPPORT,
				static fn (): int => count(
					( new SupportRepository() )->inbox(
						[
							'project_id' => $id,
							'status'     => SupportRepository::STATUS_OPEN,
						]
					)
				)
			),
		];
	}

	/**
	 * Each logged stage change, oldest first, for the timeline.
	 *
	 * @return list<array{at: string, from: string, to: string}>
	 */
	private function stageHistory( int $id ): array {
		$out = [];
		foreach ( ActivityLog::forObject( 'project', $id, 50 ) as $row ) {
			if ( 'project_stage_changed' !== ( $row['event_type'] ?? '' ) ) {
				continue;
			}
			$context = json_decode( (string) ( $row['context'] ?? '' ), true );
			$out[]   = [
				'at'   => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['occurred_at'] . ' UTC' ) ),
				'from' => (string) ( $context['from'] ?? '' ),
				'to'   => (string) ( $context['to'] ?? '' ),
			];
		}
		return array_reverse( $out );
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		$post       = get_post( $id );
		$repo       = new Repository();
		$orgId      = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		$memId      = (int) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, true );
		$standalone = $memId ? get_userdata( $memId ) : null;
		$status     = (string) ( get_post_meta( $id, Meta::KEY_STATUS, true ) ?: Meta::STATUS_PROPOSED );
		// A project with no sub-groups has no meta to read, and an empty string
		// cast to an array is the id of nothing: no sub-group is an empty list.
		// A client author is told of the sub-groups they may see named alone
		// (Portal\AudienceShown); staff of all of them.
		$sgIds     = AudienceShown::subgroups( wp_get_current_user(), array_values( array_filter( array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_SUBGROUP_IDS, true ) ) ) ) );
		$members   = $repo->memberIds( $id );
		$lead      = $this->leadShape( $repo->leadId( $id ), $orgId );
		$contactId = (int) get_post_meta( $id, Meta::KEY_PRIMARY_CONTACT, true );

		return [
			'id'                     => $id,
			// As stored: the detail saves it back (the list's is texturized).
			'title'                  => (string) get_post_field( 'post_title', $id, 'raw' ),
			'description'            => (string) $post?->post_content,
			'status'                 => $status,
			'status_label'           => Meta::statusLabel( $status ),
			'org_id'                 => $orgId,
			'org_name'               => $orgId ? get_the_title( $orgId ) : '',
			// An organization that is not active: nobody is assigned to it
			// (assignLead() skips any but an active one).
			'org_inactive'           => $orgId > 0 && ! ( new OrgRepository() )->isActive( $orgId ),
			'standalone_member_id'   => $memId,
			'standalone_member_name' => $standalone ? $standalone->display_name : '',
			'subgroup_ids'           => $sgIds,
			'member_ids'             => array_map( 'intval', $members ),
			'started_on'             => (string) get_post_meta( $id, Meta::KEY_STARTED_ON, true ),
			'ended_on'               => (string) get_post_meta( $id, Meta::KEY_ENDED_ON, true ),
			'due_on'                 => (string) get_post_meta( $id, Meta::KEY_DUE_ON, true ),
			'budget_ref'             => (string) get_post_meta( $id, Meta::KEY_BUDGET_REF, true ),
			'primary_contact_id'     => $contactId,
			// Who that is, for the sidebar's fact; null with no contact.
			'primary_contact'        => $this->contactShape( $contactId ),
			// One of the team, never among member_ids. The id is 0 when the
			// account is gone, so the form never holds someone it cannot name.
			'lead_id'                => $lead['id'] ?? 0,
			'lead'                   => $lead,
			// What the client is asked to do next, and by when, or null
			// (At-a-glance track, FR8): the detail's two fields and its fact.
			'next_step'              => $repo->nextStep( $id ),
			// The head, the timeline and the sidebar (comp 124).
			'portal_url'             => Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $id ] ),
			'created'                => (string) get_post_time( 'c', true, $id ),
			'facts'                  => $this->projectFacts( $id ),
			'saved'                  => $this->savedStamp( $id ),
			'stage_history'          => $this->stageHistory( $id ),
			'scope'                  => (string) get_post_meta( $id, Meta::KEY_SCOPE, true ),
			'edit_url'               => admin_url( 'admin.php?page=monstera-projects&id=' . $id ),
		];
	}
}
