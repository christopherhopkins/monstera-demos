<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Content\Downloader;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Notifications\Dispatcher;
use Monstera\Projects\Discovery;
use Monstera\Projects\IntakeFiles;
use Monstera\Projects\Meta;
use Monstera\Projects\PostType;
use Monstera\Projects\Repository;
use Monstera\Reporting\ActivityLog;
use Monstera\Support\Repository as SupportRepository;
use WP_Error;
use WP_Query;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || exit;

final class ProjectsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/projects',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/mine',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_VIEW_PROJECTS ),
				'callback'            => [ $this, 'mine' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_VIEW_PROJECTS ),
					'callback'            => [ $this, 'getIntake' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_INTAKE ),
					'callback'            => [ $this, 'submitIntake' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake/files',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_INTAKE ),
				'callback'            => [ $this, 'addIntakeFile' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake/files/(?P<file>\d+)',
			[
				'methods'             => 'DELETE',
				'permission_callback' => $this->permissionCap( Capabilities::CAP_SUBMIT_INTAKE ),
				'callback'            => [ $this, 'removeIntakeFile' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/intake/schema',
			[
				'methods'             => 'PUT',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'saveIntakeSchema' ],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/projects/(?P<id>\d+)/status',
			[
				'methods'             => 'POST',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'setStatus' ],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index(): array {
		$q   = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => [ 'publish', 'draft' ],
					'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- deliberate 200-item cap for the admin projects table.
					'orderby'        => 'modified',
					'order'          => 'DESC',
				],
				$this->ownAuthorQueryArgs()
			)
		);
		$out = [];
		foreach ( $q->posts as $post ) {
			$out[] = $this->summarize( $post );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$title = sanitize_text_field( (string) ( $request['title'] ?? '' ) );
		if ( '' === $title ) {
			return $this->invalidField( 'title', __( 'Give the project a name.', 'monstera' ) );
		}
		$refused = $this->refusedRoles( 0, $request );
		if ( $refused ) {
			return $refused;
		}

		$id = wp_insert_post(
			[
				'post_type'   => PostType::SLUG,
				'post_title'  => $title,
				'post_status' => 'draft' === sanitize_key( (string) ( $request['status_post'] ?? 'publish' ) ) ? 'draft' : 'publish',
				'post_author' => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$this->applyMutations( (int) $id, $request );
		$this->stampEditor( (int) $id );
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id ) ?? $this->refusedStatus( $request ) ?? $this->refusedTeam( $id, $request ) ?? $this->refusedRoles( $id, $request );
		if ( $guard ) {
			return $guard;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'title' ) ) {
			$core['post_title'] = sanitize_text_field( (string) $request['title'] );
			if ( '' === $core['post_title'] ) {
				return $this->invalidField( 'title', __( 'Give the project a title.', 'monstera' ) );
			}
		}
		if ( $request->has_param( 'description' ) ) {
			$core['post_content'] = wp_kses_post( (string) $request['description'] );
		}
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}

		$this->applyMutations( $id, $request );
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/** A stage the pipeline does not have, named as the field it is. */
	private function refusedStatus( WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'status' ) || in_array( (string) $request['status'], Meta::statusOrder(), true ) ) {
			return null;
		}
		return $this->invalidField( 'status', __( 'Choose a stage from the pipeline.', 'monstera' ) );
	}

	/**
	 * The team comes from the project's organization (the picker offers
	 * nobody else): a 422 naming the field when a save adds someone from
	 * outside it, for an admin as for anyone. People already on the team
	 * stay, so account staff put there before are not turned away.
	 */
	private function refusedTeam( int $id, WP_REST_Request $request ): ?WP_Error {
		if ( ! $request->has_param( 'member_ids' ) ) {
			return null;
		}
		$scope = $this->scope();
		$orgId = $scope->isAdmin
			? ( $request->has_param( 'org_id' ) ? absint( $request['org_id'] ) : ( $id ? (int) get_post_meta( $id, Meta::KEY_ORG_ID, true ) : 0 ) )
			: $scope->orgId;
		if ( $orgId <= 0 ) {
			return null;
		}
		$current = $id ? ( new Repository() )->memberIds( $id ) : [];
		$wanted  = array_values( array_filter( array_map( 'absint', (array) $request['member_ids'] ) ) );
		foreach ( array_diff( $wanted, $current ) as $userId ) {
			if ( UserMeta::associatedOrg( (int) $userId ) !== $orgId ) {
				$user = get_userdata( (int) $userId );
				return $this->invalidField(
					'member_ids',
					sprintf(
						/* translators: 1: a person's name, 2: an organization's name */
						__( '%1$s is not in %2$s. Choose the team from its members.', 'monstera' ),
						$user ? UserMeta::fullName( $user ) : __( 'That person', 'monstera' ),
						html_entity_decode( (string) get_post_field( 'post_title', $orgId, 'raw' ), ENT_QUOTES, 'UTF-8' )
					)
				);
			}
		}
		return null;
	}

	/**
	 * The lead and the client contact are on the team (comp 124 draws both
	 * selects from it): a 422 naming the field when a save names someone
	 * else, checked against the team the save leaves.
	 */
	private function refusedRoles( int $id, WP_REST_Request $request ): ?WP_Error {
		$team   = $request->has_param( 'member_ids' )
			? array_values( array_map( 'absint', (array) $request['member_ids'] ) )
			: ( $id ? ( new Repository() )->memberIds( $id ) : [] );
		$labels = [
			'lead_id'            => __( 'Choose the lead from the team.', 'monstera' ),
			'primary_contact_id' => __( 'Choose the client contact from the team.', 'monstera' ),
		];
		foreach ( $labels as $field => $message ) {
			if ( ! $request->has_param( $field ) ) {
				continue;
			}
			$userId = absint( $request[ $field ] );
			if ( $userId > 0 && ! in_array( $userId, $team, true ) ) {
				return $this->invalidField( $field, $message );
			}
		}
		return null;
	}

	private function applyMutations( int $id, WP_REST_Request $request ): void {
		if ( $request->has_param( 'status' ) ) {
			$status = (string) $request['status'];
			if ( in_array( $status, Meta::statusOrder(), true ) ) {
				( new Repository() )->setStatus( $id, $status );
			}
		}

		$this->applyAudience( $id, $request );

		if ( $request->has_param( 'member_ids' ) ) {
			// Anyone from outside the organization was refused by refusedTeam()
			// before this save began; otherwise an outsider would gain the
			// project's intake data.
			$this->syncMembers( $id, array_map( 'absint', (array) $request['member_ids'] ) );
		}

		foreach ( [
			'started_on' => Meta::KEY_STARTED_ON,
			'ended_on'   => Meta::KEY_ENDED_ON,
			'due_on'     => Meta::KEY_DUE_ON,
			'budget_ref' => Meta::KEY_BUDGET_REF,
		] as $param => $metaKey ) {
			if ( $request->has_param( $param ) ) {
				update_post_meta( $id, $metaKey, sanitize_text_field( (string) $request[ $param ] ) );
			}
		}

		if ( $request->has_param( 'primary_contact_id' ) ) {
			update_post_meta( $id, Meta::KEY_PRIMARY_CONTACT, absint( $request['primary_contact_id'] ) );
		}
		if ( $request->has_param( 'lead_id' ) ) {
			( new Repository() )->setLead( $id, absint( $request['lead_id'] ) );
		}
		// Someone who leaves the team stops leading it or being its contact.
		$team = ( new Repository() )->memberIds( $id );
		if ( ! in_array( (int) get_post_meta( $id, Meta::KEY_PRIMARY_CONTACT, true ), $team, true ) ) {
			delete_post_meta( $id, Meta::KEY_PRIMARY_CONTACT );
		}
		if ( $request->has_param( 'scope' ) ) {
			update_post_meta( $id, Meta::KEY_SCOPE, wp_kses_post( (string) $request['scope'] ) );
		}
	}

	/**
	 * Projects carry a single parent — org OR standalone member, mutually
	 * exclusive. Admins choose either; delegated authors are pinned to their own
	 * org (standalone targeting denied) with sub-group gating clamped.
	 */
	private function applyAudience( int $id, WP_REST_Request $request ): void {
		$scope = $this->scope();

		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'org_id' ) ) {
				$orgId = absint( $request['org_id'] );
				if ( $orgId > 0 ) {
					update_post_meta( $id, Meta::KEY_ORG_ID, $orgId );
					delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
				} else {
					delete_post_meta( $id, Meta::KEY_ORG_ID );
				}
			}
			if ( $request->has_param( 'standalone_member_id' ) ) {
				$mid = absint( $request['standalone_member_id'] );
				if ( $mid > 0 ) {
					update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, $mid );
					delete_post_meta( $id, Meta::KEY_ORG_ID );
				} else {
					delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
				}
			}
			if ( $request->has_param( 'subgroup_ids' ) ) {
				$proposed = array_map( 'absint', (array) $request['subgroup_ids'] );
				$orgId    = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
				$memId    = (int) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, true );
				$valid    = ContentController::filterSubgroupsByAudience(
					$proposed,
					$orgId ? [ $orgId ] : [],
					$memId ? [ $memId ] : []
				);
				update_post_meta( $id, Meta::KEY_SUBGROUP_IDS, array_values( $valid ) );
			}
			return;
		}

		$orgId = $scope->orgId;
		if ( $orgId > 0 ) {
			update_post_meta( $id, Meta::KEY_ORG_ID, $orgId );
		}
		delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );

		if ( $scope->isLeader() || $request->has_param( 'subgroup_ids' ) ) {
			$proposed = $scope->clampSubgroupIds( (array) ( $request['subgroup_ids'] ?? [] ) );
			$valid    = ContentController::filterSubgroupsByAudience( $proposed, $orgId ? [ $orgId ] : [], [] );
			update_post_meta( $id, Meta::KEY_SUBGROUP_IDS, array_values( $valid ) );
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwned( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * @param array<int, int> $wanted
	 */
	private function syncMembers( int $projectId, array $wanted ): void {
		$repo    = new Repository();
		$current = $repo->memberIds( $projectId );
		$wanted  = array_values( array_unique( array_filter( $wanted ) ) );

		foreach ( array_diff( $current, $wanted ) as $userId ) {
			$repo->removeMember( $projectId, (int) $userId );
		}
		foreach ( array_diff( $wanted, $current ) as $userId ) {
			$repo->addMember( $projectId, (int) $userId );
		}
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function mine(): array {
		$repo = new Repository();
		$user = wp_get_current_user();
		$mine = $repo->forMember( $user->ID );
		$out  = [];
		foreach ( $mine as $post ) {
			$out[] = $this->summarize( $post );
		}
		return [ 'items' => $out ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function getIntake( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];

		// Permission: must be on the project team OR a Monstera admin.
		// Mirrors submitIntake() — the GET is just as sensitive as the POST
		// because it returns other clients' submitted discovery answers.
		$repo   = new Repository();
		$user   = wp_get_current_user();
		$onTeam = in_array( $user->ID, $repo->memberIds( $projectId ), true );
		if ( ! $onTeam && ! $this->canManage() ) {
			return new WP_Error( 'monstera_forbidden', __( 'Not on this project team.', 'monstera' ), [ 'status' => 403 ] );
		}

		return [
			'schema'    => Discovery::schema( $projectId ),
			'responses' => Discovery::responses( $projectId ),
			// Who answered each question and when (the detail's responses).
			'answers'   => Discovery::answers( $projectId ),
			// A file question's answer is its files, each with a link signed
			// for the reader.
			'files'     => $this->intakeFilesShape( $projectId ),
		];
	}

	/**
	 * Save the discovery intake's questions (comp 124's intake editor):
	 * validated as a whole, refused with a 422 that names the question, and
	 * stored with the answers to kept questions intact.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function saveIntakeSchema( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		$post      = get_post( $projectId );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$schema = Discovery::validate( $request['schema'] ?? null );
		if ( is_string( $schema ) ) {
			return $this->invalidField( 'schema', $schema );
		}
		Discovery::saveSchema( $projectId, $schema );
		return [
			'schema'    => Discovery::schema( $projectId ),
			'responses' => Discovery::responses( $projectId ),
			'answers'   => Discovery::answers( $projectId ),
			'files'     => $this->intakeFilesShape( $projectId ),
		];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function submitIntake( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		$values    = (array) $request->get_json_params();

		// Permission: must be on the project team OR a Monstera admin.
		$repo   = new Repository();
		$user   = wp_get_current_user();
		$onTeam = in_array( $user->ID, $repo->memberIds( $projectId ), true );
		if ( ! $onTeam && ! $this->canManage() ) {
			return new WP_Error( 'monstera_forbidden', __( 'Not on this project team.', 'monstera' ), [ 'status' => 403 ] );
		}
		// The portal shows the form while the project is Proposed or in
		// Discovery; the route holds the same line.
		if ( ! Discovery::isOpen( $projectId ) ) {
			return new WP_Error( 'monstera_intake_closed', __( 'This project is past discovery, so its answers are closed. Ask your account team to change one.', 'monstera' ), [ 'status' => 409 ] );
		}

		Discovery::submit( $projectId, $values, $user->ID );
		return [
			'ok'       => true,
			'project'  => $this->summarize( get_post( $projectId ) ),
			// Whether the agency was emailed: the portal says so only then.
			'notified' => Dispatcher::intakeNotified( $projectId ),
		];
	}

	/**
	 * Add one file to a discovery file question (comp 97): a multipart `file`
	 * and the question's `field_key`. The team or an admin, while discovery
	 * is open; 201 with the file's facts, or 422 naming what was refused.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function addIntakeFile( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$projectId = (int) $request['id'];
		$refused   = $this->refuseIntakeChange( $projectId );
		if ( $refused ) {
			return $refused;
		}
		if ( ! Discovery::isOpen( $projectId ) ) {
			return $this->intakeFilesClosed();
		}

		$upload = $request->get_file_params()['file'] ?? null;
		$upload = is_array( $upload ) ? $upload : null;
		// Over post_max_size PHP discards the whole body, so neither the file
		// nor the question arrives: only the length the browser declared.
		if ( ! $upload && IntakeFiles::bodyTooLarge( (int) $request->get_header( 'content_length' ), (string) ini_get( 'post_max_size' ) ) ) {
			return $this->invalidField( 'file', IntakeFiles::sayTooBig() );
		}

		$key     = sanitize_key( (string) $request->get_param( 'field_key' ) );
		$refusal = IntakeFiles::refusal( $projectId, $key, $upload );
		if ( null !== $refusal || null === $upload ) {
			$onQuestion = ! in_array( $key, Discovery::fileKeys( $projectId ), true );
			return $this->invalidField( $onQuestion ? 'field_key' : 'file', $refusal ?? __( 'Choose a file to add.', 'monstera' ) );
		}

		try {
			$file = ( new IntakeFiles() )->store(
				$projectId,
				$key,
				[
					'name'     => (string) $upload['name'],
					'tmp_name' => (string) $upload['tmp_name'],
					'size'     => (int) $upload['size'],
				],
				get_current_user_id()
			);
		} catch ( \OverflowException $e ) {
			// Another upload took the question's last place meanwhile.
			return $this->invalidField( 'file', IntakeFiles::sayFull() );
		} catch ( \RuntimeException $e ) {
			return new WP_Error( 'monstera_file_not_stored', __( 'The file could not be stored. Try again.', 'monstera' ), [ 'status' => 500 ] );
		}
		ActivityLog::record( 'intake_file_added', 'project', $projectId, IntakeFiles::activityContext( $projectId, $file, $key ) );
		return new WP_REST_Response( [ 'file' => $this->intakeFileShape( $file ) ], 201 );
	}

	/**
	 * Remove one of a project's intake files: the team while discovery is
	 * open, an admin at any time.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function removeIntakeFile( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		// Who may change the project's files comes first, so someone off the
		// team learns nothing about which file ids are the project's.
		$refused = $this->refuseIntakeChange( $projectId );
		if ( $refused ) {
			return $refused;
		}
		$files = new IntakeFiles();
		$file  = $files->find( (int) $request['file'] );
		if ( ! $file || $file['project_id'] !== $projectId ) {
			return new WP_Error( 'monstera_not_found', __( 'File not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! $this->canManage() && ! Discovery::isOpen( $projectId ) ) {
			return $this->intakeFilesClosed();
		}
		$files->remove( $file['id'] );
		ActivityLog::record( 'intake_file_removed', 'project', $projectId, IntakeFiles::activityContext( $projectId, $file, $file['field_key'] ) );
		return [
			'ok'      => true,
			'removed' => $file['id'],
		];
	}

	/**
	 * Null when the current user may change the project's intake files: a
	 * project that exists, and the team or an admin.
	 */
	private function refuseIntakeChange( int $projectId ): ?WP_Error {
		if ( PostType::SLUG !== get_post_type( $projectId ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Project not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		if ( ! $this->canManage() && ! in_array( get_current_user_id(), ( new Repository() )->memberIds( $projectId ), true ) ) {
			return new WP_Error( 'monstera_forbidden', __( 'Not on this project team.', 'monstera' ), [ 'status' => 403 ] );
		}
		return null;
	}

	private function intakeFilesClosed(): WP_Error {
		return new WP_Error( 'monstera_intake_closed', __( 'This project is past discovery, so its files can no longer change.', 'monstera' ), [ 'status' => 409 ] );
	}

	/**
	 * An intake file as the browser sees it: its facts and a download link
	 * signed for the reader, never where it is stored.
	 *
	 * @param array<string, mixed> $file From IntakeFiles.
	 * @return array<string, mixed>
	 */
	private function intakeFileShape( array $file ): array {
		return [
			'id'             => (int) $file['id'],
			'name'           => (string) $file['name'],
			'size'           => (int) $file['size'],
			'type'           => (string) $file['type'],
			'uploaded_by'    => (string) $file['uploaded_by'],
			'uploaded_by_id' => (int) $file['uploaded_by_id'],
			'uploaded_at'    => (string) $file['uploaded_at'],
			// The portal's row in the site's words and time zone.
			'size_label'     => (string) size_format( (int) $file['size'] ),
			'sent_by'        => IntakeFiles::sentBy( $file ),
			'download_url'   => Downloader::signedUrl( (int) $file['id'], get_current_user_id() ),
		];
	}

	/**
	 * A project's intake files by question, as the browser sees them: a JSON
	 * object keyed by question, `{}` when none holds a file (an empty PHP
	 * array would read as a list).
	 */
	private function intakeFilesShape( int $projectId ): object {
		return (object) array_map(
			fn ( array $files ): array => array_map( [ $this, 'intakeFileShape' ], $files ),
			( new IntakeFiles() )->forProject( $projectId )
		);
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function setStatus( WP_REST_Request $request ): array|WP_Error {
		$projectId = (int) $request['id'];
		$status    = (string) $request->get_param( 'status' );
		if ( ! in_array( $status, Meta::statusOrder(), true ) ) {
			return $this->invalidField( 'status', __( 'Choose a stage from the pipeline.', 'monstera' ) );
		}
		( new Repository() )->setStatus( $projectId, $status );
		return [
			'ok'     => true,
			'status' => $status,
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function summarize( ?\WP_Post $post ): array {
		if ( ! $post ) {
			return [];
		}
		$orgId      = (int) get_post_meta( $post->ID, Meta::KEY_ORG_ID, true );
		$memId      = (int) get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBER_ID, true );
		$standalone = $memId ? get_userdata( $memId ) : null;
		$status     = (string) ( get_post_meta( $post->ID, Meta::KEY_STATUS, true ) ?: Meta::STATUS_PROPOSED );
		$dueOn      = (string) get_post_meta( $post->ID, Meta::KEY_DUE_ON, true );
		$repo       = new Repository();

		return [
			'id'                     => $post->ID,
			'title'                  => get_the_title( $post ),
			'status'                 => $status,
			'status_label'           => Meta::statusLabel( $status ),
			'org_id'                 => $orgId,
			'org_name'               => $orgId ? get_the_title( $orgId ) : '',
			'standalone_member_id'   => $memId,
			'standalone_member_name' => $standalone ? $standalone->display_name : '',
			'started_on'             => (string) get_post_meta( $post->ID, Meta::KEY_STARTED_ON, true ),
			'ended_on'               => (string) get_post_meta( $post->ID, Meta::KEY_ENDED_ON, true ),
			'due_on'                 => $dueOn,
			'team_size'              => count( $repo->memberIds( $post->ID ) ),
			'updated'                => get_post_modified_time( 'c', true, $post ),
			'edit_url'               => admin_url( 'admin.php?page=monstera-projects&id=' . $post->ID ),
		];
	}

	/**
	 * The sidebar's counts (comp 124): content gated to the project (as the
	 * Content list shows it) and its open support requests.
	 *
	 * @return array{content: int, support_open: int}
	 */
	private function projectFacts( int $id ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- counts from Monstera's own tables, read once per detail load.
		$content = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i cp INNER JOIN {$wpdb->posts} p ON p.ID = cp.content_id WHERE cp.project_id = %d AND p.post_status IN ('publish', 'draft', 'pending')",
				Schema::tableName( Schema::TABLE_CONTENT_PROJECTS ),
				$id
			)
		);
		// phpcs:enable
		return [
			'content'      => $content,
			// Null with Support off: the page leaves the fact out.
			'support_open' => $this->factOf(
				\Monstera\Core\Modules::SUPPORT,
				static fn (): int => count(
					( new SupportRepository() )->inbox(
						[
							'project_id' => $id,
							'status'     => SupportRepository::STATUS_OPEN,
						]
					)
				)
			),
		];
	}

	/**
	 * Each logged stage change, oldest first, for the timeline.
	 *
	 * @return list<array{at: string, from: string, to: string}>
	 */
	private function stageHistory( int $id ): array {
		$out = [];
		foreach ( ActivityLog::forObject( 'project', $id, 50 ) as $row ) {
			if ( 'project_stage_changed' !== ( $row['event_type'] ?? '' ) ) {
				continue;
			}
			$context = json_decode( (string) ( $row['context'] ?? '' ), true );
			$out[]   = [
				'at'   => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['occurred_at'] . ' UTC' ) ),
				'from' => (string) ( $context['from'] ?? '' ),
				'to'   => (string) ( $context['to'] ?? '' ),
			];
		}
		return array_reverse( $out );
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		$post       = get_post( $id );
		$repo       = new Repository();
		$orgId      = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		$memId      = (int) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, true );
		$standalone = $memId ? get_userdata( $memId ) : null;
		$status     = (string) ( get_post_meta( $id, Meta::KEY_STATUS, true ) ?: Meta::STATUS_PROPOSED );
		$sgIds      = array_map( 'intval', (array) get_post_meta( $id, Meta::KEY_SUBGROUP_IDS, true ) );
		$members    = $repo->memberIds( $id );

		return [
			'id'                     => $id,
			// As stored: the detail saves it back (the list's is texturized).
			'title'                  => (string) get_post_field( 'post_title', $id, 'raw' ),
			'description'            => (string) $post?->post_content,
			'status'                 => $status,
			'status_label'           => Meta::statusLabel( $status ),
			'org_id'                 => $orgId,
			'org_name'               => $orgId ? get_the_title( $orgId ) : '',
			'standalone_member_id'   => $memId,
			'standalone_member_name' => $standalone ? $standalone->display_name : '',
			'subgroup_ids'           => $sgIds,
			'member_ids'             => array_map( 'intval', $members ),
			'started_on'             => (string) get_post_meta( $id, Meta::KEY_STARTED_ON, true ),
			'ended_on'               => (string) get_post_meta( $id, Meta::KEY_ENDED_ON, true ),
			'due_on'                 => (string) get_post_meta( $id, Meta::KEY_DUE_ON, true ),
			'budget_ref'             => (string) get_post_meta( $id, Meta::KEY_BUDGET_REF, true ),
			'primary_contact_id'     => (int) get_post_meta( $id, Meta::KEY_PRIMARY_CONTACT, true ),
			'lead_id'                => $repo->leadId( $id ),
			// The head, the timeline and the sidebar (comp 124).
			'portal_url'             => Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $id ] ),
			'created'                => (string) get_post_time( 'c', true, $id ),
			'facts'                  => $this->projectFacts( $id ),
			'saved'                  => $this->savedStamp( $id ),
			'stage_history'          => $this->stageHistory( $id ),
			'scope'                  => (string) get_post_meta( $id, Meta::KEY_SCOPE, true ),
			'edit_url'               => admin_url( 'admin.php?page=monstera-projects&id=' . $id ),
		];
	}
}
