<?php
/**
 * Who an item reaches, in words, for the admin's lists (Forms-and-resources
 * track, FR7, FR8; comps 105 and 134): the sub-groups it is narrowed to, by
 * name; else the one organization's members, or how many organizations;
 * else the standalone members it names; else everyone. For staff alone: a
 * client author is told the counts, which name nobody.
 *
 * @package Monstera
 */

declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

trait SaysAudience {

	/**
	 * @param array<int, int> $subgroupIds As stored.
	 * @param array<int, int> $orgIds
	 * @param array<int, int> $memIds
	 */
	private function audienceInWords( array $subgroupIds, array $orgIds, array $memIds ): string {
		$live   = SubgroupRepository::ofOrgsOnSite( SubgroupRepository::published( $subgroupIds ) );
		$groups = array_values( array_filter( array_map( static fn ( int $sg ): string => (string) get_the_title( $sg ), $live ) ) );
		if ( $groups ) {
			return implode( ', ', $groups );
		}
		// Limited to sub-groups that are no longer on the site: the gate
		// holds and lets no member in (trash grants nothing).
		if ( $subgroupIds ) {
			return __( 'No one: its sub-group was removed', 'monstera' );
		}
		if ( 1 === count( $orgIds ) && ! $memIds ) {
			/* translators: %s: an organization's name */
			return sprintf( __( 'Members of %s', 'monstera' ), (string) get_the_title( $orgIds[0] ) );
		}
		if ( $orgIds && ! $memIds ) {
			return sprintf(
				/* translators: %d: how many organizations */
				_n( '%d organization', '%d organizations', count( $orgIds ), 'monstera' ),
				count( $orgIds )
			);
		}
		if ( $orgIds || $memIds ) {
			return $this->summarizeAccess( $orgIds, $memIds );
		}
		return __( 'Everyone', 'monstera' );
	}
}
