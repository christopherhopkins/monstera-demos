<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Admin\RailCounts;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta;
use Monstera\Organizations\PostType;
use Monstera\Organizations\Repository;
use Monstera\Organizations\Roster;
use Monstera\Organizations\TierTaxonomy;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Reporting\ActivityFeed;
use Monstera\Reporting\ActivityLog;
use Monstera\Rest\BulkRequest;
use Monstera\Rest\BulkResult;
use Monstera\Rest\DayField;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

final class OrganizationsController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/organizations',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'index' ],
					'args'                => [
						// No default here: index() takes 50, or 20 for a search
						// the caller gave no page size of its own.
						'per_page'  => [
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 500,
						],
						// A name search for the organization combobox: twenty
						// by name unless the caller asks for a page size.
						'search'    => [
							'type'    => 'string',
							'default' => '',
						],
						// Published ones alone, which is to say active ones, for
						// an organization field whose save needs one (a
						// membership, an assignment), so a suspended or archived
						// one never takes a place in its list or its twenty.
						'published' => [
							'type'    => 'boolean',
							'default' => false,
						],
					],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/organizations/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionManage(),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id'              => [
							'type'     => 'integer',
							'required' => true,
						],
						// The account lead: one of the assigned staff by id,
						// 0 for nobody (At-a-glance track, FR4). Anything that
						// is not a whole number is refused by the schema.
						'account_lead_id' => [
							'type'    => 'integer',
							'minimum' => 0,
						],
					],
				],
			]
		);

		// One organization as the list reads it, for the summary block on
		// other details (At-a-glance track, FR5): the row, not the detail,
		// which counts its facts and builds its activity.
		register_rest_route(
			$this->restNamespace,
			'/organizations/(?P<id>\d+)/summary',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'summary' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		// The tier names for the list's "Reassign tier" panel. Here, not at
		// the taxonomy's own core REST base, which answered anyone.
		register_rest_route(
			$this->restNamespace,
			'/organizations/tiers',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'tiers' ],
			]
		);

		$this->registerBulkRoute( '/organizations', [ 'suspend', 'reassign_tier' ], [ $this, 'bulkAction' ], [ $this, 'validateBulk' ] );
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$repo    = new Repository();
		$search  = trim( sanitize_text_field( (string) $request['search'] ) );
		$perPage = (int) ( $request['per_page'] ?? 0 );
		$args    = [ 'posts_per_page' => $perPage > 0 ? $perPage : ( '' !== $search ? 20 : 50 ) ];
		if ( '' !== $search ) {
			// By name alone, for the combobox: twenty unless the caller asked
			// for a page size of its own.
			$args['s']              = $search;
			$args['search_columns'] = [ 'post_title' ];
		}
		// A registered boolean: the server has read "1" or "true" as one.
		if ( true === $request['published'] ) {
			$args['post_status'] = 'publish';
		}
		return [ 'items' => $this->rows( $repo->all( $args ), $repo ) ];
	}

	/**
	 * One organization as the list reads it: the summary block's read on
	 * other details (At-a-glance track, FR5).
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function summary( WP_REST_Request $request ): array|WP_Error {
		$repo = new Repository();
		$org  = $repo->findById( (int) $request['id'] );
		// What the list shows, in any status: a trashed organization is no
		// longer on the site to the block, as a deleted one is.
		if ( ! $org || ! in_array( $org->post_status, Repository::ON_SITE, true ) ) {
			return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return $this->rows( [ $org ], $repo )[0];
	}

	/**
	 * The list's rows. Every row counts its members: one read of the
	 * memberships for the page; its projects under way from one grouped
	 * read, and its account lead's name from one read of the leads'
	 * accounts (FR2).
	 *
	 * @param \WP_Post[] $posts
	 * @return list<array<string, mixed>>
	 */
	private function rows( array $posts, Repository $repo ): array {
		$ids = wp_list_pluck( $posts, 'ID' );
		Roster::primeOrgs( $ids );
		$projectsOn = \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::PROJECTS );
		$underWay   = $this->underWay( $ids );
		$leads      = $this->accountLeadsOf( $ids, $repo );

		$items = [];
		foreach ( $posts as $org ) {
			$items[] = [
				'id'              => $org->ID,
				'name'            => get_the_title( $org ),
				'slug'            => $org->post_name,
				// Active, suspended or archived, read from the post: the
				// organization field marks one that is not active, and leaves
				// it out where the save needs an active one.
				'status'          => $repo->status( $org->ID ),
				'tier'            => $this->tierOf( $org->ID ),
				'seat_limit'      => (int) get_post_meta( $org->ID, Meta::KEY_SEAT_LIMIT, true ),
				'expires'         => (string) get_post_meta( $org->ID, Meta::KEY_EXPIRES, true ),
				'members'         => $repo->memberCount( $org->ID ),
				// Null with Projects off, as every module-fed fact: what it
				// would have counted is unknown, not zero.
				'projects_active' => $projectsOn ? ( $underWay[ $org->ID ] ?? 0 ) : null,
				'account_lead'    => $leads[ $org->ID ] ?? null,
				'edit_url'        => $this->shellEditUrl( $org->ID ),
			];
		}
		return $items;
	}

	/**
	 * The organization's tier name, from the term cache the list query
	 * primed: wp_get_post_terms() asks the database for every row.
	 */
	private function tierOf( int $orgId ): string {
		$terms = get_the_terms( $orgId, TierTaxonomy::SLUG );
		return is_array( $terms ) && $terms ? (string) reset( $terms )->name : '';
	}

	/**
	 * Projects under way by organization, or nothing with Projects off.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return array<int, int>
	 */
	private function underWay( array $orgIds ): array {
		if ( ! \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::PROJECTS ) ) {
			return [];
		}
		return ( new ProjectRepository() )->inFlightCountsFor( $orgIds );
	}

	/**
	 * Each organization's account lead as the list and the detail name one
	 * (`{ id, name, url }`, the url their staff detail), from one read of
	 * the accounts. An organization with none is not in the answer.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return array<int, array{id: int, name: string, url: string}>
	 */
	private function accountLeadsOf( array $orgIds, Repository $repo ): array {
		$leadOf = [];
		foreach ( $orgIds as $orgId ) {
			$leadId = $repo->accountLeadId( (int) $orgId );
			if ( $leadId > 0 ) {
				$leadOf[ (int) $orgId ] = $leadId;
			}
		}
		if ( ! $leadOf ) {
			return [];
		}
		cache_users( array_values( array_unique( $leadOf ) ) );
		// One person built per lead, not per organization they lead: a
		// WP_User and a name are work for every row, and a lead has many.
		// A lead whose account is gone reads as none.
		$people = [];
		foreach ( array_unique( $leadOf ) as $leadId ) {
			$user = get_userdata( $leadId );
			if ( $user instanceof \WP_User ) {
				$people[ $leadId ] = [
					'id'   => $leadId,
					'name' => UserMeta::fullName( $user ),
					'url'  => admin_url( 'admin.php?page=monstera-team&id=' . $leadId ),
				];
			}
		}
		$out = [];
		foreach ( $leadOf as $orgId => $leadId ) {
			if ( isset( $people[ $leadId ] ) ) {
				$out[ $orgId ] = $people[ $leadId ];
			}
		}
		return $out;
	}

	/**
	 * Every tier by name, used or not, in alphabetical order.
	 *
	 * @return array{items: list<string>}
	 */
	public function tiers(): array {
		$names = get_terms(
			[
				'taxonomy'   => TierTaxonomy::SLUG,
				'hide_empty' => false,
				'fields'     => 'names',
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);
		return [ 'items' => is_array( $names ) ? array_values( array_map( 'strval', $names ) ) : [] ];
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id  = (int) $request['id'];
		$org = ( new Repository() )->findById( $id );
		if ( ! $org ) {
			return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		return $this->shape( $org->ID );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$name = sanitize_text_field( (string) ( $request['name'] ?? '' ) );
		if ( '' === $name ) {
			return $this->invalidField( 'name', __( 'Give the organization a name.', 'monstera' ) );
		}
		// A slug the admin typed must be free; one derived from the name (the
		// field left blank) may take WordPress's numbered suffix instead.
		$slug = sanitize_title( $name );
		if ( '' !== trim( (string) ( $request['slug'] ?? '' ) ) ) {
			$slug = $this->checkedSlug( (string) $request['slug'], 0 );
			if ( $slug instanceof WP_Error ) {
				return $slug;
			}
		}

		// The people named as its first members are checked before the
		// organization is made, so a refused create makes nothing.
		$refused = $this->refusedFirstMembers( $request ) ?? DayField::refusal( $request, 'expires' );
		if ( $refused ) {
			return $refused;
		}

		// Made in the status asked for (the owner, 2026-10-18): active is
		// published, suspended and archived are drafts, a draft's slug made
		// unique as a published one's is (Repository::uniqueSlug()).
		$id = wp_insert_post(
			array_merge(
				[
					'post_type'  => PostType::SLUG,
					'post_title' => $name,
					'post_name'  => $slug,
				],
				Repository::madeAs( (string) ( $request['status'] ?? Meta::STATUS_ACTIVE ) )
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$this->applyMutations( (int) $id, $request );
		$this->joinFirstMembers( (int) $id, $request );
		$this->stampEditor( (int) $id );

		// A standard org renewal cycle is one year. If no renewal date came in
		// with the request, start the org on that cycle so every org has a
		// sensible default expiry; it stays editable via the `expires` param.
		if ( '' === (string) get_post_meta( (int) $id, Meta::KEY_EXPIRES, true ) ) {
			update_post_meta( (int) $id, Meta::KEY_EXPIRES, Membership::defaultExpiry() );
		}

		// Heard once the organization is whole, its fields, first members and
		// renewal date saved, in whatever status it was made (docs/HOOKS.md).
		do_action( Hooks::ORG_CREATED, (int) $id );

		return $this->shape( (int) $id );
	}

	/**
	 * Save the organization's own fields. Its people are not among them: a
	 * membership is made, given another tier and ended through the roster's
	 * routes (OrgMembersController) and the memberships routes
	 * (MembersController), one at a time and each with its tier, so a save
	 * here reads no roster. A request that names one (`member_ids`,
	 * `invites`, as the organization detail sent them while its roster was a
	 * picker) is saved for everything else it carries and adds, removes and
	 * invites nobody; the answer counts the roster as it stands.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id  = (int) $request['id'];
		$org = ( new Repository() )->findById( $id );
		if ( ! $org ) {
			return new WP_Error( 'monstera_not_found', __( 'Organization not found.', 'monstera' ), [ 'status' => 404 ] );
		}

		// Every refusal comes before the first write, so a refused save
		// changes nothing.
		if ( $request->has_param( 'account_lead_id' ) ) {
			$leadId = absint( $request['account_lead_id'] );
			if ( $leadId > 0 && ! in_array( $leadId, Roster::staffIds( $id ), true ) ) {
				return $this->invalidField( 'account_lead_id', __( 'Choose someone assigned to this organization.', 'monstera' ) );
			}
		}
		$day = DayField::refusal( $request, 'expires' );
		if ( $day ) {
			return $day;
		}
		$postUpdate = [ 'ID' => $id ];
		if ( $request->has_param( 'name' ) ) {
			$name = sanitize_text_field( (string) $request['name'] );
			if ( '' === $name ) {
				return $this->invalidField( 'name', __( 'Give the organization a name.', 'monstera' ) );
			}
			$postUpdate['post_title'] = $name;
		}
		if ( $request->has_param( 'slug' ) ) {
			$slug = $this->checkedSlug( (string) $request['slug'], $id );
			if ( $slug instanceof WP_Error ) {
				return $slug;
			}
			$postUpdate['post_name'] = $slug;
		}
		if ( count( $postUpdate ) > 1 ) {
			wp_update_post( $postUpdate );
		}

		$this->applyMutations( $id, $request );
		if ( $request->has_param( 'account_lead_id' ) ) {
			// Checked above; the repository is the one writer, with the hook
			// and the sentence (At-a-glance track, FR4).
			( new Repository() )->setAccountLead( $id, absint( $request['account_lead_id'] ) );
		}
		$this->stampEditor( $id );
		// A meta-only save leaves the post untouched; bump its modified time
		// so "Last saved" tells the truth.
		if ( 1 === count( $postUpdate ) ) {
			wp_update_post( [ 'ID' => $id ] );
		}
		return $this->shape( $id );
	}

	/**
	 * The slug as it will be stored, or a 422 naming the field when it is
	 * empty or another organization already has it (the message names that
	 * organization, as the comp's save bar does).
	 */
	private function checkedSlug( string $raw, int $selfId ): string|WP_Error {
		$slug = sanitize_title( $raw );
		if ( '' === $slug ) {
			return $this->invalidField( 'slug', __( 'Give the organization a slug: letters, numbers and hyphens.', 'monstera' ) );
		}
		$taken = get_posts(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'any',
				'name'           => $slug,
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'exclude'        => $selfId ? [ $selfId ] : [], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- at most one id, the organization itself.
			]
		);
		if ( $taken ) {
			return $this->invalidField(
				'slug',
				sprintf(
					/* translators: %s: the organization that already uses the slug */
					__( 'Already used by %s. Try another slug.', 'monstera' ),
					html_entity_decode( (string) get_post_field( 'post_title', (int) $taken[0] ), ENT_QUOTES, 'UTF-8' )
				)
			);
		}
		return $slug;
	}

	/**
	 * Apply optional mutations from a request to an org. Used by both create
	 * and update so the schema stays consistent: anything the form can set
	 * on either goes through here. Who belongs to the organization is not
	 * one of them (see update() and joinFirstMembers()).
	 */
	private function applyMutations( int $id, WP_REST_Request $request ): void {
		if ( $request->has_param( 'description' ) ) {
			update_post_meta( $id, Meta::KEY_DESCRIPTION, wp_kses_post( (string) $request['description'] ) );
		}
		if ( $request->has_param( 'location' ) ) {
			update_post_meta( $id, Meta::KEY_LOCATION, sanitize_text_field( (string) $request['location'] ) );
		}
		if ( $request->has_param( 'seat_limit' ) ) {
			update_post_meta( $id, Meta::KEY_SEAT_LIMIT, absint( $request['seat_limit'] ) );
		}
		if ( $request->has_param( 'expires' ) ) {
			update_post_meta( $id, Meta::KEY_EXPIRES, sanitize_text_field( (string) $request['expires'] ) );
		}
		if ( $request->has_param( 'status' ) ) {
			$status = (string) $request['status'];
			// setStatus() rejects unknown values and fires the status hook only
			// on a real change, so a suspension here emails the members exactly
			// as the bulk and cron paths do.
			if ( ( new Repository() )->setStatus( $id, $status ) && Meta::STATUS_SUSPENDED === $status ) {
				ActivityLog::record( 'org_suspended', 'org', $id );
			}
		}
		if ( $request->has_param( 'tier' ) ) {
			$tier = sanitize_text_field( (string) $request['tier'] );
			if ( '' === $tier ) {
				wp_set_post_terms( $id, [], TierTaxonomy::SLUG );
			} else {
				wp_set_post_terms( $id, [ $tier ], TierTaxonomy::SLUG );
			}
		}
	}

	/**
	 * The people a new organization is made with: the accounts its form
	 * names (`member_ids`) and the email addresses it invites (`invites`).
	 * An organization that does not exist yet has no roster route to ask, so
	 * the one request that makes it carries them, and only that request: a
	 * save of an organization that exists names nobody (update()).
	 *
	 * @return array{0: list<int>, 1: list<string>}
	 */
	private function firstMembers( WP_REST_Request $request ): array {
		$ids     = array_values( array_map( 'absint', (array) ( $request['member_ids'] ?? [] ) ) );
		$invites = array_values( array_map( 'strval', (array) ( $request['invites'] ?? [] ) ) );
		return [ $ids, $invites ];
	}

	/**
	 * A 422 naming the members field when the first members a create asks
	 * for cannot join, or null: each must be someone who can belong to an
	 * organization, each invite an email address the picker cannot offer (a
	 * free one, or one whose account is in no list and an invitation would
	 * take, Roster::refusal()), and together they must fit the seat limit
	 * the create carries.
	 *
	 * One of the team is not someone who can: staff are assigned to an
	 * organization and are never on its roster (People-model track, FR6).
	 * The Roster's own check lets both team roles through, its roles being
	 * the Members list's, so a team account is turned away here first, in
	 * the words the memberships route says it in (MembersController::join()).
	 * Without it this form would be the one door left for staff onto a
	 * roster, and a person put there could no longer be assigned.
	 */
	private function refusedFirstMembers( WP_REST_Request $request ): ?WP_Error {
		[ $ids, $invites ] = $this->firstMembers( $request );
		if ( ! $ids && ! $invites ) {
			return null;
		}
		// One made suspended or archived takes no one new until it is active
		// (the owner, 2026-10-18).
		if ( in_array( (string) ( $request['status'] ?? '' ), [ Meta::STATUS_SUSPENDED, Meta::STATUS_ARCHIVED ], true ) ) {
			return $this->invalidField( 'member_ids', __( 'Make the organization active to add its first members.', 'monstera' ) );
		}
		foreach ( $ids as $userId ) {
			$user = get_userdata( $userId );
			if ( $user && Capabilities::isStaff( $user ) ) {
				return $this->invalidField( 'member_ids', __( 'The team is assigned to organizations, not added to them.', 'monstera' ) );
			}
		}
		$limit  = $request->has_param( 'seat_limit' ) ? absint( $request['seat_limit'] ) : null;
		$reason = Roster::refusal( 0, $ids, $invites, $limit );
		return null === $reason ? null : $this->invalidField( 'member_ids', $reason );
	}

	/**
	 * Put a new organization's first members on its roster, through the one
	 * path people join by (Roster::addMany()): each joins at the tier their
	 * role implies and keeps every organization they already have, and each
	 * address invited becomes an account with the welcome email, or is
	 * attached when it has one no picker lists (Roster::invite()).
	 * refusedFirstMembers() has passed them before the organization was made.
	 */
	private function joinFirstMembers( int $id, WP_REST_Request $request ): void {
		[ $ids, $invites ] = $this->firstMembers( $request );
		if ( $ids || $invites ) {
			Roster::addMany( $id, $ids, $invites );
		}
	}

	/**
	 * The sidebar's counts (comp 120): the organization's sub-groups, the
	 * content addressed to it (as the Content list shows it), and its projects in flight.
	 *
	 * @return array{subgroups: int, content: int, projects_in_flight: int|null}
	 */
	private function facts( int $id ): array {
		$count = static function ( array $args ): int {
			$query = new \WP_Query(
				array_merge(
					[
						'post_status'    => 'publish',
						'posts_per_page' => 1,
						'fields'         => 'ids',
					],
					$args
				)
			);
			return (int) $query->found_posts;
		};
		return [
			'subgroups'          => count( ( new SubgroupRepository() )->forOrg( $id ) ),
			// What the Content list shows (published, draft and pending), so
			// the count matches the list it links to.
			'content'            => $count(
				[
					'post_type'   => ContentPostType::SLUG,
					'post_status' => [ 'publish', 'draft', 'pending' ],
					'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- one key, counted once per detail load; the same match Content\Repository::forOrgs() uses.
						[
							'key'     => ContentMeta::KEY_ORG_IDS,
							'value'   => sprintf( ':%d;', $id ),
							'compare' => 'LIKE',
						],
					],
				]
			),
			// Null with Projects off: the page leaves the fact out. The same
			// read, and so the same number, as the list's projects_active.
			'projects_in_flight' => $this->underWay( [ $id ] )[ $id ] ?? ( \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::PROJECTS ) ? 0 : null ),
		];
	}

	/**
	 * Standard payload for a single org — used by show / create / update.
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		$repo      = new Repository();
		$tierTerms = wp_get_post_terms( $id, TierTaxonomy::SLUG, [ 'fields' => 'names' ] );

		$slug  = (string) get_post_field( 'post_name', $id );
		$facts = $this->facts( $id );

		return [
			'id'              => $id,
			// The title as stored, not as the theme displays it: the detail's
			// name field saves it back, and get_the_title() would turn a
			// straight apostrophe into a curly one (and an entity) on the way.
			'name'            => (string) get_post_field( 'post_title', $id, 'raw' ),
			'slug'            => $slug,
			'portal_url'      => $slug ? Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] ) : '',
			// Where the portal lives, for the slug field's hint.
			'portal_base'     => Routing::url( Routing::ROUTE_DASHBOARD ),
			'facts'           => $facts,
			'activity'        => ActivityFeed::shape( ActivityLog::forOrg( $id, 5 ) ),
			// Active, suspended or archived, read from the post. One that is
			// not active takes no new member and no team (the invite and assign
			// routes refuse it; the roster's and the team's other routes still
			// answer), so the detail says to reactivate it there (the owner,
			// 2026-10-18).
			'status'          => $repo->status( $id ),
			// For the one state the status does not say: in the trash, whose
			// hub does not open and which is restored in WordPress.
			'post_status'     => (string) get_post_status( $id ),
			'tier'            => is_array( $tierTerms ) ? ( $tierTerms[0] ?? '' ) : '',
			'seat_limit'      => (int) get_post_meta( $id, Meta::KEY_SEAT_LIMIT, true ),
			'expires'         => (string) get_post_meta( $id, Meta::KEY_EXPIRES, true ),
			'location'        => (string) get_post_meta( $id, Meta::KEY_LOCATION, true ),
			'description'     => (string) get_post_meta( $id, Meta::KEY_DESCRIPTION, true ),
			// How many, for the seats line. Who they are is the roster's own
			// route's to answer (orgs/{id}/members), with a tier for each.
			'members'         => count( Roster::memberIds( $id ) ),
			// The two at-a-glance facts the list's row carries too: for the
			// summary block on other details and the organization's own At a
			// glance (At-a-glance track, FR2, FR4).
			'projects_active' => $facts['projects_in_flight'],
			'account_lead'    => $this->accountLeadsOf( [ $id ], $repo )[ $id ] ?? null,
			'edit_url'        => $this->shellEditUrl( $id ),
			// From the post's local date, which a draft has too: WordPress
			// leaves a draft's GMT date empty until it is published.
			'created'         => get_post_timestamp( $id ) ? gmdate( 'c', (int) get_post_timestamp( $id ) ) : '',
			'saved'           => $this->savedStamp( $id ),
		];
	}

	private function shellEditUrl( int $id ): string {
		return admin_url( 'admin.php?page=monstera-organizations&id=' . $id );
	}
	/**
	 * One id of a bulk request. Each action reuses the single-item write path so
	 * the audit trail and hooks match; skipped ids carry the reason.
	 */
	public function bulkAction( BulkRequest $bulk, int $id, BulkResult $result ): void {
		match ( $bulk->action ) {
			'suspend'       => $this->bulkSuspend( $id, $result ),
			'reassign_tier' => $this->bulkReassignTier( $id, self::tierParam( $bulk ), $result ),
			default         => $result->skip( $id, __( 'Unknown bulk action.', 'monstera' ) ),
		};
	}

	/**
	 * A tier that does not exist is wrong for every id, so the whole request is
	 * refused rather than creating the term by accident (wp_set_post_terms would).
	 */
	public function validateBulk( BulkRequest $bulk ): ?WP_Error {
		if ( 'reassign_tier' !== $bulk->action ) {
			return null;
		}
		$tier = self::tierParam( $bulk );
		if ( '' !== $tier && ! term_exists( $tier, TierTaxonomy::SLUG ) ) {
			return new WP_Error( 'monstera_bulk_unknown_tier', __( 'That tier does not exist.', 'monstera' ), [ 'status' => 422 ] );
		}
		return null;
	}

	private static function tierParam( BulkRequest $bulk ): string {
		return sanitize_text_field( (string) ( $bulk->params['tier'] ?? '' ) );
	}

	private function bulkReassignTier( int $id, string $tier, BulkResult $result ): void {
		if ( ! ( new Repository() )->findById( $id ) ) {
			$result->skip( $id, __( 'Not an organization.', 'monstera' ) );
			return;
		}
		wp_set_post_terms( $id, '' === $tier ? [] : [ $tier ], TierTaxonomy::SLUG );
		ActivityLog::record( 'org_tier_changed', 'org', $id, [ 'tier' => $tier ] );
		$result->done(
			$id,
			'' === $tier
				? __( 'Tier cleared.', 'monstera' )
				/* translators: %s: tier name. */
				: sprintf( __( 'Tier set to %s.', 'monstera' ), $tier )
		);
	}

	private function bulkSuspend( int $id, BulkResult $result ): void {
		$repo = new Repository();
		if ( ! $repo->findById( $id ) ) {
			$result->skip( $id, __( 'Not an organization.', 'monstera' ) );
			return;
		}
		$status = $repo->status( $id );
		if ( Meta::STATUS_SUSPENDED === $status ) {
			$result->skip( $id, __( 'Already suspended.', 'monstera' ) );
			return;
		}
		if ( Meta::STATUS_ARCHIVED === $status ) {
			$result->skip( $id, __( 'Archived organizations stay archived.', 'monstera' ) );
			return;
		}
		// A move WordPress refuses leaves it active, and is no suspension.
		if ( ! $repo->setStatus( $id, Meta::STATUS_SUSPENDED ) ) {
			$result->skip( $id, __( 'Could not suspend.', 'monstera' ) );
			return;
		}
		ActivityLog::record( 'org_suspended', 'org', $id );
		$result->done( $id, __( 'Suspended.', 'monstera' ) );
	}
}
