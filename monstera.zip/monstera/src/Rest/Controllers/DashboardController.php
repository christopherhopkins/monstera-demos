<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\BackgroundSync\Cron;
use Monstera\Alerts\Expiry;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\PostType as AlertPostType;
use Monstera\Content\Meta as ContentMeta;
use Monstera\BackgroundSync\BackgroundSyncModule;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Core\Database\Schema;
use Monstera\Core\Modules;
use Monstera\Core\SecureStorage;
use Monstera\Integrations\Detector;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Reporting\ActivityFeed;
use Monstera\Support\Repository as SupportRepository;
use WP_Query;

/**
 * Backs the admin dashboard.
 *
 * Returns a single payload describing what needs attention, recent activity,
 * and system health. Designed to make the dashboard render in one round-trip.
 */
final class DashboardController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/dashboard/summary',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'summary' ],
			]
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	public function summary(): array {
		return [
			'tasks'           => $this->tasks(),
			'recent_activity' => $this->recentActivity(),
			'health'          => $this->health(),
			'health_checked'  => (string) wp_date( (string) get_option( 'time_format', 'g:i a' ) ),
		];
	}

	/**
	 * What needs the admin's attention (comp 90): one row per kind, each with
	 * a line, a sub-line and one action. Kinds tied to a module leave with it.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function tasks(): array {
		$tasks = [];
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			$tasks[] = $this->discoveryTask();
		}
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			$tasks[] = $this->supportTask();
		}
		array_push( $tasks, ...$this->renewalTasks() );
		if ( Modules::isActive( Modules::ALERTS ) ) {
			$tasks[] = $this->alertsTask();
		}
		$tasks[] = $this->pendingContentTask();
		return array_values( array_filter( $tasks ) );
	}

	/**
	 * Up to three names, then "and N more".
	 *
	 * @param array<int, string> $names The names, first three shown.
	 */
	private function andMore( array $names, int $total ): string {
		$shown = implode( ', ', array_slice( $names, 0, 3 ) );
		$more  = $total - min( 3, count( $names ) );
		return $more > 0
			/* translators: 1: a list of names, 2: how many more there are */
			? sprintf( _n( '%1$s and %2$d more', '%1$s and %2$d more', $more, 'monstera' ), $shown, $more )
			: $shown;
	}

	/** "Friday" within the last week, "Sep 12" before that. */
	private function dayLabel( int $at ): string {
		return time() - $at < 6 * DAY_IN_SECONDS ? (string) wp_date( 'l', $at ) : (string) wp_date( 'M j', $at );
	}

	/** @return array<string, string>|null */
	private function discoveryTask(): ?array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one grouped read for the dashboard.
			$wpdb->prepare(
				'SELECT project_id, MAX(submitted_at) AS submitted_at FROM %i GROUP BY project_id ORDER BY submitted_at DESC',
				Schema::tableName( Schema::TABLE_PROJECT_INTAKE )
			),
			ARRAY_A
		);
		// Answers from the last seven days: submitting moves a project on to
		// In progress by default (FILTER_AUTO_ADVANCE_AFTER_INTAKE), so the
		// stage alone would hide exactly the answers that want reading.
		$waiting = [];
		foreach ( (array) $rows as $row ) {
			$id = (int) $row['project_id'];
			$at = (int) strtotime( $row['submitted_at'] . ' UTC' );
			if ( 'publish' === get_post_status( $id ) && time() - $at <= 7 * DAY_IN_SECONDS ) {
				$waiting[] = [ $id, $at ];
			}
		}
		if ( ! $waiting ) {
			return null;
		}
		[ $first, $at ] = $waiting[0];
		$orgId          = (int) get_post_meta( $first, ProjectMeta::KEY_ORG_ID, true );
		$parts          = array_values( array_filter( [ $this->title( $first ), $orgId ? $this->title( $orgId ) : '' ] ) );
		/* translators: %s: a weekday or date, e.g. "Friday" */
		$parts[] = sprintf( __( 'submitted %s', 'monstera' ), $this->dayLabel( $at ) );
		$count   = count( $waiting );
		$detail  = implode( ' · ', $parts );
		if ( $count > 1 ) {
			/* translators: 1: the first project's line, 2: how many more projects */
			$detail = sprintf( _n( '%1$s, and %2$d more project', '%1$s, and %2$d more projects', $count - 1, 'monstera' ), $detail, $count - 1 );
		}
		return [
			'id'           => 'discovery',
			/* translators: %d: number of projects whose discovery answers are in */
			'title'        => sprintf( _n( '%d discovery response to review', '%d discovery responses to review', $count, 'monstera' ), $count ),
			'detail'       => $detail,
			'url'          => 1 === $count ? admin_url( 'admin.php?page=monstera-projects&id=' . $first ) : admin_url( 'admin.php?page=monstera-projects' ),
			'action_label' => __( 'Review', 'monstera' ),
		];
	}

	/** @return array<string, string>|null */
	private function supportTask(): ?array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the dashboard's own read.
			$wpdb->prepare(
				'SELECT ref, org_id FROM %i WHERE status = %s AND created_at < %s ORDER BY created_at ASC',
				Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
				SupportRepository::STATUS_OPEN,
				gmdate( 'Y-m-d H:i:s', time() - 2 * DAY_IN_SECONDS )
			),
			ARRAY_A
		);
		if ( ! $rows ) {
			return null;
		}
		$names = [];
		foreach ( array_slice( (array) $rows, 0, 3 ) as $row ) {
			$names[] = (int) $row['org_id']
				/* translators: 1: a support reference, 2: an organization's name */
				? sprintf( __( '%1$s (%2$s)', 'monstera' ), $row['ref'], $this->title( (int) $row['org_id'] ) )
				: (string) $row['ref'];
		}
		$count = count( (array) $rows );
		return [
			'id'           => 'support',
			/* translators: %d: number of open support requests older than two days */
			'title'        => sprintf( _n( '%d support request open more than two days', '%d support requests open more than two days', $count, 'monstera' ), $count ),
			'detail'       => $this->andMore( $names, $count ),
			'url'          => admin_url( 'admin.php?page=monstera-support' ),
			'action_label' => __( 'Open inbox', 'monstera' ),
		];
	}

	/**
	 * One row per active organization renewing within 30 days, soonest first.
	 *
	 * @return array<int, array<string, string>>
	 */
	private function renewalTasks(): array {
		$soon = [];
		$orgs = new OrgRepository();
		foreach ( $orgs->all() as $org ) {
			// Through the repository: an organization made in the admin has no
			// status meta until it is first suspended, and is active.
			if ( ! $orgs->isActive( $org->ID ) ) {
				continue;
			}
			$raw = (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true );
			$day = $raw ? strtotime( substr( $raw, 0, 10 ) . ' UTC' ) : false;
			if ( $day && $day >= strtotime( gmdate( 'Y-m-d' ) . ' UTC' ) && $day - time() < 30 * DAY_IN_SECONDS ) {
				$soon[ $org->ID ] = $day;
			}
		}
		asort( $soon );
		$today = (int) strtotime( gmdate( 'Y-m-d' ) . ' UTC' );
		$tasks = [];
		foreach ( $soon as $orgId => $day ) {
			$days  = (int) round( ( $day - $today ) / DAY_IN_SECONDS );
			$name  = $this->title( $orgId );
			$title = match ( true ) {
				/* translators: %s: an organization's name */
				$days <= 0  => sprintf( __( '%s renews today', 'monstera' ), $name ),
				/* translators: %s: an organization's name */
				1 === $days => sprintf( __( '%s renews tomorrow', 'monstera' ), $name ),
				/* translators: 1: an organization's name, 2: number of days */
				default     => sprintf( _n( '%1$s renews in %2$d day', '%1$s renews in %2$d days', $days, 'monstera' ), $name, $days ),
			};
			$tasks[] = [
				'id'           => 'renewal-' . $orgId,
				'title'        => $title,
				/* translators: %s: the membership's end date, e.g. "Oct 3" */
				'detail'       => sprintf( __( 'Expires %s', 'monstera' ), gmdate( 'M j', $day ) ),
				'url'          => admin_url( 'admin.php?page=monstera-organizations&id=' . $orgId ),
				'action_label' => __( 'Open org', 'monstera' ),
			];
		}
		return $tasks;
	}

	/** @return array<string, string>|null */
	private function alertsTask(): ?array {
		$query    = new WP_Query(
			[
				'post_type'      => AlertPostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);
		$expiring = [];
		foreach ( $query->posts as $id ) {
			$at = Expiry::timestamp( (string) get_post_meta( (int) $id, AlertMeta::KEY_EXPIRES_AT, true ) );
			if ( $at && $at > time() && $at - time() <= DAY_IN_SECONDS ) {
				$expiring[ (int) $id ] = $at;
			}
		}
		if ( ! $expiring ) {
			return null;
		}
		asort( $expiring );
		$first = (int) array_key_first( $expiring );
		$count = count( $expiring );
		$line  = $this->title( $first ) . ' · ' . wp_date( (string) get_option( 'time_format', 'g:i a' ), $expiring[ $first ] );
		return [
			'id'           => 'alerts',
			/* translators: %d: number of live alerts that expire in the next 24 hours */
			'title'        => sprintf( _n( '%d alert expires within a day', '%d alerts expire within a day', $count, 'monstera' ), $count ),
			'detail'       => $count > 1
				/* translators: 1: the first alert's line, 2: how many more alerts */
				? sprintf( _n( '%1$s, and %2$d more', '%1$s, and %2$d more', $count - 1, 'monstera' ), $line, $count - 1 )
				: $line,
			'url'          => 1 === $count ? admin_url( 'admin.php?page=monstera-alerts&id=' . $first ) : admin_url( 'admin.php?page=monstera-alerts' ),
			'action_label' => __( 'Extend or dismiss', 'monstera' ),
		];
	}

	/** @return array<string, string>|null */
	private function pendingContentTask(): ?array {
		$pending = new WP_Query(
			[
				'post_type'      => ContentPostType::SLUG,
				'post_status'    => [ 'publish', 'draft', 'pending', 'future' ],
				'meta_key'       => ContentMeta::KEY_VISIBILITY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one indexed key, counted once per dashboard load.
				'meta_value'     => ContentMeta::VISIBILITY_PENDING, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
				'posts_per_page' => 1,
				'fields'         => 'ids',
			]
		);
		$count   = (int) $pending->found_posts;
		if ( 0 === $count ) {
			return null;
		}
		return [
			'id'           => 'pending-content',
			/* translators: %d: number of content items whose visibility is Pending review */
			'title'        => sprintf( _n( '%d item is waiting for review', '%d items are waiting for review', $count, 'monstera' ), $count ),
			'detail'       => __( 'They reach members once you mark them Published.', 'monstera' ),
			'url'          => admin_url( 'admin.php?page=monstera-content' ),
			'action_label' => __( 'Open', 'monstera' ),
		];
	}

	/** A post's title as plain text. */
	private function title( int $postId ): string {
		return html_entity_decode( (string) get_post_field( 'post_title', $postId ), ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private function recentActivity(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'monstera_activity_log';
		// Guard against a half-run migration: if the table isn't present, return
		// empty rather than emitting a DB error and a foreach-on-null warning.
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			return [];
		}
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY occurred_at DESC LIMIT 8', $table ), ARRAY_A );

		return ActivityFeed::shape( (array) $rows );
	}

	/**
	 * System health (comp 90): five rows, each with a sub-line and OK or
	 * Check. Nothing here walks the disk or calls out: the storage size is
	 * the daily sync's measurement and the update check is WordPress's own.
	 *
	 * @return array<int, array{key: string, name: string, ok: bool, message: string}>
	 */
	private function health(): array {
		return [
			$this->cronHealth(),
			$this->storageHealth(),
			$this->emailHealth(),
			$this->loginHealth(),
			$this->versionsHealth(),
		];
	}

	/** A time today ("2:00 am"), or a date and time on another day. */
	private function moment( int $at ): string {
		$time = (string) get_option( 'time_format', 'g:i a' );
		return wp_date( 'Y-m-d', $at ) === wp_date( 'Y-m-d' )
			? (string) wp_date( $time, $at )
			: (string) wp_date( 'M j, ' . $time, $at );
	}

	/**
	 * @return array{key: string, name: string, ok: bool, message: string}
	 */
	private function healthRow( string $key, string $name, bool $ok, string $message ): array {
		return [
			'key'     => $key,
			'name'    => $name,
			'ok'      => $ok,
			'message' => $message,
		];
	}

	/** @return array{key: string, name: string, ok: bool, message: string} */
	private function cronHealth(): array {
		$next  = (int) wp_next_scheduled( Cron::DAILY_SYNC );
		$last  = (int) get_option( BackgroundSyncModule::LAST_RUN_OPTION, 0 );
		$bits  = [
			$last
				/* translators: %s: when the daily sync last ran, e.g. "2:00 am" */
				? sprintf( __( 'Last run %s', 'monstera' ), $this->moment( $last ) )
				: __( 'Not run yet', 'monstera' ),
			$next
				/* translators: %s: when the daily sync runs next, e.g. "2:00 am" */
				? sprintf( __( 'next %s', 'monstera' ), $this->moment( $next ) )
				: __( 'not scheduled', 'monstera' ),
		];
		$fresh = ! $last || time() - $last < 2 * DAY_IN_SECONDS;
		return $this->healthRow( 'cron', __( 'Scheduled tasks', 'monstera' ), $next && $fresh, implode( ' · ', $bits ) );
	}

	/** @return array{key: string, name: string, ok: bool, message: string} */
	private function storageHealth(): array {
		$root     = SecureStorage::rootPath();
		$writable = is_dir( $root ) && wp_is_writable( $root );
		$usage    = SecureStorage::usage();
		if ( ! is_dir( $root ) ) {
			$message = __( 'The storage folder is missing', 'monstera' );
		} elseif ( ! $writable ) {
			$message = __( 'The storage folder is not writable', 'monstera' );
		} else {
			$message  = SecureStorage::isProtected()
				? __( 'Protected folder', 'monstera' )
				: __( 'Folder without its deny file', 'monstera' );
			$message .= ' · ' . ( $usage
				/* translators: %s: a size, e.g. "4.2 GB" */
				? sprintf( __( '%s used', 'monstera' ), size_format( $usage['bytes'], $usage['bytes'] >= KB_IN_BYTES ? 1 : 0 ) ?: '0 B' )
				: __( 'size measured tonight', 'monstera' ) );
		}
		return $this->healthRow( 'secure-storage', __( 'Secure file storage', 'monstera' ), $writable && SecureStorage::isProtected(), $message );
	}

	/** @return array{key: string, name: string, ok: bool, message: string} */
	private function emailHealth(): array {
		global $wpdb;
		$last = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the dashboard's own read of Monstera's log.
			$wpdb->prepare( 'SELECT delivered, sent_at FROM %i ORDER BY id DESC LIMIT 1', Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ) ),
			ARRAY_A
		);
		$name = __( 'Outgoing email', 'monstera' );
		if ( ! $last ) {
			return $this->healthRow( 'email', $name, true, __( 'Nothing sent yet', 'monstera' ) );
		}
		$at = (int) strtotime( $last['sent_at'] . ' UTC' );
		if ( '0' === (string) $last['delivered'] ) {
			$accepted = (string) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the dashboard's own read of Monstera's log.
				$wpdb->prepare( 'SELECT MAX(sent_at) FROM %i WHERE delivered = 1', Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ) )
			);
			return $this->healthRow(
				'email',
				$name,
				false,
				'' !== $accepted
					/* translators: 1: when the last email was attempted, 2: when one was last accepted for delivery */
					? sprintf( __( 'The last email failed %1$s; the last one accepted was %2$s', 'monstera' ), $this->moment( $at ), $this->moment( (int) strtotime( $accepted . ' UTC' ) ) )
					/* translators: %s: when the last email was attempted */
					: sprintf( __( 'The last email failed %s; none has been accepted yet', 'monstera' ), $this->moment( $at ) )
			);
		}
		/* translators: %s: when the last email was accepted for delivery */
		return $this->healthRow( 'email', $name, true, sprintf( __( 'Last delivered %s', 'monstera' ), $this->moment( $at ) ) );
	}

	/** @return array{key: string, name: string, ok: bool, message: string} */
	private function loginHealth(): array {
		$plugin = ( new Detector() )->loginProtection();
		return $this->healthRow(
			'login',
			__( 'Login protection', 'monstera' ),
			'' !== $plugin,
			'' !== $plugin
				/* translators: %s: a login-protection plugin's name, e.g. "Wordfence" */
				? sprintf( __( '%s is active', 'monstera' ), $plugin )
				: __( 'No login protection plugin found. One that limits sign-in attempts is worth adding.', 'monstera' )
		);
	}

	/** @return array{key: string, name: string, ok: bool, message: string} */
	private function versionsHealth(): array {
		$wp      = (string) get_bloginfo( 'version' );
		$message = sprintf(
			/* translators: 1: the PHP version, 2: the WordPress version */
			__( 'PHP %1$s · WordPress %2$s', 'monstera' ),
			PHP_VERSION,
			$wp
		);
		$reasons = [];
		// PHP 8.1 left security support on 2025-12-31.
		if ( version_compare( PHP_VERSION, '8.2', '<' ) ) {
			$reasons[] = __( 'this PHP no longer gets security fixes', 'monstera' );
		}
		$updates = get_site_transient( 'update_core' );
		foreach ( (array) ( is_object( $updates ) ? ( $updates->updates ?? [] ) : [] ) as $offer ) {
			if ( is_object( $offer ) && 'upgrade' === ( $offer->response ?? '' ) ) {
				$reasons[] = __( 'a WordPress update is waiting', 'monstera' );
				break;
			}
		}
		if ( $reasons ) {
			$message .= ' · ' . implode( ', ', $reasons );
		}
		return $this->healthRow( 'versions', __( 'PHP and WordPress', 'monstera' ), ! $reasons, $message );
	}
}
