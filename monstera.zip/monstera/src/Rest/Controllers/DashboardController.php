<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use DateTimeZone;
use Monstera\Admin\Shell;
use Monstera\BackgroundSync\Cron;
use Monstera\Alerts\Expiry;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\PostType as AlertPostType;
use Monstera\Content\Meta as ContentMeta;
use Monstera\BackgroundSync\BackgroundSyncModule;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\SiteDay;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Core\Database\Schema;
use Monstera\Core\Modules;
use Monstera\Core\SecureStorage;
use Monstera\Integrations\Detector;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Reporting\ActivityFeed;
use Monstera\Support\Repository as SupportRepository;
use WP_Query;

defined( 'ABSPATH' ) || exit;

/**
 * Backs the admin dashboard.
 *
 * Returns a single payload describing what needs attention, recent activity,
 * and system health. Designed to make the dashboard render in one round-trip.
 */
final class DashboardController extends BaseController {

	public function register(): void {
		register_rest_route(
			$this->restNamespace,
			'/dashboard/summary',
			[
				'methods'             => 'GET',
				'permission_callback' => $this->permissionManage(),
				'callback'            => [ $this, 'summary' ],
			]
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	public function summary(): array {
		return [
			'tasks'           => $this->tasks(),
			'recent_activity' => $this->recentActivity(),
			'health'          => $this->health(),
			'health_checked'  => (string) wp_date( (string) get_option( 'time_format', 'g:i a' ) ),
		];
	}

	/**
	 * What needs the admin's attention (comp 90): one row per kind, each with
	 * a line, a sub-line and one action. Kinds tied to a module leave with it.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function tasks(): array {
		$tasks = [];
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			$tasks[] = $this->discoveryTask();
		}
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			$tasks[] = $this->supportTask();
		}
		array_push( $tasks, ...$this->renewalTasks() );
		if ( Modules::isActive( Modules::ALERTS ) ) {
			$tasks[] = $this->alertsTask();
		}
		$tasks[] = $this->pendingContentTask();
		return array_values( array_filter( $tasks ) );
	}

	/**
	 * Up to three names, then "and N more".
	 *
	 * @param array<int, string> $names The names, first three shown.
	 */
	private function andMore( array $names, int $total ): string {
		$shown = implode( ', ', array_slice( $names, 0, 3 ) );
		$more  = $total - min( 3, count( $names ) );
		return $more > 0
			/* translators: 1: a list of names, 2: how many more there are */
			? sprintf( _n( '%1$s and %2$d more', '%1$s and %2$d more', $more, 'monstera' ), $shown, $more )
			: $shown;
	}

	/** "Friday" within the last week, "Sep 12" before that. */
	private function dayLabel( int $at ): string {
		return time() - $at < 6 * DAY_IN_SECONDS ? (string) wp_date( 'l', $at ) : (string) wp_date( 'M j', $at );
	}

	/** @return array<string, string>|null */
	private function discoveryTask(): ?array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one grouped read for the dashboard.
			$wpdb->prepare(
				'SELECT project_id, MAX(submitted_at) AS submitted_at FROM %i GROUP BY project_id ORDER BY submitted_at DESC',
				Schema::tableName( Schema::TABLE_PROJECT_INTAKE )
			),
			ARRAY_A
		);
		// Answers from the last seven days: submitting moves a project on to
		// In progress by default (FILTER_AUTO_ADVANCE_AFTER_INTAKE), so the
		// stage alone would hide exactly the answers that want reading.
		$waiting = [];
		foreach ( (array) $rows as $row ) {
			$id = (int) $row['project_id'];
			$at = (int) strtotime( $row['submitted_at'] . ' UTC' );
			if ( 'publish' === get_post_status( $id ) && time() - $at <= 7 * DAY_IN_SECONDS ) {
				$waiting[] = [ $id, $at ];
			}
		}
		if ( ! $waiting ) {
			return null;
		}
		[ $first, $at ] = $waiting[0];
		$orgId          = (int) get_post_meta( $first, ProjectMeta::KEY_ORG_ID, true );
		$parts          = array_values( array_filter( [ $this->title( $first ), $orgId ? $this->title( $orgId ) : '' ] ) );
		/* translators: %s: a weekday or date, e.g. "Friday" */
		$parts[] = sprintf( __( 'submitted %s', 'monstera' ), $this->dayLabel( $at ) );
		$count   = count( $waiting );
		$detail  = implode( ' · ', $parts );
		if ( $count > 1 ) {
			/* translators: 1: the first project's line, 2: how many more projects */
			$detail = sprintf( _n( '%1$s, and %2$d more project', '%1$s, and %2$d more projects', $count - 1, 'monstera' ), $detail, $count - 1 );
		}
		return [
			'id'           => 'discovery',
			/* translators: %d: number of projects whose discovery answers are in */
			'title'        => sprintf( _n( '%d discovery response to review', '%d discovery responses to review', $count, 'monstera' ), $count ),
			'detail'       => $detail,
			'url'          => 1 === $count ? admin_url( 'admin.php?page=monstera-projects&id=' . $first ) : admin_url( 'admin.php?page=monstera-projects' ),
			'action_label' => __( 'Review', 'monstera' ),
		];
	}

	/** @return array<string, string>|null */
	private function supportTask(): ?array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the dashboard's own read.
			$wpdb->prepare(
				'SELECT ref, org_id FROM %i WHERE status = %s AND created_at < %s ORDER BY created_at ASC',
				Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
				SupportRepository::STATUS_OPEN,
				gmdate( 'Y-m-d H:i:s', time() - 2 * DAY_IN_SECONDS )
			),
			ARRAY_A
		);
		if ( ! $rows ) {
			return null;
		}
		$names = [];
		foreach ( array_slice( (array) $rows, 0, 3 ) as $row ) {
			$names[] = (int) $row['org_id']
				/* translators: 1: a support reference, 2: an organization's name */
				? sprintf( __( '%1$s (%2$s)', 'monstera' ), $row['ref'], $this->title( (int) $row['org_id'] ) )
				: (string) $row['ref'];
		}
		$count = count( (array) $rows );
		return [
			'id'           => 'support',
			/* translators: %d: number of open support requests older than two days */
			'title'        => sprintf( _n( '%d support request open more than two days', '%d support requests open more than two days', $count, 'monstera' ), $count ),
			'detail'       => $this->andMore( $names, $count ),
			'url'          => admin_url( 'admin.php?page=monstera-support' ),
			'action_label' => __( 'Open inbox', 'monstera' ),
		];
	}

	/**
	 * One row per active organization renewing within 30 days, soonest first.
	 *
	 * @return array<int, array<string, string>>
	 */
	private function renewalTasks(): array {
		$soon  = [];
		$ends  = [];
		$today = SiteDay::today();
		$orgs  = new OrgRepository();
		foreach ( $orgs->all() as $org ) {
			// Through the repository, which reads the status from the post: a
			// published organization is active.
			if ( ! $orgs->isActive( $org->ID ) ) {
				continue;
			}
			// The site's days to its last (Core\SiteDay): today on its last day,
			// wherever the site is, and the thirty days before it.
			$raw   = (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true );
			$since = SiteDay::daysSince( $raw, $today );
			if ( null !== $since && $since <= 0 && -$since <= 30 ) {
				$soon[ $org->ID ] = -$since;
				$ends[ $org->ID ] = (int) strtotime( SiteDay::ymd( $raw ) . ' UTC' );
			}
		}
		asort( $soon );
		$tasks = [];
		foreach ( $soon as $orgId => $days ) {
			$name  = $this->title( $orgId );
			$title = match ( true ) {
				/* translators: %s: an organization's name */
				$days <= 0  => sprintf( __( '%s renews today', 'monstera' ), $name ),
				/* translators: %s: an organization's name */
				1 === $days => sprintf( __( '%s renews tomorrow', 'monstera' ), $name ),
				/* translators: 1: an organization's name, 2: number of days */
				default     => sprintf( _n( '%1$s renews in %2$d day', '%1$s renews in %2$d days', $days, 'monstera' ), $name, $days ),
			};
			$tasks[] = [
				'id'           => 'renewal-' . $orgId,
				'title'        => $title,
				/* translators: %s: the membership's end date, e.g. "Oct 3" */
				'detail'       => sprintf( __( 'Expires %s', 'monstera' ), wp_date( 'M j', $ends[ $orgId ], new DateTimeZone( 'UTC' ) ) ),
				'url'          => admin_url( 'admin.php?page=monstera-organizations&id=' . $orgId ),
				'action_label' => __( 'Open org', 'monstera' ),
			];
		}
		return $tasks;
	}

	/** @return array<string, string>|null */
	private function alertsTask(): ?array {
		$query    = new WP_Query(
			[
				'post_type'      => AlertPostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);
		$expiring = [];
		foreach ( $query->posts as $id ) {
			$at = Expiry::timestamp( (string) get_post_meta( (int) $id, AlertMeta::KEY_EXPIRES_AT, true ) );
			if ( $at && $at > time() && $at - time() <= DAY_IN_SECONDS ) {
				$expiring[ (int) $id ] = $at;
			}
		}
		if ( ! $expiring ) {
			return null;
		}
		asort( $expiring );
		$first = (int) array_key_first( $expiring );
		$count = count( $expiring );
		$line  = $this->title( $first ) . ' · ' . wp_date( (string) get_option( 'time_format', 'g:i a' ), $expiring[ $first ] );
		return [
			'id'           => 'alerts',
			/* translators: %d: number of live alerts that expire in the next 24 hours */
			'title'        => sprintf( _n( '%d alert expires within a day', '%d alerts expire within a day', $count, 'monstera' ), $count ),
			'detail'       => $count > 1
				/* translators: 1: the first alert's line, 2: how many more alerts */
				? sprintf( _n( '%1$s, and %2$d more', '%1$s, and %2$d more', $count - 1, 'monstera' ), $line, $count - 1 )
				: $line,
			'url'          => 1 === $count ? admin_url( 'admin.php?page=monstera-alerts&id=' . $first ) : admin_url( 'admin.php?page=monstera-alerts' ),
			'action_label' => __( 'Extend or dismiss', 'monstera' ),
		];
	}

	/** @return array<string, string>|null */
	private function pendingContentTask(): ?array {
		$pending = new WP_Query(
			[
				'post_type'      => ContentPostType::SLUG,
				'post_status'    => [ 'publish', 'draft', 'pending', 'future' ],
				'meta_key'       => ContentMeta::KEY_VISIBILITY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one indexed key, counted once per dashboard load.
				'meta_value'     => ContentMeta::VISIBILITY_PENDING, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
				'posts_per_page' => 1,
				'fields'         => 'ids',
			]
		);
		$count   = (int) $pending->found_posts;
		if ( 0 === $count ) {
			return null;
		}
		return [
			'id'           => 'pending-content',
			/* translators: %d: number of content items whose visibility is Pending review */
			'title'        => sprintf( _n( '%d item is waiting for review', '%d items are waiting for review', $count, 'monstera' ), $count ),
			'detail'       => __( 'They reach members once you mark them Published.', 'monstera' ),
			'url'          => admin_url( 'admin.php?page=monstera-content' ),
			'action_label' => __( 'Open', 'monstera' ),
		];
	}

	/** A post's title as plain text. */
	private function title( int $postId ): string {
		return html_entity_decode( (string) get_post_field( 'post_title', $postId ), ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private function recentActivity(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'monstera_activity_log';
		// Guard against a half-run migration: if the table isn't present, return
		// empty rather than emitting a DB error and a foreach-on-null warning.
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			return [];
		}
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY occurred_at DESC LIMIT 8', $table ), ARRAY_A );

		return ActivityFeed::shape( (array) $rows );
	}

	/**
	 * System health (comp 90): five rows about the site, each with a
	 * sub-line and OK or Check, then three about its people (People-model
	 * track, FR2 and FR4; At-a-glance track, FR4): the organizations with no
	 * admin, the active organizations with no account lead and the projects
	 * with no lead. Nothing here walks the disk or calls out: the storage
	 * size is the daily sync's measurement and the update check is
	 * WordPress's own. The projects row leaves with its module, and the
	 * organizations row with the Organizations page: a program of
	 * individuals with no organizations is not told that each has an admin.
	 *
	 * @return array<int, array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>}>
	 */
	private function health(): array {
		$rows = [
			$this->cronHealth(),
			$this->storageHealth(),
			$this->emailHealth(),
			$this->loginHealth(),
			$this->versionsHealth(),
		];
		if ( ! Shell::hidesOrganizationPages() ) {
			$rows[] = $this->adminsHealth();
			$rows[] = $this->accountLeadsHealth();
		}
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			$rows[] = $this->leadsHealth();
		}
		return $rows;
	}

	/**
	 * Active organizations without an account lead (At-a-glance track,
	 * FR4): none named yet, or the lead's assignment ended. Which
	 * organizations are asked about is the repository's to say
	 * (Organizations\Repository::withoutAccountLead()): the active ones
	 * alone, where the admins row above asks the suspended too. An admin is
	 * what an organization needs to run its own people, suspended or not; a
	 * lead is a staffing to-do, and a lapsed client is not one to staff
	 * now. The row leaves with the Organizations page, as the admins row
	 * does, and names every organization it finds, as that row does.
	 *
	 * @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>}
	 */
	private function accountLeadsHealth(): array {
		return $this->missingRow(
			'orgs-without-account-lead',
			__( 'Organizations without an account lead', 'monstera' ),
			__( 'Every active organization has an account lead', 'monstera' ),
			( new OrgRepository() )->withoutAccountLead(),
			'monstera-organizations'
		);
	}

	/** A time today ("2:00 am"), or a date and time on another day. */
	private function moment( int $at ): string {
		$time = (string) get_option( 'time_format', 'g:i a' );
		return wp_date( 'Y-m-d', $at ) === wp_date( 'Y-m-d' )
			? (string) wp_date( $time, $at )
			: (string) wp_date( 'M j, ' . $time, $at );
	}

	/**
	 * One row. The message is the whole sub-line as plain text; a row that
	 * names records also carries them as links, in the order it names them,
	 * and every other row carries none.
	 *
	 * @param list<array{text: string, url: string}> $links
	 * @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>}
	 */
	private function healthRow( string $key, string $name, bool $ok, string $message, array $links = [] ): array {
		return [
			'key'     => $key,
			'name'    => $name,
			'ok'      => $ok,
			'message' => $message,
			'links'   => $links,
		];
	}

	/**
	 * A row about records that are missing someone: OK with its sentence
	 * when there are none, otherwise Check with each one by name, linked to
	 * its detail page. Every one is named, as the spec asks: the row is how
	 * the team finds them.
	 *
	 * @param list<int> $postIds The records, in the order to name them.
	 * @param string    $page    The admin page that opens one.
	 * @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>}
	 */
	private function missingRow( string $key, string $name, string $none, array $postIds, string $page ): array {
		$links = [];
		foreach ( $postIds as $postId ) {
			$links[] = [
				'text' => $this->title( $postId ),
				'url'  => admin_url( 'admin.php?page=' . $page . '&id=' . $postId ),
			];
		}
		return $this->healthRow( $key, $name, ! $links, $links ? implode( ', ', array_column( $links, 'text' ) ) : $none, $links );
	}

	/**
	 * Organizations without an admin (People-model track, FR2). An
	 * organization may have none: one the team has just created has nobody
	 * in it yet, and one whose people were invited as managers and members
	 * has nobody who can make a manager. Every organization that is not
	 * archived is asked about, whoever is in it: a suspended one is still a
	 * client. A staff assignment is not an admin. The rosters are read
	 * together (Roster::primeOrgs()), so the row costs the same for eighty
	 * organizations as for eight, and the organizations are listed by the
	 * query the renewal rows made, which WordPress answers from its cache
	 * the second time.
	 *
	 * @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>}
	 */
	private function adminsHealth(): array {
		$orgs  = new OrgRepository();
		$asked = [];
		foreach ( $orgs->all() as $org ) {
			if ( OrgMeta::STATUS_ARCHIVED !== $orgs->status( $org->ID ) ) {
				$asked[] = (int) $org->ID;
			}
		}
		Roster::primeOrgs( $asked );
		$without = [];
		foreach ( $asked as $orgId ) {
			if ( ! Roster::memberIds( $orgId, [ Roster::TIER_ADMIN ] ) ) {
				$without[] = $orgId;
			}
		}
		return $this->missingRow(
			'orgs-without-admin',
			__( 'Organizations without an admin', 'monstera' ),
			__( 'Every organization has an admin', 'monstera' ),
			$without,
			'monstera-organizations'
		);
	}

	/**
	 * Projects without a project lead (People-model track, FR4): none chosen yet, or
	 * the lead has left the team. Which projects are asked about is the
	 * repository's to say (Projects\Repository::withoutLead()).
	 *
	 * @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>}
	 */
	private function leadsHealth(): array {
		$without = [];
		foreach ( ( new ProjectRepository() )->withoutLead() as $project ) {
			$without[] = (int) $project->ID;
		}
		return $this->missingRow(
			'projects-without-lead',
			__( 'Projects without a project lead', 'monstera' ),
			__( 'Every open project has a project lead', 'monstera' ),
			$without,
			'monstera-projects'
		);
	}

	/** @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>} */
	private function cronHealth(): array {
		$next  = (int) wp_next_scheduled( Cron::DAILY_SYNC );
		$last  = (int) get_option( BackgroundSyncModule::LAST_RUN_OPTION, 0 );
		$bits  = [
			$last
				/* translators: %s: when the daily sync last ran, e.g. "2:00 am" */
				? sprintf( __( 'Last run %s', 'monstera' ), $this->moment( $last ) )
				: __( 'Not run yet', 'monstera' ),
			$next
				/* translators: %s: when the daily sync runs next, e.g. "2:00 am" */
				? sprintf( __( 'next %s', 'monstera' ), $this->moment( $next ) )
				: __( 'not scheduled', 'monstera' ),
		];
		$fresh = ! $last || time() - $last < 2 * DAY_IN_SECONDS;
		return $this->healthRow( 'cron', __( 'Scheduled tasks', 'monstera' ), $next && $fresh, implode( ' · ', $bits ) );
	}

	/** @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>} */
	private function storageHealth(): array {
		$root     = SecureStorage::rootPath();
		$writable = is_dir( $root ) && wp_is_writable( $root );
		$usage    = SecureStorage::usage();
		if ( ! is_dir( $root ) ) {
			$message = __( 'The storage folder is missing', 'monstera' );
		} elseif ( ! $writable ) {
			$message = __( 'The storage folder is not writable', 'monstera' );
		} else {
			$message  = SecureStorage::isProtected()
				? __( 'Protected folder', 'monstera' )
				: __( 'Folder without its deny file', 'monstera' );
			$message .= ' · ' . ( $usage
				/* translators: %s: a size, e.g. "4.2 GB" */
				? sprintf( __( '%s used', 'monstera' ), size_format( $usage['bytes'], $usage['bytes'] >= KB_IN_BYTES ? 1 : 0 ) ?: '0 B' )
				: __( 'size measured tonight', 'monstera' ) );
		}
		return $this->healthRow( 'secure-storage', __( 'Secure file storage', 'monstera' ), $writable && SecureStorage::isProtected(), $message );
	}

	/** @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>} */
	private function emailHealth(): array {
		global $wpdb;
		$last = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the dashboard's own read of Monstera's log.
			$wpdb->prepare( 'SELECT delivered, sent_at FROM %i ORDER BY id DESC LIMIT 1', Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ) ),
			ARRAY_A
		);
		$name = __( 'Outgoing email', 'monstera' );
		if ( ! $last ) {
			return $this->healthRow( 'email', $name, true, __( 'Nothing sent yet', 'monstera' ) );
		}
		$at = (int) strtotime( $last['sent_at'] . ' UTC' );
		if ( '0' === (string) $last['delivered'] ) {
			$accepted = (string) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the dashboard's own read of Monstera's log.
				$wpdb->prepare( 'SELECT MAX(sent_at) FROM %i WHERE delivered = 1', Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ) )
			);
			return $this->healthRow(
				'email',
				$name,
				false,
				'' !== $accepted
					/* translators: 1: when the last email was attempted, 2: when one was last accepted for delivery */
					? sprintf( __( 'The last email failed %1$s; the last one accepted was %2$s', 'monstera' ), $this->moment( $at ), $this->moment( (int) strtotime( $accepted . ' UTC' ) ) )
					/* translators: %s: when the last email was attempted */
					: sprintf( __( 'The last email failed %s; none has been accepted yet', 'monstera' ), $this->moment( $at ) )
			);
		}
		/* translators: %s: when the last email was accepted for delivery */
		return $this->healthRow( 'email', $name, true, sprintf( __( 'Last delivered %s', 'monstera' ), $this->moment( $at ) ) );
	}

	/** @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>} */
	private function loginHealth(): array {
		$plugin = ( new Detector() )->loginProtection();
		return $this->healthRow(
			'login',
			__( 'Login protection', 'monstera' ),
			'' !== $plugin,
			'' !== $plugin
				/* translators: %s: a login-protection plugin's name, e.g. "Wordfence" */
				? sprintf( __( '%s is active', 'monstera' ), $plugin )
				: __( 'No login protection plugin found. One that limits sign-in attempts is worth adding.', 'monstera' )
		);
	}

	/** @return array{key: string, name: string, ok: bool, message: string, links: list<array{text: string, url: string}>} */
	private function versionsHealth(): array {
		$wp      = (string) get_bloginfo( 'version' );
		$message = sprintf(
			/* translators: 1: the PHP version, 2: the WordPress version */
			__( 'PHP %1$s · WordPress %2$s', 'monstera' ),
			PHP_VERSION,
			$wp
		);
		$reasons = [];
		// PHP 8.1 left security support on 2025-12-31.
		if ( version_compare( PHP_VERSION, '8.2', '<' ) ) {
			$reasons[] = __( 'this PHP no longer gets security fixes', 'monstera' );
		}
		$updates = get_site_transient( 'update_core' );
		foreach ( (array) ( is_object( $updates ) ? ( $updates->updates ?? [] ) : [] ) as $offer ) {
			if ( is_object( $offer ) && 'upgrade' === ( $offer->response ?? '' ) ) {
				$reasons[] = __( 'a WordPress update is waiting', 'monstera' );
				break;
			}
		}
		if ( $reasons ) {
			$message .= ' · ' . implode( ', ', $reasons );
		}
		return $this->healthRow( 'versions', __( 'PHP and WordPress', 'monstera' ), ! $reasons, $message );
	}
}
