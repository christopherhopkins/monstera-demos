<?php
declare(strict_types=1);

namespace Monstera\Rest\Controllers;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Members\UserMeta;
use Monstera\Subgroups\Meta;
use Monstera\Subgroups\PostType;
use Monstera\Subgroups\Repository;
use WP_Error;
use WP_Query;
use WP_REST_Request;

final class SubgroupsController extends BaseController {

	public function register(): void {
		// Listing is readable by any portal author (it backs the sub-group picker
		// used when scoping content); creating and editing sub-groups is org
		// infrastructure — org managers and admins only, never leaders.
		register_rest_route(
			$this->restNamespace,
			'/subgroups',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_AUTHOR_PORTAL ),
					'callback'            => [ $this, 'index' ],
				],
				[
					'methods'             => 'POST',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'create' ],
				],
			]
		);

		register_rest_route(
			$this->restNamespace,
			'/subgroups/(?P<id>\d+)',
			[
				[
					'methods'             => 'GET',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'show' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'PUT',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'update' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'permission_callback' => $this->permissionCap( Capabilities::CAP_MANAGE_OWN_ORG ),
					'callback'            => [ $this, 'destroy' ],
					'args'                => [
						'id' => [
							'type'     => 'integer',
							'required' => true,
						],
					],
				],
			]
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>}
	 */
	public function index( WP_REST_Request $request ): array {
		$orgFilter        = self::parseIdList( $request->get_param( 'org_ids' ) );
		$standaloneFilter = self::parseIdList( $request->get_param( 'standalone_member_ids' ) );

		$repo = new Repository();
		$q    = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			]
		);

		$scope = $this->scope();
		$out   = [];
		foreach ( $q->posts as $post ) {
			$orgId = (int) get_post_meta( $post->ID, Meta::KEY_ORG_ID, true );
			$memId = (int) get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBER_ID, true );

			// Delegated authors only ever see sub-groups under their own org (a
			// group with no organization is never theirs).
			if ( ! $scope->isAdmin && ( $orgId <= 0 || $orgId !== $scope->orgId ) ) {
				continue;
			}

			// If either filter is provided, the subgroup must match at least
			// one of them. An empty filter set means "no constraint".
			if ( $orgFilter || $standaloneFilter ) {
				$matchesOrg        = $orgFilter && $orgId && in_array( $orgId, $orgFilter, true );
				$matchesStandalone = $standaloneFilter && $memId && in_array( $memId, $standaloneFilter, true );
				if ( ! $matchesOrg && ! $matchesStandalone ) {
					continue;
				}
			}

			$leaderId         = (int) get_post_meta( $post->ID, Meta::KEY_LEADER, true );
			$leader           = $leaderId ? get_userdata( $leaderId ) : null;
			$standaloneMember = $memId ? get_userdata( $memId ) : null;
			$out[]            = [
				'id'                     => $post->ID,
				'name'                   => get_the_title( $post ),
				'org_id'                 => $orgId,
				'org_name'               => $orgId ? get_the_title( $orgId ) : '',
				'standalone_member_id'   => $memId,
				'standalone_member_name' => $standaloneMember ? $standaloneMember->display_name : '',
				'leader_id'              => $leaderId,
				'leader_name'            => $leader ? $leader->display_name : '',
				'is_private'             => (bool) get_post_meta( $post->ID, Meta::KEY_IS_PRIVATE, true ),
				'cadence'                => (string) get_post_meta( $post->ID, Meta::KEY_MEETING_CADENCE, true ),
				'member_count'           => count( $repo->memberIds( $post->ID ) ),
				'edit_url'               => admin_url( 'admin.php?page=monstera-subgroups&id=' . $post->ID ),
			];
		}
		return [ 'items' => $out ];
	}

	/**
	 * Normalize a query param that may arrive as an array, a comma-separated
	 * string, or a single int.
	 *
	 * @param mixed $raw
	 * @return int[]
	 */
	private static function parseIdList( $raw ): array {
		if ( null === $raw || '' === $raw ) {
			return [];
		}
		if ( is_array( $raw ) ) {
			$parts = $raw;
		} elseif ( is_string( $raw ) && str_contains( $raw, ',' ) ) {
			$parts = explode( ',', $raw );
		} else {
			$parts = [ $raw ];
		}
		$ints = array_map( 'absint', $parts );
		return array_values( array_filter( $ints ) );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function show( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Sub-group not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwnSubgroup( $id );
		if ( $guard ) {
			return $guard;
		}
		return $this->shape( $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function create( WP_REST_Request $request ): array|WP_Error {
		$name = trim( sanitize_text_field( (string) ( $request['name'] ?? '' ) ) );
		if ( '' === $name ) {
			return $this->invalidField( 'name', __( 'Give the sub-group a name.', 'monstera' ) );
		}
		$refused = $this->checkMemberScope( $request, 0 ) ?? $this->checkLeader( $request, 0 );
		if ( $refused ) {
			return $refused;
		}

		$id = wp_insert_post(
			[
				'post_type'   => PostType::SLUG,
				'post_title'  => $name,
				'post_status' => 'publish',
				'post_author' => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$this->applyMutations( (int) $id, $request );
		$this->stampEditor( (int) $id );
		return $this->shape( (int) $id );
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function update( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Sub-group not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwnSubgroup( $id );
		if ( $guard ) {
			return $guard;
		}

		// Every refusal comes before the first write.
		if ( $request->has_param( 'name' ) && '' === trim( sanitize_text_field( (string) $request['name'] ) ) ) {
			return $this->invalidField( 'name', __( 'Give the sub-group a name.', 'monstera' ) );
		}
		$refused = $this->checkMemberScope( $request, $id ) ?? $this->checkLeader( $request, $id );
		if ( $refused ) {
			return $refused;
		}

		$core = [ 'ID' => $id ];
		if ( $request->has_param( 'name' ) ) {
			$core['post_title'] = trim( sanitize_text_field( (string) $request['name'] ) );
		}
		if ( $request->has_param( 'description' ) ) {
			$core['post_content'] = wp_kses_post( (string) $request['description'] );
		}
		if ( count( $core ) > 1 ) {
			wp_update_post( $core );
		}

		$this->applyMutations( $id, $request );
		$this->stampEditor( $id );
		return $this->shape( $id );
	}

	/**
	 * An admin naming a member of another organization is refused (422 on
	 * member_ids) rather than filtered: the picker offers only the parent
	 * organization's people, so an outsider here is a mistake worth saying.
	 * Managers keep their silent filter in applyMutations().
	 */
	private function checkMemberScope( WP_REST_Request $request, int $id ): ?WP_Error {
		if ( ! $request->has_param( 'member_ids' ) || ! $this->scope()->isAdmin ) {
			return null;
		}
		$orgId = $request->has_param( 'org_id' )
			? absint( $request['org_id'] )
			: (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		if ( $orgId <= 0 ) {
			return null;
		}
		foreach ( array_map( 'absint', (array) $request['member_ids'] ) as $userId ) {
			if ( UserMeta::associatedOrg( $userId ) !== $orgId ) {
				$user = get_userdata( $userId );
				return $this->invalidField(
					'member_ids',
					sprintf(
						/* translators: 1: a member's name, 2: the sub-group's organization */
						__( '%1$s is not in %2$s. Only its members can join this sub-group.', 'monstera' ),
						$user ? UserMeta::fullName( $user ) : __( 'That person', 'monstera' ),
						html_entity_decode( (string) get_post_field( 'post_title', $orgId ), ENT_QUOTES, 'UTF-8' )
					)
				);
			}
		}
		return null;
	}

	/**
	 * The leader is one of the group (comp 123's leader select offers only
	 * its members): a 422 naming the field when a save makes someone else
	 * lead, or takes the leader out while they still lead. A save that
	 * changes neither the leader nor the members passes, so an older
	 * leader who is not a member does not block other edits.
	 */
	private function checkLeader( WP_REST_Request $request, int $id ): ?WP_Error {
		if ( ! $request->has_param( 'leader_id' ) && ! $request->has_param( 'member_ids' ) ) {
			return null;
		}
		// A save that names no leader keeps the one the group has.
		$leaderId = $request->has_param( 'leader_id' )
			? absint( $request['leader_id'] )
			: ( $id ? (int) get_post_meta( $id, Meta::KEY_LEADER, true ) : 0 );
		if ( 0 === $leaderId ) {
			return null;
		}
		$current = $id ? array_map( 'intval', ( new Repository() )->memberIds( $id ) ) : [];
		$members = $request->has_param( 'member_ids' )
			? array_values( array_unique( array_filter( array_map( 'absint', (array) $request['member_ids'] ) ) ) )
			: $current;
		sort( $current );
		$sorted = $members;
		sort( $sorted );
		$changed = (int) get_post_meta( $id, Meta::KEY_LEADER, true ) !== $leaderId || $sorted !== $current;
		if ( ! $changed || in_array( $leaderId, $members, true ) ) {
			return null;
		}
		$user = get_userdata( $leaderId );
		$name = $user ? UserMeta::fullName( $user ) : __( 'That person', 'monstera' );
		return $this->invalidField(
			'leader_id',
			$request->has_param( 'leader_id' )
				/* translators: %s: a person's name */
				? sprintf( __( '%s is not in this sub-group. Choose the leader from its members.', 'monstera' ), $name )
				/* translators: %s: a person's name */
				: sprintf( __( '%s leads this sub-group. Choose another leader before taking them out.', 'monstera' ), $name )
		);
	}

	/**
	 * The sidebar's counts (comp 123): the content scoped to the group (as
	 * the Content list shows it) and its members' sign-ins this week.
	 *
	 * @param list<int> $memberIds
	 * @return array{content: int, logins_7d: int|null}
	 */
	private function facts( int $id, array $memberIds ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- counts from Monstera's own tables, read once per detail load.
		$content = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i cs INNER JOIN {$wpdb->posts} p ON p.ID = cs.content_id WHERE cs.subgroup_id = %d AND p.post_status IN ('publish', 'draft', 'pending')",
				Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS ),
				$id
			)
		);
		// Sign-ins are logged while Reporting is on.
		$logins = \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::REPORTING ) ? 0 : null;
		if ( $memberIds && null !== $logins ) {
			$logins = (int) $wpdb->get_var(
				$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per member id, built beside the query.
					'SELECT COUNT(*) FROM %i WHERE event_type = %s AND occurred_at >= %s AND user_id IN (' . implode( ',', array_fill( 0, count( $memberIds ), '%d' ) ) . ')',
					Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
					'login',
					gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS ),
					...$memberIds
				)
			);
		}
		// phpcs:enable
		return [
			'content'   => $content,
			'logins_7d' => $logins,
		];
	}

	private function applyMutations( int $id, WP_REST_Request $request ): void {
		$scope = $this->scope();

		// Parent is either an org OR a standalone member, mutually exclusive.
		// Delegated managers are pinned to their own org and can never parent a
		// sub-group elsewhere or to a standalone member.
		if ( $scope->isAdmin ) {
			if ( $request->has_param( 'org_id' ) ) {
				$orgId = absint( $request['org_id'] );
				if ( $orgId > 0 ) {
					update_post_meta( $id, Meta::KEY_ORG_ID, $orgId );
					delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
				} else {
					delete_post_meta( $id, Meta::KEY_ORG_ID );
				}
			}
			if ( $request->has_param( 'standalone_member_id' ) ) {
				$memId = absint( $request['standalone_member_id'] );
				if ( $memId > 0 ) {
					update_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, $memId );
					delete_post_meta( $id, Meta::KEY_ORG_ID );
				} else {
					delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
				}
			}
		} elseif ( $scope->orgId > 0 ) {
			update_post_meta( $id, Meta::KEY_ORG_ID, $scope->orgId );
			delete_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID );
		}

		// Leader appointment. A leader must be a member of the sub-group's own
		// org; appointing them grants the portal authoring cap dynamically (via
		// Capabilities::grantLeaderCap), so the appointee can immediately author
		// for this sub-group. Managers are confined to their own org's members.
		if ( $request->has_param( 'leader_id' ) ) {
			$leaderId = absint( $request['leader_id'] );
			$ownerOrg = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
			if ( $leaderId > 0 && ( $scope->isAdmin || UserMeta::associatedOrg( $leaderId ) === $ownerOrg ) ) {
				update_post_meta( $id, Meta::KEY_LEADER, $leaderId );
			} elseif ( 0 === $leaderId ) {
				delete_post_meta( $id, Meta::KEY_LEADER );
			}
		}

		if ( $request->has_param( 'is_private' ) ) {
			update_post_meta( $id, Meta::KEY_IS_PRIVATE, self::flag( $request['is_private'] ) );
		}
		if ( $request->has_param( 'meeting_cadence' ) ) {
			update_post_meta( $id, Meta::KEY_MEETING_CADENCE, sanitize_text_field( (string) $request['meeting_cadence'] ) );
		}
		if ( $request->has_param( 'formed_on' ) ) {
			update_post_meta( $id, Meta::KEY_FORMED_ON, sanitize_text_field( (string) $request['formed_on'] ) );
		}
		if ( $request->has_param( 'member_ids' ) ) {
			$wanted = array_map( 'absint', (array) $request['member_ids'] );
			// Managers may only add members of their own org to a sub-group.
			if ( ! $scope->isAdmin ) {
				$wanted = array_values(
					array_filter(
						$wanted,
						static fn ( int $uid ) => UserMeta::associatedOrg( $uid ) === $scope->orgId
					)
				);
			}
			$this->syncMembers( $id, $wanted );
		}
	}

	/**
	 * @return array<string, mixed>|WP_Error
	 */
	public function destroy( WP_REST_Request $request ): array|WP_Error {
		$id   = (int) $request['id'];
		$post = get_post( $id );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return new WP_Error( 'monstera_not_found', __( 'Sub-group not found.', 'monstera' ), [ 'status' => 404 ] );
		}
		$guard = $this->requireOwnSubgroup( $id );
		if ( $guard ) {
			return $guard;
		}
		wp_trash_post( $id );
		return [ 'ok' => true ];
	}

	/**
	 * Sub-groups are org infrastructure, not author-owned content: a manager may
	 * manage any sub-group under their own org (including ones seeded by an
	 * admin), so we scope by parent org rather than post_author. Admins pass.
	 */
	private function requireOwnSubgroup( int $id ): ?WP_Error {
		$sgOrg = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		if ( ! $this->actsWithinOwnOrg( $sgOrg ) ) {
			return new WP_Error(
				'monstera_forbidden',
				__( 'You can only manage sub-groups in your own organization.', 'monstera' ),
				[ 'status' => 403 ]
			);
		}
		return null;
	}

	/**
	 * @param array<int, int> $wanted
	 */
	private function syncMembers( int $subgroupId, array $wanted ): void {
		$repo    = new Repository();
		$current = $repo->memberIds( $subgroupId );
		$wanted  = array_values( array_unique( array_filter( $wanted ) ) );

		foreach ( array_diff( $current, $wanted ) as $userId ) {
			$repo->removeMember( $subgroupId, (int) $userId );
		}
		foreach ( array_diff( $wanted, $current ) as $userId ) {
			$repo->addMember( $subgroupId, (int) $userId );
		}
	}

	/**
	 * @return array<string, mixed>
	 */
	private function shape( int $id ): array {
		$post      = get_post( $id );
		$repo      = new Repository();
		$orgId     = (int) get_post_meta( $id, Meta::KEY_ORG_ID, true );
		$memId     = (int) get_post_meta( $id, Meta::KEY_STANDALONE_MEMBER_ID, true );
		$leaderId  = (int) get_post_meta( $id, Meta::KEY_LEADER, true );
		$leader    = $leaderId ? get_userdata( $leaderId ) : null;
		$memberIds = $repo->memberIds( $id );

		$standaloneMember = $memId ? get_userdata( $memId ) : null;

		return [
			'id'                     => $id,
			// As stored: the detail saves it back (the list's is texturized).
			'name'                   => (string) get_post_field( 'post_title', $id, 'raw' ),
			'description'            => (string) $post?->post_content,
			'org_id'                 => $orgId,
			'org_name'               => $orgId ? get_the_title( $orgId ) : '',
			'standalone_member_id'   => $memId,
			'standalone_member_name' => $standaloneMember ? $standaloneMember->display_name : '',
			'leader_id'              => $leaderId,
			'leader_name'            => $leader ? $leader->display_name : '',
			'is_private'             => (bool) get_post_meta( $id, Meta::KEY_IS_PRIVATE, true ),
			'meeting_cadence'        => (string) get_post_meta( $id, Meta::KEY_MEETING_CADENCE, true ),
			'formed_on'              => (string) get_post_meta( $id, Meta::KEY_FORMED_ON, true ),
			'member_ids'             => array_map( 'intval', $memberIds ),
			'member_count'           => count( $memberIds ),
			'edit_url'               => admin_url( 'admin.php?page=monstera-subgroups&id=' . $id ),
			'facts'                  => $this->facts( $id, array_values( array_map( 'intval', $memberIds ) ) ),
			'saved'                  => $this->savedStamp( $id ),
		];
	}
}
