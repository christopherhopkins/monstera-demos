<?php
declare(strict_types=1);

namespace Monstera\Rest;

use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * A validated bulk request for a list screen: one action, a bounded list
 * (at most MAX_IDS, else 422) of distinct positive ids, and free-form params the action may need.
 */
final class BulkRequest {

	public const MAX_IDS = 200;

	/**
	 * @param list<int>            $ids
	 * @param array<string, mixed> $params
	 */
	private function __construct(
		public readonly string $action,
		public readonly array $ids,
		public readonly array $params
	) {}

	/**
	 * @param list<string> $actions Actions the route supports.
	 */
	public static function fromRequest( WP_REST_Request $request, array $actions ): self|WP_Error {
		$action = sanitize_key( (string) $request->get_param( 'action' ) );
		if ( ! in_array( $action, $actions, true ) ) {
			return new WP_Error( 'monstera_bulk_unknown_action', __( 'Unknown bulk action.', 'monstera' ), [ 'status' => 422 ] );
		}

		$raw = $request->get_param( 'ids' );
		$ids = [];
		foreach ( is_array( $raw ) ? $raw : [] as $value ) {
			if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
				$id = (int) $value;
				if ( $id > 0 ) {
					$ids[ $id ] = $id;
				}
			}
		}
		$ids = array_values( $ids );
		if ( ! $ids ) {
			return new WP_Error( 'monstera_bulk_no_ids', __( 'Select at least one item.', 'monstera' ), [ 'status' => 422 ] );
		}
		// Lists offer up to 500 rows; refusing (rather than truncating) an
		// oversized selection keeps it on screen so the admin can narrow it.
		if ( count( $ids ) > self::MAX_IDS ) {
			return new WP_Error(
				'monstera_bulk_too_many',
				/* translators: %d: maximum number of ids one bulk request accepts. */
				sprintf( __( 'Select at most %d items.', 'monstera' ), self::MAX_IDS ),
				[ 'status' => 422 ]
			);
		}

		$params = $request->get_param( 'params' );

		return new self( $action, $ids, is_array( $params ) ? $params : [] );
	}
}
