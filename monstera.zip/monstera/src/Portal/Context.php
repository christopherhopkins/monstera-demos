<?php
/**
 * The context organization of a portal page (People-model track, FR5): the
 * organization the page is about, now that a person may belong to several.
 * The shell's chip, the Interactivity state, the guard's expired reason and
 * the blocked page all read it here so they cannot disagree. A hub is about
 * the organization in its URL, a project about its own, a content item
 * about one of its organizations the viewer belongs to, a support request
 * about the organization it was filed with, and every other
 * page about the viewer's primary organization: their first membership by
 * date, which is what "the member's organization" meant before the
 * memberships table.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Context {

	/**
	 * Per-request memo keyed by viewer, route and the route's parameter (the
	 * hub's slug, the item's id, the request's reference): the guard, the
	 * shell and the templates ask several times per page.
	 *
	 * @var array<string, int>
	 */
	private static array $cache = [];

	/** Forget the memo: in tests, where ids are reused across rolled-back transactions. */
	public static function flushCache(): void {
		self::$cache = [];
	}

	/**
	 * The organization a portal page is about, or 0 when it is about none.
	 * Route by route:
	 *
	 * - The hub (ROUTE_ORG): the organization whose slug is in the URL, when
	 *   it exists and the viewer is a member of it or staff. A hub the viewer
	 *   does not belong to is about nothing, so the guard's expired reason
	 *   never speaks for an organization that is not theirs.
	 * - A project (ROUTE_PROJECT): the project's organization, whichever way
	 *   the viewer reaches it, when they may open the project at all
	 *   (Projects\Repository::userCanAccess(), which passes staff). A project
	 *   they may not open is about nothing, as a hub that is not theirs is:
	 *   the shell and the page state print what is answered here, and the
	 *   page the guard blocks must not name whose project it would have been,
	 *   or walking the ids would list every organization that has one.
	 * - A support request (ROUTE_SUPPORT_REQUEST): the organization the
	 *   request was filed with, for the member who opened it, while they
	 *   still belong there and it still exists. A request filed with none,
	 *   one of an organization they have left or that is gone, and a
	 *   reference that is not theirs are all about what every other route is
	 *   about. The list and the form span every organization of theirs, so
	 *   they are among the other routes.
	 * - A content item (ROUTE_CONTENT): one of the item's organizations that
	 *   the viewer belongs to, in the three tiers of Organizations\Reach: a
	 *   live one first, neither ended nor suspended nor archived (the guard's
	 *   expired reason and the shell's suspended soft block both read this
	 *   organization, so a live one speaks for the item whenever the viewer
	 *   has one); then one that is merely unended, so an ended membership
	 *   never hides as expired an item the engine allows through a suspended
	 *   one; then the first in the viewer's membership order. For staff who
	 *   belong to none of them, the item's first organization. An item that
	 *   reaches the viewer some other way (a standalone member's) is about
	 *   none, and so is an item for everyone, whatever list it kept.
	 * - Every other route: the viewer's primary organization, their first
	 *   membership by date; 0 for a standalone member and for staff with no
	 *   memberships.
	 */
	public static function orgFor( WP_User $user, string $route ): int {
		$param = match ( $route ) {
			Routing::ROUTE_ORG => (string) get_query_var( Routing::PARAM_ORG ),
			Routing::ROUTE_CONTENT, Routing::ROUTE_PROJECT => (string) (int) get_query_var( Routing::PARAM_ID ),
			Routing::ROUTE_SUPPORT_REQUEST => strtoupper( (string) get_query_var( Routing::PARAM_REF ) ),
			default => '',
		};
		$key = (int) $user->ID . '|' . $route . '|' . $param;
		if ( ! array_key_exists( $key, self::$cache ) ) {
			self::$cache[ $key ] = self::resolve( $user, $route, $param );
		}
		return self::$cache[ $key ];
	}

	/**
	 * The person's primary organization among those on the site: the
	 * oldest membership of theirs whose organization is not in the trash,
	 * or 0. One in the trash grants nothing, so no page is about it and no
	 * bar names it (the review of the At-a-glance track, 2026-10-19).
	 */
	private static function primaryOnSite( int $userId ): int {
		return OrgRepository::primaryOnSite( $userId );
	}

	/**
	 * The organization the shell's chip names (the owner's walk-through at
	 * the Phase 5 checkpoint). On a page about one organization it is that
	 * one. A page about none still has a reader, who navigates by the bar:
	 * the hub or the project they were turned away from, an item shared with
	 * everyone. There the chip names what it names on their dashboard, their
	 * first organization, so the list a person in several opens from it is
	 * there to leave by. The answer is never drawn from the address: it is
	 * what orgFor() said of the page, or the reader's own, so a page that
	 * withholds an organization's name keeps it out of the bar as well. 0
	 * for a standalone member and for staff who belong to none, whose
	 * dashboard has no chip either.
	 *
	 * Only the bar asks here. What the page is about, the guard's expired
	 * reason, the page state and the suspended block all stay with orgFor():
	 * a page about no organization is still about none.
	 */
	public static function chipOrgFor( WP_User $user, string $route ): int {
		return self::orgFor( $user, $route ) ?: self::primaryOnSite( (int) $user->ID );
	}

	/**
	 * The organizations the viewer belongs to, oldest membership first:
	 * Roster::orgIdsOf(), here so a template reads one class.
	 *
	 * @return list<int>
	 */
	public static function orgIdsOf( WP_User $user ): array {
		return Roster::orgIdsOf( (int) $user->ID );
	}

	/**
	 * Whether the viewer holds exactly one membership of an organization on
	 * the site. The shell scopes its nav to that one hub; a person in several
	 * organizations keeps the cross-organization pages and the personal
	 * dashboard, and so does a person whose organizations are all in the
	 * trash, whose hubs are closed to them. One in the trash is not counted
	 * (the review of the At-a-glance track, 2026-10-19).
	 */
	public static function isSingleOrg( WP_User $user ): bool {
		return 1 === count( OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) ) );
	}

	/**
	 * The organizations the shell's switcher lists (People-model track, FR5):
	 * every one the viewer belongs to, oldest membership first, each with its
	 * name, its hub's address and the state a mark says beside the name,
	 * as the dashboard's bands read it: 'expired' for a membership that has
	 * ended, else 'suspended' for a suspended organization, else ''. Empty
	 * for anyone whose chip stays a plain link: a person in one organization
	 * or in none, and staff, whose chip names whichever hub they are
	 * reading, theirs or not. A membership whose organization is gone does
	 * not count, nor one whose organization is in the trash, its hub being
	 * closed to its own people; a suspended one, a draft, does. With fewer
	 * than two left to list there is nothing to choose between, and the answer is
	 * empty. The organizations and their meta are read together, so six cost
	 * what two do, and whatever the shell asks of them afterwards (which one
	 * is live, what the context one is called) is already in hand.
	 *
	 * @return list<array{id: int, name: string, url: string, state: string}>
	 */
	public static function switcherOrgs( WP_User $user ): array {
		if ( Capabilities::isStaff( $user ) ) {
			return [];
		}
		$orgIds = Roster::orgIdsOf( (int) $user->ID );
		if ( count( $orgIds ) < 2 ) {
			return [];
		}
		_prime_post_caches( $orgIds, false, true );
		$orgs = new OrgRepository();
		$out  = [];
		foreach ( $orgIds as $orgId ) {
			$post = $orgs->findOnSite( $orgId );
			if ( null === $post ) {
				// A membership the daily sweep has yet to drop, its organization
				// gone; or one whose organization is in the trash, and whose hub
				// would turn the person away.
				continue;
			}
			$state = '';
			if ( PortalGuard::membershipExpired( $orgId ) ) {
				$state = 'expired';
			} elseif ( OrgMeta::STATUS_SUSPENDED === $orgs->status( $orgId ) ) {
				$state = 'suspended';
			}
			$out[] = [
				'id'    => $orgId,
				'name'  => get_the_title( $post ),
				'url'   => Routing::url( Routing::ROUTE_ORG, [ 'slug' => $post->post_name ] ),
				'state' => $state,
			];
		}
		return count( $out ) < 2 ? [] : $out;
	}

	private static function resolve( WP_User $user, string $route, string $param ): int {
		switch ( $route ) {
			case Routing::ROUTE_ORG:
				return self::hubOrg( $user, $param );
			case Routing::ROUTE_PROJECT:
				return ( new ProjectRepository() )->userCanAccess( (int) $user->ID, (int) $param )
					? (int) get_post_meta( (int) $param, ProjectMeta::KEY_ORG_ID, true )
					: 0;
			case Routing::ROUTE_CONTENT:
				return self::orgOfContent( $user, (int) $param );
			case Routing::ROUTE_SUPPORT_REQUEST:
				return self::orgOfRequest( $user, $param ) ?: self::primaryOnSite( (int) $user->ID );
			default:
				return self::primaryOnSite( (int) $user->ID );
		}
	}

	/**
	 * The organization a support request's page is about: the one the
	 * request was filed with, when the request is the viewer's own, they
	 * still belong there and the organization is still on the site, so the
	 * request never puts on the chip an organization whose hub would turn
	 * them away (one they have left, one in the trash), nor one that is gone
	 * while its membership row waits for the sweep. 0 otherwise, and the
	 * page is then about what every other route is about: their first
	 * organization on the site (primaryOnSite(), in resolve()), whatever
	 * state it is in. The early answer below counts every membership, one
	 * in the trash among them, which costs nothing: such a request's
	 * organization is not on the site and answers 0 all the same.
	 */
	private static function orgOfRequest( WP_User $user, string $ref ): int {
		$userId = (int) $user->ID;
		// With one organization or none the page is about that one whatever
		// the request says, so the request is read only for a person in several.
		if ( count( Roster::orgIdsOf( $userId ) ) < 2 ) {
			return 0;
		}
		$request = SupportPages::ownRequest( $userId, $ref );
		$orgId   = (int) ( $request['org_id'] ?? 0 );
		return $orgId > 0 && Roster::isMemberOf( $userId, $orgId ) && null !== ( new OrgRepository() )->findOnSite( $orgId ) ? $orgId : 0;
	}

	private static function hubOrg( WP_User $user, string $slug ): int {
		if ( '' === $slug ) {
			return 0;
		}
		$post = ( new OrgRepository() )->findBySlug( $slug );
		if ( ! $post ) {
			return 0;
		}
		$orgId = (int) $post->ID;
		return Capabilities::isStaff( $user ) || Roster::isMemberOf( (int) $user->ID, $orgId ) ? $orgId : 0;
	}

	/**
	 * The organization one content item is about for a viewer: what orgFor()
	 * answers on the item's own page, here for a list that labels its rows
	 * (the dashboard's What's new) so the label and the page agree. Which of
	 * the viewer's organizations it is, is Organizations\Reach's to say: the
	 * emails and the activity rows about the item ask it the same question.
	 * So is which organizations the item names at all: none when it is for
	 * everyone, so the page never wears the badge of a list the audience no
	 * longer reads while its download note and its row name another.
	 */
	public static function orgOfContent( WP_User $user, int $contentId ): int {
		if ( $contentId <= 0 ) {
			return 0;
		}
		$itemOrgs = Reach::contentOrgs( $contentId );
		if ( ! $itemOrgs ) {
			return 0;
		}
		$mine = Reach::among( (int) $user->ID, $itemOrgs );
		if ( $mine > 0 ) {
			return $mine;
		}
		return Capabilities::isStaff( $user ) ? $itemOrgs[0] : 0;
	}

	/**
	 * Whether the viewer belongs to a live organization other than the one
	 * given: one whose membership has not ended and whose status is active.
	 * The shell asks before its suspended block speaks for the primary
	 * organization on a page that spans all of them.
	 */
	public static function hasLiveOrgBeside( WP_User $user, int $orgId ): bool {
		foreach ( Roster::orgIdsOf( (int) $user->ID ) as $own ) {
			if ( $own !== $orgId && Reach::isLive( $own ) ) {
				return true;
			}
		}
		return false;
	}
}
