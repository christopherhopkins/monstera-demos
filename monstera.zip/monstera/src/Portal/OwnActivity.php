<?php
/**
 * "Your recent activity", the first block of the dashboard's rail
 * (People-model track, FR5; the owner's walk-through at the Phase 5
 * checkpoint). The block listed what was newly published, which "What's new
 * for you" lists beside it, so the same rows were on the page twice. It
 * lists what the reader did instead: the items they viewed, downloaded or
 * published, the resources they opened and the guides they read, the forms
 * they sent, the files they added to a project's discovery, the support
 * requests they opened and answered (Reporting\ActivitySentences::OWN_EVENTS
 * says which events, and why no others). Newest first, a handful, and one
 * row for an act however often it was repeated, with the time of the latest
 * the log holds.
 *
 * The latest the log holds is not always the latest time it was done. A
 * download, a reply and a file are logged every time. A view is logged once
 * for a member, an item and a day, the day being UTC's
 * (Reporting\Tracking::contentViewed(), so a refresh is not a second view
 * in the admin's counts): an item opened at nine and again at three reads
 * "6 hours ago" that afternoon, under what was done between, and moves up
 * only with the next day's view. Telling the true latest means recording
 * every view, which changes those counts; that is the owner's to decide and
 * is not done here.
 *
 * The thing an act is on is the thing its row links. For a file added to a
 * project's discovery that is the project, so several files sent to one
 * project are one row, naming the file sent last: the files have no page of
 * their own, and an afternoon of uploads would otherwise be the whole
 * block.
 *
 * A row names the thing and links its page, so it is shown only while the
 * reader can still open that page, by the rule the page itself follows: an
 * item the visibility engine allows whose page the guard would not close as
 * ended, a project the dashboard lists, a request that is the reader's own,
 * a resource the Resources page lists for them, a form the Forms page lists
 * for them. Anything else is left out whole, sentence and name, and an
 * older act takes its place: a row that said "You viewed" with no link
 * would still name what is no longer theirs to read.
 *
 * The reads do not grow with the rows: the reader's acts come from one read
 * of the log, the posts they name from one read with their meta, the gates
 * of the items from the two reads the engine primes with, the requests from
 * one read, and the resources and forms (each asked only when one of the
 * acts is on one) from their pages' own lists.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\AccessControl\PortalGuard;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\Repository as FormsRepository;
use Monstera\Resources\Meta as ResourceMeta;
use Monstera\Resources\Repository as ResourcesRepository;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Reporting\ActivityLog;
use Monstera\Reporting\ActivitySentences;
use Monstera\Support\Activity as SupportActivity;
use Monstera\Support\Repository as SupportRepository;
use WP_Post;
use WP_Query;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class OwnActivity {

	/** How many rows the block shows: what it showed when it listed what was published. */
	public const SHOWN = 5;

	/**
	 * How far back the log is read. Enough that five rows are left once the
	 * repeats of an act are one row and what the reader can no longer open
	 * is left out; a person whose last fifty acts were all on the same few
	 * things reads those few.
	 */
	private const WINDOW = 50;

	/**
	 * The block's rows for a reader, newest first.
	 *
	 * @param Visibility        $visibility       The page's own engine, so what it has already read of the items is not read again.
	 * @param array<int, mixed> $listedProjectIds The projects the page lists for the reader (Projects\Repository::listedFor()): those they may open, less the ones an ended membership closes.
	 * @return list<array{parts: list<array{text: string, url?: string}>, at: int}> Each row's sentence in parts, and when the act was last done (a Unix time).
	 */
	public static function rows( WP_User $user, Visibility $visibility, array $listedProjectIds ): array {
		$acts = self::latestOfEach( ActivityLog::actsOf( (int) $user->ID, ActivitySentences::OWN_EVENTS, self::WINDOW ) );
		if ( ! $acts ) {
			return [];
		}

		// What the acts name, by kind, read together before any row is judged.
		$named = [];
		foreach ( $acts as $act ) {
			$named[ (string) $act['object_type'] ][] = (int) $act['object_id'];
		}
		$posts = self::published( array_merge( $named['content'] ?? [], $named['project'] ?? [] ) );
		$visibility->prime( array_intersect( $named['content'] ?? [], array_keys( $posts ) ) );
		$requests  = isset( $named[ SupportActivity::OBJECT ] ) && Modules::isActive( Modules::SUPPORT )
			? ( new SupportRepository() )->findMany( $named[ SupportActivity::OBJECT ] )
			: [];
		$resources = [];
		if ( isset( $named['resource'] ) && Modules::isActive( Modules::RESOURCES ) ) {
			foreach ( ( new ResourcesRepository() )->visibleTo( $user ) as $resource ) {
				$resources[ (int) $resource->ID ] = $resource;
			}
		}
		$forms = [];
		if ( isset( $named['form'] ) && Modules::isActive( Modules::FORMS ) ) {
			foreach ( ( new FormsRepository() )->visibleTo( $user ) as $form ) {
				$forms[ (int) $form->ID ] = $form;
			}
		}
		$listedProjectIds = array_map( 'intval', $listedProjectIds );

		$rows = [];
		foreach ( $acts as $act ) {
			$id    = (int) $act['object_id'];
			$thing = match ( (string) $act['object_type'] ) {
				'content'               => self::item( $user, $visibility, $posts[ $id ] ?? null ),
				'project'               => self::project( $posts[ $id ] ?? null, $listedProjectIds ),
				'resource'              => self::resource( $resources[ $id ] ?? null ),
				'form'                  => self::form( $forms[ $id ] ?? null ),
				SupportActivity::OBJECT => self::request( $user, $requests[ $id ] ?? null ),
				default                 => null,
			};
			if ( null === $thing ) {
				continue;
			}
			// An event with no sentence of the reader's own has no row: the log
			// is asked for OWN_EVENTS alone, and this holds if it ever answers
			// with another.
			$parts = ActivitySentences::describeOwn( $act, $thing );
			if ( ! $parts ) {
				continue;
			}
			$rows[] = [
				'parts' => $parts,
				'at'    => (int) strtotime( (string) $act['occurred_at'] . ' UTC' ),
			];
			if ( self::SHOWN === count( $rows ) ) {
				break;
			}
		}
		return $rows;
	}

	/**
	 * One row for each act on each thing: the latest the log holds, the rows
	 * coming newest first. An item downloaded five times was downloaded,
	 * once, most recently then; one viewed twice in a day has the one row
	 * the log wrote for that day, with the time of the first (the class
	 * comment says why). A download reads the same under the event's older
	 * name.
	 *
	 * The thing is the row's object, which for a file added to a project's
	 * discovery is the project: the file's name is left out of the key on
	 * purpose, so the files sent to one project are one row, the last one's.
	 *
	 * @param list<array<string, mixed>> $acts Log rows, newest first.
	 * @return list<array<string, mixed>>
	 */
	private static function latestOfEach( array $acts ): array {
		$latest = [];
		foreach ( $acts as $act ) {
			$event = 'content_downloaded' === $act['event_type'] ? 'download' : (string) $act['event_type'];
			$key   = $event . '|' . $act['object_type'] . '|' . (int) $act['object_id'];
			if ( ! isset( $latest[ $key ] ) ) {
				$latest[ $key ] = $act;
			}
		}
		return array_values( $latest );
	}

	/**
	 * The items and projects among these ids that are published, with their
	 * meta, in one read. One that was deleted, sent to the trash or taken
	 * back to a draft is absent, and its row is left out without the engine
	 * being asked about a post that is not there.
	 *
	 * @param list<int> $ids
	 * @return array<int, WP_Post> By id.
	 */
	private static function published( array $ids ): array {
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		if ( ! $ids ) {
			return [];
		}
		$query = new WP_Query(
			[
				'post_type'              => [ ContentPostType::SLUG, ProjectPostType::SLUG ],
				'post_status'            => 'publish',
				'post__in'               => $ids,
				'posts_per_page'         => count( $ids ),
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
			]
		);
		$posts = [];
		foreach ( $query->posts as $post ) {
			if ( $post instanceof WP_Post ) {
				$posts[ (int) $post->ID ] = $post;
			}
		}
		return $posts;
	}

	/**
	 * An item, while its page would open: the engine allows it, and the
	 * organization it reaches the reader through has not ended, which is
	 * when the guard answers the page with "Membership ended" (staff are
	 * never turned away). A suspended organization's item still opens, its
	 * download paused, so its row stays.
	 *
	 * @return array{text: string, url: string}|null
	 */
	private static function item( WP_User $user, Visibility $visibility, ?WP_Post $post ): ?array {
		if ( ! $post || ContentPostType::SLUG !== $post->post_type || ! $visibility->userCanSee( $user, (int) $post->ID ) ) {
			return null;
		}
		if ( ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			$orgId = Context::orgOfContent( $user, (int) $post->ID );
			if ( $orgId > 0 && PortalGuard::membershipExpired( $orgId ) ) {
				return null;
			}
		}
		return [
			'text' => get_the_title( $post ),
			'url'  => Routing::url( Routing::ROUTE_CONTENT, [ 'id' => (int) $post->ID ] ),
		];
	}

	/**
	 * A project, while the page lists it for the reader.
	 *
	 * @param list<int> $listedProjectIds
	 * @return array{text: string, url: string}|null
	 */
	private static function project( ?WP_Post $post, array $listedProjectIds ): ?array {
		if ( ! $post || ProjectPostType::SLUG !== $post->post_type || ! in_array( (int) $post->ID, $listedProjectIds, true ) ) {
			return null;
		}
		return [
			'text' => get_the_title( $post ),
			'url'  => Routing::url( Routing::ROUTE_PROJECT, [ 'id' => (int) $post->ID ] ),
		];
	}

	/**
	 * A resource the Resources page lists for the reader. A guide has a page
	 * of its own, which the row leads to; a link or a file has none, so the
	 * row leads to the Resources page.
	 *
	 * @return array{text: string, url: string}|null
	 */
	private static function resource( ?WP_Post $post ): ?array {
		if ( ! $post ) {
			return null;
		}
		return [
			'text' => get_the_title( $post ),
			'url'  => ResourceMeta::KIND_GUIDE === ResourceMeta::kindOf( (int) $post->ID )
				? Routing::url( Routing::ROUTE_RESOURCE, [ 'id' => (int) $post->ID ] )
				: Routing::url( Routing::ROUTE_RESOURCES ),
		];
	}

	/**
	 * A form the Forms page lists for the reader. The row leads to that page
	 * until the form has one of its own (the Forms-and-resources track's
	 * Phase 4 gives it one, where the reader's own submissions are read).
	 *
	 * @return array{text: string, url: string}|null
	 */
	private static function form( ?WP_Post $post ): ?array {
		if ( ! $post ) {
			return null;
		}
		return [
			'text' => get_the_title( $post ),
			'url'  => Routing::url( Routing::ROUTE_FORMS ),
		];
	}

	/**
	 * A support request that is the reader's own, by its subject: its page
	 * is its member's alone (the guard turns even staff away from one that
	 * is not theirs), so what staff answered in the admin is not listed for
	 * them here.
	 *
	 * @param array<string, mixed>|null $request
	 * @return array{text: string, url: string}|null
	 */
	private static function request( WP_User $user, ?array $request ): ?array {
		if ( ! $request || (int) $request['member_id'] !== (int) $user->ID ) {
			return null;
		}
		return [
			'text' => (string) $request['subject'],
			'url'  => SupportRepository::portalUrl( $request ),
		];
	}
}
