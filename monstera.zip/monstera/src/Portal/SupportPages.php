<?php
/**
 * Support's pages in the portal: the member's requests (/support/), the
 * form (/support/new/) and one request (/support/{REF}/).
 *
 * What the router and the guard ask about them lives here: where an old
 * address now leads, and which request a reference names for a member. So
 * does what a person in several organizations is asked and told (People-model
 * track, FR5): which organizations a new request may be filed with, which
 * one the form opens on, and what each request's organization is called.
 * The form, the list, the request's page and the route that takes a new
 * request all read it here, so the select never offers what the server
 * would refuse.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Routing;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Support\Repository;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class SupportPages {

	/**
	 * Where a request for an old support address should go, or null to
	 * render the route as asked. /support/?sent=<ref> was the confirmation
	 * page and is the request's own page now; /support/?project=<id> was
	 * the form about a project, which lives at /support/new/.
	 *
	 * @param array<string, mixed> $query The request's query string.
	 */
	public static function redirectTarget( string $route, array $query ): ?string {
		if ( Routing::ROUTE_SUPPORT !== $route ) {
			return null;
		}
		$sent = isset( $query['sent'] ) && is_scalar( $query['sent'] ) ? (string) $query['sent'] : '';
		if ( 1 === preg_match( '/^' . Routing::REF_PATTERN . '$/', $sent ) ) {
			return Routing::url( Routing::ROUTE_SUPPORT_REQUEST, [ 'ref' => $sent ] );
		}
		$project = isset( $query['project'] ) && is_scalar( $query['project'] ) ? absint( $query['project'] ) : 0;
		if ( $project > 0 ) {
			return Routing::url( Routing::ROUTE_SUPPORT_NEW, [ 'project' => $project ] );
		}
		return null;
	}

	/**
	 * The request a reference names, when it is this member's own. Anyone
	 * else's, and a reference that names none, are both null: the page
	 * answers them alike.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function ownRequest( int $userId, string $ref ): ?array {
		$row = ( new Repository() )->findByRef( $ref );
		return $row && $userId > 0 && (int) $row['member_id'] === $userId ? $row : null;
	}

	/**
	 * The organizations a new request may be filed with, when there is a
	 * choice to make: the ones the shell's switcher lists
	 * (Context::switcherOrgs()), which is every organization the person
	 * belongs to whose hub opens (it exists and is published), oldest
	 * membership first. A suspended organization and one whose membership
	 * has ended are among them: the support pages and the route stay open to
	 * a member of one organization in either state, who may need to ask
	 * about exactly that, so a person in several is not refused what a
	 * person in one is allowed. Empty when there is nothing to choose: for a
	 * person in one organization or in none, and for staff, who file as they
	 * always have whatever memberships the account also holds.
	 *
	 * @return array<int, string> Organization id => its name.
	 */
	public static function filingOrgs( WP_User $user ): array {
		return array_column( Context::switcherOrgs( $user ), 'name', 'id' );
	}

	/**
	 * The organizations a person belongs to that still exist and are
	 * published, oldest membership first. With nothing to choose between
	 * (filingOrgs() is empty) the route holds a request to these, and files
	 * it with the first when none is named. A membership whose organization
	 * is gone, its row not yet swept, is no more among them than among the
	 * choices, and nor is one whose organization is in the trash or a draft:
	 * with two memberships and one organization gone, the request is the
	 * other's.
	 *
	 * @return list<int>
	 */
	public static function ownOrgs( int $userId ): array {
		$orgs = new OrgRepository();
		return array_values( array_filter( Roster::orgIdsOf( $userId ), static fn ( int $orgId ): bool => null !== $orgs->findPublished( $orgId ) ) );
	}

	/**
	 * The organization the new-request form opens on. A request about a
	 * project is the project's organization's; a form reached from a page
	 * about one organization (its hub, an item of it) is about that one,
	 * named in the address; any other is about the context organization, as
	 * the chip says. Each only when it is among the choices, and the first
	 * of those when none is.
	 *
	 * @param array<int, string>   $choices    filingOrgs(), with something in it.
	 * @param int                  $projectOrg The organization of the project the form is about; 0 when it is about none.
	 * @param array<string, mixed> $query      The request's query string.
	 */
	public static function chosenOrg( WP_User $user, array $choices, int $projectOrg, array $query ): int {
		$named = isset( $query['org'] ) && is_scalar( $query['org'] ) ? absint( $query['org'] ) : 0;
		foreach ( [ $projectOrg, $named, Context::orgFor( $user, Routing::ROUTE_SUPPORT_NEW ) ] as $orgId ) {
			if ( isset( $choices[ $orgId ] ) ) {
				return $orgId;
			}
		}
		return (int) array_key_first( $choices );
	}

	/**
	 * What the organizations of a person's requests are called, for a person
	 * in several: their own, and any other a request of theirs was filed
	 * with (one they have since left), read together. Empty for everyone
	 * else, so a person in one organization is never told which.
	 *
	 * @param array<int, array<string, mixed>> $requests The requests about to be shown.
	 * @return array<int, string> Organization id => its name.
	 */
	public static function orgNames( WP_User $user, array $requests ): array {
		$names = self::filingOrgs( $user );
		if ( ! $names ) {
			return [];
		}
		$others = array_diff( array_unique( array_map( 'intval', array_column( $requests, 'org_id' ) ) ), array_keys( $names ), [ 0 ] );
		if ( $others ) {
			_prime_post_caches( $others, false, false );
			$orgs = new OrgRepository();
			foreach ( $others as $orgId ) {
				$post = $orgs->findById( $orgId );
				if ( null !== $post ) {
					$names[ $orgId ] = get_the_title( $post );
				}
			}
		}
		return $names;
	}

	/**
	 * The form's address from a page about one organization (its hub, an
	 * item of it): with the organization named when the form would offer it,
	 * so the request starts out about the page the person came from. For
	 * anyone with nothing to choose it is the address it always was.
	 */
	public static function newRequestUrl( WP_User $user, int $orgId ): string {
		return Routing::url( Routing::ROUTE_SUPPORT_NEW, isset( self::filingOrgs( $user )[ $orgId ] ) ? [ 'org' => $orgId ] : [] );
	}
}
