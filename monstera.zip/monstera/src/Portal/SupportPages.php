<?php
/**
 * Support's pages in the portal: the member's requests (/support/), the
 * form (/support/new/) and one request (/support/{REF}/).
 *
 * What the router and the guard ask about them lives here: where an old
 * address now leads, and which request a reference names for a member.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Routing;
use Monstera\Support\Repository;

defined( 'ABSPATH' ) || exit;

final class SupportPages {

	/**
	 * Where a request for an old support address should go, or null to
	 * render the route as asked. /support/?sent=<ref> was the confirmation
	 * page and is the request's own page now; /support/?project=<id> was
	 * the form about a project, which lives at /support/new/.
	 *
	 * @param array<string, mixed> $query The request's query string.
	 */
	public static function redirectTarget( string $route, array $query ): ?string {
		if ( Routing::ROUTE_SUPPORT !== $route ) {
			return null;
		}
		$sent = isset( $query['sent'] ) && is_scalar( $query['sent'] ) ? (string) $query['sent'] : '';
		if ( 1 === preg_match( '/^' . Routing::REF_PATTERN . '$/', $sent ) ) {
			return Routing::url( Routing::ROUTE_SUPPORT_REQUEST, [ 'ref' => $sent ] );
		}
		$project = isset( $query['project'] ) && is_scalar( $query['project'] ) ? absint( $query['project'] ) : 0;
		if ( $project > 0 ) {
			return Routing::url( Routing::ROUTE_SUPPORT_NEW, [ 'project' => $project ] );
		}
		return null;
	}

	/**
	 * The request a reference names, when it is this member's own. Anyone
	 * else's, and a reference that names none, are both null: the page
	 * answers them alike.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function ownRequest( int $userId, string $ref ): ?array {
		$row = ( new Repository() )->findByRef( $ref );
		return $row && $userId > 0 && (int) $row['member_id'] === $userId ? $row : null;
	}
}
