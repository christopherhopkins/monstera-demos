<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Projects\Repository as ProjectRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Who a client reaches first (At-a-glance track, FR4 and FR7): a project's
 * lead and an organization's account lead, as the portal offers them.
 *
 * A lead is offered only while the record holds when the page is read (the
 * Phase 2 review), since the meta naming them is cleared by the daily sweep
 * (Organizations\Roster::sweepOrphans()) and may still name someone for up
 * to a day after they left: the person is staff. An account lead must also
 * still be assigned to the organization, which an unassignment ends at
 * once; a project's lead need not be, since unassigning someone keeps the
 * projects they lead (the admin's confirmation says so: "change that from
 * the project"), and the admin names them the lead all the same. Nobody
 * else's address is ever offered: a lead is staff.
 */
final class Leads {

	/** The project's lead, while they are still staff, or null. */
	public static function project( int $projectId ): ?WP_User {
		return self::staff( ( new ProjectRepository() )->leadId( $projectId ) );
	}

	/**
	 * The organization's account lead, while still staff and assigned to it,
	 * or null. Whether they are assigned is read from the person's own rows:
	 * one small read on a page about one organization, and none on a page
	 * that lists many once it has primed the leads (Roster::prime()); the
	 * organization's whole roster is never loaded to answer it.
	 */
	public static function account( int $orgId ): ?WP_User {
		if ( $orgId <= 0 ) {
			return null;
		}
		$lead = self::staff( ( new OrgRepository() )->accountLeadId( $orgId ) );
		return $lead && Roster::isAssignedTo( (int) $lead->ID, $orgId ) ? $lead : null;
	}

	/**
	 * Whom the project page's card names, and as what: the project's lead,
	 * else the organization's account lead for a member of that organization,
	 * else nobody. Someone who reaches the project by its team alone (a
	 * project moved to another organization keeps its team) is not told
	 * another organization's account lead. The page words the heading.
	 *
	 * @param int $orgId    The project's organization; 0 for a standalone client's project, which has no account lead.
	 * @param int $readerId Who reads the page.
	 * @return array{lead: WP_User, kind: string}|null `kind` is 'project' or 'account'.
	 */
	public static function forProject( int $projectId, int $orgId, int $readerId ): ?array {
		$lead = self::project( $projectId );
		if ( $lead ) {
			return [
				'lead' => $lead,
				'kind' => 'project',
			];
		}
		$lead = $orgId > 0 && Roster::isMemberOf( $readerId, $orgId ) ? self::account( $orgId ) : null;
		return $lead ? [
			'lead' => $lead,
			'kind' => 'account',
		] : null;
	}

	private static function staff( int $userId ): ?WP_User {
		$user = $userId > 0 ? get_userdata( $userId ) : false;
		return $user instanceof WP_User && Capabilities::isStaff( $user ) ? $user : null;
	}
}
