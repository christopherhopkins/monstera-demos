<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Module;
use Monstera\Core\Routing;
use Monstera\Content\Downloader;
use Monstera\Content\SecureFiles;
use Monstera\Content\Visibility;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

final class PortalModule implements Module {

	public function slug(): string {
		return 'portal';
	}

	public function boot(): void {
		add_action( 'template_redirect', [ $this, 'maybeRender' ], 5 );
		add_action( 'wp_head', [ $this, 'addBodyClass' ], 1 );
		add_action( 'wp_interactivity_state', [ $this, 'seedInteractivityState' ] );
		add_filter( 'show_admin_bar', static fn ( bool $show ) => get_query_var( Routing::QUERY_VAR ) ? false : $show );
	}

	public function maybeRender(): void {
		$route = (string) get_query_var( Routing::QUERY_VAR );
		if ( ! $route ) {
			return;
		}

		// A form link: log the open and send the member on (Forms\Opener).
		if ( Routing::ROUTE_FORM_OPEN === $route ) {
			\Monstera\Forms\Opener::handle( (int) get_query_var( Routing::PARAM_ID ) );
			exit;
		}

		if ( Routing::ROUTE_DOWNLOAD === $route ) {
			$downloader = new Downloader( new SecureFiles(), new Visibility( new SubgroupRepository(), new ProjectRepository() ) );
			$downloader->handle();
			exit;
		}

		$router = new Router();
		$router->dispatch( $route );
		exit;
	}

	public function addBodyClass(): void {
		if ( get_query_var( Routing::QUERY_VAR ) ) {
			add_filter(
				'body_class',
				static function ( array $classes ): array {
					$classes[] = 'monstera-portal-page';
					return $classes;
				}
			);
		}
	}

	public function seedInteractivityState(): void {
		// The Interactivity API namespace state is hydrated client-side via wp_interactivity_state(),
		// configured per-page in Router::renderShell to keep concerns local.
	}

	public function registerPostTypes(): void {}
}
