<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\Repository as FormsRepository;
use Monstera\Forms\Standing;
use WP_Post;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * The forms coming up for a person (Forms-and-resources track, FR5): those
 * that reach them with a due day in the Portal's "Coming up" window
 * (NextStep::window()) that they have not sent, as rows beside the
 * projects' dates, each leading to the form's page. A form they have sent,
 * one that takes nothing now and one for everyone are what the Forms page
 * says of them (Forms\Standing): only a form standing as Due is coming up.
 *
 * For clients alone, as the next steps are (NextStep::addressedTo()):
 * staff reach every form and send none, so for them the rows would only
 * crowd out the projects' dates.
 */
final class DueForms {

	/**
	 * @param array{0: int, 1: int} $window  As NextStep::window() answers it.
	 * @param bool                  $several Whether the reader is in several organizations, whose rows name the one each form reaches them through.
	 * @return list<array{date: int, title: string, detail: string, url: string, org: string}> When the day starts, the form, the row's fact, its page, and the organization named (else '').
	 */
	public static function comingUp( WP_User $user, array $window, bool $several = false ): array {
		if ( ! Modules::isActive( Modules::FORMS ) || ! NextStep::addressedTo( $user ) ) {
			return [];
		}
		$forms = new FormsRepository();
		// Only a built form with a due day in the window can be coming up:
		// the rest are set aside before what they have sent is read.
		$dueAt      = [];
		$candidates = [];
		foreach ( $forms->visibleTo( $user ) as $form ) {
			$formId = (int) $form->ID;
			if ( FormMeta::KIND_BUILT !== FormMeta::kindOf( $formId ) ) {
				continue;
			}
			$at = CalendarDay::start( FormMeta::dueOn( $formId ) )?->getTimestamp() ?? 0;
			if ( NextStep::inWindow( $at, $window ) ) {
				$dueAt[ $formId ] = $at;
				$candidates[]     = $form;
			}
		}
		if ( ! $candidates ) {
			return [];
		}
		$through = $several ? $forms->reachedThrough( $user, $candidates ) : [];
		$out     = [];
		foreach ( Standing::ofEach( $user, $candidates ) as $formId => $standing ) {
			if ( Standing::GROUP_DUE !== $standing['group'] ) {
				continue;
			}
			$orgId = (int) ( $through[ $formId ] ?? 0 );
			$out[] = [
				'date'   => $dueAt[ $formId ],
				'title'  => (string) get_the_title( $formId ),
				'detail' => __( 'Form due', 'monstera' ),
				'url'    => Routing::url( Routing::ROUTE_FORM, [ 'id' => $formId ] ),
				'org'    => $orgId > 0 ? (string) get_the_title( $orgId ) : '',
			];
		}
		return $out;
	}
}
