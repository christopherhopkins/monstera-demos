<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Routing;

defined( 'ABSPATH' ) || exit;

/**
 * The document title of a portal page (WCAG 2.2 SC 2.4.2, Page Titled): the
 * page's own name first, then what it sits under, then the site, joined by
 * " · ". "Forms · Acme", "Claim form · Forms · Acme", "Members · Harbor Lane
 * Dental · Acme". Every page had read "Acme · Acme" before.
 *
 * The names are the ones the nav, the hub's tabs and the breadcrumbs already
 * use. A page that turns its reader away is named by its badge ("Not shared
 * with you", "Not enabled", "Membership ended"), then the section it was
 * asked from where it has one, so the title never names the hub, item,
 * project, form or guide that the page withholds.
 *
 * Only the template knows which of those it is showing, and it decides
 * after the shell has printed the head. So the shell prints a slot where the
 * title goes (tag()), the template names the page where it decides what it
 * shows (name(), refused()), and the router's output buffer puts the name in
 * the slot once the page is rendered (fill()). A page that names nothing
 * keeps its route's name: the section's own ("Profile", "Directory"), the
 * Portal at /portal/, and for a hub or an item, which have no name but their
 * own, the site's alone.
 */
final class DocumentTitle {

	/** Where the title goes until the page has named itself. */
	public const SLOT = '%%monstera-document-title%%';

	private const SEPARATOR = ' · ';

	private static string $route = '';

	/** @var list<string> */
	private static array $parts = [];

	/** A new page on a route: its name is the route's until the template says otherwise. */
	public static function begin( string $route ): void {
		self::$route = $route;
		self::$parts = Routing::ROUTE_DASHBOARD === $route
			? [ __( 'Portal', 'monstera' ) ]
			: self::clean( [ self::section( $route ) ] );
	}

	/** The page's own name, then what it sits under, nearest first; the site follows. */
	public static function name( string ...$parts ): void {
		self::$parts = self::clean( $parts );
	}

	/**
	 * A page that turns its reader away: its badge, then the section it was
	 * asked from (none on the Portal, a hub or an item).
	 */
	public static function refused( string $reason ): void {
		self::$parts = self::clean( [ $reason, self::section( self::$route ) ] );
	}

	/** The title as text, the site last. */
	public static function text(): string {
		return implode( self::SEPARATOR, self::clean( [ ...self::$parts, get_bloginfo( 'name' ) ] ) );
	}

	/**
	 * The head's one title element, as a slot fill() fills. The theme's own
	 * title tag would be a second one, naming the site alone, so it is taken
	 * off the head.
	 */
	public static function tag(): void {
		remove_action( 'wp_head', '_wp_render_title_tag', 1 );
		remove_action( 'wp_head', '_block_template_render_title_tag', 1 );
		echo '<title>' . esc_html( self::SLOT ) . '</title>';
	}

	/** The rendered page with its title in the slot: the router's output buffer callback. */
	public static function fill( string $html ): string {
		$at = strpos( $html, self::SLOT );
		if ( false === $at ) {
			return $html;
		}
		return substr_replace( $html, esc_html( self::text() ), $at, strlen( self::SLOT ) );
	}

	/** The section a route belongs to, by the nav's names; '' for the Portal, a hub and an item. */
	private static function section( string $route ): string {
		return match ( $route ) {
			Routing::ROUTE_FORMS, Routing::ROUTE_FORM => __( 'Forms', 'monstera' ),
			Routing::ROUTE_RESOURCES, Routing::ROUTE_RESOURCE => __( 'Resources', 'monstera' ),
			Routing::ROUTE_PROJECTS, Routing::ROUTE_PROJECT => __( 'Projects', 'monstera' ),
			Routing::ROUTE_SUPPORT, Routing::ROUTE_SUPPORT_NEW, Routing::ROUTE_SUPPORT_REQUEST => __( 'Support', 'monstera' ),
			Routing::ROUTE_DIRECTORY => __( 'Directory', 'monstera' ),
			Routing::ROUTE_PROFILE => __( 'Profile', 'monstera' ),
			Routing::ROUTE_ACCESSIBILITY => __( 'Accessibility statement', 'monstera' ),
			Routing::ROUTE_SIGN_IN => __( 'Sign in', 'monstera' ),
			default => '',
		};
	}

	/**
	 * Each part as plain text, the empty ones left out: a title may carry
	 * markup ("<em>"), which a title element would print as it stands.
	 *
	 * @param array<int, string> $parts
	 * @return list<string>
	 */
	private static function clean( array $parts ): array {
		$clean = [];
		foreach ( $parts as $part ) {
			$part = trim( wp_strip_all_tags( $part ) );
			if ( '' !== $part ) {
				$clean[] = $part;
			}
		}
		return $clean;
	}
}
