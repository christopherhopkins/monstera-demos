<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\AccessControl\PortalGuard;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Projects\Repository as ProjectRepository;

defined( 'ABSPATH' ) || exit;

/**
 * The projects a content item names to its reader (At-a-glance track, FR6
 * portal; comps 40, 20 and 23): outside a project's own page, the hub's
 * Content tab and the Portal's "What's new for you" say on a row's meta
 * line which projects an item belongs to, after the audience or the
 * organization, each a link to its page; the item's own page names them
 * in its head.
 *
 * A project is named only to a reader who may open it, as its page judges
 * (Projects\Repository::userCanAccess()), and while it is published: an
 * item on several projects may be on another client's too, whose name is
 * not this reader's to read (the Task 1 review), a draft is not shared yet,
 * and one in the trash was taken away. Nor is a project named whose
 * organization's membership has ended, since its page answers "Membership
 * ended" to all but staff, nor any to a reader the portal shows no
 * projects to (an account with a membership and no client role, whose
 * project pages answer "Not shared with you"). The rows' projects are the
 * gates the page judged its items by, which Visibility remembers, and
 * whether the reader may open them is asked of them together, so naming
 * them costs the same however many projects the rows name. With Projects
 * off nothing is named.
 */
final class ContentProjects {

	/** How many projects a row names before it counts the rest. */
	public const NAMED = 2;

	/**
	 * The ones of these projects the reader is told of: published, theirs
	 * to open, and of no organization whose membership has ended for them.
	 *
	 * @param int[] $projectIds
	 * @param int[] $known The ones the page already knows the reader may open (its own lists); not asked again.
	 * @return list<int> In the order given, each once.
	 */
	public static function shown( int $userId, array $projectIds, array $known = [] ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $projectIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $ids ) {
			return [];
		}
		$manager = user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA );
		if ( ! $manager && ! user_can( $userId, Capabilities::CAP_VIEW_PROJECTS ) ) {
			return [];
		}
		// The posts at once, then the meta of the published ones alone (the
		// organization each belongs to): a draft's or another client's
		// scope and intake are never loaded for nothing.
		_prime_post_caches( $ids, false, false );
		$published = array_values(
			array_filter(
				$ids,
				static function ( int $id ): bool {
					$post = get_post( $id );
					return $post && ProjectPostType::SLUG === $post->post_type && 'publish' === $post->post_status;
				}
			)
		);
		if ( $published ) {
			update_meta_cache( 'post', $published );
		}
		$knows = array_fill_keys( array_map( 'intval', $known ), true );
		$asked = array_values( array_filter( $published, static fn ( int $id ): bool => ! isset( $knows[ $id ] ) ) );
		$opens = $asked ? array_fill_keys( ( new ProjectRepository() )->openableBy( $userId, $asked ), true ) : [];
		$open  = array_values( array_filter( $published, static fn ( int $id ): bool => isset( $knows[ $id ] ) || isset( $opens[ $id ] ) ) );
		if ( ! $open || $manager ) {
			return $open;
		}
		// Each one's organization, and that organization's end date, read
		// together: whether the page knew the project or asked.
		$orgOf = [];
		foreach ( $open as $id ) {
			$orgOf[ $id ] = (int) get_post_meta( $id, ProjectMeta::KEY_ORG_ID, true );
		}
		$orgs = array_values( array_unique( array_filter( $orgOf ) ) );
		if ( $orgs ) {
			update_meta_cache( 'post', $orgs );
		}
		return array_values( array_filter( $open, static fn ( int $id ): bool => 0 === $orgOf[ $id ] || ! PortalGuard::membershipExpired( $orgOf[ $id ] ) ) );
	}

	/**
	 * The projects each row's item is on that its reader is told of,
	 * oldest first.
	 *
	 * @param Visibility $visibility The page's, which judged the items.
	 * @param int        $userId     The reader.
	 * @param int[]      $contentIds The rows' items.
	 * @param int[]      $known      As shown() takes it.
	 * @return array<int, list<array{title: string, url: string}>> By content id; an item that names none is left out.
	 */
	public static function forRows( Visibility $visibility, int $userId, array $contentIds, array $known ): array {
		if ( ! $contentIds || ! Modules::isActive( Modules::PROJECTS ) ) {
			return [];
		}
		$byContent = $visibility->projectsOf( $contentIds );
		$shown     = array_fill_keys( self::shown( $userId, array_merge( [], ...array_values( $byContent ) ), $known ), true );
		if ( ! $shown ) {
			return [];
		}
		$out = [];
		foreach ( $byContent as $contentId => $projectIds ) {
			// Oldest first, whichever read the gates came from.
			sort( $projectIds );
			foreach ( $projectIds as $projectId ) {
				if ( isset( $shown[ $projectId ] ) ) {
					$out[ (int) $contentId ][] = [
						'title' => get_the_title( $projectId ),
						'url'   => Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $projectId ] ),
					];
				}
			}
		}
		return $out;
	}

	/**
	 * One row's part of the meta line: the first projects as links, then
	 * "+N" for the rest, said in words for a screen reader; '' for an item
	 * that names none. Each name is an item of its own, so a line that wraps
	 * between them keeps every link's 24 px target clear of the next line.
	 *
	 * @param list<array{title: string, url: string}> $projects As forRows() answers them for the item.
	 */
	public static function render( array $projects ): string {
		if ( ! $projects ) {
			return '';
		}
		$named = array_slice( $projects, 0, self::NAMED );
		$more  = count( $projects ) - count( $named );
		$items = [];
		foreach ( $named as $i => $project ) {
			$after = $i < count( $named ) - 1
				/* translators: follows each name but the last in a content row's list of projects, as a comma does in English */
				? esc_html( _x( ',', 'between the projects a content row names', 'monstera' ) )
				: '';
			$items[] = '<span><a href="' . esc_url( $project['url'] ) . '">' . esc_html( $project['title'] ) . '</a>' . $after . '</span>';
		}
		if ( $more > 0 ) {
			$items[] = '<span aria-hidden="true">+' . esc_html( number_format_i18n( $more ) ) . '</span><span class="m-sr-only">' . esc_html(
				sprintf(
					/* translators: %s: how many more projects a content item is on than its row names */
					_n( 'and %s more project', 'and %s more projects', $more, 'monstera' ),
					number_format_i18n( $more )
				)
			) . '</span>';
		}
		// A space between the items, which the line does not draw (it sets
		// them a space apart itself), so their text never runs together.
		return '<span class="m-list__projects">' . implode( ' ', $items ) . '</span>';
	}
}
