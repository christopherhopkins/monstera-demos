<?php
/**
 * What a route has just done for a person, kept for the page that comes
 * back to say it once. The portal's store reloads a page after some writes
 * and marks the address (`?invited=1`) so the template prints the sentence;
 * the mark alone is a word in an address, which anyone can type or send in
 * a link, and the page then said "Invitation sent." of an invitation
 * nobody sent. The route leaves a note here as it succeeds, and the
 * template says its sentence only when it finds the note, taking it as it
 * does: once, to the person who did the thing, about the record it was
 * done to.
 *
 * A note nobody collects (the page did not come back) lapses on its own.
 */

declare(strict_types=1);

namespace Monstera\Portal;

defined( 'ABSPATH' ) || exit;

final class Flash {

	/** An invitation into an organization went: the hub's Members tab says "Invitation sent." */
	public const INVITED = 'invited';

	/** How long a note waits for its page, which comes back at once: the bound on one nobody collects. */
	private const WAIT = 5 * MINUTE_IN_SECONDS;

	/**
	 * Note that the person signed in has just done this to that record.
	 *
	 * @param self::INVITED $what    What was done.
	 * @param int           $aboutId The record it was done to (the organization invited into).
	 */
	public static function leave( string $what, int $aboutId ): void {
		if ( get_current_user_id() > 0 ) {
			set_transient( self::key( $what, $aboutId ), 1, self::WAIT );
		}
	}

	/**
	 * Whether the person signed in has just done this to that record, asked
	 * once: the note is gone afterwards, so a reload says nothing.
	 *
	 * @param self::INVITED $what    What was done.
	 * @param int           $aboutId The record it was done to.
	 */
	public static function take( string $what, int $aboutId ): bool {
		$key = self::key( $what, $aboutId );
		if ( get_current_user_id() <= 0 || false === get_transient( $key ) ) {
			return false;
		}
		delete_transient( $key );
		return true;
	}

	private static function key( string $what, int $aboutId ): string {
		return 'monstera_flash_' . md5( $what . '|' . $aboutId . '|' . get_current_user_id() );
	}
}
