<?php
/**
 * Accessibility statement.
 *
 * Public page required by the European Accessibility Act (Directive (EU)
 * 2019/882 via EN 301 549). The fixed text describes what Monstera does;
 * the site-specific parts (contact, known limitations, review date) come
 * from Settings → General.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$siteName    = (string) get_bloginfo( 'name' );
$contact     = (string) get_option( 'monstera_a11y_contact_email', (string) get_option( 'admin_email' ) );
$limitations = trim( (string) get_option( 'monstera_a11y_known_limitations', '' ) );
$reviewed    = (string) get_option( 'monstera_a11y_last_reviewed', '' );
$reviewedTs  = $reviewed ? strtotime( $reviewed ) : false;
$portalHome  = \Monstera\Core\Routing::url( \Monstera\Core\Routing::ROUTE_DASHBOARD );
?>
<div class="m-statement">
	<h1><?php esc_html_e( 'Accessibility statement', 'monstera' ); ?></h1>
	<article class="m-prose" data-plain>
		<p>
			<?php
			printf(
				/* translators: 1: site name, 2: portal URL */
				esc_html__( '%1$s is committed to making its member and client portal at %2$s accessible to everyone, in line with the European Accessibility Act (Directive (EU) 2019/882) and the harmonised standard EN 301 549.', 'monstera' ),
				esc_html( $siteName ),
				'<a href="' . esc_url( $portalHome ) . '">' . esc_html( $portalHome ) . '</a>'
			);
			?>
		</p>

	<h2><?php esc_html_e( 'Conformance status', 'monstera' ); ?></h2>
	<p>
		<?php esc_html_e( 'This portal is designed to conform with the Web Content Accessibility Guidelines (WCAG) 2.2 at Level AA, which EN 301 549 incorporates for web content. Every screen is checked automatically against WCAG 2.2 AA with axe-core in both the light and dark themes, and keyboard focus is verified to stay visible and unobscured.', 'monstera' ); ?>
	</p>

	<h2><?php esc_html_e( 'What we do', 'monstera' ); ?></h2>
	<ul>
		<li><?php esc_html_e( 'Every interactive element can be reached and operated with a keyboard and shows a visible focus indicator.', 'monstera' ); ?></li>
		<li><?php esc_html_e( 'Colour contrast is verified for every text and control pairing in both themes.', 'monstera' ); ?></li>
		<li><?php esc_html_e( 'Pointer targets are at least 24 by 24 pixels, and content respects your reduced-motion preference.', 'monstera' ); ?></li>
		<li><?php esc_html_e( 'Signing in works with password managers and pasting; no puzzles or memorised codes are required.', 'monstera' ); ?></li>
		<li><?php esc_html_e( 'Forms do not ask you to re-enter information you have already given us.', 'monstera' ); ?></li>
	</ul>

	<h2><?php esc_html_e( 'Known limitations', 'monstera' ); ?></h2>
	<?php if ( '' !== $limitations ) : ?>
		<?php foreach ( preg_split( '/\r?\n+/', $limitations ) as $line ) : ?>
			<?php if ( '' !== trim( $line ) ) : ?>
				<p><?php echo esc_html( trim( $line ) ); ?></p>
			<?php endif; ?>
		<?php endforeach; ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No known limitations have been recorded. If you find something that does not work for you, please tell us using the contact details below.', 'monstera' ); ?></p>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Feedback and contact', 'monstera' ); ?></h2>
	<p>
		<?php esc_html_e( 'If you cannot access part of this portal, need information in another format, or want to report an accessibility problem, please contact us:', 'monstera' ); ?>
	</p>
	<dl>
		<dt><?php esc_html_e( 'Email', 'monstera' ); ?></dt>
		<dd><a href="mailto:<?php echo esc_attr( $contact ); ?>"><?php echo esc_html( $contact ); ?></a></dd>
	</dl>
	<p><?php esc_html_e( 'We aim to respond within ten working days.', 'monstera' ); ?></p>

	<h2><?php esc_html_e( 'Enforcement', 'monstera' ); ?></h2>
	<p>
		<?php esc_html_e( 'If you are not satisfied with our response, you can contact the authority responsible for enforcing accessibility requirements in your country.', 'monstera' ); ?>
	</p>

	<h2><?php esc_html_e( 'About this statement', 'monstera' ); ?></h2>
	<p>
		<?php if ( $reviewedTs ) : ?>
			<?php
			printf(
				/* translators: %s: date */
				esc_html__( 'This statement was last reviewed on %s.', 'monstera' ),
				'<time datetime="' . esc_attr( $reviewed ) . '">' . esc_html( wp_date( get_option( 'date_format' ), $reviewedTs ) ) . '</time>'
			);
			?>
		<?php else : ?>
			<?php esc_html_e( 'This statement has not yet been formally reviewed.', 'monstera' ); ?>
		<?php endif; ?>
		<?php
		printf(
			/* translators: %s: plugin version */
			' ' . esc_html__( 'The portal runs Monstera %s.', 'monstera' ),
			esc_html( MONSTERA_VERSION )
		);
		?>
	</p>
</article>
</div>
