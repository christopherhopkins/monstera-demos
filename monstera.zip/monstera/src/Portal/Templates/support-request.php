<?php
/**
 * Support — one request (/portal/support/{REF}/, comp 86).
 *
 * The guard lets only the member who opened it through. The head says where
 * it stands; the conversation runs oldest first: the opening message, the
 * replies, and one sentence for each change of status or priority. Images
 * show as thumbnails, other files as rows, each a signed link. Under it the
 * reply form, with the picker holding its files until the send; in the rail
 * the facts, the priority (the new request's four choices), "Mark resolved"
 * and where email goes. A closed request keeps the reply form as the way to
 * reopen it (the priority and "Mark resolved" wait until it is open). A closed
 * request keeps its conversation and offers a new request instead.
 *
 * A write reloads the page, which says once what was done: ?sent=1 after
 * the request itself, ?replied=<message>, ?priority=1, ?resolved=1.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Content\Downloader;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Portal\SupportPages;
use Monstera\Portal\SupportView;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Support\Files;
use Monstera\Support\Inbox;
use Monstera\Support\Repository as SupportRepository;
use Monstera\Support\Thread;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::SUPPORT ) ) {
	include __DIR__ . '/_support-off.php';
	return;
}

$user    = $ctx['user'];
$userId  = (int) $user->ID;
$request = SupportPages::ownRequest( $userId, (string) get_query_var( Routing::PARAM_REF ) );
if ( ! $request ) {
	// The guard answers this address for anyone but the request's member.
	return;
}

$requestId = (int) $request['id'];
$ref       = (string) $request['ref'];
$stands    = (string) $request['status'];
$closed    = SupportRepository::STATUS_CLOSED === $stands;
$waiting   = SupportRepository::STATUS_PENDING === $stands;
$resolved  = SupportRepository::STATUS_RESOLVED === $stands;
$thread    = ( new SupportRepository() )->thread( $requestId );
$files     = ( new Files() )->forRequest( $requestId );
$email     = Inbox::email();
$openedAt  = (int) strtotime( (string) $request['created_at'] . ' UTC' );
$api       = 'monstera/v1/support/requests/mine/' . $requestId . '/';
$failed    = __( 'That did not go through. Check your connection and try again.', 'monstera' );
// What sending a reply does to the request, beside the button.
$replyNote = __( 'We\'ll see it with your request.', 'monstera' );
if ( $closed ) {
	$replyNote = __( 'Sending opens the request again.', 'monstera' );
} elseif ( $waiting || $resolved ) {
	$replyNote = __( 'A reply opens the request again.', 'monstera' );
}

// The opening message heads the conversation as its first entry.
$entries  = array_merge(
	[
		[
			'id'         => 0,
			'kind'       => Thread::KIND_MESSAGE,
			'author_id'  => (int) $request['member_id'],
			'side'       => Thread::SIDE_MEMBER,
			'body'       => (string) $request['body'],
			'event'      => null,
			'created_at' => gmdate( 'Y-m-d\TH:i:s\Z', $openedAt ),
		],
	],
	$thread
);
$messages = count( array_filter( $entries, static fn ( array $entry ): bool => Thread::KIND_MESSAGE === $entry['kind'] ) );

$projectId    = (int) ( $request['project_id'] ?? 0 );
$projectTitle = $projectId ? (string) get_the_title( $projectId ) : '';
// Linked while the member can still open it.
$projectOpen = $projectTitle && Modules::isActive( Modules::PROJECTS ) && ( new ProjectRepository() )->userCanAccess( $userId, $projectId );

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only: what the page says after a write that has already happened.
$sent  = isset( $_GET['sent'] );
$flash = SupportView::flash( $request, $thread, $userId, $_GET );
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$photo    = (int) get_user_meta( $userId, UserMeta::KEY_PROFILE_PHOTO, true );
$photoUrl = $photo ? (string) wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
?>

<div class="monstera-portal__dash">
	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>"><?php esc_html_e( 'Support', 'monstera' ); ?></a>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo esc_html( $ref ); ?></span>
	</nav>

	<header class="m-project-head">
		<div class="m-project-head__kickers">
			<span class="m-badge" data-tone="<?php echo esc_attr( SupportView::statusTone( $stands ) ); ?>"><?php echo esc_html( SupportView::statusLabel( $stands ) ); ?></span>
			<span class="m-badge" data-tone="neutral"><?php echo esc_html( SupportView::priorityLine( (string) $request['priority'] ) ); ?></span>
		</div>
		<h1><?php echo esc_html( (string) $request['subject'] ); ?></h1>
		<p class="m-project-head__scope">
			<?php
			$openedOn    = '<time datetime="' . esc_attr( gmdate( 'c', $openedAt ) ) . '">' . esc_html( (string) wp_date( 'M j', $openedAt ) ) . '</time>';
			$projectName = $projectOpen
				? '<a href="' . esc_url( Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $projectId ] ) ) . '">' . esc_html( $projectTitle ) . '</a>'
				: esc_html( $projectTitle );
			echo wp_kses(
				$projectTitle
					/* translators: 1: a project's title, 2: a date, e.g. "Sep 29" */
					? sprintf( esc_html__( 'About %1$s · opened %2$s', 'monstera' ), $projectName, $openedOn )
					/* translators: %s: when, e.g. "Sep 29" or "Sep 29, 2:14pm" */
					: sprintf( esc_html__( 'Opened %s', 'monstera' ), $openedOn ),
				[
					'a'    => [ 'href' => [] ],
					'time' => [ 'datetime' => [] ],
				]
			);
			?>
		</p>
	</header>

	<?php if ( $sent ) : ?>
		<section class="m-confirm" role="status" aria-live="polite">
			<?php Icons::sprig(); ?>
			<h2><?php /* translators: %s: the request reference (wrapped in a mono span) */ printf( esc_html__( 'Request %s sent.', 'monstera' ), '<span class="m-mono">' . esc_html( $ref ) . '</span>' ); ?></h2>
			<p>
				<?php
				/* translators: %s: the member's email address (wrapped in <strong>) */
				printf( esc_html__( 'We\'ll reply here and to %s. Quote the reference if you write to us another way.', 'monstera' ), '<strong>' . esc_html( $user->user_email ) . '</strong>' );
				?>
			</p>
		</section>
	<?php elseif ( $flash ) : ?>
		<p class="m-toast" data-wp-init="callbacks.flash"><?php Icons::emit( 'check', 18 ); ?><span><strong><?php echo esc_html( $flash[0] ); ?></strong> <?php echo esc_html( $flash[1] ); ?></span></p>
	<?php endif; ?>
	<p class="m-sr-only" role="status" aria-live="polite" data-flash-status></p>

	<div class="m-dash">
		<div class="m-dash__main">
			<?php if ( $waiting ) : ?>
				<p class="m-band" data-lead><span><strong><?php echo esc_html( SupportView::waitingLine( $thread ) ); ?></strong>
					<?php
					printf(
						/* translators: %s: "mark it resolved", a link to that control */
						esc_html__( 'Reply below, or %s if the fix worked.', 'monstera' ),
						'<a href="#sr-resolve">' . esc_html__( 'mark it resolved', 'monstera' ) . '</a>'
					);
					?>
				</span></p>
			<?php endif; ?>

			<section class="m-section" aria-labelledby="sr-thread">
				<div class="m-section__head">
					<h2 id="sr-thread"><?php esc_html_e( 'Conversation', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono"><?php /* translators: %d: how many messages a conversation has */ echo esc_html( sprintf( _n( '%d message', '%d messages', $messages, 'monstera' ), $messages ) ); ?></span>
				</div>
				<ol class="m-thread" data-wp-on--click="actions.threadFileClick" data-files-url="<?php echo esc_url( Routing::restUrl( $api . 'files' ) ); ?>">
					<?php foreach ( $entries as $entry ) : ?>
						<?php
						$entryId   = (int) $entry['id'];
						$entryTime = (int) strtotime( (string) $entry['created_at'] );
						?>
						<?php if ( Thread::KIND_MESSAGE !== $entry['kind'] ) : ?>
							<?php $entryTone = SupportView::eventTone( $entry ); ?>
							<li class="m-thread__event">
								<span class="m-thread__dot"<?php echo $entryTone ? ' data-tone="' . esc_attr( $entryTone ) . '"' : ''; ?> aria-hidden="true"></span>
								<p class="m-thread__note"><span><?php echo wp_kses( SupportView::eventHtml( $entry, $userId ), [ 'strong' => [] ] ); ?></span><time datetime="<?php echo esc_attr( gmdate( 'c', $entryTime ) ); ?>"><?php echo esc_html( SupportView::stamp( (string) $entry['created_at'] ) ); ?></time></p>
							</li>
						<?php else : ?>
							<?php
							$entryStaff  = Thread::SIDE_STAFF === $entry['side'];
							$entryImages = array_values( array_filter( $files[ $entryId ] ?? [], static fn ( array $file ): bool => (bool) $file['is_image'] ) );
							$entryOthers = array_values( array_filter( $files[ $entryId ] ?? [], static fn ( array $file ): bool => ! $file['is_image'] ) );
							?>
							<li class="m-thread__msg" data-side="<?php echo $entryStaff ? 'staff' : 'member'; ?>" id="msg-<?php echo (int) $entryId; ?>">
								<?php if ( $entryStaff ) : ?>
									<span class="m-avatar" data-size="md" data-staff aria-hidden="true"><?php Icons::sprig(); ?></span>
								<?php else : ?>
									<span class="m-avatar" data-size="md" aria-hidden="true">
										<?php if ( $photoUrl && (int) $entry['author_id'] === $userId ) : ?>
											<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
										<?php else : ?>
											<?php Icons::emit( 'sprout', 22 ); ?>
										<?php endif; ?>
									</span>
								<?php endif; ?>
								<article class="m-thread__letter" aria-labelledby="msg-<?php echo (int) $entryId; ?>-who">
									<header class="m-thread__head">
										<h3 class="m-thread__who" id="msg-<?php echo (int) $entryId; ?>-who"><?php echo esc_html( SupportView::author( $entry, $userId ) ); ?></h3>
										<span class="m-thread__side"><?php echo esc_html( SupportView::role( $entry, 0 === $entryId ) ); ?></span>
										<time class="m-thread__when" datetime="<?php echo esc_attr( gmdate( 'c', $entryTime ) ); ?>"><?php echo esc_html( SupportView::stamp( (string) $entry['created_at'] ) ); ?></time>
									</header>
									<div class="m-thread__body"><?php echo SupportView::bodyHtml( (string) $entry['body'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped, then only its paragraphs and links added. ?></div>
									<?php if ( $entryImages || $entryOthers ) : ?>
										<div class="m-thread__files">
											<?php if ( $entryImages ) : ?>
												<ul class="m-thumbs" aria-label="<?php esc_attr_e( 'Images', 'monstera' ); ?>">
													<?php foreach ( $entryImages as $image ) : ?>
														<?php $imageUrl = Downloader::signedUrl( (int) $image['id'], $userId ); ?>
														<li><a class="m-thumb" href="<?php echo esc_url( $imageUrl ); ?>" target="_blank" data-file-id="<?php echo (int) $image['id']; ?>"><span class="m-thumb__img"><img src="<?php echo esc_url( $imageUrl ); ?>" alt="" loading="lazy" decoding="async" /></span><span class="m-thumb__name"><?php echo esc_html( (string) $image['name'] ); ?></span><span class="m-thumb__size"><?php echo esc_html( (string) size_format( (int) $image['size'] ) ); ?><span class="m-sr-only">, <?php esc_html_e( 'opens in a new tab', 'monstera' ); ?></span></span></a></li>
													<?php endforeach; ?>
												</ul>
											<?php endif; ?>
											<?php if ( $entryOthers ) : ?>
												<ul class="m-files" aria-label="<?php esc_attr_e( 'Files', 'monstera' ); ?>">
													<?php foreach ( $entryOthers as $other ) : ?>
														<li class="m-files__row" data-file-id="<?php echo (int) $other['id']; ?>">
															<span class="m-files__kind" aria-hidden="true"><?php echo esc_html( substr( strtolower( (string) pathinfo( (string) $other['name'], PATHINFO_EXTENSION ) ), 0, 4 ) ?: __( 'file', 'monstera' ) ); ?></span>
															<a class="m-files__name" href="<?php echo esc_url( Downloader::signedUrl( (int) $other['id'], $userId ) ); ?>" download><?php echo esc_html( (string) $other['name'] ); ?></a>
															<span class="m-files__meta"><span><?php echo esc_html( (string) size_format( (int) $other['size'] ) ); ?></span></span>
														</li>
													<?php endforeach; ?>
												</ul>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</article>
							</li>
						<?php endif; ?>
					<?php endforeach; ?>
				</ol>
			</section>

			<?php if ( $closed ) : ?>
				<?php // A closed request that comes back is reopened by a reply, so its history stays with it. ?>
				<div class="m-closed-line">
					<?php Icons::sprig(); ?>
					<p><?php esc_html_e( 'This request is closed. If it has come back, reply below and it opens again. For something else, open a new request.', 'monstera' ); ?></p>
					<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW ) ); ?>"><?php esc_html_e( 'New request', 'monstera' ); ?></a>
				</div>
			<?php endif; ?>

			<form
				method="post"
				enctype="multipart/form-data"
				class="m-form m-reply"
				data-plain
				aria-labelledby="sr-reply"
				action="<?php echo esc_url( Routing::restUrl( $api . 'reply' ) ); ?>"
				data-wp-on--submit="actions.submitSupportReply"
				<?php foreach ( SupportView::fileFormAttributes( __( 'Goes with your reply', 'monstera' ) ) as $attribute => $value ) : ?>
					<?php echo esc_attr( $attribute ); ?>="<?php echo esc_attr( $value ); ?>"
				<?php endforeach; ?>>
				<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>
				<h2 id="sr-reply"><?php echo esc_html( $closed ? __( 'Reopen this request', 'monstera' ) : __( 'Reply', 'monstera' ) ); ?></h2>

				<div class="m-field">
					<label class="m-field__label" for="sr-body"><?php esc_html_e( 'Your reply', 'monstera' ); ?></label>
					<textarea class="m-textarea" id="sr-body" name="body" rows="5" required></textarea>
				</div>

				<?php
				$supportFieldId = 'sr-files';
				require __DIR__ . '/partials/_support-file-field.php';
				?>

				<div class="m-form__actions">
					<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php echo esc_html( $closed ? __( 'Reopen and send', 'monstera' ) : __( 'Send reply', 'monstera' ) ); ?></button>
					<span class="m-mono"><?php echo esc_html( $replyNote ); ?></span>
				</div>
				<div class="m-sending" data-sending hidden>
					<progress max="100" value="0" aria-label="<?php esc_attr_e( 'Sending your reply', 'monstera' ); ?>"></progress>
					<span></span>
				</div>
				<p class="m-sr-only" role="status" aria-live="polite" aria-atomic="false" data-files-status></p>
			</form>
		</div>

		<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'About this request', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'This request', 'monstera' ); ?></h3>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Reference', 'monstera' ); ?></span>
					<span class="m-stat__value m-mono"><?php echo esc_html( $ref ); ?></span>
				</div>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Status', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( SupportView::statusLabel( $stands ) ); ?></span>
				</div>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Opened', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( SupportView::stamp( gmdate( 'c', $openedAt ) ) ); ?></span>
				</div>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Last activity', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( SupportView::lastActor( $thread ? $thread[ count( $thread ) - 1 ] : null, $userId ) . ' · ' . SupportView::when( $request ) ); ?></span>
				</div>
			</div>

			<?php if ( ! $closed ) : ?>
				<div class="m-rail-block">
					<h3><?php esc_html_e( 'Priority', 'monstera' ); ?></h3>
					<form class="m-priority" method="post" action="<?php echo esc_url( Routing::restUrl( $api . 'priority' ) ); ?>" data-wp-on--submit="actions.changeSupport" data-flash="priority" data-msg-failed="<?php echo esc_attr( $failed ); ?>">
						<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>
						<fieldset class="m-choices" data-stack>
							<legend><?php esc_html_e( 'How urgent is it now?', 'monstera' ); ?></legend>
							<?php foreach ( SupportView::priorityChoices() as $choice => [ $choiceName, $choiceMeans ] ) : ?>
								<label><input type="radio" name="priority" value="<?php echo esc_attr( $choice ); ?>"<?php echo $choice === $request['priority'] ? ' checked' : ''; ?> /><span><?php echo esc_html( $choiceName ); ?><small><?php echo esc_html( $choiceMeans ); ?></small></span></label>
							<?php endforeach; ?>
						</fieldset>
						<button class="m-btn" data-intent="secondary" data-size="sm" type="submit"><?php esc_html_e( 'Change priority', 'monstera' ); ?></button>
					</form>
				</div>
			<?php endif; ?>

			<?php if ( ! $closed && ! $resolved ) : ?>
				<div class="m-rail-block" id="sr-resolve">
					<h3><?php esc_html_e( 'All sorted?', 'monstera' ); ?></h3>
					<p class="m-rail-block__empty"><?php esc_html_e( 'Tell us it\'s fixed and we\'ll stop following up. A reply later opens it again.', 'monstera' ); ?></p>
					<form method="post" action="<?php echo esc_url( Routing::restUrl( $api . 'resolve' ) ); ?>" data-wp-on--submit="actions.changeSupport" data-flash="resolved" data-msg-failed="<?php echo esc_attr( $failed ); ?>">
						<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>
						<button class="m-btn" data-intent="secondary" data-size="sm" type="submit"><?php esc_html_e( 'Mark resolved', 'monstera' ); ?></button>
					</form>
				</div>
			<?php endif; ?>

			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Prefer email?', 'monstera' ); ?></h3>
				<p class="m-rail-block__empty">
					<?php
					printf(
						/* translators: 1: the support email address as a link, 2: the request's reference */
						esc_html__( 'Write to %1$s and quote %2$s. We answer email by email; it won\'t show on this page.', 'monstera' ),
						'<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>',
						esc_html( $ref )
					);
					?>
				</p>
			</div>
		</aside>
	</div>
</div>
