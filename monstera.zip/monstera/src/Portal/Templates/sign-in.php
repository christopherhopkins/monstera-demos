<?php
/**
 * Sign in — the portal's own form (2026-09 design review, comp 30).
 *
 * Posts to wp-login.php with a marker field; AccessControl\SignIn returns a
 * failed attempt here with ?failed=1 so the error renders inline. Password
 * reset stays on wp-login.php. Rendered inside the public shell.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\SignIn;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Portal\Audience;

defined( 'ABSPATH' ) || exit;

$siteName = Audience::siteName();
$failed   = isset( $_GET['failed'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag set by our own redirect; nothing is written.
$redirect = isset( $_GET['redirect_to'] ) ? esc_url_raw( (string) wp_unslash( $_GET['redirect_to'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing parameter carried into the form.
if ( '' === $redirect ) {
	$redirect = Routing::url( Routing::ROUTE_DASHBOARD );
}
$lostUrl = add_query_arg( 'action', 'lostpassword', site_url( 'wp-login.php', 'login' ) );
$contact = (string) get_option( 'admin_email' );
?>
<div class="m-auth">
	<form class="m-auth__form" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post" novalidate>
		<h1>
			<?php
			/* translators: %s: site name */
			printf( esc_html__( 'Sign in to %s.', 'monstera' ), esc_html( $siteName ) );
			?>
		</h1>
		<p><?php esc_html_e( 'Use the email address your invitation was sent to.', 'monstera' ); ?></p>

		<?php if ( $failed ) : ?>
			<p class="m-auth__error" id="auth-error" role="alert">
				<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="10" cy="10" r="8"/><path d="M10 6v5M10 13.5v.5"/></svg>
				<?php esc_html_e( 'That email and password did not match. Check both and try again.', 'monstera' ); ?>
			</p>
		<?php endif; ?>

		<div class="m-field"<?php echo $failed ? ' data-error' : ''; ?>>
			<label class="m-field__label" for="auth-email"><?php esc_html_e( 'Email', 'monstera' ); ?></label>
			<input class="m-input" id="auth-email" name="log" type="email" autocomplete="username" inputmode="email" spellcheck="false" required placeholder="you@example.com"<?php echo $failed ? ' aria-invalid="true" aria-describedby="auth-error"' : ''; ?> />
		</div>
		<div class="m-field"<?php echo $failed ? ' data-error' : ''; ?>>
			<label class="m-field__label" for="auth-password">
				<span><?php esc_html_e( 'Password', 'monstera' ); ?></span>
				<a href="<?php echo esc_url( $lostUrl ); ?>"><?php esc_html_e( 'Forgot it?', 'monstera' ); ?></a>
			</label>
			<input class="m-input" id="auth-password" name="pwd" type="password" autocomplete="current-password" required<?php echo $failed ? ' aria-invalid="true" aria-describedby="auth-error"' : ''; ?> />
		</div>
		<label class="m-auth__check">
			<input type="checkbox" class="m-checkbox" name="rememberme" value="forever" />
			<?php esc_html_e( 'Keep me signed in on this device', 'monstera' ); ?>
		</label>

		<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect ); ?>" />
		<input type="hidden" name="<?php echo esc_attr( SignIn::FIELD_MARKER ); ?>" value="1" />

		<button class="m-btn m-auth__submit" data-intent="primary" data-size="lg" type="submit"><?php esc_html_e( 'Sign in', 'monstera' ); ?></button>

		<p class="m-auth__foot">
			<?php
			printf(
				/* translators: %s: a mailto link to the site's team */
				esc_html__( 'Don\'t have access yet? Ask the person who manages your membership, or %s.', 'monstera' ),
				'<a href="mailto:' . esc_attr( $contact ) . '">' . esc_html( sprintf( /* translators: %s: site name */ __( 'ask the %s team', 'monstera' ), $siteName ) ) . '</a>'
			);
			?>
		</p>
	</form>

	<aside class="m-auth__aside" aria-hidden="true">
		<?php Icons::sprig(); ?>
		<p><?php esc_html_e( 'Everything shared with you, in one quiet place.', 'monstera' ); ?></p>
	</aside>
</div>
