<?php
/**
 * Portal shell — opening markup.
 * Renders <html>, <head>, header with brand + nav, theme attribute.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Alerts\Expiry;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertsRepository;
use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Roster;
use Monstera\Portal\Context;
use Monstera\Projects\Repository as ProjectRepository;

defined( 'ABSPATH' ) || exit;

$user  = $ctx['user'];
$theme = $ctx['theme'];
$route = $ctx['route'];

// The organizations the chip's switcher lists, for a person in several
// (People-model track, FR5): asked first, because the answer arrives with
// every organization of theirs read together, and what this file asks of them
// below (the context one's name, which of them is live) then costs nothing
// more. Empty for everyone whose chip stays the link it was: a person in one
// organization, a standalone member, staff.
$switcherOrgs = Context::switcherOrgs( $user );

/**
 * The organization the page is about is the context organization, and
 * Portal\Context alone says which that is: the hub's when the viewer belongs
 * to it or is staff, a project's when they may open the project, a content
 * item's among the viewer's, the one a support request of theirs was filed
 * with, else the viewer's primary one. The chip reflects where the viewer
 * is whenever that is somewhere they may be.
 *
 * Nothing is read from the address here. On a page the guard blocks, the
 * chip, the drawer's title and the suspended block below would otherwise
 * name the organization the viewer was turned away from, and say whether it
 * is suspended, around a page that withholds both; Context answers none for
 * a hub or a project that is not theirs, so the shell names none of it.
 */
$orgId   = Context::orgFor( $user, $route );
$orgName = $orgId ? get_the_title( $orgId ) : '';

// The chip and the drawer's title name the context organization, and on a
// page that has none (one the reader was turned away from, an item shared
// with everyone) what they name on the reader's dashboard: their own first.
// The bar is how a person leaves a refusal, so it stays the bar they know,
// and a person in several keeps the list (the owner's walk-through). The
// suspended block below still reads the context organization alone.
$chipOrgId = Context::chipOrgFor( $user, $route );
$chipName  = $chipOrgId ? get_the_title( $chipOrgId ) : '';
$chipSlug  = $chipOrgId ? get_post_field( 'post_name', $chipOrgId ) : '';

// One organization's link, as the switcher's panel and the drawer's section
// both print it (docs/DESIGN.md, Nav (portal)). The organization the chip
// names is marked: as the current page on its own hub, as the current one of
// the set ("true") anywhere else, so a list never names two current pages.
// On a hub the reader was turned away from none of theirs is the page, and
// the one the chip names is marked as on the dashboard. A suspended
// organization or an ended membership wears its badge after the name, the
// one its band wears on the dashboard.
$printOrgLink = static function ( array $org, string $linkClass = '' ) use ( $orgId, $chipOrgId, $route ): void {
	$marks   = [
		'expired'   => __( 'Expired', 'monstera' ),
		'suspended' => __( 'Suspended', 'monstera' ),
	];
	$current = '';
	if ( $org['id'] === $chipOrgId ) {
		$current = Routing::ROUTE_ORG === $route && $org['id'] === $orgId ? 'page' : 'true';
	}
	echo '<a';
	if ( '' !== $linkClass ) {
		echo ' class="' . esc_attr( $linkClass ) . '"';
	}
	echo ' href="' . esc_url( $org['url'] ) . '"';
	if ( '' !== $current ) {
		echo ' aria-current="' . esc_attr( $current ) . '"';
	}
	echo '>' . esc_html( $org['name'] );
	if ( isset( $marks[ $org['state'] ] ) ) {
		echo ' <span class="m-badge" data-tone="' . esc_attr( $org['state'] ) . '">' . esc_html( $marks[ $org['state'] ] ) . '</span>';
	}
	echo '</a>';
};

// Suspended-org soft block surface. A page about one organization (its hub,
// a project or an item of it) wears the block when that organization is
// suspended. A page that names none is about the primary organization only
// for want of another, so for a non-staff person in several the block stands
// back there: on the dashboard always, where the bands carry each
// organization's state instead (comp 23), and on the other pages that span
// every organization (projects, directory, resources, support, profile)
// while another of theirs is live, because the block would speak for the
// first one over people, projects and resources that are not paused; the
// item-level "Download paused" still says where a download waits. With no
// other live organization the block stands, as for a person with one. Staff
// bands never carry a state (dashboard.php's $bandsCarryState has the same
// two conditions), so for staff the block stands as it always has.
//
// Over a page the reader was turned away from the block never stands. A
// request that is someone else's is about the reader's first organization
// for want of another, and the block would say "You can still read
// everything here" above the sentence that says the page is not shared with
// them, with a heading of its own beside the refusal's.
//
// Nor over an ended membership, and an ended organization is never called
// suspended. The daily StatusSync suspends every organization whose expiry
// has passed, so the two states co-occur as a matter of course; the guard
// answers expired for such an organization's pages, and the blocked page
// says "has ended" where this block would say "is suspended" and "You can
// still read everything here". On the open pages (the profile, support) of
// a person whose organization has ended, the block would call suspended an
// organization every other door answers for as ended.
$orgStatus    = $orgId ? (string) get_post_meta( $orgId, 'monstera_status', true ) : 'active';
$pageNamesOrg = in_array( $route, [ Routing::ROUTE_ORG, Routing::ROUTE_CONTENT, Routing::ROUTE_PROJECT ], true );
$isSuspended  = 'suspended' === $orgStatus
	&& ! in_array( $ctx['blocked'] ?? null, [ PortalGuard::BLOCKED_NO_ACCESS, PortalGuard::BLOCKED_EXPIRED ], true )
	&& ! ( $orgId && PortalGuard::membershipExpired( $orgId ) );
// Whether the block stands back is asked only once the organization is known
// to be suspended: the answer reads the standing of every organization of
// theirs, which a page with nothing suspended has no use for. A suspended
// organization here is one of theirs: their primary one on a page that names
// none, and on a support request's page the one the request was filed with,
// which Portal\Context answers only while they belong to it. So not being in
// exactly one here means being in several.
if ( $isSuspended && ! $pageNamesOrg && ! Context::isSingleOrg( $user ) && ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
	$isSuspended = Routing::ROUTE_DASHBOARD !== $route && ! Context::hasLiveOrgBeside( $user, $orgId );
}

/**
 * Resolve the user's primary org for nav routing (independent of the
 * "current context" $orgId resolved above). If the user belongs to exactly
 * one org, the top-bar nav routes into that org's hub tabs instead of the
 * cross-org top-level pages — Dashboard/Directory/Resources/Projects all
 * point at /portal/{slug}/?tab=… so a single-org member sees one
 * navigational layer, not two.
 *
 * Users without a primary org (admins, standalone members) keep the
 * cross-org nav — they have legitimate reasons to see the personal
 * dashboard, full directory, etc. So does a person in several organizations
 * (People-model track, FR5): their dashboard, directory and resources span
 * all of them, and the chip's switcher leads to each hub.
 */
$userPrimaryOrgId   = Roster::primaryOrgOf( (int) $user->ID );
$userPrimaryOrgSlug = $userPrimaryOrgId ? (string) get_post_field( 'post_name', $userPrimaryOrgId ) : '';
$navScopedToOrg     = '' !== $userPrimaryOrgSlug && Context::isSingleOrg( $user );

// Resolve the active tab from the query so the org-scoped nav links can
// light up Projects / Resources / Directory correctly on the hub.
$currentTab = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.

$orgTabUrl = static function ( string $tab ) use ( $userPrimaryOrgSlug ): string {
	$base = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $userPrimaryOrgSlug ] );
	return 'content' === $tab ? $base : add_query_arg( 'tab', $tab, $base );
};

// Active alerts visible to this user. Only query the Alerts module when
// it's enabled — disabling the module should remove the banner entirely.
$alerts = ( Modules::isActive( Modules::ALERTS ) && class_exists( AlertsRepository::class ) )
	? ( new AlertsRepository() )->visibleTo( $user )
	: [];
?>
<!doctype html>
<html <?php language_attributes(); ?> data-monstera-theme="<?php echo esc_attr( $theme ); ?>">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
	<meta name="robots" content="noindex,nofollow" />
	<title><?php echo esc_html( wp_get_document_title() ); ?> · <?php bloginfo( 'name' ); ?></title>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'monstera-portal' ); ?>
	data-wp-interactive="monstera">

	<a class="m-skip" href="#monstera-main">
		<?php esc_html_e( 'Skip to main content', 'monstera' ); ?>
	</a>

	<?php // The bar's height follows its rows; the store hands its bottom edge to the hub's tab strip (callbacks.watchTopbar). ?>
	<header class="m-topbar" role="banner" data-wp-init="callbacks.watchTopbar">
		<a class="m-topbar__brand" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>">
			<?php Icons::emit( 'leaf-mark', 28 ); ?>
			<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		</a>
		<?php if ( $switcherOrgs && $chipName ) : ?>
			<?php
			// A person in several organizations: the chip is a disclosure, not
			// a link. The button names the context organization, or their
			// first on a page that has none, and opens a list of plain links
			// to every hub of theirs, then the dashboard, which spans them
			// all; no menu roles, so Tab walks it as it walks any links (the
			// store's toggleSwitcher has the rest).
			//
			// The list is the store's to open, so the button also works
			// without it: it is the submit of a form that sends nothing and
			// whose address is the dashboard, where a band lists each of
			// their organizations. With scripting off, or before the page's
			// script is there, the press leads to every hub by that page;
			// the store takes the click and opens the list instead. The form
			// is the anchor the list hangs from, and a block, which the
			// panel's div and its list need around them.
			?>
			<div class="m-switcher" data-label="<?php esc_attr_e( 'Organization', 'monstera' ); ?>">
				<form class="m-switcher__anchor" method="get" action="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>">
					<?php /* translators: read to screen readers before the name of the organization the page is about, on the button that lists the person's organizations. */ ?>
					<button class="m-topbar__org" type="submit" aria-expanded="false" aria-controls="m-switcher-panel" data-wp-on--click="actions.toggleSwitcher"><span class="m-sr-only"><?php esc_html_e( 'Switch organization:', 'monstera' ); ?> </span><span class="m-topbar__org-name"><?php echo esc_html( $chipName ); ?></span><svg class="m-topbar__org-caret" viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M6 8l4 4 4-4"/></svg></button>
					<div class="m-switcher__panel" id="m-switcher-panel" hidden>
						<ul class="m-switcher__list">
							<?php foreach ( $switcherOrgs as $switcherOrg ) : ?>
								<li><?php $printOrgLink( $switcherOrg, 'm-switcher__link' ); ?></li>
							<?php endforeach; ?>
						</ul>
						<a class="m-switcher__all" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"<?php echo Routing::ROUTE_DASHBOARD === $route ? ' aria-current="page"' : ''; ?>><?php esc_html_e( 'Your Portal', 'monstera' ); ?></a>
					</div>
				</form>
				<?php
				// Under the open list, over the page: the click outside that
				// closes the list lands here, so nothing the list half covers
				// (the notices line on a phone, a hub's tabs) is a target with
				// a sliver left to aim at. It listens for itself: Safari on a
				// phone sends no click for a tap on a plain element with no
				// listener of its own, and the page's listener would never
				// hear the tap that closes the list.
				?>
				<span class="m-switcher__scrim" hidden data-wp-on--click="actions.closeSwitcher"></span>
			</div>
		<?php elseif ( $chipName && $chipSlug ) : ?>
			<a class="m-topbar__org"
				href="<?php echo esc_url( Routing::url( Routing::ROUTE_ORG, [ 'slug' => $chipSlug ] ) ); ?>"
				data-label="<?php esc_attr_e( 'Organization', 'monstera' ); ?>"
				aria-label="
				<?php
					/* translators: %s: organization name */
					printf( esc_attr__( 'Open the %s page', 'monstera' ), esc_attr( $chipName ) );
				?>
				">
				<?php echo esc_html( $chipName ); ?>
			</a>
		<?php elseif ( $chipName ) : ?>
			<span class="m-topbar__org" data-label="<?php esc_attr_e( 'Organization', 'monstera' ); ?>"><?php echo esc_html( $chipName ); ?></span>
		<?php endif; ?>

		<span class="m-topbar__spacer"></span>

		<?php
		$projectsEnabled = Modules::isActive( Modules::PROJECTS );
		$supportEnabled  = Modules::isActive( Modules::SUPPORT );
		$userHasProjects = $projectsEnabled
			&& class_exists( ProjectRepository::class )
			&& ( current_user_can( Capabilities::CAP_VIEW_PROJECTS ) || current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) )
			// Asked of every organization of theirs, as the list itself is
			// built: one whose first organization has no project still has
			// the item when another does.
			&& ( new ProjectRepository() )->userHasAnyProject( (int) $user->ID );

		// Helper that decides which URL each nav slot points at.
		// When the user has a primary org, route into the org hub tabs.
		// When they don't (admin / standalone), use the cross-org routes.
		$navHref = static function ( string $slot ) use ( $navScopedToOrg, $orgTabUrl ): string {
			if ( $navScopedToOrg ) {
				return $orgTabUrl( 'dashboard' === $slot ? 'content' : $slot );
			}
			return match ( $slot ) {
				'dashboard' => Routing::url( Routing::ROUTE_DASHBOARD ),
				'projects'  => Routing::url( Routing::ROUTE_PROJECTS ),
				'directory' => Routing::url( Routing::ROUTE_DIRECTORY ),
				'resources' => Routing::url( Routing::ROUTE_FORMS ),
				default     => Routing::url( Routing::ROUTE_DASHBOARD ),
			};
		};

		/**
		 * Which slot is the user currently looking at?
		 *
		 * Two coordinate systems to combine:
		 *  - the route ($route — dashboard, org, projects, directory, forms, …)
		 *  - the org-hub tab ($currentTab — content, projects, members, resources, …)
		 *
		 * For org-routed navs, the *tab* drives active state.
		 * For cross-org navs, the *route* drives active state.
		 */
		$activeSlot = '';
		if ( $navScopedToOrg ) {
			if ( Routing::ROUTE_ORG === $route ) {
				$activeSlot = match ( $currentTab ) {
					'projects'  => 'projects',
					'resources' => 'resources',
					'members'   => 'directory',
					default     => 'dashboard', // content tab + no-tab default
				};
			} else {
				// The Portal at /portal/ is not the Dashboard, which is the hub
				// this nav's first item leads to (the owner's naming,
				// 2026-10-13), so on the Portal no item is the page being read.
				$activeSlot = match ( $route ) {
					Routing::ROUTE_DASHBOARD => '',
					Routing::ROUTE_CONTENT   => 'dashboard',
					Routing::ROUTE_PROJECTS  => 'projects',
					Routing::ROUTE_PROJECT   => 'projects',
					Routing::ROUTE_DIRECTORY => 'directory',
					Routing::ROUTE_FORMS     => 'resources',
					Routing::ROUTE_SUPPORT,
					Routing::ROUTE_SUPPORT_NEW,
					Routing::ROUTE_SUPPORT_REQUEST => 'support',
					Routing::ROUTE_PROFILE   => 'profile',
					default                  => '',
				};
			}
		} else {
			// The first item (Portal) stands for a hub in this nav, which has
			// no item for one. For a person in several organizations the switcher's list
			// marks a hub of theirs as the current page, so there the nav
			// gives the mark up: the bar and the drawer each name one current
			// page, not two (docs/DESIGN.md, Nav (portal)).
			$hubIsListed = Routing::ROUTE_ORG === $route && in_array( $orgId, array_column( $switcherOrgs, 'id' ), true );
			$activeSlot  = match ( $route ) {
				Routing::ROUTE_DASHBOARD => 'dashboard',
				Routing::ROUTE_ORG       => $hubIsListed ? '' : 'dashboard',
				Routing::ROUTE_CONTENT   => 'dashboard',
				Routing::ROUTE_PROJECTS  => 'projects',
				Routing::ROUTE_PROJECT   => 'projects',
				Routing::ROUTE_DIRECTORY => 'directory',
				Routing::ROUTE_FORMS     => 'resources',
				Routing::ROUTE_SUPPORT,
				Routing::ROUTE_SUPPORT_NEW,
				Routing::ROUTE_SUPPORT_REQUEST => 'support',
				Routing::ROUTE_PROFILE   => 'profile',
				default                  => '',
			};
		}

		// The nav items, once: the top bar prints them from 768 and the
		// drawer prints the same list below it. The first item says where it
		// leads: to the organization's hub, their Dashboard, for a member of
		// one organization; to the personal home at /portal/ for everyone
		// else, which is the Portal to its reader (the owner's naming,
		// 2026-10-13), as the switcher's last link says.
		$navItems   = [];
		$navItems[] = [ 'dashboard', $navHref( 'dashboard' ), $navScopedToOrg ? __( 'Dashboard', 'monstera' ) : __( 'Portal', 'monstera' ) ];
		if ( $userHasProjects ) {
			$navItems[] = [ 'projects', $navHref( 'projects' ), __( 'Projects', 'monstera' ) ];
		}
		// Directory + Resources only surface in the chrome for cross-org
		// users (admins, standalone members). For a single-org member the
		// same destinations are reachable from the org hub's tab bar
		// (Members tab + Resources tab) — surfacing them twice was the
		// visual-confusion problem fixed earlier.
		if ( ! $navScopedToOrg ) {
			if ( current_user_can( Capabilities::CAP_VIEW_DIRECTORY ) || current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) ) {
				$navItems[] = [ 'directory', $navHref( 'directory' ), __( 'Directory', 'monstera' ) ];
			}
			$navItems[] = [ 'resources', $navHref( 'resources' ), __( 'Resources', 'monstera' ) ];
		}
		if ( $supportEnabled ) {
			$navItems[] = [ 'support', Routing::url( Routing::ROUTE_SUPPORT ), __( 'Support', 'monstera' ) ];
		}
		$navItems[] = [ 'profile', Routing::url( Routing::ROUTE_PROFILE ), __( 'Profile', 'monstera' ) ];

		$printNav = static function () use ( $navItems, $activeSlot ): void {
			foreach ( $navItems as [ $slot, $href, $label ] ) {
				printf(
					'<a href="%s"%s>%s</a>',
					esc_url( $href ),
					$slot === $activeSlot ? ' aria-current="page"' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal attribute chosen by the ternary; no user data.
					esc_html( $label )
				);
			}
		};

		// The segmented theme group, printed in the top bar and again in the
		// drawer. aria-pressed mirrors the <html> theme attribute; the store
		// keeps every group in step (actions.setTheme).
		$printTheme = static function () use ( $theme ): void {
			?>
			<div class="m-theme" role="group" aria-label="<?php esc_attr_e( 'Theme', 'monstera' ); ?>">
				<button type="button" data-theme-set="light" aria-pressed="<?php echo 'dark' === $theme ? 'false' : 'true'; ?>" aria-label="<?php esc_attr_e( 'Light theme', 'monstera' ); ?>" data-wp-on--click="actions.setTheme"><?php Icons::emit( 'sun', 16 ); ?></button>
				<button type="button" data-theme-set="dark" aria-pressed="<?php echo 'dark' === $theme ? 'true' : 'false'; ?>" aria-label="<?php esc_attr_e( 'Dark theme', 'monstera' ); ?>" data-wp-on--click="actions.setTheme"><?php Icons::emit( 'moon', 16 ); ?></button>
			</div>
			<?php
		};
		?>
		<nav class="m-topbar__nav" aria-label="<?php esc_attr_e( 'Portal navigation', 'monstera' ); ?>">
			<?php $printNav(); ?>
		</nav>

		<div class="m-topbar__actions">
			<?php $printTheme(); ?>
			<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">
				<?php esc_html_e( 'Sign out', 'monstera' ); ?>
			</a>
		</div>

		<button class="m-topbar__menu" type="button" aria-controls="m-drawer" aria-expanded="false" data-wp-on--click="actions.openDrawer">
			<span class="m-sr-only"><?php esc_html_e( 'Open menu', 'monstera' ); ?></span>
			<?php Icons::emit( 'menu', 22 ); ?>
		</button>
	</header>

	<div class="m-drawer" id="m-drawer" hidden>
		<button class="m-drawer__scrim" type="button" tabindex="-1" data-wp-on--click="actions.closeDrawer">
			<span class="m-sr-only"><?php esc_html_e( 'Close menu', 'monstera' ); ?></span>
		</button>
		<div class="m-drawer__panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Menu', 'monstera' ); ?>">
			<div class="m-drawer__head">
				<span class="m-drawer__title"><?php echo esc_html( $switcherOrgs ? __( 'Menu', 'monstera' ) : ( $chipName ?: get_bloginfo( 'name' ) ) ); ?></span>
				<button class="m-drawer__close" type="button" data-wp-on--click="actions.closeDrawer" aria-label="<?php esc_attr_e( 'Close menu', 'monstera' ); ?>">×</button>
			</div>
			<nav class="m-drawer__nav" aria-label="<?php esc_attr_e( 'Portal navigation', 'monstera' ); ?>">
				<?php $printNav(); ?>
			</nav>
			<?php
			// A person in several organizations: the switcher's links again, in
			// a section of their own, and no one organization names the drawer.
			// The section opens inside this tag and its closing tag shares a
			// line with the Appearance heading, so that a drawer without the
			// section prints what it always printed, to the byte.
			if ( $switcherOrgs ) :
				?>
				<div class="m-drawer__section"><?php esc_html_e( 'Your organizations', 'monstera' ); ?></div>
				<nav class="m-drawer__nav m-drawer__orgs" aria-label="<?php esc_attr_e( 'Your organizations', 'monstera' ); ?>">
					<?php
					foreach ( $switcherOrgs as $switcherOrg ) {
						$printOrgLink( $switcherOrg );
					}
					?>
				</nav>
			<?php endif; ?><div class="m-drawer__section"><?php esc_html_e( 'Appearance', 'monstera' ); ?></div>
			<div class="m-drawer__row">
				<span><?php esc_html_e( 'Theme', 'monstera' ); ?></span>
				<?php $printTheme(); ?>
			</div>
			<div class="m-drawer__foot">
				<a class="m-btn" data-intent="secondary" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Sign out', 'monstera' ); ?></a>
			</div>
		</div>
	</div>

	<?php
	/**
	 * Under the topbar, above the nudge and the notices band, on every portal
	 * page including the blocked ones. Rendered on the server with the shell.
	 *
	 * @param string $route The portal route being rendered.
	 */
	do_action( Hooks::PORTAL_SHELL_BEFORE_NOTICES, $route );
	?>

	<?php
	// The nudge is for someone the directory lists and the profile opens for.
	// An account the portal is not for is turned away from both (the guard
	// answers every page), so it is not asked to finish a profile.
	?>
	<?php if ( Routing::ROUTE_DASHBOARD === $route && PortalGuard::isPortalAccount( $user ) && UserMeta::profileCompletionPct( (int) $user->ID ) < 80 ) : ?>
		<div class="m-nudge" role="status">
			<span>
				<?php
				printf(
					/* translators: %d: completion percentage */
					esc_html__( 'Your profile is %d%% complete.', 'monstera' ),
					(int) UserMeta::profileCompletionPct( (int) $user->ID )
				);
				?>
				<?php esc_html_e( 'A photo and a one-line bio help other members find you in the directory.', 'monstera' ); ?>
			</span>
			<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROFILE ) ); ?>"><?php esc_html_e( 'Finish profile →', 'monstera' ); ?></a>
		</div>
	<?php endif; ?>

	<?php if ( $alerts ) : ?>
		<?php
		$alertRows = [];
		foreach ( $alerts as $alert ) {
			$alertRows[] = [
				'id'          => (int) $alert->ID,
				'severity'    => (string) ( get_post_meta( $alert->ID, AlertMeta::KEY_SEVERITY, true ) ?: AlertMeta::SEVERITY_INFO ),
				'title'       => get_the_title( $alert ),
				'line'        => $alert->post_excerpt
					? wp_strip_all_tags( $alert->post_excerpt )
					: wp_trim_words( wp_strip_all_tags( $alert->post_content ), 30 ),
				'expires'     => Expiry::timestamp( (string) get_post_meta( $alert->ID, AlertMeta::KEY_EXPIRES_AT, true ) ),
				'link_url'    => (string) get_post_meta( $alert->ID, AlertMeta::KEY_LINK_URL, true ),
				'link_label'  => (string) get_post_meta( $alert->ID, AlertMeta::KEY_LINK_LABEL, true ),
				'dismissible' => (bool) get_post_meta( $alert->ID, AlertMeta::KEY_DISMISSIBLE, true ),
			];
		}
		$noticeCount   = count( $alertRows );
		$criticalCount = count( array_filter( $alertRows, static fn ( $r ) => AlertMeta::SEVERITY_CRITICAL === $r['severity'] ) );
		$moreCount     = max( 0, $noticeCount - 2 );
		?>
		<details class="m-notices" data-count="<?php echo (int) $noticeCount; ?>"
			data-wp-init="callbacks.syncNoticesOpen"
			<?php /* translators: %d: number of notices */ ?>
			data-label-notice="<?php esc_attr_e( '%d notice', 'monstera' ); ?>"
			<?php /* translators: %d: number of notices */ ?>
			data-label-notices="<?php esc_attr_e( '%d notices', 'monstera' ); ?>"
			<?php /* translators: %d: number of critical notices */ ?>
			data-label-critical="<?php esc_attr_e( '%d critical', 'monstera' ); ?>">
			<summary>
				<span class="m-notices__dots" aria-hidden="true">
					<?php foreach ( array_slice( $alertRows, 0, 3 ) as $row ) : ?>
						<span class="m-notices__dot" data-severity="<?php echo esc_attr( $row['severity'] ); ?>"></span>
					<?php endforeach; ?>
				</span>
				<span class="m-notices__summary" data-notices-summary>
					<?php
					/* translators: %d: number of notices */
					echo esc_html( sprintf( _n( '%d notice', '%d notices', $noticeCount, 'monstera' ), $noticeCount ) );
					if ( $criticalCount ) {
						/* translators: %d: number of critical notices */
						echo esc_html( ' · ' . sprintf( _n( '%d critical', '%d critical', $criticalCount, 'monstera' ), $criticalCount ) );
					}
					?>
				</span>
				<svg class="m-notices__chevron" viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M5 8l5 5 5-5"/></svg>
			</summary>
			<div class="m-notices__list" role="status">
				<?php foreach ( $alertRows as $row ) : ?>
					<div class="m-alert-row" data-severity="<?php echo esc_attr( $row['severity'] ); ?>" data-alert-row="<?php echo (int) $row['id']; ?>">
						<span class="m-alert-row__icon" aria-hidden="true">
							<?php if ( AlertMeta::SEVERITY_CRITICAL === $row['severity'] ) : ?>
								<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="10" cy="10" r="8"/><path d="M10 6v5M10 13.5v.5"/></svg>
							<?php elseif ( AlertMeta::SEVERITY_WARNING === $row['severity'] ) : ?>
								<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M10 2 18 17H2Z"/><path d="M10 8v4M10 14v.5"/></svg>
							<?php else : ?>
								<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="10" cy="10" r="8"/><path d="M10 6v.5M10 9v5"/></svg>
							<?php endif; ?>
						</span>
						<div class="m-alert-row__body">
							<strong><?php echo esc_html( $row['title'] ); ?></strong>
							<?php echo esc_html( $row['line'] ); ?>
							<?php if ( $row['expires'] ) : ?>
								<time class="m-alert-row__meta" datetime="<?php echo esc_attr( wp_date( 'c', $row['expires'] ) ); ?>">
									<?php
									/* translators: %s: alert expiry date and time, e.g. "Mar 4 · 5:30pm". */
									printf( esc_html__( 'until %s', 'monstera' ), esc_html( wp_date( 'M j · g:ia', $row['expires'] ) ) );
									?>
								</time>
							<?php endif; ?>
						</div>
						<div class="m-alert-row__actions">
							<?php if ( $row['link_url'] ) : ?>
								<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $row['link_url'] ); ?>"><?php echo esc_html( $row['link_label'] ?: __( 'More details', 'monstera' ) ); ?></a>
							<?php endif; ?>
							<?php if ( $row['dismissible'] ) : ?>
								<button
									class="m-alert-row__dismiss"
									type="button"
									data-wp-on--click="actions.dismissAlert"
									data-alert-id="<?php echo (int) $row['id']; ?>"
									aria-label="<?php esc_attr_e( 'Dismiss notice', 'monstera' ); ?>">×</button>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<button
				class="m-notices__more"
				type="button"
				aria-expanded="false"
				data-wp-on--click="actions.toggleMoreNotices"
				data-more="<?php echo (int) $moreCount; ?>"
				<?php /* translators: %d: number of notices hidden behind the line */ ?>
				data-label-one="<?php esc_attr_e( 'Show %d more notice', 'monstera' ); ?>"
				<?php /* translators: %d: number of notices hidden behind the line */ ?>
				data-label-many="<?php esc_attr_e( 'Show %d more notices', 'monstera' ); ?>"
				data-label-fewer="<?php esc_attr_e( 'Show fewer notices', 'monstera' ); ?>"
				<?php echo $moreCount ? '' : 'hidden'; ?>>
				<?php
				/* translators: %d: number of notices hidden behind the line */
				echo esc_html( sprintf( _n( 'Show %d more notice', 'Show %d more notices', $moreCount, 'monstera' ), $moreCount ) );
				?>
			</button>
		</details>
	<?php endif; ?>

	<main id="monstera-main" class="monstera-portal__main">
	<?php if ( $isSuspended ) : ?>
		<section class="m-blocked" data-soft role="region" aria-labelledby="monstera-suspended-title">
			<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
			<span class="m-badge m-blocked__reason" data-tone="suspended"><?php esc_html_e( 'Suspended', 'monstera' ); ?></span>
			<h1 id="monstera-suspended-title">
				<?php
				/* translators: %s: organization name */
				printf( esc_html__( 'The membership of %s is suspended.', 'monstera' ), esc_html( $orgName ) );
				?>
			</h1>
			<p>
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'You can still read everything here. Downloads are paused until the %s team reactivates the organization.', 'monstera' ), esc_html( \Monstera\Portal\Audience::siteName() ) );
				?>
			</p>
			<a class="m-btn m-blocked__action" data-intent="secondary" href="mailto:<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'Contact the %s team →', 'monstera' ), esc_html( \Monstera\Portal\Audience::siteName() ) );
				?>
			</a>
		</section>
	<?php endif; ?>
