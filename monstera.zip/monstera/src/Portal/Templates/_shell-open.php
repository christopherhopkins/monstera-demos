<?php
/**
 * Portal shell — opening markup.
 * Renders <html>, <head>, header with brand + nav, theme attribute.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Alerts\Expiry;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertsRepository;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;

$user  = $ctx['user'];
$theme = $ctx['theme'];
$route = $ctx['route'];

/**
 * Resolve the "current org" for the topbar chip. Priority:
 *   1. Org page route       → that org
 *   2. Content detail       → content's primary org
 *   3. Project detail       → project's org
 *   4. Fallback             → user's associated org (their home)
 * Result: the chip always reflects where the user IS, not just who they are.
 */
$contextOrgId = 0;

if ( Routing::ROUTE_ORG === $route ) {
	$paramSlug = (string) get_query_var( Routing::PARAM_ORG );
	if ( $paramSlug ) {
		$paramOrg = ( new OrgRepository() )->findBySlug( $paramSlug );
		if ( $paramOrg ) {
			$contextOrgId = (int) $paramOrg->ID;
		}
	}
}

if ( ! $contextOrgId && Routing::ROUTE_CONTENT === $route ) {
	$contentId    = (int) get_query_var( Routing::PARAM_ID );
	$contentOrgs  = array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true ) );
	$contextOrgId = $contentOrgs ? (int) $contentOrgs[0] : 0;
}

if ( ! $contextOrgId && Routing::ROUTE_PROJECT === $route ) {
	$projectId    = (int) get_query_var( Routing::PARAM_ID );
	$contextOrgId = (int) get_post_meta( $projectId, ProjectMeta::KEY_ORG_ID, true );
}

if ( ! $contextOrgId ) {
	$contextOrgId = UserMeta::associatedOrg( $user->ID );
}

$orgId   = $contextOrgId;
$orgName = $orgId ? get_the_title( $orgId ) : '';
$orgSlug = $orgId ? get_post_field( 'post_name', $orgId ) : '';

// Suspended-org soft block surface.
$orgStatus   = $orgId ? (string) get_post_meta( $orgId, 'monstera_status', true ) : 'active';
$isSuspended = 'suspended' === $orgStatus;

/**
 * Resolve the user's primary org for nav routing (independent of the
 * "current context" $orgId resolved above). If the user belongs to one
 * org, the top-bar nav routes into that org's hub tabs instead of the
 * cross-org top-level pages — Dashboard/Directory/Resources/Projects all
 * point at /portal/{slug}/?tab=… so a single-org member sees one
 * navigational layer, not two.
 *
 * Users without a primary org (admins, standalone members) keep the
 * cross-org nav — they have legitimate reasons to see the personal
 * dashboard, full directory, etc.
 */
$userPrimaryOrgId   = UserMeta::associatedOrg( (int) $user->ID );
$userPrimaryOrgSlug = $userPrimaryOrgId ? (string) get_post_field( 'post_name', $userPrimaryOrgId ) : '';
$navScopedToOrg     = '' !== $userPrimaryOrgSlug;

// Resolve the active tab from the query so the org-scoped nav links can
// light up Projects / Resources / Directory correctly on the hub.
$currentTab = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.

$orgTabUrl = static function ( string $tab ) use ( $userPrimaryOrgSlug ): string {
	$base = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $userPrimaryOrgSlug ] );
	return 'content' === $tab ? $base : add_query_arg( 'tab', $tab, $base );
};

// Active alerts visible to this user. Only query the Alerts module when
// it's enabled — disabling the module should remove the banner entirely.
$alerts = ( Modules::isActive( Modules::ALERTS ) && class_exists( AlertsRepository::class ) )
	? ( new AlertsRepository() )->visibleTo( $user )
	: [];
?>
<!doctype html>
<html <?php language_attributes(); ?> data-monstera-theme="<?php echo esc_attr( $theme ); ?>">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
	<meta name="robots" content="noindex,nofollow" />
	<title><?php echo esc_html( wp_get_document_title() ); ?> · <?php bloginfo( 'name' ); ?></title>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'monstera-portal' ); ?>
	data-wp-interactive="monstera">

	<a class="m-skip" href="#monstera-main">
		<?php esc_html_e( 'Skip to main content', 'monstera' ); ?>
	</a>

	<header class="m-topbar" role="banner">
		<a class="m-topbar__brand" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>">
			<?php Icons::emit( 'leaf-mark', 28 ); ?>
			<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		</a>
		<?php if ( $orgName && $orgSlug ) : ?>
			<a class="m-topbar__org"
				href="<?php echo esc_url( Routing::url( Routing::ROUTE_ORG, [ 'slug' => $orgSlug ] ) ); ?>"
				data-label="<?php esc_attr_e( 'Organization', 'monstera' ); ?>"
				aria-label="
				<?php
					/* translators: %s: organization name */
					printf( esc_attr__( 'Open the %s page', 'monstera' ), esc_attr( $orgName ) );
				?>
				">
				<?php echo esc_html( $orgName ); ?>
			</a>
		<?php elseif ( $orgName ) : ?>
			<span class="m-topbar__org" data-label="<?php esc_attr_e( 'Organization', 'monstera' ); ?>"><?php echo esc_html( $orgName ); ?></span>
		<?php endif; ?>

		<span class="m-topbar__spacer"></span>

		<?php
		$projectsEnabled = Modules::isActive( Modules::PROJECTS );
		$supportEnabled  = Modules::isActive( Modules::SUPPORT );
		$userHasProjects = $projectsEnabled
			&& class_exists( ProjectRepository::class )
			&& ( current_user_can( Capabilities::CAP_VIEW_PROJECTS ) || current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) )
			&& ( new ProjectRepository() )->userHasAnyProject( (int) $user->ID, $userPrimaryOrgId );

		// Helper that decides which URL each nav slot points at.
		// When the user has a primary org, route into the org hub tabs.
		// When they don't (admin / standalone), use the cross-org routes.
		$navHref = static function ( string $slot ) use ( $navScopedToOrg, $orgTabUrl ): string {
			if ( $navScopedToOrg ) {
				return $orgTabUrl( 'dashboard' === $slot ? 'content' : $slot );
			}
			return match ( $slot ) {
				'dashboard' => Routing::url( Routing::ROUTE_DASHBOARD ),
				'projects'  => Routing::url( Routing::ROUTE_PROJECTS ),
				'directory' => Routing::url( Routing::ROUTE_DIRECTORY ),
				'resources' => Routing::url( Routing::ROUTE_FORMS ),
				default     => Routing::url( Routing::ROUTE_DASHBOARD ),
			};
		};

		/**
		 * Which slot is the user currently looking at?
		 *
		 * Two coordinate systems to combine:
		 *  - the route ($route — dashboard, org, projects, directory, forms, …)
		 *  - the org-hub tab ($currentTab — content, projects, members, resources, …)
		 *
		 * For org-routed navs, the *tab* drives active state.
		 * For cross-org navs, the *route* drives active state.
		 */
		$activeSlot = '';
		if ( $navScopedToOrg ) {
			if ( Routing::ROUTE_ORG === $route ) {
				$activeSlot = match ( $currentTab ) {
					'projects'  => 'projects',
					'resources' => 'resources',
					'members'   => 'directory',
					default     => 'dashboard', // content tab + no-tab default
				};
			} else {
				$activeSlot = match ( $route ) {
					Routing::ROUTE_DASHBOARD => 'dashboard',
					Routing::ROUTE_CONTENT   => 'dashboard',
					Routing::ROUTE_PROJECTS  => 'projects',
					Routing::ROUTE_PROJECT   => 'projects',
					Routing::ROUTE_DIRECTORY => 'directory',
					Routing::ROUTE_FORMS     => 'resources',
					Routing::ROUTE_SUPPORT   => 'support',
					Routing::ROUTE_PROFILE   => 'profile',
					default                  => '',
				};
			}
		} else {
			$activeSlot = match ( $route ) {
				Routing::ROUTE_DASHBOARD => 'dashboard',
				Routing::ROUTE_ORG       => 'dashboard',
				Routing::ROUTE_CONTENT   => 'dashboard',
				Routing::ROUTE_PROJECTS  => 'projects',
				Routing::ROUTE_PROJECT   => 'projects',
				Routing::ROUTE_DIRECTORY => 'directory',
				Routing::ROUTE_FORMS     => 'resources',
				Routing::ROUTE_SUPPORT   => 'support',
				Routing::ROUTE_PROFILE   => 'profile',
				default                  => '',
			};
		}

		// The nav items, once: the top bar prints them from 768 and the
		// drawer prints the same list below it.
		$navItems   = [];
		$navItems[] = [ 'dashboard', $navHref( 'dashboard' ), __( 'Dashboard', 'monstera' ) ];
		if ( $userHasProjects ) {
			$navItems[] = [ 'projects', $navHref( 'projects' ), __( 'Projects', 'monstera' ) ];
		}
		// Directory + Resources only surface in the chrome for cross-org
		// users (admins, standalone members). For a single-org member the
		// same destinations are reachable from the org hub's tab bar
		// (Members tab + Resources tab) — surfacing them twice was the
		// visual-confusion problem fixed earlier.
		if ( ! $navScopedToOrg ) {
			if ( current_user_can( Capabilities::CAP_VIEW_DIRECTORY ) || current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) ) {
				$navItems[] = [ 'directory', $navHref( 'directory' ), __( 'Directory', 'monstera' ) ];
			}
			$navItems[] = [ 'resources', $navHref( 'resources' ), __( 'Resources', 'monstera' ) ];
		}
		if ( $supportEnabled ) {
			$navItems[] = [ 'support', Routing::url( Routing::ROUTE_SUPPORT ), __( 'Support', 'monstera' ) ];
		}
		$navItems[] = [ 'profile', Routing::url( Routing::ROUTE_PROFILE ), __( 'Profile', 'monstera' ) ];

		$printNav = static function () use ( $navItems, $activeSlot ): void {
			foreach ( $navItems as [ $slot, $href, $label ] ) {
				printf(
					'<a href="%s"%s>%s</a>',
					esc_url( $href ),
					$slot === $activeSlot ? ' aria-current="page"' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal attribute chosen by the ternary; no user data.
					esc_html( $label )
				);
			}
		};

		// The segmented theme group, printed in the top bar and again in the
		// drawer. aria-pressed mirrors the <html> theme attribute; the store
		// keeps every group in step (actions.setTheme).
		$printTheme = static function () use ( $theme ): void {
			?>
			<div class="m-theme" role="group" aria-label="<?php esc_attr_e( 'Theme', 'monstera' ); ?>">
				<button type="button" data-theme-set="light" aria-pressed="<?php echo 'dark' === $theme ? 'false' : 'true'; ?>" aria-label="<?php esc_attr_e( 'Light theme', 'monstera' ); ?>" data-wp-on--click="actions.setTheme"><?php Icons::emit( 'sun', 16 ); ?></button>
				<button type="button" data-theme-set="dark" aria-pressed="<?php echo 'dark' === $theme ? 'true' : 'false'; ?>" aria-label="<?php esc_attr_e( 'Dark theme', 'monstera' ); ?>" data-wp-on--click="actions.setTheme"><?php Icons::emit( 'moon', 16 ); ?></button>
			</div>
			<?php
		};
		?>
		<nav class="m-topbar__nav" aria-label="<?php esc_attr_e( 'Portal navigation', 'monstera' ); ?>">
			<?php $printNav(); ?>
		</nav>

		<div class="m-topbar__actions">
			<?php $printTheme(); ?>
			<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">
				<?php esc_html_e( 'Sign out', 'monstera' ); ?>
			</a>
		</div>

		<button class="m-topbar__menu" type="button" aria-controls="m-drawer" aria-expanded="false" data-wp-on--click="actions.openDrawer">
			<span class="m-sr-only"><?php esc_html_e( 'Open menu', 'monstera' ); ?></span>
			<?php Icons::emit( 'menu', 22 ); ?>
		</button>
	</header>

	<div class="m-drawer" id="m-drawer" hidden>
		<button class="m-drawer__scrim" type="button" tabindex="-1" data-wp-on--click="actions.closeDrawer">
			<span class="m-sr-only"><?php esc_html_e( 'Close menu', 'monstera' ); ?></span>
		</button>
		<div class="m-drawer__panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Menu', 'monstera' ); ?>">
			<div class="m-drawer__head">
				<span class="m-drawer__title"><?php echo esc_html( $orgName ?: get_bloginfo( 'name' ) ); ?></span>
				<button class="m-drawer__close" type="button" data-wp-on--click="actions.closeDrawer" aria-label="<?php esc_attr_e( 'Close menu', 'monstera' ); ?>">×</button>
			</div>
			<nav class="m-drawer__nav" aria-label="<?php esc_attr_e( 'Portal navigation', 'monstera' ); ?>">
				<?php $printNav(); ?>
			</nav>
			<div class="m-drawer__section"><?php esc_html_e( 'Appearance', 'monstera' ); ?></div>
			<div class="m-drawer__row">
				<span><?php esc_html_e( 'Theme', 'monstera' ); ?></span>
				<?php $printTheme(); ?>
			</div>
			<div class="m-drawer__foot">
				<a class="m-btn" data-intent="secondary" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Sign out', 'monstera' ); ?></a>
			</div>
		</div>
	</div>

	<?php
	/**
	 * Under the topbar, above the nudge and the notices band, on every portal
	 * page including the blocked ones. Rendered on the server with the shell.
	 *
	 * @param string $route The portal route being rendered.
	 */
	do_action( Hooks::PORTAL_SHELL_BEFORE_NOTICES, $route );
	?>

	<?php if ( Routing::ROUTE_DASHBOARD === $route && UserMeta::profileCompletionPct( (int) $user->ID ) < 80 ) : ?>
		<div class="m-nudge" role="status">
			<span>
				<?php
				printf(
					/* translators: %d: completion percentage */
					esc_html__( 'Your profile is %d%% complete.', 'monstera' ),
					(int) UserMeta::profileCompletionPct( (int) $user->ID )
				);
				?>
				<?php esc_html_e( 'A photo and a one-line bio help other members find you in the directory.', 'monstera' ); ?>
			</span>
			<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROFILE ) ); ?>"><?php esc_html_e( 'Finish profile →', 'monstera' ); ?></a>
		</div>
	<?php endif; ?>

	<?php if ( $alerts ) : ?>
		<?php
		$alertRows = [];
		foreach ( $alerts as $alert ) {
			$alertRows[] = [
				'id'          => (int) $alert->ID,
				'severity'    => (string) ( get_post_meta( $alert->ID, AlertMeta::KEY_SEVERITY, true ) ?: AlertMeta::SEVERITY_INFO ),
				'title'       => get_the_title( $alert ),
				'line'        => $alert->post_excerpt
					? wp_strip_all_tags( $alert->post_excerpt )
					: wp_trim_words( wp_strip_all_tags( $alert->post_content ), 30 ),
				'expires'     => Expiry::timestamp( (string) get_post_meta( $alert->ID, AlertMeta::KEY_EXPIRES_AT, true ) ),
				'link_url'    => (string) get_post_meta( $alert->ID, AlertMeta::KEY_LINK_URL, true ),
				'link_label'  => (string) get_post_meta( $alert->ID, AlertMeta::KEY_LINK_LABEL, true ),
				'dismissible' => (bool) get_post_meta( $alert->ID, AlertMeta::KEY_DISMISSIBLE, true ),
			];
		}
		$noticeCount   = count( $alertRows );
		$criticalCount = count( array_filter( $alertRows, static fn ( $r ) => AlertMeta::SEVERITY_CRITICAL === $r['severity'] ) );
		$moreCount     = max( 0, $noticeCount - 2 );
		?>
		<details class="m-notices" data-count="<?php echo (int) $noticeCount; ?>"
			data-wp-init="callbacks.syncNoticesOpen"
			<?php /* translators: %d: number of notices */ ?>
			data-label-notice="<?php esc_attr_e( '%d notice', 'monstera' ); ?>"
			<?php /* translators: %d: number of notices */ ?>
			data-label-notices="<?php esc_attr_e( '%d notices', 'monstera' ); ?>"
			<?php /* translators: %d: number of critical notices */ ?>
			data-label-critical="<?php esc_attr_e( '%d critical', 'monstera' ); ?>">
			<summary>
				<span class="m-notices__dots" aria-hidden="true">
					<?php foreach ( array_slice( $alertRows, 0, 3 ) as $row ) : ?>
						<span class="m-notices__dot" data-severity="<?php echo esc_attr( $row['severity'] ); ?>"></span>
					<?php endforeach; ?>
				</span>
				<span class="m-notices__summary" data-notices-summary>
					<?php
					/* translators: %d: number of notices */
					echo esc_html( sprintf( _n( '%d notice', '%d notices', $noticeCount, 'monstera' ), $noticeCount ) );
					if ( $criticalCount ) {
						/* translators: %d: number of critical notices */
						echo esc_html( ' · ' . sprintf( _n( '%d critical', '%d critical', $criticalCount, 'monstera' ), $criticalCount ) );
					}
					?>
				</span>
				<svg class="m-notices__chevron" viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M5 8l5 5 5-5"/></svg>
			</summary>
			<div class="m-notices__list" role="status">
				<?php foreach ( $alertRows as $row ) : ?>
					<div class="m-alert-row" data-severity="<?php echo esc_attr( $row['severity'] ); ?>" data-alert-row="<?php echo (int) $row['id']; ?>">
						<span class="m-alert-row__icon" aria-hidden="true">
							<?php if ( AlertMeta::SEVERITY_CRITICAL === $row['severity'] ) : ?>
								<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="10" cy="10" r="8"/><path d="M10 6v5M10 13.5v.5"/></svg>
							<?php elseif ( AlertMeta::SEVERITY_WARNING === $row['severity'] ) : ?>
								<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M10 2 18 17H2Z"/><path d="M10 8v4M10 14v.5"/></svg>
							<?php else : ?>
								<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="10" cy="10" r="8"/><path d="M10 6v.5M10 9v5"/></svg>
							<?php endif; ?>
						</span>
						<div class="m-alert-row__body">
							<strong><?php echo esc_html( $row['title'] ); ?></strong>
							<?php echo esc_html( $row['line'] ); ?>
							<?php if ( $row['expires'] ) : ?>
								<time class="m-alert-row__meta" datetime="<?php echo esc_attr( wp_date( 'c', $row['expires'] ) ); ?>">
									<?php
									/* translators: %s: alert expiry date and time, e.g. "Mar 4 · 5:30pm". */
									printf( esc_html__( 'until %s', 'monstera' ), esc_html( wp_date( 'M j · g:ia', $row['expires'] ) ) );
									?>
								</time>
							<?php endif; ?>
						</div>
						<div class="m-alert-row__actions">
							<?php if ( $row['link_url'] ) : ?>
								<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $row['link_url'] ); ?>"><?php echo esc_html( $row['link_label'] ?: __( 'More details', 'monstera' ) ); ?></a>
							<?php endif; ?>
							<?php if ( $row['dismissible'] ) : ?>
								<button
									class="m-alert-row__dismiss"
									type="button"
									data-wp-on--click="actions.dismissAlert"
									data-alert-id="<?php echo (int) $row['id']; ?>"
									aria-label="<?php esc_attr_e( 'Dismiss notice', 'monstera' ); ?>">×</button>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<button
				class="m-notices__more"
				type="button"
				aria-expanded="false"
				data-wp-on--click="actions.toggleMoreNotices"
				data-more="<?php echo (int) $moreCount; ?>"
				<?php /* translators: %d: number of notices hidden behind the line */ ?>
				data-label-one="<?php esc_attr_e( 'Show %d more notice', 'monstera' ); ?>"
				<?php /* translators: %d: number of notices hidden behind the line */ ?>
				data-label-many="<?php esc_attr_e( 'Show %d more notices', 'monstera' ); ?>"
				data-label-fewer="<?php esc_attr_e( 'Show fewer notices', 'monstera' ); ?>"
				<?php echo $moreCount ? '' : 'hidden'; ?>>
				<?php
				/* translators: %d: number of notices hidden behind the line */
				echo esc_html( sprintf( _n( 'Show %d more notice', 'Show %d more notices', $moreCount, 'monstera' ), $moreCount ) );
				?>
			</button>
		</details>
	<?php endif; ?>

	<main id="monstera-main" class="monstera-portal__main">
	<?php if ( $isSuspended ) : ?>
		<section class="m-blocked" data-soft role="region" aria-labelledby="monstera-suspended-title">
			<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
			<span class="m-badge m-blocked__reason" data-tone="suspended"><?php esc_html_e( 'Suspended', 'monstera' ); ?></span>
			<h1 id="monstera-suspended-title">
				<?php
				/* translators: %s: organization name */
				printf( esc_html__( '%s\'s membership is suspended.', 'monstera' ), esc_html( $orgName ) );
				?>
			</h1>
			<p>
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'You can still read everything here. Downloads are paused until the %s team reactivates the organization.', 'monstera' ), esc_html( \Monstera\Portal\Audience::siteName() ) );
				?>
			</p>
			<a class="m-btn m-blocked__action" data-intent="secondary" href="mailto:<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'Contact the %s team →', 'monstera' ), esc_html( \Monstera\Portal\Audience::siteName() ) );
				?>
			</a>
		</section>
	<?php endif; ?>
