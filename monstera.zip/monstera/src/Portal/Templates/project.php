<?php
/**
 * Single project view — status, scope, discovery intake, team.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Capabilities;
use Monstera\Subgroups\Repository as SubgroupRepository;
use Monstera\Core\Icons;
use Monstera\Content\Visibility;
use Monstera\Content\Repository as ContentRepository;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\Downloader;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Portal\Audience;
use Monstera\Projects\Discovery;
use Monstera\Projects\IntakeFiles;
use Monstera\Projects\Meta;
use Monstera\Projects\Repository as ProjectRepository;

if ( ! Modules::isActive( Modules::PROJECTS ) ) {
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Projects are not enabled on this site.', 'monstera' ); ?></h1>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user        = $ctx['user'];
$projectId   = (int) get_query_var( Routing::PARAM_ID );
$projectPost = get_post( $projectId );
$repo        = new ProjectRepository();

// Permission: team member, the project's org, the named standalone client, or
// admin. Shared with PortalGuard via Repository::userCanAccess so the route
// guard and this template can never drift. The view_projects capability gates
// the feature; userCanAccess gates the specific row.
$canView = current_user_can( Capabilities::CAP_VIEW_PROJECTS ) || current_user_can( Capabilities::CAP_MANAGE_MONSTERA );
$canSee  = $canView && $repo->userCanAccess( (int) $user->ID, $projectId );

if ( ! $canSee ) {
	// The blocked pattern (comps 31-33). The portal guard answers first on a
	// request; this is what the template says when it is reached all the same.
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not shared with you', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'You don\'t have access to this project.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( 'It may not be shared with you, or your access changed. %s if this seems wrong.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It may belong to a different organization, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROJECTS ) ); ?>"><?php esc_html_e( 'Back to projects', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$projectStatus = $repo->status( $projectId );
$startedOn     = (string) get_post_meta( $projectId, Meta::KEY_STARTED_ON, true );
$dueOn         = (string) get_post_meta( $projectId, Meta::KEY_DUE_ON, true );
$scope         = (string) get_post_meta( $projectId, Meta::KEY_SCOPE, true );
$schema        = Discovery::schema( $projectId );
$responses     = Discovery::responses( $projectId );
$teamIds       = $repo->memberIds( $projectId );
$intakeOpen    = in_array( $projectStatus, [ Meta::STATUS_PROPOSED, Meta::STATUS_DISCOVERY ], true );
// File answers (comp 97): the team and admins add and remove them while
// discovery is open; who may download them, or reads "Download paused",
// is the Downloader's answer.
$intakeFiles    = ( new IntakeFiles() )->forProject( $projectId );
$fileAccess     = Downloader::intakeAccess( $user, $projectId );
$canChangeFiles = $intakeOpen && ( current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) || in_array( (int) $user->ID, $teamIds, true ) );
?>

<?php
$endedOn    = (string) get_post_meta( $projectId, Meta::KEY_ENDED_ON, true );
$stages     = [
	Meta::STATUS_PROPOSED,
	Meta::STATUS_DISCOVERY,
	Meta::STATUS_IN_PROGRESS,
	Meta::STATUS_REVIEW,
	Meta::STATUS_COMPLETED,
];
$stageIndex = array_search( $projectStatus, $stages, true );
if ( false === $stageIndex ) {
	// On hold and archived sit outside the five; show the last known stage.
	$stageIndex = Meta::STATUS_ARCHIVED === $projectStatus ? 4 : 2;
}
$tone = match ( $projectStatus ) {
	Meta::STATUS_COMPLETED => 'success',
	Meta::STATUS_ON_HOLD   => 'suspended',
	Meta::STATUS_DISCOVERY => 'info',
	Meta::STATUS_REVIEW    => 'warning',
	Meta::STATUS_PROPOSED  => 'pending',
	Meta::STATUS_ARCHIVED  => 'archived',
	default                => 'active',
};

// Breadcrumb: the projects index (or the client org's hub) then the project.
$backUrl      = Routing::url( Routing::ROUTE_PROJECTS );
$backLabel    = __( 'Projects', 'monstera' );
$projectOrgId = (int) get_post_meta( $projectId, Meta::KEY_ORG_ID, true );
$readerOrgId  = UserMeta::associatedOrg( (int) $user->ID );
if ( $projectOrgId && $readerOrgId === $projectOrgId ) {
	$projectOrgSlug = (string) get_post_field( 'post_name', $projectOrgId );
	if ( $projectOrgSlug ) {
		$backUrl   = add_query_arg( 'tab', 'projects', Routing::url( Routing::ROUTE_ORG, [ 'slug' => $projectOrgSlug ] ) );
		$backLabel = __( 'Projects', 'monstera' );
	}
}

// Deliverables: the content gated to this project the reader can see.
$deliverables = [];
$visibility   = new Visibility( new SubgroupRepository(), $repo );
if ( ! $intakeOpen ) {
	$contentRepo = new ContentRepository();
	foreach ( $repo->contentForProject( $projectId ) as $deliverableId ) {
		if ( $visibility->userCanSee( $user, $deliverableId ) ) {
			$deliverables[] = $deliverableId;
		}
	}
}

// Timeline from the dates and the stage.
$timeline = [];
if ( $startedOn && strtotime( $startedOn ) ) {
	$timeline[] = [
		'ts'    => strtotime( $startedOn ),
		'label' => __( 'Started', 'monstera' ),
		'state' => 'done',
	];
}
$timeline[] = [
	'ts'    => time(),
	'label' => Meta::statusLabel( $projectStatus ),
	'state' => 'now',
];
if ( $dueOn && strtotime( $dueOn ) && Meta::STATUS_COMPLETED !== $projectStatus ) {
	$timeline[] = [
		'ts'    => strtotime( $dueOn ),
		'label' => __( 'Due', 'monstera' ),
		'state' => strtotime( $dueOn ) > time() ? 'next' : 'done',
	];
}
if ( $endedOn && strtotime( $endedOn ) ) {
	$timeline[] = [
		'ts'    => strtotime( $endedOn ),
		'label' => __( 'Completed', 'monstera' ),
		'state' => 'done',
	];
}
usort( $timeline, static fn ( $a, $b ) => $a['ts'] <=> $b['ts'] );
?>
<div class="monstera-portal__dash">

	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( $backUrl ); ?>"><?php echo esc_html( $backLabel ); ?></a>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo esc_html( get_the_title( $projectPost ) ); ?></span>
	</nav>

	<?php if ( Meta::STATUS_COMPLETED === $projectStatus ) : ?>
		<section class="m-blocked" data-soft data-tone="success" role="region" aria-labelledby="project-completed-title">
			<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
			<span class="m-badge m-blocked__reason" data-tone="success">
				<?php
				if ( $endedOn && strtotime( $endedOn ) ) {
					/* translators: %s: completion date */
					printf( esc_html__( 'Completed %s', 'monstera' ), esc_html( wp_date( 'M j', strtotime( $endedOn ) ) ) );
				} else {
					esc_html_e( 'Completed', 'monstera' );
				}
				?>
			</span>
			<h2 id="project-completed-title">
				<?php
				if ( $endedOn && strtotime( $endedOn ) ) {
					/* translators: %s: completion date */
					printf( esc_html__( 'This project wrapped up on %s.', 'monstera' ), esc_html( wp_date( 'F j', strtotime( $endedOn ) ) ) );
				} else {
					esc_html_e( 'This project has wrapped up.', 'monstera' );
				}
				?>
			</h2>
			<p><?php esc_html_e( 'The final files stay here for your records; nothing is still being worked on.', 'monstera' ); ?></p>
			<?php if ( $deliverables ) : ?>
				<a class="m-btn m-blocked__action" data-intent="primary" href="#project-deliverables"><?php esc_html_e( 'Open the final files →', 'monstera' ); ?></a>
			<?php endif; ?>
		</section>
	<?php elseif ( Meta::STATUS_ON_HOLD === $projectStatus ) : ?>
		<section class="m-blocked" data-soft role="region" aria-labelledby="project-hold-title">
			<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
			<span class="m-badge m-blocked__reason" data-tone="suspended"><?php esc_html_e( 'On hold', 'monstera' ); ?></span>
			<h2 id="project-hold-title"><?php esc_html_e( 'This project is on hold.', 'monstera' ); ?></h2>
			<p>
				<?php
				printf(
					/* translators: %s: the stage the project paused at */
					esc_html__( 'Work paused at the %s stage. Everything here stays as it is, and the timeline picks up when the project resumes.', 'monstera' ),
					esc_html( strtolower( Meta::statusLabel( $stages[ $stageIndex ] ) ) )
				);
				?>
			</p>
			<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
				<a class="m-btn m-blocked__action" data-intent="secondary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) . '?project=' . $projectId ); ?>"><?php esc_html_e( 'Ask about this project →', 'monstera' ); ?></a>
			<?php endif; ?>
		</section>
	<?php endif; ?>

	<header class="m-project-head">
		<div class="m-project-head__kickers">
			<span class="m-badge" data-tone="<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( Meta::statusLabel( $projectStatus ) ); ?></span>
			<?php if ( $startedOn && strtotime( $startedOn ) ) : ?>
				<span class="m-badge" data-tone="neutral">
					<?php
					/* translators: %s: start date, e.g. "Mar 4, 2026". */
					printf( esc_html__( 'Started %s', 'monstera' ), esc_html( wp_date( 'M j, Y', strtotime( $startedOn ) ) ) );
					?>
				</span>
			<?php endif; ?>
			<?php if ( $dueOn && strtotime( $dueOn ) && Meta::STATUS_COMPLETED !== $projectStatus ) : ?>
				<span class="m-badge" data-tone="neutral">
					<?php
					/* translators: %s: due date, e.g. "Mar 4". */
					printf( esc_html__( 'Due %s', 'monstera' ), esc_html( wp_date( 'M j', strtotime( $dueOn ) ) ) );
					?>
				</span>
			<?php endif; ?>
		</div>
		<h1><?php echo esc_html( get_the_title( $projectPost ) ); ?></h1>
		<?php if ( $scope ) : ?>
			<p class="m-project-head__scope"><?php echo esc_html( wp_strip_all_tags( $scope ) ); ?></p>
		<?php elseif ( $projectPost->post_excerpt ) : ?>
			<p class="m-project-head__scope"><?php echo esc_html( wp_strip_all_tags( $projectPost->post_excerpt ) ); ?></p>
		<?php endif; ?>
	</header>

	<ol class="m-pipeline" aria-label="<?php esc_attr_e( 'Project stage', 'monstera' ); ?>">
		<?php foreach ( $stages as $idx => $stage ) : ?>
			<li<?php echo $idx < $stageIndex ? ' data-done' : ( $idx === $stageIndex ? ' aria-current="step"' : '' ); ?>><span class="m-pipeline__label"><?php echo esc_html( Meta::statusLabel( $stage ) ); ?></span></li>
		<?php endforeach; ?>
		<li class="m-pipeline__now" aria-hidden="true">
			<strong>
				<?php
				/* translators: 1: stage number, 2: stage count, 3: stage name */
				printf( esc_html__( 'Stage %1$d of %2$d · %3$s', 'monstera' ), (int) $stageIndex + 1, count( $stages ), esc_html( Meta::statusLabel( $stages[ $stageIndex ] ) ) );
				?>
			</strong>
			<?php if ( $dueOn && strtotime( $dueOn ) && Meta::STATUS_COMPLETED !== $projectStatus ) : ?>
				·
				<?php
				/* translators: %s: due date */
				printf( esc_html__( 'due %s', 'monstera' ), esc_html( wp_date( 'M j', strtotime( $dueOn ) ) ) );
				?>
			<?php endif; ?>
		</li>
	</ol>

	<div class="m-dash">
		<div class="m-dash__main">
			<?php if ( $projectPost->post_content ) : ?>
				<article class="m-prose" data-plain>
					<?php echo apply_filters( 'the_content', $projectPost->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput -- the_content pipeline output, the same trust model as a theme template. ?>
				</article>
			<?php endif; ?>

			<?php if ( $intakeOpen && ( current_user_can( Capabilities::CAP_SUBMIT_INTAKE ) || current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) ) ) : ?>
				<form
					class="m-form"
					action="<?php echo esc_url( Routing::restUrl( "monstera/v1/projects/{$projectId}/intake" ) ); ?>"
					method="post"
					data-wp-on--submit="actions.submitIntake"
					data-files-url="<?php echo esc_url( Routing::restUrl( "monstera/v1/projects/{$projectId}/intake/files" ) ); ?>"
					data-max-bytes="<?php echo (int) IntakeFiles::maxBytes(); ?>"
					data-max-count="<?php echo (int) IntakeFiles::maxCount(); ?>"
					data-accept="<?php echo esc_attr( IntakeFiles::accept() ); ?>"
					data-msg-file-remove="<?php esc_attr_e( 'Remove', 'monstera' ); ?>"
					data-msg-file-remove-label="<?php /* translators: %s: a file's name */ esc_attr_e( 'Remove %s', 'monstera' ); ?>"
					data-msg-file-dismiss="<?php esc_attr_e( 'Dismiss', 'monstera' ); ?>"
					data-msg-file-dismiss-label="<?php /* translators: %s: a file's name */ esc_attr_e( 'Dismiss %s', 'monstera' ); ?>"
					data-msg-file-uploading="<?php /* translators: 1: how much has been sent, 2: the file's size, e.g. "4 MB of 12 MB" */ esc_attr_e( 'Uploading · %1$s of %2$s', 'monstera' ); ?>"
					data-msg-file-uploading-label="<?php /* translators: %s: a file's name */ esc_attr_e( 'Uploading %s', 'monstera' ); ?>"
					data-msg-file-big="<?php echo esc_attr( IntakeFiles::sayTooBig() ); ?>"
					data-msg-file-type="<?php echo esc_attr( IntakeFiles::sayWrongType() ); ?>"
					data-msg-file-full="<?php echo esc_attr( IntakeFiles::sayFull() ); ?>"
					data-msg-file-failed="<?php esc_attr_e( 'That file could not be added. Try again.', 'monstera' ); ?>"
					data-msg-file-added="<?php /* translators: %s: a file's name */ esc_attr_e( '%s added.', 'monstera' ); ?>"
					data-msg-file-refused="<?php /* translators: 1: a file's name, 2: why it was refused */ esc_attr_e( '%1$s was not added. %2$s', 'monstera' ); ?>"
					data-msg-file-removed="<?php /* translators: %s: a file's name */ esc_attr_e( '%s removed.', 'monstera' ); ?>"
					data-msg-file-required="<?php /* translators: %s: a discovery question that needs a file */ esc_attr_e( 'Add a file to “%s” before you submit.', 'monstera' ); ?>"
					data-msg-file-pending="<?php esc_attr_e( 'Wait for your files to finish uploading, then submit.', 'monstera' ); ?>"
					data-msg-file-remove-failed="<?php /* translators: %s: a file's name */ esc_attr_e( '%s could not be removed. Try again.', 'monstera' ); ?>"
					data-msg-file-server-big="<?php esc_attr_e( 'That file is larger than this site accepts. Send a smaller one.', 'monstera' ); ?>"
					data-msg-file-signed-out="<?php esc_attr_e( 'Your session has ended. Reload the page, then try again.', 'monstera' ); ?>"
					data-msg-file-kind="<?php /* translators: the tag on a file whose name has no extension */ esc_attr_e( 'file', 'monstera' ); ?>"
					data-size-units="<?php echo esc_attr( (string) wp_json_encode( IntakeFiles::sizeUnits() ) ); ?>"
					data-msg-saved="<?php esc_attr_e( 'Discovery saved.', 'monstera' ); ?>"
					data-msg-notified="<?php esc_attr_e( 'Discovery saved. Your team has been notified.', 'monstera' ); ?>"
					data-msg-failed="<?php esc_attr_e( 'Could not save. Try again or contact support.', 'monstera' ); ?>"
					aria-labelledby="project-discovery-title">
					<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>
					<p class="m-sr-only" role="status" aria-live="polite" aria-atomic="false" data-intake-status></p>
					<h3 id="project-discovery-title"><?php esc_html_e( 'Discovery', 'monstera' ); ?></h3>
					<p class="m-form__help"><?php esc_html_e( 'Help us understand what we\'re building together. Your answers shape the kickoff.', 'monstera' ); ?></p>

					<?php
					// WCAG 2.2 SC 3.3.7 Redundant Entry: identity fields the member has
					// already given us are prefilled from their profile, and carry
					// autocomplete tokens so browsers can fill them too.
					$viewer  = wp_get_current_user();
					$prefill = [
						'email'         => [ $viewer->user_email, 'email' ],
						'contact_email' => [ $viewer->user_email, 'email' ],
						'name'          => [ $viewer->display_name, 'name' ],
						'full_name'     => [ $viewer->display_name, 'name' ],
						'first_name'    => [ $viewer->first_name, 'given-name' ],
						'last_name'     => [ $viewer->last_name, 'family-name' ],
						'phone'         => [ '', 'tel' ],
					];
					foreach ( $schema as $field ) :
						if ( 'file' === ( $field['type'] ?? '' ) ) {
							$questionFiles = $intakeFiles[ (string) $field['key'] ] ?? [];
							require __DIR__ . '/partials/_intake-file-question.php';
							continue;
						}
						$key   = (string) $field['key'];
						$value = (string) ( $responses[ $key ] ?? '' );
						$auto  = '';
						if ( isset( $prefill[ $key ] ) ) {
							$auto = $prefill[ $key ][1];
							if ( '' === $value ) {
								$value = (string) $prefill[ $key ][0];
							}
						}
						$fieldId  = 'intake-' . sanitize_html_class( $key );
						$required = ! empty( $field['required'] );
						?>
						<div class="m-field">
							<label class="m-field__label" for="<?php echo esc_attr( $fieldId ); ?>">
								<?php echo esc_html( $field['label'] ); ?>
								<?php if ( $required ) : ?>
									<span class="m-req" aria-hidden="true">*</span>
								<?php endif; ?>
							</label>
							<?php if ( 'textarea' === ( $field['type'] ?? '' ) ) : ?>
								<textarea id="<?php echo esc_attr( $fieldId ); ?>" name="<?php echo esc_attr( $key ); ?>" class="m-textarea" rows="4" <?php echo $required ? 'required' : ''; ?>><?php echo esc_textarea( $value ); ?></textarea>
							<?php elseif ( 'select' === ( $field['type'] ?? '' ) ) : ?>
								<select id="<?php echo esc_attr( $fieldId ); ?>" name="<?php echo esc_attr( $key ); ?>" class="m-select" <?php echo $required ? 'required' : ''; ?>>
									<option value=""><?php esc_html_e( 'Pick one…', 'monstera' ); ?></option>
									<?php foreach ( (array) ( $field['options'] ?? [] ) as $opt ) : ?>
										<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $opt, $value ); ?>><?php echo esc_html( $opt ); ?></option>
									<?php endforeach; ?>
								</select>
							<?php else : ?>
								<input
									id="<?php echo esc_attr( $fieldId ); ?>"
									type="<?php echo esc_attr( $field['type'] ?? 'text' ); ?>"
									name="<?php echo esc_attr( $key ); ?>"
									class="m-input"
									<?php echo $auto ? 'autocomplete="' . esc_attr( $auto ) . '"' : ''; ?>
									value="<?php echo esc_attr( $value ); ?>"
									<?php echo $required ? 'required' : ''; ?> />
							<?php endif; ?>
							<?php if ( ! empty( $field['help'] ) ) : ?>
								<span class="m-field__hint"><?php echo esc_html( $field['help'] ); ?></span>
							<?php elseif ( $auto ) : ?>
								<span class="m-field__hint"><?php esc_html_e( 'From your profile.', 'monstera' ); ?></span>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>

					<div class="m-form__actions">
						<button class="m-btn" data-intent="primary" data-size="md" type="submit">
							<?php echo $responses ? esc_html__( 'Update discovery', 'monstera' ) : esc_html__( 'Submit discovery', 'monstera' ); ?>
						</button>
						<?php if ( $responses ) : ?>
							<span class="m-mono"><?php esc_html_e( 'Answers on file', 'monstera' ); ?></span>
						<?php endif; ?>
					</div>
				</form>
			<?php endif; ?>

			<?php if ( ! $intakeOpen ) : ?>
				<section class="m-section" id="project-deliverables" aria-labelledby="project-deliverables-title">
					<div class="m-section__head">
						<h2 id="project-deliverables-title"><?php esc_html_e( 'Deliverables', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono">
							<?php
							/* translators: %d: number of deliverables */
							printf( esc_html( _n( '%d file', '%d files', count( $deliverables ), 'monstera' ) ), (int) count( $deliverables ) );
							?>
						</span>
					</div>
					<?php if ( $deliverables ) : ?>
						<ul class="m-list">
							<?php
							foreach ( $deliverables as $deliverableId ) :
								$dPost      = get_post( $deliverableId );
								$dFileId    = (int) get_post_meta( $deliverableId, ContentMeta::KEY_SECURE_FILE_ID, true );
								$dClick     = (string) get_post_meta( $deliverableId, ContentMeta::KEY_CLICK_BEHAVIOR, true );
								$dHref      = Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $deliverableId ] );
								$dIsFile    = ContentMeta::CLICK_FILE === $dClick && $dFileId;
								$dCanFetch  = $dIsFile && $visibility->userCanDownload( $user, $deliverableId );
								$dActionUrl = $dCanFetch ? Downloader::signedUrl( $dFileId, $user->ID ) : $dHref;
								$dTs        = $dPost ? (int) get_post_time( 'U', true, $dPost ) : 0;
								?>
								<li class="m-list__row">
									<span class="m-list__date"><?php echo esc_html( wp_date( 'M j', $dTs ?: null ) ); ?></span>
									<a class="m-list__title" href="<?php echo esc_url( $dHref ); ?>"><?php echo esc_html( get_the_title( $deliverableId ) ); ?></a>
									<span class="m-list__meta"><span><?php echo $dIsFile ? esc_html__( 'File', 'monstera' ) : esc_html__( 'Article', 'monstera' ); ?></span></span>
									<?php if ( $dIsFile && ! $dCanFetch ) : ?>
										<span class="m-paused m-list__action"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
									<?php else : ?>
										<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $dActionUrl ); ?>"<?php echo $dCanFetch ? ' download' : ''; ?>><?php echo $dCanFetch ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Open →', 'monstera' ); ?></a>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p class="m-rail-block__empty"><?php esc_html_e( 'Nothing delivered yet. Files land here as the work is shared with you.', 'monstera' ); ?></p>
					<?php endif; ?>
				</section>
			<?php endif; ?>

			<?php
			// Once discovery is over the form gives way to the stage's work, so
			// the files sent at discovery are kept here, read-only (comp 97).
			$sentCount = (int) array_sum( array_map( 'count', $intakeFiles ) );
			if ( ! $intakeOpen && $sentCount ) :
				?>
				<section class="m-section" id="project-discovery-files" aria-labelledby="project-discovery-files-title">
					<div class="m-section__head">
						<h2 id="project-discovery-files-title"><?php esc_html_e( 'What you sent at discovery', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono">
							<?php
							/* translators: %d: number of files sent at discovery */
							printf( esc_html( _n( '%d file', '%d files', $sentCount, 'monstera' ) ), (int) $sentCount );
							?>
						</span>
					</div>
					<?php
					$fileRemovable = false;
					$fileClosed    = true;
					foreach ( $schema as $field ) :
						$questionFiles = $intakeFiles[ (string) $field['key'] ] ?? [];
						if ( 'file' !== ( $field['type'] ?? '' ) || ! $questionFiles ) {
							continue;
						}
						$titleId = 'project-files-' . sanitize_html_class( (string) $field['key'] );
						?>
						<h3 class="m-fileq__title" id="<?php echo esc_attr( $titleId ); ?>"><?php echo esc_html( $field['label'] ); ?></h3>
						<ul class="m-files" aria-labelledby="<?php echo esc_attr( $titleId ); ?>">
							<?php
							foreach ( $questionFiles as $intakeFile ) {
								require __DIR__ . '/partials/_intake-file-row.php';
							}
							?>
						</ul>
					<?php endforeach; ?>
				</section>
			<?php endif; ?>
		</div>

		<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'On this project', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Timeline', 'monstera' ); ?></h3>
				<ol class="m-timeline">
					<?php foreach ( $timeline as $event ) : ?>
						<li<?php echo 'now' === $event['state'] ? ' data-now' : ( 'next' === $event['state'] ? ' data-next' : '' ); ?>>
							<time datetime="<?php echo esc_attr( wp_date( 'Y-m-d', $event['ts'] ) ); ?>"><?php echo esc_html( wp_date( 'M j', $event['ts'] ) ); ?></time>
							<strong><?php echo esc_html( $event['label'] ); ?></strong>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>

			<div class="m-rail-block">
				<h3><?php esc_html_e( 'On this project', 'monstera' ); ?></h3>
				<ul class="m-people">
					<?php
					foreach ( $teamIds as $memberId ) :
						$member = get_userdata( $memberId );
						if ( ! $member ) {
							continue;
						}
						$position = (string) get_user_meta( $memberId, UserMeta::KEY_POSITION, true );
						$photo    = (int) get_user_meta( $memberId, UserMeta::KEY_PROFILE_PHOTO, true );
						$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
						?>
						<li>
							<span class="m-avatar" aria-hidden="true">
								<?php if ( $photoUrl ) : ?>
									<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
								<?php else : ?>
									<?php Icons::emit( 'sprout', 18 ); ?>
								<?php endif; ?>
							</span>
							<span>
								<?php echo esc_html( trim( $member->first_name . ' ' . $member->last_name ) ?: $member->display_name ); ?>
								<?php if ( $position || $memberId === (int) $user->ID ) : ?>
									<small>
										<?php
										echo esc_html( $position );
										if ( $memberId === (int) $user->ID ) {
											echo esc_html( ( $position ? ' · ' : '' ) . __( 'that\'s you', 'monstera' ) );
										}
										?>
									</small>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) . '?project=' . $projectId ); ?>"><?php esc_html_e( 'Ask a question about this project →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		</aside>
	</div>
</div>
