<?php
/**
 * Portal org content hub — /portal/{org-slug}/
 *
 * Implements comp 05: editorial cover (org name, tier, description, leaf
 * motif), sticky tabs (Content / Projects / Sub-groups / Members), per-tab
 * surfaces, and an aside with about/leadership/CTA panels.
 *
 * Tabs are URL-driven via ?tab=… so each section is shareable and
 * server-rendered. Defaults to "content".
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Content\Downloader;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\Repository as ContentRepository;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\Repository as MemberRepository;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Portal\AuthorScope;
use Monstera\Portal\CalendarDay;
use Monstera\Portal\ContentProjects;
use Monstera\Portal\DocumentTitle;
use Monstera\Portal\Leads;
use Monstera\Portal\NextStep;
use Monstera\Portal\SubgroupNames;
use Monstera\Portal\SupportPages;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

$user    = $ctx['user'];
$slug    = (string) get_query_var( Routing::PARAM_ORG );
$orgRepo = new OrgRepository();
$org     = $slug ? $orgRepo->findBySlug( $slug ) : null;

// 404 — unknown slug.
if ( ! $org ) {
	DocumentTitle::name( __( 'Organization not found', 'monstera' ) );
	?>
	<section class="monstera-portal__hero">
		<h1><?php esc_html_e( 'Organization not found.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'The URL might be stale, or this org no longer exists.', 'monstera' ); ?></p>
		<p><a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a></p>
	</section>
	<?php
	return;
}

$orgId   = (int) $org->ID;
$isAdmin = user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
// The viewer's tier here (People-model track, FR2): a manager of another
// organization is whatever they are in this one.
$tierHere    = Roster::roleOf( (int) $user->ID, $orgId );
$managesHere = in_array( $tierHere, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true );

// Permission: must belong to this org, OR be a Monstera admin.
if ( ! $isAdmin && null === $tierHere ) {
	DocumentTitle::refused( __( 'Not shared with you', 'monstera' ) );
	?>
	<section class="monstera-portal__hero">
		<h1><?php esc_html_e( 'You don\'t have access to this organization.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( '%s if you should have access.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php
				// "Its" is the organization this page is about, so the
				// sentence holds for a person in one organization and for a
				// person in several, none of whose own it is. An admin or a
				// manager may invite (Organizations\RosterPolicy).
				esc_html_e( 'If you should be a member, ask one of its admins or managers to invite you.', 'monstera' );
				?>
			<?php endif; ?>
		</p>
		<p><a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a></p>
	</section>
	<?php
	return;
}

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------
$subgroupRepo = new SubgroupRepository();
$projectRepo  = new ProjectRepository();
$contentRepo  = new ContentRepository();
$visibility   = new Visibility( $subgroupRepo, $projectRepo );

$projectsEnabled  = Modules::isActive( Modules::PROJECTS );
$resourcesEnabled = Modules::isActive( Modules::RESOURCES );
$formsEnabled     = Modules::isActive( Modules::FORMS );

// Content visible to this user, scoped to this org.
$contentPosts = $contentRepo->forOrgs( [ $orgId ], [ 'posts_per_page' => 200 ] ); // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- deliberate 200-item cap for the org hub content list.
// What gates the items (their sub-groups, their projects) is read together
// before each is judged, as on the dashboard, and the rows name their
// projects from the same read.
$visibility->prime( array_map( static fn ( $post ): int => (int) $post->ID, $contentPosts ) );
$contentRows  = array_filter(
	$contentRepo->summarize( $contentPosts ),
	static fn ( $r ) => $visibility->userCanSee( $user, $r['id'] )
);
$contentTotal = count( $contentRows );

$orgSubgroups = $subgroupRepo->forOrg( $orgId );
// Skip the projects query entirely when the module is disabled — the CPT
// isn't even registered in that case.
$orgProjects = $projectsEnabled ? $projectRepo->forOrg( $orgId ) : [];

// Oldest account first, so the roster keeps its order as people join and the
// rows past the first 25 are the newest. The rows then ask each person's
// tier here, so the memo is filled for all of them in one query.
$orgMembers = ( new MemberRepository() )->byOrg(
	$orgId,
	[
		'orderby' => 'ID',
		'order'   => 'ASC',
	]
);
Roster::prime( array_map( static fn ( \WP_User $member ): int => (int) $member->ID, $orgMembers ) );

// Org meta
$tierTerms   = wp_get_post_terms( $orgId, 'monstera_org_tier', [ 'fields' => 'names' ] );
$tier        = is_array( $tierTerms ) ? ( $tierTerms[0] ?? '' ) : '';
$description = (string) get_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, true );
$expires     = (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true );
$location    = (string) get_post_meta( $orgId, OrgMeta::KEY_LOCATION, true );
$seatLimit   = (int) get_post_meta( $orgId, OrgMeta::KEY_SEAT_LIMIT, true );
$orgStatus   = $orgRepo->status( $orgId );

// Org self-service affordance. The capability is the ceiling and the tier
// held in this organization the answer, as in the REST guards, which
// re-check every write; this only governs whether the control is shown.
// What the roster offers is the Members tab's own to ask
// (partials/_org-members.php, by Organizations\RosterPolicy).
$canRenewOrg = current_user_can( Capabilities::CAP_MANAGE_MONSTERA )
	|| ( current_user_can( Capabilities::CAP_RENEW_OWN ) && $managesHere );

// Delegated authoring affordance. The "Manage" tab appears for an admin or
// manager of this organization, or for a sub-group leader whose group lives
// under it; the scope is asked for this organization, so a manager of one
// organization authors here only when they manage this one. REST re-checks
// every write via AuthorScope, so this only governs visibility.
$authorScope     = AuthorScope::forUser( (int) $user->ID, $orgId );
$canAuthorPortal = $authorScope->isAuthor() && $authorScope->orgId === $orgId;

// The new-request form as this hub links it: about this organization, named
// in the address for a person in several (SupportPages::newRequestUrl()).
// Worked out once, for the rail and for every sub-group the reader is not in.
$newRequestUrl = Modules::isActive( Modules::SUPPORT ) ? SupportPages::newRequestUrl( $user, $orgId ) : '';

// ---------------------------------------------------------------------------
// Tab routing
// ---------------------------------------------------------------------------
// Tab availability follows module activation. Content / Sub-groups /
// Members are always-on. Projects, Resources and Forms only show when
// their modules are enabled in Settings.
$allowedTabs = array_values(
	array_filter(
		[
			'content',
			Modules::isActive( Modules::PROJECTS ) ? 'projects' : null,
			$resourcesEnabled ? 'resources' : null,
			$formsEnabled ? 'forms' : null,
			'subgroups',
			'members',
			$canAuthorPortal ? 'manage' : null,
		]
	)
);
$activeTab   = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : 'content'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
if ( ! in_array( $activeTab, $allowedTabs, true ) ) {
	$activeTab = 'content';
}

$tabUrl = static function ( string $slug, string $activeTab ): string {
	return add_query_arg( 'tab', $activeTab, Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] ) );
};

// Per-tab counts shown in tab pills.
// The organization's resources this person can open: published, naming the
// organization, and past the role and sub-group gates, as on the Resources
// page. Drafts are the manager's, under Manage.
$resourcesRepo = new \Monstera\Resources\Repository();
$orgResources  = $resourcesEnabled ? $resourcesRepo->forOrg( $user, $orgId ) : [];
// The organization's forms that reach this person, where each stands for
// them (Forms\Standing, one read of what they have sent): a closed form
// they never sent is not theirs to see, so the pill counts the rows the
// tab lists (Forms-and-resources track, FR5).
$orgForms = [];
if ( $formsEnabled ) {
	$reachingForms = ( new \Monstera\Forms\Repository() )->forOrg( $user, $orgId );
	$formStandings = \Monstera\Forms\Standing::ofEach( $user, $reachingForms );
	foreach ( $reachingForms as $orgForm ) {
		if ( isset( $formStandings[ (int) $orgForm->ID ] ) ) {
			$orgForms[ (int) $orgForm->ID ] = [ $orgForm, $formStandings[ (int) $orgForm->ID ] ];
		}
	}
}

$tabCounts = [
	'content'   => $contentTotal,
	'projects'  => count( $orgProjects ),
	'subgroups' => count( $orgSubgroups ),
	'members'   => count( $orgMembers ),
	'resources' => count( $orgResources ),
	'forms'     => count( $orgForms ),
];


// Leadership: the organization's admins, then its managers, up to four.
$leaders = [];
foreach ( array_slice( array_merge( Roster::memberIds( $orgId, [ Roster::TIER_ADMIN ] ), Roster::memberIds( $orgId, [ Roster::TIER_MANAGER ] ) ), 0, 4 ) as $leaderId ) {
	$leader = get_userdata( $leaderId );
	if ( $leader ) {
		$leaders[] = $leader;
	}
}

?>

<div class="monstera-portal__dash">
<!-- Cover -->
<section class="m-org-cover" aria-labelledby="m-org-cover-title">
	<p class="m-org-cover__eyebrow"><?php esc_html_e( 'Organization', 'monstera' ); ?></p>
	<h1 id="m-org-cover-title"><?php echo esc_html( get_the_title( $org ) ); ?></h1>
	<?php if ( $description ) : ?>
		<p class="m-org-cover__lede"><?php echo esc_html( wp_strip_all_tags( $description ) ); ?></p>
	<?php endif; ?>
	<div class="m-chips m-org-cover__chips">
		<?php if ( $tier ) : ?>
			<span class="m-chip" data-tone="brand"><?php echo esc_html( $tier ); ?></span>
		<?php endif; ?>
		<?php if ( $expires ) : ?>
			<span class="m-chip">
				<?php
				/* translators: %s: renewal date */
				printf( esc_html__( 'Renews %s', 'monstera' ), esc_html( CalendarDay::format( $expires, 'M j, Y' ) ) );
				?>
			</span>
		<?php endif; ?>
		<?php // The count moves when someone is removed in place on the Members tab: both forms ride on the chip for the store to redraw it from (redrawRosterCounts), as the section head's own count carries them. ?>
		<span class="m-chip" data-roster-total data-one="<?php /* translators: %d: how many members */ esc_attr_e( '%d member', 'monstera' ); ?>" data-many="<?php /* translators: %d: how many members */ esc_attr_e( '%d members', 'monstera' ); ?>">
			<?php
			/* translators: %d: how many members */
			printf( esc_html( _n( '%d member', '%d members', count( $orgMembers ), 'monstera' ) ), count( $orgMembers ) );
			?>
		</span>
		<?php if ( $orgSubgroups ) : ?>
			<span class="m-chip">
				<?php
				/* translators: %d: subgroup count */
				printf( esc_html( _n( '%d sub-group', '%d sub-groups', count( $orgSubgroups ), 'monstera' ) ), count( $orgSubgroups ) );
				?>
			</span>
		<?php endif; ?>
		<?php if ( $location ) : ?>
			<span class="m-chip"><?php echo esc_html( $location ); ?></span>
		<?php endif; ?>
	</div>

	<!-- Leaf-fenestration motif -->
	<svg class="m-org-cover__motif" viewBox="0 0 320 240" aria-hidden="true">
		<defs>
			<linearGradient id="m-org-leaf-<?php echo (int) $orgId; ?>" x1="0" y1="0" x2="1" y2="1">
				<stop offset="0%" stop-color="var(--m-brand-soft)"/>
				<stop offset="100%" stop-color="var(--m-brand)"/>
			</linearGradient>
		</defs>
		<path d="M170 30 C 250 60 290 130 290 200 C 260 220 220 230 180 215 C 130 200 90 160 80 110 C 90 70 120 40 170 30 Z" fill="url(#m-org-leaf-<?php echo (int) $orgId; ?>)" opacity="0.85"/>
		<path d="M170 80 Q 200 90 210 120 Q 200 140 175 130 Q 165 110 170 80 Z" fill="var(--m-surface)" opacity="0.92"/>
		<path d="M140 130 Q 165 140 175 165 Q 170 185 145 175 Q 130 155 140 130 Z" fill="var(--m-surface)" opacity="0.92"/>
		<path d="M210 150 Q 235 155 245 175 Q 240 195 220 185 Q 210 170 210 150 Z" fill="var(--m-surface)" opacity="0.92"/>
		<path d="M85 110 Q 170 140 285 200" fill="none" stroke="var(--m-brand-pressed)" stroke-width="1.2" opacity="0.5"/>
	</svg>
</section>

<!-- Section tabs: links with aria-current, never ARIA tabs. On a phone the store brings the current tab, and any tab that takes keyboard focus, clear of the strip's edge fade. -->
<nav class="m-org-tabs" aria-label="<?php esc_attr_e( 'Organization sections', 'monstera' ); ?>">
	<div class="m-org-tabs__scroll" data-wp-init="callbacks.revealCurrentTab" data-wp-on--focusin="actions.revealTab">
		<?php
		$tabLabels = array_intersect_key(
			[
				'content'   => ContentPostType::label(),
				'projects'  => __( 'Projects', 'monstera' ),
				'resources' => __( 'Resources', 'monstera' ),
				'forms'     => __( 'Forms', 'monstera' ),
				'subgroups' => __( 'Sub-groups', 'monstera' ),
				'members'   => __( 'Members', 'monstera' ),
				'manage'    => __( 'Manage', 'monstera' ),
			],
			array_flip( $allowedTabs )
		);
		// The hub is named by its organization, and an open tab other than
		// the first goes before it: "Members · Harbor Lane Dental".
		DocumentTitle::name( 'content' === $activeTab ? '' : $tabLabels[ $activeTab ], get_the_title( $org ) );
		foreach ( $tabLabels as $key => $label ) :
			$href = $tabUrl( $slug, $key );
			?>
			<a href="<?php echo esc_url( $href ); ?>"<?php echo $activeTab === $key ? ' aria-current="page"' : ''; ?>>
				<?php echo esc_html( $label ); ?>
				<?php if ( isset( $tabCounts[ $key ] ) ) : ?>
					<?php // The Members pill is the roster's count, which moves when someone is removed in place; the store redraws it (redrawRosterCounts). ?>
					<span class="m-org-tabs__count"<?php echo 'members' === $key ? ' data-roster-total' : ''; ?>><?php echo (int) $tabCounts[ $key ]; ?></span>
				<?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
</nav>

<!-- Body: the dashboard grid, rail from 1024 -->
<div class="m-dash m-org-hub">
	<div class="m-dash__main">

<?php if ( 'content' === $activeTab ) : ?>
		<?php
		// Each row's sub-groups, read from the gates the items were judged
		// by and kept to the ones the reader may see named, never another
		// client's.
		$rowSubgroups = SubgroupNames::shownFor( $user, $visibility->subgroupsOf( array_map( static fn ( array $r ): int => (int) $r['id'], $contentRows ) ) );

		// Filter chips: "All" + each sub-group named on at least one item.
		$contentSubgroupCounts = [];
		foreach ( $contentRows as $row ) {
			foreach ( $rowSubgroups[ (int) $row['id'] ] ?? [] as $sgId ) {
				$contentSubgroupCounts[ $sgId ] = ( $contentSubgroupCounts[ $sgId ] ?? 0 ) + 1;
			}
		}
		$activeFilter = isset( $_GET['filter'] ) ? sanitize_key( (string) $_GET['filter'] ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
		// A filter by a sub-group the reader may not see named, another
		// client's among them, is no filter. One of theirs with nothing for
		// them yet (the Sub-groups tab's "Open →") still filters, to none.
		if ( str_starts_with( $activeFilter, 'sg-' ) && ! SubgroupNames::shown( $user, [ (int) substr( $activeFilter, 3 ) ] ) ) {
			$activeFilter = 'all';
		}

		$filterHref = static function ( string $slug, string $activeTab, string $filter ): string {
			return add_query_arg(
				[
					'tab'    => $activeTab,
					'filter' => 'all' === $filter ? null : $filter,
				],
				Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] )
			);
		};

	if ( 'all' !== $activeFilter && str_starts_with( $activeFilter, 'sg-' ) ) {
		$filterSgId  = (int) substr( $activeFilter, 3 );
		$contentRows = array_filter(
			$contentRows,
			static fn ( $r ) => in_array( $filterSgId, $rowSubgroups[ (int) $r['id'] ] ?? [], true )
		);
	}

		// Newest first.
		usort(
			$contentRows,
			static fn ( $a, $b ) => strtotime( (string) $b['date'] ) <=> strtotime( (string) $a['date'] )
		);
		$contentRows = array_values( $contentRows );

		// One item's link, kind and scope, shared by the featured item and the
		// list: a file the reader may fetch links to the signed download, a
		// file a suspended org may not fetch reads "Download paused". The
		// rows' files are read together, never one a row.
		$fileIdOf = static fn ( array $row ): int => ContentMeta::CLICK_FILE === $row['click'] ? (int) get_post_meta( $row['id'], ContentMeta::KEY_SECURE_FILE_ID, true ) : 0;
		$files    = ( new \Monstera\Content\SecureFiles() )->findByIds( array_map( $fileIdOf, $contentRows ) );
		$describe = static function ( array $row ) use ( $user, $visibility, $rowSubgroups, $files, $fileIdOf ): array {
			$fileId     = $fileIdOf( $row );
			$isFile     = 0 < $fileId;
			$href       = Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] );
			$isDownload = false;
			$isPaused   = false;
			if ( $isFile ) {
				if ( $visibility->userCanDownload( $user, (int) $row['id'] ) ) {
					$href       = Downloader::signedUrl( $fileId, $user->ID );
					$isDownload = true;
				} else {
					$isPaused = true;
				}
			}
			// The first sub-group the reader may see named; a reader who sees an
			// item limited to sub-groups is in one, so "Sub-groups" alone is
			// only a guard.
			$rowSg = $rowSubgroups[ (int) $row['id'] ] ?? [];
			$gated = (bool) ( $visibility->subgroupsOf( [ (int) $row['id'] ] )[ (int) $row['id'] ] ?? [] );
			$scope = $rowSg ? get_the_title( $rowSg[0] ) : ( $gated ? __( 'Sub-groups', 'monstera' ) : __( 'All members', 'monstera' ) );
			$kind  = __( 'Article', 'monstera' );
			if ( $isFile ) {
				$file = $files[ $fileId ] ?? null;
				$ext  = $file ? strtoupper( (string) pathinfo( (string) ( $file['original_name'] ?? '' ), PATHINFO_EXTENSION ) ) : '';
				$kind = $ext ?: __( 'File', 'monstera' );
				if ( $file && ! empty( $file['filesize'] ) ) {
					$kind .= ' · ' . size_format( (int) $file['filesize'] );
				}
			}
			return compact( 'href', 'isDownload', 'isPaused', 'scope', 'kind' );
		};
	?>

		<nav class="m-chips m-filters" aria-label="<?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_attr( sprintf( __( 'Filter %s', 'monstera' ), ContentPostType::noun() ) ); ?>">
			<a class="m-chip" href="<?php echo esc_url( $filterHref( $slug, 'content', 'all' ) ); ?>"<?php echo 'all' === $activeFilter ? ' aria-current="true"' : ''; ?>>
				<?php esc_html_e( 'All', 'monstera' ); ?>
				<span class="m-chip__count"><?php echo (int) $contentTotal; ?></span>
			</a>
			<?php
			foreach ( $contentSubgroupCounts as $sgId => $count ) :
				$sg = $subgroupRepo->find( $sgId );
				if ( ! $sg ) {
					continue;
				}
				$key = 'sg-' . $sgId;
				?>
				<a class="m-chip" href="<?php echo esc_url( $filterHref( $slug, 'content', $key ) ); ?>"<?php echo $activeFilter === $key ? ' aria-current="true"' : ''; ?>>
					<?php echo esc_html( get_the_title( $sg ) ); ?>
					<span class="m-chip__count"><?php echo (int) $count; ?></span>
				</a>
			<?php endforeach; ?>
		</nav>

		<?php if ( ! $contentRows ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'Nothing published to this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>

			<?php
			$hero = array_shift( $contentRows );
			$d    = $describe( $hero );
			// The projects each item names (At-a-glance track, FR6), the
			// featured one's too, from the gates the items were judged by:
			// the organization's own projects open for its reader, any other
			// asked.
			$rowProjects = ContentProjects::forRows(
				$visibility,
				(int) $user->ID,
				array_map( static fn ( array $r ): int => (int) $r['id'], array_merge( [ $hero ], $contentRows ) ),
				array_map( static fn ( $p ): int => (int) $p->ID, $orgProjects )
			);
			?>
			<section class="m-featured" aria-label="<?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_attr( sprintf( __( 'Featured %s', 'monstera' ), ContentPostType::noun() ) ); ?>">
				<span class="m-featured__mark" aria-hidden="true">
					<svg viewBox="0 0 80 80" fill="currentColor"><path d="M40 8 C 60 15 70 35 70 55 C 60 65 45 70 30 65 C 18 60 10 45 12 28 C 18 16 28 10 40 8 Z" opacity="0.55"/><path d="M40 25 Q 50 30 55 42 Q 52 50 42 47 Q 38 38 40 25 Z" fill="var(--m-surface)"/><path d="M30 42 Q 40 47 42 58 Q 38 64 28 60 Q 25 52 30 42 Z" fill="var(--m-surface)"/></svg>
				</span>
				<?php
				/* translators: %s: month and year the item was published */
				$kicker = sprintf( __( 'Featured · %s', 'monstera' ), wp_date( 'F Y', strtotime( $hero['date'] ) ) );
				?>
				<p class="m-featured__kicker"><?php echo esc_html( $kicker ); ?></p>
				<h2><a class="m-featured__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $hero['id'] ] ) ); ?>"><?php echo esc_html( $hero['title'] ); ?></a></h2>
				<?php if ( $hero['summary'] ) : ?>
					<p class="m-featured__summary"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $hero['summary'] ), 28 ) ); ?></p>
				<?php endif; ?>
				<div class="m-featured__foot">
					<span class="m-featured__facts"><span><?php echo esc_html( $d['kind'] . ' · ' . $d['scope'] ); ?></span><?php echo ContentProjects::render( $rowProjects[ (int) $hero['id'] ] ?? [] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts. ?></span>
					<?php if ( $d['isPaused'] ) : ?>
						<span class="m-paused"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
					<?php else : ?>
						<a class="m-btn" data-intent="primary" data-size="sm" href="<?php echo esc_url( $d['href'] ); ?>"<?php echo $d['isDownload'] ? ' download' : ''; ?>>
							<?php echo $d['isDownload'] ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Read →', 'monstera' ); ?>
						</a>
					<?php endif; ?>
				</div>
			</section>

			<?php if ( $contentRows ) : ?>
				<?php $moreCount = max( 0, count( $contentRows ) - 25 ); ?>
				<section class="m-section" aria-labelledby="m-org-content-list">
					<div class="m-section__head">
						<h2 id="m-org-content-list"><?php esc_html_e( 'Earlier this season', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono">
						<?php
							/* translators: %d: content count */
							printf( esc_html( _n( '%d item · scoped to your access', '%d items · scoped to your access', count( $contentRows ), 'monstera' ) ), (int) count( $contentRows ) );
						?>
							</span>
					</div>
					<ul class="m-list" data-reveal>
						<?php
						foreach ( $contentRows as $i => $row ) :
							$d  = $describe( $row );
							$ts = strtotime( (string) $row['date'] ) ?: 0;
							?>
							<li class="m-list__row"<?php echo $i >= 25 ? ' data-more hidden' : ''; ?>>
								<span class="m-list__date"><?php echo esc_html( wp_date( 'M j', $ts ?: null ) ); ?></span>
								<a class="m-list__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] ) ); ?>"><?php echo esc_html( $row['title'] ); ?></a>
								<span class="m-list__meta"><span><?php echo esc_html( $d['scope'] ); ?></span><?php echo ContentProjects::render( $rowProjects[ (int) $row['id'] ] ?? [] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts. ?><span><?php echo esc_html( $d['kind'] ); ?></span></span>
								<?php if ( $d['isPaused'] ) : ?>
									<span class="m-paused m-list__action"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
								<?php else : ?>
									<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $d['href'] ); ?>"<?php echo $d['isDownload'] ? ' download' : ''; ?>>
										<?php echo $d['isDownload'] ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Open →', 'monstera' ); ?>
									</a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
					<?php if ( $moreCount ) : ?>
						<p class="m-list__more">
							<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-wp-on--click="actions.revealMore">
								<?php
								/* translators: %d: number of rows still hidden */
								printf( esc_html( _n( 'Show %d more →', 'Show %d more →', $moreCount, 'monstera' ) ), (int) $moreCount );
								?>
							</button>
						</p>
					<?php endif; ?>
				</section>
			<?php endif; ?>

		<?php endif; ?>

	<?php elseif ( 'projects' === $activeTab ) : ?>
		<?php if ( ! $orgProjects ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No projects yet for this organization.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<?php
			$pipelineStages = [
				ProjectMeta::STATUS_PROPOSED,
				ProjectMeta::STATUS_DISCOVERY,
				ProjectMeta::STATUS_IN_PROGRESS,
				ProjectMeta::STATUS_REVIEW,
				ProjectMeta::STATUS_COMPLETED,
			];
			$inFlight       = 0;
			$completedCount = 0;
			foreach ( $orgProjects as $project ) {
				$projectStatus = $projectRepo->status( (int) $project->ID );
				if ( in_array( $projectStatus, [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true ) ) {
					++$completedCount;
				} elseif ( ProjectMeta::STATUS_PROPOSED !== $projectStatus ) {
					++$inFlight;
				}
			}
			?>
			<section class="m-section" aria-labelledby="m-org-projects">
				<div class="m-section__head">
					<h2 id="m-org-projects"><?php esc_html_e( 'Projects', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						printf(
							/* translators: 1, 2: two short facts set side by side, e.g. "Closed Mar 4 · 3 sent" */
							esc_html__( '%1$s · %2$s', 'monstera' ),
							/* translators: %d: number of projects under way */
							esc_html( sprintf( _n( '%d in flight', '%d in flight', $inFlight, 'monstera' ), $inFlight ) ),
							/* translators: %d: number of completed projects */
							esc_html( sprintf( _n( '%d completed', '%d completed', $completedCount, 'monstera' ), $completedCount ) )
						);
					?>
						</span>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $orgProjects as $project ) :
						$pid          = (int) $project->ID;
						$pStat        = $projectRepo->status( $pid );
						$dueOn        = (string) get_post_meta( $pid, ProjectMeta::KEY_DUE_ON, true );
						$endedOn      = (string) get_post_meta( $pid, ProjectMeta::KEY_ENDED_ON, true );
						$teamSize     = count( $projectRepo->memberIds( $pid ) );
						$isDone       = in_array( $pStat, [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true );
						$currentIndex = array_search( $pStat, $pipelineStages, true );
						if ( false === $currentIndex ) {
							$currentIndex = 0;
						}
						$tone = match ( $pStat ) {
							ProjectMeta::STATUS_COMPLETED => 'success',
							ProjectMeta::STATUS_ARCHIVED  => 'neutral',
							ProjectMeta::STATUS_ON_HOLD   => 'suspended',
							ProjectMeta::STATUS_DISCOVERY => 'info',
							ProjectMeta::STATUS_PROPOSED  => 'pending',
							ProjectMeta::STATUS_REVIEW    => 'warning',
							default                       => 'active',
						};
						$pUrl = Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $pid ] );
						?>
						<li class="m-rows__row">
							<span class="m-rows__date">
								<?php
								if ( ProjectMeta::STATUS_ON_HOLD === $pStat ) {
									esc_html_e( 'on hold', 'monstera' );
								} elseif ( $isDone && '' !== CalendarDay::format( $endedOn, 'M j' ) ) {
									echo esc_html( CalendarDay::format( $endedOn, 'M j' ) );
								} elseif ( '' !== CalendarDay::format( $dueOn, 'M j' ) ) {
									/* translators: %s: due date, e.g. "Mar 4". */
									printf( esc_html__( 'due %s', 'monstera' ), esc_html( CalendarDay::format( $dueOn, 'M j' ) ) );
								}
								?>
							</span>
							<a class="m-rows__title" href="<?php echo esc_url( $pUrl ); ?>"><?php echo esc_html( get_the_title( $project ) ); ?></a>
							<span class="m-rows__meta">
								<span class="m-badge" data-tone="<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( ProjectMeta::statusLabel( $pStat ) ); ?></span>
								<span>
									<?php
									/* translators: %d: team size count */
									printf( esc_html( _n( '%d on team', '%d on team', $teamSize, 'monstera' ) ), (int) $teamSize );
									?>
								</span>
							<?php echo NextStep::shownTo( $user ) ? NextStep::rowFact( $projectRepo, $pid ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by NextStep::rowFact(). ?></span>
							<span class="m-rows__side">
								<?php if ( $isDone ) : ?>
									<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $pUrl ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a>
								<?php else : ?>
									<?php
									/* translators: 1: current stage number, 2: total stages */
									$stageLabel = sprintf( __( 'Stage %1$d of %2$d', 'monstera' ), (int) $currentIndex + 1, count( $pipelineStages ) );
									?>
									<span class="m-progress" role="img" aria-label="<?php echo esc_attr( $stageLabel ); ?>">
										<?php foreach ( $pipelineStages as $idx => $stage ) : ?>
											<span<?php echo $idx < $currentIndex ? ' data-done' : ( $idx === $currentIndex ? ' data-now' : '' ); ?>></span>
										<?php endforeach; ?>
									</span>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

	<?php elseif ( 'subgroups' === $activeTab ) : ?>
		<?php if ( ! $orgSubgroups ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No sub-groups for this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<?php
			$mySubgroups = $subgroupRepo->subgroupsForMember( (int) $user->ID );
			$mineHere    = count( array_filter( $orgSubgroups, static fn ( $sg ) => in_array( (int) $sg->ID, $mySubgroups, true ) ) );
			?>
			<section class="m-section" aria-labelledby="m-org-subgroups">
				<div class="m-section__head">
					<h2 id="m-org-subgroups"><?php esc_html_e( 'Sub-groups', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						printf(
							/* translators: 1, 2: two short facts set side by side, e.g. "Closed Mar 4 · 3 sent" */
							esc_html__( '%1$s · %2$s', 'monstera' ),
							/* translators: %d: number of sub-groups */
							esc_html( sprintf( _n( '%d group', '%d groups', count( $orgSubgroups ), 'monstera' ), count( $orgSubgroups ) ) ),
							/* translators: %d: number of these sub-groups the reader belongs to */
							esc_html( sprintf( __( 'you’re in %d', 'monstera' ), $mineHere ) )
						);
					?>
						</span>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $orgSubgroups as $sg ) :
						$sgId      = (int) $sg->ID;
						$leaderId  = (int) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_LEADER, true );
						$leader    = $leaderId ? get_userdata( $leaderId ) : null;
						$memCount  = count( $subgroupRepo->memberIds( $sgId ) );
						$cadence   = (string) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_MEETING_CADENCE, true );
						$isPrivate = (bool) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_IS_PRIVATE, true );
						$isMember  = $isAdmin || in_array( $sgId, $mySubgroups, true );
						$openUrl   = add_query_arg(
							[
								'tab'    => 'content',
								'filter' => 'sg-' . $sgId,
							],
							Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] )
						);
						$facts     = [];
						if ( $leader ) {
							/* translators: %s: leader's name */
							$facts[] = sprintf( __( 'Chaired by %s', 'monstera' ), trim( $leader->first_name . ' ' . $leader->last_name ) ?: $leader->display_name );
						}
						/* translators: %d: how many members */
						$facts[] = sprintf( _n( '%d member', '%d members', $memCount, 'monstera' ), $memCount );
						?>
						<li class="m-rows__row">
							<span class="m-rows__date"><?php echo esc_html( $cadence ?: __( 'As needed', 'monstera' ) ); ?></span>
							<?php if ( $isMember ) : ?>
								<a class="m-rows__title" href="<?php echo esc_url( $openUrl ); ?>"><?php echo esc_html( get_the_title( $sg ) ); ?></a>
							<?php else : ?>
								<span class="m-rows__title"><?php echo esc_html( get_the_title( $sg ) ); ?></span>
							<?php endif; ?>
							<span class="m-rows__meta">
								<?php if ( $isMember && ! $isAdmin ) : ?>
									<span class="m-badge" data-tone="brand"><?php esc_html_e( 'Member', 'monstera' ); ?></span>
								<?php endif; ?>
								<?php if ( $isPrivate ) : ?>
									<span class="m-badge" data-tone="neutral"><?php esc_html_e( 'Private', 'monstera' ); ?></span>
								<?php endif; ?>
								<span><?php echo esc_html( implode( ' · ', $facts ) ); ?></span>
							</span>
							<span class="m-rows__side">
								<?php if ( $isMember ) : ?>
									<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $openUrl ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a>
								<?php elseif ( Modules::isActive( Modules::SUPPORT ) ) : ?>
									<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $newRequestUrl ); ?>"><?php esc_html_e( 'Ask to join →', 'monstera' ); ?></a>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

<?php elseif ( 'resources' === $activeTab ) : ?>
		<?php if ( ! $orgResources ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No resources published to this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<section class="m-section" aria-labelledby="m-org-resources">
				<div class="m-section__head">
					<h2 id="m-org-resources"><?php esc_html_e( 'Resources', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						/* translators: %d: number of resources */
						printf( esc_html( _n( '%d resource', '%d resources', count( $orgResources ), 'monstera' ) ), (int) count( $orgResources ) );
					?>
						</span>
				</div>
				<ul class="m-list">
					<?php
					// The same row the Resources page renders, so a resource reads
					// the same wherever a member meets it: a file that waits for
					// a person in several organizations waits here too, where a
					// link would only lead to the redirect's refusal. Every row
					// is this hub's, so none names an organization. The rows are
					// asked about together: one read of the reader's sub-groups.
					$resourceOrg = '';
					$beside      = $resourcesRepo->besideEach( $user, $orgResources );
					foreach ( $orgResources as $resource ) {
						$resourceWait = $beside[ (int) $resource->ID ]['waits'] ?? false;
						require __DIR__ . '/partials/_resource-row.php';
					}
					?>
				</ul>
			</section>
		<?php endif; ?>

	<?php elseif ( 'forms' === $activeTab ) : ?>
		<?php if ( ! $orgForms ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No forms for this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<section class="m-section" aria-labelledby="m-org-forms">
				<div class="m-section__head">
					<h2 id="m-org-forms"><?php esc_html_e( 'Forms', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						/* translators: %d: number of forms */
						printf( esc_html( _n( '%d form', '%d forms', count( $orgForms ), 'monstera' ) ), (int) count( $orgForms ) );
					?>
						</span>
				</div>
				<ul class="m-list">
					<?php
					// The same row the Forms page renders (partials/_form-row.php),
					// so a form reads the same wherever a member meets it. Every
					// row is this hub's, so none names an organization.
					$formOrg = '';
					foreach ( $orgForms as [ $form, $formStanding ] ) {
						require __DIR__ . '/partials/_form-row.php';
					}
					?>
				</ul>
			</section>
		<?php endif; ?>

	<?php elseif ( 'members' === $activeTab ) : ?>
		<?php require __DIR__ . '/partials/_org-members.php'; ?>

<?php elseif ( 'manage' === $activeTab ) : ?>
		<?php require __DIR__ . '/partials/_org-manage.php'; ?>

	<?php endif; ?>

	</div>

	<!-- Rail: about, membership, leadership -->
	<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'About this organization', 'monstera' ); ?>">
		<div class="m-rail-block">
			<h3><?php esc_html_e( 'About this org', 'monstera' ); ?></h3>
			<div class="m-stat">
				<span class="m-stat__label"><?php esc_html_e( 'Joined', 'monstera' ); ?></span>
				<?php // The local date, which a suspended organization, a draft, has where its GMT date is still empty. ?>
				<span class="m-stat__value"><?php echo esc_html( wp_date( 'M Y', (int) get_post_timestamp( $org ) ) ); ?></span>
			</div>
			<?php if ( $expires ) : ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Renews', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( CalendarDay::format( $expires, 'M j, Y' ) ); ?></span>
				</div>
			<?php endif; ?>
			<?php if ( $tier ) : ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Tier', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( $tier ); ?></span>
				</div>
			<?php endif; ?>
			<div class="m-stat">
				<span class="m-stat__label"><?php esc_html_e( 'Seats used', 'monstera' ); ?></span>
				<?php // The seats taken move when someone is removed in place on the Members tab; the store redraws the count (redrawRosterCounts), and the limit stays. ?>
				<span class="m-stat__value"><span data-roster-total><?php echo (int) count( $orgMembers ); ?></span><?php echo $seatLimit ? ' / ' . (int) $seatLimit : ''; ?></span>
			</div>
			<?php if ( $location ) : ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Region', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( $location ); ?></span>
				</div>
			<?php endif; ?>
			<div class="m-stat">
				<span class="m-stat__label"><?php esc_html_e( 'Status', 'monstera' ); ?></span>
				<span class="m-stat__value"><?php echo esc_html( ucfirst( $orgStatus ) ); ?></span>
			</div>
		</div>

		<?php if ( $canRenewOrg && ( current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) || Membership::renewalOpen( $orgId ) ) ) : ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Membership', 'monstera' ); ?></h3>
				<p>
					<?php
					if ( $expires ) {
						/* translators: %s: expiry date */
						printf( esc_html__( 'Expires %s. ', 'monstera' ), esc_html( CalendarDay::format( $expires, 'M j, Y' ) ) );
					}
					esc_html_e( 'Renewing extends the membership one year from the payment date.', 'monstera' );
					?>
				</p>
				<button type="button" class="m-btn" data-intent="secondary" data-size="sm" data-renew data-org-id="<?php echo (int) $orgId; ?>" data-wp-on--click="actions.startRenewal"><?php esc_html_e( 'Renew membership →', 'monstera' ); ?></button>
			</div>
		<?php endif; ?>

		<?php if ( $leaders ) : ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Leadership', 'monstera' ); ?></h3>
				<ul class="m-people">
					<?php
					foreach ( $leaders as $member ) :
						$position = (string) get_user_meta( $member->ID, UserMeta::KEY_POSITION, true );
						$photo    = (int) get_user_meta( $member->ID, UserMeta::KEY_PROFILE_PHOTO, true );
						$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
						?>
						<li>
							<span class="m-avatar" aria-hidden="true">
								<?php if ( $photoUrl ) : ?>
									<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
								<?php else : ?>
									<?php \Monstera\Core\Icons::emit( 'sprout', 18 ); ?>
								<?php endif; ?>
							</span>
							<span>
								<?php echo esc_html( trim( $member->first_name . ' ' . $member->last_name ) ?: $member->display_name ); ?>
								<?php if ( $position ) : ?>
									<small><?php echo esc_html( $position ); ?></small>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( $newRequestUrl ); ?>"><?php esc_html_e( 'Open a support request →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php
		// The organization's account lead (At-a-glance track, FR4 portal;
		// comp 40), while still staff and assigned to it (Portal\Leads).
		$lead = Leads::account( $orgId );
		if ( $lead ) {
			$leadHeading = __( 'Your account lead', 'monstera' );
			require __DIR__ . '/partials/_lead-card.php';
		}
		?>
	</aside>
</div>
</div>
