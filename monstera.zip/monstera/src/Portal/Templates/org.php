<?php
/**
 * Portal org content hub — /portal/{org-slug}/
 *
 * Implements comp 05: editorial cover (org name, tier, description, leaf
 * motif), sticky tabs (Content / Projects / Sub-groups / Members), per-tab
 * surfaces, and an aside with about/leadership/CTA panels.
 *
 * Tabs are URL-driven via ?tab=… so each section is shareable and
 * server-rendered. Defaults to "content".
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Content\Downloader;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\Repository as ContentRepository;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Portal\Audience;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

$user    = $ctx['user'];
$slug    = (string) get_query_var( Routing::PARAM_ORG );
$orgRepo = new OrgRepository();
$org     = $slug ? $orgRepo->findBySlug( $slug ) : null;

// 404 — unknown slug.
if ( ! $org ) {
	?>
	<section class="monstera-portal__hero">
		<h1><?php esc_html_e( 'Organization not found.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'The URL might be stale, or this org no longer exists.', 'monstera' ); ?></p>
		<p><a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a></p>
	</section>
	<?php
	return;
}

$orgId   = (int) $org->ID;
$userOrg = UserMeta::associatedOrg( $user->ID );
$isAdmin = user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );

// Permission: must belong to this org, OR be a Monstera admin.
if ( ! $isAdmin && $userOrg !== $orgId ) {
	?>
	<section class="monstera-portal__hero">
		<h1><?php esc_html_e( 'You don\'t have access to this organization.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( '%s if you should have access.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'If you should be a member, ask your org\'s manager to invite you.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<p><a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a></p>
	</section>
	<?php
	return;
}

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------
$subgroupRepo = new SubgroupRepository();
$projectRepo  = new ProjectRepository();
$contentRepo  = new ContentRepository();
$visibility   = new Visibility( $subgroupRepo, $projectRepo );

$projectsEnabled = Modules::isActive( Modules::PROJECTS );
$formsEnabled    = Modules::isActive( Modules::FORMS );

// Content visible to this user, scoped to this org.
$contentPosts = $contentRepo->forOrgs( [ $orgId ], [ 'posts_per_page' => 200 ] ); // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- deliberate 200-item cap for the org hub content list.
$contentRows  = array_filter(
	$contentRepo->summarize( $contentPosts ),
	static fn ( $r ) => $visibility->userCanSee( $user, $r['id'] )
);
$contentTotal = count( $contentRows );

$orgSubgroups = $subgroupRepo->forOrg( $orgId );
// Skip the projects query entirely when the module is disabled — the CPT
// isn't even registered in that case.
$orgProjects = $projectsEnabled ? $projectRepo->forOrg( $orgId ) : [];

// Oldest account first, so the roster keeps its order as people join and the
// rows past the first 25 are the newest.
$orgMembers = get_users(
	[
		'meta_key' => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
	'meta_value'   => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
	'number'       => -1,
	'orderby'      => 'ID',
	'order'        => 'ASC',
	]
);

// Org meta
$tierTerms   = wp_get_post_terms( $orgId, 'monstera_org_tier', [ 'fields' => 'names' ] );
$tier        = is_array( $tierTerms ) ? ( $tierTerms[0] ?? '' ) : '';
$description = (string) get_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, true );
$expires     = (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true );
$location    = (string) get_post_meta( $orgId, OrgMeta::KEY_LOCATION, true );
$seatLimit   = (int) get_post_meta( $orgId, OrgMeta::KEY_SEAT_LIMIT, true );
$orgStatus   = $orgRepo->status( $orgId );

// Org self-service affordances. "manage OR cap, scoped to own org" mirrors the
// REST guards (BaseController::actsWithinOwnOrg) — the endpoints re-check, so
// this only governs whether the controls are shown.
$canManageOrg = current_user_can( Capabilities::CAP_MANAGE_MONSTERA )
	|| ( current_user_can( Capabilities::CAP_MANAGE_OWN_ORG ) && $userOrg === $orgId );
$canRenewOrg  = current_user_can( Capabilities::CAP_MANAGE_MONSTERA )
	|| ( current_user_can( Capabilities::CAP_RENEW_OWN ) && $userOrg === $orgId );

// Delegated authoring affordance. The "Manage" tab appears for an org manager
// on their own org, or for a sub-group leader whose group lives under this org.
// REST re-checks every write via AuthorScope, so this only governs visibility.
$authorScope     = \Monstera\Portal\AuthorScope::forCurrentUser();
$canAuthorPortal = $authorScope->isAuthor() && $authorScope->orgId === $orgId;

// ---------------------------------------------------------------------------
// Tab routing
// ---------------------------------------------------------------------------
// Tab availability follows module activation. Content / Sub-groups /
// Members are always-on. Projects and Resources only show when their
// modules are enabled in Settings.
$allowedTabs = array_values(
	array_filter(
		[
			'content',
			Modules::isActive( Modules::PROJECTS ) ? 'projects' : null,
			Modules::isActive( Modules::FORMS ) ? 'resources' : null,
			'subgroups',
			'members',
			$canAuthorPortal ? 'manage' : null,
		]
	)
);
$activeTab   = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : 'content'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
if ( ! in_array( $activeTab, $allowedTabs, true ) ) {
	$activeTab = 'content';
}

$tabUrl = static function ( string $slug, string $activeTab ): string {
	return add_query_arg( 'tab', $activeTab, Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] ) );
};

// Per-tab counts shown in tab pills.
// The organization's resources this person can open: published, naming the
// organization, and past the role and sub-group gates, as on the Resources
// page. Drafts are the manager's, under Manage.
$orgForms = $formsEnabled ? ( new \Monstera\Forms\Repository() )->forOrg( $user, $orgId ) : [];

$tabCounts = [
	'content'   => $contentTotal,
	'projects'  => count( $orgProjects ),
	'subgroups' => count( $orgSubgroups ),
	'members'   => count( $orgMembers ),
	'resources' => count( $orgForms ),
];


// Leadership = org_manager users for this org, plus the post author as fallback.
$leaders = get_users(
	[
		'role__in' => [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_ADMIN, Capabilities::ROLE_MEMBER ],
		'meta_key' => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
	'meta_value'   => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
	'number'       => 4,
	]
);

?>

<div class="monstera-portal__dash">
<!-- Cover -->
<section class="m-org-cover" aria-labelledby="m-org-cover-title">
	<p class="m-org-cover__eyebrow"><?php esc_html_e( 'Organization', 'monstera' ); ?></p>
	<h1 id="m-org-cover-title"><?php echo esc_html( get_the_title( $org ) ); ?></h1>
	<?php if ( $description ) : ?>
		<p class="m-org-cover__lede"><?php echo esc_html( wp_strip_all_tags( $description ) ); ?></p>
	<?php endif; ?>
	<div class="m-chips m-org-cover__chips">
		<?php if ( $tier ) : ?>
			<span class="m-chip" data-tone="brand"><?php echo esc_html( $tier ); ?></span>
		<?php endif; ?>
		<?php if ( $expires ) : ?>
			<span class="m-chip">
				<?php
				/* translators: %s: renewal date */
				printf( esc_html__( 'Renews %s', 'monstera' ), esc_html( wp_date( 'M j, Y', strtotime( $expires ) ) ) );
				?>
			</span>
		<?php endif; ?>
		<span class="m-chip">
			<?php
			/* translators: %d: member count */
			printf( esc_html( _n( '%d member', '%d members', count( $orgMembers ), 'monstera' ) ), count( $orgMembers ) );
			?>
		</span>
		<?php if ( $orgSubgroups ) : ?>
			<span class="m-chip">
				<?php
				/* translators: %d: subgroup count */
				printf( esc_html( _n( '%d sub-group', '%d sub-groups', count( $orgSubgroups ), 'monstera' ) ), count( $orgSubgroups ) );
				?>
			</span>
		<?php endif; ?>
		<?php if ( $location ) : ?>
			<span class="m-chip"><?php echo esc_html( $location ); ?></span>
		<?php endif; ?>
	</div>

	<!-- Leaf-fenestration motif -->
	<svg class="m-org-cover__motif" viewBox="0 0 320 240" aria-hidden="true">
		<defs>
			<linearGradient id="m-org-leaf-<?php echo (int) $orgId; ?>" x1="0" y1="0" x2="1" y2="1">
				<stop offset="0%" stop-color="var(--m-brand-soft)"/>
				<stop offset="100%" stop-color="var(--m-brand)"/>
			</linearGradient>
		</defs>
		<path d="M170 30 C 250 60 290 130 290 200 C 260 220 220 230 180 215 C 130 200 90 160 80 110 C 90 70 120 40 170 30 Z" fill="url(#m-org-leaf-<?php echo (int) $orgId; ?>)" opacity="0.85"/>
		<path d="M170 80 Q 200 90 210 120 Q 200 140 175 130 Q 165 110 170 80 Z" fill="var(--m-surface)" opacity="0.92"/>
		<path d="M140 130 Q 165 140 175 165 Q 170 185 145 175 Q 130 155 140 130 Z" fill="var(--m-surface)" opacity="0.92"/>
		<path d="M210 150 Q 235 155 245 175 Q 240 195 220 185 Q 210 170 210 150 Z" fill="var(--m-surface)" opacity="0.92"/>
		<path d="M85 110 Q 170 140 285 200" fill="none" stroke="var(--m-brand-pressed)" stroke-width="1.2" opacity="0.5"/>
	</svg>
</section>

<!-- Section tabs: links with aria-current, never ARIA tabs. On a phone the store brings the current tab, and any tab that takes keyboard focus, clear of the strip's edge fade. -->
<nav class="m-org-tabs" aria-label="<?php esc_attr_e( 'Organization sections', 'monstera' ); ?>">
	<div class="m-org-tabs__scroll" data-wp-init="callbacks.revealCurrentTab" data-wp-on--focusin="actions.revealTab">
		<?php
		$tabLabels = array_intersect_key(
			[
				'content'   => ContentPostType::label(),
				'projects'  => __( 'Projects', 'monstera' ),
				'resources' => __( 'Resources', 'monstera' ),
				'subgroups' => __( 'Sub-groups', 'monstera' ),
				'members'   => __( 'Members', 'monstera' ),
				'manage'    => __( 'Manage', 'monstera' ),
			],
			array_flip( $allowedTabs )
		);
		foreach ( $tabLabels as $key => $label ) :
			$href = $tabUrl( $slug, $key );
			?>
			<a href="<?php echo esc_url( $href ); ?>"<?php echo $activeTab === $key ? ' aria-current="page"' : ''; ?>>
				<?php echo esc_html( $label ); ?>
				<?php if ( isset( $tabCounts[ $key ] ) ) : ?>
					<span class="m-org-tabs__count"><?php echo (int) $tabCounts[ $key ]; ?></span>
				<?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
</nav>

<!-- Body: the dashboard grid, rail from 1024 -->
<div class="m-dash m-org-hub">
	<div class="m-dash__main">

<?php if ( 'content' === $activeTab ) : ?>
		<?php
		// Filter chips: "All" + each sub-group that has at least one item.
		$contentSubgroupCounts = [];
		foreach ( $contentRows as $row ) {
			foreach ( $subgroupRepo->subgroupsForContent( $row['id'] ) as $sgId ) {
				$contentSubgroupCounts[ $sgId ] = ( $contentSubgroupCounts[ $sgId ] ?? 0 ) + 1;
			}
		}
		$activeFilter = isset( $_GET['filter'] ) ? sanitize_key( (string) $_GET['filter'] ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.

		$filterHref = static function ( string $slug, string $activeTab, string $filter ): string {
			return add_query_arg(
				[
					'tab'    => $activeTab,
					'filter' => 'all' === $filter ? null : $filter,
				],
				Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] )
			);
		};

	if ( 'all' !== $activeFilter && str_starts_with( $activeFilter, 'sg-' ) ) {
		$filterSgId  = (int) substr( $activeFilter, 3 );
		$contentRows = array_filter(
			$contentRows,
			fn ( $r ) => in_array( $filterSgId, $subgroupRepo->subgroupsForContent( $r['id'] ), true )
		);
	}

		// Newest first.
		usort(
			$contentRows,
			static fn ( $a, $b ) => strtotime( (string) $b['date'] ) <=> strtotime( (string) $a['date'] )
		);
		$contentRows = array_values( $contentRows );

		// One item's link, kind and scope, shared by the featured item and the
		// list: a file the reader may fetch links to the signed download, a
		// file a suspended org may not fetch reads "Download paused".
		$secureFiles = new \Monstera\Content\SecureFiles();
		$describe    = static function ( array $row ) use ( $user, $visibility, $subgroupRepo, $secureFiles ): array {
			$fileId     = (int) get_post_meta( $row['id'], ContentMeta::KEY_SECURE_FILE_ID, true );
			$isFile     = ContentMeta::CLICK_FILE === $row['click'] && $fileId;
			$href       = Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] );
			$isDownload = false;
			$isPaused   = false;
			if ( $isFile ) {
				if ( $visibility->userCanDownload( $user, (int) $row['id'] ) ) {
					$href       = Downloader::signedUrl( $fileId, $user->ID );
					$isDownload = true;
				} else {
					$isPaused = true;
				}
			}
			$rowSg = $subgroupRepo->subgroupsForContent( $row['id'] );
			$scope = $rowSg ? get_the_title( $rowSg[0] ) : __( 'All members', 'monstera' );
			$kind  = __( 'Article', 'monstera' );
			if ( $isFile ) {
				$file = $secureFiles->findById( $fileId );
				$ext  = $file ? strtoupper( (string) pathinfo( (string) ( $file['original_name'] ?? '' ), PATHINFO_EXTENSION ) ) : '';
				$kind = $ext ?: __( 'File', 'monstera' );
				if ( $file && ! empty( $file['filesize'] ) ) {
					$kind .= ' · ' . size_format( (int) $file['filesize'] );
				}
			}
			return compact( 'href', 'isDownload', 'isPaused', 'scope', 'kind' );
		};
	?>

		<nav class="m-chips m-filters" aria-label="<?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_attr( sprintf( __( 'Filter %s', 'monstera' ), ContentPostType::noun() ) ); ?>">
			<a class="m-chip" href="<?php echo esc_url( $filterHref( $slug, 'content', 'all' ) ); ?>"<?php echo 'all' === $activeFilter ? ' aria-current="true"' : ''; ?>>
				<?php esc_html_e( 'All', 'monstera' ); ?>
				<span class="m-chip__count"><?php echo (int) $contentTotal; ?></span>
			</a>
			<?php
			foreach ( $contentSubgroupCounts as $sgId => $count ) :
				$sg = $subgroupRepo->find( $sgId );
				if ( ! $sg ) {
					continue;
				}
				$key = 'sg-' . $sgId;
				?>
				<a class="m-chip" href="<?php echo esc_url( $filterHref( $slug, 'content', $key ) ); ?>"<?php echo $activeFilter === $key ? ' aria-current="true"' : ''; ?>>
					<?php echo esc_html( get_the_title( $sg ) ); ?>
					<span class="m-chip__count"><?php echo (int) $count; ?></span>
				</a>
			<?php endforeach; ?>
		</nav>

		<?php if ( ! $contentRows ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'Nothing published to this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>

			<?php
			$hero = array_shift( $contentRows );
			$d    = $describe( $hero );
			?>
			<section class="m-featured" aria-label="<?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_attr( sprintf( __( 'Featured %s', 'monstera' ), ContentPostType::noun() ) ); ?>">
				<span class="m-featured__mark" aria-hidden="true">
					<svg viewBox="0 0 80 80" fill="currentColor"><path d="M40 8 C 60 15 70 35 70 55 C 60 65 45 70 30 65 C 18 60 10 45 12 28 C 18 16 28 10 40 8 Z" opacity="0.55"/><path d="M40 25 Q 50 30 55 42 Q 52 50 42 47 Q 38 38 40 25 Z" fill="var(--m-surface)"/><path d="M30 42 Q 40 47 42 58 Q 38 64 28 60 Q 25 52 30 42 Z" fill="var(--m-surface)"/></svg>
				</span>
				<?php
				/* translators: %s: month and year the item was published */
				$kicker = sprintf( __( 'Featured · %s', 'monstera' ), wp_date( 'F Y', strtotime( $hero['date'] ) ) );
				?>
				<p class="m-featured__kicker"><?php echo esc_html( $kicker ); ?></p>
				<h2><a class="m-featured__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $hero['id'] ] ) ); ?>"><?php echo esc_html( $hero['title'] ); ?></a></h2>
				<?php if ( $hero['summary'] ) : ?>
					<p class="m-featured__summary"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $hero['summary'] ), 28 ) ); ?></p>
				<?php endif; ?>
				<div class="m-featured__foot">
					<span><?php echo esc_html( $d['kind'] . ' · ' . $d['scope'] ); ?></span>
					<?php if ( $d['isPaused'] ) : ?>
						<span class="m-paused"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
					<?php else : ?>
						<a class="m-btn" data-intent="primary" data-size="sm" href="<?php echo esc_url( $d['href'] ); ?>"<?php echo $d['isDownload'] ? ' download' : ''; ?>>
							<?php echo $d['isDownload'] ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Read →', 'monstera' ); ?>
						</a>
					<?php endif; ?>
				</div>
			</section>

			<?php if ( $contentRows ) : ?>
				<?php $moreCount = max( 0, count( $contentRows ) - 25 ); ?>
				<section class="m-section" aria-labelledby="m-org-content-list">
					<div class="m-section__head">
						<h2 id="m-org-content-list"><?php esc_html_e( 'Earlier this season', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono">
						<?php
							/* translators: %d: content count */
							printf( esc_html( _n( '%d item · scoped to your access', '%d items · scoped to your access', count( $contentRows ), 'monstera' ) ), (int) count( $contentRows ) );
						?>
							</span>
					</div>
					<ul class="m-list" data-reveal>
						<?php
						foreach ( $contentRows as $i => $row ) :
							$d  = $describe( $row );
							$ts = strtotime( (string) $row['date'] ) ?: 0;
							?>
							<li class="m-list__row"<?php echo $i >= 25 ? ' data-more hidden' : ''; ?>>
								<span class="m-list__date"><?php echo esc_html( wp_date( 'M j', $ts ?: null ) ); ?></span>
								<a class="m-list__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] ) ); ?>"><?php echo esc_html( $row['title'] ); ?></a>
								<span class="m-list__meta"><span><?php echo esc_html( $d['scope'] ); ?></span><span><?php echo esc_html( $d['kind'] ); ?></span></span>
								<?php if ( $d['isPaused'] ) : ?>
									<span class="m-paused m-list__action"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
								<?php else : ?>
									<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $d['href'] ); ?>"<?php echo $d['isDownload'] ? ' download' : ''; ?>>
										<?php echo $d['isDownload'] ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Open →', 'monstera' ); ?>
									</a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
					<?php if ( $moreCount ) : ?>
						<p class="m-list__more">
							<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-wp-on--click="actions.revealMore">
								<?php
								/* translators: %d: number of rows still hidden */
								printf( esc_html( _n( 'Show %d more →', 'Show %d more →', $moreCount, 'monstera' ) ), (int) $moreCount );
								?>
							</button>
						</p>
					<?php endif; ?>
				</section>
			<?php endif; ?>

		<?php endif; ?>

	<?php elseif ( 'projects' === $activeTab ) : ?>
		<?php if ( ! $orgProjects ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No projects yet for this organization.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<?php
			$pipelineStages = [
				ProjectMeta::STATUS_PROPOSED,
				ProjectMeta::STATUS_DISCOVERY,
				ProjectMeta::STATUS_IN_PROGRESS,
				ProjectMeta::STATUS_REVIEW,
				ProjectMeta::STATUS_COMPLETED,
			];
			$inFlight       = 0;
			$completedCount = 0;
			foreach ( $orgProjects as $project ) {
				$projectStatus = $projectRepo->status( (int) $project->ID );
				if ( in_array( $projectStatus, [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true ) ) {
					++$completedCount;
				} elseif ( ProjectMeta::STATUS_PROPOSED !== $projectStatus ) {
					++$inFlight;
				}
			}
			?>
			<section class="m-section" aria-labelledby="m-org-projects">
				<div class="m-section__head">
					<h2 id="m-org-projects"><?php esc_html_e( 'Projects', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						printf(
							/* translators: 1: how many projects are under way, 2: how many are completed */
							esc_html__( '%1$s · %2$s', 'monstera' ),
							/* translators: %d: number of projects under way */
							esc_html( sprintf( _n( '%d in flight', '%d in flight', $inFlight, 'monstera' ), $inFlight ) ),
							/* translators: %d: number of completed projects */
							esc_html( sprintf( _n( '%d completed', '%d completed', $completedCount, 'monstera' ), $completedCount ) )
						);
					?>
						</span>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $orgProjects as $project ) :
						$pid          = (int) $project->ID;
						$pStat        = $projectRepo->status( $pid );
						$dueOn        = (string) get_post_meta( $pid, ProjectMeta::KEY_DUE_ON, true );
						$endedOn      = (string) get_post_meta( $pid, ProjectMeta::KEY_ENDED_ON, true );
						$teamSize     = count( $projectRepo->memberIds( $pid ) );
						$isDone       = in_array( $pStat, [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true );
						$currentIndex = array_search( $pStat, $pipelineStages, true );
						if ( false === $currentIndex ) {
							$currentIndex = 0;
						}
						$tone = match ( $pStat ) {
							ProjectMeta::STATUS_COMPLETED => 'success',
							ProjectMeta::STATUS_ARCHIVED  => 'neutral',
							ProjectMeta::STATUS_ON_HOLD   => 'suspended',
							ProjectMeta::STATUS_DISCOVERY => 'info',
							ProjectMeta::STATUS_PROPOSED  => 'pending',
							ProjectMeta::STATUS_REVIEW    => 'warning',
							default                       => 'active',
						};
						$pUrl = Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $pid ] );
						?>
						<li class="m-rows__row">
							<span class="m-rows__date">
								<?php
								if ( ProjectMeta::STATUS_ON_HOLD === $pStat ) {
									esc_html_e( 'on hold', 'monstera' );
								} elseif ( $isDone && $endedOn ) {
									echo esc_html( wp_date( 'M j', strtotime( $endedOn ) ) );
								} elseif ( $dueOn ) {
									/* translators: %s: due date, e.g. "Mar 4". */
									printf( esc_html__( 'due %s', 'monstera' ), esc_html( wp_date( 'M j', strtotime( $dueOn ) ) ) );
								}
								?>
							</span>
							<a class="m-rows__title" href="<?php echo esc_url( $pUrl ); ?>"><?php echo esc_html( get_the_title( $project ) ); ?></a>
							<span class="m-rows__meta">
								<span class="m-badge" data-tone="<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( ProjectMeta::statusLabel( $pStat ) ); ?></span>
								<span>
									<?php
									/* translators: %d: team size count */
									printf( esc_html( _n( '%d on team', '%d on team', $teamSize, 'monstera' ) ), (int) $teamSize );
									?>
								</span>
							</span>
							<span class="m-rows__side">
								<?php if ( $isDone ) : ?>
									<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $pUrl ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a>
								<?php else : ?>
									<?php
									/* translators: 1: current stage number, 2: total stages */
									$stageLabel = sprintf( __( 'Stage %1$d of %2$d', 'monstera' ), (int) $currentIndex + 1, count( $pipelineStages ) );
									?>
									<span class="m-progress" role="img" aria-label="<?php echo esc_attr( $stageLabel ); ?>">
										<?php foreach ( $pipelineStages as $idx => $stage ) : ?>
											<span<?php echo $idx < $currentIndex ? ' data-done' : ( $idx === $currentIndex ? ' data-now' : '' ); ?>></span>
										<?php endforeach; ?>
									</span>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

	<?php elseif ( 'subgroups' === $activeTab ) : ?>
		<?php if ( ! $orgSubgroups ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No sub-groups for this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<?php
			$mySubgroups = $subgroupRepo->subgroupsForMember( (int) $user->ID );
			$mineHere    = count( array_filter( $orgSubgroups, static fn ( $sg ) => in_array( (int) $sg->ID, $mySubgroups, true ) ) );
			?>
			<section class="m-section" aria-labelledby="m-org-subgroups">
				<div class="m-section__head">
					<h2 id="m-org-subgroups"><?php esc_html_e( 'Sub-groups', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						printf(
							/* translators: 1: how many sub-groups the organization has, 2: how many of them the reader belongs to */
							esc_html__( '%1$s · %2$s', 'monstera' ),
							/* translators: %d: number of sub-groups */
							esc_html( sprintf( _n( '%d group', '%d groups', count( $orgSubgroups ), 'monstera' ), count( $orgSubgroups ) ) ),
							/* translators: %d: number of these sub-groups the reader belongs to */
							esc_html( sprintf( __( 'you’re in %d', 'monstera' ), $mineHere ) )
						);
					?>
						</span>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $orgSubgroups as $sg ) :
						$sgId      = (int) $sg->ID;
						$leaderId  = (int) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_LEADER, true );
						$leader    = $leaderId ? get_userdata( $leaderId ) : null;
						$memCount  = count( $subgroupRepo->memberIds( $sgId ) );
						$cadence   = (string) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_MEETING_CADENCE, true );
						$isPrivate = (bool) get_post_meta( $sgId, \Monstera\Subgroups\Meta::KEY_IS_PRIVATE, true );
						$isMember  = $isAdmin || in_array( $sgId, $mySubgroups, true );
						$openUrl   = add_query_arg(
							[
								'tab'    => 'content',
								'filter' => 'sg-' . $sgId,
							],
							Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] )
						);
						$facts     = [];
						if ( $leader ) {
							/* translators: %s: leader's name */
							$facts[] = sprintf( __( 'Chaired by %s', 'monstera' ), trim( $leader->first_name . ' ' . $leader->last_name ) ?: $leader->display_name );
						}
						/* translators: %d: member count */
						$facts[] = sprintf( _n( '%d member', '%d members', $memCount, 'monstera' ), $memCount );
						?>
						<li class="m-rows__row">
							<span class="m-rows__date"><?php echo esc_html( $cadence ?: __( 'As needed', 'monstera' ) ); ?></span>
							<?php if ( $isMember ) : ?>
								<a class="m-rows__title" href="<?php echo esc_url( $openUrl ); ?>"><?php echo esc_html( get_the_title( $sg ) ); ?></a>
							<?php else : ?>
								<span class="m-rows__title"><?php echo esc_html( get_the_title( $sg ) ); ?></span>
							<?php endif; ?>
							<span class="m-rows__meta">
								<?php if ( $isMember && ! $isAdmin ) : ?>
									<span class="m-badge" data-tone="brand"><?php esc_html_e( 'Member', 'monstera' ); ?></span>
								<?php endif; ?>
								<?php if ( $isPrivate ) : ?>
									<span class="m-badge" data-tone="neutral"><?php esc_html_e( 'Private', 'monstera' ); ?></span>
								<?php endif; ?>
								<span><?php echo esc_html( implode( ' · ', $facts ) ); ?></span>
							</span>
							<span class="m-rows__side">
								<?php if ( $isMember ) : ?>
									<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $openUrl ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a>
								<?php elseif ( Modules::isActive( Modules::SUPPORT ) ) : ?>
									<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW ) ); ?>"><?php esc_html_e( 'Ask to join →', 'monstera' ); ?></a>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

<?php elseif ( 'resources' === $activeTab ) : ?>
		<?php if ( ! $orgForms ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No resources published to this organization yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<section class="m-section" aria-labelledby="m-org-resources">
				<div class="m-section__head">
					<h2 id="m-org-resources"><?php esc_html_e( 'Resources', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						/* translators: %d: number of resources */
						printf( esc_html( _n( '%d resource', '%d resources', count( $orgForms ), 'monstera' ) ), (int) count( $orgForms ) );
					?>
						</span>
				</div>
				<ul class="m-list">
					<?php
					// The same row the Resources page renders, so a resource reads
					// the same wherever a member meets it.
					foreach ( $orgForms as $form ) {
						require __DIR__ . '/partials/_resource-row.php';
					}
					?>
				</ul>
			</section>
		<?php endif; ?>

	<?php elseif ( 'members' === $activeTab ) : ?>
		<?php if ( $canManageOrg ) : ?>
			<form class="m-invite" data-org-id="<?php echo (int) $orgId; ?>" data-wp-on--submit="actions.inviteMember">
				<h2><?php esc_html_e( 'Invite a member', 'monstera' ); ?></h2>
				<p>
					<?php
					if ( $seatLimit ) {
						/* translators: 1: seats used, 2: seat limit */
						printf( esc_html__( '%1$d of %2$d seats used. They\'ll get an email to set a password and join the portal.', 'monstera' ), (int) count( $orgMembers ), (int) $seatLimit );
					} else {
						esc_html_e( 'They\'ll get an email to set a password and join the portal.', 'monstera' );
					}
					?>
				</p>
				<div class="m-invite__fields">
					<div class="m-field">
						<label class="m-field__label" for="m-invite-first"><?php esc_html_e( 'First name', 'monstera' ); ?></label>
						<input class="m-input" id="m-invite-first" name="first_name" type="text" autocomplete="off" />
					</div>
					<div class="m-field">
						<label class="m-field__label" for="m-invite-last"><?php esc_html_e( 'Last name', 'monstera' ); ?></label>
						<input class="m-input" id="m-invite-last" name="last_name" type="text" autocomplete="off" />
					</div>
					<div class="m-field" data-span>
						<label class="m-field__label" for="m-invite-email"><?php esc_html_e( 'Email', 'monstera' ); ?></label>
						<input class="m-input" id="m-invite-email" name="email" type="email" required autocomplete="off" inputmode="email" spellcheck="false" />
					</div>
				</div>
				<div class="m-invite__actions">
					<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php esc_html_e( 'Send invitation', 'monstera' ); ?></button>
				</div>
			</form>
		<?php endif; ?>
		<?php if ( ! $orgMembers ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message"><?php esc_html_e( 'No members yet.', 'monstera' ); ?></p>
			</div>
		<?php else : ?>
			<?php $rosterMore = max( 0, count( $orgMembers ) - 25 ); ?>
			<section class="m-section" aria-labelledby="m-org-members">
				<div class="m-section__head">
					<h2 id="m-org-members"><?php esc_html_e( 'Members', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						/* translators: %d: number of members */
						printf( esc_html( _n( '%d person', '%d people', count( $orgMembers ), 'monstera' ) ), (int) count( $orgMembers ) );
					?>
						</span>
				</div>
				<?php
				// The store announces the outcome of Remove and Resend; the
				// sentences travel on the list so they are translated here.
				?>
				<ul class="m-roster" data-reveal
					data-msg-removed="<?php esc_attr_e( 'Removed from the organization.', 'monstera' ); ?>"
					data-msg-remove-failed="<?php esc_attr_e( 'Could not remove that member. Try again.', 'monstera' ); ?>"
					data-msg-resend-failed="<?php esc_attr_e( 'Could not resend the invitation. Try again.', 'monstera' ); ?>"
					data-msg-sent="<?php esc_attr_e( 'Invitation sent again.', 'monstera' ); ?>">
					<?php
					foreach ( $orgMembers as $i => $member ) :
						$memberId  = (int) $member->ID;
						$isSelf    = $memberId === (int) $user->ID;
						$name      = trim( $member->first_name . ' ' . $member->last_name ) ?: $member->display_name;
						$firstName = $member->first_name ?: $member->display_name;
						$position  = (string) get_user_meta( $memberId, UserMeta::KEY_POSITION, true );
						$photo     = (int) get_user_meta( $memberId, UserMeta::KEY_PROFILE_PHOTO, true );
						$photoUrl  = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
						$signedIn  = '' !== (string) get_user_meta( $memberId, UserMeta::KEY_LAST_LOGIN, true );
						$isManager = in_array( Capabilities::ROLE_ORG_MANAGER, (array) $member->roles, true );
						if ( $signedIn ) {
							$roleLine = implode( ' · ', array_filter( [ $position, $isManager ? __( 'manager', 'monstera' ) : '' ] ) );
						} else {
							/* translators: %s: the date the invitation went out */
							$roleLine = sprintf( __( 'Invited %s · not yet signed in', 'monstera' ), wp_date( 'M j', strtotime( $member->user_registered ) ?: null ) );
						}
						?>
						<li data-roster-row data-member-id="<?php echo (int) $memberId; ?>"<?php echo $isSelf ? ' data-self' : ''; ?><?php echo $i >= 25 ? ' data-more hidden' : ''; ?>>
							<span class="m-avatar" data-size="md" aria-hidden="true">
								<?php if ( $photoUrl ) : ?>
									<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
								<?php else : ?>
									<?php \Monstera\Core\Icons::emit( 'sprout', 22 ); ?>
								<?php endif; ?>
							</span>
							<span>
								<span class="m-roster__name"><?php echo esc_html( $name ); ?></span>
								<?php if ( $roleLine ) : ?>
									<span class="m-roster__role"><?php echo esc_html( $roleLine ); ?></span>
								<?php endif; ?>
							</span>
							<?php if ( $isSelf ) : ?>
								<span class="m-mono m-roster__role"><?php esc_html_e( 'You', 'monstera' ); ?></span>
							<?php elseif ( $canManageOrg ) : ?>
								<span class="m-roster__actions">
									<?php if ( ! $signedIn ) : ?>
										<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-org-id="<?php echo (int) $orgId; ?>" data-member-id="<?php echo (int) $memberId; ?>" data-sent-label="<?php esc_attr_e( 'Sent', 'monstera' ); ?>" data-wp-on--click="actions.resendInvite"><?php esc_html_e( 'Resend', 'monstera' ); ?></button>
									<?php endif; ?>
									<button type="button" class="m-btn" data-intent="ghost" data-size="sm" aria-expanded="false" aria-controls="m-roster-confirm-<?php echo (int) $memberId; ?>" data-wp-on--click="actions.confirmRemove"><?php esc_html_e( 'Remove', 'monstera' ); ?></button>
								</span>
								<div class="m-roster__confirm" id="m-roster-confirm-<?php echo (int) $memberId; ?>" role="group" aria-label="<?php esc_attr_e( 'Confirm removal', 'monstera' ); ?>" hidden data-wp-on--keydown="actions.rosterKeydown">
									<span>
										<?php
										/* translators: 1: the member's first name, 2: the organization's name */
										printf( esc_html__( 'Remove %1$s from %2$s? They lose access right away.', 'monstera' ), esc_html( $firstName ), esc_html( get_the_title( $org ) ) );
										?>
									</span>
									<button type="button" class="m-btn" data-intent="secondary" data-size="sm" data-keep data-wp-on--click="actions.cancelRemove"><?php esc_html_e( 'Keep', 'monstera' ); ?></button>
									<button type="button" class="m-btn" data-intent="primary" data-size="sm" data-org-id="<?php echo (int) $orgId; ?>" data-member-id="<?php echo (int) $memberId; ?>" data-wp-on--click="actions.removeMember">
										<?php
										/* translators: %s: the member's first name */
										printf( esc_html__( 'Remove %s', 'monstera' ), esc_html( $firstName ) );
										?>
									</button>
								</div>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( $rosterMore ) : ?>
					<p class="m-list__more">
						<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-wp-on--click="actions.revealMore">
							<?php
							/* translators: %d: number of rows still hidden */
							printf( esc_html( _n( 'Show %d more →', 'Show %d more →', $rosterMore, 'monstera' ) ), (int) $rosterMore );
							?>
						</button>
					</p>
				<?php endif; ?>
			</section>
		<?php endif; ?>

<?php elseif ( 'manage' === $activeTab ) : ?>
		<?php require __DIR__ . '/partials/_org-manage.php'; ?>

	<?php endif; ?>

	</div>

	<!-- Rail: about, membership, leadership -->
	<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'About this organization', 'monstera' ); ?>">
		<div class="m-rail-block">
			<h3><?php esc_html_e( 'About this org', 'monstera' ); ?></h3>
			<div class="m-stat">
				<span class="m-stat__label"><?php esc_html_e( 'Joined', 'monstera' ); ?></span>
				<span class="m-stat__value"><?php echo esc_html( wp_date( 'M Y', (int) get_post_time( 'U', true, $org ) ) ); ?></span>
			</div>
			<?php if ( $expires ) : ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Renews', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( wp_date( 'M j, Y', strtotime( $expires ) ) ); ?></span>
				</div>
			<?php endif; ?>
			<?php if ( $tier ) : ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Tier', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( $tier ); ?></span>
				</div>
			<?php endif; ?>
			<div class="m-stat">
				<span class="m-stat__label"><?php esc_html_e( 'Seats used', 'monstera' ); ?></span>
				<span class="m-stat__value">
					<?php echo (int) count( $orgMembers ); ?>
					<?php echo $seatLimit ? ' / ' . (int) $seatLimit : ''; ?>
				</span>
			</div>
			<?php if ( $location ) : ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Region', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( $location ); ?></span>
				</div>
			<?php endif; ?>
			<div class="m-stat">
				<span class="m-stat__label"><?php esc_html_e( 'Status', 'monstera' ); ?></span>
				<span class="m-stat__value"><?php echo esc_html( ucfirst( $orgStatus ) ); ?></span>
			</div>
		</div>

		<?php if ( $canRenewOrg && ( current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) || Membership::renewalOpen( $orgId ) ) ) : ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Membership', 'monstera' ); ?></h3>
				<p>
					<?php
					if ( $expires ) {
						/* translators: %s: expiry date */
						printf( esc_html__( 'Expires %s. ', 'monstera' ), esc_html( wp_date( 'M j, Y', strtotime( $expires ) ) ) );
					}
					esc_html_e( 'Renewing extends the membership one year from the payment date.', 'monstera' );
					?>
				</p>
				<button type="button" class="m-btn" data-intent="secondary" data-size="sm" data-renew data-org-id="<?php echo (int) $orgId; ?>" data-wp-on--click="actions.startRenewal"><?php esc_html_e( 'Renew membership →', 'monstera' ); ?></button>
			</div>
		<?php endif; ?>

		<?php if ( $leaders ) : ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Leadership', 'monstera' ); ?></h3>
				<ul class="m-people">
					<?php
					foreach ( $leaders as $member ) :
						$position = (string) get_user_meta( $member->ID, UserMeta::KEY_POSITION, true );
						$photo    = (int) get_user_meta( $member->ID, UserMeta::KEY_PROFILE_PHOTO, true );
						$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
						?>
						<li>
							<span class="m-avatar" aria-hidden="true">
								<?php if ( $photoUrl ) : ?>
									<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
								<?php else : ?>
									<?php \Monstera\Core\Icons::emit( 'sprout', 18 ); ?>
								<?php endif; ?>
							</span>
							<span>
								<?php echo esc_html( trim( $member->first_name . ' ' . $member->last_name ) ?: $member->display_name ); ?>
								<?php if ( $position ) : ?>
									<small><?php echo esc_html( $position ); ?></small>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW ) ); ?>"><?php esc_html_e( 'Open a support request →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</aside>
</div>
</div>
