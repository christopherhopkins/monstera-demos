<?php
/**
 * Support switched off in Settings: every support address answers with the
 * blocked pattern, so a typed or bookmarked URL explains itself.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Portal\Audience;

defined( 'ABSPATH' ) || exit;
?>
<section class="m-blocked" data-reason="module-off">
	<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
	<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
	<h1><?php esc_html_e( 'Support requests are not enabled on this site.', 'monstera' ); ?></h1>
	<p>
		<?php if ( Audience::isStandalone( (int) $ctx['user']->ID ) ) : ?>
			<?php
			/* translators: %s: site name */
			printf( esc_html__( 'Contact %s directly, or check back later.', 'monstera' ), esc_html( Audience::siteName() ) );
			?>
		<?php else : ?>
			<?php esc_html_e( 'Ask your account team how to reach them, or check back later if your admin enables the module.', 'monstera' ); ?>
		<?php endif; ?>
	</p>
	<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
</section>
