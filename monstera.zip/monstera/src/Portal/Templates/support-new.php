<?php
/**
 * Support — open a request (comp 80).
 *
 * The form: a subject, what is going on, optional screenshots or files
 * (the picker, holding them until the send), the priority as a stacked
 * radio list. ?project=<id> says which project it is about. The message and
 * its files go in one request, with a bar while they do, and a send lands
 * on the request's own page. The member's latest requests and the email
 * fallback are in the rail.
 *
 * A person in several organizations (comp 87) also says which one the
 * request is filed with: a select above Subject, opened on the project's
 * organization, else the one the address names (?org=<id>, from a hub or an
 * item's page), else the context organization. A project sits in that field
 * and goes when another organization is chosen, since a request about a
 * project is its organization's; and each request in the rail names its
 * organization. With one organization or none the form is what it always
 * was, to the byte: the field takes the place of the project line in one
 * branch, so nobody else's page gains so much as a blank.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Portal\DocumentTitle;
use Monstera\Portal\SupportPages;
use Monstera\Portal\SupportView;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Support\Inbox;
use Monstera\Support\Repository as SupportRepository;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::SUPPORT ) ) {
	include __DIR__ . '/_support-off.php';
	return;
}

$user      = $ctx['user'];
$projectId = isset( $_GET['project'] ) ? absint( $_GET['project'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
// Only a project the member can open is named; the route checks again.
$projectTitle = $projectId && ( new ProjectRepository() )->userCanAccess( (int) $user->ID, $projectId ) ? get_the_title( $projectId ) : '';
$recent       = ( new SupportRepository() )->listForMember( (int) $user->ID );
$email        = Inbox::email();

// The organizations to choose between; none for anyone with nothing to
// choose. A request about a project is the project's organization's, so when
// that is not one of theirs to choose (they are on its team from outside, or
// it has none) the project settles it and the form asks nothing.
$orgChoices = SupportPages::filingOrgs( $user );
$projectOrg = $projectTitle ? (int) get_post_meta( $projectId, ProjectMeta::KEY_ORG_ID, true ) : 0;
if ( $projectTitle && ! isset( $orgChoices[ $projectOrg ] ) ) {
	$orgChoices = [];
}
$orgChosen = $orgChoices ? SupportPages::chosenOrg( $user, $orgChoices, $projectOrg, $_GET ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
// What the rail's requests name as theirs: for a person in several only.
$orgNames = SupportPages::orgNames( $user, array_slice( $recent, 0, 3 ) );

DocumentTitle::name( __( 'New request', 'monstera' ), __( 'Support', 'monstera' ) );

// The breadcrumb is the hero's own, above its heading: printed before the
// hero it sat straight in the page, which has no gutter, and began at the
// window's edge. Inside, it starts where the heading starts at every width,
// as on a request's page and an item's, whose breadcrumb shares the
// container of their heading. data-crumbs moves the hero's top space under
// the breadcrumb, so it keeps its place below the bar.
?>

<section class="monstera-portal__hero" data-crumbs>
	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>"><?php esc_html_e( 'Support', 'monstera' ); ?></a>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php esc_html_e( 'New request', 'monstera' ); ?></span>
	</nav>
	<h1><?php esc_html_e( 'Open a support request', 'monstera' ); ?></h1>
	<p><?php esc_html_e( 'Tell us what you need. We\'ll reply here and by email.', 'monstera' ); ?></p>
</section>

<div class="monstera-portal__dash">
	<div class="m-dash">
		<div class="m-dash__main">
			<form
				method="post"
				enctype="multipart/form-data"
				class="m-form"
				data-plain
				action="<?php echo esc_url( Routing::restUrl( 'monstera/v1/support/requests' ) ); ?>"
				data-wp-on--submit="actions.submitSupport"
				<?php foreach ( SupportView::fileFormAttributes( __( 'Goes with your request', 'monstera' ) ) as $attribute => $value ) : ?>
					<?php echo esc_attr( $attribute ); ?>="<?php echo esc_attr( $value ); ?>"
				<?php endforeach; ?>>
				<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>

				<?php if ( $orgChoices ) : ?>
					<div class="m-field">
						<label class="m-field__label" for="sr-org"><?php esc_html_e( 'Organization', 'monstera' ); ?></label>
						<?php
						// Choosing another organization lets the project go (the
						// store's supportOrgChange): the select says whose it is and
						// what the page then announces. A page come back to opens on
						// the organization it was rendered with, never on a choice the
						// browser remembered beside a project that is back on the page.
						?>
						<select class="m-select" id="sr-org" name="org_id" autocomplete="off" aria-describedby="sr-org-hint"<?php echo $projectTitle ? ' data-project-org="' . (int) $projectOrg . '" data-msg-project-cleared="' . esc_attr__( 'Project cleared.', 'monstera' ) . '" data-wp-on--change="actions.supportOrgChange"' : ''; ?>>
							<?php foreach ( $orgChoices as $choiceId => $choiceName ) : ?>
								<option value="<?php echo (int) $choiceId; ?>"<?php echo $choiceId === $orgChosen ? ' selected' : ''; ?>><?php echo esc_html( $choiceName ); ?></option>
							<?php endforeach; ?>
						</select>
						<span class="m-field__hint" id="sr-org-hint"><?php esc_html_e( 'Your request is filed with this organization.', 'monstera' ); ?><?php echo $projectTitle ? '<span data-about-project> ' . esc_html__( 'Choose another organization and the project is cleared.', 'monstera' ) . '</span>' : ''; ?></span>
						<?php if ( $projectTitle ) : ?>
							<input type="hidden" name="project_id" value="<?php echo esc_attr( (string) $projectId ); ?>" />
							<p class="m-form__context" data-about-project>
								<?php
								/* translators: %s: project title (wrapped in <strong>). */
								printf( esc_html__( 'About project: %s', 'monstera' ), '<strong>' . esc_html( $projectTitle ) . '</strong>' );
								?>
								· <a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW, [ 'org' => $projectOrg ] ) ); ?>"><?php esc_html_e( 'Change project', 'monstera' ); ?></a>
							</p>
						<?php endif; ?>
					</div>
				<?php elseif ( $projectTitle ) : ?>
					<input type="hidden" name="project_id" value="<?php echo esc_attr( (string) $projectId ); ?>" />
					<p class="m-form__context">
						<?php
						/* translators: %s: project title (wrapped in <strong>). */
						printf( esc_html__( 'About project: %s', 'monstera' ), '<strong>' . esc_html( $projectTitle ) . '</strong>' );
						?>
						<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW ) ); ?>"><?php esc_html_e( 'change', 'monstera' ); ?></a>
					</p>
				<?php endif; ?>

				<div class="m-field">
					<label class="m-field__label" for="sr-subject"><?php esc_html_e( 'Subject', 'monstera' ); ?></label>
					<input class="m-input" id="sr-subject" type="text" name="subject" required maxlength="200" />
				</div>

				<div class="m-field">
					<label class="m-field__label" for="sr-body"><?php esc_html_e( 'What\'s going on?', 'monstera' ); ?></label>
					<textarea class="m-textarea" id="sr-body" name="body" rows="8" required></textarea>
					<span class="m-field__hint"><?php esc_html_e( 'Be specific. URLs, screenshots and timestamps help a lot.', 'monstera' ); ?></span>
				</div>

				<?php
				$supportFieldId = 'sr-files';
				require __DIR__ . '/partials/_support-file-field.php';
				?>

				<fieldset class="m-choices" data-stack>
					<legend><?php esc_html_e( 'Priority', 'monstera' ); ?></legend>
					<?php foreach ( SupportView::priorityChoices() as $choice => [ $choiceName, $choiceMeans ] ) : ?>
						<label><input type="radio" name="priority" value="<?php echo esc_attr( $choice ); ?>"<?php echo SupportRepository::PRIORITY_NORMAL === $choice ? ' checked' : ''; ?> /><span><?php echo esc_html( $choiceName ); ?><small><?php echo esc_html( $choiceMeans ); ?></small></span></label>
					<?php endforeach; ?>
					<span class="m-field__hint"><?php esc_html_e( 'We see every request within one business day, whatever its priority. You can change it later.', 'monstera' ); ?></span>
				</fieldset>

				<div class="m-form__actions">
					<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php esc_html_e( 'Send request', 'monstera' ); ?></button>
				</div>
				<div class="m-sending" data-sending hidden>
					<progress max="100" value="0" aria-label="<?php esc_attr_e( 'Sending your request', 'monstera' ); ?>"></progress>
					<span></span>
				</div>
				<p class="m-sr-only" role="status" aria-live="polite" aria-atomic="false" data-files-status></p>
			</form>
		</div>

		<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'Your requests', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Your requests', 'monstera' ); ?></h3>
				<?php if ( ! $recent ) : ?>
					<p class="m-rail-block__empty"><?php esc_html_e( 'No requests yet. Anything you send will land here.', 'monstera' ); ?></p>
				<?php else : ?>
					<ul class="m-requests">
						<?php foreach ( array_slice( $recent, 0, 3 ) as $row ) : ?>
							<li>
								<span class="m-requests__top">
									<a href="<?php echo esc_url( SupportRepository::portalUrl( $row ) ); ?>"><?php echo esc_html( (string) $row['subject'] ); ?></a>
									<span class="m-badge" data-tone="<?php echo esc_attr( SupportView::statusTone( (string) $row['status'] ) ); ?>"><?php echo esc_html( SupportView::statusLabel( (string) $row['status'] ) ); ?></span>
								</span>
								<time datetime="<?php echo esc_attr( gmdate( 'c', (int) strtotime( (string) ( $row['last_activity_at'] ?: $row['created_at'] ) . ' UTC' ) ) ); ?>"><?php echo esc_html( (string) $row['ref'] ); ?> · <?php echo isset( $orgNames[ (int) $row['org_id'] ] ) ? esc_html( $orgNames[ (int) $row['org_id'] ] ) . ' · ' : ''; ?><?php echo esc_html( SupportView::when( $row ) ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>"><?php esc_html_e( 'All requests →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Prefer email?', 'monstera' ); ?></h3>
				<p class="m-rail-block__empty">
					<?php
					printf(
						/* translators: %s: the support email address as a link */
						esc_html__( 'Write to %s. We answer email by email; it won\'t appear in your requests here.', 'monstera' ),
						'<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>'
					);
					?>
				</p>
			</div>
		</aside>
	</div>
</div>
