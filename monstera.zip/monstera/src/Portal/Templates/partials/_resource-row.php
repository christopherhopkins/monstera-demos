<?php
/**
 * One resource row (comp 82), shared by the Resources page and the org hub's
 * Resources tab: the kind in the date column, the title, the description or
 * the file facts on the meta line, and the one action the kind allows. A
 * shortcode form renders inline on the Resources page only, so its row links
 * to that page's anchor wherever the row is shown.
 *
 * Included in the caller's scope, one row per include.
 *
 * @var \WP_Post $form
 */

declare(strict_types=1);

use Monstera\Core\Routing;
use Monstera\Forms\Meta as FormsMeta;

$rowType  = (string) ( get_post_meta( $form->ID, FormsMeta::KEY_FORM_TYPE, true ) ?: FormsMeta::TYPE_PDF );
$rowDesc  = trim( wp_strip_all_tags( (string) get_post_meta( $form->ID, FormsMeta::KEY_DESCRIPTION, true ) ) );
$rowTitle = get_the_title( $form );
$rowKind  = __( 'Form', 'monstera' );
$rowFacts = '';
$rowHref  = Routing::url( Routing::ROUTE_FORMS ) . '#m-form-' . (int) $form->ID;
$rowAttrs = '';
$rowLabel = __( 'Open →', 'monstera' );
if ( FormsMeta::TYPE_PDF === $rowType ) {
	$rowKind   = __( 'PDF', 'monstera' );
	$rowFileId = (int) get_post_meta( $form->ID, FormsMeta::KEY_PDF_FILE_ID, true );
	$rowUrl    = $rowFileId ? (string) wp_get_attachment_url( $rowFileId ) : '';
	$rowPath   = $rowFileId ? (string) get_attached_file( $rowFileId ) : '';
	$rowSize   = $rowPath && file_exists( $rowPath ) ? (int) filesize( $rowPath ) : 0;
	/* translators: %s: the date the resource was last updated */
	$rowUpdated = sprintf( __( 'updated %s', 'monstera' ), wp_date( 'M j', (int) get_post_modified_time( 'U', true, $form ) ) );
	$rowFacts   = implode( ' · ', array_filter( [ $rowSize ? size_format( $rowSize ) : '', $rowUpdated ] ) );
	// Through the logging redirect, so the admin can count opens.
	$rowHref  = $rowUrl ? Routing::url( Routing::ROUTE_FORM_OPEN, [ 'id' => $form->ID ] ) : '';
	$rowAttrs = $rowUrl ? ' download="' . esc_attr( $rowPath ? wp_basename( $rowPath ) : 'form.pdf' ) . '"' : '';
	$rowLabel = __( 'Download →', 'monstera' );
} elseif ( FormsMeta::TYPE_EXTERNAL === $rowType ) {
	$rowKind  = __( 'Link', 'monstera' );
	$rowHref  = '' !== (string) get_post_meta( $form->ID, FormsMeta::KEY_EXTERNAL_URL, true ) ? Routing::url( Routing::ROUTE_FORM_OPEN, [ 'id' => $form->ID ] ) : '';
	$rowFacts = __( 'opens in a new tab', 'monstera' );
	$rowAttrs = ' target="_blank" rel="noopener noreferrer"';
	$rowLabel = __( 'Visit ↗', 'monstera' );
}
?>
<li class="m-list__row">
	<span class="m-list__date"><?php echo esc_html( $rowKind ); ?></span>
	<?php if ( $rowHref ) : ?>
		<a class="m-list__title" href="<?php echo esc_url( $rowHref ); ?>"<?php echo $rowAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?>><?php echo esc_html( $rowTitle ); ?></a>
	<?php else : ?>
		<span class="m-list__title"><?php echo esc_html( $rowTitle ); ?></span>
	<?php endif; ?>
	<span class="m-list__meta"><span><?php echo esc_html( $rowDesc ? wp_trim_words( $rowDesc, 20 ) : $rowFacts ); ?></span></span>
	<?php if ( $rowHref ) : ?>
		<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $rowHref ); ?>"<?php echo $rowAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?>><?php echo esc_html( $rowLabel ); ?></a>
	<?php else : ?>
		<span class="m-list__action m-paused"><?php esc_html_e( 'Awaiting upload', 'monstera' ); ?></span>
	<?php endif; ?>
</li>
