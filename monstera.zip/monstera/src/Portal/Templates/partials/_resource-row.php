<?php
/**
 * One resource row (comp 82), shared by the Resources page and the org hub's
 * Resources tab: the kind in the date column (Link, File, Guide), the title,
 * the description or the file facts on the meta line, and the one action
 * the kind allows: Visit for a link, Download for a file, Read for a guide,
 * which opens at /portal/resources/{id}/ (Forms-and-resources track, FR4).
 *
 * For a person in several organizations the Resources page says two things
 * more (People-model track, FR5). The organization the resource reaches
 * them through comes first on the meta line, as on the dashboard's rows
 * (comp 23). And a file that only organizations of theirs that are not live
 * share reads "Download paused" in the action slot, the dashboard's idiom,
 * with no link on the title: Resources\Opener refuses the file all the
 * same. A hub's tab holds that hub's resources alone, so it names no
 * organization and says only where a file waits. Every row of a person in
 * one organization, on the page and on the hub, is what it was.
 *
 * Included in the caller's scope, one row per include. Both facts come from
 * Resources\Repository::besideEach(), asked once for the whole list.
 *
 * @var \WP_Post $resource
 * @var string   $resourceOrg  The organization to name on the meta line, or '' for none.
 * @var bool     $resourceWait Whether the resource's file waits.
 */

declare(strict_types=1);

use Monstera\Core\Routing;
use Monstera\Resources\Meta as ResourcesMeta;

defined( 'ABSPATH' ) || exit;

$rowKindKey = ResourcesMeta::kindOf( (int) $resource->ID );
$rowDesc    = trim( wp_strip_all_tags( (string) get_post_meta( $resource->ID, ResourcesMeta::KEY_DESCRIPTION, true ) ) );
$rowTitle   = get_the_title( $resource );
$rowKind    = __( 'Link', 'monstera' );
$rowFacts   = '';
$rowHref    = '';
$rowAttrs   = '';
$rowLabel   = __( 'Visit ↗', 'monstera' );
$rowOrg     = $resourceOrg;
$rowWaits   = false;
/* translators: %s: the date the resource was last updated */
$rowUpdated = sprintf( __( 'updated %s', 'monstera' ), wp_date( 'M j', (int) get_post_modified_time( 'U', true, $resource ) ) );
if ( ResourcesMeta::KIND_FILE === $rowKindKey ) {
	$rowKind   = __( 'File', 'monstera' );
	$rowFileId = (int) get_post_meta( $resource->ID, ResourcesMeta::KEY_FILE_ID, true );
	$rowUrl    = $rowFileId ? (string) wp_get_attachment_url( $rowFileId ) : '';
	$rowPath   = $rowFileId ? (string) get_attached_file( $rowFileId ) : '';
	$rowSize   = $rowPath && file_exists( $rowPath ) ? (int) filesize( $rowPath ) : 0;
	$rowExt    = $rowPath ? strtoupper( (string) pathinfo( $rowPath, PATHINFO_EXTENSION ) ) : '';
	$rowFacts  = implode( ' · ', array_filter( [ $rowExt, $rowSize ? size_format( $rowSize ) : '', $rowUpdated ] ) );
	// A file not uploaded yet has nothing to pause: it reads "Awaiting upload".
	$rowWaits = $resourceWait && '' !== $rowUrl;
	// Through the logging redirect, so the admin can count opens. A file
	// that waits has no address to print.
	$rowHref  = $rowUrl && ! $rowWaits ? Routing::url( Routing::ROUTE_RESOURCE_OPEN, [ 'id' => $resource->ID ] ) : '';
	$rowAttrs = $rowUrl ? ' download="' . esc_attr( $rowPath ? wp_basename( $rowPath ) : 'resource' ) . '"' : '';
	$rowLabel = __( 'Download →', 'monstera' );
} elseif ( ResourcesMeta::KIND_GUIDE === $rowKindKey ) {
	$rowKind  = __( 'Guide', 'monstera' );
	$rowHref  = Routing::url( Routing::ROUTE_RESOURCE, [ 'id' => $resource->ID ] );
	$rowFacts = $rowUpdated;
	$rowLabel = __( 'Read →', 'monstera' );
} else {
	$rowHref  = '' !== (string) get_post_meta( $resource->ID, ResourcesMeta::KEY_EXTERNAL_URL, true ) ? Routing::url( Routing::ROUTE_RESOURCE_OPEN, [ 'id' => $resource->ID ] ) : '';
	$rowFacts = __( 'opens in a new tab', 'monstera' );
	$rowAttrs = ' target="_blank" rel="noopener noreferrer"';
}
// The meta line: the organization for a person in several, the description
// or the facts, and for a file or a guide with a description the facts too.
$rowMeta = [];
if ( '' !== $rowOrg ) {
	$rowMeta[] = $rowOrg;
}
if ( $rowDesc ) {
	$rowMeta[] = wp_trim_words( $rowDesc, 20 );
	if ( ResourcesMeta::KIND_LINK !== $rowKindKey ) {
		$rowMeta[] = $rowFacts;
	}
} else {
	$rowMeta[] = $rowFacts;
}
?>
<li class="m-list__row">
	<span class="m-list__date"><?php echo esc_html( $rowKind ); ?></span>
	<?php if ( $rowHref ) : ?>
		<a class="m-list__title" href="<?php echo esc_url( $rowHref ); ?>"<?php echo $rowAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?>><?php echo esc_html( $rowTitle ); ?></a>
	<?php else : ?>
		<span class="m-list__title"><?php echo esc_html( $rowTitle ); ?></span>
	<?php endif; ?>
	<span class="m-list__meta"><?php echo implode( '', array_map( static fn ( string $part ): string => '<span>' . esc_html( $part ) . '</span>', array_filter( $rowMeta ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- each part is escaped above. ?></span>
	<?php if ( $rowHref ) : ?>
		<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $rowHref ); ?>"<?php echo $rowAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?>><?php echo esc_html( $rowLabel ); ?></a>
	<?php elseif ( $rowWaits ) : ?>
		<span class="m-paused m-list__action"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
	<?php else : ?>
		<span class="m-list__action m-paused"><?php esc_html_e( 'Awaiting upload', 'monstera' ); ?></span>
	<?php endif; ?>
</li>
