<?php
/**
 * One form row (comp 130), shared by the Forms page and the org hub's Forms
 * tab: where the form stands for the reader in the date column (Due <day>,
 * Open, or Sent <day> once they have sent it), the title leading to the
 * form's page, the sub-line and, on the Forms page for a person in several
 * organizations, the organization it reaches them through on the meta line,
 * and the one action its standing allows: Fill in (first in line for a form
 * that is due), View answers for a once-only form they have sent, or Closed
 * for a form that no longer accepts and that they sent at least once
 * (Forms-and-resources track, FR5; Forms\Standing has the rule).
 *
 * Included in the caller's scope, one row per include.
 *
 * @var \WP_Post                                                                                      $form
 * @var string                                                                                        $formOrg      The organization to name on the meta line, or '' for none.
 * @var array{group: string, action: string, due_on: string, closed_on: string, sent_at: string, sent: int} $formStanding
 */

declare(strict_types=1);

use Monstera\Core\Routing;
use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\Standing;
use Monstera\Portal\CalendarDay;

defined( 'ABSPATH' ) || exit;

$rowHref   = Routing::url( Routing::ROUTE_FORM, [ 'id' => $form->ID ] );
$rowDesc   = trim( wp_strip_all_tags( (string) get_post_meta( $form->ID, FormMeta::KEY_DESCRIPTION, true ) ) );
$rowSent   = '' !== $formStanding['sent_at'] ? wp_date( 'M j', (int) strtotime( $formStanding['sent_at'] . ' UTC' ) ) : '';
$rowDue    = '' !== $formStanding['due_on'] ? CalendarDay::format( $formStanding['due_on'], 'M j' ) : '';
$rowClosed = '' !== $formStanding['closed_on'] ? CalendarDay::format( $formStanding['closed_on'], 'M j' ) : '';

// The date column: the day it is due, the day they last sent it, or Open.
if ( Standing::GROUP_DUE === $formStanding['group'] ) {
	/* translators: %s: a date, e.g. "Mar 4" */
	$rowWhen = sprintf( __( 'Due %s', 'monstera' ), $rowDue );
} elseif ( '' !== $rowSent ) {
	/* translators: %s: a date, e.g. "Mar 4" */
	$rowWhen = sprintf( __( 'Sent %s', 'monstera' ), $rowSent );
} else {
	$rowWhen = __( 'Open', 'monstera' );
}

// The meta line: the organization for a person in several, the sub-line
// (and the due day, for a form they may send again before it), or for a
// closed form when it closed, when its due day is what closed it, and how
// many they sent.
$rowMeta = [];
if ( '' !== $formOrg ) {
	$rowMeta[] = $formOrg;
}
if ( Standing::ACTION_CLOSED === $formStanding['action'] ) {
	$rowMeta[] = sprintf(
		/* translators: 1, 2: two short facts set side by side, e.g. "Closed Mar 4 · 3 sent" */
		__( '%1$s · %2$s', 'monstera' ),
		/* translators: %s: the day a form closed */
		'' !== $rowClosed ? sprintf( __( 'Closed %s', 'monstera' ), $rowClosed ) : __( 'Closed', 'monstera' ),
		/* translators: %d: how many submissions the reader sent (the plural form is for translators; English reads "you sent 1" too) */
		sprintf( _n( 'you sent %d', 'you sent %d', $formStanding['sent'], 'monstera' ), $formStanding['sent'] )
	);
} else {
	if ( $rowDesc ) {
		$rowMeta[] = wp_trim_words( $rowDesc, 20 );
	}
	if ( in_array( $formStanding['group'], [ Standing::GROUP_OPEN, Standing::GROUP_DUE ], true ) && '' !== $rowDue ) {
		// A due row's date column says the day from 768 up, so the meta
		// says it for a phone alone; an open row's column says Sent or Open.
		/* translators: %s: a date, e.g. "Mar 4" */
		$rowMeta[ Standing::GROUP_DUE === $formStanding['group'] ? 'phone' : 'due' ] = sprintf( __( 'Due %s', 'monstera' ), $rowDue );
	}
}
// The date column is gone on a phone: a sent day it says is said there by
// the meta (the due day above is), so no width loses it (WCAG 1.4.10; the
// Phase 6 review).
if ( '' !== $rowSent && Standing::GROUP_DUE !== $formStanding['group'] ) {
	$rowMeta['phone'] = $rowWhen;
}
?>
<li class="m-list__row">
	<span class="m-list__date"><?php echo esc_html( $rowWhen ); ?></span>
	<a class="m-list__title" href="<?php echo esc_url( $rowHref ); ?>"><?php echo esc_html( get_the_title( $form ) ); ?></a>
	<?php $rowParts = array_filter( $rowMeta ); ?>
	<span class="m-list__meta"><?php echo implode( '', array_map( static fn ( string $part, int|string $key ): string => ( 'phone' === $key ? '<span class="m-list__phone">' : '<span>' ) . esc_html( $part ) . '</span>', $rowParts, array_keys( $rowParts ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- each part is escaped above. ?></span>
	<?php if ( Standing::ACTION_CLOSED === $formStanding['action'] ) : ?>
		<span class="m-list__action"><span class="m-badge" data-tone="neutral"><?php esc_html_e( 'Closed', 'monstera' ); ?></span></span>
	<?php elseif ( Standing::ACTION_VIEW === $formStanding['action'] ) : ?>
		<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $rowHref ); ?>"><?php esc_html_e( 'View answers →', 'monstera' ); ?></a>
	<?php else : ?>
		<a class="m-btn m-list__action" data-intent="<?php echo Standing::GROUP_DUE === $formStanding['group'] ? 'primary' : 'ghost'; ?>" data-size="sm" href="<?php echo esc_url( $rowHref ); ?>"><?php esc_html_e( 'Fill in →', 'monstera' ); ?></a>
	<?php endif; ?>
</li>
