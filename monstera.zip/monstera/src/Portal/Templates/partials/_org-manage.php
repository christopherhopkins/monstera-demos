<?php
/**
 * Org-hub "Manage" tab — delegated authoring surface (comps 50–55).
 *
 * Included from org.php in the current scope, so it inherits $orgId, $slug,
 * $user, $orgMembers, $orgSubgroups, and $authorScope. Lets an org manager (or a
 * sub-group leader, auto-scoped to their group) create and maintain content,
 * forms, projects, alerts — and, for managers only, sub-groups. Every write is
 * re-authorized server-side via AuthorScope; this template only renders the
 * affordances and forces the visible audience hint to match.
 *
 * The section switcher is a row of chip links with aria-current; each section
 * renders its compose form (.m-form) above the author's items as a
 * priority-column table. Field-based entities post through the shared
 * `manage*` Interactivity actions; Content opens the block-editor island.
 *
 * @var int                          $orgId
 * @var string                       $slug
 * @var \WP_User                     $user
 * @var \WP_User[]                   $orgMembers
 * @var \WP_Post[]                   $orgSubgroups
 * @var \Monstera\Portal\AuthorScope $authorScope
 */

declare(strict_types=1);

use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Portal\AuthorScope;

if ( ! $authorScope->isAuthor() ) {
	return;
}

$isLeaderActor = $authorScope->isLeader();
$leaderSgName  = $isLeaderActor ? get_the_title( $authorScope->leaderSubgroupId ) : '';

// Available sections: content always; sub-groups for managers only; the rest
// follow module activation — mirroring how the read-only tabs are gated.
$sections = [ 'content' => ContentPostType::label() ];
if ( in_array( AuthorScope::ENTITY_SUBGROUP, $authorScope->manageableEntities(), true ) ) {
	$sections['subgroups'] = __( 'Sub-groups', 'monstera' );
}
if ( Modules::isActive( Modules::FORMS ) ) {
	$sections['forms'] = __( 'Resources', 'monstera' );
}
if ( Modules::isActive( Modules::PROJECTS ) ) {
	$sections['projects'] = __( 'Projects', 'monstera' );
}
if ( Modules::isActive( Modules::ALERTS ) ) {
	$sections['alerts'] = __( 'Alerts', 'monstera' );
}

$section = isset( $_GET['section'] ) ? sanitize_key( (string) $_GET['section'] ) : 'content'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
if ( ! isset( $sections[ $section ] ) ) {
	$section = 'content';
}
$editId  = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
$compose = ! empty( $_GET['compose'] ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.

$mUrl = static function ( array $args ) use ( $slug ): string {
	return add_query_arg( array_merge( [ 'tab' => 'manage' ], $args ), Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] ) );
};

/** @var callable(string):\WP_Post[] $authored */
$authored = static function ( string $postType ) use ( $user ): array {
	return get_posts(
		[
			'post_type'      => $postType,
			'author'         => $user->ID,
			'post_status'    => [ 'publish', 'draft', 'pending' ],
			'posts_per_page' => 100,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		]
	);
};

// Optional "limit to sub-groups" picker. Managers may narrow; a leader's audience
// is fixed to their one group, so they never see it.
$scopePicker = static function ( array $selected = [] ) use ( $orgSubgroups, $isLeaderActor ): void {
	if ( $isLeaderActor || ! $orgSubgroups ) {
		return;
	}
	?>
	<fieldset class="m-choices">
		<legend><?php esc_html_e( 'Limit to sub-groups (optional)', 'monstera' ); ?></legend>
		<?php foreach ( $orgSubgroups as $sg ) : ?>
			<label>
				<input type="checkbox" name="subgroup_ids[]" value="<?php echo (int) $sg->ID; ?>" <?php checked( in_array( (int) $sg->ID, $selected, true ) ); ?> />
				<?php echo esc_html( get_the_title( $sg ) ); ?>
			</label>
		<?php endforeach; ?>
		<span class="m-field__hint"><?php esc_html_e( 'Leave all unticked to reach the whole organization.', 'monstera' ); ?></span>
	</fieldset>
	<?php
};

// "Reaches": the sub-groups an item is limited to, or the whole organization.
$reaches = static function ( array $subgroupIds ): string {
	$titles = array_filter( array_map( static fn ( $id ) => get_the_title( (int) $id ), $subgroupIds ) );
	return $titles ? implode( ', ', $titles ) : __( 'Whole organization', 'monstera' );
};

// Publication status as a badge.
$statusBadge = static function ( string $status ): void {
	$labels = [
		'publish' => __( 'Published', 'monstera' ),
		'draft'   => __( 'Draft', 'monstera' ),
		'pending' => __( 'Pending', 'monstera' ),
	];
	$tones  = [
		'publish' => 'success',
		'draft'   => 'neutral',
		'pending' => 'warning',
	];
	printf(
		'<span class="m-badge" data-tone="%s">%s</span>',
		esc_attr( $tones[ $status ] ?? 'neutral' ),
		esc_html( $labels[ $status ] ?? ucfirst( $status ) )
	);
};

// Edit / Delete for a table row.
$rowActions = static function ( \WP_Post $p, string $endpoint, string $section ) use ( $mUrl ): void {
	$editUrl = $mUrl(
		[
			'section' => $section,
			'edit'    => $p->ID,
		]
	);
	?>
	<span class="m-table__actions">
		<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $editUrl ); ?>"><?php esc_html_e( 'Edit', 'monstera' ); ?></a>
		<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-endpoint="<?php echo esc_attr( $endpoint ); ?>" data-id="<?php echo (int) $p->ID; ?>" data-wp-on--click="actions.manageDelete"><?php esc_html_e( 'Delete', 'monstera' ); ?></button>
	</span>
	<?php
};
?>

<section class="m-manage" aria-labelledby="m-manage-title">
	<header class="m-manage__head">
		<h2 id="m-manage-title"><?php esc_html_e( 'Manage', 'monstera' ); ?></h2>
		<p>
			<?php
			if ( $isLeaderActor ) {
				/* translators: 1: sub-group name, 2: organization name */
				printf( esc_html__( 'Everything you create here is scoped to %1$s, in %2$s.', 'monstera' ), '<strong>' . esc_html( $leaderSgName ) . '</strong>', esc_html( get_the_title( $orgId ) ) );
			} else {
				/* translators: %s: organization name */
				printf( esc_html__( 'Everything you create here is for %s. You can narrow individual items to a sub-group.', 'monstera' ), '<strong>' . esc_html( get_the_title( $orgId ) ) . '</strong>' );
			}
			?>
		</p>
	</header>

	<nav class="m-subnav" aria-label="<?php esc_attr_e( 'Manage sections', 'monstera' ); ?>">
		<?php foreach ( $sections as $key => $label ) : ?>
			<a class="m-chip" href="<?php echo esc_url( $mUrl( [ 'section' => $key ] ) ); ?>"<?php echo $section === $key ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</nav>

	<div class="m-manage__panel">
	<?php
	switch ( $section ) :
		case 'content':
			require __DIR__ . '/manage/content.php';
			break;
		case 'subgroups':
			require __DIR__ . '/manage/subgroups.php';
			break;
		case 'forms':
			require __DIR__ . '/manage/forms.php';
			break;
		case 'projects':
			require __DIR__ . '/manage/projects.php';
			break;
		case 'alerts':
			require __DIR__ . '/manage/alerts.php';
			break;
	endswitch;
	?>
	</div>
</section>
