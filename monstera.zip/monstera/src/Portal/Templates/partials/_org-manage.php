<?php
/**
 * Org-hub "Manage" tab — delegated authoring surface (comps 50–55).
 *
 * Included from org.php in the current scope, so it inherits $orgId, $slug,
 * $user, $orgMembers, $orgSubgroups, and $authorScope. Lets an org manager (or a
 * sub-group leader, auto-scoped to their group) create and maintain content,
 * forms, projects, alerts — and, for managers only, sub-groups. Every write is
 * re-authorized server-side via AuthorScope; this template only renders the
 * affordances and forces the visible audience hint to match. The tab is this
 * hub's: a new item names the hub's organization (a hidden org_id, which the
 * create routes check the author's tier in) and its lists show the items
 * written for this hub, so someone who authors in several organizations
 * works in one at a time.
 *
 * The section switcher is a row of chip links with aria-current; each section
 * renders its compose form (.m-form) above the author's items as a
 * priority-column table. Field-based entities post through the shared
 * `manage*` Interactivity actions; Content opens the block-editor island.
 *
 * A submit the store does not take (scripting off, or the page's script not
 * there yet) is the browser's own, so each compose form posts to the page it
 * is on, as the invite form does: with no method the fields would go in the
 * address (a title and a message in the address bar, the history and the
 * server's log). A post is read here as any visit is and nothing is done
 * with what it carried; whoever arrives by one is told that nothing was
 * saved, and where there is no scripting at all the panel says what it
 * needs before anything is typed.
 *
 * @var int                          $orgId
 * @var string                       $slug
 * @var \WP_User                     $user
 * @var \WP_User[]                   $orgMembers
 * @var \WP_Post[]                   $orgSubgroups
 * @var \Monstera\Portal\AuthorScope $authorScope
 */

declare(strict_types=1);

use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Portal\Audience;
use Monstera\Portal\AuthorScope;
use Monstera\Portal\SubgroupNames;

defined( 'ABSPATH' ) || exit;

if ( ! $authorScope->isAuthor() ) {
	return;
}

$isLeaderActor = $authorScope->isLeader();
// The sub-groups a leader leads here: one for most, several for some
// (People-model track, FR2). Named together in the head, and offered as a
// choice on the forms when there are two or more.
$leaderGroups = $isLeaderActor
	? array_values( array_filter( $orgSubgroups, static fn ( \WP_Post $sg ): bool => in_array( (int) $sg->ID, $authorScope->leaderSubgroupIds, true ) ) )
	: [];
$leaderSgName = $isLeaderActor ? wp_sprintf( '%l', array_map( 'get_the_title', $authorScope->leaderSubgroupIds ) ) : '';

// Available sections: content always; sub-groups for managers only; the rest
// follow module activation — mirroring how the read-only tabs are gated.
$sections = [ 'content' => ContentPostType::label() ];
if ( in_array( AuthorScope::ENTITY_SUBGROUP, $authorScope->manageableEntities(), true ) ) {
	$sections['subgroups'] = __( 'Sub-groups', 'monstera' );
}
if ( Modules::isActive( Modules::RESOURCES ) ) {
	$sections['resources'] = __( 'Resources', 'monstera' );
}
if ( Modules::isActive( Modules::FORMS ) && in_array( AuthorScope::ENTITY_FORM, $authorScope->manageableEntities(), true ) ) {
	$sections['forms'] = __( 'Forms', 'monstera' );
}
if ( Modules::isActive( Modules::PROJECTS ) ) {
	$sections['projects'] = __( 'Projects', 'monstera' );
}
if ( Modules::isActive( Modules::ALERTS ) ) {
	$sections['alerts'] = __( 'Alerts', 'monstera' );
}

$section = isset( $_GET['section'] ) ? sanitize_key( (string) $_GET['section'] ) : 'content'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
if ( ! isset( $sections[ $section ] ) ) {
	$section = 'content';
}
$editId  = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
$compose = ! empty( $_GET['compose'] ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
// Forms › Submissions: one form's, under the forms section (comp 133).
$subsId = isset( $_GET['submissions'] ) ? absint( $_GET['submissions'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.

$mUrl = static function ( array $args ) use ( $slug ): string {
	return add_query_arg( array_merge( [ 'tab' => 'manage' ], $args ), Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] ) );
};

// What the author wrote for this hub's organization, the hundred last touched.
// Their items for another organization they author in are on that hub's
// Manage tab, so the hundred are counted after those are left out: counted
// before, a hundred newer items for another hub would hide this one's. Staff
// are scoped to no organization and see what they wrote for any, as before.
/** @var callable(string):\WP_Post[] $authored */
$authored = static function ( string $postType ) use ( $user, $orgId, $authorScope ): array {
	$posts = get_posts(
		[
			'post_type'      => $postType,
			'author'         => $user->ID,
			'post_status'    => [ 'publish', 'draft', 'pending' ],
			'posts_per_page' => $authorScope->isAdmin ? 100 : -1,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		]
	);
	if ( $authorScope->isAdmin ) {
		return $posts;
	}
	return array_slice(
		array_values(
			array_filter(
				$posts,
				static fn ( \WP_Post $post ): bool => in_array( $orgId, AuthorScope::orgIdsOfItem( (int) $post->ID ), true )
			)
		),
		0,
		100
	);
};

// The hub's organization, for a form that creates: a create says which
// organization it is for, and the route checks the author's tier there. An
// edit names none, since a save acts on the item's own organization.
$orgField = static function () use ( $orgId ): void {
	printf( '<input type="hidden" name="org_id" value="%d" />', (int) $orgId );
};

// Optional "limit to sub-groups" picker. Managers may narrow to any of the
// organization's sub-groups. A leader of one has the audience fixed to that
// sub-group, so they never see it; a leader of several chooses among the
// groups they lead, and none ticked reaches all of them, never the whole
// organization (the server clamps a save the same way).
$pickable = $isLeaderActor ? ( count( $leaderGroups ) > 1 ? $leaderGroups : [] ) : $orgSubgroups;

// An item whose audience is not the author's to change keeps who it reaches
// through their saves (AuthorScope::frozenBy()): the team shared it beyond
// their part, or every sub-group it is limited to was deleted or put in the
// trash. In place of the picker the form says who chooses it; the editor
// reads the same words.
/* translators: %s: the site's name, e.g. "Monstera" in "the Monstera team" */
$sharedNote = sprintf( __( 'The %s team shared this beyond your organization, so they choose who sees it.', 'monstera' ), Audience::siteName() );
$frozenNote = static function ( int $itemId ) use ( $authorScope, $sharedNote ): string {
	$why = $authorScope->frozenBy( $itemId );
	if ( 'deleted' === $why ) {
		return sprintf(
			/* translators: %s: the site's name, e.g. "Monstera" in "the Monstera team" */
			_n(
				'The sub-group this was limited to was deleted or put in the trash, so only the %s team can see it until they choose its sub-groups again.',
				'The sub-groups this was limited to were deleted or put in the trash, so only the %s team can see it until they choose its sub-groups again.',
				count( $authorScope::subgroupIdsOfItem( $itemId ) ),
				'monstera'
			),
			Audience::siteName()
		);
	}
	return 'shared' === $why ? $sharedNote : '';
};

$scopePicker = static function ( array $selected = [], string $note = '' ) use ( $pickable, $isLeaderActor ): void {
	if ( '' !== $note ) {
		// Where the picker was, under the picker's own label, so the sentence
		// is not a bare line under another field's hint (the design-review
		// capture's verdict, Review-leftovers track FR11, 2026-10-22).
		printf(
			'<fieldset class="m-choices" data-note><legend>%s</legend><p class="m-field__hint" data-shared-further>%s</p></fieldset>',
			esc_html__( 'Sub-groups', 'monstera' ),
			esc_html( $note )
		);
		return;
	}
	if ( ! $pickable ) {
		return;
	}
	?>
	<fieldset class="m-choices">
		<legend><?php esc_html_e( 'Limit to sub-groups (optional)', 'monstera' ); ?></legend>
		<?php foreach ( $pickable as $sg ) : ?>
			<label>
				<input type="checkbox" name="subgroup_ids[]" value="<?php echo (int) $sg->ID; ?>" <?php checked( in_array( (int) $sg->ID, $selected, true ) ); ?> />
				<?php echo esc_html( get_the_title( $sg ) ); ?>
			</label>
		<?php endforeach; ?>
		<span class="m-field__hint">
			<?php
			if ( $isLeaderActor ) {
				esc_html_e( 'Leave all unticked to reach every sub-group you lead.', 'monstera' );
			} else {
				esc_html_e( 'Leave all unticked to reach the whole organization.', 'monstera' );
			}
			?>
		</span>
	</fieldset>
	<?php
};

// "Reaches": the sub-groups an item is limited to, or the whole organization.
// Only the sub-groups the author may see named (Portal\SubgroupNames): staff
// may have shared the item with another client's too, which is not named.
$reaches = static function ( array $subgroupIds ) use ( $user ): string {
	$titles = array_filter( array_map( static fn ( $id ) => get_the_title( (int) $id ), SubgroupNames::shown( $user, $subgroupIds ) ) );
	if ( $titles ) {
		return implode( ', ', $titles );
	}
	return $subgroupIds ? __( 'Sub-groups', 'monstera' ) : __( 'Whole organization', 'monstera' );
};

// Publication status as a badge.
$statusBadge = static function ( string $status ): void {
	$labels = [
		'publish' => __( 'Published', 'monstera' ),
		'draft'   => __( 'Draft', 'monstera' ),
		'pending' => __( 'Pending', 'monstera' ),
	];
	$tones  = [
		'publish' => 'success',
		'draft'   => 'neutral',
		'pending' => 'warning',
	];
	printf(
		'<span class="m-badge" data-tone="%s">%s</span>',
		esc_attr( $tones[ $status ] ?? 'neutral' ),
		esc_html( $labels[ $status ] ?? ucfirst( $status ) )
	);
};

// Edit / Delete for a table row, after any links the row adds first (a
// form's Submissions, comp 132), each a ghost button: url => label.
$rowActions = static function ( \WP_Post $p, string $endpoint, string $section, array $before = [] ) use ( $mUrl ): void {
	$editUrl = $mUrl(
		[
			'section' => $section,
			'edit'    => $p->ID,
		]
	);
	?>
	<span class="m-table__actions">
		<?php foreach ( $before as $url => $label ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( (string) $url ); ?>"><?php echo esc_html( (string) $label ); ?></a>
		<?php endforeach; ?>
		<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $editUrl ); ?>"><?php esc_html_e( 'Edit', 'monstera' ); ?></a>
		<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-endpoint="<?php echo esc_attr( $endpoint ); ?>" data-id="<?php echo (int) $p->ID; ?>" data-wp-on--click="actions.manageDelete"><?php esc_html_e( 'Delete', 'monstera' ); ?></button>
	</span>
	<?php
};
?>

<section class="m-manage" aria-labelledby="m-manage-title">
	<header class="m-manage__head">
		<h2 id="m-manage-title"><?php esc_html_e( 'Manage', 'monstera' ); ?></h2>
		<p>
			<?php
			if ( $isLeaderActor ) {
				/* translators: 1: sub-group name, 2: organization name */
				printf( esc_html__( 'Everything you create here is scoped to %1$s, in %2$s.', 'monstera' ), '<strong>' . esc_html( $leaderSgName ) . '</strong>', esc_html( get_the_title( $orgId ) ) );
			} else {
				/* translators: %s: organization name */
				printf( esc_html__( 'Everything you create here is for %s. You can narrow individual items to a sub-group.', 'monstera' ), '<strong>' . esc_html( get_the_title( $orgId ) ) . '</strong>' );
			}
			?>
		</p>
	</header>

	<nav class="m-subnav" aria-label="<?php esc_attr_e( 'Manage sections', 'monstera' ); ?>">
		<?php foreach ( $sections as $key => $label ) : ?>
			<a class="m-chip" href="<?php echo esc_url( $mUrl( [ 'section' => $key ] ) ); ?>"<?php echo $section === $key ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</nav>

	<div class="m-manage__panel">
	<?php
	$manageNeedsScript = __( 'Saving here needs JavaScript.', 'monstera' );
	if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] ) :
		?>
		<p class="m-manage__refusal" tabindex="-1"><?php echo esc_html( __( 'Nothing was saved.', 'monstera' ) . ' ' . $manageNeedsScript ); ?></p>
	<?php else : ?>
		<noscript><p class="m-manage__refusal"><?php echo esc_html( $manageNeedsScript ); ?></p></noscript>
	<?php endif; ?>
	<?php
	switch ( $section ) :
		case 'content':
			require __DIR__ . '/manage/content.php';
			break;
		case 'subgroups':
			require __DIR__ . '/manage/subgroups.php';
			break;
		case 'resources':
			require __DIR__ . '/manage/resources.php';
			break;
		case 'forms':
			require __DIR__ . ( $subsId > 0 ? '/manage/submissions.php' : '/manage/forms.php' );
			break;
		case 'projects':
			require __DIR__ . '/manage/projects.php';
			break;
		case 'alerts':
			require __DIR__ . '/manage/alerts.php';
			break;
	endswitch;
	?>
	</div>
</section>
