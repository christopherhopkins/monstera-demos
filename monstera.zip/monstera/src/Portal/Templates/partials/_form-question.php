<?php
/**
 * One question of a built form (comp 131): the portal's field for its type,
 * text, textarea, number, select or date, with its required mark and its
 * help line, or for a file question the picker in the mode that holds what
 * is chosen until the form is sent (`data-hold`, as a support message's).
 * The picker's input is named for the question (`key[]`), so without a
 * script the browser posts the chosen files with the rest; with one the
 * store empties the input as it holds each file, and sends the held ones.
 * A complaint from a send that did not go sits under the field, which is
 * marked invalid and described by it first; what was typed is kept.
 *
 * Included in the caller's scope, one question per include.
 *
 * @var array{key: string, label: string, type: string, required: bool, options: list<string>, help: string} $question
 * @var string $questionValue What the reader typed or chose, kept from a send that did not go, or ''.
 * @var string $questionError The complaint about this answer, or ''.
 */

declare(strict_types=1);

use Monstera\Content\SecureFiles;
use Monstera\Projects\IntakeFiles;

defined( 'ABSPATH' ) || exit;

$qKey      = (string) $question['key'];
$qId       = 'fq-' . sanitize_html_class( $qKey );
$qRequired = ! empty( $question['required'] );
$qHelp     = trim( (string) $question['help'] );
$qType     = (string) $question['type'];

// What the control is described by: the complaint first when there is
// one, then the help, then (a file question) the limits.
$qDescribed = [];
if ( '' !== $questionError ) {
	$qDescribed[] = $qId . '-error';
}
if ( '' !== $qHelp ) {
	$qDescribed[] = $qId . '-hint';
}
if ( 'file' === $qType ) {
	$qDescribed[] = $qId . '-limits';
}
$qAttrs = ( $qRequired && 'file' !== $qType ? ' required' : '' )
	. ( '' !== $questionError ? ' aria-invalid="true"' : '' )
	. ( $qDescribed ? ' aria-describedby="' . esc_attr( implode( ' ', $qDescribed ) ) . '"' : '' );

$qMark = $qRequired
	? '<span class="m-req" aria-hidden="true">*</span><span class="m-sr-only">' . esc_html__( 'required', 'monstera' ) . '</span>'
	: '';
?>
<?php if ( 'file' === $qType ) : ?>
<div class="m-field m-fileq" data-hold data-fileq="<?php echo esc_attr( $qKey ); ?>" data-question="<?php echo esc_attr( $qKey ); ?>" data-label="<?php echo esc_attr( $question['label'] ); ?>"<?php echo $qRequired ? ' data-required' : ''; ?><?php echo '' !== $questionError ? ' data-error' : ''; ?>>
	<span class="m-field__label" id="<?php echo esc_attr( $qId ); ?>-label"><?php echo esc_html( $question['label'] ) . $qMark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the mark is built above from escaped parts. ?></span>
	<div class="m-filepick" data-drop data-wp-on--dragenter="actions.filesDragOver" data-wp-on--dragover="actions.filesDragOver" data-wp-on--dragleave="actions.filesDragLeave" data-wp-on--drop="actions.filesDrop">
		<span><?php esc_html_e( 'Drop files here or', 'monstera' ); ?></span>
		<span class="m-btn m-filepick__choose" data-intent="ghost" data-size="sm">
			<span id="<?php echo esc_attr( $qId ); ?>-choose"><?php esc_html_e( 'Choose files', 'monstera' ); ?></span>
			<input type="file" multiple class="m-filepick__input" id="<?php echo esc_attr( $qId ); ?>" name="<?php echo esc_attr( $qKey ); ?>[]" accept="<?php echo esc_attr( SecureFiles::accept() ); ?>" aria-labelledby="<?php echo esc_attr( $qId ); ?>-choose <?php echo esc_attr( $qId ); ?>-label"<?php echo $qAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?> data-wp-on--change="actions.filesChoose" />
		</span>
		<span class="m-filepick__limits" id="<?php echo esc_attr( $qId ); ?>-limits"><?php echo esc_html( IntakeFiles::limitsLine() ); ?></span>
	</div>
	<ul class="m-files" aria-labelledby="<?php echo esc_attr( $qId ); ?>-label" data-wp-on--click="actions.filesListClick" hidden></ul>
	<?php if ( '' !== $qHelp ) : ?>
		<span class="m-field__hint" id="<?php echo esc_attr( $qId ); ?>-hint"><?php echo esc_html( $qHelp ); ?></span>
	<?php endif; ?>
	<span class="m-field__error" id="<?php echo esc_attr( $qId ); ?>-error"<?php echo '' === $questionError ? ' hidden' : ''; ?>><?php echo esc_html( $questionError ); ?></span>
</div>
<?php else : ?>
<div class="m-field" data-question="<?php echo esc_attr( $qKey ); ?>"<?php echo '' !== $questionError ? ' data-error' : ''; ?>>
	<label class="m-field__label" for="<?php echo esc_attr( $qId ); ?>"><?php echo esc_html( $question['label'] ) . $qMark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the mark is built above from escaped parts. ?></label>
	<?php if ( 'textarea' === $qType ) : ?>
		<textarea class="m-textarea" id="<?php echo esc_attr( $qId ); ?>" name="<?php echo esc_attr( $qKey ); ?>" rows="4"<?php echo $qAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?>><?php echo esc_textarea( $questionValue ); ?></textarea>
	<?php elseif ( 'select' === $qType ) : ?>
		<select class="m-select" id="<?php echo esc_attr( $qId ); ?>" name="<?php echo esc_attr( $qKey ); ?>"<?php echo $qAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?>>
			<option value=""><?php esc_html_e( 'Pick one…', 'monstera' ); ?></option>
			<?php foreach ( $question['options'] as $qOption ) : ?>
				<option value="<?php echo esc_attr( (string) $qOption ); ?>"<?php echo (string) $qOption === $questionValue ? ' selected' : ''; ?>><?php echo esc_html( (string) $qOption ); ?></option>
			<?php endforeach; ?>
		</select>
	<?php elseif ( 'number' === $qType ) : ?>
		<input class="m-input" id="<?php echo esc_attr( $qId ); ?>" name="<?php echo esc_attr( $qKey ); ?>" type="number" inputmode="decimal" step="any" value="<?php echo esc_attr( $questionValue ); ?>"<?php echo $qAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?> />
	<?php elseif ( 'date' === $qType ) : ?>
		<input class="m-input" id="<?php echo esc_attr( $qId ); ?>" name="<?php echo esc_attr( $qKey ); ?>" type="date" value="<?php echo esc_attr( $questionValue ); ?>"<?php echo $qAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?> />
	<?php else : ?>
		<input class="m-input" id="<?php echo esc_attr( $qId ); ?>" name="<?php echo esc_attr( $qKey ); ?>" type="text" value="<?php echo esc_attr( $questionValue ); ?>"<?php echo $qAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above from escaped values. ?> />
	<?php endif; ?>
	<?php if ( '' !== $qHelp ) : ?>
		<span class="m-field__hint" id="<?php echo esc_attr( $qId ); ?>-hint"><?php echo esc_html( $qHelp ); ?></span>
	<?php endif; ?>
	<span class="m-field__error" id="<?php echo esc_attr( $qId ); ?>-error"<?php echo '' === $questionError ? ' hidden' : ''; ?>><?php echo esc_html( $questionError ); ?></span>
</div>
<?php endif; ?>
