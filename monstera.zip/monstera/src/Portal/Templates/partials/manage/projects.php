<?php
/**
 * Manage › Projects (comp 53). The compose / edit form over the author's
 * projects as a priority-column table. Inherits _org-manage.php scope.
 *
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable(string):\WP_Post[]           $authored
 * @var callable                              $rowActions
 * @var callable                              $scopePicker
 * @var callable(int[]):string                $reaches
 * @var \Monstera\Portal\AuthorScope          $authorScope
 */

declare(strict_types=1);

use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectType;

defined( 'ABSPATH' ) || exit;

$items = $authored( ProjectType::SLUG );
$edit  = $editId ? get_post( $editId ) : null;
// The id comes from the URL: another author's project must not prefill the
// form (the route would refuse the save, but the reader would see the item).
if ( $edit && ( ProjectType::SLUG !== $edit->post_type || ! $authorScope->canEdit( $edit->ID ) ) ) {
	$edit = null;
}

$curTitle  = $edit ? get_the_title( $edit ) : '';
$curDesc   = $edit ? (string) $edit->post_content : '';
$curStatus = $edit ? (string) ( get_post_meta( $edit->ID, ProjectMeta::KEY_STATUS, true ) ?: ProjectMeta::STATUS_PROPOSED ) : ProjectMeta::STATUS_PROPOSED;
$curDue    = $edit ? (string) get_post_meta( $edit->ID, ProjectMeta::KEY_DUE_ON, true ) : '';
$curSgs    = $edit ? array_map( 'intval', (array) get_post_meta( $edit->ID, ProjectMeta::KEY_SUBGROUP_IDS, true ) ) : [];
$listUrl   = $mUrl( [ 'section' => 'projects' ] );
$tones     = [
	ProjectMeta::STATUS_COMPLETED => 'success',
	ProjectMeta::STATUS_ARCHIVED  => 'neutral',
	ProjectMeta::STATUS_ON_HOLD   => 'suspended',
	ProjectMeta::STATUS_DISCOVERY => 'info',
	ProjectMeta::STATUS_PROPOSED  => 'pending',
	ProjectMeta::STATUS_REVIEW    => 'warning',
];
?>

<form class="m-form" data-card data-wp-on--submit="actions.manageSave"
	data-endpoint="projects"
	<?php echo $edit ? 'data-id="' . (int) $edit->ID . '"' : ''; ?>
	data-redirect="<?php echo esc_url( $listUrl ); ?>">
	<h3><?php echo $edit ? esc_html__( 'Edit project', 'monstera' ) : esc_html__( 'New project', 'monstera' ); ?></h3>
	<div class="m-field">
		<label class="m-field__label" for="m-pj-title"><?php esc_html_e( 'Title', 'monstera' ); ?></label>
		<input class="m-input" id="m-pj-title" type="text" name="title" required value="<?php echo esc_attr( $curTitle ); ?>" />
	</div>
	<div class="m-field">
		<label class="m-field__label" for="m-pj-desc"><?php esc_html_e( 'Description', 'monstera' ); ?></label>
		<textarea class="m-textarea" id="m-pj-desc" name="description"><?php echo esc_textarea( $curDesc ); ?></textarea>
	</div>
	<div class="m-form__row">
		<div class="m-field">
			<label class="m-field__label" for="m-pj-status"><?php esc_html_e( 'Status', 'monstera' ); ?></label>
			<select class="m-select" id="m-pj-status" name="status">
				<?php foreach ( ProjectMeta::statusOrder() as $statusKey ) : ?>
					<option value="<?php echo esc_attr( $statusKey ); ?>" <?php selected( $curStatus, $statusKey ); ?>><?php echo esc_html( ProjectMeta::statusLabel( $statusKey ) ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="m-field">
			<label class="m-field__label" for="m-pj-due"><?php esc_html_e( 'Due date', 'monstera' ); ?></label>
			<input class="m-input" id="m-pj-due" type="date" name="due_on" value="<?php echo esc_attr( $curDue ); ?>" />
		</div>
	</div>
	<?php $scopePicker( $curSgs ); ?>
	<div class="m-form__actions">
		<button class="m-btn" data-intent="primary" data-size="md" type="submit">
			<?php echo $edit ? esc_html__( 'Save project', 'monstera' ) : esc_html__( 'Create project', 'monstera' ); ?>
		</button>
		<?php if ( $edit ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Cancel', 'monstera' ); ?></a>
			<span class="m-mono">
				<?php
				/* translators: %s: date and time of the last save */
				printf( esc_html__( 'Last saved %s', 'monstera' ), esc_html( wp_date( 'M j, g:ia', (int) get_post_modified_time( 'U', true, $edit ) ) ) );
				?>
			</span>
		<?php endif; ?>
	</div>
</form>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Projects', 'monstera' ); ?></h3>
	<?php if ( $edit ) : ?>
		<a class="m-btn" data-intent="secondary" data-size="sm" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'New project', 'monstera' ); ?></a>
	<?php else : ?>
		<span class="m-mono">
			<?php
			/* translators: %d: number of projects */
			printf( esc_html( _n( '%d project', '%d projects', count( $items ), 'monstera' ) ), (int) count( $items ) );
			?>
		</span>
	<?php endif; ?>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'You haven\'t created any projects yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Projects, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Project', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Status', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Reaches', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Due', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $items as $p ) :
					$pStatus = (string) ( get_post_meta( $p->ID, ProjectMeta::KEY_STATUS, true ) ?: ProjectMeta::STATUS_PROPOSED );
					$dueOn   = (string) get_post_meta( $p->ID, ProjectMeta::KEY_DUE_ON, true );
					$sgIds   = array_map( 'intval', (array) get_post_meta( $p->ID, ProjectMeta::KEY_SUBGROUP_IDS, true ) );
					$editUrl = $mUrl(
						[
							'section' => 'projects',
							'edit'    => $p->ID,
						]
					);
					?>
					<tr data-manage-row>
						<td data-priority="1"><a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a></td>
						<td data-priority="2"><span class="m-badge" data-tone="<?php echo esc_attr( $tones[ $pStatus ] ?? 'active' ); ?>"><?php echo esc_html( ProjectMeta::statusLabel( $pStatus ) ); ?></span></td>
						<td data-priority="3"><?php echo esc_html( $reaches( $sgIds ) ); ?></td>
						<td data-priority="2"><span class="m-mono"><?php echo $dueOn ? esc_html( wp_date( 'M j', strtotime( $dueOn ) ?: null ) ) : '—'; ?></span></td>
						<td data-priority="1"><?php $rowActions( $p, 'projects', 'projects' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
