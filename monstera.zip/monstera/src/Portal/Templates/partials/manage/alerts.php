<?php
/**
 * Manage › Alerts (in-portal notifications; comp 54). The compose / edit form
 * over the author's notifications as a priority-column table. A leader's
 * alert is pinned to their sub-group; a manager may target the org or narrow
 * to sub-groups. "Post notification" publishes, "Save as draft" keeps it
 * private (the submit button names the status). Inherits _org-manage.php
 * scope.
 *
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable(string):\WP_Post[]           $authored
 * @var callable                              $rowActions
 * @var callable                              $scopePicker
 * @var callable(int[]):string                $reaches
 * @var callable(string):void                 $statusBadge
 * @var \Monstera\Portal\AuthorScope          $authorScope
 */

declare(strict_types=1);

use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\PostType as AlertType;

$items = $authored( AlertType::SLUG );
$edit  = $editId ? get_post( $editId ) : null;
// The id comes from the URL: another author's notification must not prefill
// the form (the route would refuse the save, but the reader would see it).
if ( $edit && ( AlertType::SLUG !== $edit->post_type || ! $authorScope->canEdit( $edit->ID ) ) ) {
	$edit = null;
}

$curTitle   = $edit ? get_the_title( $edit ) : '';
$curBody    = $edit ? (string) $edit->post_content : '';
$curSev     = $edit ? (string) ( get_post_meta( $edit->ID, AlertMeta::KEY_SEVERITY, true ) ?: AlertMeta::SEVERITY_INFO ) : AlertMeta::SEVERITY_INFO;
$curLink    = $edit ? (string) get_post_meta( $edit->ID, AlertMeta::KEY_LINK_URL, true ) : '';
$curLabel   = $edit ? (string) get_post_meta( $edit->ID, AlertMeta::KEY_LINK_LABEL, true ) : '';
$curSgs     = $edit ? array_map( 'intval', (array) get_post_meta( $edit->ID, AlertMeta::KEY_SUBGROUP_IDS, true ) ) : [];
$curStatus  = $edit ? (string) $edit->post_status : 'publish';
$listUrl    = $mUrl( [ 'section' => 'alerts' ] );
$severities = [ AlertMeta::SEVERITY_INFO, AlertMeta::SEVERITY_WARNING, AlertMeta::SEVERITY_CRITICAL ];
$sevTones   = [
	AlertMeta::SEVERITY_INFO     => 'info',
	AlertMeta::SEVERITY_WARNING  => 'warning',
	AlertMeta::SEVERITY_CRITICAL => 'danger',
];
$live       = count( array_filter( $items, static fn ( $p ) => 'publish' === $p->post_status ) );
$drafts     = count( $items ) - $live;
?>

<form class="m-form" data-card data-wp-on--submit="actions.manageSave"
	data-endpoint="alerts"
	<?php echo $edit ? 'data-id="' . (int) $edit->ID . '"' : ''; ?>
	data-redirect="<?php echo esc_url( $listUrl ); ?>">
	<h3><?php echo $edit ? esc_html__( 'Edit notification', 'monstera' ) : esc_html__( 'New notification', 'monstera' ); ?></h3>
	<div class="m-field">
		<label class="m-field__label" for="m-al-title"><?php esc_html_e( 'Title', 'monstera' ); ?></label>
		<input class="m-input" id="m-al-title" type="text" name="title" required value="<?php echo esc_attr( $curTitle ); ?>" />
	</div>
	<div class="m-field">
		<label class="m-field__label" for="m-al-body"><?php esc_html_e( 'Message', 'monstera' ); ?></label>
		<textarea class="m-textarea" id="m-al-body" name="body"><?php echo esc_textarea( $curBody ); ?></textarea>
	</div>
	<fieldset class="m-choices" data-inline>
		<legend><?php esc_html_e( 'Severity', 'monstera' ); ?></legend>
		<?php foreach ( $severities as $sev ) : ?>
			<label><input type="radio" name="severity" value="<?php echo esc_attr( $sev ); ?>" <?php checked( $curSev, $sev ); ?> /> <?php echo esc_html( AlertMeta::severityLabel( $sev ) ); ?></label>
		<?php endforeach; ?>
	</fieldset>
	<div class="m-form__row">
		<div class="m-field">
			<label class="m-field__label" for="m-al-url"><?php esc_html_e( 'Link URL (optional)', 'monstera' ); ?></label>
			<input class="m-input" id="m-al-url" type="url" name="link_url" value="<?php echo esc_attr( $curLink ); ?>" placeholder="https://" />
		</div>
		<div class="m-field">
			<label class="m-field__label" for="m-al-label"><?php esc_html_e( 'Link label (optional)', 'monstera' ); ?></label>
			<input class="m-input" id="m-al-label" type="text" name="link_label" value="<?php echo esc_attr( $curLabel ); ?>" />
		</div>
	</div>
	<?php $scopePicker( $curSgs ); ?>
	<input type="hidden" name="status" value="<?php echo esc_attr( 'draft' === $curStatus ? 'draft' : 'publish' ); ?>" />
	<div class="m-form__actions">
		<button class="m-btn" data-intent="primary" data-size="md" type="submit" data-status="publish">
			<?php echo $edit && 'publish' === $curStatus ? esc_html__( 'Save notification', 'monstera' ) : esc_html__( 'Post notification', 'monstera' ); ?>
		</button>
		<button class="m-btn" data-intent="secondary" data-size="md" type="submit" data-status="draft"><?php esc_html_e( 'Save as draft', 'monstera' ); ?></button>
		<?php if ( $edit ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Cancel', 'monstera' ); ?></a>
		<?php endif; ?>
	</div>
</form>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Notifications', 'monstera' ); ?></h3>
	<span class="m-mono">
		<?php
		printf(
			/* translators: 1: how many notifications are live, 2: how many are drafts */
			esc_html__( '%1$s · %2$s', 'monstera' ),
			/* translators: %d: number of live notifications */
			esc_html( sprintf( _n( '%d live', '%d live', $live, 'monstera' ), $live ) ),
			/* translators: %d: number of draft notifications */
			esc_html( sprintf( _n( '%d draft', '%d drafts', $drafts, 'monstera' ), $drafts ) )
		);
		?>
	</span>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'You haven\'t posted any notifications yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Notifications, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Notification', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Severity', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Reaches', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Status', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $items as $p ) :
					$sev     = (string) ( get_post_meta( $p->ID, AlertMeta::KEY_SEVERITY, true ) ?: AlertMeta::SEVERITY_INFO );
					$sgIds   = array_map( 'intval', (array) get_post_meta( $p->ID, AlertMeta::KEY_SUBGROUP_IDS, true ) );
					$editUrl = $mUrl(
						[
							'section' => 'alerts',
							'edit'    => $p->ID,
						]
					);
					if ( 'publish' === $p->post_status ) {
						/* translators: %s: the date the notification was posted */
						$when = sprintf( __( 'Posted %s', 'monstera' ), wp_date( 'M j', (int) get_post_time( 'U', true, $p ) ) );
					} else {
						/* translators: %s: the date the draft was last edited */
						$when = sprintf( __( 'Edited %s', 'monstera' ), wp_date( 'M j', (int) get_post_modified_time( 'U', true, $p ) ) );
					}
					?>
					<tr data-manage-row>
						<td data-priority="1">
							<a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a>
							<span class="m-table__sub"><?php echo esc_html( $when ); ?></span>
						</td>
						<td data-priority="2"><span class="m-badge" data-tone="<?php echo esc_attr( $sevTones[ $sev ] ?? 'info' ); ?>"><?php echo esc_html( AlertMeta::severityLabel( $sev ) ); ?></span></td>
						<td data-priority="3"><?php echo esc_html( $reaches( $sgIds ) ); ?></td>
						<td data-priority="2"><?php $statusBadge( (string) $p->post_status ); ?></td>
						<td data-priority="1"><?php $rowActions( $p, 'alerts', 'alerts' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
