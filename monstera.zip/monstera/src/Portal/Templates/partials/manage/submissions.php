<?php
/**
 * Manage › Forms › Submissions (comp 133; Forms-and-resources track, FR6).
 * What the organization's members sent to one form, newest first, for its
 * admins and managers. For a form the organization built, each one in
 * full: the row opens its answers in question order, file links signed
 * for the reader (Content\Downloader's rule), and the list exports as CSV
 * through the forms route. For a form the team built that reaches the
 * organization, who has sent one and when and never an answer: those are
 * between the member and the site. A form that does not reach the
 * organization is not one of its own to read. Inherits _org-manage.php
 * scope.
 *
 * @var int                                   $subsId
 * @var callable(array<string, mixed>):string $mUrl
 * @var \Monstera\Portal\AuthorScope          $authorScope
 * @var \WP_User                              $user
 * @var int                                   $orgId
 */

declare(strict_types=1);

use Monstera\Forms\Answers;
use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\PostType as FormType;
use Monstera\Forms\Submissions;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Roster;
use Monstera\Members\UserMeta;
use Monstera\Portal\CalendarDay;

defined( 'ABSPATH' ) || exit;

$orgName  = (string) get_the_title( $orgId );
$listUrl  = $mUrl( [ 'section' => 'forms' ] );
$subsForm = get_post( $subsId );
// A built form that reaches this organization; its submissions are for the
// organization's admins and managers (staff read every hub's).
$reaches = $subsForm
	&& FormType::SLUG === $subsForm->post_type
	&& FormMeta::KIND_BUILT === FormMeta::kindOf( (int) $subsForm->ID )
	&& in_array( $orgId, Reach::formOrgs( (int) $subsForm->ID ), true );
$mayList = $authorScope->isAdmin || in_array( Roster::roleOf( (int) $user->ID, $orgId ), [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true );
?>

<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
	<a href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Forms', 'monstera' ); ?></a>
	<span aria-hidden="true">/</span>
	<span aria-current="page"><?php echo $reaches ? esc_html( get_the_title( $subsForm ) ) : esc_html__( 'Submissions', 'monstera' ); ?></span>
</nav>

<?php
if ( ! $reaches || ! $mayList ) :
	?>
	<div class="m-manage__bar">
		<h3><?php esc_html_e( 'Submissions', 'monstera' ); ?></h3>
	</div>
	<p class="m-manage__empty">
		<?php
		if ( ! $reaches ) {
			/* translators: %s: the organization's name */
			echo esc_html( sprintf( __( 'That form does not belong to %s.', 'monstera' ), $orgName ) );
		} else {
			/* translators: %s: the organization's name */
			echo esc_html( sprintf( __( 'Submissions are for the admins and managers of %s.', 'monstera' ), $orgName ) );
		}
		?>
	</p>
	<?php
	return;
endif;

$formId = (int) $subsForm->ID;
// The organization's own form, or the team's, as it was built: whose it is
// decides whose the answers are (Content\Downloader::mayReadSubmission() has the rule).
$full     = FormMeta::openToLeads( $formId );
$subsRows = Submissions::forFormAndOrg( $formId, $orgId );
$total    = count( $subsRows );
$dueOn    = FormMeta::dueOn( $formId );
$fields   = $full ? FormMeta::fieldsOf( $formId ) : [];
// How many rows the page shows: the first ten, or as many as asked for.
$pageSize = 10;
$show     = isset( $_GET['show'] ) ? absint( $_GET['show'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only paging parameter; nothing is written.
$show     = $show > 0 ? min( $show, $total ) : min( $pageSize, $total );
$shown    = array_slice( $subsRows, 0, $show );
$removed  = $full ? Submissions::removedKeys( $formId, $shown ) : [];
// Each shown send's files, read together once for the rows and their
// answers; the senders and their standing here, once for the rows.
$filesByRow = $full ? Submissions::filesOfMany( array_map( static fn ( array $subsRow ): int => (int) $subsRow['id'], $shown ) ) : [];
$senderIds  = array_values( array_unique( array_map( static fn ( array $subsRow ): int => (int) $subsRow['user_id'], $shown ) ) );
cache_users( $senderIds );
Roster::prime( $senderIds );
$tierLabels = [
	Roster::TIER_MEMBER  => __( 'Member', 'monstera' ),
	Roster::TIER_MANAGER => __( 'Manager', 'monstera' ),
	Roster::TIER_ADMIN   => __( 'Organization admin', 'monstera' ),
];
$senders    = count( array_unique( array_map( static fn ( array $subsRow ): int => (int) $subsRow['user_id'], $subsRows ) ) );
$members    = count( Roster::memberIds( $orgId ) );
$siteName   = (string) get_bloginfo( 'name' );
$recipients = $full ? FormMeta::recipientsOf( $formId ) : [
	'emails'    => [],
	'org_leads' => false,
];
$emailed    = $recipients['emails'];
if ( $recipients['org_leads'] ) {
	$emailed[] = __( 'the organization\'s admins and managers', 'monstera' );
}
$exportUrl = $full ? wp_nonce_url( add_query_arg( 'org', $orgId, rest_url( 'monstera/v1/forms/' . $formId . '/submissions/export' ) ), 'wp_rest' ) : '';
?>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Submissions', 'monstera' ); ?></h3>
	<span class="m-mono">
		<?php
		if ( $full ) {
			/* translators: %d: how many submissions were sent (the count stands with "sent" at any number) */
			$count = sprintf( _n( '%d sent', '%d sent', $total, 'monstera' ), $total );
			if ( '' !== $dueOn ) {
				/* translators: 1: "N sent", 2: the form's due day */
				$count = sprintf( __( '%1$s · due %2$s', 'monstera' ), $count, CalendarDay::format( $dueOn, 'M j' ) );
			}
			echo esc_html( $count );
		} else {
			/* translators: 1: how many members have sent the form, 2: how many members the organization has */
			echo esc_html( sprintf( __( '%1$d of %2$d members have sent one', 'monstera' ), $senders, $members ) );
		}
		?>
	</span>
</div>

<?php if ( $full ) : ?>
	<p class="m-form__help">
		<?php
		esc_html_e( 'Everything members sent to this form, newest first.', 'monstera' );
		echo ' ';
		if ( $emailed ) {
			/* translators: %s: who each submission was emailed to, as a list */
			echo esc_html( sprintf( __( 'Each one was emailed to %s when it arrived.', 'monstera' ), wp_sprintf_l( '%l', $emailed ) ) );
		} else {
			esc_html_e( 'Each one is kept here.', 'monstera' );
		}
		if ( $total > 0 ) {
			echo ' <a href="' . esc_url( $exportUrl ) . '">' . esc_html__( 'Export as CSV', 'monstera' ) . '</a>.';
		}
		?>
	</p>
<?php else : ?>
	<p class="m-band" data-lead>
		<span>
			<strong>
				<?php
				/* translators: %s: the site's name */
				echo esc_html( sprintf( __( 'This form belongs to %s.', 'monstera' ), $siteName ) );
				?>
			</strong>
			<?php
			/* translators: %s: the site's name */
			echo esc_html( sprintf( __( 'Its answers are between each member and %s, so you see who has sent one and when, not what they said.', 'monstera' ), $siteName ) );
			?>
		</span>
	</p>
<?php endif; ?>

<?php if ( ! $subsRows ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'Nobody has sent this form yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Submissions, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Sent', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Member', 'monstera' ); ?></th>
					<?php if ( $full ) : ?>
						<th scope="col" data-priority="2"><?php esc_html_e( 'Summary', 'monstera' ); ?></th>
						<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
					<?php endif; ?>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $shown as $subsRow ) :
					$rowId      = (int) $subsRow['id'];
					$sender     = get_userdata( (int) $subsRow['user_id'] );
					$senderName = $sender ? UserMeta::fullName( $sender ) : __( 'A former member', 'monstera' );
					$senderTier = $sender ? Roster::roleOf( (int) $sender->ID, $orgId ) : null;
					$when       = (int) strtotime( $subsRow['submitted_at'] . ' UTC' );
					// Every row's button says View: each is described by its
					// own row's member and day, so a list of them is told
					// apart. Not under ms-{id}, whose ids the answers' file
					// lists take by question key.
					$rowRef = 'ms-row-' . $rowId;
					?>
					<tr data-submission-row>
						<td data-priority="1"><span class="m-mono"><time id="<?php echo esc_attr( $rowRef ); ?>-sent" datetime="<?php echo esc_attr( wp_date( 'c', $when ) ); ?>"><?php echo esc_html( wp_date( 'M j', $when ) ); ?></time></span></td>
						<td data-priority="1">
							<span class="m-table__primary" id="<?php echo esc_attr( $rowRef ); ?>-member"><?php echo esc_html( $senderName ); ?></span>
							<span class="m-table__sub"><?php echo esc_html( $tierLabels[ $senderTier ] ?? __( 'No longer a member', 'monstera' ) ); ?></span>
						</td>
						<?php if ( $full ) : ?>
							<td data-priority="2"><?php echo esc_html( Answers::summary( $fields, $subsRow, $filesByRow[ $rowId ] ?? [] ) ); ?></td>
							<td data-priority="1">
								<button class="m-btn" data-intent="ghost" data-size="sm" type="button" aria-expanded="false" aria-controls="ms-<?php echo (int) $rowId; ?>" aria-describedby="<?php echo esc_attr( $rowRef . '-member ' . $rowRef . '-sent' ); ?>" data-wp-on--click="actions.toggleAnswers" data-msg-show="<?php esc_attr_e( 'View', 'monstera' ); ?>" data-msg-hide="<?php esc_attr_e( 'Hide', 'monstera' ); ?>"><?php esc_html_e( 'View', 'monstera' ); ?></button>
							</td>
						<?php endif; ?>
					</tr>
					<?php if ( $full ) : ?>
						<tr class="m-table__open" id="ms-<?php echo (int) $rowId; ?>" hidden>
							<td colspan="4">
								<div class="m-answers" tabindex="-1">
									<?php
									$answersOf = [
										'row'         => $subsRow,
										'fields'      => $fields,
										'removedKeys' => $removed,
										'files'       => $filesByRow[ $rowId ] ?? [],
										'user'        => $user,
										'idPrefix'    => 'ms-' . $rowId,
									];
									( static function ( array $vars ): void {
										extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- the partial's named variables, scoped to this closure.
										require __DIR__ . '/../_submission-answers.php';
									} )( $answersOf );
									?>
								</div>
							</td>
						</tr>
					<?php endif; ?>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<div class="m-table__foot">
		<span class="m-mono">
			<?php
			/* translators: 1: how many rows are shown, 2: how many there are */
			echo esc_html( sprintf( __( 'Showing %1$d of %2$d', 'monstera' ), count( $shown ), $total ) );
			?>
		</span>
		<?php
		if ( $total > count( $shown ) ) :
			$moreUrl = add_query_arg(
				'show',
				$total,
				$mUrl(
					[
						'section'     => 'forms',
						'submissions' => $formId,
					]
				)
			);
			?>
			<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $moreUrl ); ?>">
				<?php
				/* translators: %d: how many more submissions it shows */
				echo esc_html( sprintf( _n( 'Show %d more', 'Show %d more', $total - count( $shown ), 'monstera' ), $total - count( $shown ) ) );
				?>
			</a>
		<?php endif; ?>
	</div>
<?php endif; ?>
