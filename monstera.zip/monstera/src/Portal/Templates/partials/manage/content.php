<?php
/**
 * Manage › Content (comp 50). The author's own items as a priority-column
 * table under the "Your content" bar, and the block-editor island for
 * compose / edit. Inherits scope from _org-manage.php.
 *
 * @var bool                                  $compose
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable(string):\WP_Post[]           $authored
 * @var callable(int[]):string                $reaches
 * @var callable(string):void                 $statusBadge
 */

declare(strict_types=1);

use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentType;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

if ( $compose || $editId ) :
	?>
	<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $mUrl( [ 'section' => 'content' ] ) ); ?>">
		&larr; <?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_html( sprintf( __( 'Back to %s', 'monstera' ), ContentType::noun() ) ); ?>
	</a>
	<?php
	// data-wp-ignore keeps the Interactivity runtime out of the island: the
	// shell is one interactive region, and WordPress 6.5's runtime hydrates
	// the whole subtree, so the block editor React mounts later would insert
	// into nodes the runtime had already replaced (an empty canvas on 6.5).
	?>
	<div id="monstera-portal-editor"
		data-wp-ignore
		data-content-id="<?php echo (int) $editId; ?>"
		data-back="<?php echo esc_url( $mUrl( [ 'section' => 'content' ] ) ); ?>"
		style="margin-top:var(--m-space-4)">
		<p style="color:var(--m-text-muted);font-size:var(--m-size-xs)"><?php esc_html_e( 'Loading editor…', 'monstera' ); ?></p>
	</div>
	<?php
	return;
endif;

$items        = $authored( ContentType::SLUG );
$subgroupRepo = new SubgroupRepository();
$composeUrl   = $mUrl(
	[
		'section' => 'content',
		'compose' => 1,
	]
);
?>

<div class="m-manage__bar">
	<h3><?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_html( sprintf( __( 'Your %s', 'monstera' ), ContentType::noun() ) ); ?></h3>
	<a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( $composeUrl ); ?>"><?php /* translators: %s: one item of what this site calls content, e.g. "content" or "deliverable" */ echo esc_html( sprintf( __( 'New %s', 'monstera' ), ContentType::nounSingular() ) ); ?></a>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_html( sprintf( __( 'You haven\'t created any %s yet.', 'monstera' ), ContentType::noun() ) ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php /* translators: %s: what this site calls content, e.g. "content" or "deliverables" */ echo esc_attr( sprintf( __( 'Your %s, scrolls sideways', 'monstera' ), ContentType::noun() ) ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Title', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Status', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Reaches', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Updated', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $items as $p ) :
					$click   = (string) ( get_post_meta( $p->ID, ContentMeta::KEY_CLICK_BEHAVIOR, true ) ?: ContentMeta::CLICK_FILE );
					$isFile  = ContentMeta::CLICK_FILE === $click && (int) get_post_meta( $p->ID, ContentMeta::KEY_SECURE_FILE_ID, true );
					$sgIds   = $subgroupRepo->subgroupsForContent( (int) $p->ID );
					$editUrl = $mUrl(
						[
							'section' => 'content',
							'edit'    => $p->ID,
						]
					);
					?>
					<tr data-manage-row>
						<td data-priority="1">
							<a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a>
							<span class="m-table__sub"><?php echo $isFile ? esc_html__( 'File', 'monstera' ) : esc_html__( 'Article', 'monstera' ); ?></span>
						</td>
						<td data-priority="2"><?php $statusBadge( (string) $p->post_status ); ?></td>
						<td data-priority="3"><?php echo esc_html( $reaches( $sgIds ) ); ?></td>
						<td data-priority="3"><span class="m-mono"><?php echo esc_html( wp_date( 'M j', (int) get_post_modified_time( 'U', true, $p ) ) ); ?></span></td>
						<td data-priority="1">
							<span class="m-table__actions">
								<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $editUrl ); ?>"><?php esc_html_e( 'Edit', 'monstera' ); ?></a>
								<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-endpoint="content-items" data-id="<?php echo (int) $p->ID; ?>" data-wp-on--click="actions.manageDelete"><?php esc_html_e( 'Delete', 'monstera' ); ?></button>
							</span>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
