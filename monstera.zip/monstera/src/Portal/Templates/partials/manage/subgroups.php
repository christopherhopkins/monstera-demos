<?php
/**
 * Manage › Sub-groups (org managers only; comp 51). The compose / edit form
 * over the org's sub-groups as a priority-column table. Inherits
 * _org-manage.php scope.
 *
 * @var int                                   $orgId
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable                              $rowActions
 * @var \WP_User[]                            $orgMembers
 */

declare(strict_types=1);

use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\PostType as SubgroupType;
use Monstera\Subgroups\Repository as SubgroupRepository;

// Sub-groups are org-scoped (not author-owned), so a manager sees every
// sub-group under their org — including ones an admin seeded.
$subgroupRepo = new SubgroupRepository();
$items        = $subgroupRepo->forOrg( $orgId );
$edit         = $editId ? get_post( $editId ) : null;
// The id comes from the URL: a sub-group under another organization must not
// prefill the form (the route would refuse the save, but the reader would see
// its name, leader and members).
if ( $edit && ( SubgroupType::SLUG !== $edit->post_type || (int) get_post_meta( $edit->ID, SubgroupMeta::KEY_ORG_ID, true ) !== $orgId ) ) {
	$edit = null;
}

$curName    = $edit ? get_the_title( $edit ) : '';
$curDesc    = $edit ? (string) $edit->post_content : '';
$curCadence = $edit ? (string) get_post_meta( $edit->ID, SubgroupMeta::KEY_MEETING_CADENCE, true ) : '';
$curLeader  = $edit ? (int) get_post_meta( $edit->ID, SubgroupMeta::KEY_LEADER, true ) : 0;
$curMembers = $edit ? $subgroupRepo->memberIds( $edit->ID ) : [];
$listUrl    = $mUrl( [ 'section' => 'subgroups' ] );
$memberName = static fn ( \WP_User $m ): string => trim( $m->first_name . ' ' . $m->last_name ) ?: $m->display_name;
?>

<form class="m-form" data-card data-wp-on--submit="actions.manageSave"
	data-endpoint="subgroups"
	<?php echo $edit ? 'data-id="' . (int) $edit->ID . '"' : ''; ?>
	data-redirect="<?php echo esc_url( $listUrl ); ?>">
	<h3><?php echo $edit ? esc_html__( 'Edit sub-group', 'monstera' ) : esc_html__( 'New sub-group', 'monstera' ); ?></h3>
	<div class="m-form__row">
		<div class="m-field">
			<label class="m-field__label" for="m-sg-name"><?php esc_html_e( 'Name', 'monstera' ); ?></label>
			<input class="m-input" id="m-sg-name" type="text" name="name" required value="<?php echo esc_attr( $curName ); ?>" />
		</div>
		<div class="m-field">
			<label class="m-field__label" for="m-sg-cadence"><?php esc_html_e( 'Meeting cadence', 'monstera' ); ?></label>
			<input class="m-input" id="m-sg-cadence" type="text" name="meeting_cadence" value="<?php echo esc_attr( $curCadence ); ?>" placeholder="<?php esc_attr_e( 'e.g. Monthly', 'monstera' ); ?>" />
		</div>
	</div>
	<div class="m-field">
		<label class="m-field__label" for="m-sg-desc"><?php esc_html_e( 'Description', 'monstera' ); ?></label>
		<textarea class="m-textarea" id="m-sg-desc" name="description"><?php echo esc_textarea( $curDesc ); ?></textarea>
	</div>
	<div class="m-form__row">
		<div class="m-field">
			<label class="m-field__label" for="m-sg-leader"><?php esc_html_e( 'Leader', 'monstera' ); ?></label>
			<select class="m-select" id="m-sg-leader" name="leader_id">
				<option value="0"><?php esc_html_e( 'None', 'monstera' ); ?></option>
				<?php foreach ( $orgMembers as $member ) : ?>
					<option value="<?php echo (int) $member->ID; ?>" <?php selected( $curLeader, (int) $member->ID ); ?>><?php echo esc_html( $memberName( $member ) ); ?></option>
				<?php endforeach; ?>
			</select>
			<span class="m-field__hint"><?php esc_html_e( 'A leader can create content scoped to this sub-group.', 'monstera' ); ?></span>
		</div>
		<fieldset class="m-choices">
			<legend><?php esc_html_e( 'Members', 'monstera' ); ?></legend>
			<?php foreach ( $orgMembers as $member ) : ?>
				<label>
					<input type="checkbox" name="member_ids[]" value="<?php echo (int) $member->ID; ?>" <?php checked( in_array( (int) $member->ID, $curMembers, true ) ); ?> />
					<span class="m-avatar" aria-hidden="true"><?php \Monstera\Core\Icons::emit( 'sprout', 14 ); ?></span>
					<?php echo esc_html( $memberName( $member ) ); ?>
				</label>
			<?php endforeach; ?>
		</fieldset>
	</div>
	<div class="m-form__actions">
		<button class="m-btn" data-intent="primary" data-size="md" type="submit">
			<?php echo $edit ? esc_html__( 'Save sub-group', 'monstera' ) : esc_html__( 'Create sub-group', 'monstera' ); ?>
		</button>
		<?php if ( $edit ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Cancel', 'monstera' ); ?></a>
		<?php endif; ?>
	</div>
</form>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Sub-groups', 'monstera' ); ?></h3>
	<span class="m-mono">
		<?php
		/* translators: %d: number of sub-groups */
		printf( esc_html( _n( '%d group', '%d groups', count( $items ), 'monstera' ) ), (int) count( $items ) );
		?>
	</span>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'No sub-groups yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Sub-groups, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Sub-group', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Leader', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Members', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Cadence', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $items as $p ) :
					$leaderId = (int) get_post_meta( $p->ID, SubgroupMeta::KEY_LEADER, true );
					$leader   = $leaderId ? get_userdata( $leaderId ) : null;
					$cadence  = (string) get_post_meta( $p->ID, SubgroupMeta::KEY_MEETING_CADENCE, true );
					$editUrl  = $mUrl(
						[
							'section' => 'subgroups',
							'edit'    => $p->ID,
						]
					);
					?>
					<tr data-manage-row>
						<td data-priority="1"><a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a></td>
						<td data-priority="2"><?php echo $leader ? esc_html( $memberName( $leader ) ) : '—'; ?></td>
						<td data-priority="3"><span class="m-mono"><?php echo (int) count( $subgroupRepo->memberIds( (int) $p->ID ) ); ?></span></td>
						<td data-priority="3"><?php echo esc_html( $cadence ?: __( 'As needed', 'monstera' ) ); ?></td>
						<td data-priority="1"><?php $rowActions( $p, 'subgroups', 'subgroups' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
