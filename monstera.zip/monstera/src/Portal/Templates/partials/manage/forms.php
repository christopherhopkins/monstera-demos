<?php
/**
 * Manage › Resources (Forms; comp 52). The compose / edit form over the
 * author's resources as a priority-column table. Portal authors are limited
 * to PDF (Media Library attachment) and external-URL forms — shortcode forms
 * stay admin-only (see FormsController). Inherits _org-manage.php scope.
 *
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable(string):\WP_Post[]           $authored
 * @var callable                              $rowActions
 * @var callable                              $scopePicker
 * @var callable(int[]):string                $reaches
 * @var \Monstera\Portal\AuthorScope          $authorScope
 */

declare(strict_types=1);

use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\PostType as FormType;

$items = $authored( FormType::SLUG );
$edit  = $editId ? get_post( $editId ) : null;
// The id comes from the URL: another author's resource must not prefill the
// form (the route would refuse the save, but the reader would see the item).
if ( $edit && ( FormType::SLUG !== $edit->post_type || ! $authorScope->canEdit( $edit->ID ) ) ) {
	$edit = null;
}

$curTitle = $edit ? get_the_title( $edit ) : '';
$curType  = $edit ? (string) ( get_post_meta( $edit->ID, FormMeta::KEY_FORM_TYPE, true ) ?: FormMeta::TYPE_EXTERNAL ) : FormMeta::TYPE_EXTERNAL;
$curDesc  = $edit ? (string) get_post_meta( $edit->ID, FormMeta::KEY_DESCRIPTION, true ) : '';
$curUrl   = $edit ? (string) get_post_meta( $edit->ID, FormMeta::KEY_EXTERNAL_URL, true ) : '';
$curPdf   = $edit ? (int) get_post_meta( $edit->ID, FormMeta::KEY_PDF_FILE_ID, true ) : 0;
$curSgs   = $edit ? array_map( 'intval', (array) get_post_meta( $edit->ID, FormMeta::KEY_SUBGROUPS, true ) ) : [];
$listUrl  = $mUrl( [ 'section' => 'forms' ] );

// "PDF · 420 KB" or "External link" for a row's Type column.
$typeLabel = static function ( \WP_Post $p ): string {
	$type = (string) ( get_post_meta( $p->ID, FormMeta::KEY_FORM_TYPE, true ) ?: FormMeta::TYPE_PDF );
	if ( FormMeta::TYPE_PDF !== $type ) {
		return FormMeta::TYPE_EXTERNAL === $type ? __( 'External link', 'monstera' ) : __( 'Form', 'monstera' );
	}
	$fileId = (int) get_post_meta( $p->ID, FormMeta::KEY_PDF_FILE_ID, true );
	$path   = $fileId ? (string) get_attached_file( $fileId ) : '';
	$size   = $path && file_exists( $path ) ? (int) filesize( $path ) : 0;
	if ( ! $size ) {
		return __( 'PDF', 'monstera' );
	}
	/* translators: %s: the file size, e.g. "420 KB" */
	return sprintf( __( 'PDF · %s', 'monstera' ), size_format( $size ) );
};
?>

<form class="m-form" data-card data-wp-on--submit="actions.manageSave"
	data-endpoint="forms"
	<?php echo $edit ? 'data-id="' . (int) $edit->ID . '"' : ''; ?>
	data-redirect="<?php echo esc_url( $listUrl ); ?>"
	data-msg-upload-failed="<?php esc_attr_e( 'Saved, but the PDF did not upload. Edit the resource to try again.', 'monstera' ); ?>">
	<h3><?php echo $edit ? esc_html__( 'Edit resource', 'monstera' ) : esc_html__( 'New resource', 'monstera' ); ?></h3>
	<div class="m-field">
		<label class="m-field__label" for="m-rs-title"><?php esc_html_e( 'Title', 'monstera' ); ?></label>
		<input class="m-input" id="m-rs-title" type="text" name="title" required value="<?php echo esc_attr( $curTitle ); ?>" />
	</div>
	<div class="m-field">
		<label class="m-field__label" for="m-rs-desc"><?php esc_html_e( 'Description', 'monstera' ); ?></label>
		<textarea class="m-textarea" id="m-rs-desc" name="description"><?php echo esc_textarea( $curDesc ); ?></textarea>
	</div>
	<fieldset class="m-choices" data-inline>
		<legend><?php esc_html_e( 'Type', 'monstera' ); ?></legend>
		<label><input type="radio" name="form_type" value="<?php echo esc_attr( FormMeta::TYPE_EXTERNAL ); ?>" <?php checked( $curType, FormMeta::TYPE_EXTERNAL ); ?> /> <?php esc_html_e( 'External link', 'monstera' ); ?></label>
		<label><input type="radio" name="form_type" value="<?php echo esc_attr( FormMeta::TYPE_PDF ); ?>" <?php checked( $curType, FormMeta::TYPE_PDF ); ?> /> <?php esc_html_e( 'PDF', 'monstera' ); ?></label>
	</fieldset>
	<div class="m-field">
		<label class="m-field__label" for="m-rs-url"><?php esc_html_e( 'External URL', 'monstera' ); ?></label>
		<input class="m-input" id="m-rs-url" type="url" name="external_url" value="<?php echo esc_attr( $curUrl ); ?>" placeholder="https://" />
	</div>
	<?php
	// The chosen PDF: its name and size when one is attached, a native file
	// input to choose or replace it. The store uploads it after the save.
	$pdfName = '';
	$pdfSize = 0;
	if ( $curPdf ) {
		$pdfPath = (string) get_attached_file( $curPdf );
		$pdfName = $pdfPath ? wp_basename( $pdfPath ) : '';
		$pdfSize = $pdfPath && file_exists( $pdfPath ) ? (int) filesize( $pdfPath ) : 0;
	}
	?>
	<div class="m-field">
		<label class="m-field__label" for="m-rs-file"><?php echo $pdfName ? esc_html__( 'Replace the PDF', 'monstera' ) : esc_html__( 'Choose a PDF', 'monstera' ); ?></label>
		<div class="m-filepick">
			<?php if ( $pdfName ) : ?>
				<strong><?php echo esc_html( $pdfName ); ?></strong>
				<?php if ( $pdfSize ) : ?>
					<span><?php echo esc_html( size_format( $pdfSize ) ); ?></span>
				<?php endif; ?>
			<?php else : ?>
				<span><?php esc_html_e( 'No PDF yet', 'monstera' ); ?></span>
			<?php endif; ?>
			<input type="file" id="m-rs-file" name="pdf_file" data-upload="pdf" accept="application/pdf,.pdf" />
		</div>
		<span class="m-field__hint"><?php esc_html_e( 'PDF up to 25 MB. Members download it from the Resources tab.', 'monstera' ); ?></span>
	</div>
	<?php $scopePicker( $curSgs ); ?>
	<div class="m-form__actions">
		<button class="m-btn" data-intent="primary" data-size="md" type="submit">
			<?php echo $edit ? esc_html__( 'Save resource', 'monstera' ) : esc_html__( 'Create resource', 'monstera' ); ?>
		</button>
		<?php if ( $edit ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Cancel', 'monstera' ); ?></a>
		<?php endif; ?>
	</div>
</form>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Resources', 'monstera' ); ?></h3>
	<span class="m-mono">
		<?php
		/* translators: %d: number of resources */
		printf( esc_html( _n( '%d resource', '%d resources', count( $items ), 'monstera' ) ), (int) count( $items ) );
		?>
	</span>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'You haven\'t published any resources yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Resources, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Resource', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Type', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Reaches', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Updated', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $items as $p ) :
					$sgIds   = array_map( 'intval', (array) get_post_meta( $p->ID, FormMeta::KEY_SUBGROUPS, true ) );
					$editUrl = $mUrl(
						[
							'section' => 'forms',
							'edit'    => $p->ID,
						]
					);
					?>
					<tr data-manage-row>
						<td data-priority="1"><a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a></td>
						<td data-priority="2"><?php echo esc_html( $typeLabel( $p ) ); ?></td>
						<td data-priority="3"><?php echo esc_html( $reaches( $sgIds ) ); ?></td>
						<td data-priority="3"><span class="m-mono"><?php echo esc_html( wp_date( 'M j', (int) get_post_modified_time( 'U', true, $p ) ) ); ?></span></td>
						<td data-priority="1"><?php $rowActions( $p, 'forms', 'forms' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
