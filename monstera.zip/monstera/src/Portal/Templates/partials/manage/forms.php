<?php
/**
 * Manage › Forms (comp 132; Forms-and-resources track, FR6). The compose /
 * edit form over the organization's built forms as a priority-column
 * table. The questions are the portal's builder island on a field of the
 * form (resources/js/portal-builder), which reads them from the hidden
 * `fields` field and writes each change back as JSON; the intro is the
 * portal's editor island on another (as a guide's body is); the settings
 * are the form's own fields. Embedded forms are the team's alone, so a
 * kind is never asked here: every form built here is built. The audience
 * is clamped to the author's scope by the route, as every Manage save is,
 * and the organization's leads are emailed each submission unless the
 * author says otherwise. Inherits _org-manage.php scope.
 *
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable(string):\WP_Post[]           $authored
 * @var callable                              $rowActions
 * @var callable                              $scopePicker
 * @var callable(int):string                   $frozenNote
 * @var callable():void                       $orgField
 * @var callable(int[]):string                $reaches
 * @var \Monstera\Portal\AuthorScope          $authorScope
 * @var \WP_User                              $user
 * @var int                                   $orgId
 */

declare(strict_types=1);

use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\PostType as FormType;
use Monstera\Forms\Repository as FormRepository;
use Monstera\Forms\Submissions;
use Monstera\Organizations\Roster;
use Monstera\Portal\CalendarDay;

defined( 'ABSPATH' ) || exit;

// Only a built form is the organization's to edit here: an embed the team
// shared with it stays the team's.
$items = array_values( array_filter( $authored( FormType::SLUG ), static fn ( \WP_Post $p ): bool => FormMeta::KIND_BUILT === FormMeta::kindOf( (int) $p->ID ) ) );
$edit  = $editId ? get_post( $editId ) : null;
// The id comes from the URL: another author's form, or one of the reader's
// own from another organization, must not prefill this hub's form.
if ( $edit && ( FormType::SLUG !== $edit->post_type || FormMeta::KIND_BUILT !== FormMeta::kindOf( (int) $edit->ID ) || ! $authorScope->canEdit( $edit->ID ) ) ) {
	$edit = null;
}
$curTitle   = $edit ? get_the_title( $edit ) : '';
$curDesc    = $edit ? (string) get_post_meta( $edit->ID, FormMeta::KEY_DESCRIPTION, true ) : '';
$curIntro   = $edit ? (string) $edit->post_content : '';
$curFields  = $edit ? FormMeta::fieldsOf( (int) $edit->ID ) : [];
$curRecips  = $edit ? FormMeta::recipientsOf( (int) $edit->ID ) : [
	'emails'    => [],
	'org_leads' => true,
];
$curConfirm = $edit ? (string) get_post_meta( $edit->ID, FormMeta::KEY_CONFIRMATION, true ) : '';
$curClosed  = $edit ? (string) get_post_meta( $edit->ID, FormMeta::KEY_CLOSED_MESSAGE, true ) : '';
$curDue     = $edit ? FormMeta::dueOn( (int) $edit->ID ) : '';
$curRemind  = $edit ? FormMeta::remindWanted( (int) $edit->ID ) : true;
$curOnce    = $edit ? FormMeta::onceOnly( (int) $edit->ID ) : false;
$curAccept  = $edit ? FormMeta::accepting( (int) $edit->ID ) : true;
$curSgs     = $edit ? array_values( array_filter( array_map( 'intval', (array) get_post_meta( $edit->ID, FormMeta::KEY_SUBGROUPS, true ) ) ) ) : [];
$listUrl    = $mUrl( [ 'section' => 'forms' ] );
$orgName    = (string) get_the_title( $orgId );
// The team's built forms that reach the organization: its admins and
// managers see who has sent one (Submissions, comp 133), nothing to edit.
$staffForms = [];
if ( $authorScope->isAdmin || in_array( Roster::roleOf( (int) $user->ID, $orgId ), [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true ) ) {
	foreach ( ( new FormRepository() )->forOrg( $user, $orgId ) as $p ) {
		if ( FormMeta::KIND_BUILT === FormMeta::kindOf( (int) $p->ID ) && 'publish' === $p->post_status && FormMeta::builtByTeam( (int) $p->ID ) ) {
			$staffForms[] = $p;
		}
	}
}
?>

<form class="m-form" method="post" data-card data-wp-on--submit="actions.manageSave"
	data-endpoint="forms"
	<?php echo $edit ? 'data-id="' . (int) $edit->ID . '"' : ''; ?>
	data-redirect="<?php echo esc_url( $listUrl ); ?>">
	<?php
	if ( ! $edit ) {
		$orgField();
	}
	?>
	<input type="hidden" name="kind" value="<?php echo esc_attr( FormMeta::KIND_BUILT ); ?>" />
	<h3><?php echo $edit ? esc_html__( 'Edit form', 'monstera' ) : esc_html__( 'New form', 'monstera' ); ?></h3>
	<p class="m-form__help">
		<?php
		/* translators: %s: the organization's name */
		echo esc_html( sprintf( __( 'Members of %s fill it in under Forms. Every submission is emailed to the people you name and kept under Submissions.', 'monstera' ), $orgName ) );
		?>
	</p>
	<div class="m-field">
		<label class="m-field__label" for="mf-title"><?php esc_html_e( 'Title', 'monstera' ); ?></label>
		<input class="m-input" id="mf-title" type="text" name="title" required value="<?php echo esc_attr( $curTitle ); ?>" />
	</div>
	<div class="m-field">
		<label class="m-field__label" for="mf-desc"><?php esc_html_e( 'One line under the title', 'monstera' ); ?></label>
		<input class="m-input" id="mf-desc" type="text" name="description" value="<?php echo esc_attr( $curDesc ); ?>" />
	</div>
	<?php
	// The intro: the portal's editor island on this field (data-wp-ignore
	// keeps the Interactivity runtime out of it), reading from and writing
	// to the hidden field the save sends.
	?>
	<div class="m-editor m-field">
		<span class="m-field__label" id="mf-intro-label"><?php esc_html_e( 'Introduction', 'monstera' ); ?></span>
		<div id="monstera-portal-editor" data-wp-ignore data-field="intro" data-labelled-by="mf-intro-label">
			<p class="m-field__hint"><?php esc_html_e( 'Loading editor…', 'monstera' ); ?></p>
		</div>
		<textarea name="intro" id="mf-intro" hidden><?php echo esc_textarea( $curIntro ); ?></textarea>
		<span class="m-field__hint"><?php esc_html_e( 'Above the questions on the form\'s page. Leave it empty for none.', 'monstera' ); ?></span>
	</div>
	<?php
	// The questions: the builder island on this field, the list as JSON in
	// the hidden field it reads and writes.
	?>
	<fieldset class="m-fieldset m-field">
		<legend class="m-field__label" id="mf-questions-label"><?php esc_html_e( 'Questions', 'monstera' ); ?></legend>
		<div id="monstera-portal-builder" data-wp-ignore data-field="fields" data-labelled-by="mf-questions-label">
			<p class="m-field__hint"><?php esc_html_e( 'Loading the builder…', 'monstera' ); ?></p>
		</div>
		<textarea name="fields" id="mf-fields" hidden><?php echo esc_textarea( (string) wp_json_encode( $curFields ) ); ?></textarea>
		<span class="m-field__hint"><?php esc_html_e( 'Short text, long text, number, choice, date or file. Up to 50.', 'monstera' ); ?></span>
	</fieldset>
	<fieldset class="m-fieldset m-field">
		<legend class="m-field__label"><?php esc_html_e( 'Settings', 'monstera' ); ?></legend>
		<div class="m-field">
			<span class="m-field__label"><?php esc_html_e( 'Who is emailed each submission', 'monstera' ); ?></span>
			<label class="m-check"><input type="checkbox" class="m-checkbox" name="org_leads" value="1"<?php checked( $curRecips['org_leads'] ); ?> /> <?php /* translators: %s: an organization's name, or several in a list */ echo esc_html( sprintf( __( 'The admins and managers of %s', 'monstera' ), $orgName ) ); ?></label>
			<label class="m-field__label" for="mf-emails"><?php esc_html_e( 'Other addresses', 'monstera' ); ?></label>
			<input class="m-input" id="mf-emails" type="text" name="emails" value="<?php echo esc_attr( implode( ', ', $curRecips['emails'] ) ); ?>" aria-describedby="mf-emails-hint" data-msg-addresses="<?php /* translators: %s: the typed addresses that are not addresses, comma-separated */ esc_attr_e( 'Separate addresses with commas. These are not addresses: %s', 'monstera' ); ?>" />
			<span class="m-field__hint" id="mf-emails-hint"><?php esc_html_e( 'Separate addresses with commas. The member gets a copy of their own answers.', 'monstera' ); ?></span>
		</div>
		<div class="m-field">
			<label class="m-field__label" for="mf-confirm"><?php esc_html_e( 'After sending, say', 'monstera' ); ?></label>
			<input class="m-input" id="mf-confirm" type="text" name="confirmation" value="<?php echo esc_attr( $curConfirm ); ?>" />
		</div>
		<div class="m-form__row">
			<div class="m-field">
				<label class="m-field__label" for="mf-due"><?php esc_html_e( 'Due', 'monstera' ); ?></label>
				<input class="m-input" id="mf-due" type="date" name="due_on" value="<?php echo esc_attr( $curDue ); ?>" aria-describedby="mf-due-hint" data-msg-day="<?php esc_attr_e( 'Pick a day on the calendar.', 'monstera' ); ?>" />
				<span class="m-field__hint" id="mf-due-hint"><?php esc_html_e( 'The form closes at the end of that day. Leave it empty for no due date.', 'monstera' ); ?></span>
			</div>
			<div class="m-field">
				<span class="m-field__label"><?php esc_html_e( 'Reminders', 'monstera' ); ?></span>
				<label class="m-check"><input type="checkbox" class="m-checkbox" name="remind" value="1"<?php checked( $curRemind ); ?> /> <?php esc_html_e( 'Email members who have not sent one, 7 days and 1 day before', 'monstera' ); ?></label>
			</div>
		</div>
		<div class="m-field">
			<span class="m-field__label"><?php esc_html_e( 'Answers', 'monstera' ); ?></span>
			<label class="m-check"><input type="checkbox" class="m-checkbox" name="once_only" value="1"<?php checked( $curOnce ); ?> /> <?php esc_html_e( 'One submission per member', 'monstera' ); ?></label>
			<label class="m-check"><input type="checkbox" class="m-checkbox" name="accepting" value="1"<?php checked( $curAccept ); ?> /> <?php esc_html_e( 'Accepting submissions', 'monstera' ); ?></label>
		</div>
		<div class="m-field">
			<label class="m-field__label" for="mf-closed"><?php esc_html_e( 'When closed, say', 'monstera' ); ?></label>
			<input class="m-input" id="mf-closed" type="text" name="closed_message" value="<?php echo esc_attr( $curClosed ); ?>" />
		</div>
	</fieldset>
	<?php $scopePicker( $curSgs, $edit ? $frozenNote( (int) $edit->ID ) : '' ); ?>
	<div class="m-form__actions">
		<button class="m-btn" data-intent="primary" data-size="md" type="submit" data-status="publish">
			<?php echo $edit && 'publish' === $edit->post_status ? esc_html__( 'Save form', 'monstera' ) : esc_html__( 'Publish form', 'monstera' ); ?>
		</button>
		<button class="m-btn" data-intent="secondary" data-size="md" type="submit" data-status="draft"><?php esc_html_e( 'Save as draft', 'monstera' ); ?></button>
		<?php if ( $edit ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Cancel', 'monstera' ); ?></a>
		<?php endif; ?>
	</div>
</form>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Forms', 'monstera' ); ?></h3>
	<span class="m-mono">
		<?php
		/* translators: %d: number of forms */
		printf( esc_html( _n( '%d form', '%d forms', count( $items ), 'monstera' ) ), (int) count( $items ) );
		?>
	</span>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'You haven\'t built any forms yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Forms, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Form', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Accepting', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Due', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Submissions', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				// A lead counts this organization's; staff the form's. Every
				// row's count in one grouped read.
				$sentOf = Submissions::countsFor( array_map( static fn ( \WP_Post $p ): int => (int) $p->ID, $items ), $authorScope->isAdmin ? null : [ $orgId ] );
				foreach ( $items as $p ) :
					$formId  = (int) $p->ID;
					$editUrl = $mUrl(
						[
							'section' => 'forms',
							'edit'    => $formId,
						]
					);
					$sent    = $sentOf[ $formId ];
					$dueOn   = FormMeta::dueOn( $formId );
					$facts   = [];
					$facts[] = sprintf(
						/* translators: %d: how many questions a form or a discovery asks */
						_n( '%d question', '%d questions', count( FormMeta::fieldsOf( $formId ) ), 'monstera' ),
						count( FormMeta::fieldsOf( $formId ) )
					);
					if ( FormMeta::onceOnly( $formId ) ) {
						$facts[] = __( 'one per member', 'monstera' );
					}
					if ( FormMeta::remind( $formId ) && '' !== $dueOn ) {
						$facts[] = __( 'reminders on', 'monstera' );
					}
					if ( 'publish' !== $p->post_status ) {
						$facts[] = __( 'draft', 'monstera' );
					}
					$accepts = FormMeta::accepting( $formId ) && ( '' === $dueOn || ! \Monstera\Core\SiteDay::hasPassed( $dueOn ) );
					if ( ! $accepts ) {
						$facts[] = __( 'closed', 'monstera' );
					}
					$subsUrl = $mUrl(
						[
							'section'     => 'forms',
							'submissions' => $formId,
						]
					);
					?>
					<tr data-manage-row>
						<td data-priority="1">
							<a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a>
							<span class="m-table__sub"><?php echo esc_html( implode( ' · ', $facts ) ); ?></span>
						</td>
						<td data-priority="2">
							<?php if ( $accepts ) : ?>
								<span class="m-badge" data-tone="success"><?php esc_html_e( 'Accepting', 'monstera' ); ?></span>
							<?php elseif ( '' !== $dueOn && \Monstera\Core\SiteDay::hasPassed( $dueOn ) ) : ?>
								<span class="m-badge" data-tone="neutral"><?php /* translators: %s: the day a form closed */ echo esc_html( sprintf( __( 'Closed %s', 'monstera' ), CalendarDay::format( $dueOn, 'M j' ) ) ); ?></span>
							<?php else : ?>
								<span class="m-badge" data-tone="neutral"><?php esc_html_e( 'Closed', 'monstera' ); ?></span>
							<?php endif; ?>
						</td>
						<td data-priority="3"><span class="m-mono"><?php echo '' !== $dueOn ? esc_html( CalendarDay::format( $dueOn, 'M j' ) ) : '—'; ?></span></td>
						<td data-priority="2">
							<?php
							if ( $sent['count'] > 0 && null !== $sent['last_at'] ) {
								/* translators: 1: how many submissions, 2: the day of the last one */
								echo esc_html( sprintf( __( '%1$d · last %2$s', 'monstera' ), $sent['count'], wp_date( 'M j', (int) strtotime( $sent['last_at'] . ' UTC' ) ) ) );
							} else {
								echo '0';
							}
							?>
						</td>
						<td data-priority="1"><?php $rowActions( $p, 'forms', 'forms', $sent['count'] > 0 ? [ $subsUrl => __( 'Submissions', 'monstera' ) ] : [] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>

<?php if ( $staffForms ) : ?>
	<div class="m-manage__bar">
		<h3>
			<?php
			/* translators: %s: the site's name */
			echo esc_html( sprintf( __( 'Forms from %s', 'monstera' ), (string) get_bloginfo( 'name' ) ) );
			?>
		</h3>
		<span class="m-mono">
			<?php
			/* translators: %d: number of forms */
			printf( esc_html( _n( '%d form', '%d forms', count( $staffForms ), 'monstera' ) ), (int) count( $staffForms ) );
			?>
		</span>
	</div>
	<p class="m-form__help">
		<?php
		/* translators: %s: the organization's name */
		echo esc_html( sprintf( __( 'Built by the team for %s. You can see who has sent one and when; the answers are between each member and the team.', 'monstera' ), $orgName ) );
		?>
	</p>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'The team\'s forms, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Form', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Due', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Sent by', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				// Who has sent each, counted for every row in one read.
				$sendersOf = Submissions::sendersFor( array_map( static fn ( \WP_Post $p ): int => (int) $p->ID, $staffForms ), $orgId );
				foreach ( $staffForms as $p ) :
					$formId  = (int) $p->ID;
					$dueOn   = FormMeta::dueOn( $formId );
					$senders = $sendersOf[ $formId ];
					$subsUrl = $mUrl(
						[
							'section'     => 'forms',
							'submissions' => $formId,
						]
					);
					?>
					<tr data-staff-form-row>
						<td data-priority="1"><span class="m-table__primary"><?php echo esc_html( get_the_title( $p ) ); ?></span></td>
						<td data-priority="3"><span class="m-mono"><?php echo '' !== $dueOn ? esc_html( CalendarDay::format( $dueOn, 'M j' ) ) : '—'; ?></span></td>
						<td data-priority="2">
							<?php
							/* translators: %d: how many members */
							echo esc_html( sprintf( _n( '%d member', '%d members', $senders, 'monstera' ), $senders ) );
							?>
						</td>
						<td data-priority="1">
							<?php if ( $senders > 0 ) : ?>
								<span class="m-table__actions"><a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $subsUrl ); ?>"><?php esc_html_e( 'Submissions', 'monstera' ); ?></a></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
