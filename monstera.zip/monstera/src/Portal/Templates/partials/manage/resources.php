<?php
/**
 * Manage › Resources (comp 52). The compose / edit form over the author's
 * resources as a priority-column table: a link, a file in the Media
 * Library, or a guide whose body is the portal's editor island on a field
 * of the form (Forms-and-resources track, FR6). The kind chosen shows its
 * own fields (`data-for-kind`, actions.manageKind); the island writes block
 * markup into the hidden body field the save sends, and reads it back when
 * a guide is edited. Inherits _org-manage.php scope.
 *
 * @var int                                   $editId
 * @var callable(array<string, mixed>):string $mUrl
 * @var callable(string):\WP_Post[]           $authored
 * @var callable                              $rowActions
 * @var callable                              $scopePicker
 * @var callable(int):string                   $frozenNote
 * @var callable():void                       $orgField
 * @var callable(int[]):string                $reaches
 * @var \Monstera\Portal\AuthorScope          $authorScope
 */

declare(strict_types=1);

use Monstera\Resources\Files as ResourceFiles;
use Monstera\Resources\Meta as ResourceMeta;
use Monstera\Resources\PostType as ResourceType;

defined( 'ABSPATH' ) || exit;

$items = $authored( ResourceType::SLUG );
// The file rows' attachments, read together before each row's label asks.
ResourceFiles::prime( $items );
$edit = $editId ? get_post( $editId ) : null;
// The id comes from the URL: another author's resource, or one of the
// reader's own from another organization, must not prefill this hub's form
// (the route would refuse the save, but the reader would see the item).
if ( $edit && ( ResourceType::SLUG !== $edit->post_type || ! $authorScope->canEdit( $edit->ID ) ) ) {
	$edit = null;
}

$curTitle = $edit ? get_the_title( $edit ) : '';
$curKind  = $edit ? ResourceMeta::kindOf( (int) $edit->ID ) : ResourceMeta::KIND_LINK;
$curDesc  = $edit ? (string) get_post_meta( $edit->ID, ResourceMeta::KEY_DESCRIPTION, true ) : '';
$curUrl   = $edit ? (string) get_post_meta( $edit->ID, ResourceMeta::KEY_EXTERNAL_URL, true ) : '';
$curPdf   = $edit ? (int) get_post_meta( $edit->ID, ResourceMeta::KEY_FILE_ID, true ) : 0;
$curBody  = $edit ? (string) $edit->post_content : '';
/**
 * The fields of one kind: shown for the kind in hand, hidden for the others
 * until it is chosen, their controls disabled meanwhile so the browser
 * neither checks nor sends them (actions.manageKind keeps this in step).
 */
$forKind = static function ( string $kind ) use ( $curKind ): void {
	printf( ' data-for-kind="%s"%s', esc_attr( $kind ), $kind === $curKind ? '' : ' hidden' );
};
$offKind = static function ( string $kind ) use ( $curKind ): void {
	echo $kind === $curKind ? '' : ' disabled';
};
$curSgs  = $edit ? array_values( array_filter( array_map( 'intval', (array) get_post_meta( $edit->ID, ResourceMeta::KEY_SUBGROUPS, true ) ) ) ) : [];
$listUrl = $mUrl( [ 'section' => 'resources' ] );

// "File · PDF · 420 KB", "Link" or "Guide" for a row's Kind column.
$typeLabel = static function ( \WP_Post $p ): string {
	$kind = ResourceMeta::kindOf( (int) $p->ID );
	if ( ResourceMeta::KIND_FILE !== $kind ) {
		return ResourceMeta::KIND_GUIDE === $kind ? __( 'Guide', 'monstera' ) : __( 'Link', 'monstera' );
	}
	$fileId = (int) get_post_meta( $p->ID, ResourceMeta::KEY_FILE_ID, true );
	$path   = $fileId ? (string) get_attached_file( $fileId ) : '';
	$size   = $path && file_exists( $path ) ? (int) filesize( $path ) : 0;
	$ext    = $path ? strtoupper( (string) pathinfo( $path, PATHINFO_EXTENSION ) ) : '';
	if ( ! $size ) {
		return __( 'File', 'monstera' );
	}
	/* translators: 1: the file's kind, e.g. "PDF", 2: the file size, e.g. "420 KB" */
	return sprintf( __( 'File · %1$s · %2$s', 'monstera' ), $ext, size_format( $size ) );
};
?>

<form class="m-form" method="post" data-card data-wp-on--submit="actions.manageSave"
	data-endpoint="resources"
	<?php echo $edit ? 'data-id="' . (int) $edit->ID . '"' : ''; ?>
	data-redirect="<?php echo esc_url( $listUrl ); ?>"
	data-msg-upload-failed="<?php esc_attr_e( 'Saved, but the file did not upload. Edit the resource to try again.', 'monstera' ); ?>"
	data-msg-upload-refused="<?php /* translators: %s: why the site refused the file, in its own words, e.g. "That file is over 64 MB. Choose a smaller one." */ esc_attr_e( 'Saved, but the file did not upload. %s', 'monstera' ); ?>"
	data-msg-file-big="<?php /* translators: %s: the largest file allowed, e.g. "64 MB" */ echo esc_attr( sprintf( __( 'That file is over %s. Choose a smaller one.', 'monstera' ), size_format( ResourceFiles::maxBytes() ) ) ); ?>"
	data-msg-file-server-big="<?php esc_attr_e( 'That file is larger than this site accepts. Send a smaller one.', 'monstera' ); ?>"
	data-msg-file-signed-out="<?php esc_attr_e( 'Your session has ended. Reload the page, then try again.', 'monstera' ); ?>">
	<?php
	if ( ! $edit ) {
		$orgField();
	}
	?>
	<h3><?php echo $edit ? esc_html__( 'Edit resource', 'monstera' ) : esc_html__( 'New resource', 'monstera' ); ?></h3>
	<div class="m-field">
		<label class="m-field__label" for="m-rs-title"><?php esc_html_e( 'Title', 'monstera' ); ?></label>
		<input class="m-input" id="m-rs-title" type="text" name="title" required value="<?php echo esc_attr( $curTitle ); ?>" />
	</div>
	<div class="m-field">
		<label class="m-field__label" for="m-rs-desc"><?php esc_html_e( 'Description', 'monstera' ); ?></label>
		<textarea class="m-textarea" id="m-rs-desc" name="description"><?php echo esc_textarea( $curDesc ); ?></textarea>
	</div>
	<fieldset class="m-choices" data-inline data-wp-on--change="actions.manageKind">
		<legend><?php esc_html_e( 'Kind', 'monstera' ); ?></legend>
		<label><input type="radio" name="kind" value="<?php echo esc_attr( ResourceMeta::KIND_LINK ); ?>"<?php checked( $curKind, ResourceMeta::KIND_LINK ); ?> /> <?php esc_html_e( 'Link', 'monstera' ); ?></label>
		<label><input type="radio" name="kind" value="<?php echo esc_attr( ResourceMeta::KIND_FILE ); ?>"<?php checked( $curKind, ResourceMeta::KIND_FILE ); ?> /> <?php esc_html_e( 'File', 'monstera' ); ?></label>
		<label><input type="radio" name="kind" value="<?php echo esc_attr( ResourceMeta::KIND_GUIDE ); ?>"<?php checked( $curKind, ResourceMeta::KIND_GUIDE ); ?> /> <?php esc_html_e( 'Guide', 'monstera' ); ?></label>
	</fieldset>
	<div class="m-field"<?php $forKind( ResourceMeta::KIND_LINK ); ?>>
		<label class="m-field__label" for="m-rs-url"><?php esc_html_e( 'External URL', 'monstera' ); ?></label>
		<input class="m-input" id="m-rs-url" type="url" name="external_url" value="<?php echo esc_attr( $curUrl ); ?>" placeholder="https://"<?php $offKind( ResourceMeta::KIND_LINK ); ?> />
	</div>
	<?php
	// The chosen file: its name and size when one is attached, a native file
	// input to choose or replace it. The store uploads it after the save,
	// refuses one over the hint's limit under the field before the save, and
	// says why the site refused one in the site's own words.
	$pdfName = '';
	$pdfSize = 0;
	if ( $curPdf ) {
		$pdfPath = (string) get_attached_file( $curPdf );
		$pdfName = $pdfPath ? wp_basename( $pdfPath ) : '';
		$pdfSize = $pdfPath && file_exists( $pdfPath ) ? (int) filesize( $pdfPath ) : 0;
	}
	?>
	<div class="m-field"<?php $forKind( ResourceMeta::KIND_FILE ); ?>>
		<label class="m-field__label" for="m-rs-file"><?php echo $pdfName ? esc_html__( 'Replace the file', 'monstera' ) : esc_html__( 'Choose a file', 'monstera' ); ?></label>
		<div class="m-filepick">
			<?php if ( $pdfName ) : ?>
				<strong><?php echo esc_html( $pdfName ); ?></strong>
				<?php if ( $pdfSize ) : ?>
					<span><?php echo esc_html( size_format( $pdfSize ) ); ?></span>
				<?php endif; ?>
			<?php else : ?>
				<span><?php esc_html_e( 'No file yet', 'monstera' ); ?></span>
			<?php endif; ?>
			<input type="file" id="m-rs-file" name="file" data-upload="file" data-max-bytes="<?php echo (int) ResourceFiles::maxBytes(); ?>" aria-describedby="m-rs-file-hint"<?php echo '' !== ResourceFiles::accept() ? ' accept="' . esc_attr( ResourceFiles::accept() ) . '"' : ''; ?><?php $offKind( ResourceMeta::KIND_FILE ); ?> />
		</div>
		<span class="m-field__hint" id="m-rs-file-hint">
			<?php
			/* translators: %s: the largest file allowed, e.g. "64 MB" */
			printf( esc_html__( 'Any file this site allows, up to %s. Members download it from the Resources tab.', 'monstera' ), esc_html( (string) size_format( ResourceFiles::maxBytes() ) ) );
			?>
		</span>
		<span class="m-field__error" id="m-rs-file-error" hidden></span>
	</div>
	<?php
	// A guide's body: the portal's editor island on this field (data-wp-ignore
	// keeps the Interactivity runtime out of it, as content's compose does).
	// The island reads the body from the hidden field and writes each change
	// back, so the save sends it as any other field.
	?>
	<div class="m-editor m-field"<?php $forKind( ResourceMeta::KIND_GUIDE ); ?>>
		<span class="m-field__label" id="m-rs-body-label"><?php esc_html_e( 'Guide', 'monstera' ); ?></span>
		<div id="monstera-portal-editor" data-wp-ignore data-field="body" data-labelled-by="m-rs-body-label">
			<p class="m-field__hint"><?php esc_html_e( 'Loading editor…', 'monstera' ); ?></p>
		</div>
		<textarea name="body" id="m-rs-body" hidden<?php $offKind( ResourceMeta::KIND_GUIDE ); ?>><?php echo esc_textarea( $curBody ); ?></textarea>
		<span class="m-field__hint"><?php esc_html_e( 'Members read it on its own page under Resources. Images and files you add here go to the Media Library and are not confidential.', 'monstera' ); ?></span>
	</div>
	<?php $scopePicker( $curSgs, $edit ? $frozenNote( (int) $edit->ID ) : '' ); ?>
	<div class="m-form__actions">
		<button class="m-btn" data-intent="primary" data-size="md" type="submit">
			<?php echo $edit ? esc_html__( 'Save resource', 'monstera' ) : esc_html__( 'Create resource', 'monstera' ); ?>
		</button>
		<?php if ( $edit ) : ?>
			<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( $listUrl ); ?>"><?php esc_html_e( 'Cancel', 'monstera' ); ?></a>
		<?php endif; ?>
	</div>
</form>

<div class="m-manage__bar">
	<h3><?php esc_html_e( 'Resources', 'monstera' ); ?></h3>
	<span class="m-mono">
		<?php
		/* translators: %d: number of resources */
		printf( esc_html( _n( '%d resource', '%d resources', count( $items ), 'monstera' ) ), (int) count( $items ) );
		?>
	</span>
</div>

<?php if ( ! $items ) : ?>
	<p class="m-manage__empty"><?php esc_html_e( 'You haven\'t published any resources yet.', 'monstera' ); ?></p>
<?php else : ?>
	<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Resources, scrolls sideways', 'monstera' ); ?>">
		<table class="m-table">
			<thead>
				<tr>
					<th scope="col" data-priority="1"><?php esc_html_e( 'Resource', 'monstera' ); ?></th>
					<th scope="col" data-priority="2"><?php esc_html_e( 'Kind', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Reaches', 'monstera' ); ?></th>
					<th scope="col" data-priority="3"><?php esc_html_e( 'Updated', 'monstera' ); ?></th>
					<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $items as $p ) :
					$sgIds   = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $p->ID, ResourceMeta::KEY_SUBGROUPS, true ) ) ) );
					$editUrl = $mUrl(
						[
							'section' => 'resources',
							'edit'    => $p->ID,
						]
					);
					?>
					<tr data-manage-row>
						<td data-priority="1">
							<a class="m-table__primary" href="<?php echo esc_url( $editUrl ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a>
							<?php if ( 'publish' !== $p->post_status ) : ?>
								<span class="m-table__sub"><?php 'pending' === $p->post_status ? esc_html_e( 'Pending · not on the Resources page yet', 'monstera' ) : esc_html_e( 'Draft · not on the Resources page yet', 'monstera' ); ?></span>
							<?php endif; ?>
						</td>
						<td data-priority="2"><?php echo esc_html( $typeLabel( $p ) ); ?></td>
						<td data-priority="3"><?php echo esc_html( $reaches( $sgIds ) ); ?></td>
						<td data-priority="3"><span class="m-mono"><?php echo esc_html( wp_date( 'M j', (int) get_post_modified_time( 'U', true, $p ) ) ); ?></span></td>
						<td data-priority="1"><?php $rowActions( $p, 'resources', 'resources' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
