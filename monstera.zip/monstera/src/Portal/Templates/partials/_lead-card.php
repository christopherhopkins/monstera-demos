<?php
/**
 * The lead card (At-a-glance track, FR7; comp 72): a rail block naming the
 * person a client reaches first, with their position, their photo (the
 * leaf on the brand ground without one, as staff write in a conversation)
 * and their account email as a mailto. The project page opens its rail with
 * it; Portal\Leads says whom it names and under which heading.
 *
 * Included in the caller's scope.
 *
 * @var \WP_User $lead        Staff, as Portal\Leads offers them.
 * @var string   $leadHeading "Your project lead" or "Your account lead".
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

$leadPosition = trim( (string) get_user_meta( $lead->ID, UserMeta::KEY_POSITION, true ) );
$leadPhoto    = UserMeta::photoUrl( (int) $lead->ID );
$leadEmail    = is_email( $lead->user_email ) ? (string) $lead->user_email : '';
?>
<div class="m-rail-block m-lead-card">
	<h3><?php echo esc_html( $leadHeading ); ?></h3>
	<div class="m-lead-card__who">
		<?php if ( $leadPhoto ) : ?>
			<span class="m-avatar" data-size="md" aria-hidden="true"><img src="<?php echo esc_url( $leadPhoto ); ?>" alt="" /></span>
		<?php else : ?>
			<span class="m-avatar" data-size="md" data-staff aria-hidden="true"><?php Icons::sprig(); ?></span>
		<?php endif; ?>
		<span>
			<strong><?php echo esc_html( UserMeta::fullName( $lead ) ); ?></strong>
			<?php if ( '' !== $leadPosition ) : ?>
				<small><?php echo esc_html( $leadPosition ); ?></small>
			<?php endif; ?>
		</span>
	</div>
	<?php if ( '' !== $leadEmail ) : ?>
		<a class="m-lead-card__mail" href="<?php echo esc_url( 'mailto:' . $leadEmail ); ?>"><?php echo esc_html( $leadEmail ); ?></a>
	<?php endif; ?>
</div>
