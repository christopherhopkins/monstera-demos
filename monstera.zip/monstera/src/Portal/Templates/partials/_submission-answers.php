<?php
/**
 * One submission's answers as stats, in question order, removed questions
 * last by key. Drawn on the form's page under the member's own send and on
 * Manage › Submissions under a row the organization's leads open.
 *
 * Each key says what was sent under it, whatever its question is now, as
 * the admin's sheet does (SubmissionSheet.js, entry()): the written answer,
 * then its files as links signed for the reader (Content\Downloader decides
 * at the download who may open one). So a question retyped since keeps
 * what it was sent as, a file question become a text one its files and a
 * text one become a file question its words. A removed question's answer
 * and files stay under "key (removed question)", and so do the files of a
 * key no question asks any more.
 *
 * @var array<string, mixed>                      $row         Submissions::find()'s shape.
 * @var list<array<string, mixed>>                $fields      Meta::fieldsOf().
 * @var list<string>                              $removedKeys Submissions::removedKeys().
 * @var array<string, list<array<string, mixed>>> $files       The row's files by question, as Submissions::filesOf() or filesOfMany() reads them.
 * @var \WP_User                                  $user        The reader.
 * @var string                                    $idPrefix    For the file lists' labels.
 */

declare(strict_types=1);

use Monstera\Content\Downloader;
use Monstera\Forms\Answers;

defined( 'ABSPATH' ) || exit;

// The keys no question asks: those the form names as removed, then any key
// with files that it does not (a file answer is stored empty, so
// Submissions::removedKeys() does not see it).
$asked   = array_map( static fn ( array $question ): string => (string) $question['key'], $fields );
$removed = array_map( 'strval', $removedKeys );
foreach ( $files as $fileKey => $fileList ) {
	$fileKey = (string) $fileKey;
	if ( $fileList && ! in_array( $fileKey, $asked, true ) && ! in_array( $fileKey, $removed, true ) ) {
		$removed[] = $fileKey;
	}
}

// Each entry: the key, its label, the question as it is now (null when it
// is gone, so its answer is read as written).
$entries = [];
foreach ( $fields as $question ) {
	$entries[] = [ (string) $question['key'], (string) $question['label'], $question ];
}
foreach ( $removed as $removedKey ) {
	$entries[] = [
		$removedKey,
		/* translators: %s: a removed question's key */
		sprintf( __( '%s (removed question)', 'monstera' ), $removedKey ),
		null,
	];
}

foreach ( $entries as [ $key, $label, $question ] ) {
	$text = Answers::text(
		$question ?? [
			'key'  => $key,
			'type' => '',
		],
		(array) $row['answers']
	);
	$list = $files[ $key ] ?? [];
	if ( '' === $text && ! $list ) {
		continue;
	}
	$mono = $question && 'number' === $question['type'] ? ' m-mono' : '';
	if ( ! $list ) {
		?>
		<div class="m-stat"><span class="m-stat__label"><?php echo esc_html( $label ); ?></span><span class="m-stat__value<?php echo esc_attr( $mono ); ?>"><?php echo esc_html( $text ); ?></span></div>
		<?php
		continue;
	}
	$labelId = $idPrefix . '-' . sanitize_html_class( $key );
	?>
	<div class="m-stat">
		<span class="m-stat__label" id="<?php echo esc_attr( $labelId ); ?>"><?php echo esc_html( $label ); ?></span>
		<div class="m-stat__value" data-files>
			<?php if ( '' !== $text ) : ?>
				<p class="m-stat__text<?php echo esc_attr( $mono ); ?>"><?php echo esc_html( $text ); ?></p>
			<?php endif; ?>
			<ul class="m-files" aria-labelledby="<?php echo esc_attr( $labelId ); ?>">
				<?php foreach ( $list as $file ) : ?>
					<li class="m-files__row">
						<span class="m-files__kind" aria-hidden="true"><?php echo esc_html( strtolower( (string) pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) ) ?: 'file' ); ?></span>
						<a class="m-files__name" href="<?php echo esc_url( Downloader::signedUrl( (int) $file['id'], (int) $user->ID ) ); ?>"><?php echo esc_html( (string) $file['name'] ); ?></a>
						<span class="m-files__meta"><span><?php echo esc_html( (string) size_format( (int) $file['size'] ) ); ?></span></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<?php
}
