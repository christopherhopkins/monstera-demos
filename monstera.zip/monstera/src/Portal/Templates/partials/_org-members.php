<?php
/**
 * Org-hub "Members" tab: the invite form over the roster with tiers
 * (comp 43 for an organization admin and the team, comp 44 for a manager).
 *
 * Included from org.php in the current scope, so it inherits $user, $org,
 * $orgId, $orgMembers and $seatLimit. What the viewer is offered is asked of
 * Organizations\RosterPolicy, the rules the roster's routes refuse by, and
 * is never worked out here: a control this page shows is one the route
 * honours. A control the viewer may not use is absent, not disabled. A
 * plain member reads the roster and nothing to act with.
 *
 * Nothing here is saved by the page. A tier is chosen in the row's select
 * and asked about in the row before it is sent; Remove asks in the row too;
 * what came of either is held on the row by the store, which reads its
 * sentences from the list (data-msg-*), so they are translated here. In
 * them {name} and {first} stand for the person of the row acted on. The
 * list carries each tier's label the same way, and a row marks the tier
 * word its line shows, so a tier that moved behind the page is shown when
 * the store reads the roster again.
 *
 * What a row offers can move behind the page too: for a manager, someone
 * made a manager is no longer theirs to remove, and someone made a plain
 * member now is. Each row says what it offers (data-can), the roster's
 * route says the same of each person, and where the two differ the store
 * asks for this tab again and puts the row printed then in the row's place.
 * So a control is only ever one this template printed, with its question
 * and its labels, and the store builds none.
 *
 * The invitation is the store's to send too. A submit it does not take
 * (scripting off, or the page's script not there yet) is the browser's own,
 * so the form posts to this tab's address, where nothing is done with it:
 * nothing typed reaches the address bar, and the form says that nothing
 * was sent.
 *
 * @var \WP_User   $user
 * @var \WP_Post   $org
 * @var int        $orgId
 * @var \WP_User[] $orgMembers
 * @var int        $seatLimit
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Roster;
use Monstera\Organizations\RosterPolicy;
use Monstera\Portal\Flash;

defined( 'ABSPATH' ) || exit;

$policy      = RosterPolicy::of( $user, $orgId );
$manages     = $policy->manages();
$setsTiers   = null === $policy->tiersRefusal();
$inviteTiers = $policy->inviteTiers();
$orgName     = get_the_title( $org );
$tierLabels  = [
	Roster::TIER_MEMBER  => __( 'Member', 'monstera' ),
	Roster::TIER_MANAGER => __( 'Manager', 'monstera' ),
	Roster::TIER_ADMIN   => __( 'Organization admin', 'monstera' ),
];

// True of a new address and of one that already has an account: the first
// is sent a link to set a password, the second a link to this organization.
$joins = __( 'They\'ll get an email with a link to join the portal.', 'monstera' );
?>

<?php if ( $inviteTiers ) : ?>
	<?php
	// The page comes back with this once an invitation went (the store adds
	// it to the address), and says so here, where the form was sent from. The
	// address only asks: the sentence is said when the route left its note
	// that this person's invitation into this organization went, and once
	// (Portal\Flash), so a link made by hand says nothing.
	$justInvited = isset( $_GET['invited'] ) && Flash::take( Flash::INVITED, (int) $orgId ); // phpcs:ignore WordPress.Security.NonceVerification -- a read-only flag for a sentence; the note it collects is the reader's own.
	$asksTier    = count( $inviteTiers ) > 1;
	// The store sends the invitation. A submit it did not take is the
	// browser's: with no method the fields would go in the address (a name
	// and an email in the address bar, the history and the server's log), so
	// the form posts, and to this tab, where a post is read as any visit is
	// and nothing is done with what it carried. Whoever arrives by one is
	// told that nothing was sent; where there is no scripting at all the
	// form says what it needs before anything is typed.
	$inviteHere  = add_query_arg( 'tab', 'members', Routing::url( Routing::ROUTE_ORG, [ 'slug' => (string) $org->post_name ] ) ) . '#m-org-invite';
	$postedPlain = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
	$needsScript = __( 'Sending an invitation needs JavaScript.', 'monstera' );
	?>
	<form class="m-invite" id="m-org-invite" method="post" action="<?php echo esc_url( $inviteHere ); ?>" novalidate data-org-id="<?php echo (int) $orgId; ?>" data-msg-failed="<?php esc_attr_e( 'The request failed.', 'monstera' ); ?>" data-wp-on--submit="actions.inviteMember">
		<h2><?php esc_html_e( 'Invite a member', 'monstera' ); ?></h2>
		<?php if ( $justInvited ) : ?>
			<div class="m-toast" data-wp-init="callbacks.flash"><?php Icons::emit( 'check', 18 ); ?><span><strong><?php esc_html_e( 'Invitation sent.', 'monstera' ); ?></strong> <?php echo esc_html( $joins ); ?></span></div>
			<div class="m-sr-only" role="status" aria-live="polite" data-flash-status></div>
		<?php endif; ?>
		<p>
			<?php
			if ( $seatLimit ) {
				// The seats taken move when someone is removed in place, so the
				// sentence carries its own pattern and the limit for the store to
				// redraw it from (redrawRosterCounts); the plural is the limit's,
				// which does not move.
				/* translators: 1: seats taken, 2: the seat limit */
				$seatsUsed = _n( '%1$d of %2$d seat used.', '%1$d of %2$d seats used.', $seatLimit, 'monstera' );
				printf(
					'<span data-seats="%s" data-seat-limit="%d">%s</span> ',
					esc_attr( $seatsUsed ),
					(int) $seatLimit,
					esc_html( sprintf( $seatsUsed, count( $orgMembers ), $seatLimit ) )
				);
			}
			echo esc_html( $joins );
			?>
		</p>
		<div class="m-invite__fields">
			<div class="m-field">
				<label class="m-field__label" for="m-invite-first"><?php esc_html_e( 'First name', 'monstera' ); ?></label>
				<input class="m-input" id="m-invite-first" name="first_name" type="text" autocomplete="off" />
			</div>
			<div class="m-field">
				<label class="m-field__label" for="m-invite-last"><?php esc_html_e( 'Last name', 'monstera' ); ?></label>
				<input class="m-input" id="m-invite-last" name="last_name" type="text" autocomplete="off" />
			</div>
			<div class="m-field"<?php echo $asksTier ? '' : ' data-span'; ?>>
				<label class="m-field__label" for="m-invite-email"><?php esc_html_e( 'Email', 'monstera' ); ?></label>
				<input class="m-input" id="m-invite-email" name="email" type="email" required autocomplete="off" inputmode="email" spellcheck="false" />
				<span class="m-field__error" id="m-invite-email-error" hidden></span>
			</div>
			<?php if ( $asksTier ) : ?>
				<div class="m-field">
					<label class="m-field__label" for="m-invite-tier"><?php esc_html_e( 'Tier', 'monstera' ); ?></label>
					<select class="m-select" id="m-invite-tier" name="tier" autocomplete="off" aria-describedby="m-invite-tier-hint">
						<?php foreach ( $inviteTiers as $inviteTier ) : ?>
							<option value="<?php echo esc_attr( $inviteTier ); ?>"<?php echo Roster::TIER_MEMBER === $inviteTier ? ' selected' : ''; ?>><?php echo esc_html( $tierLabels[ $inviteTier ] ); ?></option>
						<?php endforeach; ?>
					</select>
					<span class="m-field__hint" id="m-invite-tier-hint"><?php esc_html_e( 'Managers can invite and remove members. Organization admins can also change tiers and remove anyone.', 'monstera' ); ?></span>
					<span class="m-field__error" id="m-invite-tier-error" hidden></span>
				</div>
			<?php endif; ?>
		</div>
		<?php if ( $postedPlain ) : ?>
			<div class="m-invite__refusal" tabindex="-1"><?php echo esc_html( __( 'Nothing was sent.', 'monstera' ) . ' ' . $needsScript ); ?></div>
		<?php else : ?>
			<div class="m-invite__refusal" tabindex="-1" hidden></div>
			<noscript><p class="m-invite__refusal"><?php echo esc_html( $needsScript ); ?></p></noscript>
		<?php endif; ?>
		<div class="m-invite__actions">
			<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php esc_html_e( 'Send invitation', 'monstera' ); ?></button>
		</div>
	</form>
<?php endif; ?>

<?php if ( ! $orgMembers ) : ?>
	<div class="m-empty">
		<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
		<p class="m-empty__message"><?php esc_html_e( 'No members yet.', 'monstera' ); ?></p>
	</div>
	<?php
	return;
endif;

$rosterMore = max( 0, count( $orgMembers ) - 25 );

// One line saying what the viewer may do here. The team may leave an
// organization with no admin, so it is not told that one is kept.
$lead = '';
if ( $setsTiers ) {
	$lead = $policy->keepsAnAdmin()
		? __( 'You can change anyone\'s tier or remove them. The organization keeps at least one admin.', 'monstera' )
		: __( 'You can change anyone\'s tier or remove them.', 'monstera' );
} elseif ( $manages ) {
	$lead = __( 'You can invite members and remove them. Only an organization admin can make someone a manager or an admin.', 'monstera' );
}

// What the store says on a row, by what was asked or what came of it. The
// sentences a change came to are the admin roster's own (memberships.js).
$says = [];
if ( $manages ) {
	$says = [
		/* translators: 1: a person's name, 2: an organization's name */
		'removed'  => sprintf( __( '%1$s is no longer in %2$s.', 'monstera' ), '{name}', $orgName ),
		/* translators: 1: a person's name, 2: an organization's name */
		'still'    => sprintf( __( '%1$s is still in %2$s.', 'monstera' ), '{name}', $orgName ),
		'sent'     => __( 'Invitation sent again.', 'monstera' ),
		'not-sent' => __( 'Not sent.', 'monstera' ),
		'failed'   => __( 'The request failed.', 'monstera' ),
	];
	// Each tier's label, for the word a row's line shows: the roster is read
	// again when the server says the page is behind, and a row with no tier
	// control has only the word to say a tier that moved.
	foreach ( $tierLabels as $tierKey => $tierLabel ) {
		$says[ 'tier-' . $tierKey ] = $tierLabel;
	}
}
if ( $setsTiers ) {
	$says += [
		/* translators: %s: a person's first name */
		'ask-member'  => sprintf( __( 'Make %s a member? Members cannot invite or remove anyone.', 'monstera' ), '{first}' ),
		/* translators: %s: a person's first name */
		'ask-manager' => sprintf( __( 'Make %s a manager? Managers can invite and remove members.', 'monstera' ), '{first}' ),
		/* translators: %s: a person's first name */
		'ask-admin'   => sprintf( __( 'Make %s an organization admin? Organization admins can also change tiers and remove anyone.', 'monstera' ), '{first}' ),
		'do-member'   => __( 'Make member', 'monstera' ),
		'do-manager'  => __( 'Make manager', 'monstera' ),
		'do-admin'    => __( 'Make organization admin', 'monstera' ),
		// In sentence case mid-sentence, as the questions above say "a
		// manager" and "an organization admin".
		/* translators: 1: a person's name, 2: an organization's name */
		'now-member'  => sprintf( __( '%1$s is now a member in %2$s.', 'monstera' ), '{name}', $orgName ),
		/* translators: 1: a person's name, 2: an organization's name */
		'now-manager' => sprintf( __( '%1$s is now a manager in %2$s.', 'monstera' ), '{name}', $orgName ),
		/* translators: 1: a person's name, 2: an organization's name */
		'now-admin'   => sprintf( __( '%1$s is now an organization admin in %2$s.', 'monstera' ), '{name}', $orgName ),
		'can-member'  => __( 'They no longer invite, remove or change anyone there.', 'monstera' ),
		'can-manager' => __( 'They can invite and remove members there.', 'monstera' ),
		'can-admin'   => __( 'They can change anyone’s tier there and remove anyone.', 'monstera' ),
		'tier-kept'   => __( 'The tier was not changed.', 'monstera' ),
		// After "The tier was not changed.": a tier chosen while the roster
		// waited on another request. The controls do not open then, but a
		// choice can still reach one (a touch picker, assistive technology
		// that sets the value), and the select going back alone says
		// nothing. The admin roster's own sentence (memberships.js).
		'waits'       => __( 'Another change was still being saved. Choose the tier again.', 'monstera' ),
	];
	// The team may give an organization's only admin another tier, or take
	// them off. What that leaves is said with what the change came to, as the
	// admin roster says it (memberships.js hasNoAdmin()).
	if ( ! $policy->keepsAnAdmin() ) {
		/* translators: %s: an organization's name */
		$says['no-admin'] = sprintf( __( '%s has no organization admin until you name one.', 'monstera' ), $orgName );
	}
}
?>
<section class="m-section" aria-labelledby="m-org-members">
	<div class="m-section__head">
		<h2 id="m-org-members"><?php esc_html_e( 'Members', 'monstera' ); ?></h2>
		<?php // The count moves when someone is removed in place: both forms ride on the span for the store to redraw it from (redrawRosterCounts), as the directory's status line carries its own. ?>
		<span class="m-section__link m-mono" data-roster-count data-one="<?php /* translators: %d: number of members */ esc_attr_e( '%d person', 'monstera' ); ?>" data-many="<?php /* translators: %d: number of members */ esc_attr_e( '%d people', 'monstera' ); ?>">
		<?php
			/* translators: %d: number of members */
			printf( esc_html( _n( '%d person', '%d people', count( $orgMembers ), 'monstera' ) ), (int) count( $orgMembers ) );
		?>
			</span>
	</div>
	<?php if ( $manages ) : ?>
		<p class="m-roster-lead"><?php echo esc_html( $lead ); ?></p>
		<?php // The tier control and Remove are the store's, as the invite form's submit is: where there is no scripting the lead says so. ?>
		<noscript><p class="m-roster-lead"><?php esc_html_e( 'Changing a tier or removing someone needs JavaScript.', 'monstera' ); ?></p></noscript>
		<?php // What a change came to is said here once; the row holds it for the eye. ?>
		<p class="m-sr-only" role="status" aria-live="polite" data-roster-status></p>
	<?php endif; ?>
	<ul class="m-roster" data-reveal
		<?php if ( $manages ) : ?>
			data-org-id="<?php echo (int) $orgId; ?>"
			data-sent-label="<?php esc_attr_e( 'Sent', 'monstera' ); ?>"
			<?php foreach ( $says as $key => $sentence ) : ?>
				data-msg-<?php echo esc_attr( $key ); ?>="<?php echo esc_attr( $sentence ); ?>"
			<?php endforeach; ?>
		<?php endif; ?>
		>
		<?php
		foreach ( $orgMembers as $i => $member ) :
			$memberId  = (int) $member->ID;
			$isSelf    = $memberId === (int) $user->ID;
			$name      = trim( $member->first_name . ' ' . $member->last_name ) ?: $member->display_name;
			$firstName = $member->first_name ?: $member->display_name;
			$position  = (string) get_user_meta( $memberId, UserMeta::KEY_POSITION, true );
			$photo     = (int) get_user_meta( $memberId, UserMeta::KEY_PROFILE_PHOTO, true );
			$photoUrl  = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
			$signedIn  = UserMeta::hasSignedIn( $memberId );
			// The tier held in this organization, not the WordPress role: a
			// manager elsewhere is a plain member here.
			$tierHeld = (string) Roster::roleOf( $memberId, $orgId );
			$tierWord = $tierLabels[ $tierHeld ] ?? '';
			$offer    = $policy->rowOffer( $memberId );
			$hasTier  = (bool) $offer['tiers'];
			$acts     = $hasTier || $offer['remove'] || $offer['resend'];
			// Someone who has not signed in is an invitation, dated from the
			// day this membership began: an account that was attached may be
			// years older than its place here.
			$invitedOn = '';
			if ( ! $signedIn ) {
				$since     = (string) Roster::sinceOf( $memberId, $orgId );
				$invitedOn = wp_date( 'M j', '' !== $since ? ( strtotime( $since . ' UTC' ) ?: null ) : null );
			}
			// The tier as the role line shows it. For someone who works the
			// roster the word is marked, so the store can put the tier held
			// now in its place when it reads the roster again (setRowTier);
			// a plain member's roster is never read again and carries no
			// mark. The line is built here of escaped pieces around that one
			// span, and printed as it is.
			$tierMark = esc_html( $tierWord );
			if ( $manages && '' !== $tierWord ) {
				$tierMark = '<span data-tier-word>' . $tierMark . '</span>';
			}
			// Where the row has a tier control the tier is in it, so an
			// invitation's line leaves the word out.
			if ( $signedIn ) {
				$roleLine = implode( ' · ', array_filter( [ esc_html( $position ), $tierMark ] ) );
			} elseif ( $hasTier ) {
				/* translators: %s: the date the invitation went out */
				$roleLine = sprintf( esc_html__( 'Invited %s · not yet signed in', 'monstera' ), esc_html( $invitedOn ) );
			} else {
				/* translators: 1: the date the invitation went out, 2: the tier the person was invited at */
				$roleLine = sprintf( esc_html__( 'Invited %1$s · %2$s · not yet signed in', 'monstera' ), esc_html( $invitedOn ), $tierMark );
			}
			/* translators: %s: a person's name */
			$resendLabel = sprintf( __( 'Resend invitation to %s', 'monstera' ), $name );
			?>
			<li data-roster-row data-member-id="<?php echo (int) $memberId; ?>"<?php echo $isSelf ? ' data-self' : ''; ?><?php echo $i >= 25 ? ' data-more hidden' : ''; ?>
				<?php if ( $manages ) : ?>
					data-tier="<?php echo esc_attr( $tierHeld ); ?>"
					<?php // What this row offers, in the words the roster's route says it in (`can`): the store tells by it a row whose offer has moved since the page was read. ?>
					data-can="<?php echo esc_attr( implode( ' ', array_keys( array_filter( RosterPolicy::rowCan( $offer ) ) ) ) ); ?>"
				<?php endif; ?>
				<?php if ( $acts ) : ?>
					data-name="<?php echo esc_attr( $name ); ?>" data-first="<?php echo esc_attr( $firstName ); ?>"
					data-wp-on--keydown="actions.rosterKeydown"
					<?php if ( $hasTier ) : ?>
						<?php // A tier control that waits on a request does not open to the pointer. ?>
						data-wp-on--mousedown="actions.rosterMousedown"
					<?php endif; ?>
				<?php endif; ?>
				>
				<span class="m-avatar" data-size="md" aria-hidden="true">
					<?php if ( $photoUrl ) : ?>
						<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
					<?php else : ?>
						<?php Icons::emit( 'sprout', 22 ); ?>
					<?php endif; ?>
				</span>
				<span>
					<span class="m-roster__name"><?php echo esc_html( $name ); ?></span>
					<?php if ( $hasTier && $offer['resend'] ) : ?>
						<span class="m-roster__role"><?php echo $roleLine; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above of escaped pieces. ?> · <button type="button" class="m-roster__inline" aria-label="<?php echo esc_attr( $resendLabel ); ?>" data-wp-on--click="actions.resendInvite"><?php esc_html_e( 'Resend invitation', 'monstera' ); ?></button></span>
					<?php elseif ( $roleLine ) : ?>
						<span class="m-roster__role"><?php echo $roleLine; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above of escaped pieces and the span that marks the tier. ?></span>
					<?php endif; ?>
				</span>
				<?php if ( $isSelf ) : ?>
					<?php
					// The store rewrites the mark when a tier it gives or takes
					// makes the viewer the only admin, or no longer the only one.
					$you  = __( 'You', 'monstera' );
					$only = __( 'You · the only admin', 'monstera' );
					$mark = $policy->isOnlyAdmin( $memberId ) ? $only : $you;
					?>
					<?php if ( $manages ) : ?>
						<span class="m-roster__role" data-plain="<?php echo esc_attr( $you ); ?>" data-only="<?php echo esc_attr( $only ); ?>"><?php echo esc_html( $mark ); ?></span>
					<?php else : ?>
						<span class="m-roster__role"><?php echo esc_html( $mark ); ?></span>
					<?php endif; ?>
				<?php elseif ( $acts ) : ?>
					<div class="m-roster__actions">
						<?php if ( $hasTier ) : ?>
							<label class="m-sr-only" for="m-roster-tier-<?php echo (int) $memberId; ?>">
								<?php
								/* translators: %s: a person's name */
								printf( esc_html__( 'Tier for %s', 'monstera' ), esc_html( $name ) );
								?>
							</label>
							<?php // Not for the browser to put back as it was left: a tier chosen and never confirmed would come back as the tier held. ?>
							<select class="m-tier" id="m-roster-tier-<?php echo (int) $memberId; ?>" autocomplete="off" data-wp-on--change="actions.askTier">
								<?php foreach ( RosterPolicy::CONTROL_ORDER as $option ) : ?>
									<?php if ( $option === $tierHeld || in_array( $option, $offer['tiers'], true ) ) : ?>
										<option value="<?php echo esc_attr( $option ); ?>"<?php echo $option === $tierHeld ? ' selected' : ''; ?>><?php echo esc_html( $tierLabels[ $option ] ); ?></option>
									<?php endif; ?>
								<?php endforeach; ?>
							</select>
						<?php elseif ( $offer['resend'] ) : ?>
							<button type="button" class="m-btn" data-intent="ghost" data-size="sm" aria-label="<?php echo esc_attr( $resendLabel ); ?>" data-wp-on--click="actions.resendInvite"><?php esc_html_e( 'Resend', 'monstera' ); ?></button>
						<?php endif; ?>
						<?php if ( $offer['remove'] ) : ?>
							<button type="button" class="m-btn" data-intent="ghost" data-size="sm" aria-label="<?php /* translators: %s: a person's name */ echo esc_attr( sprintf( __( 'Remove %s', 'monstera' ), $name ) ); ?>" aria-expanded="false" aria-controls="m-roster-confirm-<?php echo (int) $memberId; ?>" data-wp-on--click="actions.confirmRemove"><?php esc_html_e( 'Remove', 'monstera' ); ?></button>
						<?php endif; ?>
					</div>
					<?php if ( $hasTier ) : ?>
						<?php // The store fills the question and the action for the tier chosen. ?>
						<div class="m-roster__confirm" role="group" aria-label="<?php esc_attr_e( 'Confirm tier change', 'monstera' ); ?>" hidden data-tier-confirm>
							<span id="m-roster-tier-<?php echo (int) $memberId; ?>-ask"></span>
							<span class="m-roster__confirm-actions">
								<button type="button" class="m-btn" data-intent="secondary" data-size="sm" data-keep data-wp-on--click="actions.keepRosterRow"><?php esc_html_e( 'Keep', 'monstera' ); ?></button>
								<button type="button" class="m-btn" data-intent="primary" data-size="sm" data-wp-on--click="actions.changeTier"></button>
							</span>
						</div>
					<?php endif; ?>
					<?php if ( $offer['remove'] ) : ?>
						<div class="m-roster__confirm" id="m-roster-confirm-<?php echo (int) $memberId; ?>" role="group" aria-label="<?php esc_attr_e( 'Confirm removal', 'monstera' ); ?>" hidden>
							<span>
								<?php
								if ( $signedIn ) {
									/* translators: 1: the member's first name, 2: the organization's name */
									printf( esc_html__( 'Remove %1$s from %2$s? They lose access right away.', 'monstera' ), esc_html( $firstName ), esc_html( $orgName ) );
								} else {
									/* translators: 1: the invited person's first name, 2: the organization's name */
									printf( esc_html__( 'Remove %1$s from %2$s? The invitation link stops working.', 'monstera' ), esc_html( $firstName ), esc_html( $orgName ) );
								}
								?>
							</span>
							<span class="m-roster__confirm-actions">
								<button type="button" class="m-btn" data-intent="secondary" data-size="sm" data-keep data-wp-on--click="actions.keepRosterRow"><?php esc_html_e( 'Keep', 'monstera' ); ?></button>
								<button type="button" class="m-btn" data-intent="primary" data-size="sm" data-wp-on--click="actions.removeMember">
									<?php
									/* translators: %s: the member's first name */
									printf( esc_html__( 'Remove %s', 'monstera' ), esc_html( $firstName ) );
									?>
								</button>
							</span>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( $rosterMore ) : ?>
		<p class="m-list__more">
			<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-wp-on--click="actions.revealMore">
				<?php
				/* translators: %d: number of rows still hidden */
				printf( esc_html( _n( 'Show %d more →', 'Show %d more →', $rosterMore, 'monstera' ) ), (int) $rosterMore );
				?>
			</button>
		</p>
	<?php endif; ?>
</section>
