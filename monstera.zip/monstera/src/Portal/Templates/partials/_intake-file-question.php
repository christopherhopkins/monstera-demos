<?php
/**
 * A discovery file question (comp 97): the label, the drop zone with its
 * Choose files button over a native multiple file input and the limits in
 * words, then the files already sent as rows. The rows are rendered here so
 * the list is complete before any script runs; the portal store uploads
 * what is chosen or dropped and adds rows as uploads finish.
 *
 * The input has no name, so the form's own submit never carries files, and
 * never `required`, since a file already sent is not in it: the store checks
 * a required question on submit.
 *
 * Included in the caller's scope, one question per include.
 *
 * @var array{key: string, label: string, required?: bool, help?: string} $field
 * @var list<array<string, mixed>> $questionFiles  This question's files, oldest first.
 * @var bool                       $canChangeFiles The reader may add and remove files now.
 * @var string                     $fileAccess     Downloader::ACCESS_* for the reader.
 * @var \WP_User                   $user
 */

declare(strict_types=1);

use Monstera\Projects\IntakeFiles;

$qKey          = (string) $field['key'];
$qId           = 'intake-' . sanitize_html_class( $qKey );
$qRequired     = ! empty( $field['required'] );
$fileRemovable = $canChangeFiles;
$fileClosed    = false;
?>
<div class="m-field m-fileq" data-fileq="<?php echo esc_attr( $qKey ); ?>" data-label="<?php echo esc_attr( $field['label'] ); ?>"<?php echo $qRequired ? ' data-required' : ''; ?>>
	<span class="m-field__label" id="<?php echo esc_attr( $qId ); ?>-label"><?php echo esc_html( $field['label'] ); ?><?php echo $qRequired ? '<span class="m-req" aria-hidden="true">*</span>' : ''; ?></span>
	<?php if ( $qRequired ) : ?>
		<?php // The input cannot carry `required` (see above), so its name says it. ?>
		<span class="m-sr-only" id="<?php echo esc_attr( $qId ); ?>-req"><?php esc_html_e( '(required)', 'monstera' ); ?></span>
	<?php endif; ?>
	<?php if ( $canChangeFiles ) : ?>
		<div class="m-filepick" data-drop data-wp-on--dragenter="actions.intakeDragOver" data-wp-on--dragover="actions.intakeDragOver" data-wp-on--dragleave="actions.intakeDragLeave" data-wp-on--drop="actions.intakeDrop">
			<span><?php esc_html_e( 'Drop files here or', 'monstera' ); ?></span>
			<span class="m-btn m-filepick__choose" data-intent="ghost" data-size="sm">
				<span id="<?php echo esc_attr( $qId ); ?>-choose"><?php esc_html_e( 'Choose files', 'monstera' ); ?></span>
				<input type="file" multiple class="m-filepick__input" id="<?php echo esc_attr( $qId ); ?>" accept="<?php echo esc_attr( IntakeFiles::accept() ); ?>" aria-labelledby="<?php echo esc_attr( $qId ); ?>-choose <?php echo esc_attr( $qId ); ?>-label<?php echo $qRequired ? ' ' . esc_attr( $qId ) . '-req' : ''; ?>" aria-describedby="<?php echo esc_attr( $qId ); ?>-limits" data-wp-on--change="actions.intakeChoose" />
			</span>
			<span class="m-filepick__limits" id="<?php echo esc_attr( $qId ); ?>-limits"><?php echo esc_html( IntakeFiles::limitsLine() ); ?></span>
		</div>
	<?php endif; ?>
	<?php if ( ! empty( $field['help'] ) ) : ?>
		<span class="m-field__hint"><?php echo esc_html( $field['help'] ); ?></span>
	<?php endif; ?>
	<ul class="m-files" aria-labelledby="<?php echo esc_attr( $qId ); ?>-label" data-wp-on--click="actions.intakeListClick"<?php echo $questionFiles ? '' : ' hidden'; ?>>
		<?php
		foreach ( $questionFiles as $intakeFile ) {
			require __DIR__ . '/_intake-file-row.php';
		}
		?>
	</ul>
	<span class="m-field__error" id="<?php echo esc_attr( $qId ); ?>-error" hidden></span>
</div>
