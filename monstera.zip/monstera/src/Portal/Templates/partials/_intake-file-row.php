<?php
/**
 * One intake file (comp 97's .m-files__row): a kind tag, the name over its
 * size and who sent it when, and one action. In the discovery form the name
 * is the signed download and the action is Remove; once discovery is over
 * the name is plain and the action is Download. A suspended organization's
 * member reads "Download paused" instead of a link.
 *
 * Included in the caller's scope, one row per include.
 *
 * @var array{id: int, name: string, size: int, uploaded_by: string, uploaded_at: string} $intakeFile
 * @var string   $fileAccess    Downloader::ACCESS_YES, ACCESS_PAUSED or ACCESS_NO.
 * @var bool     $fileRemovable The reader may remove it (the form, while discovery is open).
 * @var bool     $fileClosed    Discovery is over: the read-only list.
 * @var \WP_User $user
 */

declare(strict_types=1);

use Monstera\Content\Downloader;
use Monstera\Projects\IntakeFiles;

defined( 'ABSPATH' ) || exit;

$rowName    = (string) $intakeFile['name'];
$rowKind    = substr( strtolower( (string) pathinfo( $rowName, PATHINFO_EXTENSION ) ), 0, 4 ) ?: __( 'file', 'monstera' );
$rowFetch   = Downloader::ACCESS_YES === $fileAccess;
$rowPaused  = Downloader::ACCESS_PAUSED === $fileAccess;
$rowHref    = $rowFetch ? Downloader::signedUrl( (int) $intakeFile['id'], (int) $user->ID ) : '';
$rowWho     = IntakeFiles::sentBy( $intakeFile );
$rowPauseIc = '<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg>';
?>
<li class="m-files__row" data-file-id="<?php echo (int) $intakeFile['id']; ?>">
	<span class="m-files__kind" aria-hidden="true"><?php echo esc_html( $rowKind ); ?></span>
	<?php if ( $rowFetch && ! $fileClosed ) : ?>
		<a class="m-files__name" href="<?php echo esc_url( $rowHref ); ?>" download><?php echo esc_html( $rowName ); ?></a>
	<?php else : ?>
		<span class="m-files__name"><?php echo esc_html( $rowName ); ?></span>
	<?php endif; ?>
	<span class="m-files__meta">
		<span><?php echo esc_html( size_format( (int) $intakeFile['size'] ) ); ?></span>
		<?php if ( $rowWho ) : ?>
			<span><?php echo esc_html( $rowWho ); ?></span>
		<?php endif; ?>
		<?php if ( $rowPaused && ! $fileClosed ) : ?>
			<span class="m-paused"><?php echo $rowPauseIc; // phpcs:ignore WordPress.Security.EscapeOutput -- a literal icon. ?><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
		<?php endif; ?>
	</span>
	<?php if ( $fileClosed ) : ?>
		<?php if ( $rowFetch ) : ?>
			<a class="m-btn m-files__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $rowHref ); ?>" download aria-label="<?php echo esc_attr( sprintf( /* translators: %s: a file's name */ __( 'Download %s', 'monstera' ), $rowName ) ); ?>"><?php esc_html_e( 'Download →', 'monstera' ); ?></a>
		<?php elseif ( $rowPaused ) : ?>
			<span class="m-paused m-files__action"><?php echo $rowPauseIc; // phpcs:ignore WordPress.Security.EscapeOutput -- a literal icon. ?><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
		<?php endif; ?>
	<?php elseif ( $fileRemovable ) : ?>
		<button type="button" class="m-btn m-files__action" data-intent="ghost" data-size="sm" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: a file's name */ __( 'Remove %s', 'monstera' ), $rowName ) ); ?>" data-action="remove"><?php esc_html_e( 'Remove', 'monstera' ); ?></button>
	<?php endif; ?>
</li>
