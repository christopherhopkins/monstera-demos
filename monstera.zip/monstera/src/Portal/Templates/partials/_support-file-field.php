<?php
/**
 * A support form's file field (comps 80 and 86): the portal's picker in
 * the mode that holds what is chosen until the form is sent (`data-hold`).
 * Chosen files show as rows with Remove; nothing is uploaded before the
 * send, so a message and its files arrive together or not at all. The form
 * carries the limits and the words (SupportView::fileFormAttributes()).
 *
 * @var string $supportFieldId The file input's id; the field's other ids are built on it.
 */

declare(strict_types=1);

use Monstera\Content\SecureFiles;
use Monstera\Support\Files;

defined( 'ABSPATH' ) || exit;
?>
<div class="m-field m-fileq" data-hold data-fileq="files">
	<span class="m-field__label" id="<?php echo esc_attr( $supportFieldId ); ?>-label"><?php esc_html_e( 'Screenshots or files (optional)', 'monstera' ); ?></span>
	<div class="m-filepick" data-drop data-wp-on--dragenter="actions.filesDragOver" data-wp-on--dragover="actions.filesDragOver" data-wp-on--dragleave="actions.filesDragLeave" data-wp-on--drop="actions.filesDrop">
		<span><?php esc_html_e( 'Drop files here or', 'monstera' ); ?></span>
		<span class="m-btn m-filepick__choose" data-intent="ghost" data-size="sm">
			<span id="<?php echo esc_attr( $supportFieldId ); ?>-choose"><?php esc_html_e( 'Choose files', 'monstera' ); ?></span>
			<input type="file" multiple class="m-filepick__input" id="<?php echo esc_attr( $supportFieldId ); ?>" accept="<?php echo esc_attr( SecureFiles::accept() ); ?>" aria-labelledby="<?php echo esc_attr( $supportFieldId ); ?>-choose <?php echo esc_attr( $supportFieldId ); ?>-label" aria-describedby="<?php echo esc_attr( $supportFieldId ); ?>-limits" data-wp-on--change="actions.filesChoose" />
		</span>
		<span class="m-filepick__limits" id="<?php echo esc_attr( $supportFieldId ); ?>-limits"><?php echo esc_html( Files::limitsLine() ); ?></span>
	</div>
	<ul class="m-files" aria-labelledby="<?php echo esc_attr( $supportFieldId ); ?>-label" data-wp-on--click="actions.filesListClick" hidden></ul>
	<span class="m-field__error" id="<?php echo esc_attr( $supportFieldId ); ?>-error" hidden></span>
</div>
