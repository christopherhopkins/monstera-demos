<?php
/**
 * Portal shell — closing markup.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

?>
	</main>

	<footer class="monstera-portal__footer" role="contentinfo">
		<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		<span><a href="mailto:<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"><?php esc_html_e( 'Support', 'monstera' ); ?></a></span>
		<span><a href="<?php echo esc_url( \Monstera\Core\Routing::url( \Monstera\Core\Routing::ROUTE_ACCESSIBILITY ) ); ?>"><?php esc_html_e( 'Accessibility', 'monstera' ); ?></a></span>
	</footer>

	<?php wp_footer(); ?>
</body>
</html>
