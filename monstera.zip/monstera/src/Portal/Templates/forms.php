<?php
/**
 * Forms (comp 130): what the reader is asked to fill in, in three groups
 * (Forms-and-resources track, FR5). Due: a form with a due day ahead they
 * have not sent, soonest first. Open: the rest that accept, an embedded
 * form among them. Sent: a once-only form they have sent, and a closed
 * form they sent at least once. A row carries the title, the sub-line, the
 * day and one action (partials/_form-row.php, shared with the org hub's
 * Forms tab). Forms\Repository::grouped() has the rule.
 *
 * For a person in several organizations a row says first on its meta line
 * which organization the form reaches them through, as the Resources page's
 * rows do, and what only an organization whose membership has ended asks is
 * left out beside one still running, one line above the lists saying whose
 * forms are waiting. A standalone member whose own membership has ended has
 * every form held back, and the line says they wait on it. A suspended
 * organization's forms are listed and offered as any other's (Forms\Standing
 * says why): the shell's block above says the organization is suspended.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\Repository as FormsRepository;
use Monstera\Forms\Standing;
use Monstera\Portal\Audience;
use Monstera\Portal\DocumentTitle;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::FORMS ) ) {
	DocumentTitle::refused( __( 'Not enabled', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Forms are not enabled on this site.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'Forms are currently disabled in Settings.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user    = $ctx['user'];
$grouped = ( new FormsRepository() )->grouped( $user );
$groups  = $grouped['groups'];
$through = $grouped['through'];
$listed  = array_sum( array_map( 'count', $groups ) );

// The ended organizations whose forms were left out, by name; a standalone
// member whose own membership has ended waits on it.
$waitingNames = array_values( array_filter( array_map( static fn ( int $id ): string => (string) get_the_title( $id ), $grouped['waiting'] ) ) );
$ownWaiting   = PortalGuard::ownMembershipExpired( $user );

// One section per group that has rows: the heading, the count, the rows.
$formList = static function ( string $id, string $heading, array $entries ) use ( $through ): void {
	?>
	<section class="m-section" aria-labelledby="<?php echo esc_attr( $id ); ?>">
		<div class="m-section__head">
			<h2 id="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $heading ); ?></h2>
			<span class="m-section__link m-mono">
				<?php
				/* translators: %d: number of forms */
				printf( esc_html( _n( '%d form', '%d forms', count( $entries ), 'monstera' ) ), (int) count( $entries ) );
				?>
			</span>
		</div>
		<ul class="m-list">
			<?php
			foreach ( $entries as [ $form, $formStanding ] ) {
				$formOrgId = $through[ (int) $form->ID ] ?? 0;
				$formOrg   = $formOrgId > 0 ? (string) get_the_title( $formOrgId ) : '';
				require __DIR__ . '/partials/_form-row.php';
			}
			?>
		</ul>
	</section>
	<?php
};
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Forms', 'monstera' ); ?></h1>
	<p>
		<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
			<?php
			/* translators: %s: the site name */
			echo esc_html( sprintf( __( 'What %s asks you to fill in. Your answers stay on each form\'s page for you.', 'monstera' ), Audience::siteName() ) );
			?>
		<?php elseif ( Audience::isMultiOrg( (int) $user->ID ) ) : ?>
			<?php
			/* translators: %s: the site name */
			echo esc_html( sprintf( __( 'What your organizations and %s ask you to fill in. Your answers stay on each form\'s page for you.', 'monstera' ), Audience::siteName() ) );
			?>
		<?php else : ?>
			<?php
			/* translators: %s: the site name */
			echo esc_html( sprintf( __( 'What your organization and %s ask you to fill in. Your answers stay on each form\'s page for you.', 'monstera' ), Audience::siteName() ) );
			?>
		<?php endif; ?>
	</p>
</section>

<div class="monstera-portal__dash">
	<?php if ( 0 === $listed && ! $waitingNames && ! $ownWaiting ) : ?>
		<div class="m-empty">
			<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
			<p class="m-empty__message">
				<?php
				/* translators: %s: the site name */
				echo esc_html( sprintf( __( 'No forms yet. Anything %s asks you to fill in will land here.', 'monstera' ), Audience::siteName() ) );
				?>
			</p>
		</div>
	<?php else : ?>
		<?php
		if ( $waitingNames ) {
			?>
			<p class="m-paused">
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg>
				<?php
				printf(
					esc_html(
						/* translators: %s: the name of an organization whose membership has ended, or several separated by commas */
						_n(
							'Forms from %s are kept safe and come back the moment its membership is renewed.',
							'Forms from %s are kept safe and come back the moment each membership is renewed.',
							count( $waitingNames ),
							'monstera'
						)
					),
					/* translators: used between list items; there is a space after the comma */
					esc_html( implode( __( ', ', 'monstera' ), $waitingNames ) )
				);
				?>
			</p>
			<?php
		}
		if ( $ownWaiting ) {
			?>
			<p class="m-paused">
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg>
				<?php esc_html_e( 'Forms are kept safe and come back the moment your membership is renewed.', 'monstera' ); ?>
			</p>
			<?php
		}
		if ( $groups[ Standing::GROUP_DUE ] ) {
			$formList( 'fl-due', __( 'Due', 'monstera' ), $groups[ Standing::GROUP_DUE ] );
		}
		if ( $groups[ Standing::GROUP_OPEN ] ) {
			$formList( 'fl-open', __( 'Open', 'monstera' ), $groups[ Standing::GROUP_OPEN ] );
		}
		if ( $groups[ Standing::GROUP_SENT ] ) {
			$formList( 'fl-sent', __( 'Sent', 'monstera' ), $groups[ Standing::GROUP_SENT ] );
		}
		?>
	<?php endif; ?>
</div>
