<?php
/**
 * Resources (forms library; comp 82): two plain lists, the resources shared
 * with the reader's organization and the ones the site shares with
 * everyone. Each row names its kind (PDF, Link, Form), carries the
 * description or the file facts on the meta line and offers one action.
 * Forms that render inline (shortcode forms) follow the lists.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\Meta as FormsMeta;
use Monstera\Forms\Repository as FormsRepository;
use Monstera\Members\UserMeta;
use Monstera\Portal\Audience;

if ( ! Modules::isActive( Modules::FORMS ) ) {
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Resources are not enabled on this site.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'The Forms / Resources library is currently disabled in Settings.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user    = $ctx['user'];
$repo    = new FormsRepository();
$items   = $repo->visibleTo( $user );
$userOrg = UserMeta::associatedOrg( $user->ID );
$orgName = $userOrg ? (string) get_the_title( $userOrg ) : '';

// Resources aimed at an audience (an organization or named members) come
// from the reader's organization; the rest the site shares with everyone.
$fromOrg  = [];
$fromSite = [];
$embedded = [];
foreach ( $items as $form ) {
	$orgs    = array_filter( (array) get_post_meta( $form->ID, FormsMeta::KEY_ORGS, true ) );
	$members = array_filter( (array) get_post_meta( $form->ID, FormsMeta::KEY_STANDALONE_MEMBERS, true ) );
	if ( $orgName && ( $orgs || $members ) ) {
		$fromOrg[] = $form;
	} else {
		$fromSite[] = $form;
	}
	if ( FormsMeta::TYPE_SHORTCODE === (string) get_post_meta( $form->ID, FormsMeta::KEY_FORM_TYPE, true ) ) {
		$embedded[] = $form;
	}
}

// One row per resource: partials/_resource-row.php, shared with the org hub's
// Resources tab so both surfaces read the same.
$resourceList = static function ( string $id, string $heading, array $forms ): void {
	?>
	<section class="m-section" aria-labelledby="<?php echo esc_attr( $id ); ?>">
		<div class="m-section__head">
			<h2 id="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $heading ); ?></h2>
			<span class="m-section__link m-mono">
				<?php
				/* translators: %d: number of resources */
				printf( esc_html( _n( '%d resource', '%d resources', count( $forms ), 'monstera' ) ), (int) count( $forms ) );
				?>
			</span>
		</div>
		<ul class="m-list">
			<?php
			foreach ( $forms as $form ) {
				require __DIR__ . '/partials/_resource-row.php';
			}
			?>
		</ul>
	</section>
	<?php
};
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Resources', 'monstera' ); ?></h1>
	<p>
		<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
			<?php esc_html_e( 'Forms, downloads, and links available to you.', 'monstera' ); ?>
		<?php else : ?>
			<?php esc_html_e( 'Forms, downloads, and links your organization makes available.', 'monstera' ); ?>
		<?php endif; ?>
	</p>
</section>

<div class="monstera-portal__dash">
	<?php if ( ! $items ) : ?>
		<div class="m-empty">
			<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
			<p class="m-empty__message">
				<?php
				/* translators: %s: the site name */
				echo esc_html( sprintf( __( 'No resources yet. Anything %s publishes will land here.', 'monstera' ), Audience::siteName() ) );
				?>
			</p>
		</div>
	<?php else : ?>
		<?php
		if ( $fromOrg ) {
			/* translators: %s: the reader's organization */
			$resourceList( 'm-resources-org', sprintf( __( 'From %s', 'monstera' ), $orgName ), $fromOrg );
		}
		if ( $fromSite ) {
			/* translators: %s: the site name */
			$resourceList( 'm-resources-site', sprintf( __( 'From %s', 'monstera' ), Audience::siteName() ), $fromSite );
		}
		?>

		<?php if ( $embedded ) : ?>
			<section class="m-section" aria-labelledby="m-resources-embedded">
				<div class="m-section__head">
					<h2 id="m-resources-embedded"><?php esc_html_e( 'Forms to fill in', 'monstera' ); ?></h2>
				</div>
				<?php foreach ( $embedded as $form ) : ?>
					<article class="m-form" data-card id="m-form-<?php echo (int) $form->ID; ?>">
						<h3><?php echo esc_html( get_the_title( $form ) ); ?></h3>
						<?php echo $repo->renderAction( $form ); // phpcs:ignore WordPress.Security.EscapeOutput -- renderAction() escapes every value it interpolates. ?>
					</article>
				<?php endforeach; ?>
			</section>
		<?php endif; ?>
	<?php endif; ?>
</div>
