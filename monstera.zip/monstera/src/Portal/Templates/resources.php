<?php
/**
 * Resources (comp 82): two plain lists, the resources shared with the
 * reader's organization (any of their organizations, for a person in
 * several; People-model track, FR5) and the ones the site shares with
 * everyone. Each row names its kind (Link, File, Guide), carries the
 * description or the file facts on the meta line and offers one action
 * (Forms-and-resources track, FR4; the forms library until 2026-10-26).
 *
 * For a person in several organizations the first list is the union of what
 * reaches any of them, each resource once, and a row says first on its meta
 * line which organization it reaches them through, as the dashboard's rows
 * do (comp 23); Organizations\Reach picks it, never the resource's own first
 * organization. A row of the second list says it too when the resource is
 * narrowed to one organization's sub-group: it names no organization, so it
 * sits where it always has, and it is that organization's all the same
 * (Forms\Repository::besideEach()). What only an organization whose
 * membership has ended shares is left out beside one still running, and one
 * line above the lists says whose resources are waiting, as the projects
 * list says it; a suspended organization's stay, and its PDF waits where no
 * live organization shares it (partials/_resource-row.php). With one
 * organization the page is what it always was, to the byte. A standalone
 * member whose own membership has ended has every resource held back, and
 * the line says they wait on it.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Resources\Meta as ResourcesMeta;
use Monstera\Resources\Repository as ResourcesRepository;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Portal\DocumentTitle;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::RESOURCES ) ) {
	DocumentTitle::refused( __( 'Not enabled', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Resources are not enabled on this site.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'The Resources library is currently disabled in Settings.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

// An organization in the trash grants nothing, so the page never names it.
$user     = $ctx['user'];
$repo     = new ResourcesRepository();
$userOrgs = OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
$several  = Audience::isMultiOrg( (int) $user->ID );
if ( $several ) {
	// The rows and the line above them name these organizations and ask
	// where each stands: one read for all of them, however many.
	_prime_post_caches( $userOrgs, false, true );
}
[ $items, $waitingOrgs ] = $repo->listedFor( $user );
$orgName                 = $userOrgs ? (string) get_the_title( $userOrgs[0] ) : '';
// A standalone member whose own membership has ended has every resource
// held back (Forms\Repository::listedFor()) and no organization to name, so
// the page says the resources wait on their membership.
$ownWaiting = PortalGuard::ownMembershipExpired( $user );

// Resources aimed at an audience (an organization or named members) reached
// the reader through one of their organizations, so they are grouped as
// the organizations'; the rest the site shares with everyone.
$fromOrg  = [];
$fromSite = [];
foreach ( $items as $resource ) {
	$orgs    = array_filter( (array) get_post_meta( $resource->ID, ResourcesMeta::KEY_ORGS, true ) );
	$members = array_filter( (array) get_post_meta( $resource->ID, ResourcesMeta::KEY_STANDALONE_MEMBERS, true ) );
	if ( $userOrgs && ( $orgs || $members ) ) {
		$fromOrg[] = $resource;
	} else {
		$fromSite[] = $resource;
	}
}

// What a row of a person in several organizations says beside the resource:
// the organization it reaches them through, and whether its file waits. The
// repository that listed the resources says both, by the reading of "reaches
// them through" that the list was drawn up with, so a row cannot name an
// organization the list held back or pause a file for the wrong one. It is
// asked about every row, the site's list included: a resource narrowed to one
// organization's sub-group sits there, is that organization's all the same,
// and its file waits with it. Nothing is said of a person in one.
$beside = $repo->besideEach( $user, $items );

// The ended organizations whose resources were left out, by name.
$waitingNames = array_values( array_filter( array_map( static fn ( int $id ): string => (string) get_the_title( $id ), $waitingOrgs ) ) );

// One row per resource: partials/_resource-row.php, shared with the org hub's
// Resources tab so both surfaces read the same. The row is told its
// organization and whether its file waits, one row at a time.
$resourceList = static function ( string $id, string $heading, array $resources ) use ( $beside ): void {
	?>
	<section class="m-section" aria-labelledby="<?php echo esc_attr( $id ); ?>">
		<div class="m-section__head">
			<h2 id="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $heading ); ?></h2>
			<span class="m-section__link m-mono">
				<?php
				/* translators: %d: number of resources */
				printf( esc_html( _n( '%d resource', '%d resources', count( $resources ), 'monstera' ) ), (int) count( $resources ) );
				?>
			</span>
		</div>
		<ul class="m-list">
			<?php
			foreach ( $resources as $resource ) {
				$said         = $beside[ (int) $resource->ID ] ?? null;
				$resourceOrg  = $said && $said['org'] > 0 ? (string) get_the_title( $said['org'] ) : '';
				$resourceWait = $said && $said['waits'];
				require __DIR__ . '/partials/_resource-row.php';
			}
			?>
		</ul>
	</section>
	<?php
};
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Resources', 'monstera' ); ?></h1>
	<p>
		<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
			<?php esc_html_e( 'Guides, downloads, and links available to you.', 'monstera' ); ?>
		<?php elseif ( $several ) : ?>
			<?php esc_html_e( 'Guides, downloads, and links your organizations make available.', 'monstera' ); ?>
		<?php else : ?>
			<?php esc_html_e( 'Guides, downloads, and links your organization makes available.', 'monstera' ); ?>
		<?php endif; ?>
	</p>
</section>

<div class="monstera-portal__dash">
	<?php
	// With resources held back by an ended membership the page is not empty:
	// it says whose they are instead. (The note is inside this tag, and the
	// line that names them inside the next one, so that a page with nothing
	// held back prints what it always printed, to the byte.)
	if ( ! $items && ! $waitingNames && ! $ownWaiting ) :
		?>
		<div class="m-empty">
			<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
			<p class="m-empty__message">
				<?php
				/* translators: %s: the site name */
				echo esc_html( sprintf( __( 'No resources yet. Anything %s publishes will land here.', 'monstera' ), Audience::siteName() ) );
				?>
			</p>
		</div>
	<?php else : ?>
		<?php
		if ( $waitingNames ) {
			?>
			<p class="m-paused">
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg>
				<?php
				printf(
					esc_html(
						/* translators: %s: the name of an organization whose membership has ended, or several separated by commas */
						_n(
							'Resources from %s are kept safe and come back the moment its membership is renewed.',
							'Resources from %s are kept safe and come back the moment each membership is renewed.',
							count( $waitingNames ),
							'monstera'
						)
					),
					/* translators: used between list items; there is a space after the comma */
					esc_html( implode( __( ', ', 'monstera' ), $waitingNames ) )
				);
				?>
			</p>
			<?php
		}
		if ( $ownWaiting ) {
			?>
			<p class="m-paused">
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg>
				<?php esc_html_e( 'Resources are kept safe and come back the moment your membership is renewed.', 'monstera' ); ?>
			</p>
			<?php
		}
		if ( $fromOrg ) {
			$resourceList(
				'm-resources-org',
				/* translators: %s: the reader's organization */
				$several ? __( 'From your organizations', 'monstera' ) : sprintf( __( 'From %s', 'monstera' ), $orgName ),
				$fromOrg
			);
		}
		if ( $fromSite ) {
			/* translators: %s: the site name */
			$resourceList( 'm-resources-site', sprintf( __( 'From %s', 'monstera' ), Audience::siteName() ), $fromSite );
		}
		?>
	<?php endif; ?>
</div>
