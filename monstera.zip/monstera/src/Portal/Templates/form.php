<?php
/**
 * A form at /portal/forms/{id}/ (comp 131; Forms-and-resources track, FR5).
 *
 *  - Breadcrumb (Forms, the form), then the head: where the form stands for
 *    the reader as kickers (Due <day>, Sent <day> with "One answer per
 *    member", Closed <day>), the organization it reaches them through, the
 *    title and the intro
 *  - After a send (`?sent=`), the confirmation band with the form's own
 *    words, said once in the page's status line (callbacks.flash)
 *  - A built form that accepts: the questions in order as the portal's
 *    fields (partials/_form-question.php), the file picker holding its
 *    files until the send, Send, and beside it the line a send that did
 *    not go is said in; the store sends it all in one request to the
 *    route (actions.submitForm) and, without a script, the form posts to
 *    this page and the router answers the same way (Portal\FormSend)
 *  - A once-only form they have sent: their answers, read-only
 *  - A form that takes nothing now (closed, its due day passed): its
 *    closed message in place of Send, the author's own words or the
 *    default
 *  - Your submissions: each send of theirs, newest first, with its answers
 *    and signed file links behind Show answers
 *  - An embedded form: the other plugin's form under the intro, nothing
 *    else, since Monstera does not see its submissions
 *  - In the rail, the form's facts and a way to ask about it
 *
 * The form must be one the library lists for the reader
 * (Forms\Repository::openable()): a draft, one out of reach and no form at
 * all answer the blocked pattern, with the 404 the router sent before the
 * shell began.
 *
 * @var array<string, mixed> $ctx `send` carries a script-less send that did not go: its complaints by question key and what was typed.
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\Accepts;
use Monstera\Forms\Answers;
use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\Repository as FormsRepository;
use Monstera\Forms\Submissions;
use Monstera\Portal\Audience;
use Monstera\Portal\Body;
use Monstera\Portal\CalendarDay;
use Monstera\Portal\Context;
use Monstera\Portal\DocumentTitle;
use Monstera\Portal\FormSend;
use Monstera\Portal\SupportPages;
use Monstera\Portal\SupportView;
use Monstera\Support\Files as SupportFiles;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::FORMS ) ) {
	DocumentTitle::refused( __( 'Not enabled', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Forms are not enabled on this site.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'Forms are currently disabled in Settings.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user   = $ctx['user'];
$formId = (int) get_query_var( Routing::PARAM_ID );
$form   = $ctx['form'] ?? null;
if ( ! $form instanceof \WP_Post || (int) $form->ID !== $formId ) {
	$form = ( new FormsRepository() )->openable( $user, $formId );
}

if ( ! $form ) {
	// The blocked pattern, with a 404 that says nothing of what is there. On
	// a request the router sent the status before the shell began; this
	// call finds the headers gone, and is what a test rendering the template
	// alone sees.
	status_header( 404 );
	DocumentTitle::refused( __( 'Not available', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not available', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'This form is not available to you.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( 'It may have been removed, or your access changed. %s if this seems wrong.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It may have been removed, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_FORMS ) ); ?>"><?php esc_html_e( 'Back to Forms', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

DocumentTitle::name( get_the_title( $form ), __( 'Forms', 'monstera' ) );

$isEmbed     = FormMeta::KIND_EMBED === FormMeta::kindOf( $formId );
$description = trim( wp_strip_all_tags( (string) get_post_meta( $formId, FormMeta::KEY_DESCRIPTION, true ) ) );
$dueOn       = FormMeta::dueOn( $formId );
$onceOnly    = FormMeta::onceOnly( $formId );
$mine        = $isEmbed ? [] : Submissions::mine( $formId, (int) $user->ID );
// The form reaches them (openable() said so): the send's reason is the
// rest of the rule, read without a second pass over the library.
$accept      = $isEmbed ? Accepts::NOT_REACHED : Accepts::reasonFor( $formId, [] !== $mine );
$fields      = $isEmbed ? [] : FormMeta::fieldsOf( $formId );
$removedKeys = $isEmbed ? [] : Submissions::removedKeys( $formId, $mine );
// Each send's files, read together once for the rows and their answers
// alike (Forms-and-resources track, NFR Query cost).
$filesByRow = Submissions::filesOfMany( array_map( static fn ( array $row ): int => (int) $row['id'], $mine ) );
$sentId     = isset( $_GET['sent'] ) ? (int) $_GET['sent'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only: which of their own sends the page says went.
$justSent   = null;
foreach ( $mine as $row ) {
	if ( (int) $row['id'] === $sentId ) {
		$justSent = $row;
		break;
	}
}
$send       = is_array( $ctx['send'] ?? null ) ? $ctx['send'] : [];
$sendErrors = (array) ( $send['errors'] ?? [] );
$values     = (array) ( $send['values'] ?? [] );
$closed     = in_array( $accept, [ Accepts::CLOSED, Accepts::DUE_PASSED ], true );
$readOnly   = Accepts::ALREADY_SENT === $accept;
$opens      = Accepts::OK === $accept;

// The organization this page is about for this reader (Portal\Context):
// the one its row names, or none for a form for everyone.
$contextOrgId   = Context::orgFor( $user, Routing::ROUTE_FORM );
$contextOrgName = $contextOrgId ? (string) get_the_title( $contextOrgId ) : '';

// The day a closed form closed, when its due day is what closed it.
$closedOn = Accepts::DUE_PASSED === $accept ? $dueOn : '';

// One submission's answers as stats (partials/_submission-answers.php),
// and one line for a row (Forms\Answers): shared with Manage › Submissions.
$answersBlock = static function ( array $row ) use ( $fields, $removedKeys, $filesByRow, $user ): void {
	$vars = [
		'row'         => $row,
		'fields'      => $fields,
		'removedKeys' => $removedKeys,
		'files'       => $filesByRow[ (int) $row['id'] ] ?? [],
		'user'        => $user,
		'idPrefix'    => 'fm-sub-' . (int) $row['id'],
	];
	( static function ( array $vars ): void {
		extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- the partial's named variables, scoped to this closure.
		require __DIR__ . '/partials/_submission-answers.php';
	} )( $vars );
};
$summaryOf    = static fn ( array $row ): string => Answers::summary( $fields, $row, $filesByRow[ (int) $row['id'] ] ?? [] );
?>
<div class="monstera-portal__dash">

	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_FORMS ) ); ?>"><?php esc_html_e( 'Forms', 'monstera' ); ?></a>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo esc_html( get_the_title( $form ) ); ?></span>
	</nav>

	<header class="m-project-head">
		<div class="m-project-head__kickers">
			<?php if ( $readOnly ) : ?>
				<span class="m-badge" data-tone="success"><?php /* translators: %s: a date, e.g. "Mar 4" */ echo esc_html( sprintf( __( 'Sent %s', 'monstera' ), wp_date( 'M j', (int) strtotime( $mine[0]['submitted_at'] . ' UTC' ) ) ) ); ?></span>
			<?php elseif ( $closed ) : ?>
				<span class="m-badge" data-tone="neutral"><?php '' !== $closedOn ? printf( /* translators: %s: the day a form closed */ esc_html__( 'Closed %s', 'monstera' ), esc_html( CalendarDay::format( $closedOn, 'M j' ) ) ) : esc_html_e( 'Closed', 'monstera' ); ?></span>
			<?php elseif ( '' !== $dueOn && ! $isEmbed ) : ?>
				<span class="m-badge" data-tone="warning"><?php /* translators: %s: a date, e.g. "Mar 4" */ echo esc_html( sprintf( __( 'Due %s', 'monstera' ), CalendarDay::format( $dueOn, 'M j' ) ) ); ?></span>
			<?php endif; ?>
			<?php if ( $onceOnly && ! $isEmbed ) : ?>
				<span class="m-badge" data-tone="neutral"><?php esc_html_e( 'One answer per member', 'monstera' ); ?></span>
			<?php endif; ?>
			<?php if ( $contextOrgName ) : ?>
				<span class="m-badge" data-tone="brand"><?php echo esc_html( $contextOrgName ); ?></span>
			<?php endif; ?>
		</div>
		<h1><?php echo esc_html( get_the_title( $form ) ); ?></h1>
		<?php if ( '' !== $description ) : ?>
			<p class="m-project-head__scope"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( '' !== trim( (string) $form->post_content ) ) : ?>
		<div class="m-prose m-form-intro" data-plain>
			<?php echo Body::html( $form ); // phpcs:ignore WordPress.Security.EscapeOutput -- the_content pipeline output (shortcodes only from the team), the same trust model as a theme template. ?>
		</div>
	<?php endif; ?>

	<?php
	// The band is in the page as it arrives, where a screen reader would not
	// say it: the store says it once, in the status line drawn empty beside
	// it (callbacks.flash), as a request's page says what was just done.
	if ( $justSent ) :
		?>
		<section class="m-confirm" data-wp-init="callbacks.flash">
			<?php Icons::sprig(); ?>
			<?php // The form's own sentence, the one its email says; Meta's default when it has none. ?>
			<h2><?php echo esc_html( wp_strip_all_tags( FormMeta::confirmationOf( $formId ) ) ); ?></h2>
			<p><?php esc_html_e( 'Your answers are kept below.', 'monstera' ); ?>
			</p>
		</section>
	<?php endif; ?>
	<p class="m-sr-only" role="status" aria-live="polite" data-flash-status></p>

	<div class="m-dash">
		<div class="m-dash__main">
			<?php if ( $isEmbed ) : ?>
				<div class="m-form m-form--embed">
					<?php echo do_shortcode( (string) get_post_meta( $formId, FormMeta::KEY_SHORTCODE, true ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the other plugin's form, as a theme would render its shortcode. ?>
				</div>
			<?php elseif ( $readOnly ) : ?>
				<section class="m-section m-answers" aria-labelledby="fm-yours">
					<div class="m-section__head">
						<h2 id="fm-yours"><?php esc_html_e( 'Your answers', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono"><?php /* translators: %s: the day and time the reader sent the form, e.g. "Sep 3, 4:12pm" */ echo esc_html( sprintf( __( 'Sent on %s', 'monstera' ), wp_date( 'M j, g:ia', (int) strtotime( $mine[0]['submitted_at'] . ' UTC' ) ) ) ); ?></span>
					</div>
					<?php $answersBlock( $mine[0] ); ?>
					<p class="m-form__help">
						<?php esc_html_e( 'This form takes one answer per member, so it cannot be sent again.', 'monstera' ); ?>
						<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
							<a href="<?php echo esc_url( SupportPages::newRequestUrl( $user, $contextOrgId ) ); ?>"><?php esc_html_e( 'Ask about it if something needs correcting.', 'monstera' ); ?></a>
						<?php endif; ?>
					</p>
				</section>
			<?php elseif ( $closed ) : ?>
				<div class="m-closed-line">
					<?php Icons::sprig(); ?>
					<p>
						<?php
						// The author's own words, or the default naming the day the
						// due day closed it; Meta's default is for a form closed by hand.
						$closedMessage = trim( wp_strip_all_tags( (string) get_post_meta( $formId, FormMeta::KEY_CLOSED_MESSAGE, true ) ) );
						if ( '' !== $closedMessage ) {
							echo esc_html( $closedMessage );
						} elseif ( '' !== $closedOn ) {
							/* translators: %s: the day a form closed */
							echo esc_html( sprintf( __( 'This form closed on %s.', 'monstera' ), CalendarDay::format( $closedOn, 'M j, Y' ) ) );
						} else {
							esc_html_e( 'This form is closed.', 'monstera' );
						}
						?>
					</p>
					<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( Routing::url( Routing::ROUTE_FORMS ) ); ?>"><?php esc_html_e( 'Back to Forms', 'monstera' ); ?></a>
				</div>
			<?php elseif ( $opens ) : ?>
				<?php
				// The picker's limits and words are a support message's
				// (SupportView), with a form's own limits and the words that
				// name them over the top: a file question takes what a
				// discovery question takes (Submissions::maxBytes(), maxCount()).
				// What one send can carry is a support message's too
				// (Support\Files::maxTotal(), from post_max_size): every
				// question's files go in the one request, and the store
				// weighs them together as each is added and before the send.
				$formAttrs                   = SupportView::fileFormAttributes( __( 'Goes when you send', 'monstera' ) );
				$formAttrs['data-max-bytes'] = (string) Submissions::maxBytes();
				$formAttrs['data-max-count'] = (string) Submissions::maxCount();
				$formAttrs['data-max-total'] = (string) SupportFiles::maxTotal();
				/* translators: %s: the largest file allowed, e.g. "50 MB" */
				$formAttrs['data-msg-file-big'] = sprintf( __( 'That file is over %s.', 'monstera' ), size_format( Submissions::maxBytes() ) );
				/* translators: %d: how many files a question takes */
				$formAttrs['data-msg-file-full']  = sprintf( __( 'A question takes up to %d files.', 'monstera' ), Submissions::maxCount() );
				$formAttrs['data-msg-file-total'] = __( 'Together these files are more than one send can carry. Remove some.', 'monstera' );
				/* translators: %s: a question that needs a file */
				$formAttrs['data-msg-file-required'] = __( 'Add a file to “%s” before you send.', 'monstera' );
				$formAttrs['data-msg-failed']        = __( 'That did not send. Nothing was lost: send again.', 'monstera' );
				$formAttrs['data-msg-fix']           = __( 'Some answers need another look.', 'monstera' );
				?>
				<form
					class="m-form"
					method="post"
					enctype="multipart/form-data"
					novalidate
					action="<?php echo esc_url( Routing::url( Routing::ROUTE_FORM, [ 'id' => $formId ] ) ); ?>"
					data-rest="<?php echo esc_url( Routing::restUrl( 'monstera/v1/forms/' . $formId . '/submissions' ) ); ?>"
					data-wp-on--submit="actions.submitForm"
					aria-labelledby="fm-title"
					<?php foreach ( $formAttrs as $attribute => $value ) : ?>
						<?php echo esc_attr( $attribute ); ?>="<?php echo esc_attr( $value ); ?>"
					<?php endforeach; ?>>
					<?php wp_nonce_field( FormSend::nonceAction( $formId ), FormSend::NONCE_FIELD, false ); ?>
					<h2 id="fm-title"><?php esc_html_e( 'Your answers', 'monstera' ); ?></h2>
					<p class="m-form__help">
						<?php
						/* translators: %d: how many questions the form has */
						echo esc_html( sprintf( _n( '%d question.', '%d questions.', count( $fields ), 'monstera' ), count( $fields ) ) );
						?>
						<?php if ( array_filter( array_column( $fields, 'required' ) ) ) : ?>
							<?php
							printf(
								/* translators: %s: the required mark */
								esc_html__( 'Fields marked %s are required.', 'monstera' ),
								'<span class="m-req" aria-hidden="true">*</span><span class="m-sr-only">' . esc_html__( 'required', 'monstera' ) . '</span>'
							);
							?>
						<?php endif; ?>
					</p>
					<?php if ( '' !== (string) ( $sendErrors['_form'] ?? '' ) ) : ?>
						<p class="m-field__error m-form__error" role="alert"><?php echo esc_html( (string) $sendErrors['_form'] ); ?></p>
					<?php elseif ( $sendErrors ) : ?>
						<p class="m-field__error m-form__error" role="alert"><?php esc_html_e( 'Some answers need another look.', 'monstera' ); ?></p>
					<?php endif; ?>
					<?php
					foreach ( $fields as $question ) {
						$questionValue = (string) ( $values[ (string) $question['key'] ] ?? '' );
						$questionError = (string) ( $sendErrors[ (string) $question['key'] ] ?? '' );
						require __DIR__ . '/partials/_form-question.php';
					}
					?>
					<div class="m-form__actions">
						<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php $mine ? esc_html_e( 'Send again', 'monstera' ) : esc_html_e( 'Send', 'monstera' ); ?></button>
						<?php // A send that did not go is said beside Send. The line is on the page from the start, empty, so a screen reader hears it as the store fills it. ?>
						<p class="m-field__error m-form__failure" role="alert" data-form-status></p>
					</div>
					<div class="m-sending" data-sending hidden>
						<progress max="100" value="0" aria-label="<?php esc_attr_e( 'Sending your answers', 'monstera' ); ?>"></progress>
						<span></span>
					</div>
					<p class="m-sr-only" role="status" aria-live="polite" aria-atomic="false" data-files-status></p>
				</form>
			<?php endif; ?>

			<?php if ( $mine && ! $readOnly && ! $isEmbed ) : ?>
				<section class="m-section m-answers" aria-labelledby="fm-subs">
					<div class="m-section__head">
						<h2 id="fm-subs"><?php esc_html_e( 'Your submissions', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono">
							<?php
							/* translators: %d: how many submissions were sent (the count stands with "sent" at any number) */
							echo esc_html( sprintf( _n( '%d sent', '%d sent', count( $mine ), 'monstera' ), count( $mine ) ) );
							?>
						</span>
					</div>
					<?php
					// Each send is a row of its own list with its answers under it,
					// so the answers sit beside the list, not inside it.
					foreach ( $mine as $row ) :
						$rowId   = (int) $row['id'];
						$isOpen  = $rowId === $sentId;
						$rowWhen = $isOpen ? __( 'Just now', 'monstera' ) : wp_date( 'M j', (int) strtotime( $row['submitted_at'] . ' UTC' ) );
						// Every row's button says Show answers: each is described
						// by its own row's day and summary, so a list of them is
						// told apart. Not under fm-sub-{id}, whose ids the answers'
						// file lists take by question key.
						$rowRef = 'fm-row-' . $rowId;
						?>
						<ul class="m-list">
							<li class="m-list__row">
								<span class="m-list__date" id="<?php echo esc_attr( $rowRef ); ?>-date"><?php echo esc_html( $rowWhen ); ?></span>
								<span class="m-list__title" id="<?php echo esc_attr( $rowRef ); ?>-summary"><?php echo esc_html( $summaryOf( $row ) ); ?></span>
								<?php // The date column is gone on a phone: the day is said under the summary there. ?>
								<span class="m-list__meta m-list__phone"><span><?php echo esc_html( $rowWhen ); ?></span></span>
								<button class="m-btn m-list__action" data-intent="ghost" data-size="sm" type="button" aria-expanded="<?php echo $isOpen ? 'true' : 'false'; ?>" aria-controls="fm-sub-<?php echo (int) $rowId; ?>" aria-describedby="<?php echo esc_attr( $rowRef . '-date ' . $rowRef . '-summary' ); ?>" data-wp-on--click="actions.toggleAnswers" data-msg-show="<?php esc_attr_e( 'Show answers', 'monstera' ); ?>" data-msg-hide="<?php esc_attr_e( 'Hide answers', 'monstera' ); ?>"><?php $isOpen ? esc_html_e( 'Hide answers', 'monstera' ) : esc_html_e( 'Show answers', 'monstera' ); ?></button>
							</li>
						</ul>
						<div id="fm-sub-<?php echo (int) $rowId; ?>" class="m-answers"<?php echo $isOpen ? '' : ' hidden'; ?>>
							<?php $answersBlock( $row ); ?>
						</div>
					<?php endforeach; ?>
				</section>
			<?php endif; ?>
		</div>

		<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'About this form', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'This form', 'monstera' ); ?></h3>
				<?php if ( '' !== $dueOn && ! $isEmbed ) : ?>
					<div class="m-stat">
						<span class="m-stat__label"><?php esc_html_e( 'Due', 'monstera' ); ?></span>
						<span class="m-stat__value"><?php echo esc_html( $closed ? sprintf( /* translators: %s: the day the form was due */ __( '%s · closed', 'monstera' ), CalendarDay::format( $dueOn, 'M j, Y' ) ) : CalendarDay::format( $dueOn, 'M j, Y' ) ); ?></span>
					</div>
				<?php endif; ?>
				<?php if ( $onceOnly && ! $isEmbed ) : ?>
					<div class="m-stat">
						<span class="m-stat__label"><?php esc_html_e( 'Answers', 'monstera' ); ?></span>
						<span class="m-stat__value"><?php esc_html_e( 'One per member', 'monstera' ); ?></span>
					</div>
				<?php endif; ?>
				<?php if ( $mine ) : ?>
					<div class="m-stat">
						<span class="m-stat__label"><?php esc_html_e( 'Sent by you', 'monstera' ); ?></span>
						<span class="m-stat__value m-mono"><?php echo esc_html( count( $mine ) . ' · ' . wp_date( 'M j', (int) strtotime( $mine[0]['submitted_at'] . ' UTC' ) ) ); ?></span>
					</div>
				<?php endif; ?>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( SupportPages::newRequestUrl( $user, $contextOrgId ) ); ?>"><?php esc_html_e( 'Ask a question about this form →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		</aside>
	</div>
</div>
