<?php
/**
 * Member directory (comp 81): opted-in members as one roster under letter
 * headings, behind a search field and sub-group chips that filter in place.
 * The viewer's own row is tinted and offers Edit profile; every other row
 * offers Email. Rows past the first 25 wait behind "Show N more".
 *
 * Who is listed (People-model track, FR5): the people of every organization
 * the viewer belongs to, once each; everyone for staff. A row says why the
 * person is in the viewer's list and no more: the organizations the viewer
 * shares with them and their sub-groups there. A membership the viewer has
 * no part in is not theirs to read (an invite never says whether an address
 * already belongs elsewhere, and the directory must not undo that). Staff
 * read every organization and sub-group.
 *
 * A viewer with no membership on the site has nobody to read (the owner,
 * 2026-10-21, Review-leftovers track FR1, on FR5's "a viewer with no
 * organization reads none"): a standalone member, and someone whose last
 * membership was removed, open the page to its empty state, which says
 * whose the directory is and offers no opt-in, since it would list them
 * nowhere they can read. Their own membership's end changes nothing here.
 * Until then the page had shown them every opted-in member on the site.
 *
 * An organization whose membership has ended grants the viewer nothing any
 * more (FR5 as built): its people are left out, its sub-groups are no chips
 * and no row names it, by the rule the resources and the notices follow
 * (Organizations\Reach::heldBackFor()). Someone the viewer shares a running
 * organization with stays, named for that one alone.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Capabilities;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Members\Repository as MemberRepository;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\DocumentTitle;
use Monstera\Subgroups\PostType as SubgroupType;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

if ( ! current_user_can( Capabilities::CAP_VIEW_DIRECTORY ) && ! current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) ) {
	DocumentTitle::refused( __( 'Not shared with you', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not shared with you', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'The member directory isn\'t available to you.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'Directory access comes with your membership; ask whoever manages it if you expected to see it.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user         = $ctx['user'];
$repo         = new MemberRepository();
$subgroupRepo = new SubgroupRepository();
$isAdmin      = user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) || Capabilities::isStaff( $user );
$memberships  = Roster::orgIdsOf( (int) $user->ID );
// One in the trash grants nothing, its people among it (the review of the
// At-a-glance track, 2026-10-19); a viewer whose organizations are all in
// the trash reads nobody.
$viewerOrgs = OrgRepository::onSite( $memberships );
// The organizations the page is drawn from: the viewer's, less those whose
// membership has ended, which grant them nothing any more. A viewer with
// none left reads nobody.
$listedOrgs = array_values( array_diff( $viewerOrgs, Reach::heldBackFor( $user ) ) );
// A viewer with no organization on the site, who is not staff, has nobody
// to read: a standalone member, someone whose last membership was removed,
// or someone whose organizations are all in the trash (the owner,
// 2026-10-21; the trash case from the track's review). The page says whose
// the directory is and offers no opt-in, which would list them nowhere they
// can read.
$noOrg = ! $isAdmin && ! $viewerOrgs;
// Every organization of theirs has ended: the listings are held back, not
// missing, so the page says when they return and offers no opt-in either.
$heldBack = ! $isAdmin && $viewerOrgs && ! $listedOrgs;

// The people of every organization of the viewer's, once each, and among
// them only those listed; staff read the site-wide directory. The Roster
// already holds each organization's ids, so nobody is loaded only to be
// counted: the directory query loads the listed ones, and drops an id whose
// account is gone. The viewer's organizations are read together, not one
// query each.
if ( $noOrg ) {
	$members = [];
} elseif ( $isAdmin ) {
	$members = $repo->inDirectory();
} else {
	Roster::primeOrgs( $listedOrgs );
	$ids = [];
	foreach ( $listedOrgs as $viewerOrg ) {
		$ids += array_fill_keys( Roster::memberIds( $viewerOrg ), true );
	}
	$members = $ids ? $repo->inDirectory( [ 'include' => array_keys( $ids ) ] ) : [];
}
Roster::prime( array_map( static fn ( \WP_User $person ): int => (int) $person->ID, $members ) );

$fullName = static fn ( \WP_User $person ): string => trim( $person->first_name . ' ' . $person->last_name ) ?: $person->display_name;
// Surname first for the letter headings; someone without a last name sorts
// by their display name.
$sortKey = static fn ( \WP_User $person ): string => strtolower( trim( ( $person->last_name ?: $person->display_name ) . ' ' . $person->first_name ) );
usort( $members, static fn ( $a, $b ) => strcmp( $sortKey( $a ), $sortKey( $b ) ) );

// The chips: the sub-groups of every organization of the viewer's (every
// sub-group for an admin), each counted by listed members. A viewer's are
// read together, organization by organization in membership order, so six
// organizations cost what two do (QueryCostTest).
$chipGroups = [];
if ( $isAdmin ) {
	$chipGroups = get_posts(
		[
			'post_type'      => SubgroupType::SLUG,
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
		]
	);
} else {
	$chipGroups = $subgroupRepo->forOrgs( $listedOrgs );
}

// The organizations the rows name: the viewer's own still running for
// anyone but staff, every listed person's for staff. Their names are read
// together here, not one organization at a time as each row asks.
$namedOrgs = $listedOrgs;
if ( $isAdmin ) {
	$namedOrgs = [];
	foreach ( $members as $person ) {
		$namedOrgs = array_merge( $namedOrgs, Roster::orgIdsOf( (int) $person->ID ) );
	}
}
_prime_post_caches( array_values( array_unique( $namedOrgs ) ), false, false );

// Each listed member's sub-groups, read for all of them at once: for anyone
// but staff only those under the viewer's organizations, which are the
// chips' groups, so a group of an organization the viewer is not in is
// neither named on the row, nor searchable, nor among the ids the chips
// filter by. A standalone viewer has no chips, and so reads no sub-group.
$viewerGroupIds  = array_map( static fn ( $sg ): int => (int) $sg->ID, $chipGroups );
$memberSubgroups = $subgroupRepo->subgroupsForMembers( array_map( static fn ( \WP_User $person ): int => (int) $person->ID, $members ) );
if ( ! $isAdmin ) {
	$memberSubgroups = array_map( static fn ( array $groupIds ): array => array_values( array_intersect( $groupIds, $viewerGroupIds ) ), $memberSubgroups );
} else {
	// Staff read every group but one deleted or in the trash, which is named
	// nowhere (the owner's call, 2026-10-18); their posts are read together.
	\Monstera\Subgroups\Repository::prime( $memberSubgroups ? array_merge( ...array_values( $memberSubgroups ) ) : [] );
	$memberSubgroups = array_map( static fn ( array $groupIds ): array => \Monstera\Subgroups\Repository::published( $groupIds ), $memberSubgroups );
}

// A row's organization line. For staff: every organization the person
// belongs to. For anyone else: the running organizations the viewer shares
// with the person, in the person's membership order, which for a viewer
// with one organization is that organization.
$orgLineOf = static function ( int $memberId ) use ( $isAdmin, $listedOrgs ): string {
	$orgIds = Roster::orgIdsOf( $memberId );
	if ( ! $isAdmin ) {
		// array_intersect keeps the first array's order: the person's memberships, oldest first.
		$orgIds = array_values( array_intersect( $orgIds, $listedOrgs ) );
	}
	return implode( ', ', array_filter( array_map( static fn ( int $id ): string => (string) get_the_title( $id ), $orgIds ) ) );
};

$chipCounts = [];
foreach ( $chipGroups as $sg ) {
	$chipCounts[ (int) $sg->ID ] = count( array_filter( $memberSubgroups, static fn ( $ids ) => in_array( (int) $sg->ID, $ids, true ) ) );
}
$viewerListed = in_array( (int) $user->ID, array_map( static fn ( $person ) => (int) $person->ID, $members ), true );
$moreCount    = 0; // Settled by the fold pass above the roster.
$profileUrl   = Routing::url( Routing::ROUTE_PROFILE );

// The search offers what a row carries: every row the page draws names an
// organization the viewer shares with the person, or for staff the person's
// own, since a viewer with none reads no row (2026-10-21).
$searchHint = __( 'Search by name, role or organization', 'monstera' );
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Member directory', 'monstera' ); ?></h1>
	<p>
		<?php esc_html_e( 'Other members who have opted to be listed.', 'monstera' ); ?>
		<?php if ( $heldBack || $noOrg ) : ?>
			<?php // No link: their listing, and everyone else's, waits with the membership, or is nobody's to read. ?>
		<?php elseif ( $viewerListed ) : ?>
			<?php
			/* translators: %s: a link reading "edit your profile" */
			printf( esc_html__( 'You\'re listed too · %s.', 'monstera' ), '<a href="' . esc_url( $profileUrl ) . '">' . esc_html__( 'edit your profile', 'monstera' ) . '</a>' );
			?>
		<?php else : ?>
			<a href="<?php echo esc_url( $profileUrl ); ?>"><?php esc_html_e( 'Opt in from your profile', 'monstera' ); ?></a>
		<?php endif; ?>
	</p>
</section>

<div class="monstera-portal__dash">
	<?php if ( ! $members ) : ?>
		<div class="m-empty">
			<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
			<?php if ( $noOrg ) : ?>
				<p class="m-empty__message"><?php esc_html_e( 'The directory lists the people of an organization. You don\'t belong to one, so there is nobody to list here.', 'monstera' ); ?></p>
			<?php elseif ( $heldBack && 1 === count( $viewerOrgs ) ) : ?>
				<p class="m-empty__message">
					<?php
					/* translators: %s: organization name */
					printf( esc_html__( 'The directory is back when the membership of %s is renewed.', 'monstera' ), esc_html( get_the_title( $viewerOrgs[0] ) ) );
					?>
				</p>
			<?php elseif ( $heldBack ) : ?>
				<p class="m-empty__message"><?php esc_html_e( 'The directory is back when one of your memberships is renewed.', 'monstera' ); ?></p>
			<?php else : ?>
				<p class="m-empty__message"><?php esc_html_e( 'No directory listings yet. Be the first to opt in from your profile.', 'monstera' ); ?></p>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="m-filterbar">
			<div class="m-search">
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><circle cx="9" cy="9" r="5.5"/><path d="M13.5 13.5 17 17"/></svg>
				<label class="m-sr-only" for="m-dir-q"><?php esc_html_e( 'Search members', 'monstera' ); ?></label>
				<input class="m-input" id="m-dir-q" type="search" placeholder="<?php echo esc_attr( $searchHint ); ?>" autocomplete="off" data-wp-on--input="actions.filterDirectory" />
			</div>
			<div class="m-chips" role="group" aria-label="<?php esc_attr_e( 'Filter by sub-group', 'monstera' ); ?>">
				<button type="button" class="m-chip" aria-pressed="true" data-filter="" data-wp-on--click="actions.filterDirectory">
					<?php esc_html_e( 'Everyone', 'monstera' ); ?>
					<span class="m-chip__count"><?php echo (int) count( $members ); ?></span>
				</button>
				<?php foreach ( $chipGroups as $sg ) : ?>
					<button type="button" class="m-chip" aria-pressed="false" data-filter="sg-<?php echo (int) $sg->ID; ?>" data-wp-on--click="actions.filterDirectory">
						<?php echo esc_html( get_the_title( $sg ) ); ?>
						<span class="m-chip__count"><?php echo (int) ( $chipCounts[ (int) $sg->ID ] ?? 0 ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>
			<p class="m-filterbar__status" role="status" aria-live="polite"
				data-label-one="<?php /* translators: %d: number of members shown after filtering */ esc_attr_e( '%d member shown', 'monstera' ); ?>"
				data-label-many="<?php /* translators: %d: number of members shown after filtering */ esc_attr_e( '%d members shown', 'monstera' ); ?>"></p>
		</div>

		<?php
		// Fold the rows past the first 25 behind "Show N more". The viewer's
		// own row is never folded, and a letter heading folds only when every
		// row under it does.
		$entries = [];
		$visible = 0;
		foreach ( $members as $member ) {
			$initial = mb_strtoupper( mb_substr( $sortKey( $member ), 0, 1 ) );
			if ( ! preg_match( '/\p{L}/u', $initial ) ) {
				$initial = '#';
			}
			$isSelf = (int) $member->ID === (int) $user->ID;
			$folded = ! $isSelf && $visible >= 25;
			if ( ! $folded ) {
				++$visible;
			}
			$entries[] = [
				'member' => $member,
				'letter' => $initial,
				'self'   => $isSelf,
				'folded' => $folded,
			];
		}
		$letterFolded = [];
		foreach ( $entries as $entry ) {
			$letterFolded[ $entry['letter'] ] = ( $letterFolded[ $entry['letter'] ] ?? true ) && $entry['folded'];
		}
		$moreCount = count( array_filter( $entries, static fn ( $e ) => $e['folded'] ) );
		?>
		<ul class="m-roster" data-reveal aria-label="<?php esc_attr_e( 'Members', 'monstera' ); ?>">
			<?php
			$letter = '';
			foreach ( $entries as $entry ) :
				$member   = $entry['member'];
				$memberId = (int) $member->ID;
				$isSelf   = $entry['self'];
				if ( $entry['letter'] !== $letter ) :
					$letter = $entry['letter'];
					?>
					<li class="m-roster__letter" aria-hidden="true"<?php echo $letterFolded[ $letter ] ? ' data-more hidden' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static attribute names. ?>><?php echo esc_html( $letter ); ?></li>
					<?php
				endif;
				$name     = $fullName( $member );
				$position = (string) get_user_meta( $memberId, UserMeta::KEY_POSITION, true );
				$photo    = (int) get_user_meta( $memberId, UserMeta::KEY_PROFILE_PHOTO, true );
				$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
				$orgName  = $orgLineOf( $memberId );
				$sgNames  = array_filter( array_map( static fn ( $id ) => (string) get_the_title( (int) $id ), $memberSubgroups[ $memberId ] ?? [] ) );
				$roleLine = $position;
				if ( $isSelf ) {
					/* translators: %s: the viewer's position, may be empty */
					$roleLine = $position ? sprintf( __( '%s · that\'s you', 'monstera' ), $position ) : __( 'that\'s you', 'monstera' );
				}
				$orgLine  = implode( ' · ', array_filter( [ implode( ', ', $sgNames ), $orgName ] ) );
				$haystack = strtolower( implode( ' ', array_filter( [ $name, $position, $orgName, implode( ' ', $sgNames ) ] ) ) );
				$rowAttrs = ( $isSelf ? ' data-self' : '' ) . ( $entry['folded'] ? ' data-more hidden' : '' );
				?>
				<li data-roster-row data-search="<?php echo esc_attr( $haystack ); ?>" data-subgroups="<?php echo esc_attr( implode( ',', array_map( 'intval', $memberSubgroups[ $memberId ] ?? [] ) ) ); ?>"<?php echo $rowAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static attribute names. ?>>
					<span class="m-avatar" data-size="md" aria-hidden="true">
						<?php if ( $photoUrl ) : ?>
							<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
						<?php else : ?>
							<?php Icons::emit( 'sprout', 22 ); ?>
						<?php endif; ?>
					</span>
					<span>
						<span class="m-roster__name"><?php echo esc_html( $name ); ?></span>
						<?php if ( $roleLine ) : ?>
							<span class="m-roster__role"><?php echo esc_html( $roleLine ); ?></span>
						<?php endif; ?>
						<?php if ( $orgLine ) : ?>
							<span class="m-roster__org"><?php echo esc_html( $orgLine ); ?></span>
						<?php endif; ?>
					</span>
					<?php if ( $isSelf ) : ?>
						<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $profileUrl ); ?>"><?php esc_html_e( 'Edit profile', 'monstera' ); ?></a>
					<?php else : ?>
						<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( 'mailto:' . $member->user_email ); ?>"><?php esc_html_e( 'Email', 'monstera' ); ?></a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $moreCount ) : ?>
			<p class="m-list__more">
				<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-wp-on--click="actions.revealMore">
					<?php
					/* translators: %d: number of rows still hidden */
					printf( esc_html( _n( 'Show %d more →', 'Show %d more →', $moreCount, 'monstera' ) ), (int) $moreCount );
					?>
				</button>
			</p>
				<?php endif; ?>
	<?php endif; ?>
</div>
