<?php
/**
 * Member directory (comp 81): opted-in members as one roster under letter
 * headings, behind a search field and sub-group chips that filter in place.
 * The viewer's own row is tinted and offers Edit profile; every other row
 * offers Email. Rows past the first 25 wait behind "Show N more".
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Capabilities;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Members\Repository as MemberRepository;
use Monstera\Members\UserMeta;
use Monstera\Subgroups\PostType as SubgroupType;
use Monstera\Subgroups\Repository as SubgroupRepository;

if ( ! current_user_can( Capabilities::CAP_VIEW_DIRECTORY ) && ! current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) ) {
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not shared with you', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'The member directory isn\'t available to you.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'Directory access comes with your membership; ask whoever manages it if you expected to see it.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user         = $ctx['user'];
$repo         = new MemberRepository();
$subgroupRepo = new SubgroupRepository();
$members      = $repo->inDirectory();

$fullName = static fn ( \WP_User $person ): string => trim( $person->first_name . ' ' . $person->last_name ) ?: $person->display_name;
// Surname first for the letter headings; someone without a last name sorts
// by their display name.
$sortKey = static fn ( \WP_User $person ): string => strtolower( trim( ( $person->last_name ?: $person->display_name ) . ' ' . $person->first_name ) );
usort( $members, static fn ( $a, $b ) => strcmp( $sortKey( $a ), $sortKey( $b ) ) );

// Each listed member's sub-groups, and the chips: the viewer's org's
// sub-groups (every sub-group for an admin), each counted by listed members.
$memberSubgroups = [];
foreach ( $members as $person ) {
	$memberSubgroups[ (int) $person->ID ] = $subgroupRepo->subgroupsForMember( (int) $person->ID );
}
$isAdmin    = user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
$viewerOrg  = UserMeta::associatedOrg( $user->ID );
$chipGroups = $isAdmin
	? get_posts(
		[
			'post_type'      => SubgroupType::SLUG,
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
		]
	)
	: ( $viewerOrg ? $subgroupRepo->forOrg( $viewerOrg ) : [] );
$chipCounts = [];
foreach ( $chipGroups as $sg ) {
	$chipCounts[ (int) $sg->ID ] = count( array_filter( $memberSubgroups, static fn ( $ids ) => in_array( (int) $sg->ID, $ids, true ) ) );
}
$viewerListed = in_array( (int) $user->ID, array_map( static fn ( $person ) => (int) $person->ID, $members ), true );
$moreCount    = 0; // Settled by the fold pass above the roster.
$profileUrl   = Routing::url( Routing::ROUTE_PROFILE );
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Member directory', 'monstera' ); ?></h1>
	<p>
		<?php esc_html_e( 'Other members who have opted to be listed.', 'monstera' ); ?>
		<?php if ( $viewerListed ) : ?>
			<?php
			/* translators: %s: a link reading "edit your profile" */
			printf( esc_html__( 'You\'re listed too · %s.', 'monstera' ), '<a href="' . esc_url( $profileUrl ) . '">' . esc_html__( 'edit your profile', 'monstera' ) . '</a>' );
			?>
		<?php else : ?>
			<a href="<?php echo esc_url( $profileUrl ); ?>"><?php esc_html_e( 'Opt in from your profile', 'monstera' ); ?></a>
		<?php endif; ?>
	</p>
</section>

<div class="monstera-portal__dash">
	<?php if ( ! $members ) : ?>
		<div class="m-empty">
			<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
			<p class="m-empty__message"><?php esc_html_e( 'No directory listings yet. Be the first to opt in from your profile.', 'monstera' ); ?></p>
		</div>
	<?php else : ?>
		<div class="m-filterbar">
			<div class="m-search">
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><circle cx="9" cy="9" r="5.5"/><path d="M13.5 13.5 17 17"/></svg>
				<label class="m-sr-only" for="m-dir-q"><?php esc_html_e( 'Search members', 'monstera' ); ?></label>
				<input class="m-input" id="m-dir-q" type="search" placeholder="<?php esc_attr_e( 'Search by name, role or organization', 'monstera' ); ?>" autocomplete="off" data-wp-on--input="actions.filterDirectory" />
			</div>
			<div class="m-chips" role="group" aria-label="<?php esc_attr_e( 'Filter by sub-group', 'monstera' ); ?>">
				<button type="button" class="m-chip" aria-pressed="true" data-filter="" data-wp-on--click="actions.filterDirectory">
					<?php esc_html_e( 'Everyone', 'monstera' ); ?>
					<span class="m-chip__count"><?php echo (int) count( $members ); ?></span>
				</button>
				<?php foreach ( $chipGroups as $sg ) : ?>
					<button type="button" class="m-chip" aria-pressed="false" data-filter="sg-<?php echo (int) $sg->ID; ?>" data-wp-on--click="actions.filterDirectory">
						<?php echo esc_html( get_the_title( $sg ) ); ?>
						<span class="m-chip__count"><?php echo (int) ( $chipCounts[ (int) $sg->ID ] ?? 0 ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>
			<p class="m-filterbar__status" role="status" aria-live="polite"
				data-label-one="<?php /* translators: %d: number of members shown after filtering */ esc_attr_e( '%d member shown', 'monstera' ); ?>"
				data-label-many="<?php /* translators: %d: number of members shown after filtering */ esc_attr_e( '%d members shown', 'monstera' ); ?>"></p>
		</div>

		<?php
		// Fold the rows past the first 25 behind "Show N more". The viewer's
		// own row is never folded, and a letter heading folds only when every
		// row under it does.
		$entries = [];
		$visible = 0;
		foreach ( $members as $member ) {
			$initial = mb_strtoupper( mb_substr( $sortKey( $member ), 0, 1 ) );
			if ( ! preg_match( '/\p{L}/u', $initial ) ) {
				$initial = '#';
			}
			$isSelf = (int) $member->ID === (int) $user->ID;
			$folded = ! $isSelf && $visible >= 25;
			if ( ! $folded ) {
				++$visible;
			}
			$entries[] = [
				'member' => $member,
				'letter' => $initial,
				'self'   => $isSelf,
				'folded' => $folded,
			];
		}
		$letterFolded = [];
		foreach ( $entries as $entry ) {
			$letterFolded[ $entry['letter'] ] = ( $letterFolded[ $entry['letter'] ] ?? true ) && $entry['folded'];
		}
		$moreCount = count( array_filter( $entries, static fn ( $e ) => $e['folded'] ) );
		?>
		<ul class="m-roster" data-reveal aria-label="<?php esc_attr_e( 'Members', 'monstera' ); ?>">
			<?php
			$letter = '';
			foreach ( $entries as $entry ) :
				$member   = $entry['member'];
				$memberId = (int) $member->ID;
				$isSelf   = $entry['self'];
				if ( $entry['letter'] !== $letter ) :
					$letter = $entry['letter'];
					?>
					<li class="m-roster__letter" aria-hidden="true"<?php echo $letterFolded[ $letter ] ? ' data-more hidden' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static attribute names. ?>><?php echo esc_html( $letter ); ?></li>
					<?php
				endif;
				$name     = $fullName( $member );
				$position = (string) get_user_meta( $memberId, UserMeta::KEY_POSITION, true );
				$photo    = (int) get_user_meta( $memberId, UserMeta::KEY_PROFILE_PHOTO, true );
				$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
				$orgId    = UserMeta::associatedOrg( $memberId );
				$orgName  = $orgId ? (string) get_the_title( $orgId ) : '';
				$sgNames  = array_filter( array_map( static fn ( $id ) => (string) get_the_title( (int) $id ), $memberSubgroups[ $memberId ] ?? [] ) );
				$roleLine = $position;
				if ( $isSelf ) {
					/* translators: %s: the viewer's position, may be empty */
					$roleLine = $position ? sprintf( __( '%s · that\'s you', 'monstera' ), $position ) : __( 'that\'s you', 'monstera' );
				}
				$orgLine  = implode( ' · ', array_filter( [ implode( ', ', $sgNames ), $orgName ] ) );
				$haystack = strtolower( implode( ' ', array_filter( [ $name, $position, $orgName, implode( ' ', $sgNames ) ] ) ) );
				$rowAttrs = ( $isSelf ? ' data-self' : '' ) . ( $entry['folded'] ? ' data-more hidden' : '' );
				?>
				<li data-roster-row data-search="<?php echo esc_attr( $haystack ); ?>" data-subgroups="<?php echo esc_attr( implode( ',', array_map( 'intval', $memberSubgroups[ $memberId ] ?? [] ) ) ); ?>"<?php echo $rowAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static attribute names. ?>>
					<span class="m-avatar" data-size="md" aria-hidden="true">
						<?php if ( $photoUrl ) : ?>
							<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
						<?php else : ?>
							<?php Icons::emit( 'sprout', 22 ); ?>
						<?php endif; ?>
					</span>
					<span>
						<span class="m-roster__name"><?php echo esc_html( $name ); ?></span>
						<?php if ( $roleLine ) : ?>
							<span class="m-roster__role"><?php echo esc_html( $roleLine ); ?></span>
						<?php endif; ?>
						<?php if ( $orgLine ) : ?>
							<span class="m-roster__org"><?php echo esc_html( $orgLine ); ?></span>
						<?php endif; ?>
					</span>
					<?php if ( $isSelf ) : ?>
						<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $profileUrl ); ?>"><?php esc_html_e( 'Edit profile', 'monstera' ); ?></a>
					<?php else : ?>
						<a class="m-btn" data-intent="ghost" data-size="sm" href="mailto:<?php echo esc_attr( $member->user_email ); ?>"><?php esc_html_e( 'Email', 'monstera' ); ?></a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $moreCount ) : ?>
			<p class="m-list__more">
				<button type="button" class="m-btn" data-intent="ghost" data-size="sm" data-wp-on--click="actions.revealMore">
					<?php
					/* translators: %d: number of rows still hidden */
					printf( esc_html( _n( 'Show %d more →', 'Show %d more →', $moreCount, 'monstera' ) ), (int) $moreCount );
					?>
				</button>
			</p>
				<?php endif; ?>
	<?php endif; ?>
</div>
