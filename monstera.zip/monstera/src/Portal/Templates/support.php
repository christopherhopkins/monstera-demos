<?php
/**
 * Support / contact form.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Modules;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Portal\Audience;
use Monstera\Support\Repository as SupportRepository;

// Module-gate: if Support is disabled in Settings, the form should not
// be accessible by typing /portal/support/ directly.
if ( ! Modules::isActive( Modules::SUPPORT ) ) {
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Support requests are not enabled on this site.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $ctx['user']->ID ) ) : ?>
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'Contact %s directly, or check back later.', 'monstera' ), esc_html( Audience::siteName() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'Ask your account team how to reach them, or check back later if your admin enables the module.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user         = $ctx['user'];
$projectId    = isset( $_GET['project'] ) ? (int) $_GET['project'] : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
$projectTitle = $projectId ? get_the_title( $projectId ) : '';
$recent       = ( new SupportRepository() )->listForMember( $user->ID );
$isStandalone = Audience::isStandalone( (int) $user->ID );
$siteName     = Audience::siteName();
$contact      = (string) get_option( 'admin_email' );

// The sent page: ?sent=<ref> renders the confirmation for the request the
// member just opened. Only the member's own reference matches.
$sentRef = isset( $_GET['sent'] ) ? strtoupper( sanitize_text_field( (string) wp_unslash( $_GET['sent'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; the reference is matched against the member's own rows.
$sent    = null;
if ( '' !== $sentRef ) {
	foreach ( $recent as $row ) {
		if ( strtoupper( (string) $row['ref'] ) === $sentRef ) {
			$sent = $row;
			break;
		}
	}
}

$statusTone    = static function ( string $status ): string {
	return match ( $status ) {
		SupportRepository::STATUS_RESOLVED, SupportRepository::STATUS_CLOSED => 'success',
		SupportRepository::STATUS_PENDING => 'warning',
		default => 'info',
	};
};
$statusLabel   = static function ( string $status ): string {
	return match ( $status ) {
		SupportRepository::STATUS_RESOLVED => __( 'Answered', 'monstera' ),
		SupportRepository::STATUS_CLOSED   => __( 'Closed', 'monstera' ),
		SupportRepository::STATUS_PENDING  => __( 'Waiting on you', 'monstera' ),
		default                            => __( 'Open', 'monstera' ),
	};
};
$priorityLabel = static function ( string $priority ): string {
	return match ( $priority ) {
		SupportRepository::PRIORITY_LOW    => __( 'Low', 'monstera' ),
		SupportRepository::PRIORITY_HIGH   => __( 'High', 'monstera' ),
		SupportRepository::PRIORITY_URGENT => __( 'Urgent', 'monstera' ),
		default                            => __( 'Normal', 'monstera' ),
	};
};
?>

<?php if ( $sent ) : ?>
	<div class="monstera-portal__dash">
		<section class="m-confirm" role="status" aria-live="polite">
			<?php Icons::sprig(); ?>
			<h1>
				<?php
				/* translators: %s: the request reference (wrapped in a mono span) */
				printf( esc_html__( 'Request %s sent.', 'monstera' ), '<span class="m-mono">' . esc_html( (string) $sent['ref'] ) . '</span>' );
				?>
			</h1>
			<p>
				<?php
				/* translators: %s: the member's email address (wrapped in <strong>) */
				printf( esc_html__( 'We\'ll reply to %s and post follow-ups here. Quote the reference if you write to us another way.', 'monstera' ), '<strong>' . esc_html( $user->user_email ) . '</strong>' );
				?>
			</p>
			<div class="m-confirm__actions">
				<a class="m-btn" data-intent="primary" data-size="sm" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
				<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>"><?php esc_html_e( 'Open another request', 'monstera' ); ?></a>
			</div>
		</section>
<?php else : ?>
	<section class="monstera-portal__hero">
		<h1><?php esc_html_e( 'Open a support request', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'Tell us what you need. We\'ll reply by email and post follow-ups here.', 'monstera' ); ?></p>
	</section>
	<div class="monstera-portal__dash">
<?php endif; ?>

	<div class="m-dash">
		<div class="m-dash__main">
			<?php if ( $sent ) : ?>
				<section class="m-section" aria-labelledby="support-sent-title">
					<div class="m-section__head">
						<h2 id="support-sent-title"><?php esc_html_e( 'What you sent', 'monstera' ); ?></h2>
						<span class="m-section__link m-mono"><?php echo esc_html( wp_date( 'M j, g:ia', strtotime( (string) $sent['created_at'] ) ) ); ?></span>
					</div>
					<article class="m-prose" data-plain>
						<p>
							<strong><?php echo esc_html( (string) $sent['subject'] ); ?></strong>
							· <?php echo esc_html( $priorityLabel( (string) $sent['priority'] ) ); ?>
							<?php if ( ! empty( $sent['project_id'] ) && get_the_title( (int) $sent['project_id'] ) ) : ?>
								·
								<?php
								/* translators: %s: project title */
								printf( esc_html__( 'about %s', 'monstera' ), esc_html( get_the_title( (int) $sent['project_id'] ) ) );
								?>
							<?php endif; ?>
						</p>
						<?php echo wp_kses_post( wpautop( esc_html( (string) $sent['body'] ) ) ); ?>
					</article>
				</section>
			<?php else : ?>
				<form
					method="post"
					class="m-form"
					data-plain
					action="<?php echo esc_url( Routing::restUrl( 'monstera/v1/support/requests' ) ); ?>"
					data-wp-on--submit="actions.submitSupport"
					data-sent-url="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>">
					<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>

					<?php if ( $projectTitle ) : ?>
						<input type="hidden" name="project_id" value="<?php echo esc_attr( (string) $projectId ); ?>" />
						<p class="m-form__context">
							<?php
							/* translators: %s: project title (wrapped in <strong>). */
							printf( esc_html__( 'About project: %s', 'monstera' ), '<strong>' . esc_html( $projectTitle ) . '</strong>' );
							?>
							<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>"><?php esc_html_e( 'change', 'monstera' ); ?></a>
						</p>
					<?php endif; ?>

					<div class="m-field">
						<label class="m-field__label" for="sr-subject"><?php esc_html_e( 'Subject', 'monstera' ); ?></label>
						<input class="m-input" id="sr-subject" type="text" name="subject" required maxlength="200" />
					</div>

					<div class="m-field">
						<label class="m-field__label" for="sr-body"><?php esc_html_e( 'What\'s going on?', 'monstera' ); ?></label>
						<textarea class="m-textarea" id="sr-body" name="body" rows="8" required></textarea>
						<span class="m-field__hint"><?php esc_html_e( 'Be specific. URLs, screenshots, and timestamps help a lot.', 'monstera' ); ?></span>
					</div>

					<fieldset class="m-choices" data-stack>
						<legend><?php esc_html_e( 'Priority', 'monstera' ); ?></legend>
						<label><input type="radio" name="priority" value="low" /><span><?php esc_html_e( 'Low', 'monstera' ); ?><small><?php esc_html_e( 'When you can get to it', 'monstera' ); ?></small></span></label>
						<label><input type="radio" name="priority" value="normal" checked /><span><?php esc_html_e( 'Normal', 'monstera' ); ?><small><?php esc_html_e( 'Within a couple of business days', 'monstera' ); ?></small></span></label>
						<label><input type="radio" name="priority" value="high" /><span><?php esc_html_e( 'High', 'monstera' ); ?><small><?php esc_html_e( 'Blocking work', 'monstera' ); ?></small></span></label>
						<label><input type="radio" name="priority" value="urgent" /><span><?php esc_html_e( 'Urgent', 'monstera' ); ?><small><?php esc_html_e( 'Production-impacting', 'monstera' ); ?></small></span></label>
						<span class="m-field__hint"><?php esc_html_e( 'We see all requests within one business day regardless of priority.', 'monstera' ); ?></span>
					</fieldset>

					<div class="m-form__actions">
						<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php esc_html_e( 'Send request', 'monstera' ); ?></button>
					</div>
				</form>
			<?php endif; ?>
		</div>

		<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'Your recent requests', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Your recent requests', 'monstera' ); ?></h3>
				<?php if ( ! $recent ) : ?>
					<p class="m-rail-block__empty"><?php esc_html_e( 'No requests yet. Anything you send will land here.', 'monstera' ); ?></p>
				<?php else : ?>
					<ul class="m-requests">
						<?php foreach ( array_slice( $recent, 0, 8 ) as $row ) : ?>
							<li>
								<span class="m-requests__top">
									<strong><?php echo esc_html( (string) $row['subject'] ); ?></strong>
									<span class="m-badge" data-tone="<?php echo esc_attr( $statusTone( (string) $row['status'] ) ); ?>"><?php echo esc_html( $statusLabel( (string) $row['status'] ) ); ?></span>
								</span>
								<time datetime="<?php echo esc_attr( (string) $row['created_at'] ); ?>"><?php echo esc_html( (string) $row['ref'] ); ?> · <?php echo esc_html( human_time_diff( strtotime( (string) $row['created_at'] ), time() ) ); ?> <?php esc_html_e( 'ago', 'monstera' ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Prefer email?', 'monstera' ); ?></h3>
				<p class="m-rail-block__empty">
					<?php
					printf(
						/* translators: %s: the support email address as a link */
						esc_html__( 'Write to %s and quote a reference. Same inbox, same people.', 'monstera' ),
						'<a href="mailto:' . esc_attr( $contact ) . '">' . esc_html( $contact ) . '</a>'
					);
					?>
				</p>
			</div>
		</aside>
	</div>
</div>
