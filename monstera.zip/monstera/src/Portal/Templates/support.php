<?php
/**
 * Support — the member's requests (comp 85).
 *
 * Those waiting on the member first, then the open ones, then the resolved
 * and closed (five, until all are asked for). Each row links the request's
 * own page and says where it stands and who acted last. With no requests
 * the page invites the first. The form is at /portal/support/new/.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Portal\SupportView;
use Monstera\Support\Inbox;
use Monstera\Support\Repository as SupportRepository;
use Monstera\Support\Thread;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::SUPPORT ) ) {
	include __DIR__ . '/_support-off.php';
	return;
}

$user    = $ctx['user'];
$rows    = ( new SupportRepository() )->listForMember( (int) $user->ID );
$groups  = SupportView::groups( $rows );
$last    = ( new Thread() )->lastEntries( array_map( 'intval', array_column( $rows, 'id' ) ) );
$showAll = isset( $_GET['done'] ) && 'all' === $_GET['done']; // phpcs:ignore WordPress.Security.NonceVerification -- a read-only view switch; nothing is written.
$newUrl  = Routing::url( Routing::ROUTE_SUPPORT_NEW );
$email   = Inbox::email();

$sections = [
	'waiting' => [ 'sl-waiting', __( 'Waiting on you', 'monstera' ), $groups['waiting'] ],
	'open'    => [ 'sl-open', __( 'Open', 'monstera' ), $groups['open'] ],
	'done'    => [ 'sl-done', __( 'Resolved and closed', 'monstera' ), $showAll ? $groups['done'] : array_slice( $groups['done'], 0, SupportView::DONE_SHOWN ) ],
];
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Support', 'monstera' ); ?></h1>
	<?php if ( $rows ) : ?>
		<p><?php esc_html_e( 'Your requests and our replies, in one place. We read every request within one business day.', 'monstera' ); ?></p>
		<a class="m-btn m-hero__action" data-intent="primary" data-size="md" href="<?php echo esc_url( $newUrl ); ?>"><?php esc_html_e( 'New request', 'monstera' ); ?></a>
	<?php else : ?>
		<p><?php esc_html_e( 'Ask us anything about your projects, your files or the portal. We read every request within one business day.', 'monstera' ); ?></p>
	<?php endif; ?>
</section>

<div class="monstera-portal__dash">
	<div class="m-dash">
		<div class="m-dash__main">
			<?php if ( ! $rows ) : ?>
				<div class="m-empty">
					<div class="m-empty__sprig"><?php Icons::sprig(); ?></div>
					<p class="m-empty__message"><?php esc_html_e( 'No requests yet. When something needs us, open one and the conversation lands here.', 'monstera' ); ?></p>
					<a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( $newUrl ); ?>"><?php esc_html_e( 'New request', 'monstera' ); ?></a>
				</div>
			<?php endif; ?>

			<?php foreach ( $sections as $key => [ $headingId, $heading, $list ] ) : ?>
				<?php
				if ( ! $list ) {
					continue;
				}
				$total = count( $groups[ $key ] );
				?>
				<section class="m-section" aria-labelledby="<?php echo esc_attr( $headingId ); ?>">
					<div class="m-section__head">
						<h2 id="<?php echo esc_attr( $headingId ); ?>"><?php echo esc_html( $heading ); ?></h2>
						<?php if ( $total > count( $list ) ) : ?>
							<a class="m-section__link" href="<?php echo esc_url( add_query_arg( 'done', 'all', Routing::url( Routing::ROUTE_SUPPORT ) ) . '#' . $headingId ); ?>">
								<?php
								/* translators: %d: how many resolved and closed requests there are */
								printf( esc_html__( 'All %d →', 'monstera' ), (int) $total );
								?>
							</a>
						<?php else : ?>
							<span class="m-section__link m-mono">
								<?php
								/* translators: %d: how many requests are in this group */
								printf( esc_html( _n( '%d request', '%d requests', $total, 'monstera' ) ), (int) $total );
								?>
							</span>
						<?php endif; ?>
					</div>
					<ul class="m-list">
						<?php foreach ( $list as $row ) : ?>
							<?php
							$stands   = (string) $row['status'];
							$activity = SupportView::lastActivity( $row, $last[ (int) $row['id'] ] ?? null, (int) $user->ID );
							?>
							<li class="m-list__row">
								<span class="m-list__date"><?php echo esc_html( SupportView::when( $row ) ); ?></span>
								<a class="m-list__title" href="<?php echo esc_url( SupportRepository::portalUrl( $row ) ); ?>"><?php echo esc_html( (string) $row['subject'] ); ?></a>
								<span class="m-list__meta">
									<span><?php echo esc_html( (string) $row['ref'] ); ?></span>
									<span><?php echo esc_html( $activity ); ?></span>
									<?php if ( 'done' !== $key ) : ?>
										<span><?php echo esc_html( SupportView::priorityLine( (string) $row['priority'] ) ); ?></span>
									<?php endif; ?>
								</span>
								<span class="m-list__action"><span class="m-badge" data-tone="<?php echo esc_attr( SupportView::statusTone( $stands ) ); ?>"><?php echo esc_html( SupportView::statusLabel( $stands ) ); ?></span></span>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>
			<?php endforeach; ?>
		</div>

		<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'About support', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'How it works', 'monstera' ); ?></h3>
				<ol class="m-timeline">
					<li>
						<time><?php esc_html_e( 'You', 'monstera' ); ?></time>
						<strong><?php esc_html_e( 'Open a request', 'monstera' ); ?></strong>
						<p><?php esc_html_e( 'Screenshots and files help us see what you see.', 'monstera' ); ?></p>
					</li>
					<li>
						<time><?php esc_html_e( 'Us', 'monstera' ); ?></time>
						<strong><?php esc_html_e( 'We reply here and by email', 'monstera' ); ?></strong>
						<p><?php esc_html_e( 'The request waits on you until you answer.', 'monstera' ); ?></p>
					</li>
					<li data-now>
						<time><?php esc_html_e( 'You', 'monstera' ); ?></time>
						<strong><?php esc_html_e( 'Reply, or mark it resolved', 'monstera' ); ?></strong>
						<p><?php esc_html_e( 'A reply on a resolved request opens it again.', 'monstera' ); ?></p>
					</li>
				</ol>
			</div>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Prefer email?', 'monstera' ); ?></h3>
				<p class="m-rail-block__empty">
					<?php
					printf(
						/* translators: %s: the support email address as a link */
						esc_html__( 'Write to %s. We answer email by email; it won\'t appear in this list.', 'monstera' ),
						'<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>'
					);
					?>
				</p>
			</div>
		</aside>
	</div>
</div>
