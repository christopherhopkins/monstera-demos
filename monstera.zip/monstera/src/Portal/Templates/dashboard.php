<?php
/**
 * The Portal — `/portal/` (personal home). "The dashboard" in the code and
 * the comments; "the Portal" to its reader (the owner's naming, 2026-10-13),
 * to tell it from an organization's Dashboard, the hub.
 *
 * Distinct from the per-org content hub at `/portal/{org-slug}/`:
 *  - the org hub is the *org's* room (cover, tabs, deep browse)
 *  - the dashboard is the *user's* day (greeting, your orgs, what's new,
 *    your projects, upcoming, what you did lately)
 *
 * Composition (2026-09 design review, comps 20–23):
 *   • greeting hero (time-of-day aware); the profile nudge is the shell's
 *   • one org band per visible org (none for a standalone member): every
 *     organization the person belongs to, in membership order, or every
 *     organization for staff. A person in several organizations sees a
 *     suspended or ended organization's band in its soft-block state while
 *     the page stays live (comp 23); with one organization the shell's own
 *     soft block carries it, as before the memberships table.
 *   • main column — Your projects as rows with the stage meter (3) ·
 *     What's new for you as the list (5) · Coming up rows. For a person in
 *     several organizations the three union across them and every row names
 *     its organization.
 *   • rail from 1024 — Your recent activity, the reader's own acts
 *     (Portal\OwnActivity) · Sub-groups or account team; for a person in
 *     several organizations, the account lead of each · Notices, the ones
 *     the team ended in the last fortnight, only while there is one.
 *
 * The page's reads do not grow with the organizations, nor with what each
 * of them holds (QueryCostTest): the organizations, their tiers, their
 * rosters and assignments and their projects each come from one read, the
 * items their bands count from the same few however many bands there are,
 * and what gates those items from one read of each gate for all of them.
 *
 * No full content table here — the deep inventory lives on the org hub.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertRepository;
use Monstera\Content\Downloader;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\Repository as ContentRepository;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Portal\CalendarDay;
use Monstera\Portal\ContentProjects;
use Monstera\Portal\Context;
use Monstera\Portal\DueForms;
use Monstera\Portal\Leads;
use Monstera\Portal\NextStep;
use Monstera\Portal\OwnActivity;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

$user         = $ctx['user'];
$isStandalone = Audience::isStandalone( (int) $user->ID );
$siteName     = Audience::siteName();
$contentRepo  = new ContentRepository();
$subgroupRepo = new SubgroupRepository();
$projectRepo  = new ProjectRepository();
$orgRepo      = new OrgRepository();
$visibility   = new Visibility( $subgroupRepo, $projectRepo );

$projectsActive = Modules::isActive( Modules::PROJECTS );

// Resolve the orgs this user can see. Members see every organization they
// belong to, oldest membership first, less one in the trash, whose hub would
// turn them away (the switcher and the support select leave it out the same
// way); a suspended or archived one, a draft, is among them. Admins / agency
// staff see every org.
$isAdmin = user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
if ( ! $isAdmin ) {
	// A member's organizations, their meta and their tiers, each in one read
	// however many they belong to; staff's come in hand from the list query.
	_prime_post_caches( Roster::orgIdsOf( (int) $user->ID ), true, true );
}
$visibleOrgs = $isAdmin
	? $orgRepo->all( [ 'posts_per_page' => 12 ] )
	: array_values( array_filter( array_map( static fn ( int $id ) => $orgRepo->findOnSite( $id ), Roster::orgIdsOf( (int) $user->ID ) ) ) );

$orgIdsInScope = array_map( static fn ( $o ) => (int) $o->ID, $visibleOrgs );
// Each band counts its organization's members, and the rail names the people
// assigned to it: one read for all of them.
Roster::primeOrgs( $orgIdsInScope );

// Whether the bands carry a suspended or ended organization's state. With
// one organization the shell renders the full soft block above the page, as
// it always has; with several, the shell stands back and each band says
// where its organization stands, so the live ones read as live.
$bandsCarryState = ! $isAdmin && ! Context::isSingleOrg( $user );

// A person in several organizations reads which one each row belongs to
// (comp 23): the project rows, the dates and the rail's people say it, as
// the what's-new rows always have. With one organization, and for staff,
// who read every organization's band, the rows are as they were (comp 20).
$severalOrgs = ! $isAdmin && Audience::isMultiOrg( (int) $user->ID );

// Cross-org content the user can actually see, newest first, trimmed. An
// ended membership pauses what it granted: for anyone but staff the feed
// asks only the organizations whose membership has not ended, so an item
// that only an ended one shares is left out (its page answers "Membership
// ended" and its file does not download), while one a live organization
// shares too, and every item for everyone, still arrives. The ended
// organization keeps its band below, which is how the person learns why.
// The feed leaves out by the organization asked, not by the verdict: an
// item of an ended organization that also names the person on its
// standalone list goes with the rest of that organization's, since its
// page answers "Membership ended" all the same, and the query never brings
// an ended organization's rows into the fifty it reads.
$feedOrgIds   = $isAdmin
	? $orgIdsInScope
	: array_values( array_filter( $orgIdsInScope, static fn ( int $id ): bool => ! PortalGuard::membershipExpired( $id ) ) );
$contentPosts = $orgIdsInScope
	? $contentRepo->forOrgs( $feedOrgIds, [ 'posts_per_page' => 50 ] )
	: $contentRepo->forStandalone( (int) $user->ID, [ 'posts_per_page' => 50 ] );
// What gates the fifty (their sub-groups, their projects) is read together
// before each is judged, not item by item.
$visibility->prime( array_map( static fn ( $post ): int => (int) $post->ID, $contentPosts ) );
$contentRows = array_filter(
	$contentRepo->summarize( $contentPosts ),
	static fn ( $r ) => $visibility->userCanSee( $user, $r['id'] )
);
usort(
	$contentRows,
	static fn ( $a, $b ) => strtotime( (string) $b['date'] ) <=> strtotime( (string) $a['date'] )
);
$whatsNew = array_slice( $contentRows, 0, 5, true );

// Personal projects feed: union of every organization's projects and any
// projects they're directly on the team for, less those of an organization
// whose membership has ended. Same query the portal /projects list uses, so
// the dashboard's count matches the destination page.
$myProjects = $projectsActive ? $projectRepo->listedFor( $user )[0] : [];
// The published ones: one in the trash lets nobody through and is named
// nowhere (the owner's call, 2026-10-18).
$mySubgroups = $subgroupRepo->publishedSubgroupsForMember( $user->ID );

// The rail's first block: what the reader did, newest first (the owner's
// walk-through at the Phase 5 checkpoint). It listed the items above again,
// under "Recent activity"; what was published is "What's new for you", and
// this is theirs. The same block for every reader, staff included, who read
// what they did in the portal: what they did in the admin has its feeds
// there. Portal\OwnActivity says which acts, and leaves out what the reader
// can no longer open; the projects it may name are the ones listed here.
$ownActivity = OwnActivity::rows( $user, $visibility, array_map( static fn ( $project ): int => (int) $project->ID, $myProjects ) );

// The notices the team ended in the last fortnight that had been in front of
// this reader: "Resolved: <title>", which nothing else in the portal tells a
// member (the band only drops the notice). They were rows of the block above
// while it listed what was published. An ended notice is not an act of the
// reader's, so they have a block of their own at the foot of the rail, there
// only while there is one to tell, and keeping to the five ended last, as
// the block they came from kept to five. None with Alerts off, as the band
// has none.
$resolvedNotes = [];
if ( Modules::isActive( Modules::ALERTS ) ) {
	foreach ( array_slice( ( new AlertRepository() )->endedFor( $user ), 0, 5 ) as $endedAlert ) {
		$resolvedNotes[] = [
			'title' => get_the_title( $endedAlert ),
			'at'    => (int) strtotime( (string) get_post_meta( $endedAlert->ID, AlertMeta::KEY_ENDED_AT, true ) . ' UTC' ),
		];
	}
}

// The organization a project row names for a person in several: the
// project's own. A project they reach through its team may sit under an
// organization they do not belong to, so the ones named are read together.
if ( $severalOrgs ) {
	_prime_post_caches( array_filter( array_map( static fn ( $p ) => (int) get_post_meta( $p->ID, ProjectMeta::KEY_ORG_ID, true ), $myProjects ) ), false, false );
}
$projectOrgName = static function ( int $projectId ) use ( $severalOrgs ): string {
	$projectOrg = $severalOrgs ? (int) get_post_meta( $projectId, ProjectMeta::KEY_ORG_ID, true ) : 0;
	return $projectOrg > 0 ? (string) get_the_title( $projectOrg ) : '';
};

$firstName = $user->first_name ?: $user->display_name ?: __( 'there', 'monstera' );

// Project pipeline stages used by the dashboard strip.
$pipelineStages = [
	ProjectMeta::STATUS_PROPOSED,
	ProjectMeta::STATUS_DISCOVERY,
	ProjectMeta::STATUS_IN_PROGRESS,
	ProjectMeta::STATUS_REVIEW,
	ProjectMeta::STATUS_COMPLETED,
];

// "Coming up" — the projects' due dates in the next 90 days, for a client
// the next steps staff set in them (At-a-glance track, FR7), and the forms
// due that they have not sent (DueForms), soonest first. Each day is the
// site's, as CalendarDay counts them.
$upcoming   = [];
$stepsForMe = NextStep::shownTo( $user );
$comingDays = NextStep::window();
foreach ( $myProjects as $project ) {
	$dueOn         = CalendarDay::start( (string) get_post_meta( $project->ID, ProjectMeta::KEY_DUE_ON, true ) )?->getTimestamp() ?? 0;
	$projectStatus = $projectRepo->status( $project->ID );
	$projectBase   = [
		'title' => get_the_title( $project ),
		'org'   => $projectOrgName( (int) $project->ID ),
		'url'   => Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $project->ID ] ),
	];
	if ( NextStep::inWindow( $dueOn, $comingDays ) && ! in_array( $projectStatus, [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true ) ) {
		$upcoming[] = [
			'date'   => $dueOn,
			'detail' => ProjectMeta::statusLabel( $projectStatus ),
		] + $projectBase;
	}
	$stepComing = $stepsForMe ? NextStep::comingUp( $projectRepo, (int) $project->ID, $comingDays ) : null;
	if ( $stepComing ) {
		$upcoming[] = $stepComing + $projectBase;
	}
}
// The forms due in the window that they have not sent (Forms-and-resources
// track, FR5), each leading to its page.
foreach ( DueForms::comingUp( $user, $comingDays, $severalOrgs ) as $dueForm ) {
	$upcoming[] = $dueForm;
}
usort( $upcoming, static fn ( $a, $b ) => $a['date'] <=> $b['date'] );
$upcoming = array_slice( $upcoming, 0, NextStep::COMING_UP_MAX );

$activeProjects      = array_filter(
	$myProjects,
	static function ( $p ) use ( $projectRepo ) {
		return ! in_array( $projectRepo->status( $p->ID ), [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true );
	}
);
$activeProjectsStrip = array_slice( $activeProjects, 0, 3 );

// Per-org facts for the bands. The state is the band's soft-block state
// when the bands carry it: an ended membership first (its hub is closed),
// then a suspended organization (its hub opens, downloads wait). The tier
// comes from the terms read with the organizations, not a query per band.
$orgBands = [];
foreach ( $visibleOrgs as $org ) {
	$orgId     = (int) $org->ID;
	$tierTerms = get_the_terms( $orgId, 'monstera_org_tier' );
	$state     = '';
	if ( $bandsCarryState && PortalGuard::membershipExpired( $orgId ) ) {
		$state = 'expired';
	} elseif ( $bandsCarryState && OrgMeta::STATUS_SUSPENDED === $orgRepo->status( $orgId ) ) {
		$state = 'suspended';
	}
	$orgBands[ $orgId ] = [
		'id'      => $orgId,
		'slug'    => $org->post_name,
		'name'    => get_the_title( $org ),
		'tier'    => is_array( $tierTerms ) && $tierTerms ? $tierTerms[0]->name : '',
		'expires' => (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ),
		'members' => count( Roster::memberIds( $orgId ) ),
		'items'   => 0,
		'state'   => $state,
	];
}

// How many items a band holds for this reader. Only a live band with no
// renewal date says it (a renewal date takes the third fact's place, and a
// band in its soft state says what works instead), so only those are
// counted, from the same reads however many they are and however much each
// holds: the items come from the same few reads (newestIdsByOrg()), and what
// gates them is read together before the count judges each, where judging
// them one by one read twice for every item no earlier list had judged.
$countedOrgIds   = array_keys(
	array_filter(
		$orgBands,
		static fn ( array $band ): bool => '' === $band['state'] && ! ( $band['expires'] && strtotime( $band['expires'] ) )
	)
);
$countedIdsByOrg = $contentRepo->newestIdsByOrg( $countedOrgIds, 60 );
$visibility->prime( $countedIdsByOrg ? array_merge( ...array_values( $countedIdsByOrg ) ) : [] );
foreach ( $countedIdsByOrg as $orgId => $contentIds ) {
	$orgBands[ $orgId ]['items'] = count( array_filter( $contentIds, static fn ( int $id ): bool => $visibility->userCanSee( $user, $id ) ) );
}
?>


<section class="monstera-portal__hero">
	<h1>
		<?php
		$hour = (int) wp_date( 'G' );
		if ( $hour < 12 ) {
			/* translators: %s: member first name. */
			printf( esc_html__( 'Good morning, %s.', 'monstera' ), esc_html( $firstName ) );
		} elseif ( $hour < 18 ) {
			/* translators: %s: member first name. */
			printf( esc_html__( 'Welcome back, %s.', 'monstera' ), esc_html( $firstName ) );
		} else {
			/* translators: %s: member first name. */
			printf( esc_html__( 'Good evening, %s.', 'monstera' ), esc_html( $firstName ) );
		}
		?>
	</h1>
	<p>
		<?php
		$visibleItems = count( $contentRows );
		if ( $myProjects && $visibleItems ) {
			printf(
				$isStandalone
					/* translators: 1: project count, 2: content count */
					? esc_html__( '%1$d projects in flight. %2$d items available to you.', 'monstera' )
					/* translators: 1: project count, 2: content count */
					: esc_html__( '%1$d projects in flight. %2$d items available across your orgs.', 'monstera' ),
				count( $activeProjects ),
				(int) $visibleItems
			);
		} elseif ( $visibleItems ) {
			printf(
				/* translators: %d: number of content items visible to the member. */
				esc_html( _n( '%d item available to you right now.', '%d items available to you right now.', $visibleItems, 'monstera' ) ),
				(int) $visibleItems
			);
		} else {
			esc_html_e( 'Nothing new today. Check back soon, or browse the directory.', 'monstera' );
		}
		?>
	</p>
</section>

<div class="monstera-portal__dash">
<div class="m-dash">
	<div class="m-dash__main">

		<?php
		foreach ( $orgBands as $o ) :
			$url  = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $o['slug'] ] );
			$mark = strtoupper( mb_substr( (string) preg_replace( '/[^A-Za-z0-9]/', '', $o['name'] ), 0, 2 ) ) ?: 'M';
			?>
			<a class="m-org-band" href="<?php echo esc_url( $url ); ?>"<?php echo $o['state'] ? ' data-state="' . esc_attr( $o['state'] ) . '"' : ''; ?>>
				<span class="m-org-band__mark" aria-hidden="true"><?php echo esc_html( $mark ); ?></span>
				<span class="m-org-band__name"><?php echo esc_html( $o['name'] ); ?></span>
				<span class="m-org-band__meta">
					<?php if ( 'suspended' === $o['state'] ) : ?>
						<?php // The soft-block state as comp 23 draws it: the badge, then what still works and what waits. ?>
						<span class="m-badge" data-tone="suspended"><?php esc_html_e( 'Suspended', 'monstera' ); ?></span>
						<?php if ( $o['tier'] ) : ?>
							<span><?php echo esc_html( $o['tier'] ); ?></span>
						<?php endif; ?>
						<span><?php esc_html_e( 'Content still opens', 'monstera' ); ?></span>
						<span class="m-paused"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
					<?php elseif ( 'expired' === $o['state'] ) : ?>
						<?php // The same state for an ended membership; its hub is closed until renewal, so nothing is promised to open. ?>
						<span class="m-badge" data-tone="expired"><?php esc_html_e( 'Expired', 'monstera' ); ?></span>
						<?php if ( $o['tier'] ) : ?>
							<span><?php echo esc_html( $o['tier'] ); ?></span>
						<?php endif; ?>
						<span>
						<?php
							/* translators: %s: the date the membership ended */
							printf( esc_html__( 'Ended %s', 'monstera' ), esc_html( CalendarDay::format( (string) $o['expires'], 'M j, Y' ) ?: wp_date( 'M j, Y' ) ) );
						?>
						</span>
					<?php else : ?>
						<?php if ( $o['tier'] ) : ?>
							<span><?php echo esc_html( $o['tier'] ); ?></span>
						<?php endif; ?>
						<span>
						<?php
							/* translators: %d: how many members */
							printf( esc_html( _n( '%d member', '%d members', $o['members'], 'monstera' ) ), (int) $o['members'] );
						?>
						</span>
						<?php if ( '' !== CalendarDay::format( (string) $o['expires'], 'M j, Y' ) ) : ?>
							<span>
							<?php
								/* translators: %s: renewal date */
								printf( esc_html__( 'Renews %s', 'monstera' ), esc_html( CalendarDay::format( (string) $o['expires'], 'M j, Y' ) ) );
							?>
							</span>
						<?php else : ?>
							<span>
							<?php
								/* translators: %d: content count */
								printf( esc_html( _n( '%d item', '%d items', $o['items'], 'monstera' ) ), (int) $o['items'] );
							?>
							</span>
						<?php endif; ?>
					<?php endif; ?>
				</span>
				<span class="m-btn m-org-band__action" data-intent="ghost" data-size="sm"><?php esc_html_e( 'Open →', 'monstera' ); ?></span>
			</a>
		<?php endforeach; ?>

		<?php if ( $activeProjectsStrip ) : ?>
			<section class="m-section" aria-labelledby="dash-projects">
				<div class="m-section__head">
					<h2 id="dash-projects"><?php esc_html_e( 'Your projects', 'monstera' ); ?></h2>
					<a class="m-section__link" href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROJECTS ) ); ?>"><?php esc_html_e( 'See all →', 'monstera' ); ?></a>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $activeProjectsStrip as $project ) :
						$pid           = (int) $project->ID;
						$projectStatus = $projectRepo->status( $pid );
						$dueOn         = (string) get_post_meta( $pid, ProjectMeta::KEY_DUE_ON, true );
						$teamSize      = count( $projectRepo->memberIds( $pid ) );
						$currentIndex  = array_search( $projectStatus, $pipelineStages, true );
						if ( false === $currentIndex ) {
							$currentIndex = 0;
						}
						$tone = match ( $projectStatus ) {
							ProjectMeta::STATUS_COMPLETED => 'active',
							ProjectMeta::STATUS_ON_HOLD   => 'suspended',
							ProjectMeta::STATUS_DISCOVERY => 'info',
							ProjectMeta::STATUS_PROPOSED  => 'pending',
							ProjectMeta::STATUS_REVIEW    => 'warning',
							default                       => 'active',
						};
						// A person in several organizations reads whose project it is
						// after the badge, and how many are on it as the third fact,
						// which gives way on a phone (comp 23). Both are written on the
						// line of the fact's own tag, so a one-organization page is
						// the same markup, space for space, as before.
						$projectOrgLabel = $projectOrgName( $pid );
						?>
						<li class="m-rows__row">
							<span class="m-rows__date">
								<?php
								if ( ProjectMeta::STATUS_ON_HOLD === $projectStatus ) {
									esc_html_e( 'on hold', 'monstera' );
								} elseif ( '' !== CalendarDay::format( $dueOn, 'M j' ) ) {
									/* translators: %s: due date */
									printf( esc_html__( 'due %s', 'monstera' ), esc_html( CalendarDay::format( $dueOn, 'M j' ) ) );
								}
								?>
							</span>
							<a class="m-rows__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $pid ] ) ); ?>"><?php echo esc_html( get_the_title( $project ) ); ?></a>
							<span class="m-rows__meta">
								<span class="m-badge" data-tone="<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( ProjectMeta::statusLabel( $projectStatus ) ); ?></span>
								<?php echo $projectOrgLabel ? '<span class="m-rows__org">' . esc_html( $projectOrgLabel ) . '</span>' : ''; ?><span<?php echo $severalOrgs ? ' data-priority="2"' : ''; ?>>
								<?php
								if ( $severalOrgs ) {
									/* translators: %d: how many of the client's people are on the project */
									printf( esc_html( _n( '%d project member', '%d project members', $teamSize, 'monstera' ) ), (int) $teamSize );
								} else {
									/* translators: %d: team size count */
									printf( esc_html( _n( '%d on team', '%d on team', $teamSize, 'monstera' ) ), (int) $teamSize );
								}
								?>
								</span>
							<?php echo $stepsForMe ? NextStep::rowFact( $projectRepo, $pid ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by NextStep::rowFact(). ?></span>
							<span class="m-rows__side">
								<?php
								/* translators: 1: current stage number, 2: total stages */
								$stageLabel = sprintf( __( 'Stage %1$d of %2$d', 'monstera' ), (int) $currentIndex + 1, count( $pipelineStages ) );
								?>
								<span class="m-progress" role="img" aria-label="<?php echo esc_attr( $stageLabel ); ?>">
									<?php foreach ( $pipelineStages as $idx => $stage ) : ?>
										<span<?php echo $idx < $currentIndex ? ' data-done' : ( $idx === $currentIndex ? ' data-now' : '' ); ?>></span>
									<?php endforeach; ?>
								</span>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( $whatsNew ) : ?>
			<section class="m-section" aria-labelledby="dash-new">
				<div class="m-section__head">
					<h2 id="dash-new"><?php esc_html_e( 'What\'s new for you', 'monstera' ); ?></h2>
					<?php
					if ( count( $visibleOrgs ) === 1 ) :
						$first = $visibleOrgs[ array_key_first( $visibleOrgs ) ];
						?>
						<a class="m-section__link" href="<?php echo esc_url( Routing::url( Routing::ROUTE_ORG, [ 'slug' => $first->post_name ] ) ); ?>"><?php esc_html_e( 'Browse all →', 'monstera' ); ?></a>
					<?php endif; ?>
				</div>
				<?php
				// The projects each row names (At-a-glance track, FR6), from the
				// gates the fifty were judged by: the reader's own projects open
				// for them, any other asked.
				$rowProjects = ContentProjects::forRows(
					$visibility,
					(int) $user->ID,
					array_map( static fn ( array $r ): int => (int) $r['id'], $whatsNew ),
					array_map( static fn ( $p ): int => (int) $p->ID, $myProjects )
				);
				?>
				<ul class="m-list">
					<?php
					foreach ( $whatsNew as $row ) :
						$fileId     = (int) get_post_meta( $row['id'], ContentMeta::KEY_SECURE_FILE_ID, true );
						$click      = $row['click'];
						$href       = Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] );
						$isDownload = false;
						$isPaused   = false;
						if ( ContentMeta::CLICK_FILE === $click && $fileId ) {
							if ( $visibility->userCanDownload( $user, (int) $row['id'] ) ) {
								$href       = Downloader::signedUrl( $fileId, $user->ID );
								$isDownload = true;
							} else {
								// Suspended org, or an ended one beside it with no live
								// organization sharing the item: it stays readable, the file waits.
								$isPaused = true;
							}
						}
						// The organization the item reaches this reader through, as its own
						// page names it: an item shared with two organizations is labelled
						// with theirs, never with one they are not in. The site's name for
						// an item that is no one organization's.
						$rowOrg = Context::orgOfContent( $user, (int) $row['id'] );
						$scope  = $rowOrg ? get_the_title( $rowOrg ) : $siteName;
						$kind   = ContentMeta::CLICK_FILE === $click ? __( 'File', 'monstera' ) : __( 'Article', 'monstera' );
						$ts     = strtotime( (string) $row['date'] ) ?: 0;
						?>
						<li class="m-list__row">
							<span class="m-list__date"><?php echo esc_html( wp_date( 'M j', $ts ?: null ) ); ?></span>
							<a class="m-list__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] ) ); ?>"><?php echo esc_html( $row['title'] ); ?></a>
							<span class="m-list__meta"><span><?php echo esc_html( $scope ); ?></span><?php echo ContentProjects::render( $rowProjects[ (int) $row['id'] ] ?? [] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts. ?><span><?php echo esc_html( $kind ); ?></span></span>
							<?php if ( $isPaused ) : ?>
								<span class="m-paused m-list__action"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
							<?php else : ?>
								<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $href ); ?>"<?php echo $isDownload ? ' download' : ''; ?>>
									<?php echo $isDownload ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Open →', 'monstera' ); ?>
								</a>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( $upcoming ) : ?>
			<section class="m-section" aria-labelledby="dash-upcoming">
				<div class="m-section__head">
					<h2 id="dash-upcoming"><?php esc_html_e( 'Coming up', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						/* translators: %d: number of upcoming dates */
						printf( esc_html( _n( '%d date', '%d dates', count( $upcoming ), 'monstera' ) ), (int) count( $upcoming ) );
					?>
					</span>
				</div>
				<?php // A list of dates: its day stays at every width (_dashboard.scss). ?>
				<ul class="m-rows" data-dates>
					<?php foreach ( $upcoming as $event ) : ?>
						<li class="m-rows__row">
							<span class="m-rows__date"><?php echo esc_html( wp_date( 'M j · D', $event['date'] ) ); ?></span>
							<a class="m-rows__title" href="<?php echo esc_url( $event['url'] ); ?>"><?php echo esc_html( $event['title'] ); ?></a>
							<span class="m-rows__meta"><span><?php echo esc_html( $event['detail'] ); ?></span><?php echo $event['org'] ? '<span class="m-rows__org">' . esc_html( $event['org'] ) . '</span>' : ''; ?></span>
							<span class="m-rows__side"><a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $event['url'] ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( ! $visibleOrgs && ! $myProjects && ! $whatsNew && ! $upcoming ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message">
					<?php if ( $isStandalone ) : ?>
						<?php
						/* translators: %s: site name */
						printf( esc_html__( 'Nothing waiting for you yet. New material appears here as %s publishes it.', 'monstera' ), esc_html( $siteName ) );
						?>
					<?php else : ?>
						<?php esc_html_e( 'Nothing waiting for you yet. Your account team will set things up.', 'monstera' ); ?>
					<?php endif; ?>
				</p>
			</div>
		<?php endif; ?>

	</div>

	<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'Activity and people', 'monstera' ); ?>">
		<div class="m-rail-block">
			<h3><?php esc_html_e( 'Your recent activity', 'monstera' ); ?></h3>
			<?php if ( $ownActivity ) : ?>
				<ul class="m-ticker">
					<?php foreach ( $ownActivity as $act ) : ?>
						<li>
							<?php
							// One sentence, its parts end to end: the thing it names is
							// the link, the words around it are the reader's own act.
							foreach ( $act['parts'] as $part ) {
								if ( isset( $part['url'] ) ) {
									echo '<a href="' . esc_url( $part['url'] ) . '">' . esc_html( $part['text'] ) . '</a>';
								} else {
									echo esc_html( $part['text'] );
								}
							}
							?>
							<time datetime="<?php echo esc_attr( gmdate( 'c', $act['at'] ) ); ?>">
								<?php echo esc_html( human_time_diff( $act['at'] ) ); ?> <?php esc_html_e( 'ago', 'monstera' ); ?>
							</time>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<?php // One sentence for every reader: it names nobody, so it has no standalone variant. ?>
				<p class="m-rail-block__empty">
					<?php esc_html_e( 'Nothing yet. What you open, download and send appears here.', 'monstera' ); ?>
				</p>
			<?php endif; ?>
		</div>

		<?php
		// Sub-groups (association) or account team (agency; At-a-glance
		// track, FR4 portal; comps 20 and 23). Each of the reader's
		// organizations' account lead comes first, as "Account lead ·
		// <organization>" with their address, in the order of the reader's
		// organizations, while still staff and assigned (Portal\Leads); then
		// the others assigned to the reader's organizations, once each, by
		// their position or "Team", while still staff. The assignments were
		// read with the rosters above and the people are read together, so
		// six organizations ask nothing three do not. When none of theirs has
		// anybody assigned, the block is the team's first five with their
		// positions, as before, and so it is for staff, whose bands are the
		// site's organizations; a standalone member reads "Your contacts at
		// <site>" and no account words.
		$accountTeam = [];
		$leading     = [];
		$byPosition  = true;
		if ( $myProjects ) {
			$assigned = [];
			if ( ! $isStandalone && NextStep::addressedTo( $user ) ) {
				$leadIds = [];
				foreach ( $orgBands as $band ) {
					$leadIds[] = $orgRepo->accountLeadId( (int) $band['id'] );
					foreach ( Roster::staffIds( $band['id'] ) as $staffId ) {
						$assigned[ $staffId ] = true;
					}
				}
				// The leads and the assigned, with their meta, in one read, and
				// the leads' own rows, which say whether they are still assigned.
				$people = array_values( array_unique( array_filter( array_merge( $leadIds, array_keys( $assigned ) ) ) ) );
				cache_users( $people );
				Roster::prime( array_values( array_filter( $leadIds ) ) );
				foreach ( $orgBands as $band ) {
					$lead = Leads::account( (int) $band['id'] );
					if ( $lead ) {
						$leading[ (int) $lead->ID ][] = $band['name'];
					}
				}
			}
			$teamIds = array_values( array_unique( array_merge( array_keys( $leading ), array_keys( $assigned ) ) ) );
			// Still staff when the page is read: a role changed by hand waits
			// a day for the sweep, as Portal\Leads checks the leads.
			$accountTeam = array_values(
				array_filter(
					array_map( 'get_userdata', $teamIds ),
					static fn ( $person ): bool => $person instanceof \WP_User && Capabilities::isStaff( $person )
				)
			);
			$byPosition  = ! $accountTeam;
			if ( $byPosition ) {
				$accountTeam = get_users(
					[
						'role__in' => [ Capabilities::ROLE_ADMIN, Capabilities::ROLE_TEAM_MEMBER ],
						'number'   => 5,
						'fields'   => 'all',
					]
				);
			}
			// Their photos are attachments: one read for all of them.
			_prime_post_caches( array_filter( array_map( static fn ( $person ) => (int) get_user_meta( $person->ID, UserMeta::KEY_PROFILE_PHOTO, true ), $accountTeam ) ), false, true );
		}
		?>

		<?php if ( $mySubgroups && ! $myProjects ) : ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Your sub-groups', 'monstera' ); ?></h3>
				<ul class="m-ticker">
					<?php
					foreach ( $mySubgroups as $sgId ) :
						$sg = $subgroupRepo->find( $sgId );
						if ( ! $sg ) {
							continue;
						}
						$leaderId = (int) get_post_meta( $sgId, 'monstera_subgroup_leader_id', true );
						$leader   = $leaderId ? get_userdata( $leaderId ) : null;
						?>
						<li>
							<strong><?php echo esc_html( get_the_title( $sg ) ); ?></strong>
							<?php if ( $leader ) : ?>
								<small>
								<?php
									/* translators: %s: leader display name */
									printf( esc_html__( 'chaired by %s', 'monstera' ), esc_html( $leader->display_name ) );
								?>
								</small>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php elseif ( $accountTeam ) : ?>
			<div class="m-rail-block">
				<?php
				/* translators: %s: site name */
				$teamHeading = $isStandalone ? sprintf( __( 'Your contacts at %s', 'monstera' ), $siteName ) : __( 'Your account team', 'monstera' );
				?>
				<h3><?php echo esc_html( $teamHeading ); ?></h3>
				<ul class="m-people">
					<?php
					foreach ( $accountTeam as $member ) :
						// An account lead reads as one, with the reader's organizations
						// they lead, and their address; anyone else by their own
						// position, or "Team" when they gave none.
						$leads    = $leading[ $member->ID ] ?? [];
						$position = trim( (string) get_user_meta( $member->ID, UserMeta::KEY_POSITION, true ) );
						if ( $leads ) {
							/* translators: %s: the organization the person is the account lead of, or several separated by commas */
							$position = sprintf( __( 'Account lead · %s', 'monstera' ), implode( __( ', ', 'monstera' ), $leads ) );
						} elseif ( '' === $position && ! $byPosition ) {
							$position = __( 'Team', 'monstera' );
						}
						$photoUrl = UserMeta::photoUrl( (int) $member->ID );
						$name     = UserMeta::fullName( $member );
						?>
						<li>
							<span class="m-avatar" aria-hidden="true"<?php echo $leads && ! $photoUrl ? ' data-staff' : ''; ?>>
								<?php if ( $photoUrl ) : ?>
									<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
								<?php elseif ( $leads ) : ?>
									<?php \Monstera\Core\Icons::sprig(); ?>
								<?php else : ?>
									<?php \Monstera\Core\Icons::emit( 'sprout', 18 ); ?>
								<?php endif; ?>
							</span>
							<span>
								<?php if ( $leads && is_email( $member->user_email ) ) : ?>
									<?php
									// The link says it writes to them, to a screen reader; the
									// visible name stays its label. One sentence for translators,
									// split around the name.
									/* translators: %s: the name of the person the link writes to */
									$emailParts = explode( '%s', __( 'Email %s', 'monstera' ), 2 ) + [ '', '' ];
									?>
									<a href="<?php echo esc_url( 'mailto:' . $member->user_email ); ?>"><?php echo '' !== $emailParts[0] ? '<span class="m-sr-only">' . esc_html( $emailParts[0] ) . '</span>' : ''; ?><?php echo esc_html( $name ); ?><?php echo '' !== $emailParts[1] ? '<span class="m-sr-only">' . esc_html( $emailParts[1] ) . '</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped parts of a fixed span. ?></a>
								<?php else : ?>
									<?php echo esc_html( $name ); ?>
								<?php endif; ?>
								<?php if ( $position ) : ?>
									<small><?php echo esc_html( $position ); ?></small>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW ) ); ?>"><?php esc_html_e( 'Open a support request →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( $resolvedNotes ) : ?>
			<?php // The notices that were ended, latest first: plain words, an ended notice having no page to link. ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Notices', 'monstera' ); ?></h3>
				<ul class="m-ticker">
					<?php foreach ( $resolvedNotes as $note ) : ?>
						<li>
							<?php
							/* translators: %s: the title of an alert that was ended */
							echo esc_html( sprintf( __( 'Resolved: %s', 'monstera' ), $note['title'] ) );
							?>
							<time datetime="<?php echo esc_attr( gmdate( 'c', $note['at'] ) ); ?>">
								<?php echo esc_html( human_time_diff( $note['at'] ) ); ?> <?php esc_html_e( 'ago', 'monstera' ); ?>
							</time>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
	</aside>
</div>
</div>
