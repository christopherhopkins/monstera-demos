<?php
/**
 * Portal dashboard — `/portal/` (personal home).
 *
 * Distinct from the per-org content hub at `/portal/{org-slug}/`:
 *  - the org hub is the *org's* room (cover, tabs, deep browse)
 *  - the dashboard is the *user's* day (greeting, your orgs, what's new,
 *    your projects, upcoming, recent activity)
 *
 * Composition (2026-09 design review, comps 20–22):
 *   • greeting hero (time-of-day aware); the profile nudge is the shell's
 *   • one org band per visible org (none for a standalone member)
 *   • main column — Your projects as rows with the stage meter (3) ·
 *     What's new for you as the list (5) · Coming up rows
 *   • rail from 1024 — Recent activity ticker · Sub-groups or account team
 *
 * No full content table here — the deep inventory lives on the org hub.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertsRepository;
use Monstera\Content\Downloader;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\Repository as ContentRepository;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Portal\Audience;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

$user         = $ctx['user'];
$isStandalone = Audience::isStandalone( (int) $user->ID );
$siteName     = Audience::siteName();
$contentRepo  = new ContentRepository();
$subgroupRepo = new SubgroupRepository();
$projectRepo  = new ProjectRepository();
$orgRepo      = new OrgRepository();
$visibility   = new Visibility( $subgroupRepo, $projectRepo );

$projectsActive = Modules::isActive( Modules::PROJECTS );

// Resolve the orgs this user can see. Members see their associated org;
// admins / agency staff see every org. Single-org users get one big card.
$userOrgId   = UserMeta::associatedOrg( $user->ID );
$isAdmin     = user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
$visibleOrgs = $isAdmin
	? $orgRepo->all( [ 'posts_per_page' => 12 ] )
	: ( $userOrgId ? array_filter( [ $orgRepo->findById( $userOrgId ) ] ) : [] );

$orgIdsInScope = array_map( static fn ( $o ) => (int) $o->ID, $visibleOrgs );

// Cross-org content the user can actually see, newest first, trimmed.
$contentPosts = $orgIdsInScope
	? $contentRepo->forOrgs( $orgIdsInScope, [ 'posts_per_page' => 50 ] )
	: $contentRepo->forStandalone( (int) $user->ID, [ 'posts_per_page' => 50 ] );
$contentRows  = array_filter(
	$contentRepo->summarize( $contentPosts ),
	static fn ( $r ) => $visibility->userCanSee( $user, $r['id'] )
);
usort(
	$contentRows,
	static fn ( $a, $b ) => strtotime( (string) $b['date'] ) <=> strtotime( (string) $a['date'] )
);
$whatsNew = array_slice( $contentRows, 0, 5, true );

// The rail's ticker: what's new, plus one "Resolved" note for each alert
// that was ended for everyone in the last fortnight and had reached you.
$ticker = array_map(
	static fn ( $r ) => [
		'title' => (string) $r['title'],
		'url'   => Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $r['id'] ] ),
		'date'  => (string) $r['date'],
	],
	array_values( $whatsNew )
);
if ( Modules::isActive( Modules::ALERTS ) ) {
	foreach ( ( new AlertsRepository() )->endedFor( $user ) as $ended ) {
		$ticker[] = [
			/* translators: %s: the title of an alert that was ended */
			'title' => sprintf( __( 'Resolved: %s', 'monstera' ), get_the_title( $ended ) ),
			'url'   => '',
			'date'  => gmdate( 'c', (int) strtotime( get_post_meta( $ended->ID, AlertMeta::KEY_ENDED_AT, true ) . ' UTC' ) ),
		];
	}
}
usort( $ticker, static fn ( $a, $b ) => strtotime( $b['date'] ) <=> strtotime( $a['date'] ) );
$ticker = array_slice( $ticker, 0, 5 );

// Personal projects feed: union of the user's org's projects and any
// projects they're directly on the team for. Same query the portal /projects
// list uses, so the dashboard's count matches the destination page.
$myProjects  = $projectsActive ? $projectRepo->forUser( $user->ID, $userOrgId ) : [];
$mySubgroups = $subgroupRepo->subgroupsForMember( $user->ID );

$firstName = $user->first_name ?: $user->display_name ?: __( 'there', 'monstera' );

// Project pipeline stages used by the dashboard strip.
$pipelineStages = [
	ProjectMeta::STATUS_PROPOSED,
	ProjectMeta::STATUS_DISCOVERY,
	ProjectMeta::STATUS_IN_PROGRESS,
	ProjectMeta::STATUS_REVIEW,
	ProjectMeta::STATUS_COMPLETED,
];

// "Coming up" — upcoming project due dates within 90 days.
$upcoming = [];
foreach ( $myProjects as $project ) {
	$dueOn         = strtotime( (string) get_post_meta( $project->ID, ProjectMeta::KEY_DUE_ON, true ) );
	$projectStatus = $projectRepo->status( $project->ID );
	if ( $dueOn && $dueOn > time() && $dueOn - time() < 90 * DAY_IN_SECONDS && ! in_array( $projectStatus, [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true ) ) {
		$upcoming[] = [
			'date'   => $dueOn,
			'title'  => get_the_title( $project ),
			'detail' => ProjectMeta::statusLabel( $projectStatus ),
			'url'    => Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $project->ID ] ),
		];
	}
}
usort( $upcoming, static fn ( $a, $b ) => $a['date'] <=> $b['date'] );
$upcoming = array_slice( $upcoming, 0, 4 );

$activeProjects      = array_filter(
	$myProjects,
	static function ( $p ) use ( $projectRepo ) {
		return ! in_array( $projectRepo->status( $p->ID ), [ ProjectMeta::STATUS_COMPLETED, ProjectMeta::STATUS_ARCHIVED ], true );
	}
);
$activeProjectsStrip = array_slice( $activeProjects, 0, 3 );

// Per-org meta lookup for the org cards.
$orgCardData = static function ( \WP_Post $org ) use ( $orgRepo, $contentRepo, $visibility, $user ) {
	$orgId      = (int) $org->ID;
	$tierTerms  = wp_get_post_terms( $orgId, 'monstera_org_tier', [ 'fields' => 'names' ] );
	$tier       = is_array( $tierTerms ) ? ( $tierTerms[0] ?? '' ) : '';
	$desc       = (string) get_post_meta( $orgId, OrgMeta::KEY_DESCRIPTION, true );
	$expires    = (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true );
	$members    = $orgRepo->memberCount( $orgId );
	$orgContent = $contentRepo->forOrgs( [ $orgId ], [ 'posts_per_page' => 60 ] );
	$count      = 0;
	foreach ( $orgContent as $post ) {
		if ( $visibility->userCanSee( $user, (int) $post->ID ) ) {
			++$count;
		}
	}
	return [
		'id'      => $orgId,
		'slug'    => $org->post_name,
		'name'    => get_the_title( $org ),
		'tier'    => $tier,
		'desc'    => $desc,
		'expires' => $expires,
		'members' => $members,
		'items'   => $count,
	];
};
?>


<section class="monstera-portal__hero">
	<h1>
		<?php
		$hour = (int) wp_date( 'G' );
		if ( $hour < 12 ) {
			/* translators: %s: member first name. */
			printf( esc_html__( 'Good morning, %s.', 'monstera' ), esc_html( $firstName ) );
		} elseif ( $hour < 18 ) {
			/* translators: %s: member first name. */
			printf( esc_html__( 'Welcome back, %s.', 'monstera' ), esc_html( $firstName ) );
		} else {
			/* translators: %s: member first name. */
			printf( esc_html__( 'Good evening, %s.', 'monstera' ), esc_html( $firstName ) );
		}
		?>
	</h1>
	<p>
		<?php
		$visibleItems = count( $contentRows );
		if ( $myProjects && $visibleItems ) {
			printf(
				$isStandalone
					/* translators: 1: project count, 2: content count */
					? esc_html__( '%1$d projects in flight. %2$d items available to you.', 'monstera' )
					/* translators: 1: project count, 2: content count */
					: esc_html__( '%1$d projects in flight. %2$d items available across your orgs.', 'monstera' ),
				count( $activeProjects ),
				(int) $visibleItems
			);
		} elseif ( $visibleItems ) {
			printf(
				/* translators: %d: number of content items visible to the member. */
				esc_html( _n( '%d item available to you right now.', '%d items available to you right now.', $visibleItems, 'monstera' ) ),
				(int) $visibleItems
			);
		} else {
			esc_html_e( 'Nothing new today. Check back soon, or browse the directory.', 'monstera' );
		}
		?>
	</p>
</section>

<div class="monstera-portal__dash">
<div class="m-dash">
	<div class="m-dash__main">

		<?php
		foreach ( $visibleOrgs as $org ) :
			$o    = $orgCardData( $org );
			$url  = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $o['slug'] ] );
			$mark = strtoupper( mb_substr( (string) preg_replace( '/[^A-Za-z0-9]/', '', $o['name'] ), 0, 2 ) ) ?: 'M';
			?>
			<a class="m-org-band" href="<?php echo esc_url( $url ); ?>">
				<span class="m-org-band__mark" aria-hidden="true"><?php echo esc_html( $mark ); ?></span>
				<span class="m-org-band__name"><?php echo esc_html( $o['name'] ); ?></span>
				<span class="m-org-band__meta">
					<?php if ( $o['tier'] ) : ?>
						<span><?php echo esc_html( $o['tier'] ); ?></span>
					<?php endif; ?>
					<span>
					<?php
						/* translators: %d: member count */
						printf( esc_html( _n( '%d member', '%d members', $o['members'], 'monstera' ) ), (int) $o['members'] );
					?>
					</span>
					<?php if ( $o['expires'] && strtotime( $o['expires'] ) ) : ?>
						<span>
						<?php
							/* translators: %s: renewal date */
							printf( esc_html__( 'Renews %s', 'monstera' ), esc_html( wp_date( 'M j, Y', strtotime( $o['expires'] ) ) ) );
						?>
						</span>
					<?php else : ?>
						<span>
						<?php
							/* translators: %d: content count */
							printf( esc_html( _n( '%d item', '%d items', $o['items'], 'monstera' ) ), (int) $o['items'] );
						?>
						</span>
					<?php endif; ?>
				</span>
				<span class="m-btn m-org-band__action" data-intent="ghost" data-size="sm"><?php esc_html_e( 'Open →', 'monstera' ); ?></span>
			</a>
		<?php endforeach; ?>

		<?php if ( $activeProjectsStrip ) : ?>
			<section class="m-section" aria-labelledby="dash-projects">
				<div class="m-section__head">
					<h2 id="dash-projects"><?php esc_html_e( 'Your projects', 'monstera' ); ?></h2>
					<a class="m-section__link" href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROJECTS ) ); ?>"><?php esc_html_e( 'See all →', 'monstera' ); ?></a>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $activeProjectsStrip as $project ) :
						$pid           = (int) $project->ID;
						$projectStatus = $projectRepo->status( $pid );
						$dueOn         = (string) get_post_meta( $pid, ProjectMeta::KEY_DUE_ON, true );
						$teamSize      = count( $projectRepo->memberIds( $pid ) );
						$currentIndex  = array_search( $projectStatus, $pipelineStages, true );
						if ( false === $currentIndex ) {
							$currentIndex = 0;
						}
						$tone = match ( $projectStatus ) {
							ProjectMeta::STATUS_COMPLETED => 'active',
							ProjectMeta::STATUS_ON_HOLD   => 'suspended',
							ProjectMeta::STATUS_DISCOVERY => 'info',
							ProjectMeta::STATUS_PROPOSED  => 'pending',
							ProjectMeta::STATUS_REVIEW    => 'warning',
							default                       => 'active',
						};
						?>
						<li class="m-rows__row">
							<span class="m-rows__date">
								<?php
								if ( ProjectMeta::STATUS_ON_HOLD === $projectStatus ) {
									esc_html_e( 'on hold', 'monstera' );
								} elseif ( $dueOn ) {
									/* translators: %s: due date */
									printf( esc_html__( 'due %s', 'monstera' ), esc_html( wp_date( 'M j', strtotime( $dueOn ) ) ) );
								}
								?>
							</span>
							<a class="m-rows__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $pid ] ) ); ?>"><?php echo esc_html( get_the_title( $project ) ); ?></a>
							<span class="m-rows__meta">
								<span class="m-badge" data-tone="<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( ProjectMeta::statusLabel( $projectStatus ) ); ?></span>
								<span>
								<?php
									/* translators: %d: team size count */
									printf( esc_html( _n( '%d on team', '%d on team', $teamSize, 'monstera' ) ), (int) $teamSize );
								?>
								</span>
							</span>
							<span class="m-rows__side">
								<?php
								/* translators: 1: current stage number, 2: total stages */
								$stageLabel = sprintf( __( 'Stage %1$d of %2$d', 'monstera' ), (int) $currentIndex + 1, count( $pipelineStages ) );
								?>
								<span class="m-progress" role="img" aria-label="<?php echo esc_attr( $stageLabel ); ?>">
									<?php foreach ( $pipelineStages as $idx => $stage ) : ?>
										<span<?php echo $idx < $currentIndex ? ' data-done' : ( $idx === $currentIndex ? ' data-now' : '' ); ?>></span>
									<?php endforeach; ?>
								</span>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( $whatsNew ) : ?>
			<section class="m-section" aria-labelledby="dash-new">
				<div class="m-section__head">
					<h2 id="dash-new"><?php esc_html_e( 'What\'s new for you', 'monstera' ); ?></h2>
					<?php
					if ( count( $visibleOrgs ) === 1 ) :
						$first = $visibleOrgs[ array_key_first( $visibleOrgs ) ];
						?>
						<a class="m-section__link" href="<?php echo esc_url( Routing::url( Routing::ROUTE_ORG, [ 'slug' => $first->post_name ] ) ); ?>"><?php esc_html_e( 'Browse all →', 'monstera' ); ?></a>
					<?php endif; ?>
				</div>
				<ul class="m-list">
					<?php
					foreach ( $whatsNew as $row ) :
						$fileId     = (int) get_post_meta( $row['id'], ContentMeta::KEY_SECURE_FILE_ID, true );
						$click      = $row['click'];
						$href       = Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] );
						$isDownload = false;
						$isPaused   = false;
						if ( ContentMeta::CLICK_FILE === $click && $fileId ) {
							if ( $visibility->userCanDownload( $user, (int) $row['id'] ) ) {
								$href       = Downloader::signedUrl( $fileId, $user->ID );
								$isDownload = true;
							} else {
								// Suspended org: the item stays readable, the file waits.
								$isPaused = true;
							}
						}
						$rowOrgs = array_map( 'intval', (array) get_post_meta( $row['id'], ContentMeta::KEY_ORG_IDS, true ) );
						$scope   = $rowOrgs ? get_the_title( $rowOrgs[0] ) : $siteName;
						$kind    = ContentMeta::CLICK_FILE === $click ? __( 'File', 'monstera' ) : __( 'Article', 'monstera' );
						$ts      = strtotime( (string) $row['date'] ) ?: 0;
						?>
						<li class="m-list__row">
							<span class="m-list__date"><?php echo esc_html( wp_date( 'M j', $ts ?: null ) ); ?></span>
							<a class="m-list__title" href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $row['id'] ] ) ); ?>"><?php echo esc_html( $row['title'] ); ?></a>
							<span class="m-list__meta"><span><?php echo esc_html( $scope ); ?></span><span><?php echo esc_html( $kind ); ?></span></span>
							<?php if ( $isPaused ) : ?>
								<span class="m-paused m-list__action"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
							<?php else : ?>
								<a class="m-btn m-list__action" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $href ); ?>"<?php echo $isDownload ? ' download' : ''; ?>>
									<?php echo $isDownload ? esc_html__( 'Download →', 'monstera' ) : esc_html__( 'Open →', 'monstera' ); ?>
								</a>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( $upcoming ) : ?>
			<section class="m-section" aria-labelledby="dash-upcoming">
				<div class="m-section__head">
					<h2 id="dash-upcoming"><?php esc_html_e( 'Coming up', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono">
					<?php
						/* translators: %d: number of upcoming dates */
						printf( esc_html( _n( '%d date', '%d dates', count( $upcoming ), 'monstera' ) ), (int) count( $upcoming ) );
					?>
					</span>
				</div>
				<ul class="m-rows">
					<?php foreach ( $upcoming as $event ) : ?>
						<li class="m-rows__row">
							<span class="m-rows__date"><?php echo esc_html( wp_date( 'M j · D', $event['date'] ) ); ?></span>
							<a class="m-rows__title" href="<?php echo esc_url( $event['url'] ); ?>"><?php echo esc_html( $event['title'] ); ?></a>
							<span class="m-rows__meta"><span><?php echo esc_html( $event['detail'] ); ?></span></span>
							<span class="m-rows__side"><a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $event['url'] ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( ! $visibleOrgs && ! $myProjects && ! $whatsNew ) : ?>
			<div class="m-empty">
				<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
				<p class="m-empty__message">
					<?php if ( $isStandalone ) : ?>
						<?php
						/* translators: %s: site name */
						printf( esc_html__( 'Nothing waiting for you yet. New material appears here as %s publishes it.', 'monstera' ), esc_html( $siteName ) );
						?>
					<?php else : ?>
						<?php esc_html_e( 'Nothing waiting for you yet. Your account team will set things up.', 'monstera' ); ?>
					<?php endif; ?>
				</p>
			</div>
		<?php endif; ?>

	</div>

	<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'Activity and people', 'monstera' ); ?>">
		<div class="m-rail-block">
			<h3><?php esc_html_e( 'Recent activity', 'monstera' ); ?></h3>
			<?php if ( $ticker ) : ?>
				<ul class="m-ticker">
					<?php foreach ( $ticker as $row ) : ?>
						<li>
							<?php if ( $row['url'] ) : ?>
								<a href="<?php echo esc_url( $row['url'] ); ?>"><?php echo esc_html( $row['title'] ); ?></a>
							<?php else : ?>
								<strong><?php echo esc_html( $row['title'] ); ?></strong>
							<?php endif; ?>
							<time datetime="<?php echo esc_attr( $row['date'] ); ?>">
								<?php echo esc_html( human_time_diff( strtotime( $row['date'] ) ) ); ?> <?php esc_html_e( 'ago', 'monstera' ); ?>
							</time>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="m-rail-block__empty">
					<?php if ( $isStandalone ) : ?>
						<?php
						/* translators: %s: site name */
						printf( esc_html__( 'Nothing recent. Activity appears here as %s posts.', 'monstera' ), esc_html( $siteName ) );
						?>
					<?php else : ?>
						<?php esc_html_e( 'Nothing recent. Activity will appear here as your account team posts.', 'monstera' ); ?>
					<?php endif; ?>
				</p>
			<?php endif; ?>
		</div>

		<?php
		// Sub-groups (association) or account team (agency).
		$accountTeam = [];
		if ( $myProjects ) {
			$accountTeam = get_users(
				[
					'role__in' => [ Capabilities::ROLE_ADMIN ],
					'number'   => 5,
					'fields'   => 'all',
				]
			);
		}
		?>

		<?php if ( $mySubgroups && ! $myProjects ) : ?>
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Your sub-groups', 'monstera' ); ?></h3>
				<ul class="m-ticker">
					<?php
					foreach ( $mySubgroups as $sgId ) :
						$sg = $subgroupRepo->find( $sgId );
						if ( ! $sg ) {
							continue;
						}
						$leaderId = (int) get_post_meta( $sgId, 'monstera_subgroup_leader_id', true );
						$leader   = $leaderId ? get_userdata( $leaderId ) : null;
						?>
						<li>
							<strong><?php echo esc_html( get_the_title( $sg ) ); ?></strong>
							<?php if ( $leader ) : ?>
								<small>
								<?php
									/* translators: %s: leader display name */
									printf( esc_html__( 'chaired by %s', 'monstera' ), esc_html( $leader->display_name ) );
								?>
								</small>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php elseif ( $accountTeam ) : ?>
			<div class="m-rail-block">
				<?php
				/* translators: %s: site name */
				$teamHeading = $isStandalone ? sprintf( __( 'Your contacts at %s', 'monstera' ), $siteName ) : __( 'Your account team', 'monstera' );
				?>
				<h3><?php echo esc_html( $teamHeading ); ?></h3>
				<ul class="m-people">
					<?php
					foreach ( $accountTeam as $member ) :
						$position = (string) get_user_meta( $member->ID, UserMeta::KEY_POSITION, true );
						$photo    = (int) get_user_meta( $member->ID, UserMeta::KEY_PROFILE_PHOTO, true );
						$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
						?>
						<li>
							<span class="m-avatar" aria-hidden="true">
								<?php if ( $photoUrl ) : ?>
									<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
								<?php else : ?>
									<?php \Monstera\Core\Icons::emit( 'sprout', 18 ); ?>
								<?php endif; ?>
							</span>
							<span>
								<?php echo esc_html( trim( $member->first_name . ' ' . $member->last_name ) ?: $member->display_name ); ?>
								<?php if ( $position ) : ?>
									<small><?php echo esc_html( $position ); ?></small>
								<?php endif; ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT_NEW ) ); ?>"><?php esc_html_e( 'Open a support request →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</aside>
</div>
</div>
