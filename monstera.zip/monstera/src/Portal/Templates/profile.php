<?php
/**
 * Member profile editor.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;

$user      = $ctx['user'];
$photo     = (int) get_user_meta( $user->ID, UserMeta::KEY_PROFILE_PHOTO, true );
$photoUrl  = $photo ? wp_get_attachment_image_url( $photo, 'medium' ) : '';
$position  = (string) get_user_meta( $user->ID, UserMeta::KEY_POSITION, true );
$bio       = (string) get_user_meta( $user->ID, UserMeta::KEY_BIO, true );
$showInDir = (bool) get_user_meta( $user->ID, UserMeta::KEY_SHOW_IN_DIRECTORY, true );
$expires   = (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );

// Standalone members (no org) renew their own membership; org members renew
// through their org hub. Offer the self-renew CTA only when renewal is open.
$canSelfRenew = 0 === UserMeta::associatedOrg( $user->ID )
	&& current_user_can( Capabilities::CAP_RENEW_OWN )
	&& Membership::memberRenewalOpen( $user->ID );
$orgId        = UserMeta::associatedOrg( (int) $user->ID );
$orgName      = $orgId ? get_the_title( $orgId ) : '';
$orgExpires   = $orgId ? (string) get_post_meta( $orgId, \Monstera\Organizations\Meta::KEY_EXPIRES, true ) : '';
$roleLabel    = in_array( Capabilities::ROLE_ORG_MANAGER, (array) $user->roles, true ) ? __( 'Manager', 'monstera' ) : __( 'Member', 'monstera' );
$subgroups    = ( new \Monstera\Subgroups\Repository() )->subgroupsForMember( (int) $user->ID );
$memberSince  = $user->user_registered ? strtotime( $user->user_registered ) : false;
$managers     = $orgId ? get_users(
	[
		'role'       => Capabilities::ROLE_ORG_MANAGER,
		'meta_key'   => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design; one org's managers are a handful.
		'meta_value' => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- see above.
		'number'     => 1,
	]
) : [];
$manager      = $managers ? $managers[0] : null;
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Your profile.', 'monstera' ); ?></h1>
	<p><?php esc_html_e( 'How other members find you in the directory.', 'monstera' ); ?></p>
</section>

<div class="monstera-portal__dash">
	<div class="m-dash">
		<div class="m-dash__main">
			<div class="m-toast" role="status" aria-live="polite" data-profile-toast hidden>
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="10" r="7.5"/><path d="M6.5 10.5 9 13l4.5-5.5"/></svg>
				<span><strong><?php esc_html_e( 'Saved.', 'monstera' ); ?></strong> <?php esc_html_e( 'The directory shows your changes now.', 'monstera' ); ?></span>
			</div>

			<form
				method="post"
				class="m-form monstera-profile-form"
				data-plain
				action="<?php echo esc_url( Routing::restUrl( 'monstera/v1/profile/me' ) ); ?>"
				data-wp-on--submit="actions.saveProfile">
				<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>

				<div class="m-photo">
					<span class="m-avatar" data-size="xl" aria-hidden="true">
						<?php if ( $photoUrl ) : ?>
							<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
						<?php else : ?>
							<?php \Monstera\Core\Icons::emit( 'sprout', 48 ); ?>
						<?php endif; ?>
					</span>
					<div class="m-photo__actions">
						<strong><?php echo esc_html( trim( $user->first_name . ' ' . $user->last_name ) ?: $user->display_name ); ?></strong>
					</div>
					<span class="m-photo__hint"><?php esc_html_e( 'Without a photo, members see the leaf.', 'monstera' ); ?></span>
				</div>

				<div class="m-form__row">
					<div class="m-field">
						<label class="m-field__label" for="pf-first"><?php esc_html_e( 'First name', 'monstera' ); ?></label>
						<input class="m-input" id="pf-first" type="text" name="first_name" autocomplete="given-name" value="<?php echo esc_attr( $user->first_name ); ?>" />
					</div>
					<div class="m-field">
						<label class="m-field__label" for="pf-last"><?php esc_html_e( 'Last name', 'monstera' ); ?></label>
						<input class="m-input" id="pf-last" type="text" name="last_name" autocomplete="family-name" value="<?php echo esc_attr( $user->last_name ); ?>" />
					</div>
				</div>

				<div class="m-field">
					<label class="m-field__label" for="pf-position"><?php esc_html_e( 'Position or title', 'monstera' ); ?></label>
					<input class="m-input" id="pf-position" type="text" name="position" autocomplete="organization-title" value="<?php echo esc_attr( $position ); ?>" />
					<span class="m-field__hint"><?php esc_html_e( 'Shown in the member directory.', 'monstera' ); ?></span>
				</div>

				<div class="m-field">
					<label class="m-field__label" for="pf-bio"><?php esc_html_e( 'Short bio', 'monstera' ); ?></label>
					<textarea class="m-textarea" id="pf-bio" name="bio" rows="4"><?php echo esc_textarea( $bio ); ?></textarea>
				</div>

				<label class="m-check">
					<input type="checkbox" class="m-checkbox" name="show_in_directory" value="1" <?php checked( $showInDir ); ?> />
					<?php esc_html_e( 'Include me in the member directory', 'monstera' ); ?>
				</label>

				<div class="m-form__actions">
					<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php esc_html_e( 'Save profile', 'monstera' ); ?></button>
					<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Change password', 'monstera' ); ?></a>
				</div>
			</form>
		</div>

		<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'Your account', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Account', 'monstera' ); ?></h3>
				<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Email', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( $user->user_email ); ?></span></div>
				<?php if ( $orgName ) : ?>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Organization', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( $orgName ); ?></span></div>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Role', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( $roleLabel ); ?></span></div>
				<?php endif; ?>
				<?php if ( $subgroups ) : ?>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Sub-groups', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( implode( ', ', array_map( 'get_the_title', $subgroups ) ) ); ?></span></div>
				<?php endif; ?>
				<?php if ( $memberSince ) : ?>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Member since', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( wp_date( 'M Y', $memberSince ) ); ?></span></div>
				<?php endif; ?>
			</div>

			<?php if ( $orgName && $orgExpires && strtotime( $orgExpires ) ) : ?>
				<div class="m-rail-block">
					<h3><?php esc_html_e( 'Membership', 'monstera' ); ?></h3>
					<p class="m-rail-block__empty">
						<?php
						/* translators: 1: organization name, 2: the date the membership runs to */
						printf( esc_html__( '%1$s\'s membership runs to %2$s.', 'monstera' ), esc_html( $orgName ), esc_html( wp_date( 'M j, Y', strtotime( $orgExpires ) ) ) );
						if ( $manager ) {
							echo ' ';
							/* translators: %s: the manager's name */
							printf( esc_html__( '%s manages renewals.', 'monstera' ), esc_html( $manager->display_name ) );
						}
						?>
					</p>
				</div>
			<?php elseif ( $expires || $canSelfRenew ) : ?>
				<div class="m-rail-block">
					<h3><?php esc_html_e( 'Membership', 'monstera' ); ?></h3>
					<?php if ( $expires ) : ?>
						<p class="m-rail-block__empty">
							<?php
							/* translators: %s: expiry date */
							printf( esc_html__( 'Your membership runs to %s.', 'monstera' ), esc_html( wp_date( 'M j, Y', strtotime( $expires ) ?: null ) ) );
							?>
						</p>
					<?php endif; ?>
					<?php if ( $canSelfRenew ) : ?>
						<p class="m-rail-block__hint"><button type="button" class="m-btn" data-intent="primary" data-size="sm" data-renew data-wp-on--click="actions.startRenewal"><?php esc_html_e( 'Renew membership', 'monstera' ); ?></button></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</aside>
	</div>
</div>
