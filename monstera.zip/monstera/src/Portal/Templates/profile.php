<?php
/**
 * Member profile editor.
 *
 * The rail's account facts (People-model track, FR5): one organization and
 * the role held there for a person with one membership, as before; one row
 * per membership, naming the organization and the tier held there, for a
 * person with several. Self-renewal is for a person with no membership at
 * all; everyone else renews through an organization's hub.
 *
 * The Membership block says when the organization's membership runs to and
 * who renews it. A person in several reads a line for each of theirs under
 * "Memberships": the tier held there and since when, the date that
 * membership runs to or ended, and who renews it when that is someone else.
 * It is the one place on the page that gives a date, so the rail cannot say
 * of an ended membership both that it runs to a day and that it ended then.
 * With one organization the block is one sentence, and so is a standalone
 * member's about their own membership: "runs to" while the date is ahead,
 * as it always read, and "ended" once it has passed, since the guard leaves
 * this page open after the end and the old sentence went on saying "runs
 * to" of a day behind it.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\CalendarDay;

defined( 'ABSPATH' ) || exit;

$user      = $ctx['user'];
$photo     = (int) get_user_meta( $user->ID, UserMeta::KEY_PROFILE_PHOTO, true );
$photoUrl  = $photo ? wp_get_attachment_image_url( $photo, 'medium' ) : '';
$position  = (string) get_user_meta( $user->ID, UserMeta::KEY_POSITION, true );
$bio       = (string) get_user_meta( $user->ID, UserMeta::KEY_BIO, true );
$showInDir = (bool) get_user_meta( $user->ID, UserMeta::KEY_SHOW_IN_DIRECTORY, true );
$expires   = (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );

// Standalone members (no membership) renew their own membership; members of
// an organization renew through its hub. Offer the self-renew CTA only when
// renewal is open. A membership of an organization in the trash is kept for
// its return and still makes the person an organization's member, but the
// page names only those on the site (the review of the At-a-glance track,
// 2026-10-19), so a person in one live organization and one in the trash
// reads the profile of a person in one.
$held         = Roster::membershipsOf( (int) $user->ID );
$canSelfRenew = ! $held
	&& current_user_can( Capabilities::CAP_RENEW_OWN )
	&& Membership::memberRenewalOpen( $user->ID );
$onSite       = array_flip( OrgRepository::onSite( array_map( static fn ( array $one ): int => (int) $one['org_id'], $held ) ) );
$memberships  = array_values( array_filter( $held, static fn ( array $one ): bool => isset( $onSite[ (int) $one['org_id'] ] ) ) );
$orgId        = $memberships ? (int) $memberships[0]['org_id'] : 0;
$orgName      = $orgId ? get_the_title( $orgId ) : '';
$orgExpires   = $orgId ? (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ) : '';
$tierLabel    = static fn ( string $tier ): string => match ( $tier ) {
	Roster::TIER_ADMIN   => __( 'Organization admin', 'monstera' ),
	Roster::TIER_MANAGER => __( 'Manager', 'monstera' ),
	default              => __( 'Member', 'monstera' ),
};
// The role label is the highest tier held in an organization the page names,
// which is what the WordPress role is derived from but for a tier held in
// one in the trash: the label sits beside the one organization a person in
// one reads, and is the tier held there.
$highestTier = Roster::TIER_MEMBER;
foreach ( $memberships as $membership ) {
	if ( Roster::TIER_ADMIN === $membership['tier'] ) {
		$highestTier = Roster::TIER_ADMIN;
	} elseif ( Roster::TIER_MANAGER === $membership['tier'] && Roster::TIER_ADMIN !== $highestTier ) {
		$highestTier = Roster::TIER_MANAGER;
	}
}
$roleLabel   = $tierLabel( $highestTier );
$subgroups   = ( new \Monstera\Subgroups\Repository() )->publishedSubgroupsForMember( (int) $user->ID );
$memberSince = $user->user_registered ? strtotime( $user->user_registered ) : false;
// Who manages renewals: the first admin or manager of the person's one
// organization. A person in several is told for each of theirs, below.
$severalOrgs = count( $memberships ) > 1;
$managerIds  = $orgId && ! $severalOrgs ? Roster::memberIds( $orgId, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ] ) : [];
$manager     = $managerIds ? ( get_userdata( (int) $managerIds[0] ) ?: null ) : null;
// A membership as one sentence: the tier, the organization and since when.
// Each tier is a sentence of its own, so a translation can word it whole.
$heldSince = static fn ( string $tier, string $org, string $since ): string => match ( $tier ) {
	/* translators: 1: organization name, 2: the month the membership began, e.g. "Oct 2026" */
	Roster::TIER_ADMIN   => sprintf( __( 'Organization admin of %1$s since %2$s.', 'monstera' ), $org, $since ),
	/* translators: 1: organization name, 2: the month the membership began, e.g. "Oct 2026" */
	Roster::TIER_MANAGER => sprintf( __( 'Manager of %1$s since %2$s.', 'monstera' ), $org, $since ),
	/* translators: 1: organization name, 2: the month the membership began, e.g. "Oct 2026" */
	default              => sprintf( __( 'Member of %1$s since %2$s.', 'monstera' ), $org, $since ),
};
// Who renews each membership of a person in several, by organization: its
// first admin or manager. Nobody is told about themselves by name, so an
// organization the reader answers for has no entry.
$renewerIds = [];
if ( $severalOrgs ) {
	// Each line names its organization and asks for its date and who
	// renews it: one read of the organizations, one of their admins and
	// managers and one of the people named, however many memberships there
	// are.
	$heldOrgIds = array_map( static fn ( array $held ): int => (int) $held['org_id'], $memberships );
	_prime_post_caches( $heldOrgIds, false, true );
	Roster::primeOrgs( $heldOrgIds );
	foreach ( $heldOrgIds as $heldOrgId ) {
		$leaderIds = Roster::memberIds( $heldOrgId, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ] );
		if ( $leaderIds && ! in_array( (int) $user->ID, $leaderIds, true ) ) {
			$renewerIds[ $heldOrgId ] = (int) $leaderIds[0];
		}
	}
	cache_users( array_values( $renewerIds ) );
}
?>

<section class="monstera-portal__hero">
	<h1><?php esc_html_e( 'Your profile.', 'monstera' ); ?></h1>
	<p><?php esc_html_e( 'How other members find you in the directory.', 'monstera' ); ?></p>
</section>

<div class="monstera-portal__dash">
	<div class="m-dash">
		<div class="m-dash__main">
			<div class="m-toast" role="status" aria-live="polite" data-profile-toast hidden>
				<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="10" r="7.5"/><path d="M6.5 10.5 9 13l4.5-5.5"/></svg>
				<span><strong><?php esc_html_e( 'Saved.', 'monstera' ); ?></strong> <?php esc_html_e( 'The directory shows your changes now.', 'monstera' ); ?></span>
			</div>

			<form
				method="post"
				class="m-form monstera-profile-form"
				data-plain
				action="<?php echo esc_url( Routing::restUrl( 'monstera/v1/profile/me' ) ); ?>"
				data-wp-on--submit="actions.saveProfile">
				<?php wp_nonce_field( 'wp_rest', '_wpnonce', false ); ?>

				<div class="m-photo">
					<span class="m-avatar" data-size="xl" aria-hidden="true">
						<?php if ( $photoUrl ) : ?>
							<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
						<?php else : ?>
							<?php \Monstera\Core\Icons::emit( 'sprout', 48 ); ?>
						<?php endif; ?>
					</span>
					<div class="m-photo__actions">
						<strong><?php echo esc_html( trim( $user->first_name . ' ' . $user->last_name ) ?: $user->display_name ); ?></strong>
					</div>
					<span class="m-photo__hint"><?php esc_html_e( 'Without a photo, members see the leaf.', 'monstera' ); ?></span>
				</div>

				<div class="m-form__row">
					<div class="m-field">
						<label class="m-field__label" for="pf-first"><?php esc_html_e( 'First name', 'monstera' ); ?></label>
						<input class="m-input" id="pf-first" type="text" name="first_name" autocomplete="given-name" value="<?php echo esc_attr( $user->first_name ); ?>" />
					</div>
					<div class="m-field">
						<label class="m-field__label" for="pf-last"><?php esc_html_e( 'Last name', 'monstera' ); ?></label>
						<input class="m-input" id="pf-last" type="text" name="last_name" autocomplete="family-name" value="<?php echo esc_attr( $user->last_name ); ?>" />
					</div>
				</div>

				<div class="m-field">
					<label class="m-field__label" for="pf-position"><?php esc_html_e( 'Position or title', 'monstera' ); ?></label>
					<input class="m-input" id="pf-position" type="text" name="position" autocomplete="organization-title" value="<?php echo esc_attr( $position ); ?>" />
					<span class="m-field__hint"><?php esc_html_e( 'Shown in the member directory.', 'monstera' ); ?></span>
				</div>

				<div class="m-field">
					<label class="m-field__label" for="pf-bio"><?php esc_html_e( 'Short bio', 'monstera' ); ?></label>
					<textarea class="m-textarea" id="pf-bio" name="bio" rows="4"><?php echo esc_textarea( $bio ); ?></textarea>
				</div>

				<label class="m-check">
					<input type="checkbox" class="m-checkbox" name="show_in_directory" value="1" <?php checked( $showInDir ); ?> />
					<?php esc_html_e( 'Include me in the member directory', 'monstera' ); ?>
				</label>

				<div class="m-form__actions">
					<button class="m-btn" data-intent="primary" data-size="md" type="submit"><?php esc_html_e( 'Save profile', 'monstera' ); ?></button>
					<a class="m-btn" data-intent="ghost" data-size="md" href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Change password', 'monstera' ); ?></a>
				</div>
			</form>
		</div>

		<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'Your account', 'monstera' ); ?>">
			<div class="m-rail-block">
				<h3><?php esc_html_e( 'Account', 'monstera' ); ?></h3>
				<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Email', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( $user->user_email ); ?></span></div>
				<?php if ( $severalOrgs ) : ?>
					<?php
					// One row per membership: the organization and the tier held
					// there. Its date is the Memberships block's to give, which
					// tells a membership that has ended from one that runs on.
					foreach ( $memberships as $membership ) :
						?>
						<div class="m-stat"><span class="m-stat__label"><?php echo esc_html( get_the_title( (int) $membership['org_id'] ) ); ?></span><span class="m-stat__value"><?php echo esc_html( $tierLabel( (string) $membership['tier'] ) ); ?></span></div>
					<?php endforeach; ?>
				<?php elseif ( $orgName ) : ?>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Organization', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( $orgName ); ?></span></div>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Role', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( $roleLabel ); ?></span></div>
				<?php endif; ?>
				<?php if ( $subgroups ) : ?>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Sub-groups', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( implode( ', ', array_map( 'get_the_title', $subgroups ) ) ); ?></span></div>
				<?php endif; ?>
				<?php if ( $memberSince ) : ?>
					<div class="m-stat"><span class="m-stat__label"><?php esc_html_e( 'Member since', 'monstera' ); ?></span><span class="m-stat__value"><?php echo esc_html( wp_date( 'M Y', $memberSince ) ); ?></span></div>
				<?php endif; ?>
			</div>

			<?php if ( $severalOrgs ) : ?>
				<div class="m-rail-block">
					<h3><?php esc_html_e( 'Memberships', 'monstera' ); ?></h3>
					<?php
					// One line per membership, each a sentence or two that stand on
					// their own: the tier held there and since when, the date the
					// organization's membership runs to or ended, and who renews it
					// when that is not the reader. Renewal is spoken of only where
					// there is a date to renew by.
					foreach ( $memberships as $membership ) :
						$heldOrgId   = (int) $membership['org_id'];
						$heldExpires = (string) get_post_meta( $heldOrgId, OrgMeta::KEY_EXPIRES, true );
						$heldEndsTs  = CalendarDay::start( $heldExpires )?->getTimestamp() ?? false;
						$renewer     = $heldEndsTs && isset( $renewerIds[ $heldOrgId ] ) ? ( get_userdata( $renewerIds[ $heldOrgId ] ) ?: null ) : null;
						?>
						<p class="m-rail-block__empty">
							<?php
							echo esc_html( $heldSince( (string) $membership['tier'], (string) get_the_title( $heldOrgId ), wp_date( 'M Y', strtotime( $membership['since'] . ' UTC' ) ?: null ) ) );
							if ( $heldEndsTs ) {
								echo ' ';
								if ( PortalGuard::membershipExpired( $heldOrgId ) ) {
									/* translators: %s: the date the organization's membership ended */
									printf( esc_html__( 'Its membership ended %s.', 'monstera' ), esc_html( wp_date( 'M j, Y', $heldEndsTs ) ) );
								} else {
									/* translators: %s: the date the organization's membership runs to */
									printf( esc_html__( 'Its membership runs to %s.', 'monstera' ), esc_html( wp_date( 'M j, Y', $heldEndsTs ) ) );
								}
							}
							if ( $renewer ) {
								echo ' ';
								/* translators: %s: the manager's name */
								printf( esc_html__( '%s manages renewals.', 'monstera' ), esc_html( $renewer->display_name ) );
							}
							?>
						</p>
					<?php endforeach; ?>
				</div>
			<?php elseif ( $orgName && $orgExpires && strtotime( $orgExpires ) ) : ?>
				<div class="m-rail-block">
					<h3><?php esc_html_e( 'Membership', 'monstera' ); ?></h3>
					<p class="m-rail-block__empty">
						<?php
						// A date that has passed is not one the membership runs to.
						// The profile stays open after it, so its member reads this
						// the day after, and the block for a person in several
						// already tells the two apart.
						if ( PortalGuard::membershipExpired( $orgId ) ) {
							/* translators: 1: organization name, 2: the date the membership ended */
							printf( esc_html__( 'The membership of %1$s ended %2$s.', 'monstera' ), esc_html( $orgName ), esc_html( CalendarDay::format( $orgExpires, 'M j, Y' ) ) );
						} else {
							/* translators: 1: organization name, 2: the date the membership runs to */
							printf( esc_html__( 'The membership of %1$s runs to %2$s.', 'monstera' ), esc_html( $orgName ), esc_html( CalendarDay::format( $orgExpires, 'M j, Y' ) ) );
						}
						if ( $manager ) {
							echo ' ';
							/* translators: %s: the manager's name */
							printf( esc_html__( '%s manages renewals.', 'monstera' ), esc_html( $manager->display_name ) );
						}
						?>
					</p>
				</div>
			<?php elseif ( $expires || $canSelfRenew ) : ?>
				<div class="m-rail-block">
					<h3><?php esc_html_e( 'Membership', 'monstera' ); ?></h3>
					<?php if ( $expires ) : ?>
						<p class="m-rail-block__empty">
							<?php
							if ( PortalGuard::dateHasPassed( $expires ) ) {
								/* translators: %s: the date the membership ended */
								printf( esc_html__( 'Your membership ended %s.', 'monstera' ), esc_html( CalendarDay::format( (string) $expires, 'M j, Y' ) ?: wp_date( 'M j, Y' ) ) );
							} else {
								/* translators: %s: expiry date */
								printf( esc_html__( 'Your membership runs to %s.', 'monstera' ), esc_html( CalendarDay::format( (string) $expires, 'M j, Y' ) ?: wp_date( 'M j, Y' ) ) );
							}
							?>
						</p>
					<?php endif; ?>
					<?php if ( $canSelfRenew ) : ?>
						<p class="m-rail-block__hint"><button type="button" class="m-btn" data-intent="primary" data-size="sm" data-renew data-wp-on--click="actions.startRenewal"><?php esc_html_e( 'Renew membership', 'monstera' ); ?></button></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</aside>
	</div>
</div>
