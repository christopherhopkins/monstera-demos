<?php
/**
 * Single content item view — editorial reading layout.
 *
 * Composition (2026-09 design review, comp 60):
 *  - Breadcrumb, then the article head: kickers, title, summary, byline on
 *    the left and the sticky download panel (file, one action, three facts)
 *    on the right from 1024, under it on a phone
 *  - The reading column at 70ch in the dashboard grid, the back link in
 *    the foot (a pending item is denied by the visibility engine for every
 *    reader, so no pending line renders here)
 *  - Related items and people in the rail
 *  - The shell renders the suspended soft block; the panel says paused
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Content\Downloader;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\SecureFiles;
use Monstera\Content\Visibility;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Portal\Audience;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

$user        = $ctx['user'];
$contentId   = (int) get_query_var( Routing::PARAM_ID );
$contentPost = get_post( $contentId );
$subgroups   = new SubgroupRepository();
$projects    = new ProjectRepository();
$visibility  = new Visibility( $subgroups, $projects );
$secureFiles = new SecureFiles();

if ( ! $contentPost || ContentPostType::SLUG !== $contentPost->post_type || ! $visibility->userCanSee( $user, $contentId ) ) {
	// The blocked pattern (comps 31-33). The portal guard answers first on a
	// request; this is what the template says when it is reached all the same.
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not shared with you', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'You don\'t have access to this item.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( 'It may have been removed, or your access changed. %s if this seems wrong.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It may have been removed, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

// A member reading the item counts as one view a day (Reporting\Tracking).
\Monstera\Reporting\Tracking::contentViewed( $contentId, (int) $user->ID );

$canDownload = $visibility->userCanDownload( $user, $contentId );
$fileId      = (int) get_post_meta( $contentId, ContentMeta::KEY_SECURE_FILE_ID, true );
$summary     = (string) get_post_meta( $contentId, ContentMeta::KEY_SUMMARY, true );

$fileRow       = $fileId ? $secureFiles->findById( $fileId ) : null;
$fileName      = $fileRow ? (string) ( $fileRow['original_name'] ?: basename( (string) ( $fileRow['storage_path'] ?? '' ) ) ) : '';
$fileSizeBytes = $fileRow ? (int) $fileRow['filesize'] : 0;
$fileSha       = $fileRow ? (string) ( $fileRow['sha256'] ?? '' ) : '';
$fileExtension = $fileName ? strtoupper( pathinfo( $fileName, PATHINFO_EXTENSION ) ?: '' ) : '';

$contentSubgroups = $subgroups->subgroupsForContent( $contentId );
$contentProjects  = $projects->projectsForContent( $contentId );
$contentOrgIds    = array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true ) );

$author     = get_userdata( (int) $contentPost->post_author );
$publishTs  = (int) get_post_time( 'U', true, $contentPost );
$modifiedTs = (int) get_post_modified_time( 'U', true, $contentPost );
$wasUpdated = $modifiedTs && $publishTs && ( $modifiedTs - $publishTs ) > 60;

// Audience size: members in the content's associated orgs.
$audienceCount = 0;
foreach ( $contentOrgIds as $coId ) {
	$audienceCount += (int) count(
		(array) get_users(
			[
				'meta_key' => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
			'meta_value'   => (string) $coId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
			'fields'       => 'ID',
			'number'       => -1,
			]
		)
	);
}

$signedUrl = ( $fileId && $canDownload ) ? Downloader::signedUrl( $fileId, $user->ID ) : '';

// Related content within the same org/sub-group (max 4).
$related = [];
if ( $contentOrgIds ) {
	$relatedQuery = new WP_Query(
		[
			'post_type'      => ContentPostType::SLUG,
			'post_status'    => 'publish',
			'posts_per_page' => 6,
			'post__not_in'   => [ $contentId ],
			'meta_query'     => [
				[
					'key'     => ContentMeta::KEY_ORG_IDS,
					'value'   => sprintf( ':%d;', $contentOrgIds[0] ),
					'compare' => 'LIKE',
				],
			],
			'no_found_rows'  => true,
		]
	);
	foreach ( $relatedQuery->posts as $r ) {
		if ( $visibility->userCanSee( $user, $r->ID ) ) {
			$related[] = $r;
			if ( count( $related ) >= 4 ) {
				break;
			}
		}
	}
}

// People list: project team if scoped to a project, else sub-group members.
$people        = [];
$peopleHeading = '';
if ( $contentProjects ) {
	$pid = $contentProjects[0];
	/* translators: %s: project title. */
	$peopleHeading = sprintf( __( 'On the %s project', 'monstera' ), get_the_title( $pid ) );
	foreach ( array_slice( $projects->memberIds( $pid ), 0, 6 ) as $memberId ) {
		$person = get_userdata( $memberId );
		if ( $person ) {
			$people[] = $person;
		}
	}
} elseif ( $contentSubgroups ) {
	$sgId = $contentSubgroups[0];
	/* translators: %s: sub-group title. */
	$peopleHeading = sprintf( __( 'In the %s sub-group', 'monstera' ), get_the_title( $sgId ) );
	foreach ( array_slice( $subgroups->memberIds( $sgId ), 0, 6 ) as $memberId ) {
		$person = get_userdata( $memberId );
		if ( $person ) {
			$people[] = $person;
		}
	}
}

$humanFileSize = static function ( int $bytes ): string {
	if ( $bytes <= 0 ) {
		return '';
	}
	$units = [ 'B', 'KB', 'MB', 'GB' ];
	$last  = count( $units ) - 1;
	$i     = 0;
	while ( $bytes >= 1024 && $i < $last ) {
		$bytes /= 1024;
		++$i;
	}
	return number_format( $bytes, $bytes >= 100 || 0 === $i ? 0 : 1 ) . ' ' . $units[ $i ];
};

$visibilityMeta = (string) ( get_post_meta( $contentId, ContentMeta::KEY_VISIBILITY, true ) ?: ContentMeta::VISIBILITY_PUBLISHED );
?>

<?php
// Breadcrumb: dashboard, the item's first organization when the reader can
// open its hub, then the item.
$primaryOrgId   = $contentOrgIds ? (int) $contentOrgIds[0] : 0;
$primaryOrgSlug = $primaryOrgId ? (string) get_post_field( 'post_name', $primaryOrgId ) : '';
$primaryOrgName = $primaryOrgId ? (string) get_the_title( $primaryOrgId ) : '';
$backUrl        = Routing::url( Routing::ROUTE_DASHBOARD );
$backLabel      = __( 'Back to dashboard', 'monstera' );
$readerOrgId    = UserMeta::associatedOrg( (int) $user->ID );
$canOpenHub     = $primaryOrgId === $readerOrgId || user_can( $user, 'manage_monstera' );
if ( $primaryOrgSlug && $canOpenHub ) {
	$backUrl = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $primaryOrgSlug ] );
	/* translators: %s: organization name */
	$backLabel = sprintf( __( 'Back to %s', 'monstera' ), $primaryOrgName );
}
$kind = ContentMeta::CLICK_FILE === (string) get_post_meta( $contentId, ContentMeta::KEY_CLICK_BEHAVIOR, true ) ? __( 'Report', 'monstera' ) : __( 'Article', 'monstera' );
?>
<div class="monstera-portal__dash">

	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Dashboard', 'monstera' ); ?></a>
		<?php if ( $primaryOrgSlug && $canOpenHub ) : ?>
			<span aria-hidden="true">/</span>
			<a href="<?php echo esc_url( $backUrl ); ?>"><?php echo esc_html( $primaryOrgName ); ?></a>
		<?php endif; ?>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo esc_html( get_the_title( $contentPost ) ); ?></span>
	</nav>

	<header class="m-article-head">
		<div>
			<div class="m-article-head__kickers">
				<?php if ( $primaryOrgName ) : ?>
					<span class="m-badge" data-tone="brand"><?php echo esc_html( $primaryOrgName ); ?></span>
				<?php endif; ?>
				<span class="m-badge" data-tone="neutral"><?php echo esc_html( $kind ); ?></span>
				<?php
				foreach ( array_slice( $contentProjects, 0, 2 ) as $pid ) :
					$pp = get_post( $pid );
					if ( ! $pp ) {
						continue;
					}
					?>
					<span class="m-badge" data-tone="info"><?php echo esc_html( get_the_title( $pp ) ); ?></span>
				<?php endforeach; ?>
				<?php
				foreach ( array_slice( $contentSubgroups, 0, 2 ) as $sgId ) :
					$sg = $subgroups->find( $sgId );
					if ( ! $sg ) {
						continue;
					}
					?>
					<span class="m-badge" data-tone="info"><?php echo esc_html( get_the_title( $sg ) ); ?></span>
				<?php endforeach; ?>
				<?php if ( ContentMeta::VISIBILITY_PUBLISHED !== $visibilityMeta ) : ?>
					<span class="m-badge" data-tone="pending"><?php echo esc_html( ucfirst( $visibilityMeta ) ); ?></span>
				<?php endif; ?>
			</div>

			<h1><?php echo esc_html( get_the_title( $contentPost ) ); ?></h1>

			<?php if ( $summary ) : ?>
				<p class="m-article-summary"><?php echo esc_html( wp_strip_all_tags( $summary ) ); ?></p>
			<?php endif; ?>

			<p class="m-article-byline">
				<?php if ( $author ) : ?>
					<span>
						<?php
						printf(
							/* translators: %s: author display name (wrapped in <strong>) */
							esc_html__( 'Prepared by %s', 'monstera' ),
							'<strong>' . esc_html( $author->display_name ) . '</strong>'
						);
						?>
					</span>
					<span aria-hidden="true">·</span>
				<?php endif; ?>
				<time datetime="<?php echo esc_attr( wp_date( 'c', $publishTs ) ); ?>"><?php echo esc_html( wp_date( 'M j, Y', $publishTs ) ); ?></time>
				<?php if ( $wasUpdated ) : ?>
					<span aria-hidden="true">·</span>
					<span>
						<?php
						printf(
							/* translators: %s: human time-diff */
							esc_html__( 'updated %s ago', 'monstera' ),
							esc_html( human_time_diff( $modifiedTs, time() ) )
						);
						?>
					</span>
				<?php endif; ?>
				<?php if ( ! $fileRow ) : ?>
					<span aria-hidden="true">·</span>
					<span><?php esc_html_e( 'No file attached', 'monstera' ); ?></span>
				<?php endif; ?>
			</p>
		</div>

		<?php if ( $fileRow ) : ?>
			<aside class="m-download" aria-label="<?php esc_attr_e( 'File', 'monstera' ); ?>">
				<div class="m-download__file">
					<span class="m-download__ext" aria-hidden="true"><?php echo esc_html( $fileExtension ?: 'FILE' ); ?></span>
					<span>
						<span class="m-download__name"><?php echo esc_html( $fileName ); ?></span>
						<?php if ( $fileSizeBytes ) : ?>
							<span class="m-download__size"><?php echo esc_html( $humanFileSize( $fileSizeBytes ) ); ?></span>
						<?php endif; ?>
					</span>
				</div>

				<?php if ( $canDownload && $signedUrl ) : ?>
					<a class="m-btn" data-intent="primary" data-size="lg" href="<?php echo esc_url( $signedUrl ); ?>" download data-wp-on--click="actions.startDownload">
						<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3v10M5 9l5 5 5-5M3 17h14"/></svg>
						<?php esc_html_e( 'Download file', 'monstera' ); ?>
					</a>
					<div class="m-download__progress" role="status" aria-live="polite" hidden>
						<span><?php esc_html_e( 'Downloading…', 'monstera' ); ?></span>
						<div class="m-download__bar" role="progressbar" aria-label="<?php esc_attr_e( 'Download progress', 'monstera' ); ?>"><span></span></div>
						<span class="m-download__note">
							<?php
							if ( $primaryOrgName ) {
								/* translators: %s: organization name */
								printf( esc_html__( 'This link works for 5 minutes. The download is logged to %s\'s activity.', 'monstera' ), esc_html( $primaryOrgName ) );
							} else {
								esc_html_e( 'This link works for 5 minutes. The download is logged.', 'monstera' );
							}
							?>
						</span>
					</div>
				<?php else : ?>
					<span class="m-paused"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
				<?php endif; ?>

				<ul class="m-download__facts">
					<?php if ( $fileSha ) : ?>
						<li><span><?php esc_html_e( 'SHA-256', 'monstera' ); ?></span><strong><?php echo esc_html( substr( $fileSha, 0, 4 ) . '…' . substr( $fileSha, -4 ) ); ?></strong></li>
					<?php endif; ?>
					<li><span><?php esc_html_e( 'Access window', 'monstera' ); ?></span><strong><?php esc_html_e( '5 min', 'monstera' ); ?></strong></li>
					<?php if ( $audienceCount ) : ?>
						<li>
							<span><?php esc_html_e( 'Visible to', 'monstera' ); ?></span>
							<strong>
								<?php
								printf(
									/* translators: %d: audience count */
									esc_html( _n( '%d member', '%d members', $audienceCount, 'monstera' ) ),
									(int) $audienceCount
								);
								?>
							</strong>
						</li>
					<?php endif; ?>
				</ul>
			</aside>
		<?php endif; ?>
	</header>

	<div class="m-dash">
		<div class="m-dash__main">

			<article class="m-prose">
				<?php echo apply_filters( 'the_content', $contentPost->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput -- the_content pipeline output, the same trust model as a theme template. ?>
			</article>

			<div class="m-article-foot">
				<a class="m-btn" data-intent="ghost" href="<?php echo esc_url( $backUrl ); ?>">← <?php echo esc_html( $backLabel ); ?></a>
			</div>
		</div>

		<aside class="m-dash__rail" aria-label="<?php esc_attr_e( 'Related', 'monstera' ); ?>">
			<?php if ( $related ) : ?>
				<div class="m-rail-block">
					<h3>
						<?php
						$contentSubgroups
							? esc_html_e( 'Related in this sub-group', 'monstera' )
							: esc_html_e( 'Related items', 'monstera' );
						?>
					</h3>
					<ul class="m-ticker">
						<?php foreach ( $related as $r ) : ?>
							<li>
								<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $r->ID ] ) ); ?>"><?php echo esc_html( get_the_title( $r ) ); ?></a>
								<time datetime="<?php echo esc_attr( wp_date( 'c', (int) get_post_time( 'U', true, $r ) ) ); ?>"><?php echo esc_html( wp_date( 'M j, Y', (int) get_post_time( 'U', true, $r ) ) ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( $people && $peopleHeading ) : ?>
				<div class="m-rail-block">
					<h3><?php echo esc_html( $peopleHeading ); ?></h3>
					<ul class="m-people">
						<?php
						foreach ( $people as $person ) :
							$position = (string) get_user_meta( $person->ID, UserMeta::KEY_POSITION, true );
							$photo    = (int) get_user_meta( $person->ID, UserMeta::KEY_PROFILE_PHOTO, true );
							$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
							?>
							<li>
								<span class="m-avatar" aria-hidden="true">
									<?php if ( $photoUrl ) : ?>
										<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
									<?php else : ?>
										<?php \Monstera\Core\Icons::emit( 'sprout', 18 ); ?>
									<?php endif; ?>
								</span>
								<span>
									<?php echo esc_html( trim( $person->first_name . ' ' . $person->last_name ) ?: $person->display_name ); ?>
									<?php if ( $position || $person->ID === $user->ID ) : ?>
										<small>
											<?php
											echo esc_html( $position );
											if ( $person->ID === $user->ID ) {
												echo esc_html( ( $position ? ' · ' : '' ) . __( 'that\'s you', 'monstera' ) );
											}
											?>
										</small>
									<?php endif; ?>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::SUPPORT ) ) : ?>
				<div class="m-rail-block">
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( Routing::url( Routing::ROUTE_SUPPORT ) ); ?>"><?php esc_html_e( 'Ask a question about this item →', 'monstera' ); ?></a></p>
				</div>
			<?php endif; ?>
		</aside>
	</div>
</div>
