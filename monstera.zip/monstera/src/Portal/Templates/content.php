<?php
/**
 * Single content item view — editorial reading layout.
 *
 * Composition (2026-09 design review, comp 60):
 *  - Breadcrumb, then the article head: kickers, title, summary, byline on
 *    the left and the sticky download panel (file, one action, three facts)
 *    on the right from 1024, under it on a phone
 *  - The reading column at 70ch in the dashboard grid, the back link in
 *    the foot (a pending item is denied by the visibility engine for every
 *    reader, so no pending line renders here)
 *  - Related items and people in the rail
 *  - The shell renders the suspended soft block; the panel says paused,
 *    and names the organization when an ended membership holds the file
 *    (the reader's own, for an item for everyone)
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Content\Downloader;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\Readers;
use Monstera\Content\SecureFiles;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Reach;
use Monstera\Portal\Audience;
use Monstera\Portal\Body;
use Monstera\Portal\ContentProjects;
use Monstera\Portal\Context;
use Monstera\Portal\DocumentTitle;
use Monstera\Portal\SubgroupNames;
use Monstera\Portal\SupportPages;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

$user        = $ctx['user'];
$contentId   = (int) get_query_var( Routing::PARAM_ID );
$contentPost = get_post( $contentId );
$subgroups   = new SubgroupRepository();
$projects    = new ProjectRepository();
$visibility  = new Visibility( $subgroups, $projects );
$secureFiles = new SecureFiles();

if ( ! $contentPost || ContentPostType::SLUG !== $contentPost->post_type || ! $visibility->userCanSee( $user, $contentId ) ) {
	// The blocked pattern (comps 31-33). The portal guard answers first on a
	// request; this is what the template says when it is reached all the same.
	DocumentTitle::refused( __( 'Not shared with you', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not shared with you', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'You don\'t have access to this item.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( 'It may have been removed, or your access changed. %s if this seems wrong.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It may have been removed, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

// A member reading the item counts as one view a day (Reporting\Tracking).
\Monstera\Reporting\Tracking::contentViewed( $contentId, (int) $user->ID );

$canDownload = $visibility->userCanDownload( $user, $contentId );
$fileId      = (int) get_post_meta( $contentId, ContentMeta::KEY_SECURE_FILE_ID, true );
$summary     = (string) get_post_meta( $contentId, ContentMeta::KEY_SUMMARY, true );

$fileRow       = $fileId ? $secureFiles->findById( $fileId ) : null;
$fileName      = $fileRow ? (string) ( $fileRow['original_name'] ?: basename( (string) ( $fileRow['storage_path'] ?? '' ) ) ) : '';
$fileSizeBytes = $fileRow ? (int) $fileRow['filesize'] : 0;
$fileSha       = $fileRow ? (string) ( $fileRow['sha256'] ?? '' ) : '';
$fileExtension = $fileName ? strtoupper( pathinfo( $fileName, PATHINFO_EXTENSION ) ?: '' ) : '';

$contentSubgroups = $subgroups->subgroupsForContent( $contentId );
// The projects the item names to its reader, in its head and over the
// people (At-a-glance track, FR6): the ones they may open, oldest first. An
// item on another client's project too does not tell them its name, nor of
// a draft or an ended organization's project (the Task 1 review).
$contentProjects = Modules::isActive( Modules::PROJECTS )
	? ContentProjects::shown( (int) $user->ID, $visibility->projectsOf( [ $contentId ] )[ $contentId ] ?? [] )
	: [];
sort( $contentProjects );
$contentOrgIds = array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true ) );

$author     = get_userdata( (int) $contentPost->post_author );
$publishTs  = (int) get_post_time( 'U', true, $contentPost );
$modifiedTs = (int) get_post_modified_time( 'U', true, $contentPost );
$wasUpdated = $modifiedTs && $publishTs && ( $modifiedTs - $publishTs ) > 60;

// "Visible to N members" in the download panel (the owner, 2026-10-19): a
// reader's own part, the members of their organizations on the site that
// the item reaches who can read it, the reader among them, never another
// client's headcount; the whole count for staff. 0 leaves the line out: a
// standalone reader, an item that reaches them only by name. Asked only
// when the panel shows.
$audienceCount = $fileRow ? Readers::visibleTo( $user, $contentId, $visibility ) : 0;

$signedUrl = ( $fileId && $canDownload ) ? Downloader::signedUrl( $fileId, $user->ID ) : '';

// The organization this page is about for this reader (Portal\Context, the
// shell's chip): the one of the item's organizations they belong to, never
// simply the item's first, which may be one they are not in. The badge, the
// breadcrumb, the back link and the related list all read it. For staff it
// is the item's first; for a reader the item reaches some other way (it
// names them) and for an item for everyone, none.
$contextOrgId   = Context::orgFor( $user, Routing::ROUTE_CONTENT );
$contextOrgSlug = $contextOrgId ? (string) get_post_field( 'post_name', $contextOrgId ) : '';
$contextOrgName = $contextOrgId ? (string) get_the_title( $contextOrgId ) : '';

// A file that waits on a renewal says whose under "Download paused". The
// context organization is the ended one whenever no organization that shares
// the item is still running (Organizations\Reach names an unended one first),
// and the date is read where the guard reads it for its expired page. By URL
// that page answers before this one for an item only an ended organization
// shares; the note is for the template reached all the same. An item for
// everyone is about no organization, so the guard lets its page through
// and the note is what says why there: when the engine's verdict holds the
// file back for an ended membership, it names the first of the reader's
// organizations that has ended, as the verdict lists them.
$endedOrgName = '';
if ( ! $canDownload && $contextOrgId ) {
	$endedOrgName = PortalGuard::membershipExpired( $contextOrgId ) ? $contextOrgName : '';
} elseif ( ! $canDownload ) {
	$verdict = $visibility->evaluate( $user, $contentId );
	foreach ( $verdict->endedBlocked ? $verdict->organizations() : [] as $own ) {
		if ( $own['in_audience'] && $own['ended'] ) {
			$endedOrgName = $own['name'];
			break;
		}
	}
}

// Related content within the same org/sub-group (max 4): the context
// organization's, or the item's first when the page is about none; either
// way only what the reader can see is listed.
$relatedOrgId = $contextOrgId ?: ( $contentOrgIds ? (int) $contentOrgIds[0] : 0 );
$related      = [];
if ( $relatedOrgId > 0 ) {
	$relatedQuery = new WP_Query(
		[
			'post_type'      => ContentPostType::SLUG,
			'post_status'    => 'publish',
			'posts_per_page' => 6,
			'post__not_in'   => [ $contentId ],
			'meta_query'     => [
				[
					'key'     => ContentMeta::KEY_ORG_IDS,
					'value'   => sprintf( ':%d;', $relatedOrgId ),
					'compare' => 'LIKE',
				],
			],
			'no_found_rows'  => true,
		]
	);
	foreach ( $relatedQuery->posts as $r ) {
		if ( $visibility->userCanSee( $user, $r->ID ) ) {
			$related[] = $r;
			if ( count( $related ) >= 4 ) {
				break;
			}
		}
	}
}

// People list: project team if scoped to a project, else sub-group members.
$people        = [];
$peopleHeading = '';
if ( $contentProjects ) {
	$pid = $contentProjects[0];
	/* translators: %s: project title. */
	$peopleHeading = sprintf( __( 'On the %s project', 'monstera' ), get_the_title( $pid ) );
	foreach ( array_slice( $projects->memberIds( $pid ), 0, 6 ) as $memberId ) {
		$person = get_userdata( $memberId );
		if ( $person ) {
			$people[] = $person;
		}
	}
} elseif ( $contentSubgroups ) {
	// One of the item's sub-groups the reader is in, whose people they
	// know: the gate let them in through one, and another may be another
	// client's (the Task 1 review). Staff read the first. Only a published
	// one is named, and only one lets anyone in (a deleted one has no name
	// and no people).
	$openGroups    = SubgroupRepository::published( $contentSubgroups );
	$readersGroups = Capabilities::isStaff( $user ) || user_can( $user, Capabilities::CAP_MANAGE_MONSTERA )
		? $openGroups
		: array_values( array_intersect( $openGroups, $subgroups->subgroupsForMembers( [ (int) $user->ID ] )[ (int) $user->ID ] ?? [] ) );
	$sgId          = (int) ( $readersGroups[0] ?? 0 );
	if ( $sgId > 0 ) {
		/* translators: %s: sub-group title. */
		$peopleHeading = sprintf( __( 'In the %s sub-group', 'monstera' ), get_the_title( $sgId ) );
		foreach ( array_slice( $subgroups->memberIds( $sgId ), 0, 6 ) as $memberId ) {
			$person = get_userdata( $memberId );
			if ( $person ) {
				$people[] = $person;
			}
		}
	}
}

$humanFileSize = static function ( int $bytes ): string {
	if ( $bytes <= 0 ) {
		return '';
	}
	$units = [ 'B', 'KB', 'MB', 'GB' ];
	$last  = count( $units ) - 1;
	$i     = 0;
	while ( $bytes >= 1024 && $i < $last ) {
		$bytes /= 1024;
		++$i;
	}
	return number_format( $bytes, $bytes >= 100 || 0 === $i ? 0 : 1 ) . ' ' . $units[ $i ];
};

$visibilityMeta = (string) ( get_post_meta( $contentId, ContentMeta::KEY_VISIBILITY, true ) ?: ContentMeta::VISIBILITY_PUBLISHED );
?>

<?php
// Breadcrumb: the Portal, the context organization's hub (theirs, or any hub
// for staff), then the item.
$backUrl   = Routing::url( Routing::ROUTE_DASHBOARD );
$backLabel = __( 'Back to the Portal', 'monstera' );
if ( $contextOrgSlug ) {
	$backUrl = Routing::url( Routing::ROUTE_ORG, [ 'slug' => $contextOrgSlug ] );
	/* translators: %s: organization name */
	$backLabel = sprintf( __( 'Back to %s', 'monstera' ), $contextOrgName );
}
$kind = ContentMeta::CLICK_FILE === (string) get_post_meta( $contentId, ContentMeta::KEY_CLICK_BEHAVIOR, true ) ? __( 'Report', 'monstera' ) : __( 'Article', 'monstera' );

// The download note names where the download's activity row is filed, so
// it asks what the log asks (Organizations\Reach): the organization above
// when the item is shared with one of theirs, their first for an item that
// reaches them through none (one for everyone, one that names them), and
// none for staff, who belong to no organization.
$logOrgId   = Reach::ofContent( (int) $user->ID, $contentId );
$logOrgName = $logOrgId ? (string) get_the_title( $logOrgId ) : '';

// Named as the breadcrumb names it, nearest first: the item, then the hub it
// is read through. The Portal is the site's, which the title ends with.
DocumentTitle::name( get_the_title( $contentPost ), $contextOrgSlug ? $contextOrgName : '' );
?>
<div class="monstera-portal__dash">

	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Portal', 'monstera' ); ?></a>
		<?php if ( $contextOrgSlug ) : ?>
			<span aria-hidden="true">/</span>
			<a href="<?php echo esc_url( $backUrl ); ?>"><?php echo esc_html( $contextOrgName ); ?></a>
		<?php endif; ?>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo esc_html( get_the_title( $contentPost ) ); ?></span>
	</nav>

	<header class="m-article-head">
		<div>
			<div class="m-article-head__kickers">
				<?php if ( $contextOrgName ) : ?>
					<span class="m-badge" data-tone="brand"><?php echo esc_html( $contextOrgName ); ?></span>
				<?php endif; ?>
				<span class="m-badge" data-tone="neutral"><?php echo esc_html( $kind ); ?></span>
				<?php
				// Every project of the item the reader may open: the rows name
				// two and count the rest, and this page is where they are all
				// named (At-a-glance track, FR6).
				foreach ( $contentProjects as $pid ) :
					$pp = get_post( $pid );
					if ( ! $pp ) {
						continue;
					}
					?>
					<span class="m-badge" data-tone="info"><?php echo esc_html( get_the_title( $pp ) ); ?></span>
				<?php endforeach; ?>
				<?php
				// The first two of its sub-groups the reader may see named
				// (Portal\SubgroupNames: never another client's).
				foreach ( array_slice( SubgroupNames::shown( $user, $contentSubgroups ), 0, 2 ) as $sgId ) :
					$sg = $subgroups->find( $sgId );
					if ( ! $sg ) {
						continue;
					}
					?>
					<span class="m-badge" data-tone="info"><?php echo esc_html( get_the_title( $sg ) ); ?></span>
				<?php endforeach; ?>
				<?php if ( ContentMeta::VISIBILITY_PUBLISHED !== $visibilityMeta ) : ?>
					<span class="m-badge" data-tone="pending"><?php echo esc_html( ucfirst( $visibilityMeta ) ); ?></span>
				<?php endif; ?>
			</div>

			<h1><?php echo esc_html( get_the_title( $contentPost ) ); ?></h1>

			<?php if ( $summary ) : ?>
				<p class="m-article-summary"><?php echo esc_html( wp_strip_all_tags( $summary ) ); ?></p>
			<?php endif; ?>

			<p class="m-article-byline">
				<?php if ( $author ) : ?>
					<span>
						<?php
						printf(
							/* translators: %s: author display name (wrapped in <strong>) */
							esc_html__( 'Prepared by %s', 'monstera' ),
							'<strong>' . esc_html( $author->display_name ) . '</strong>'
						);
						?>
					</span>
					<span aria-hidden="true">·</span>
				<?php endif; ?>
				<time datetime="<?php echo esc_attr( wp_date( 'c', $publishTs ) ); ?>"><?php echo esc_html( wp_date( 'M j, Y', $publishTs ) ); ?></time>
				<?php if ( $wasUpdated ) : ?>
					<span aria-hidden="true">·</span>
					<span>
						<?php
						printf(
							/* translators: %s: human time-diff */
							esc_html__( 'updated %s ago', 'monstera' ),
							esc_html( human_time_diff( $modifiedTs, time() ) )
						);
						?>
					</span>
				<?php endif; ?>
				<?php if ( ! $fileRow ) : ?>
					<span aria-hidden="true">·</span>
					<span><?php esc_html_e( 'No file attached', 'monstera' ); ?></span>
				<?php endif; ?>
			</p>
		</div>

		<?php if ( $fileRow ) : ?>
			<aside class="m-download" aria-label="<?php esc_attr_e( 'File', 'monstera' ); ?>">
				<div class="m-download__file">
					<span class="m-download__ext" aria-hidden="true"><?php echo esc_html( $fileExtension ?: 'FILE' ); ?></span>
					<span>
						<span class="m-download__name"><?php echo esc_html( $fileName ); ?></span>
						<?php if ( $fileSizeBytes ) : ?>
							<span class="m-download__size"><?php echo esc_html( $humanFileSize( $fileSizeBytes ) ); ?></span>
						<?php endif; ?>
					</span>
				</div>

				<?php if ( $canDownload && $signedUrl ) : ?>
					<a class="m-btn" data-intent="primary" data-size="lg" href="<?php echo esc_url( $signedUrl ); ?>" download data-wp-on--click="actions.startDownload">
						<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3v10M5 9l5 5 5-5M3 17h14"/></svg>
						<?php esc_html_e( 'Download file', 'monstera' ); ?>
					</a>
					<div class="m-download__progress" role="status" aria-live="polite" hidden>
						<span><?php esc_html_e( 'Downloading…', 'monstera' ); ?></span>
						<div class="m-download__bar" role="progressbar" aria-label="<?php esc_attr_e( 'Download progress', 'monstera' ); ?>"><span></span></div>
						<span class="m-download__note">
							<?php
							if ( $logOrgName ) {
								/* translators: %s: organization name */
								printf( esc_html__( 'This link works for 5 minutes. The download is logged to the activity of %s.', 'monstera' ), esc_html( $logOrgName ) );
							} else {
								esc_html_e( 'This link works for 5 minutes. The download is logged.', 'monstera' );
							}
							?>
						</span>
					</div>
				<?php else : ?>
					<span class="m-paused"><svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"><path d="M7 5v10M13 5v10"/></svg><?php esc_html_e( 'Download paused', 'monstera' ); ?></span>
					<?php if ( $endedOrgName ) : ?>
						<span class="m-download__note">
							<?php
							/* translators: %s: organization name */
							printf( esc_html__( 'The membership of %s has ended. The file comes back the moment it is renewed.', 'monstera' ), esc_html( $endedOrgName ) );
							?>
						</span>
					<?php endif; ?>
				<?php endif; ?>

				<ul class="m-download__facts">
					<?php if ( $fileSha ) : ?>
						<li><span><?php esc_html_e( 'SHA-256', 'monstera' ); ?></span><strong><?php echo esc_html( substr( $fileSha, 0, 4 ) . '…' . substr( $fileSha, -4 ) ); ?></strong></li>
					<?php endif; ?>
					<li><span><?php esc_html_e( 'Access window', 'monstera' ); ?></span><strong><?php esc_html_e( '5 min', 'monstera' ); ?></strong></li>
					<?php if ( $audienceCount ) : ?>
						<li>
							<span><?php esc_html_e( 'Visible to', 'monstera' ); ?></span>
							<strong>
								<?php
								printf(
									/* translators: %d: how many members */
									esc_html( _n( '%d member', '%d members', $audienceCount, 'monstera' ) ),
									(int) $audienceCount
								);
								?>
							</strong>
						</li>
					<?php endif; ?>
				</ul>
			</aside>
		<?php endif; ?>
	</header>

	<div class="m-dash">
		<div class="m-dash__main">

			<article class="m-prose">
				<?php echo Body::html( $contentPost ); // phpcs:ignore WordPress.Security.EscapeOutput -- the_content pipeline output (shortcodes only from the team), the same trust model as a theme template. ?>
			</article>

			<div class="m-article-foot">
				<a class="m-btn" data-intent="ghost" href="<?php echo esc_url( $backUrl ); ?>">← <?php echo esc_html( $backLabel ); ?></a>
			</div>
		</div>

		<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'Related', 'monstera' ); ?>">
			<?php if ( $related ) : ?>
				<div class="m-rail-block">
					<h3>
						<?php
						$contentSubgroups
							? esc_html_e( 'Related in this sub-group', 'monstera' )
							: esc_html_e( 'Related items', 'monstera' );
						?>
					</h3>
					<ul class="m-ticker">
						<?php foreach ( $related as $r ) : ?>
							<li>
								<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $r->ID ] ) ); ?>"><?php echo esc_html( get_the_title( $r ) ); ?></a>
								<time datetime="<?php echo esc_attr( wp_date( 'c', (int) get_post_time( 'U', true, $r ) ) ); ?>"><?php echo esc_html( wp_date( 'M j, Y', (int) get_post_time( 'U', true, $r ) ) ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( $people && $peopleHeading ) : ?>
				<div class="m-rail-block">
					<h3><?php echo esc_html( $peopleHeading ); ?></h3>
					<ul class="m-people">
						<?php
						foreach ( $people as $person ) :
							$position = (string) get_user_meta( $person->ID, UserMeta::KEY_POSITION, true );
							$photo    = (int) get_user_meta( $person->ID, UserMeta::KEY_PROFILE_PHOTO, true );
							$photoUrl = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
							?>
							<li>
								<span class="m-avatar" aria-hidden="true">
									<?php if ( $photoUrl ) : ?>
										<img src="<?php echo esc_url( $photoUrl ); ?>" alt="" />
									<?php else : ?>
										<?php \Monstera\Core\Icons::emit( 'sprout', 18 ); ?>
									<?php endif; ?>
								</span>
								<span>
									<?php echo esc_html( trim( $person->first_name . ' ' . $person->last_name ) ?: $person->display_name ); ?>
									<?php if ( $position || $person->ID === $user->ID ) : ?>
										<small>
											<?php
											echo esc_html( $position );
											if ( $person->ID === $user->ID ) {
												echo esc_html( ( $position ? ' · ' : '' ) . __( 'that\'s you', 'monstera' ) );
											}
											?>
										</small>
									<?php endif; ?>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( \Monstera\Core\Modules::isActive( \Monstera\Core\Modules::SUPPORT ) ) : ?>
				<div class="m-rail-block">
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( SupportPages::newRequestUrl( $user, $contextOrgId ) ); ?>"><?php esc_html_e( 'Ask a question about this item →', 'monstera' ); ?></a></p>
				</div>
			<?php endif; ?>
		</aside>
	</div>
</div>
