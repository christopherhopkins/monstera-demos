<?php
/**
 * A guide at /portal/resources/{id}/ (comp 129; Forms-and-resources track,
 * FR4): a published guide the reader can open, on the editorial reading
 * layout content's detail page uses, without the download panel.
 *
 *  - Breadcrumb (Resources, the guide), then the article head: the
 *    organization the guide reaches the reader through and the kind as
 *    kickers, the title, the description as the summary, the byline with
 *    who wrote it and when it was updated
 *  - The body through the_content filters in the reading column, the back
 *    link in the foot
 *  - In the rail, what else that organization (or the site) shares, a
 *    block about the guide, and a way to ask about it
 *
 * The guide must be one the library lists for the reader
 * (Resources\Repository::visibleTo(): published, reaching them, not held
 * back by an ended membership), and a guide: a draft, one out of reach, a
 * link or a file answer the blocked pattern with a 404 that tells nothing
 * of the resource, as the logging redirect does for a guide. A member's
 * read is logged once a day (Reporting\Tracking::guideViewed()).
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Organizations\Reach;
use Monstera\Portal\Audience;
use Monstera\Portal\Body;
use Monstera\Portal\Context;
use Monstera\Portal\DocumentTitle;
use Monstera\Portal\SupportPages;
use Monstera\Reporting\Tracking;
use Monstera\Resources\Meta as ResourcesMeta;
use Monstera\Resources\Repository as ResourcesRepository;

defined( 'ABSPATH' ) || exit;

if ( ! Modules::isActive( Modules::RESOURCES ) ) {
	DocumentTitle::refused( __( 'Not enabled', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="module-off">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not enabled', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Resources are not enabled on this site.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'The Resources library is currently disabled in Settings.', 'monstera' ); ?></p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to the Portal', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

$user       = $ctx['user'];
$resourceId = (int) get_query_var( Routing::PARAM_ID );
$repo       = new ResourcesRepository();
$guide      = $repo->guideFor( $user, $resourceId );

if ( ! $guide ) {
	// The blocked pattern, with a 404 that says nothing of what is there:
	// a draft, a guide out of reach, a link or a file read the same. On a
	// request the router sent the status before the shell began, and this
	// call finds the headers gone; it is what a test rendering the template
	// alone sees.
	status_header( 404 );
	DocumentTitle::refused( __( 'Not available', 'monstera' ) );
	?>
	<section class="m-blocked" data-reason="no-access">
		<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Not available', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'This resource is not available to you.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: link or sentence telling the reader who to contact */
				printf( esc_html__( 'It may have been removed, or your access changed. %s if this seems wrong.', 'monstera' ), wp_kses_post( Audience::contactHtml() ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It may have been removed, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_RESOURCES ) ); ?>"><?php esc_html_e( 'Back to Resources', 'monstera' ); ?></a>
	</section>
	<?php
	return;
}

DocumentTitle::name( get_the_title( $guide ), __( 'Resources', 'monstera' ) );

// A member reading the guide counts as one view a day; staff's look is none.
Tracking::guideViewed( $resourceId, (int) $user->ID );

$description = trim( wp_strip_all_tags( (string) get_post_meta( $resourceId, ResourcesMeta::KEY_DESCRIPTION, true ) ) );
$author      = get_userdata( (int) $guide->post_author );
$modifiedTs  = (int) get_post_modified_time( 'U', true, $guide );

// The organization this page is about for this reader (Portal\Context, the
// shell's chip), by the reading its row names it with: the one of theirs
// the guide names or whose sub-group they are in, never simply the guide's
// first, never one held back. For staff it is the guide's first; a guide
// for everyone, or one that reaches them by name alone, is about none.
$contextOrgId   = Context::orgFor( $user, Routing::ROUTE_RESOURCE );
$contextOrgName = $contextOrgId ? (string) get_the_title( $contextOrgId ) : '';

// What else reaches the reader the same way (at most four): through the
// context organization by the same reading, or for a guide about none what
// the site shares with everyone (a resource naming no organization). Only
// what the library lists for them, so nothing here leads where a row would
// not: a row's rule for its address is kept below.
$listed  = $repo->visibleTo( $user );
$through = $contextOrgId ? $repo->reachedThrough( $user, $listed ) : [];
$related = [];
foreach ( $listed as $other ) {
	$otherId = (int) $other->ID;
	if ( $otherId === $resourceId ) {
		continue;
	}
	$sameWay = $contextOrgId
		? ( $through[ $otherId ] ?? 0 ) === $contextOrgId
		: ! Reach::resourceOrgs( $otherId );
	if ( $sameWay ) {
		$related[] = $other;
		if ( count( $related ) >= 4 ) {
			break;
		}
	}
}
// Whether each of those waits, and their files, asked of the four alone.
$beside = $repo->besideEach( $user, $related );

// The rail's ticker names the kind and the day, where the comp names a
// file's size: the row partial already prints the facts, and the ticker
// keeps to one reading of each line. A row's address rule, kept in step
// with partials/_resource-row.php: a guide opens its page; a link with no
// address and a file not uploaded yet print none; a file that waits prints
// none either.
$kindLabel = static fn ( int $id ): string => match ( ResourcesMeta::kindOf( $id ) ) {
	ResourcesMeta::KIND_FILE  => __( 'File', 'monstera' ),
	ResourcesMeta::KIND_GUIDE => __( 'Guide', 'monstera' ),
	default                   => __( 'Link', 'monstera' ),
};
$rowHref   = static function ( int $id ) use ( $beside ): string {
	$kind = ResourcesMeta::kindOf( $id );
	if ( ResourcesMeta::KIND_GUIDE === $kind ) {
		return Routing::url( Routing::ROUTE_RESOURCE, [ 'id' => $id ] );
	}
	$target = ResourcesMeta::KIND_FILE === $kind
		? (string) wp_get_attachment_url( (int) get_post_meta( $id, ResourcesMeta::KEY_FILE_ID, true ) )
		: (string) get_post_meta( $id, ResourcesMeta::KEY_EXTERNAL_URL, true );
	if ( '' === $target || ( $beside[ $id ]['waits'] ?? false ) ) {
		return '';
	}
	return Routing::url( Routing::ROUTE_RESOURCE_OPEN, [ 'id' => $id ] );
};
?>
<div class="monstera-portal__dash">

	<nav class="m-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
		<a href="<?php echo esc_url( Routing::url( Routing::ROUTE_RESOURCES ) ); ?>"><?php esc_html_e( 'Resources', 'monstera' ); ?></a>
		<span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo esc_html( get_the_title( $guide ) ); ?></span>
	</nav>

	<header class="m-article-head">
		<div>
			<div class="m-article-head__kickers">
				<?php if ( $contextOrgName ) : ?>
					<span class="m-badge" data-tone="brand"><?php echo esc_html( $contextOrgName ); ?></span>
				<?php endif; ?>
				<span class="m-badge" data-tone="neutral"><?php esc_html_e( 'Guide', 'monstera' ); ?></span>
			</div>

			<h1><?php echo esc_html( get_the_title( $guide ) ); ?></h1>

			<?php if ( $description ) : ?>
				<p class="m-article-summary"><?php echo esc_html( $description ); ?></p>
			<?php endif; ?>

			<p class="m-article-byline">
				<?php if ( $author ) : ?>
					<span>
						<?php
						printf(
							/* translators: %s: author display name (wrapped in <strong>) */
							esc_html__( 'Written by %s', 'monstera' ),
							'<strong>' . esc_html( $author->display_name ) . '</strong>'
						);
						?>
					</span>
					<span aria-hidden="true">·</span>
				<?php endif; ?>
				<span>
					<?php
					printf(
						/* translators: %s: the date the guide was last updated (wrapped in <time>) */
						esc_html__( 'Updated %s', 'monstera' ),
						'<time datetime="' . esc_attr( wp_date( 'c', $modifiedTs ) ) . '">' . esc_html( wp_date( 'M j, Y', $modifiedTs ) ) . '</time>'
					);
					?>
				</span>
			</p>
		</div>
	</header>

	<div class="m-dash">
		<div class="m-dash__main">

			<article class="m-prose">
				<?php echo Body::html( $guide ); // phpcs:ignore WordPress.Security.EscapeOutput -- the_content pipeline output (shortcodes only from the team), the same trust model as a theme template. ?>
			</article>

			<div class="m-article-foot">
				<a class="m-btn" data-intent="ghost" href="<?php echo esc_url( Routing::url( Routing::ROUTE_RESOURCES ) ); ?>">← <?php esc_html_e( 'Back to Resources', 'monstera' ); ?></a>
			</div>
		</div>

		<aside class="m-dash__rail" data-wp-init="callbacks.watchRail" aria-label="<?php esc_attr_e( 'Related', 'monstera' ); ?>">
			<?php if ( $related ) : ?>
				<div class="m-rail-block">
					<h3>
						<?php
						if ( $contextOrgName ) {
							/* translators: %s: an organization's name, or the site's */
							echo esc_html( sprintf( __( 'Also from %s', 'monstera' ), $contextOrgName ) );
						} else {
							/* translators: %s: an organization's name, or the site's */
							echo esc_html( sprintf( __( 'Also from %s', 'monstera' ), Audience::siteName() ) );
						}
						?>
					</h3>
					<ul class="m-ticker">
						<?php
						foreach ( $related as $r ) :
							$href = $rowHref( (int) $r->ID );
							?>
							<li>
								<?php if ( $href ) : ?>
									<a href="<?php echo esc_url( $href ); ?>"><?php echo esc_html( get_the_title( $r ) ); ?></a>
								<?php else : ?>
									<span><?php echo esc_html( get_the_title( $r ) ); ?></span>
								<?php endif; ?>
								<time datetime="<?php echo esc_attr( wp_date( 'c', (int) get_post_modified_time( 'U', true, $r ) ) ); ?>"><?php echo esc_html( $kindLabel( (int) $r->ID ) . ' · ' . wp_date( 'M j', (int) get_post_modified_time( 'U', true, $r ) ) ); ?></time>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<div class="m-rail-block">
				<h3><?php esc_html_e( 'About this guide', 'monstera' ); ?></h3>
				<?php if ( $contextOrgName ) : ?>
					<div class="m-stat">
						<span class="m-stat__label"><?php esc_html_e( 'From', 'monstera' ); ?></span>
						<span class="m-stat__value"><?php echo esc_html( $contextOrgName ); ?></span>
					</div>
				<?php endif; ?>
				<div class="m-stat">
					<span class="m-stat__label"><?php esc_html_e( 'Updated', 'monstera' ); ?></span>
					<span class="m-stat__value"><?php echo esc_html( wp_date( 'M j, Y', $modifiedTs ) ); ?></span>
				</div>
				<?php if ( Modules::isActive( Modules::SUPPORT ) ) : ?>
					<p class="m-rail-block__hint"><a href="<?php echo esc_url( SupportPages::newRequestUrl( $user, $contextOrgId ) ); ?>"><?php esc_html_e( 'Ask a question about this guide →', 'monstera' ); ?></a></p>
				<?php endif; ?>
			</div>
		</aside>
	</div>
</div>
