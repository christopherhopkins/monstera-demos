<?php
/**
 * Portal shell — opening markup for public pages (no signed-in member).
 *
 * Used for the accessibility statement, which the EAA requires to be
 * readable before signing in. Same document head and landmarks as the
 * member shell, with a brand link and a sign-in action instead of the
 * member navigation.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Icons;
use Monstera\Core\Routing;

$theme = (string) ( $ctx['theme'] ?? 'light' );
?>
<!doctype html>
<html <?php language_attributes(); ?> data-monstera-theme="<?php echo esc_attr( $theme ); ?>">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
	<title><?php echo esc_html( wp_get_document_title() ); ?> · <?php bloginfo( 'name' ); ?></title>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'monstera-portal' ); ?>>

	<a class="m-skip" href="#monstera-main">
		<?php esc_html_e( 'Skip to main content', 'monstera' ); ?>
	</a>

	<header class="m-topbar" role="banner" data-public>
		<a class="m-topbar__brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php Icons::emit( 'leaf-mark', 28 ); ?>
			<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		</a>
		<span class="m-topbar__spacer"></span>
		<?php if ( Routing::ROUTE_SIGN_IN !== (string) ( $ctx['route'] ?? '' ) ) : ?>
			<div class="m-topbar__actions">
				<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( wp_login_url( Routing::url( Routing::ROUTE_DASHBOARD ) ) ); ?>">
					<?php esc_html_e( 'Sign in', 'monstera' ); ?>
				</a>
			</div>
		<?php endif; ?>
	</header>

	<main id="monstera-main" class="monstera-portal__main">
