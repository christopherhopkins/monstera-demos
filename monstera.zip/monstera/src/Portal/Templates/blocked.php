<?php
/**
 * Blocked page — one pattern (2026-09 design review, comps 31–33): the
 * sprig, a badge naming the reason, one sentence, one action and an aside.
 * Rendered by the router at the URL the member asked for when
 * PortalGuard::blockedReason() names a reason.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Portal\Audience;

defined( 'ABSPATH' ) || exit;

$user     = $ctx['user'];
$reason   = (string) ( $ctx['blocked'] ?? PortalGuard::BLOCKED_NO_ACCESS );
$siteName = Audience::siteName();
$orgId    = UserMeta::associatedOrg( (int) $user->ID );
$orgName  = $orgId ? get_the_title( $orgId ) : '';
$contact  = (string) get_option( 'admin_email' );
$userName = trim( $user->first_name . ' ' . $user->last_name ) ?: $user->display_name;
?>
<section class="m-blocked" data-reason="<?php echo esc_attr( $reason ); ?>">
	<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
	<?php if ( PortalGuard::BLOCKED_NO_ORG === $reason ) : ?>
		<span class="m-badge m-blocked__reason" data-tone="info"><?php esc_html_e( 'Not in an organization yet', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'You\'re signed in, but nothing is shared with you yet.', 'monstera' ); ?></h1>
		<p>
			<?php
			printf(
				/* translators: %s: the member's email address */
				esc_html__( 'Access arrives when an organization adds you as a member. Ask its manager to invite %s.', 'monstera' ),
				'<span class="m-mono">' . esc_html( $user->user_email ) . '</span>'
			);
			?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="mailto:<?php echo esc_attr( $contact ); ?>">
			<?php
			/* translators: %s: site name */
			printf( esc_html__( 'Ask the %s team →', 'monstera' ), esc_html( $siteName ) );
			?>
		</a>
		<p class="m-blocked__aside">
			<?php
			/* translators: %s: the member's name */
			printf( esc_html__( 'Signed in as %s', 'monstera' ), esc_html( $userName ) );
			?>
			· <a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Sign out', 'monstera' ); ?></a>
		</p>
	<?php elseif ( PortalGuard::BLOCKED_EXPIRED === $reason ) : ?>
		<?php
		$expires   = (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true );
		$expiresTs = $expires ? strtotime( $expires ) : false;
		$isManager = user_can( $user, \Monstera\Core\Capabilities::CAP_MANAGE_OWN_ORG );
		$managers  = get_users(
			[
				'role'       => \Monstera\Core\Capabilities::ROLE_ORG_MANAGER,
				'meta_key'   => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design; one org's managers are a handful.
				'meta_value' => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- see above.
				'number'     => 1,
			]
		);
		$manager   = $managers ? $managers[0] : null;
		?>
		<span class="m-badge m-blocked__reason" data-tone="expired">
			<?php
			if ( $expiresTs ) {
				/* translators: %s: the date the membership ended */
				printf( esc_html__( 'Membership ended %s', 'monstera' ), esc_html( wp_date( 'M j', $expiresTs ) ) );
			} else {
				esc_html_e( 'Membership ended', 'monstera' );
			}
			?>
		</span>
		<h1>
			<?php
			/* translators: %s: organization name */
			printf( esc_html__( '%s\'s membership has ended.', 'monstera' ), esc_html( $orgName ) );
			?>
		</h1>
		<p><?php esc_html_e( 'Your content, downloads and projects are kept safe and come back the moment the membership is renewed.', 'monstera' ); ?></p>
		<?php if ( $isManager && \Monstera\Organizations\Membership::renewalOpen( $orgId ) ) : ?>
			<button type="button" class="m-btn m-blocked__action" data-intent="primary" data-renew data-org-id="<?php echo (int) $orgId; ?>" data-wp-on--click="actions.startRenewal"><?php esc_html_e( 'Renew the membership →', 'monstera' ); ?></button>
			<p class="m-blocked__aside">
				<?php
				/* translators: %s: organization name */
				printf( esc_html__( 'Members of %s see this page too. As its manager, only you can renew.', 'monstera' ), esc_html( $orgName ) );
				?>
			</p>
		<?php else : ?>
			<a class="m-btn m-blocked__action" data-intent="primary" href="mailto:<?php echo esc_attr( $manager ? $manager->user_email : $contact ); ?>">
				<?php
				if ( $manager ) {
					/* translators: %s: the manager's name */
					printf( esc_html__( 'Ask %s to renew →', 'monstera' ), esc_html( $manager->display_name ) );
				} else {
					/* translators: %s: site name */
					printf( esc_html__( 'Ask the %s team →', 'monstera' ), esc_html( $siteName ) );
				}
				?>
			</a>
			<p class="m-blocked__aside">
				<?php
				/* translators: %s: organization name */
				printf( esc_html__( 'Every member of %s sees this page until the membership is renewed.', 'monstera' ), esc_html( $orgName ) );
				?>
			</p>
		<?php endif; ?>
	<?php else : ?>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Another organization\'s page', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'This page isn\'t shared with you.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'It belongs to an organization, or your access changed. Contact %s if this seems wrong.', 'monstera' ), esc_html( $siteName ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It belongs to a different organization, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to your dashboard →', 'monstera' ); ?></a>
		<?php if ( $orgName ) : ?>
			<p class="m-blocked__aside">
				<?php
				/* translators: %s: organization name */
				printf( esc_html__( 'You\'re a member of %s.', 'monstera' ), esc_html( $orgName ) );
				?>
			</p>
		<?php endif; ?>
	<?php endif; ?>
</section>
