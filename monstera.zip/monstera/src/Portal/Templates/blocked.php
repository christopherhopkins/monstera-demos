<?php
/**
 * Blocked page — one pattern (2026-09 design review, comps 31–33): the
 * sprig, a badge naming the reason, one sentence, one action and an aside.
 * Rendered by the router at the URL the member asked for when
 * PortalGuard::blockedReason() names a reason. One exception to "one
 * action": when every membership of a person in several organizations has
 * ended, the page lists each organization with its end date and its own
 * action, because who can renew differs from one to the next.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\Icons;
use Monstera\Core\Routing;
use Monstera\Organizations\Membership;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Portal\Context;

defined( 'ABSPATH' ) || exit;

$user     = $ctx['user'];
$route    = (string) ( $ctx['route'] ?? '' );
$reason   = (string) ( $ctx['blocked'] ?? PortalGuard::BLOCKED_NO_ACCESS );
$siteName = Audience::siteName();
// The organization the page is about (People-model track, FR5): the hub's,
// the item's or the project's, else the viewer's primary one. The expired
// reason was judged against the same one, so that branch names it. The
// no-access aside says who the viewer is, not whose page they reached, so
// it names their own organizations: the one, as it did before memberships,
// or each of them for a person in several, since the first alone would be
// half of who they are.
$orgId       = Context::orgFor( $user, $route );
$orgName     = $orgId ? get_the_title( $orgId ) : '';
$ownOrgNames = Audience::orgNames( (int) $user->ID );
$contact     = (string) get_option( 'admin_email' );
$userName    = trim( $user->first_name . ' ' . $user->last_name ) ?: $user->display_name;

// Where one ended membership stands for this viewer: when it ended, whether
// they may renew it, and who else can. Renewing is for an admin or manager
// of that organization, whatever they are elsewhere: the role is only the
// ceiling. Everyone else is pointed at its first admin or manager, and
// how many of them there are says whether the viewer is the only one.
$standingOf = static function ( int $endedOrgId ) use ( $user ): array {
	$ends       = (string) get_post_meta( $endedOrgId, OrgMeta::KEY_EXPIRES, true );
	$managerIds = Roster::memberIds( $endedOrgId, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ] );
	return [
		'endedTs'   => $ends ? strtotime( $ends ) : false,
		'isManager' => user_can( $user, Capabilities::CAP_MANAGE_OWN_ORG )
			&& in_array( Roster::roleOf( (int) $user->ID, $endedOrgId ), [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true ),
		'manager'   => $managerIds ? ( get_user_by( 'id', $managerIds[0] ) ?: null ) : null,
		'managers'  => count( $managerIds ),
	];
};

// On a page that names no organization (the dashboard, the projects list)
// the guard says expired only when every membership has ended. A person in
// several then reads each of them with its own end date and its own action,
// so the manager of one that is not their first is not told to ask someone
// else about another. With one membership the page speaks for it alone, as
// it always has, and so does a page that names its organization.
$endedOrgIds = [];
if ( PortalGuard::BLOCKED_EXPIRED === $reason && ! in_array( $route, [ Routing::ROUTE_ORG, Routing::ROUTE_CONTENT, Routing::ROUTE_PROJECT ], true ) ) {
	foreach ( Roster::membershipsOf( (int) $user->ID ) as $membership ) {
		if ( PortalGuard::membershipExpired( $membership['org_id'] ) ) {
			$endedOrgIds[] = $membership['org_id'];
		}
	}
	// Each one's admins and managers are asked for below: one read for all.
	Roster::primeOrgs( $endedOrgIds );
	// With one ended organization the page speaks for it. It is their
	// primary one unless that one is in the trash or still a draft, which the
	// guard passed over as neither running nor ended (PortalGuard): then the
	// page names the organization that has ended, not the one that is gone.
	if ( 1 === count( $endedOrgIds ) && $endedOrgIds[0] !== $orgId ) {
		$orgId   = $endedOrgIds[0];
		$orgName = get_the_title( $orgId );
	}
}
?>
<section class="m-blocked" data-reason="<?php echo esc_attr( $reason ); ?>">
	<span class="m-blocked__sprig"><?php Icons::sprig(); ?></span>
	<?php if ( PortalGuard::BLOCKED_NO_ORG === $reason ) : ?>
		<span class="m-badge m-blocked__reason" data-tone="info"><?php esc_html_e( 'Not in an organization yet', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'You\'re signed in, but nothing is shared with you yet.', 'monstera' ); ?></h1>
		<p>
			<?php
			// An admin or a manager of an organization may invite into it
			// (Organizations\RosterPolicy), so the reader is sent to either.
			printf(
				/* translators: %s: the member's email address */
				esc_html__( 'Access arrives when an organization adds you as a member. Ask one of its admins or managers to invite %s.', 'monstera' ),
				'<span class="m-mono">' . esc_html( $user->user_email ) . '</span>'
			);
			?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( 'mailto:' . $contact ); ?>">
			<?php
			/* translators: %s: site name */
			printf( esc_html__( 'Ask the %s team →', 'monstera' ), esc_html( $siteName ) );
			?>
		</a>
		<p class="m-blocked__aside">
			<?php
			/* translators: %s: the member's name */
			printf( esc_html__( 'Signed in as %s', 'monstera' ), esc_html( $userName ) );
			?>
			· <a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Sign out', 'monstera' ); ?></a>
		</p>
	<?php elseif ( count( $endedOrgIds ) > 1 ) : ?>
		<span class="m-badge m-blocked__reason" data-tone="expired"><?php esc_html_e( 'Memberships ended', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'Your memberships have ended.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'Your content, downloads and projects are kept safe. What an organization shared comes back the moment its membership is renewed.', 'monstera' ); ?></p>
		<ul class="m-blocked__orgs">
			<?php
			foreach ( $endedOrgIds as $endedOrgId ) :
				$endedOrgName = get_the_title( $endedOrgId );
				[
					'endedTs'   => $endedTs,
					'isManager' => $managesIt,
					'manager'   => $itsManager,
				]             = $standingOf( $endedOrgId );
				?>
				<li>
					<strong><?php echo esc_html( $endedOrgName ); ?></strong>
					<?php if ( $endedTs ) : ?>
						<span>
							<?php
							/* translators: %s: the date the membership ended */
							printf( esc_html__( 'Ended %s', 'monstera' ), esc_html( wp_date( 'M j, Y', $endedTs ) ) );
							?>
						</span>
					<?php endif; ?>
					<?php if ( $managesIt && Membership::renewalOpen( $endedOrgId ) ) : ?>
						<?php
						/* translators: %s: organization name */
						$renewLabel = sprintf( __( 'Renew the membership of %s', 'monstera' ), $endedOrgName );
						?>
						<button type="button" class="m-btn" data-intent="primary" data-size="sm" data-renew data-org-id="<?php echo (int) $endedOrgId; ?>" data-wp-on--click="actions.startRenewal" aria-label="<?php echo esc_attr( $renewLabel ); ?>"><?php esc_html_e( 'Renew the membership →', 'monstera' ); ?></button>
					<?php else : ?>
						<a class="m-btn" data-intent="secondary" data-size="sm" href="<?php echo esc_url( 'mailto:' . ( $itsManager ? $itsManager->user_email : $contact ) ); ?>">
							<?php
							if ( $itsManager ) {
								/* translators: %s: the name of the organization's first admin or manager */
								printf( esc_html__( 'Ask %s to renew →', 'monstera' ), esc_html( $itsManager->display_name ) );
							} else {
								/* translators: %s: site name */
								printf( esc_html__( 'Ask the %s team →', 'monstera' ), esc_html( $siteName ) );
							}
							?>
						</a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<p class="m-blocked__aside"><?php esc_html_e( 'This page opens again once one of them is renewed.', 'monstera' ); ?></p>
	<?php elseif ( PortalGuard::BLOCKED_EXPIRED === $reason ) : ?>
		<?php
		[
			'endedTs'   => $expiresTs,
			'isManager' => $isManager,
			'manager'   => $manager,
			'managers'  => $managerCount,
		] = $standingOf( $orgId );
		// "Your content, downloads and projects" is everything a person with
		// one organization has. A person in several reaches this page for
		// one of theirs while another may be live, so they are told that
		// what this one shares is kept, and nothing about the rest.
		$keptSafe = Audience::isMultiOrg( (int) $user->ID )
			/* translators: %s: organization name */
			? sprintf( __( 'What %s shares with you is kept safe and comes back the moment the membership is renewed.', 'monstera' ), $orgName )
			: __( 'Your content, downloads and projects are kept safe and come back the moment the membership is renewed.', 'monstera' );
		?>
		<span class="m-badge m-blocked__reason" data-tone="expired">
			<?php
			if ( $expiresTs ) {
				/* translators: %s: the date the membership ended */
				printf( esc_html__( 'Membership ended %s', 'monstera' ), esc_html( wp_date( 'M j', $expiresTs ) ) );
			} else {
				esc_html_e( 'Membership ended', 'monstera' );
			}
			?>
		</span>
		<h1>
			<?php
			/* translators: %s: organization name */
			printf( esc_html__( 'The membership of %s has ended.', 'monstera' ), esc_html( $orgName ) );
			?>
		</h1>
		<p><?php echo esc_html( $keptSafe ); ?></p>
		<?php if ( $isManager && \Monstera\Organizations\Membership::renewalOpen( $orgId ) ) : ?>
			<button type="button" class="m-btn m-blocked__action" data-intent="primary" data-renew data-org-id="<?php echo (int) $orgId; ?>" data-wp-on--click="actions.startRenewal"><?php esc_html_e( 'Renew the membership →', 'monstera' ); ?></button>
			<p class="m-blocked__aside">
				<?php
				// "Only you" is true of the one person who can renew. An
				// organization may have several admins and managers, and
				// then any of them can. The one person may hold either
				// tier (an organization's first is its admin), so the
				// sentence names both and calls them neither.
				if ( $managerCount > 1 ) {
					/* translators: %s: organization name */
					printf( esc_html__( 'Members of %s see this page too. Any of its admins and managers can renew.', 'monstera' ), esc_html( $orgName ) );
				} else {
					/* translators: %s: organization name */
					printf( esc_html__( 'Members of %s see this page too. As its only admin or manager, only you can renew.', 'monstera' ), esc_html( $orgName ) );
				}
				?>
			</p>
		<?php else : ?>
			<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( 'mailto:' . ( $manager ? $manager->user_email : $contact ) ); ?>">
				<?php
				if ( $manager ) {
					/* translators: %s: the name of the organization's first admin or manager */
					printf( esc_html__( 'Ask %s to renew →', 'monstera' ), esc_html( $manager->display_name ) );
				} else {
					/* translators: %s: site name */
					printf( esc_html__( 'Ask the %s team →', 'monstera' ), esc_html( $siteName ) );
				}
				?>
			</a>
			<p class="m-blocked__aside">
				<?php
				/* translators: %s: organization name */
				printf( esc_html__( 'Every member of %s sees this page until the membership is renewed.', 'monstera' ), esc_html( $orgName ) );
				?>
			</p>
		<?php endif; ?>
	<?php else : ?>
		<span class="m-badge m-blocked__reason" data-tone="neutral"><?php esc_html_e( 'Another organization\'s page', 'monstera' ); ?></span>
		<h1><?php esc_html_e( 'This page isn\'t shared with you.', 'monstera' ); ?></h1>
		<p>
			<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
				<?php
				/* translators: %s: site name */
				printf( esc_html__( 'It belongs to an organization, or your access changed. Contact %s if this seems wrong.', 'monstera' ), esc_html( $siteName ) );
				?>
			<?php else : ?>
				<?php esc_html_e( 'It belongs to a different organization, or your access changed. Reach out to your account team if this seems wrong.', 'monstera' ); ?>
			<?php endif; ?>
		</p>
		<a class="m-btn m-blocked__action" data-intent="primary" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to your Portal →', 'monstera' ); ?></a>
		<?php if ( $ownOrgNames ) : ?>
			<p class="m-blocked__aside">
				<?php
				printf(
					esc_html(
						/* translators: %s: the name of the organization the reader belongs to, or of each of them separated by commas */
						_n(
							'You\'re a member of %s.',
							'You\'re a member of these organizations: %s.',
							count( $ownOrgNames ),
							'monstera'
						)
					),
					/* translators: used between list items; there is a space after the comma */
					esc_html( implode( __( ', ', 'monstera' ), $ownOrgNames ) )
				);
				?>
			</p>
		<?php endif; ?>
	<?php endif; ?>
</section>
