<?php
/**
 * Projects list — client/member view (comp 70).
 *
 * In flight and coming up as rows with the stage meter; completed as a
 * priority-column table in the named scroll region. When the viewer's
 * projects span more than one organization (an agency PM on many teams),
 * each row carries an org sub-line.
 *
 * @var array<string, mixed> $ctx
 */

declare(strict_types=1);

use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Portal\Audience;
use Monstera\Projects\Meta;
use Monstera\Projects\Repository as ProjectRepository;

if ( ! Modules::isActive( Modules::PROJECTS ) ) {
	?>
	<section class="monstera-portal__hero">
		<h1><?php esc_html_e( 'Projects are not enabled on this site.', 'monstera' ); ?></h1>
		<p><?php esc_html_e( 'The Projects module is currently disabled in Settings.', 'monstera' ); ?></p>
		<p><a class="m-btn" data-intent="primary" data-size="md" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>"><?php esc_html_e( 'Back to dashboard', 'monstera' ); ?></a></p>
	</section>
	<?php
	return;
}

$user  = $ctx['user'];
$repo  = new ProjectRepository();
$orgId = UserMeta::associatedOrg( $user->ID );
// Union of "my org's projects" + "projects I'm on the team for" — covers
// the common client case AND the agency-PM case where one user spans many
// client orgs' projects via direct team assignments.
$projects = $repo->forUser( $user->ID, $orgId );

$active    = [];
$upcoming  = [];
$completed = [];

foreach ( $projects as $project ) {
	$projectStatus = $repo->status( $project->ID );
	if ( in_array( $projectStatus, [ Meta::STATUS_PROPOSED, Meta::STATUS_ON_HOLD ], true ) ) {
		$upcoming[] = $project;
	} elseif ( in_array( $projectStatus, [ Meta::STATUS_COMPLETED, Meta::STATUS_ARCHIVED ], true ) ) {
		$completed[] = $project;
	} else {
		$active[] = $project;
	}
}

$pipelineStages = [
	Meta::STATUS_PROPOSED,
	Meta::STATUS_DISCOVERY,
	Meta::STATUS_IN_PROGRESS,
	Meta::STATUS_REVIEW,
	Meta::STATUS_COMPLETED,
];

// The org a project belongs to, and whether this list spans more than one.
$orgNameOf = static function ( int $projectId ): string {
	$projectOrg = (int) get_post_meta( $projectId, Meta::KEY_ORG_ID, true );
	return $projectOrg ? (string) get_the_title( $projectOrg ) : '';
};
$orgNames  = array_unique( array_filter( array_map( static fn ( $p ) => $orgNameOf( (int) $p->ID ), $projects ) ) );
$multiOrg  = count( $orgNames ) > 1;

$stageHint = static function ( string $status ): string {
	return match ( $status ) {
		Meta::STATUS_DISCOVERY   => __( 'Discovery open', 'monstera' ),
		Meta::STATUS_IN_PROGRESS => __( 'Deliverables landing', 'monstera' ),
		Meta::STATUS_REVIEW      => __( 'Waiting on your sign-off', 'monstera' ),
		Meta::STATUS_PROPOSED    => __( 'Scope drafted · discovery opens once approved', 'monstera' ),
		Meta::STATUS_ON_HOLD     => __( 'Paused until the next step is confirmed', 'monstera' ),
		default                  => '',
	};
};

$tones = [
	Meta::STATUS_COMPLETED => 'success',
	Meta::STATUS_ARCHIVED  => 'neutral',
	Meta::STATUS_ON_HOLD   => 'suspended',
	Meta::STATUS_DISCOVERY => 'info',
	Meta::STATUS_PROPOSED  => 'pending',
	Meta::STATUS_REVIEW    => 'warning',
];

// One row: the date column, the title, the badge with the hint and team
// size (and the org when the list spans several), then the stage meter for
// work under way or the Open action otherwise.
$projectRow = static function ( \WP_Post $project, bool $underWay ) use ( $repo, $pipelineStages, $orgNameOf, $multiOrg, $stageHint, $tones ): void {
	$pid          = (int) $project->ID;
	$status       = $repo->status( $pid );
	$dueOn        = (string) get_post_meta( $pid, Meta::KEY_DUE_ON, true );
	$teamSize     = count( $repo->memberIds( $pid ) );
	$currentIndex = array_search( $status, $pipelineStages, true );
	if ( false === $currentIndex ) {
		$currentIndex = 0;
	}
	$url     = Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $pid ] );
	$orgName = $multiOrg ? $orgNameOf( $pid ) : '';
	$hint    = $stageHint( $status );
	/* translators: %d: team size count */
	$team = sprintf( _n( '%d on team', '%d on team', $teamSize, 'monstera' ), $teamSize );
	?>
	<li class="m-rows__row">
		<span class="m-rows__date">
			<?php
			if ( Meta::STATUS_ON_HOLD === $status ) {
				esc_html_e( 'Paused', 'monstera' );
			} elseif ( Meta::STATUS_PROPOSED === $status ) {
				esc_html_e( 'Proposed', 'monstera' );
			} elseif ( $dueOn && strtotime( $dueOn ) ) {
				/* translators: %s: due date, e.g. "Mar 4". */
				printf( esc_html__( 'due %s', 'monstera' ), esc_html( wp_date( 'M j', strtotime( $dueOn ) ) ) );
			} else {
				echo '—';
			}
			?>
		</span>
		<a class="m-rows__title" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( get_the_title( $project ) ); ?></a>
		<span class="m-rows__meta">
			<span class="m-badge" data-tone="<?php echo esc_attr( $tones[ $status ] ?? 'active' ); ?>"><?php echo esc_html( Meta::statusLabel( $status ) ); ?></span>
			<?php if ( $orgName ) : ?>
				<span class="m-rows__org"><?php echo esc_html( $orgName ); ?></span>
			<?php endif; ?>
			<span><?php echo esc_html( $hint ? $hint . ' · ' . $team : $team ); ?></span>
		</span>
		<span class="m-rows__side">
			<?php if ( $underWay ) : ?>
				<?php
				/* translators: 1: current stage number, 2: total stages */
				$stageLabel = sprintf( __( 'Stage %1$d of %2$d', 'monstera' ), (int) $currentIndex + 1, count( $pipelineStages ) );
				?>
				<span class="m-progress" role="img" aria-label="<?php echo esc_attr( $stageLabel ); ?>">
					<?php foreach ( $pipelineStages as $idx => $stage ) : ?>
						<span<?php echo $idx < $currentIndex ? ' data-done' : ( $idx === $currentIndex ? ' data-now' : '' ); ?>></span>
					<?php endforeach; ?>
				</span>
			<?php else : ?>
				<a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a>
			<?php endif; ?>
		</span>
	</li>
	<?php
};

// The earliest due date among the projects under way, for the section line.
$nextDue = 0;
foreach ( $active as $project ) {
	$ts = strtotime( (string) get_post_meta( $project->ID, Meta::KEY_DUE_ON, true ) );
	if ( $ts && ( ! $nextDue || $ts < $nextDue ) ) {
		$nextDue = $ts;
	}
}
$pausedCount = count( array_filter( $upcoming, static fn ( $p ) => Meta::STATUS_ON_HOLD === $repo->status( $p->ID ) ) );
?>

<section class="monstera-portal__hero">
	<?php
	$orgName = $orgId ? get_the_title( $orgId ) : '';
	if ( $orgName ) :
		?>
		<h1>
		<?php
			/* translators: %s: organization name */
			printf( esc_html__( 'Projects with %s.', 'monstera' ), esc_html( $orgName ) );
		?>
		</h1>
	<?php else : ?>
		<h1><?php esc_html_e( 'Projects', 'monstera' ); ?></h1>
	<?php endif; ?>
	<p><?php esc_html_e( 'Everything we\'re working on together, what we\'ve completed, and what\'s coming up. Click any project to open discovery, see deliverables, and check status.', 'monstera' ); ?></p>
</section>

<div class="monstera-portal__dash">

	<?php if ( ! $projects ) : ?>
		<div class="m-empty">
			<div class="m-empty__sprig"><?php \Monstera\Core\Icons::sprig(); ?></div>
			<p class="m-empty__message">
				<?php if ( Audience::isStandalone( (int) $user->ID ) ) : ?>
					<?php
					/* translators: %s: site name */
					printf( esc_html__( 'No projects yet. They\'ll appear here once %s starts the first one.', 'monstera' ), esc_html( Audience::siteName() ) );
					?>
				<?php else : ?>
					<?php esc_html_e( 'No projects yet. They\'ll appear here once your account team starts the first one.', 'monstera' ); ?>
				<?php endif; ?>
			</p>
		</div>
	<?php else : ?>

		<?php if ( $active ) : ?>
			<?php
			/* translators: %d: number of projects under way */
			$inFlightLine = sprintf( _n( '%d project', '%d projects', count( $active ), 'monstera' ), count( $active ) );
			if ( $nextDue ) {
				/* translators: 1: how many projects are under way, 2: the earliest due date */
				$inFlightLine = sprintf( __( '%1$s · next due %2$s', 'monstera' ), $inFlightLine, wp_date( 'M j', $nextDue ) );
			}
			?>
			<section class="m-section" aria-labelledby="m-projects-active">
				<div class="m-section__head">
					<h2 id="m-projects-active"><?php esc_html_e( 'In flight', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono"><?php echo esc_html( $inFlightLine ); ?></span>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $active as $project ) {
						$projectRow( $project, true );
					}
					?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( $upcoming ) : ?>
			<?php
			/* translators: %d: number of proposed projects */
			$upcomingLine = sprintf( _n( '%d proposed', '%d proposed', count( $upcoming ) - $pausedCount, 'monstera' ), count( $upcoming ) - $pausedCount );
			if ( $pausedCount ) {
				/* translators: %d: number of paused projects */
				$paused = sprintf( _n( '%d paused', '%d paused', $pausedCount, 'monstera' ), $pausedCount );
				/* translators: 1: how many projects are proposed, 2: how many are paused */
				$upcomingLine = sprintf( __( '%1$s · %2$s', 'monstera' ), $upcomingLine, $paused );
			}
			?>
			<section class="m-section" aria-labelledby="m-projects-upcoming">
				<div class="m-section__head">
					<h2 id="m-projects-upcoming"><?php esc_html_e( 'Coming up', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono"><?php echo esc_html( $upcomingLine ); ?></span>
				</div>
				<ul class="m-rows">
					<?php
					foreach ( $upcoming as $project ) {
						$projectRow( $project, false );
					}
					?>
				</ul>
			</section>
		<?php endif; ?>

		<?php if ( $completed ) : ?>
			<?php
			/* translators: %d: number of completed projects */
			$completedLine = sprintf( _n( '%d since launch', '%d since launch', count( $completed ), 'monstera' ), count( $completed ) );
			?>
			<section class="m-section" aria-labelledby="m-projects-completed">
				<div class="m-section__head">
					<h2 id="m-projects-completed"><?php esc_html_e( 'Completed', 'monstera' ); ?></h2>
					<span class="m-section__link m-mono"><?php echo esc_html( $completedLine ); ?></span>
				</div>
				<div class="m-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Completed projects, scrolls sideways', 'monstera' ); ?>">
					<table class="m-table">
						<thead>
							<tr>
								<th scope="col" data-priority="1"><?php esc_html_e( 'Project', 'monstera' ); ?></th>
								<th scope="col" data-priority="2"><?php esc_html_e( 'Started', 'monstera' ); ?></th>
								<th scope="col" data-priority="2"><?php esc_html_e( 'Completed', 'monstera' ); ?></th>
								<th scope="col" data-priority="1"><span class="m-sr-only"><?php esc_html_e( 'Actions', 'monstera' ); ?></span></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $completed as $project ) :
								$pid     = (int) $project->ID;
								$url     = Routing::url( Routing::ROUTE_PROJECT, [ 'id' => $pid ] );
								$started = strtotime( (string) get_post_meta( $pid, Meta::KEY_STARTED_ON, true ) ) ?: 0;
								$ended   = strtotime( (string) get_post_meta( $pid, Meta::KEY_ENDED_ON, true ) ) ?: 0;
								$span    = [];
								if ( $started ) {
									$span[] = wp_date( 'M Y', $started );
								}
								if ( $ended && ( ! $started || wp_date( 'M Y', $ended ) !== wp_date( 'M Y', $started ) ) ) {
									$span[] = wp_date( 'M Y', $ended );
								}
								$sub = implode( ' – ', $span );
								if ( $multiOrg && $orgNameOf( $pid ) ) {
									$sub = $sub ? $orgNameOf( $pid ) . ' · ' . $sub : $orgNameOf( $pid );
								}
								?>
								<tr>
									<td data-priority="1">
										<a class="m-table__primary" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( get_the_title( $project ) ); ?></a>
										<span class="m-table__sub"><?php echo esc_html( $sub ?: Meta::statusLabel( $repo->status( $pid ) ) ); ?></span>
									</td>
									<td data-priority="2"><span class="m-mono"><?php echo $started ? esc_html( wp_date( 'M j, Y', $started ) ) : '—'; ?></span></td>
									<td data-priority="2"><span class="m-mono"><?php echo $ended ? esc_html( wp_date( 'M j, Y', $ended ) ) : '—'; ?></span></td>
									<td data-priority="1"><a class="m-btn" data-intent="ghost" data-size="sm" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Open →', 'monstera' ); ?></a></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</section>
		<?php endif; ?>

	<?php endif; ?>

</div>
