<?php
declare(strict_types=1);

namespace Monstera\Portal;

use DateTimeImmutable;
use Exception;
use Monstera\Core\SiteDay;

defined( 'ABSPATH' ) || exit;

/**
 * A day stored as a day (a next step's date, a project's start, due and end
 * dates, an organization's or a standalone member's membership expiry, the
 * accessibility statement's review), as the portal prints it. The day is
 * the site's: it starts at midnight in the site's timezone, so a site west
 * of UTC reads the day written and not the evening before, as strtotime()
 * and wp_date() together print it. A date stored as typed rather than as Y-m-d is read as
 * Projects\Repository reads it for the next step (strtotime(), as a day in
 * UTC), so the band and the page's other dates never disagree.
 */
final class CalendarDay {

	/** The day in the format asked, or '' for a value that names no day. */
	public static function format( string $value, string $format ): string {
		$at = self::start( $value );
		return null === $at ? '' : (string) wp_date( $format, $at->getTimestamp() );
	}

	/**
	 * The day as Y-m-d, or '' for a value that names no day. A day on the
	 * calendar is as written; anything else, an impossible day ("2026-04-31")
	 * included, is what strtotime() makes of it, as the repository's next
	 * step reads it, so the two never disagree.
	 */
	public static function ymd( string $value ): string {
		return SiteDay::ymd( $value );
	}

	/** When the day starts on the site, or null for a value that names no day. */
	public static function start( string $value ): ?DateTimeImmutable {
		$ymd = self::ymd( $value );
		if ( '' === $ymd ) {
			return null;
		}
		try {
			return new DateTimeImmutable( $ymd . ' 00:00:00', wp_timezone() );
		} catch ( Exception ) {
			return null;
		}
	}
}
