<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * What of an item's audience a route tells its caller (the owner's rules,
 * 2026-10-17). Staff are told all of it. Anyone else, a client author
 * reading an item they wrote, is told the organizations of theirs it
 * reaches, the sub-groups that are theirs to know of (SubgroupNames), the
 * projects they may open (ContentProjects) and no standalone member: what
 * staff shared the item with beyond that, another client and its sub-groups
 * or projects, is not theirs to know, and while it is shared so their saves
 * leave who it reaches as it is (AuthorScope::isSharedFurther()).
 */
final class AudienceShown {

	/** Whether the caller is told an audience whole. */
	public static function whole( WP_User $user ): bool {
		return Capabilities::isStaff( $user ) || user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
	}

	/**
	 * @param array<int, mixed> $orgIds
	 * @return list<int> The ones told, in the order given.
	 */
	public static function orgs( WP_User $user, array $orgIds ): array {
		$orgIds = array_values( array_filter( array_map( 'intval', $orgIds ), static fn ( int $id ): bool => $id > 0 ) );
		if ( self::whole( $user ) ) {
			return $orgIds;
		}
		// Theirs: every membership, and the organization a leader with none
		// of their own authors in, of those on the site. One in the trash is
		// nobody's to be told of (Organizations\Repository::onSite()); the
		// item keeps it, since a save is held while the item reaches beyond
		// the author's part (AuthorScope::isSharedFurther()).
		$theirs = array_fill_keys( OrgRepository::onSite( array_merge( Roster::orgIdsOf( (int) $user->ID ), AuthorScope::orgIdsFor( (int) $user->ID ) ) ), true );
		return array_values( array_filter( $orgIds, static fn ( int $id ): bool => isset( $theirs[ $id ] ) ) );
	}

	/**
	 * @param array<int, mixed> $memberIds
	 * @return list<int>
	 */
	public static function members( WP_User $user, array $memberIds ): array {
		return self::whole( $user ) ? array_values( array_map( 'intval', $memberIds ) ) : [];
	}

	/**
	 * The published ones, of those theirs to know of (SubgroupNames): one
	 * deleted or in the trash lets nobody through and is named nowhere (the
	 * owner's call, 2026-10-18), and a save keeps it on the item without
	 * being handed it (Rest\Controllers\ContentController::gateAfterSave()).
	 *
	 * @param array<int, mixed> $subgroupIds
	 * @return list<int>
	 */
	public static function subgroups( WP_User $user, array $subgroupIds ): array {
		return self::whole( $user ) ? SubgroupRepository::published( $subgroupIds ) : SubgroupNames::shown( $user, $subgroupIds );
	}

	/**
	 * @param array<int, mixed> $projectIds
	 * @return list<int>
	 */
	public static function projects( WP_User $user, array $projectIds ): array {
		return self::whole( $user ) ? array_values( array_map( 'intval', $projectIds ) ) : ContentProjects::shown( (int) $user->ID, $projectIds );
	}
}
