<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use Monstera\Organizations\Roster;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\PostType as SubgroupPostType;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Whose sub-groups the portal names to a reader (the owner's rule,
 * 2026-10-17, carried from the At-a-glance Phase 4 review). Staff see every
 * sub-group. Anyone else sees the ones they are in and the ones that belong
 * to their own organizations, private ones included, as the hub's
 * Sub-groups tab lists them, or to themselves as a standalone member: an
 * item shared with another client's sub-group too never tells them its
 * name. The hub's filter chips and its rows' audience, the item page's
 * badges and the Manage tab's "Reaches" name sub-groups through here; the
 * directory already keeps to the viewer's organizations' groups.
 */
final class SubgroupNames {

	/**
	 * The ones of these sub-groups the reader may see named, published ones
	 * alone (one deleted or in the trash lets nobody through and is named
	 * nowhere, as the hub's Sub-groups tab lists it nowhere; the owner's
	 * call, 2026-10-18). Their posts and meta are read together, so naming
	 * them costs the same however many there are, and the titles the page
	 * then prints are read already.
	 *
	 * @param array<int, mixed> $subgroupIds
	 * @return list<int> In the order given, each once.
	 */
	public static function shown( WP_User $user, array $subgroupIds ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $subgroupIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $ids ) {
			return [];
		}
		_prime_post_caches( $ids, false, true );
		$ids = array_values(
			array_filter(
				$ids,
				static function ( int $id ): bool {
					$post = get_post( $id );
					return $post && SubgroupPostType::SLUG === $post->post_type && 'publish' === $post->post_status;
				}
			)
		);
		if ( ! $ids || Capabilities::isStaff( $user ) || user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return $ids;
		}
		$userId = (int) $user->ID;
		// In it: as a member, or as its leader.
		$mine = array_fill_keys( array_merge( ( new SubgroupRepository() )->subgroupsForMembers( [ $userId ] )[ $userId ] ?? [], SubgroupRepository::leaderSubgroupIds( $userId ) ), true );
		$orgs = array_fill_keys( Roster::orgIdsOf( $userId ), true );
		return array_values(
			array_filter(
				$ids,
				static function ( int $id ) use ( $mine, $orgs, $userId ): bool {
					if ( isset( $mine[ $id ] ) ) {
						return true;
					}
					$orgId = (int) get_post_meta( $id, SubgroupMeta::KEY_ORG_ID, true );
					if ( $orgId > 0 ) {
						return isset( $orgs[ $orgId ] );
					}
					return (int) get_post_meta( $id, SubgroupMeta::KEY_STANDALONE_MEMBER_ID, true ) === $userId;
				}
			)
		);
	}

	/**
	 * shown() for each of many items' sub-groups, judged together.
	 *
	 * @param array<int, int[]> $byContent Sub-group ids by content id.
	 * @return array<int, list<int>> The ones named, by content id, every item kept.
	 */
	public static function shownFor( WP_User $user, array $byContent ): array {
		$named = array_fill_keys( self::shown( $user, $byContent ? array_merge( ...array_values( $byContent ) ) : [] ), true );
		return array_map(
			static fn ( array $ids ): array => array_values( array_filter( array_map( 'intval', $ids ), static fn ( int $id ): bool => isset( $named[ $id ] ) ) ),
			$byContent
		);
	}
}
