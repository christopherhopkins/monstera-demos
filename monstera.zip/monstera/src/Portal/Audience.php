<?php
/**
 * Which copy a portal reader should see.
 *
 * Org members have an organization, an org manager, and (in agency mode) an
 * account team, so copy may name them. Standalone members have none of those:
 * they joined the program on their own and nobody "sets things up" for them.
 * Every template that would otherwise say "your account team" or "your
 * organization" asks this class first and renders the standalone variant when
 * it applies. Templates never inspect roles or org links themselves.
 *
 * The standalone contact line is deliberately not a new setting: when the
 * Support module is on, the reader is pointed at the support form; when it is
 * off, the copy simply names the site.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;

final class Audience {

	/** @var array<int, bool> Per-request memo keyed by user id. */
	private static array $cache = [];

	/**
	 * True for a reader with no organization: the standalone role, or any
	 * non-admin portal user whose associated-org meta is empty. Admins are
	 * never standalone; they preview the portal as staff, not as a member.
	 */
	public static function isStandalone( int $userId ): bool {
		if ( $userId <= 0 ) {
			return false;
		}
		if ( isset( self::$cache[ $userId ] ) ) {
			return self::$cache[ $userId ];
		}

		$user = get_userdata( $userId );
		if ( ! $user ) {
			return false;
		}

		$result = false;
		if ( ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			$result = in_array( Capabilities::ROLE_MEMBER_STANDALONE, (array) $user->roles, true )
				|| 0 === UserMeta::associatedOrg( $userId );
		}

		self::$cache[ $userId ] = $result;
		return $result;
	}

	/**
	 * The standalone reader's "who to ask" line.
	 *
	 * @return array{label: string, url: string} `url` is empty when there is
	 *                                           nothing to link to.
	 */
	public static function contact(): array {
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			return [
				'label' => __( 'Send a support request', 'monstera' ),
				'url'   => Routing::url( Routing::ROUTE_SUPPORT ),
			];
		}
		return [
			/* translators: %s: site name */
			'label' => sprintf( __( 'Contact %s', 'monstera' ), self::siteName() ),
			'url'   => '',
		];
	}

	/**
	 * The contact line as escaped HTML: an anchor when there is a URL, plain
	 * text otherwise. Safe to echo directly inside a sentence.
	 */
	public static function contactHtml(): string {
		$contact = self::contact();
		if ( '' === $contact['url'] ) {
			return esc_html( $contact['label'] );
		}
		return sprintf( '<a href="%s">%s</a>', esc_url( $contact['url'] ), esc_html( $contact['label'] ) );
	}

	/**
	 * The site name as plain text. The `blogname` option is stored
	 * HTML-escaped, so callers that will escape on output need it decoded
	 * first or ampersands render twice.
	 */
	public static function siteName(): string {
		return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	}

	public static function flushCache(): void {
		self::$cache = [];
	}
}
