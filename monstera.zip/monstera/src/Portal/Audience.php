<?php
/**
 * Which copy a portal reader should see.
 *
 * Org members have an organization, an org manager, and (in agency mode) an
 * account team, so copy may name them. Standalone members have none of those:
 * they joined the program on their own and nobody "sets things up" for them.
 * Every template that would otherwise say "your account team" or "your
 * organization" asks this class first and renders the standalone variant when
 * it applies. A person in several organizations (People-model track, FR5) has
 * no one "your organization" either, so a sentence that names it asks here
 * for the several-organizations branch. Templates never inspect roles
 * themselves. A page that lists a person's memberships (the dashboard, the
 * profile, the blocked page) reads them from the Roster, and may branch on
 * the list it holds.
 *
 * The standalone contact line is deliberately not a new setting: when the
 * Support module is on, the reader is pointed at the support form; when it is
 * off, the copy simply names the site.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;

defined( 'ABSPATH' ) || exit;

final class Audience {

	/**
	 * Per-request memo keyed by user id: whether the reader is standalone and
	 * whether they belong to several organizations, answered together from
	 * one look at their memberships.
	 *
	 * @var array<int, array{standalone: bool, several: bool}>
	 */
	private static array $cache = [];

	/**
	 * True for a reader with no organization: the standalone role, or any
	 * non-admin portal user with no membership. Admins are never standalone;
	 * they preview the portal as staff, not as a member.
	 */
	public static function isStandalone( int $userId ): bool {
		return self::facts( $userId )['standalone'];
	}

	/**
	 * True for a reader who holds more than one membership of an
	 * organization on the site, so a sentence about "your organization" has
	 * no one organization to mean. One in the trash is not counted.
	 */
	public static function isMultiOrg( int $userId ): bool {
		return self::facts( $userId )['several'];
	}

	/**
	 * The organizations the reader belongs to by name, in membership order:
	 * what a sentence lists for a person in several where it named the one
	 * organization of a person with one. One in the trash is named nowhere
	 * (Organizations\Repository::onSite(), which reads them all at once).
	 * Titles as WordPress gives them, to be escaped on output; empty for a
	 * reader with no organization on the site.
	 *
	 * @return list<string>
	 */
	public static function orgNames( int $userId ): array {
		return array_values( array_filter( array_map( static fn ( int $orgId ): string => (string) get_the_title( $orgId ), OrgRepository::onSite( Roster::orgIdsOf( $userId ) ) ) ) );
	}

	/** @return array{standalone: bool, several: bool} */
	private static function facts( int $userId ): array {
		if ( $userId <= 0 ) {
			return [
				'standalone' => false,
				'several'    => false,
			];
		}
		if ( isset( self::$cache[ $userId ] ) ) {
			return self::$cache[ $userId ];
		}

		$user = get_userdata( $userId );
		if ( ! $user ) {
			return [
				'standalone' => false,
				'several'    => false,
			];
		}

		// Several is of the organizations on the site: a person in one and in
		// another that is in the trash is spoken to as a person in one, since
		// that one grants nothing and is named nowhere. Standalone is of the
		// memberships: a person whose organizations are all in the trash
		// joined through organizations, and what is for everyone does not
		// reach them as it reaches a standalone member
		// (Organizations\Repository::belongsToNoneOnSite()).
		$memberships = Roster::orgIdsOf( $userId );
		$standalone  = false;
		if ( ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			$standalone = in_array( Capabilities::ROLE_MEMBER_STANDALONE, (array) $user->roles, true ) || [] === $memberships;
		}

		self::$cache[ $userId ] = [
			'standalone' => $standalone,
			'several'    => count( OrgRepository::onSite( $memberships ) ) > 1,
		];
		return self::$cache[ $userId ];
	}

	/**
	 * The standalone reader's "who to ask" line.
	 *
	 * @return array{label: string, url: string} `url` is empty when there is
	 *                                           nothing to link to.
	 */
	public static function contact(): array {
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			return [
				'label' => __( 'Send a support request', 'monstera' ),
				'url'   => Routing::url( Routing::ROUTE_SUPPORT ),
			];
		}
		return [
			/* translators: %s: site name */
			'label' => sprintf( __( 'Contact %s', 'monstera' ), self::siteName() ),
			'url'   => '',
		];
	}

	/**
	 * The contact line as escaped HTML: an anchor when there is a URL, plain
	 * text otherwise. Safe to echo directly inside a sentence.
	 */
	public static function contactHtml(): string {
		$contact = self::contact();
		if ( '' === $contact['url'] ) {
			return esc_html( $contact['label'] );
		}
		return sprintf( '<a href="%s">%s</a>', esc_url( $contact['url'] ), esc_html( $contact['label'] ) );
	}

	/**
	 * The site name as plain text. The `blogname` option is stored
	 * HTML-escaped, so callers that will escape on output need it decoded
	 * first or ampersands render twice.
	 */
	public static function siteName(): string {
		return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	}

	public static function flushCache(): void {
		self::$cache = [];
	}
}
