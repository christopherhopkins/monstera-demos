<?php
/**
 * How the portal words a support request for the member who opened it:
 * where it stands, who acted last, when. The templates ask here so the
 * list, the form's rail and the request's own page say the same thing.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Content\SecureFiles;
use Monstera\Members\UserMeta;
use Monstera\Reporting\ActivityFeed;
use Monstera\Support\Files;
use Monstera\Support\Repository;
use Monstera\Support\Thread;

defined( 'ABSPATH' ) || exit;

final class SupportView {

	/** How many resolved and closed requests the list shows until all are asked for. */
	public const DONE_SHOWN = 5;

	/** A status in the member's words: a request waiting on them says so. */
	public static function statusLabel( string $status ): string {
		return match ( $status ) {
			Repository::STATUS_PENDING  => __( 'Waiting on you', 'monstera' ),
			Repository::STATUS_RESOLVED => __( 'Resolved', 'monstera' ),
			Repository::STATUS_CLOSED   => __( 'Closed', 'monstera' ),
			default                     => __( 'Open', 'monstera' ),
		};
	}

	/** The badge tone of a status. */
	public static function statusTone( string $status ): string {
		return match ( $status ) {
			Repository::STATUS_PENDING  => 'warning',
			Repository::STATUS_RESOLVED => 'success',
			Repository::STATUS_CLOSED   => 'neutral',
			default                     => 'info',
		};
	}

	/** "High priority", for a row's facts. */
	public static function priorityLine( string $priority ): string {
		/* translators: %s: a priority, e.g. "High" */
		return sprintf( __( '%s priority', 'monstera' ), Repository::priorityLabel( $priority ) );
	}

	/**
	 * A member's requests as the list shows them: those waiting on the
	 * member, the open ones, then the resolved and closed, each as given
	 * (latest activity first).
	 *
	 * @param list<array<string, mixed>> $rows
	 * @return array{waiting: list<array<string, mixed>>, open: list<array<string, mixed>>, done: list<array<string, mixed>>}
	 */
	public static function groups( array $rows ): array {
		$groups = [
			'waiting' => [],
			'open'    => [],
			'done'    => [],
		];
		foreach ( $rows as $row ) {
			$key = match ( (string) $row['status'] ) {
				Repository::STATUS_PENDING => 'waiting',
				Repository::STATUS_RESOLVED, Repository::STATUS_CLOSED => 'done',
				default => 'open',
			};
			$groups[ $key ][] = $row;
		}
		return $groups;
	}

	/**
	 * When a request last moved: "9:41am" today, "Yesterday", then the date.
	 *
	 * @param array<string, mixed> $row
	 */
	public static function when( array $row ): string {
		$stored = (string) ( $row['last_activity_at'] ?: $row['created_at'] );
		return ActivityFeed::whenLabel( (int) strtotime( $stored . ' UTC' ) );
	}

	/**
	 * Who acted last on a request, in the reader's words: "You wrote",
	 * "Avery replied", "You marked it resolved". A status a reply moved is
	 * the reply's doing.
	 *
	 * @param array<string, mixed>      $row      The request.
	 * @param array<string, mixed>|null $entry    Its thread's latest entry; null when nobody has answered.
	 * @param int                       $viewerId The reader, who opened the request.
	 */
	public static function lastActivity( array $row, ?array $entry, int $viewerId ): string {
		unset( $row );
		if ( ! $entry ) {
			return __( 'You wrote', 'monstera' );
		}
		$mine  = (int) $entry['author_id'] === $viewerId;
		$who   = self::firstName( (int) $entry['author_id'] );
		$event = $entry['event'] ?? null;
		$reply = $mine
			? __( 'You replied', 'monstera' )
			/* translators: %s: a person's first name */
			: sprintf( __( '%s replied', 'monstera' ), $who );

		if ( Thread::KIND_MESSAGE === $entry['kind'] || ! is_array( $event ) || Thread::CAUSE_REPLY === $event['cause'] ) {
			return $reply;
		}
		if ( Thread::EVENT_PRIORITY === $event['type'] ) {
			return $mine
				? __( 'You changed the priority', 'monstera' )
				/* translators: %s: a person's first name */
				: sprintf( __( '%s changed the priority', 'monstera' ), $who );
		}
		switch ( $event['to'] ) {
			case Repository::STATUS_RESOLVED:
				return $mine
					? __( 'You marked it resolved', 'monstera' )
					/* translators: %s: a person's first name */
					: sprintf( __( '%s marked it resolved', 'monstera' ), $who );
			case Repository::STATUS_CLOSED:
				/* translators: %s: a person's first name */
				return sprintf( __( '%s closed it', 'monstera' ), $who );
			case Repository::STATUS_PENDING:
				/* translators: %s: a person's name */
				return sprintf( __( '%s is waiting on you', 'monstera' ), $who );
			default:
				/* translators: %s: a person's first name */
				return sprintf( __( '%s reopened it', 'monstera' ), $who );
		}
	}

	/**
	 * The four priorities as a form offers them, each with what it means.
	 *
	 * @return array<string, array{0: string, 1: string}> Priority => its name and its meaning.
	 */
	public static function priorityChoices(): array {
		return [
			Repository::PRIORITY_LOW    => [ __( 'Low', 'monstera' ), __( 'When you can get to it', 'monstera' ) ],
			Repository::PRIORITY_NORMAL => [ __( 'Normal', 'monstera' ), __( 'Within a couple of business days', 'monstera' ) ],
			Repository::PRIORITY_HIGH   => [ __( 'High', 'monstera' ), __( 'Blocking work', 'monstera' ) ],
			Repository::PRIORITY_URGENT => [ __( 'Urgent', 'monstera' ), __( 'Production-impacting', 'monstera' ) ],
		];
	}

	/**
	 * Who acted last, for the request page's facts: "You", or a first name.
	 *
	 * @param array<string, mixed>|null $entry The thread's latest entry; null when nobody has answered.
	 */
	public static function lastActor( ?array $entry, int $viewerId ): string {
		if ( ! $entry || (int) $entry['author_id'] === $viewerId ) {
			return __( 'You', 'monstera' );
		}
		return self::firstName( (int) $entry['author_id'] );
	}

	/**
	 * Who wrote a message, as its letter is headed: "You" for the reader,
	 * anyone else in full; "Support" once their account is gone.
	 *
	 * @param array<string, mixed> $entry A thread entry.
	 */
	public static function author( array $entry, int $viewerId ): string {
		$authorId = (int) $entry['author_id'];
		if ( $authorId === $viewerId ) {
			return __( 'You', 'monstera' );
		}
		$user = $authorId > 0 ? get_userdata( $authorId ) : false;
		return $user ? UserMeta::fullName( $user ) : __( 'Support', 'monstera' );
	}

	/**
	 * A message's second word, after its author: which side wrote it, so the
	 * letter's ground is never the only signal.
	 *
	 * @param array<string, mixed> $entry   A thread entry.
	 * @param bool                 $opening The message that opened the request.
	 */
	public static function role( array $entry, bool $opening ): string {
		if ( Thread::SIDE_STAFF === $entry['side'] ) {
			return __( 'Support team', 'monstera' );
		}
		return $opening ? __( 'opened this request', 'monstera' ) : __( 'replied', 'monstera' );
	}

	/** A thread entry's time as the page shows it: "Sep 29, 2:14pm". */
	public static function stamp( string $iso ): string {
		return (string) wp_date( 'M j, g:ia', (int) strtotime( $iso ) );
	}

	/**
	 * A message as written: plain text, shown with its paragraphs and line
	 * breaks, and its addresses as links. Markup a member typed stays text.
	 */
	public static function bodyHtml( string $body ): string {
		return wp_kses_post( make_clickable( wpautop( esc_html( $body ) ) ) );
	}

	/**
	 * A change of status or priority as the thread's one sentence, for its
	 * reader: "You raised the priority to High", "Waiting on you since
	 * Avery's reply". Escaped; the new value is in <strong>.
	 *
	 * @param array<string, mixed> $entry    An event entry.
	 * @param int                  $viewerId The reader, who opened the request.
	 */
	public static function eventHtml( array $entry, int $viewerId ): string {
		$event = is_array( $entry['event'] ?? null ) ? $entry['event'] : [];
		$mine  = (int) $entry['author_id'] === $viewerId;
		$who   = esc_html( self::author( $entry, $viewerId ) );
		$to    = (string) ( $event['to'] ?? '' );

		if ( Thread::EVENT_PRIORITY === ( $event['type'] ?? '' ) ) {
			$raised = array_search( $to, Repository::PRIORITIES, true ) > array_search( (string) ( $event['from'] ?? '' ), Repository::PRIORITIES, true );
			$label  = '<strong>' . esc_html( Repository::priorityLabel( $to ) ) . '</strong>';
			if ( $mine ) {
				return $raised
					/* translators: %s: a priority, e.g. "High" */
					? sprintf( esc_html__( 'You raised the priority to %s', 'monstera' ), $label )
					/* translators: %s: a priority, e.g. "Low" */
					: sprintf( esc_html__( 'You lowered the priority to %s', 'monstera' ), $label );
			}
			return $raised
				/* translators: 1: a person's name, 2: a priority, e.g. "High" */
				? sprintf( esc_html__( '%1$s raised the priority to %2$s', 'monstera' ), $who, $label )
				/* translators: 1: a person's name, 2: a priority, e.g. "Low" */
				: sprintf( esc_html__( '%1$s lowered the priority to %2$s', 'monstera' ), $who, $label );
		}

		if ( Thread::CAUSE_REPLY === ( $event['cause'] ?? '' ) ) {
			return Repository::STATUS_PENDING === $to
				/* translators: %s: a person's first name */
				? sprintf( esc_html__( 'Waiting on you since %s\'s reply', 'monstera' ), esc_html( self::firstName( (int) $entry['author_id'] ) ) )
				: esc_html__( 'Open again after your reply', 'monstera' );
		}

		$resolved = '<strong>' . esc_html__( 'resolved', 'monstera' ) . '</strong>';
		switch ( $to ) {
			case Repository::STATUS_RESOLVED:
				return $mine
					/* translators: %s: the word "resolved", emphasised */
					? sprintf( esc_html__( 'You marked this %s', 'monstera' ), $resolved )
					/* translators: 1: a person's name, 2: the word "resolved", emphasised */
					: sprintf( esc_html__( '%1$s marked this %2$s', 'monstera' ), $who, $resolved );
			case Repository::STATUS_CLOSED:
				/* translators: %s: a person's name */
				return sprintf( esc_html__( '%s closed this request', 'monstera' ), $who );
			case Repository::STATUS_PENDING:
				/* translators: %s: a person's name */
				return sprintf( esc_html__( '%s is waiting on you', 'monstera' ), $who );
			default:
				/* translators: %s: a person's name */
				return sprintf( esc_html__( '%s reopened this request', 'monstera' ), $who );
		}
	}

	/**
	 * The tone of an event's node on the thread's stem: the status it moved
	 * to. A priority change and a close are plain.
	 *
	 * @param array<string, mixed> $entry An event entry.
	 */
	public static function eventTone( array $entry ): string {
		$event = is_array( $entry['event'] ?? null ) ? $entry['event'] : [];
		if ( Thread::EVENT_STATUS !== ( $event['type'] ?? '' ) || Repository::STATUS_CLOSED === $event['to'] ) {
			return '';
		}
		return self::statusTone( (string) $event['to'] );
	}

	/**
	 * Why a request is waiting on its member, from the latest entry that
	 * made it so: "Avery replied on Sep 30 and is waiting on you."
	 *
	 * @param list<array<string, mixed>> $thread The request's entries, oldest first.
	 */
	public static function waitingLine( array $thread ): string {
		foreach ( array_reverse( $thread ) as $entry ) {
			$event = $entry['event'] ?? null;
			if ( ! is_array( $event ) || Thread::EVENT_STATUS !== $event['type'] || Repository::STATUS_PENDING !== $event['to'] ) {
				continue;
			}
			$who = self::firstName( (int) $entry['author_id'] );
			if ( Thread::CAUSE_REPLY !== $event['cause'] ) {
				/* translators: %s: a person's first name */
				return sprintf( __( '%s is waiting on you.', 'monstera' ), $who );
			}
			/* translators: 1: a person's first name, 2: a date, e.g. "Sep 30" */
			return sprintf( __( '%1$s replied on %2$s and is waiting on you.', 'monstera' ), $who, wp_date( 'M j', (int) strtotime( (string) $entry['created_at'] ) ) );
		}
		return __( 'We are waiting on you.', 'monstera' );
	}

	/**
	 * What the member just did, when the address says so and the request
	 * agrees: a reply of theirs (which reopened it, if it was closed), a new
	 * priority, "resolved". Said once, in the page's status line.
	 *
	 * @param array<string, mixed>       $request The request.
	 * @param list<array<string, mixed>> $thread  Its entries.
	 * @param array<string, mixed>       $query   The address's query.
	 * @return array{0: string, 1: string}|null The sentence and what follows it.
	 */
	public static function flash( array $request, array $thread, int $viewerId, array $query ): ?array {
		$replied = absint( $query['replied'] ?? 0 );
		foreach ( $replied ? $thread : [] as $at => $entry ) {
			if ( (int) $entry['id'] === $replied && Thread::KIND_MESSAGE === $entry['kind'] && (int) $entry['author_id'] === $viewerId ) {
				// A reply to a closed request reopened it: the next entry says so.
				$moved    = $thread[ $at + 1 ]['event'] ?? null;
				$reopened = is_array( $moved ) && Thread::CAUSE_REPLY === $moved['cause'] && Repository::STATUS_CLOSED === $moved['from'];
				return [
					$reopened ? __( 'Request reopened.', 'monstera' ) : __( 'Reply sent.', 'monstera' ),
					__( 'We\'ll answer here and by email.', 'monstera' ),
				];
			}
		}
		if ( ! empty( $query['resolved'] ) && Repository::STATUS_RESOLVED === $request['status'] ) {
			return [ __( 'Marked resolved.', 'monstera' ), __( 'A reply opens it again.', 'monstera' ) ];
		}
		if ( ! empty( $query['priority'] ) && ! $replied && empty( $query['resolved'] ) ) {
			/* translators: %s: a priority, e.g. "High" */
			return [ sprintf( __( 'Priority changed to %s.', 'monstera' ), Repository::priorityLabel( (string) $request['priority'] ) ), '' ];
		}
		return null;
	}

	/**
	 * What a support form tells the file picker, as the form's data
	 * attributes: the limits it checks before a send and the words it says,
	 * in the site's language.
	 *
	 * @param string $heldNote What a chosen file's row says until the form is sent, e.g. "Goes with your request".
	 * @return array<string, string> Attribute name => value, unescaped.
	 */
	public static function fileFormAttributes( string $heldNote ): array {
		return [
			'data-max-bytes'              => (string) Files::maxBytes(),
			'data-max-count'              => (string) Files::maxCount(),
			'data-max-total'              => (string) Files::maxTotal(),
			'data-accept'                 => SecureFiles::accept(),
			'data-size-units'             => (string) wp_json_encode( SecureFiles::sizeUnits() ),
			'data-msg-file-remove'        => __( 'Remove', 'monstera' ),
			/* translators: %s: a file's name */
			'data-msg-file-remove-label'  => __( 'Remove %s', 'monstera' ),
			'data-msg-file-dismiss'       => __( 'Dismiss', 'monstera' ),
			/* translators: %s: a file's name */
			'data-msg-file-dismiss-label' => __( 'Dismiss %s', 'monstera' ),
			'data-msg-file-big'           => Files::sayTooBig(),
			'data-msg-file-type'          => Files::sayWrongType(),
			'data-msg-file-full'          => Files::sayTooMany(),
			'data-msg-file-total'         => __( 'Together these files are more than one message can carry. Send this one in a second message.', 'monstera' ),
			'data-msg-file-held'          => $heldNote,
			/* translators: %s: a file's name */
			'data-msg-file-picked'        => __( '%s added. It goes when you send.', 'monstera' ),
			/* translators: 1: a file's name, 2: why it was refused */
			'data-msg-file-refused'       => __( '%1$s was not added. %2$s', 'monstera' ),
			/* translators: %s: a file's name */
			'data-msg-file-removed'       => __( '%s removed.', 'monstera' ),
			/* translators: the tag on a file whose name has no extension */
			'data-msg-file-kind'          => __( 'file', 'monstera' ),
			'data-msg-file-server-big'    => __( 'That is more than this site accepts at once. Send fewer or smaller files.', 'monstera' ),
			'data-msg-file-signed-out'    => __( 'Your session has ended. Reload the page, then try again.', 'monstera' ),
			/* translators: 1: how much has been sent, 2: how much there is to send, e.g. "300 KB of 400 KB" */
			'data-msg-sending'            => __( 'Sending · %1$s of %2$s', 'monstera' ),
			'data-msg-sending-label'      => __( 'Sending…', 'monstera' ),
			'data-msg-failed'             => __( 'That did not send. Nothing was lost: check your connection and send again.', 'monstera' ),
		];
	}

	/**
	 * A person's first name, as a sentence about a request names staff;
	 * "Support" once their account is gone.
	 */
	public static function firstName( int $userId ): string {
		$user = $userId > 0 ? get_userdata( $userId ) : false;
		if ( ! $user ) {
			return __( 'Support', 'monstera' );
		}
		return (string) ( $user->first_name ?: $user->display_name );
	}
}
