<?php
/**
 * The authorization scope of a portal author.
 *
 * This is the single source of truth for "what may this user create, edit, and
 * target?" — consumed identically by the REST controllers (enforcement) and the
 * portal templates (show/hide). Keeping both sides on one object is what stops
 * the org-hub UI from drifting out of step with what the server actually allows.
 *
 * The scope is for the organization named (People-model track, FR2): a
 * person may manage one organization, be a plain member of another and lead
 * a sub-group in a third, so every question is asked about the organization
 * the actor is working in (the hub's, FR5), the one a create names, or the
 * one an existing item belongs to (forItem()).
 *
 * Three actor tiers, in precedence order:
 *   - Admin (manage_monstera): unscoped — may author anything for any audience.
 *   - Org manager (manage_own_org, and the admin or manager tier in the
 *     organization in question): may author for that org, optionally
 *     narrowed to sub-groups under it. Never another org, never standalone
 *     members. The role is only a ceiling: the tier in the organization
 *     named decides. Asked for none, the scope settles on the first
 *     organization they manage, else their primary one; that form answers
 *     only "do they author anywhere" and must never decide where a write
 *     lands for someone who authors in several.
 *   - Sub-group leader (a plain member appointed via Subgroups\Meta::KEY_LEADER):
 *     may author only for the sub-groups they lead under the organization
 *     named. Leading one, the audience is fully determined (parent org +
 *     that sub-group), nothing to choose; leading several there, they
 *     choose among them, and choosing none reaches all of them, never the
 *     whole organization. A person may lead a group in each of their
 *     organizations, and is a leader in each only for the groups there.
 *     Asked for none, the scope settles on the groups they lead under one
 *     of their organizations and that organization (so it says they author
 *     whenever one of their hubs would), and a leader with no membership of
 *     their own authors for the sub-groups' organization.
 *
 * Editing is author-owned for non-admins, and held to the item's own
 * organization: you may edit a post you created while you still manage the
 * organization it belongs to, or lead a sub-group it is gated to.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\PostType as AlertPostType;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Capabilities;
use Monstera\Forms\Meta as FormMeta;
use Monstera\Forms\PostType as FormPostType;
use Monstera\Organizations\Roster;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\PostType as SubgroupPostType;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

final class AuthorScope {

	public const ENTITY_CONTENT  = 'content';
	public const ENTITY_SUBGROUP = 'subgroup';
	public const ENTITY_FORM     = 'form';
	public const ENTITY_PROJECT  = 'project';
	public const ENTITY_ALERT    = 'alert';

	/** Where each kind of item keeps the organizations it belongs to. */
	private const ITEM_ORG_KEYS = [
		ContentPostType::SLUG  => ContentMeta::KEY_ORG_IDS,
		FormPostType::SLUG     => FormMeta::KEY_ORGS,
		AlertPostType::SLUG    => AlertMeta::KEY_ORG_IDS,
		ProjectPostType::SLUG  => ProjectMeta::KEY_ORG_ID,
		SubgroupPostType::SLUG => SubgroupMeta::KEY_ORG_ID,
	];

	/** Where each kind keeps the sub-groups it is gated to (content has its own table). */
	private const ITEM_SUBGROUP_KEYS = [
		FormPostType::SLUG    => FormMeta::KEY_SUBGROUPS,
		AlertPostType::SLUG   => AlertMeta::KEY_SUBGROUP_IDS,
		ProjectPostType::SLUG => ProjectMeta::KEY_SUBGROUP_IDS,
	];

	/** @var array<int, array<int, self>> Per-request memo keyed by user id, then by the organization asked about (0 for none). */
	private static array $cache = [];

	/** The newest of the sub-groups they lead there, or 0: one name where one is wanted. */
	public readonly int $leaderSubgroupId;

	/**
	 * @param list<int> $leaderSubgroupIds Every sub-group they lead under the scope's organization, newest first; none for anyone but a leader.
	 */
	private function __construct(
		public readonly int $userId,
		public readonly bool $isAdmin,
		public readonly bool $isOrgManager,
		public readonly int $orgId,
		public readonly array $leaderSubgroupIds
	) {
		$this->leaderSubgroupId = $leaderSubgroupIds[0] ?? 0;
	}

	/**
	 * The person's scope in the organization named.
	 *
	 * @param int $orgId The organization the actor is working in; 0 to let the scope settle on one.
	 */
	public static function forUser( int $userId, int $orgId = 0 ): self {
		$orgId = max( 0, $orgId );
		if ( isset( self::$cache[ $userId ][ $orgId ] ) ) {
			return self::$cache[ $userId ][ $orgId ];
		}

		$isAdmin      = $userId > 0 && user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA );
		$mayManage    = ! $isAdmin && $userId > 0 && user_can( $userId, Capabilities::CAP_MANAGE_OWN_ORG );
		$orgIds       = $userId > 0 ? Roster::orgIdsOf( $userId ) : [];
		$isOrgManager = false;
		$scopeOrg     = $orgIds[0] ?? 0;

		if ( $orgId > 0 ) {
			// The organization they are working in: they manage it only at the
			// admin or manager tier there, whatever they are elsewhere.
			$scopeOrg     = $orgId;
			$isOrgManager = $mayManage && self::managesAt( Roster::roleOf( $userId, $orgId ) );
		} elseif ( $mayManage ) {
			// No organization named: the first one they manage, else the primary.
			foreach ( Roster::membershipsOf( $userId ) as $membership ) {
				if ( self::managesAt( $membership['tier'] ) ) {
					$scopeOrg     = $membership['org_id'];
					$isOrgManager = true;
					break;
				}
			}
		}

		$leaderSubgroupIds = [];
		if ( ! $isAdmin && ! $isOrgManager && $userId > 0 ) {
			// The groups they lead under the organization named; with none
			// named, every group they lead anywhere, and the organization of
			// the newest.
			$leaderSubgroupIds = SubgroupRepository::leaderSubgroupIds( $userId, $orgId );
			$groupOrg          = $orgId;
			if ( 0 === $orgId && $leaderSubgroupIds ) {
				$groupOrg = (int) get_post_meta( $leaderSubgroupIds[0], SubgroupMeta::KEY_ORG_ID, true );
				if ( $orgIds ) {
					// None named, and the groups found may sit under several
					// organizations, the newest under one they are not in. The
					// scope is for one organization: settle on the first of
					// theirs they lead under, where the hub says they author,
					// so "an author somewhere" agrees with what each hub
					// answers; leading under none of theirs, they lead nowhere.
					$groupOrg = 0;
					foreach ( $orgIds as $own ) {
						if ( SubgroupRepository::leaderSubgroupIds( $userId, $own ) ) {
							$groupOrg = $own;
							break;
						}
					}
				}
				// The groups under the organization settled on, and no other's.
				$leaderSubgroupIds = $groupOrg > 0 ? SubgroupRepository::leaderSubgroupIds( $userId, $groupOrg ) : [];
			}
			if ( $leaderSubgroupIds && $orgIds && ! in_array( $groupOrg, $orgIds, true ) ) {
				// The sub-groups belong to an organization they have left: the
				// leadership does not follow them to the next one.
				$leaderSubgroupIds = [];
			} elseif ( $leaderSubgroupIds ) {
				// A leader's org is the sub-groups' parent org, under whichever
				// of their organizations it sits, or with no membership of
				// their own: the audience they may stamp must be the one their
				// sub-groups are in.
				$scopeOrg = $groupOrg;
			}
		}

		self::$cache[ $userId ][ $orgId ] = new self( $userId, $isAdmin, $isOrgManager, $scopeOrg, $leaderSubgroupIds );
		return self::$cache[ $userId ][ $orgId ];
	}

	public static function forCurrentUser( int $orgId = 0 ): self {
		return self::forUser( get_current_user_id(), $orgId );
	}

	/**
	 * The person's scope on an item that exists: theirs in the item's own
	 * organization, never the one a request names, so an edit, a delete or
	 * "End alert" is judged by the tier they hold there and a save clamped
	 * with it keeps the item where it is. An item written from the portal
	 * has exactly one organization; where staff have since given it several,
	 * the first of them in which the item is still the person's to act on
	 * speaks for it.
	 */
	public static function forItem( int $userId, int $postId ): self {
		$orgIds = self::orgIdsOfItem( $postId );
		foreach ( $orgIds as $orgId ) {
			$scope = self::forUser( $userId, $orgId );
			if ( $scope->isAdmin || $scope->covers( $postId ) ) {
				return $scope;
			}
		}
		return self::forUser( $userId, $orgIds[0] ?? 0 );
	}

	/**
	 * The organizations a person authors in, oldest membership first: each
	 * of theirs they manage by tier or lead a sub-group under. A leader with
	 * no membership of their own authors in their sub-group's organization.
	 * Staff are scoped to none, so they have no such list.
	 *
	 * @return list<int>
	 */
	public static function orgIdsFor( int $userId ): array {
		$anywhere = self::forUser( $userId );
		if ( $anywhere->isAdmin ) {
			return [];
		}
		$orgIds = Roster::orgIdsOf( $userId );
		if ( ! $orgIds ) {
			return $anywhere->canAuthor() ? [ $anywhere->orgId ] : [];
		}
		return array_values(
			array_filter(
				$orgIds,
				static fn ( int $orgId ): bool => self::forUser( $userId, $orgId )->canAuthor()
			)
		);
	}

	/**
	 * The organizations an item belongs to, from the meta its kind keeps
	 * them in: content, a resource and an alert name a list, a project and
	 * a sub-group one parent.
	 *
	 * @return list<int>
	 */
	public static function orgIdsOfItem( int $postId ): array {
		$key = self::ITEM_ORG_KEYS[ $postId > 0 ? (string) get_post_type( $postId ) : '' ] ?? '';
		if ( '' === $key ) {
			return [];
		}
		return array_values( array_unique( array_filter( array_map( 'intval', (array) get_post_meta( $postId, $key, true ) ) ) ) );
	}

	/**
	 * The sub-groups an item is gated to. Content keeps them in its own
	 * table; a resource, an alert and a project in post meta.
	 *
	 * @return list<int>
	 */
	private static function subgroupIdsOfItem( int $postId ): array {
		$type = (string) get_post_type( $postId );
		if ( ContentPostType::SLUG === $type ) {
			return array_values( array_map( 'intval', ( new SubgroupRepository() )->subgroupsForContent( $postId ) ) );
		}
		$key = self::ITEM_SUBGROUP_KEYS[ $type ] ?? '';
		if ( '' === $key ) {
			return [];
		}
		return array_values( array_filter( array_map( 'intval', (array) get_post_meta( $postId, $key, true ) ) ) );
	}

	/** Forget the memo: only tests that flip caps or memberships mid-process need it. */
	public static function flushCache(): void {
		self::$cache = [];
	}

	/** Whether a membership tier carries the organization's management: admin or manager. */
	private static function managesAt( ?string $tier ): bool {
		return in_array( $tier, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true );
	}

	public function isLeader(): bool {
		return [] !== $this->leaderSubgroupIds;
	}

	/** Whether this user may author anything at all in the portal. */
	public function isAuthor(): bool {
		return $this->isAdmin || $this->isOrgManager || $this->isLeader();
	}

	/**
	 * Whether they may author now: an admin anywhere, anyone else only
	 * while they have an organization to author for.
	 */
	public function canAuthor(): bool {
		return $this->isAdmin || ( $this->isAuthor() && $this->orgId > 0 );
	}

	/**
	 * Entity types this scope may create. Leaders cannot create sub-groups:
	 * those belong to the organization, and its admins and managers keep them.
	 *
	 * @return string[]
	 */
	public function manageableEntities(): array {
		if ( ! $this->canAuthor() ) {
			return [];
		}
		if ( $this->isAdmin || $this->isOrgManager ) {
			return [ self::ENTITY_CONTENT, self::ENTITY_SUBGROUP, self::ENTITY_FORM, self::ENTITY_PROJECT, self::ENTITY_ALERT ];
		}
		if ( $this->isLeader() ) {
			return [ self::ENTITY_CONTENT, self::ENTITY_FORM, self::ENTITY_PROJECT, self::ENTITY_ALERT ];
		}
		return [];
	}

	public function canCreate( string $entity ): bool {
		return in_array( $entity, $this->manageableEntities(), true );
	}

	/**
	 * Author-owned editing: admins may edit anything; everyone else only the
	 * posts they authored, and only through the scope of the organization
	 * the post belongs to, while they still author there. Admin-created
	 * content is therefore read-only to a delegated author by design, and so
	 * is what a person wrote for an organization they no longer manage.
	 */
	public function canEdit( int $postId ): bool {
		if ( $this->isAdmin ) {
			return true;
		}
		if ( ! $this->canAuthor() || $postId <= 0 ) {
			return false;
		}
		return (int) get_post_field( 'post_author', $postId ) === $this->userId && $this->covers( $postId );
	}

	/**
	 * Whether the item is this scope's to act on: it belongs to the scope's
	 * organization, which the person manages, or is gated to a sub-group
	 * they lead there.
	 */
	private function covers( int $postId ): bool {
		if ( ! in_array( $this->orgId, self::orgIdsOfItem( $postId ), true ) ) {
			return false;
		}
		return $this->isOrgManager
			|| ( $this->isLeader() && [] !== array_intersect( $this->leaderSubgroupIds, self::subgroupIdsOfItem( $postId ) ) );
	}

	/**
	 * The org ids this author may stamp as audience. Non-admins are held to
	 * the organization the scope was asked about, whatever they propose:
	 * they can never widen.
	 *
	 * @param int[] $proposed
	 * @return int[]
	 */
	public function clampOrgIds( array $proposed ): array {
		if ( $this->isAdmin ) {
			return array_values( array_unique( array_filter( array_map( 'absint', $proposed ) ) ) );
		}
		return $this->orgId > 0 ? [ $this->orgId ] : [];
	}

	/**
	 * The sub-group ids this author may stamp. A leader is held to the
	 * sub-groups they lead there: those of them they proposed, or every one
	 * of them when they proposed none of theirs, so a leader of one is pinned
	 * to it and a leader of several never reaches the whole organization; an
	 * org manager may narrow to any sub-group under their org; an admin keeps
	 * whatever they proposed (parentage is still validated downstream by
	 * ContentController::filterSubgroupsByAudience()).
	 *
	 * @param int[] $proposed
	 * @return int[]
	 */
	public function clampSubgroupIds( array $proposed ): array {
		$proposed = array_values( array_filter( array_map( 'absint', $proposed ) ) );

		if ( $this->isAdmin ) {
			return $proposed;
		}
		if ( $this->isLeader() ) {
			$chosen = array_values( array_intersect( $this->leaderSubgroupIds, $proposed ) );
			return $chosen ? $chosen : $this->leaderSubgroupIds;
		}
		// Org manager: keep only sub-groups whose parent org is their own.
		$out = [];
		foreach ( $proposed as $sgId ) {
			if ( (int) get_post_meta( $sgId, SubgroupMeta::KEY_ORG_ID, true ) === $this->orgId ) {
				$out[] = $sgId;
			}
		}
		return $out;
	}

	/**
	 * The sub-group ids a delegated author's save stamps on an item. A
	 * manager's save that names none leaves the item's gate alone, which the
	 * controllers do by not asking; a leader's is clamped on every save, to
	 * what they proposed or, proposing none (null), to the item's own gate,
	 * which a create does not have yet. So a leader of several groups who
	 * edits a title keeps the group chosen, and one who creates with no
	 * choice reaches every group they lead.
	 *
	 * @param int        $postId   The item, which exists by now.
	 * @param int[]|null $proposed What the request named; null when it named none.
	 * @return int[]
	 */
	public function subgroupIdsForSave( int $postId, ?array $proposed ): array {
		return $this->clampSubgroupIds( $proposed ?? self::subgroupIdsOfItem( $postId ) );
	}

	/**
	 * Standalone-member audience. Only admins may target standalone members;
	 * org managers and leaders are scoped to org membership, so this is forced
	 * empty for them.
	 *
	 * @param int[] $proposed
	 * @return int[]
	 */
	public function clampStandaloneIds( array $proposed ): array {
		if ( $this->isAdmin ) {
			return array_values( array_unique( array_filter( array_map( 'absint', $proposed ) ) ) );
		}
		return [];
	}
}
