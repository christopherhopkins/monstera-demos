<?php
/**
 * The authorization scope of a portal author.
 *
 * This is the single source of truth for "what may this user create, edit, and
 * target?" — consumed identically by the REST controllers (enforcement) and the
 * portal templates (show/hide). Keeping both sides on one object is what stops
 * the org-hub UI from drifting out of step with what the server actually allows.
 *
 * Three actor tiers, in precedence order:
 *   - Admin (manage_monstera): unscoped — may author anything for any audience.
 *   - Org manager (manage_own_org): may author for their own org, optionally
 *     narrowed to sub-groups under it. Never another org, never standalone
 *     members.
 *   - Sub-group leader (a plain member appointed via Subgroups\Meta::KEY_LEADER):
 *     may author only for their one sub-group; audience is fully determined
 *     (parent org + that sub-group), nothing to choose.
 *
 * Editing is author-owned for non-admins: you may only edit posts you created.
 */

declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\Repository as SubgroupRepository;

final class AuthorScope {

	public const ENTITY_CONTENT  = 'content';
	public const ENTITY_SUBGROUP = 'subgroup';
	public const ENTITY_FORM     = 'form';
	public const ENTITY_PROJECT  = 'project';
	public const ENTITY_ALERT    = 'alert';

	/** @var array<int, self> Per-request memo keyed by user id. */
	private static array $cache = [];

	private function __construct(
		public readonly int $userId,
		public readonly bool $isAdmin,
		public readonly bool $isOrgManager,
		public readonly int $orgId,
		public readonly int $leaderSubgroupId
	) {}

	public static function forUser( int $userId ): self {
		if ( isset( self::$cache[ $userId ] ) ) {
			return self::$cache[ $userId ];
		}

		$isAdmin      = $userId > 0 && user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA );
		$isOrgManager = ! $isAdmin && $userId > 0 && user_can( $userId, Capabilities::CAP_MANAGE_OWN_ORG );
		$orgId        = $userId > 0 ? UserMeta::associatedOrg( $userId ) : 0;

		$leaderSubgroupId = 0;
		if ( ! $isAdmin && ! $isOrgManager && $userId > 0 ) {
			$leaderSubgroupId = SubgroupRepository::leaderSubgroupId( $userId );
			$groupOrg         = $leaderSubgroupId > 0 ? (int) get_post_meta( $leaderSubgroupId, SubgroupMeta::KEY_ORG_ID, true ) : 0;
			if ( $leaderSubgroupId > 0 && $orgId > 0 && $groupOrg !== $orgId ) {
				// The sub-group belongs to an organization they have left: the
				// leadership does not follow them to the next one.
				$leaderSubgroupId = 0;
			} elseif ( $leaderSubgroupId > 0 && 0 === $orgId ) {
				// A leader's org is the sub-group's parent org, even if the user
				// carries no associatedOrg meta of their own.
				$orgId = $groupOrg;
			}
		}

		self::$cache[ $userId ] = new self( $userId, $isAdmin, $isOrgManager, $orgId, $leaderSubgroupId );
		return self::$cache[ $userId ];
	}

	public static function forCurrentUser(): self {
		return self::forUser( get_current_user_id() );
	}

	/** Forget the memo — only needed in tests that flip caps mid-process. */
	public static function flushCache(): void {
		self::$cache = [];
	}

	public function isLeader(): bool {
		return $this->leaderSubgroupId > 0;
	}

	/** Whether this user may author anything at all in the portal. */
	public function isAuthor(): bool {
		return $this->isAdmin || $this->isOrgManager || $this->isLeader();
	}

	/**
	 * Whether they may author now: an admin anywhere, anyone else only
	 * while they have an organization to author for.
	 */
	public function canAuthor(): bool {
		return $this->isAdmin || ( $this->isAuthor() && $this->orgId > 0 );
	}

	/**
	 * Entity types this scope may create. Leaders cannot create sub-groups —
	 * those are org infrastructure managed by the org manager.
	 *
	 * @return string[]
	 */
	public function manageableEntities(): array {
		if ( ! $this->canAuthor() ) {
			return [];
		}
		if ( $this->isAdmin || $this->isOrgManager ) {
			return [ self::ENTITY_CONTENT, self::ENTITY_SUBGROUP, self::ENTITY_FORM, self::ENTITY_PROJECT, self::ENTITY_ALERT ];
		}
		if ( $this->isLeader() ) {
			return [ self::ENTITY_CONTENT, self::ENTITY_FORM, self::ENTITY_PROJECT, self::ENTITY_ALERT ];
		}
		return [];
	}

	public function canCreate( string $entity ): bool {
		return in_array( $entity, $this->manageableEntities(), true );
	}

	/**
	 * Author-owned editing: admins may edit anything; everyone else only the
	 * posts they authored. Admin-created content is therefore read-only to a
	 * delegated author by design.
	 */
	public function canEdit( int $postId ): bool {
		if ( $this->isAdmin ) {
			return true;
		}
		if ( ! $this->canAuthor() || $postId <= 0 ) {
			return false;
		}
		return (int) get_post_field( 'post_author', $postId ) === $this->userId;
	}

	/**
	 * The org ids this author may stamp as audience. Non-admins are forced to
	 * their own org regardless of what they propose — they can never widen.
	 *
	 * @param int[] $proposed
	 * @return int[]
	 */
	public function clampOrgIds( array $proposed ): array {
		if ( $this->isAdmin ) {
			return array_values( array_unique( array_filter( array_map( 'absint', $proposed ) ) ) );
		}
		return $this->orgId > 0 ? [ $this->orgId ] : [];
	}

	/**
	 * The sub-group ids this author may stamp. A leader is pinned to their one
	 * sub-group; an org manager may narrow to any sub-group under their org; an
	 * admin keeps whatever they proposed (parentage is still validated downstream
	 * by ContentController::filterSubgroupsByAudience()).
	 *
	 * @param int[] $proposed
	 * @return int[]
	 */
	public function clampSubgroupIds( array $proposed ): array {
		$proposed = array_values( array_filter( array_map( 'absint', $proposed ) ) );

		if ( $this->isAdmin ) {
			return $proposed;
		}
		if ( $this->isLeader() ) {
			return [ $this->leaderSubgroupId ];
		}
		// Org manager: keep only sub-groups whose parent org is their own.
		$out = [];
		foreach ( $proposed as $sgId ) {
			if ( (int) get_post_meta( $sgId, SubgroupMeta::KEY_ORG_ID, true ) === $this->orgId ) {
				$out[] = $sgId;
			}
		}
		return $out;
	}

	/**
	 * Standalone-member audience. Only admins may target standalone members;
	 * org managers and leaders are scoped to org membership, so this is forced
	 * empty for them.
	 *
	 * @param int[] $proposed
	 * @return int[]
	 */
	public function clampStandaloneIds( array $proposed ): array {
		if ( $this->isAdmin ) {
			return array_values( array_unique( array_filter( array_map( 'absint', $proposed ) ) ) );
		}
		return [];
	}
}
