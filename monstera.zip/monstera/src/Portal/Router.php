<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\AccessControl\PortalGuard;
use Monstera\AccessControl\SignIn;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Repository as OrgRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Dispatches a portal route to its template.
 *
 * Templates live in src/Portal/Templates/ and receive a $ctx array.
 */
final class Router {

	public function dispatch( string $route ): void {
		$user = wp_get_current_user();
		$ctx  = [
			'user'  => $user,
			'orgs'  => new OrgRepository(),
			'theme' => (string) ( get_user_meta( $user->ID, UserMeta::KEY_THEME, true ) ?: 'light' ),
			'route' => $route,
		];

		// The accessibility statement is public; anonymous visitors get a
		// minimal shell (brand + sign-in) and no member state.
		$isPublic = ! $user->exists() && in_array( $route, [ Routing::ROUTE_ACCESSIBILITY, Routing::ROUTE_SIGN_IN ], true );

		// Support's old addresses lead to its new pages.
		$moved = SupportPages::redirectTarget( $route, $_GET ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameters; nothing is written.
		if ( null !== $moved ) {
			wp_safe_redirect( $moved );
			exit;
		}

		// The sign-in page has no member state; a signed-in visitor moves on.
		if ( Routing::ROUTE_SIGN_IN === $route ) {
			SignIn::redirectSignedIn();
		}

		// Hydrate Interactivity state for shared portal data (theme, user, org).
		if ( ! $isPublic && function_exists( 'wp_interactivity_state' ) ) {
			$orgId   = UserMeta::associatedOrg( $user->ID );
			$orgName = $orgId ? get_the_title( $orgId ) : '';
			$orgSlug = $orgId ? get_post_field( 'post_name', $orgId ) : '';

			// Delegated-author context. A leader's org resolves to their
			// sub-group's parent org, so prefer the scope's org for the manage URL.
			$scope     = AuthorScope::forCurrentUser();
			$scopeOrg  = $scope->orgId ?: $orgId;
			$scopeSlug = $scopeOrg ? get_post_field( 'post_name', $scopeOrg ) : '';
			$actorType = $scope->isAdmin
				? 'admin'
				: ( $scope->isOrgManager ? 'org_manager' : ( $scope->isLeader() ? 'leader' : 'member' ) );
			$manageUrl = $scope->isAuthor() && $scopeSlug
				? add_query_arg( 'tab', 'manage', Routing::url( Routing::ROUTE_ORG, [ 'slug' => $scopeSlug ] ) )
				: '';

			wp_interactivity_state(
				'monstera',
				[
					'theme'            => $ctx['theme'],
					'userName'         => $user->display_name,
					'userEmail'        => $user->user_email,
					'orgId'            => $orgId,
					'orgName'          => $orgName,
					'orgSlug'          => $orgSlug,
					'canAuthorPortal'  => $scope->isAuthor(),
					'portalActorType'  => $actorType,
					'leaderSubgroupId' => $scope->leaderSubgroupId,
					'manageOrgId'      => $scope->isAuthor() ? $scopeOrg : 0,
					'nonce'            => wp_create_nonce( 'wp_rest' ),
					// ?rest_route= form so REST works under wp-now / SQLite where
					// pretty /wp-json/ rewrites don't reliably persist.
					'apiBase'          => esc_url_raw( Routing::restUrl( 'monstera/v1/' ) ),
					'urls'             => [
						'dashboard' => Routing::url( Routing::ROUTE_DASHBOARD ),
						'profile'   => Routing::url( Routing::ROUTE_PROFILE ),
						'directory' => Routing::url( Routing::ROUTE_DIRECTORY ),
						'forms'     => Routing::url( Routing::ROUTE_FORMS ),
						'projects'  => Routing::url( Routing::ROUTE_PROJECTS ),
						'support'   => Routing::url( Routing::ROUTE_SUPPORT ),
						'manage'    => $manageUrl,
					],
				]
			);
		}

		$template = match ( $route ) {
			Routing::ROUTE_DASHBOARD => 'dashboard.php',
			Routing::ROUTE_ORG       => 'org.php',
			Routing::ROUTE_PROFILE   => 'profile.php',
			Routing::ROUTE_CONTENT   => 'content.php',
			Routing::ROUTE_DIRECTORY => 'directory.php',
			Routing::ROUTE_FORMS     => 'forms.php',
			Routing::ROUTE_PROJECTS  => 'projects.php',
			Routing::ROUTE_PROJECT   => 'project.php',
			Routing::ROUTE_SUPPORT   => 'support.php',
			Routing::ROUTE_SUPPORT_NEW     => 'support-new.php',
			Routing::ROUTE_SUPPORT_REQUEST => 'support-request.php',
			Routing::ROUTE_ACCESSIBILITY => 'accessibility.php',
			Routing::ROUTE_SIGN_IN       => 'sign-in.php',
			default                  => 'dashboard.php',
		};

		// The guard names a blocked reason instead of redirecting; the page
		// becomes the blocked pattern at the URL the member asked for.
		$blocked = PortalGuard::blocked();
		if ( null !== $blocked && ! $isPublic ) {
			$template       = 'blocked.php';
			$ctx['blocked'] = $blocked;
		}

		status_header( null !== $blocked && PortalGuard::BLOCKED_NO_ORG !== $blocked ? 403 : 200 );
		nocache_headers();

		$this->renderShell( $template, $ctx, $isPublic );
	}

	/**
	 * @param array<string, mixed> $ctx
	 */
	private function renderShell( string $template, array $ctx, bool $isPublic = false ): void {
		$path = MONSTERA_DIR . 'src/Portal/Templates/' . $template;
		if ( ! is_file( $path ) ) {
			wp_die( esc_html__( 'Portal template not found.', 'monstera' ) );
		}

		include MONSTERA_DIR . 'src/Portal/Templates/' . ( $isPublic ? '_shell-open-public.php' : '_shell-open.php' );
		include $path;
		include MONSTERA_DIR . 'src/Portal/Templates/_shell-close.php';
	}
}
