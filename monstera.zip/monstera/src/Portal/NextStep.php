<?php
declare(strict_types=1);

namespace Monstera\Portal;

use DateTimeImmutable;
use DateTimeZone;
use Monstera\Core\Capabilities;
use Monstera\Core\SiteDay;
use Monstera\Projects\Repository as ProjectRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * The client's next step on the lists of projects (At-a-glance track, FR7
 * rows; comps 20, 23, 41, 70): a project row's meta line ends with "Your
 * next step by <date>", and the Portal's "Coming up" lists the steps due in
 * the next 90 days beside the due dates.
 *
 * The step is the client's, so only a client reader is told it on the
 * lists: staff read none there (the project's own page shows its band to
 * whoever opens it). A row says what staff wrote (Projects\Repository::
 * clientStep() with no discovery step), which it reads from the project's
 * meta the list has already loaded, at no read of its own. The lists show
 * only projects their reader may open (Projects\Repository::listedFor()
 * and forOrg(), which leave out what userCanAccess() would refuse; the
 * Phase 2 review). Every day is the site's (CalendarDay).
 */
final class NextStep {

	/** How far ahead "Coming up" looks, in days. */
	public const COMING_UP_DAYS = 90;

	/** The most dates "Coming up" lists, due dates and steps together (comps 20 and 23 draw six and seven). */
	public const COMING_UP_MAX = 8;

	/** Whether the reader is a client of the agency, the one an account team and a next step are for: anyone but staff. */
	public static function addressedTo( WP_User $user ): bool {
		return ! Capabilities::isStaff( $user ) && ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
	}

	/**
	 * Whether the reader is told the projects' next steps on the lists: a
	 * client the portal shows projects to, as the content rows name their
	 * projects only to a reader who may view them (ContentProjects::shown()).
	 */
	public static function shownTo( WP_User $user ): bool {
		return self::addressedTo( $user ) && user_can( $user, Capabilities::CAP_VIEW_PROJECTS );
	}

	/**
	 * A project row's last meta fact, escaped: "Your next step by <date>",
	 * "Your next step" without a date, or '' with none written.
	 */
	public static function rowFact( ProjectRepository $repo, int $projectId ): string {
		$step = $repo->clientStep( $projectId, false );
		if ( ! $step ) {
			return '';
		}
		$day = CalendarDay::format( $step['by'], 'M j' );
		return '<span>' . esc_html(
			'' === $day
				? __( 'Your next step', 'monstera' )
				/* translators: %s: the day the client's next step is due, e.g. "Oct 2" */
				: sprintf( __( 'Your next step by %s', 'monstera' ), $day )
		) . '</span>';
	}

	/**
	 * The days "Coming up" looks at: from the start of today to the start of
	 * the day COMING_UP_DAYS ahead, counted in the site's days (a day across
	 * a clock change is not 86,400 seconds).
	 *
	 * @param string $today Y-m-d, the site's today when ''; for a test that crosses a clock change.
	 * @return array{0: int, 1: int} The first moment in, and the first moment out.
	 */
	public static function window( string $today = '' ): array {
		// Today from the site's clock (Core\SiteDay), never through the
		// filterable wp_date(), whose answer a calendar plugin may rewrite.
		$day   = CalendarDay::ymd( '' !== $today ? $today : SiteDay::today() );
		$start = CalendarDay::start( $day );
		// The end is the start of the calendar's day COMING_UP_DAYS on: added
		// to a start a midnight clock change moved to 01:00, the days would
		// end an hour into that day (the Phase 5 review).
		$end = $start ? CalendarDay::start( ( new DateTimeImmutable( $day, new DateTimeZone( 'UTC' ) ) )->modify( '+' . self::COMING_UP_DAYS . ' days' )->format( 'Y-m-d' ) ) : null;
		return $start && $end ? [ $start->getTimestamp(), $end->getTimestamp() ] : [ 0, 0 ];
	}

	/**
	 * Whether a day (when it starts) falls in the window.
	 *
	 * @param array{0: int, 1: int} $window As window() answers it.
	 */
	public static function inWindow( int $at, array $window ): bool {
		return $at > 0 && $at >= $window[0] && $at < $window[1];
	}

	/**
	 * The step of a project that is coming up, in the window window()
	 * answers, or null.
	 *
	 * @param array{0: int, 1: int} $window
	 * @return array{date: int, detail: string}|null When the day starts, and the row's fact, unescaped.
	 */
	public static function comingUp( ProjectRepository $repo, int $projectId, array $window ): ?array {
		$step = $repo->clientStep( $projectId, false );
		$at   = $step ? ( CalendarDay::start( $step['by'] )?->getTimestamp() ?? 0 ) : 0;
		if ( ! $step || ! self::inWindow( $at, $window ) ) {
			return null;
		}
		return [
			'date'   => $at,
			/* translators: %s: the client's next step on a project, as staff wrote it */
			'detail' => sprintf( __( 'Your next step: %s', 'monstera' ), $step['sentence'] ),
		];
	}
}
