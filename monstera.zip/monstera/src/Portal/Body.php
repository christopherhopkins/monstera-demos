<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Capabilities;
use WP_Post;

defined( 'ABSPATH' ) || exit;

/**
 * A body the portal prints (a guide, a form's intro, a content item):
 * the_content's pipeline, with shortcodes run only when the team last wrote
 * it. A client's save strips the shortcodes it can find (the controllers'
 * bodyFrom()), but strip_shortcodes() leaves one in an attribute or in a
 * block's settings, which the_content would run as the site; so a body a
 * client wrote is read without do_shortcode at all (shortcodes remain
 * admin-only, the Forms-and-resources review).
 */
final class Body {

	/** '1' when the team last saved the body, '0' when a client did. */
	public const META_BY_TEAM = '_monstera_body_by_team';

	public static function stamp( int $postId, bool $byTeam ): void {
		update_post_meta( $postId, self::META_BY_TEAM, $byTeam ? '1' : '0' );
	}

	/**
	 * Whether the team wrote the body as it stands: by its stamp, or for a
	 * body never saved through the routes (a seed), by its author's role.
	 */
	public static function byTeam( WP_Post $post ): bool {
		$stamp = (string) get_post_meta( $post->ID, self::META_BY_TEAM, true );
		if ( '' !== $stamp ) {
			return '1' === $stamp;
		}
		$author = (int) $post->post_author;
		return $author > 0 && user_can( $author, Capabilities::CAP_MANAGE_MONSTERA );
	}

	/** The body as HTML, through the_content. */
	public static function html( WP_Post $post ): string {
		if ( self::byTeam( $post ) ) {
			return (string) apply_filters( 'the_content', $post->post_content );
		}
		$priority = has_filter( 'the_content', 'do_shortcode' );
		if ( false === $priority ) {
			return (string) apply_filters( 'the_content', $post->post_content );
		}
		remove_filter( 'the_content', 'do_shortcode', (int) $priority );
		try {
			return (string) apply_filters( 'the_content', $post->post_content );
		} finally {
			add_filter( 'the_content', 'do_shortcode', (int) $priority );
		}
	}
}
