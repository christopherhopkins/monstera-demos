<?php
declare(strict_types=1);

namespace Monstera\Portal;

use Monstera\Core\Routing;
use Monstera\Forms\Accepts;
use Monstera\Forms\AlreadySent;
use Monstera\Forms\AnswersRefused;
use Monstera\Forms\Fields;
use Monstera\Forms\FilesRefused;
use Monstera\Forms\Meta;
use Monstera\Forms\Submissions;
use Monstera\Support\Files as Uploads;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * A form sent without a script (Forms-and-resources track, FR5): the page's
 * own form posts to its own address, and the router hands the post here
 * before the page renders. What the REST route does for the store, this
 * does for the browser: the same rule (Accepts), the same store
 * (Submissions::create()), the same complaints. Sent, the page is asked for
 * again saying which send went (one post, one submission, however the
 * page is reloaded); refused, the page renders with each complaint under
 * its field and what was typed kept.
 */
final class FormSend {

	public const NONCE_FIELD = '_monstera_form';

	/** The nonce action for one form's send. */
	public static function nonceAction( int $formId ): string {
		return 'monstera_form_send_' . $formId;
	}

	/**
	 * Handle a post to a form's page.
	 *
	 * @param array<string, mixed> $post  The request's fields ($_POST), slashed as WordPress hands them.
	 * @param array<string, mixed> $files The request's files ($_FILES), each question's under its key.
	 * @param int                  $declaredLength The request's Content-Length, for a body PHP dropped for its size.
	 * @return array{redirect?: string, errors?: array<string, string>, values?: array<string, string>} Where to send the browser, or what the page says and shows.
	 */
	public static function handle( WP_User $user, int $formId, array $post, array $files, int $declaredLength = 0 ): array {
		$values = [];
		// WordPress slashes what the browser posted (wp_magic_quotes()); the
		// REST route reads it unslashed, and so does this.
		$post = wp_unslash( $post );
		foreach ( $post as $key => $value ) {
			if ( is_string( $key ) && is_scalar( $value ) ) {
				$values[ $key ] = (string) $value;
			}
		}
		$keep = static fn ( string $message ): array => [
			'errors' => [ '_form' => $message ],
			'values' => $values,
		];

		// Over post_max_size nothing arrives, the nonce included: say why.
		$dropped = Submissions::droppedForSize( Meta::fieldsOf( $formId ), $post || array_filter( $files ), $declaredLength );
		if ( $dropped ) {
			return [
				'errors' => $dropped,
				'values' => $values,
			];
		}
		if ( ! wp_verify_nonce( (string) ( $post[ self::NONCE_FIELD ] ?? '' ), self::nonceAction( $formId ) ) ) {
			return $keep( __( 'That did not send: the page had been open too long. Send again.', 'monstera' ) );
		}
		$accept = Accepts::for( $user, $formId );
		if ( Accepts::OK !== $accept ) {
			return $keep( self::refusal( $accept ) );
		}

		if ( Submissions::sendLimitReached( $user ) ) {
			return $keep( Submissions::saySendLimit() );
		}

		$uploads = [];
		foreach ( Fields::fileKeys( Meta::fieldsOf( $formId ) ) as $key ) {
			$uploads[ $key ] = Uploads::normalise( $files[ $key ] ?? null );
		}

		try {
			$row = Submissions::create( $formId, $user, $values, $uploads );
			Submissions::recordSend( $user );
		} catch ( AnswersRefused $refused ) {
			return [
				'errors' => $refused->errors,
				'values' => $values,
			];
		} catch ( FilesRefused $refused ) {
			return [
				'errors' => [ $refused->field() => $refused->reason() ],
				'values' => $values,
			];
		} catch ( AlreadySent $twice ) {
			return $keep( self::refusal( Accepts::ALREADY_SENT ) );
		} catch ( \RuntimeException $failure ) {
			return $keep( __( 'Your answers could not be stored. Try again.', 'monstera' ) );
		}

		return [
			'redirect' => add_query_arg( 'sent', (int) $row['id'], Routing::url( Routing::ROUTE_FORM, [ 'id' => $formId ] ) ),
		];
	}

	/** Why a form takes nothing now, in the words the route answers with (FormSubmissionsController). */
	public static function refusal( string $accept ): string {
		return match ( $accept ) {
			Accepts::DUE_PASSED   => __( 'This form\'s due date has passed.', 'monstera' ),
			Accepts::ALREADY_SENT => __( 'You have already sent this form.', 'monstera' ),
			Accepts::NOT_REACHED  => __( 'This form is not available to you.', 'monstera' ),
			default               => __( 'This form is closed.', 'monstera' ),
		};
	}
}
