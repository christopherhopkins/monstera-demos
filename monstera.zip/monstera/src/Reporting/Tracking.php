<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Modules;

/**
 * The events the admin detail pages count (FR13): content views, form
 * opens and project stage changes. Like the rest of the log's reporting
 * events they are recorded only while the Reporting module is on.
 */
final class Tracking {

	/**
	 * A member opened a content detail page. Logged once per member, item
	 * and day, so a refresh is not a second view; an admin's look is not a
	 * member view.
	 *
	 * @return bool Whether a row was written.
	 */
	public static function contentViewed( int $contentId, int $userId ): bool {
		if ( ! Modules::isActive( Modules::REPORTING ) || $contentId <= 0 || $userId <= 0 ) {
			return false;
		}
		if ( user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return false;
		}
		global $wpdb;
		$seen = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live check against the log it writes.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE event_type = %s AND object_id = %d AND user_id = %d AND occurred_at >= %s',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				'content_viewed',
				$contentId,
				$userId,
				gmdate( 'Y-m-d 00:00:00' )
			)
		);
		if ( $seen > 0 ) {
			return false;
		}
		ActivityLog::record( 'content_viewed', 'content', $contentId, [ 'user_id' => $userId ] );
		return true;
	}

	/** A member followed a form from the portal (through Forms\Opener). */
	public static function formOpened( int $formId, int $userId ): void {
		if ( Modules::isActive( Modules::REPORTING ) ) {
			ActivityLog::record( 'form_opened', 'form', $formId, [ 'user_id' => $userId ] );
		}
	}

	/** A project's stage changed (the project status hook). */
	public static function projectStageChanged( int $projectId, string $to, string $from ): void {
		if ( Modules::isActive( Modules::REPORTING ) ) {
			ActivityLog::record(
				'project_stage_changed',
				'project',
				$projectId,
				[
					'from' => $from,
					'to'   => $to,
				]
			);
		}
	}
}
