<?php
declare(strict_types=1);

namespace Monstera\Reporting;

/**
 * Activity log rows as the admin shows them: the sentence in parts (links
 * without HTML), the kind of event, the organization, and when, as an ISO
 * time and a short label. The dashboard's feed and the detail pages'
 * "Recent activity" read the same shape.
 */
final class ActivityFeed {

	/**
	 * @param list<array<string, mixed>> $rows Activity log rows (ARRAY_A).
	 * @return list<array{id: int, sentence: list<array{text: string, url?: string}>, kind: string, org: string, when: string, when_label: string}>
	 */
	public static function shape( array $rows ): array {
		$out = [];
		foreach ( $rows as $row ) {
			$described = ActivitySentences::describe( $row );
			$at        = (int) strtotime( (string) $row['occurred_at'] . ' UTC' );
			$out[]     = [
				'id'         => (int) $row['id'],
				'sentence'   => $described['parts'],
				'kind'       => $described['kind'],
				'org'        => $described['org'],
				'when'       => gmdate( 'Y-m-d\TH:i:s\Z', $at ),
				'when_label' => self::whenLabel( $at ),
			];
		}
		return $out;
	}

	/** "9:41am" today, "Yesterday", then "Sep 19", in the site's timezone. */
	public static function whenLabel( int $at ): string {
		$day = wp_date( 'Y-m-d', $at );
		if ( wp_date( 'Y-m-d' ) === $day ) {
			return (string) wp_date( get_option( 'time_format' ) ?: 'g:ia', $at );
		}
		if ( wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ) === $day ) {
			return __( 'Yesterday', 'monstera' );
		}
		return (string) wp_date( 'M j', $at );
	}
}
