<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use DateTimeImmutable;
use DateTimeZone;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\SiteDay;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Roster;

defined( 'ABSPATH' ) || exit;

/**
 * Append-only activity log.
 *
 * Stored in wp_monstera_activity_log; auto-purged daily per retention setting.
 * IPs are hashed (SHA-256 + site salt) so the log is useful for audit and
 * unique-user counts without retaining raw IPs.
 */
final class ActivityLog {

	/**
	 * Display cap for the sub-group engagement report when no explicit list is
	 * passed — large installs see the first N sub-groups (by title). A named
	 * constant rather than an inline literal so the bound is explicit, not a
	 * silent magic number.
	 */
	private const ENGAGEMENT_SUBGROUP_CAP = 50;

	/**
	 * @param array<string, mixed> $context
	 */
	public static function record( string $event, string $objectType = '', int $objectId = 0, array $context = [] ): void {
		global $wpdb;

		$userId = (int) ( $context['user_id'] ?? get_current_user_id() );
		unset( $context['user_id'] );

		$ip    = (string) ( $_SERVER['REMOTE_ADDR'] ?? '' );
		$orgId = self::orgFor( $objectType, $objectId, $userId, $context );

		$wpdb->insert(
			Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
			[
				'user_id'     => $userId,
				'event_type'  => $event,
				'object_type' => $objectType,
				'object_id'   => $objectId ?: null,
				'org_id'      => $orgId ?: null,
				'occurred_at' => current_time( 'mysql', true ),
				'ip_hash'     => $ip ? hash( 'sha256', $ip . wp_salt( 'auth' ) ) : '',
				'context'     => $context ? wp_json_encode( $context ) : null,
			],
			[ '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s' ]
		);

		do_action( Hooks::ACTIVITY_LOGGED, $event, $objectType, $objectId, $userId );
	}

	/**
	 * The organization a row is filed under: the one its context names (a
	 * caller that knows the event's organization passes it as org_id, as
	 * the Roster does for a membership), an organization row's own, or a
	 * project row's project's organization. A row about a content item, a
	 * resource or an alert is filed under the organization the item reaches
	 * the actor through (Organizations\Reach): someone whose first
	 * organization is A and who downloads, reads or publishes B's item did
	 * so as a member of B, and the log is append-only, so a row misfiled
	 * under A stays there. A row about a person, and the actor when nothing
	 * above names one, is filed under the person's primary organization
	 * (their first), the fallback for events with no organization of their
	 * own: a sign-in is the person's, not one organization's.
	 *
	 * @param array<string, mixed> $context
	 */
	private static function orgFor( string $objectType, int $objectId, int $userId, array $context ): int {
		if ( array_key_exists( 'org_id', $context ) ) {
			return (int) $context['org_id'];
		}
		if ( 'org' === $objectType ) {
			return $objectId;
		}
		if ( 'user' === $objectType && $objectId ) {
			return Roster::primaryOrgOf( $objectId );
		}
		// A project's row is its organization's, whoever acted: an admin has
		// no organization, and their stage changes went missing from its
		// activity.
		if ( 'project' === $objectType && $objectId ) {
			$orgId = (int) get_post_meta( $objectId, \Monstera\Projects\Meta::KEY_ORG_ID, true );
			if ( $orgId > 0 ) {
				return $orgId;
			}
		}
		// Reach falls back to the actor's primary organization itself, for an
		// item that reaches them through none (one for everyone, one that
		// names them).
		if ( $userId && $objectId ) {
			switch ( $objectType ) {
				case 'content':
					return Reach::ofContent( $userId, $objectId );
				case 'resource':
					return Reach::ofResource( $userId, $objectId );
				case 'form':
					return Reach::ofForm( $userId, $objectId );
				case 'alert':
					return Reach::ofAlert( $userId, $objectId );
			}
		}
		return $userId ? Roster::primaryOrgOf( $userId ) : 0;
	}

	/**
	 * A secure file was served: the one row for it (the access log reads it
	 * whether or not Reporting is on), then the hook for everything else.
	 */
	public static function recordDownload( int $contentId, int $userId, int $fileId ): void {
		self::record(
			'download',
			'content',
			$contentId,
			[
				'user_id' => $userId,
				'file_id' => $fileId,
			]
		);
		do_action( Hooks::CONTENT_DOWNLOADED, $contentId, $userId, $fileId );
	}

	/**
	 * A person's history, newest first: what they did and what was done to
	 * them (a welcome resent, being added to an organization).
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forUser( int $userId, int $limit = 10 ): array {
		global $wpdb;
		return self::rows(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE user_id = %d OR ( object_type = %s AND object_id = %d ) ORDER BY occurred_at DESC, id DESC LIMIT %d',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$userId,
				'user',
				$userId,
				max( 1, $limit )
			)
		);
	}

	/**
	 * What a person did themselves, newest first: the rows they are the
	 * actor of, for the events asked for. forUser() is the admin's history of
	 * a person and also holds what was done to them; the portal's "Your
	 * recent activity" reads a person their own acts, so it asks here, and
	 * names the events worth a row.
	 *
	 * @param list<string> $events The event types to read.
	 * @return list<array<string, mixed>>
	 */
	public static function actsOf( int $userId, array $events, int $limit = 10 ): array {
		if ( $userId <= 0 || ! $events ) {
			return [];
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $events ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %s built from count( $events ); every event goes through prepare() and the sniff cannot count them.
		$sql = $wpdb->prepare(
			"SELECT * FROM %i WHERE user_id = %d AND event_type IN ({$marks}) ORDER BY occurred_at DESC, id DESC LIMIT %d",
			Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
			$userId,
			...array_merge( array_values( $events ), [ max( 1, $limit ) ] )
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		return self::rows( $sql );
	}

	/**
	 * Everything filed under an organization, newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forOrg( int $orgId, int $limit = 10 ): array {
		global $wpdb;
		return self::rows(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE org_id = %d ORDER BY occurred_at DESC, id DESC LIMIT %d',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$orgId,
				max( 1, $limit )
			)
		);
	}

	/**
	 * Everything about one object (a content item, a project), newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forObject( string $objectType, int $objectId, int $limit = 10 ): array {
		global $wpdb;
		return self::rows(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE object_type = %s AND object_id = %d ORDER BY occurred_at DESC, id DESC LIMIT %d',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$objectType,
				$objectId,
				max( 1, $limit )
			)
		);
	}

	/**
	 * @param string $sql A prepared query.
	 * @return list<array<string, mixed>>
	 */
	private static function rows( string $sql ): array {
		global $wpdb;
		return array_values( (array) $wpdb->get_results( $sql, ARRAY_A ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared by the caller; the sidebars read live history.
	}

	/**
	 * Start of the calendar window used by both the weekly total and the
	 * daily buckets: the site's midnight $days - 1 days ago, as the UTC
	 * moment the rows are stamped in (Review-leftovers track, 2026-10-21;
	 * until then UTC's midnight, so a sign-in late on the site's day was
	 * counted on the next). Anchoring both to the same boundary is what
	 * makes loginsThisWeek and loginsByDay agree: a sliding "7 × 86400
	 * seconds ago" cutoff produces rows that fall on the partial day at the
	 * window's edge and never get bucketed.
	 */
	private static function windowStart( int $days ): string {
		// `today - (days - 1)` so that a 7-day window includes today + the
		// 6 preceding days = 7 calendar dates.
		return self::dayStartUtc( self::siteDayAgo( max( 0, $days - 1 ) ) );
	}

	/** The site's day $ago days before its today, as Y-m-d (a day on the calendar, so the arithmetic is UTC's). */
	private static function siteDayAgo( int $ago ): string {
		return ( new DateTimeImmutable( SiteDay::today(), new DateTimeZone( 'UTC' ) ) )->modify( sprintf( '%+d days', -$ago ) )->format( 'Y-m-d' );
	}

	/** When the site's day begins, as the UTC moment the log stamps rows in. */
	private static function dayStartUtc( string $day ): string {
		return ( new DateTimeImmutable( $day . ' 00:00:00', wp_timezone() ) )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	public static function loginsThisWeek(): int {
		return self::eventsInWindow( 'login', 7 );
	}

	public static function downloadsThisWeek(): int {
		return self::eventsInWindow( 'download', 7 );
	}

	/**
	 * Every event in the window, whatever its type (the activity export's
	 * row count).
	 */
	public static function eventsSince( int $days ): int {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE occurred_at >= %s', $table, self::windowStart( $days ) ) );
	}

	/**
	 * The seven days before this week's window, for the week-over-week word.
	 */
	public static function loginsLastWeek(): int {
		return max( 0, self::eventsInWindow( 'login', 14 ) - self::eventsInWindow( 'login', 7 ) );
	}

	public static function downloadsLastWeek(): int {
		return max( 0, self::eventsInWindow( 'download', 14 ) - self::eventsInWindow( 'download', 7 ) );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	public static function loginsByDay( int $days = 7 ): array {
		return self::eventsByDay( 'login', $days );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	public static function downloadsByDay( int $days = 7 ): array {
		return self::eventsByDay( 'download', $days );
	}

	/**
	 * Links and files opened and guides read (Forms-and-resources track,
	 * FR8: the Reports page's "Resource opens"): one count of both events.
	 */
	public const RESOURCE_OPENS = [ 'resource_opened', 'guide_viewed' ];

	public static function resourceOpensThisWeek(): int {
		return self::eventsInWindow( self::RESOURCE_OPENS, 7 );
	}

	public static function resourceOpensLastWeek(): int {
		return max( 0, self::eventsInWindow( self::RESOURCE_OPENS, 14 ) - self::eventsInWindow( self::RESOURCE_OPENS, 7 ) );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	public static function resourceOpensByDay( int $days = 7 ): array {
		return self::eventsByDay( self::RESOURCE_OPENS, $days );
	}

	public static function formSubmissionsThisWeek(): int {
		return self::eventsInWindow( 'form_submitted', 7 );
	}

	public static function formSubmissionsLastWeek(): int {
		return max( 0, self::eventsInWindow( 'form_submitted', 14 ) - self::eventsInWindow( 'form_submitted', 7 ) );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	public static function formSubmissionsByDay( int $days = 7 ): array {
		return self::eventsByDay( 'form_submitted', $days );
	}

	/**
	 * @param string|list<string> $eventTypes One event, or several counted together.
	 */
	private static function eventsInWindow( string|array $eventTypes, int $days ): int {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$since = self::windowStart( $days );
		$types = array_values( (array) $eventTypes );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %s per event type, spread in below.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE event_type IN (' . implode( ',', array_fill( 0, count( $types ), '%s' ) ) . ') AND occurred_at >= %s', $table, ...array_merge( $types, [ $since ] ) ) );
		// phpcs:enable
	}

	/**
	 * @param string|list<string> $eventTypes One event, or several counted together.
	 * @return array<int, array{day:string, count:int}>
	 */
	private static function eventsByDay( string|array $eventTypes, int $days ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$days  = max( 1, $days );

		// $days buckets ending today (i = 0) and reaching back to $days - 1
		// days ago, each the site's day: it begins at the site's midnight
		// and ends where the next begins, so a clock change or a half-hour
		// zone costs nothing, and the first bucket begins where windowStart
		// does, so every row in the window lands in exactly one bucket. One
		// query sums every bucket (DATE() would bucket by UTC's day).
		$labels = [];
		$bounds = [];
		for ( $i = $days - 1; $i >= -1; --$i ) {
			$bounds[] = self::dayStartUtc( self::siteDayAgo( $i ) );
		}
		$sums   = [];
		$values = [];
		$utc    = new DateTimeZone( 'UTC' );
		for ( $i = 0; $i < $days; $i++ ) {
			// The day's name in the site's language (wp_date() reads the
			// locale's abbreviations), of the date itself, so no zone moves it.
			$labels[] = wp_date( 'D', (int) strtotime( self::siteDayAgo( $days - 1 - $i ) . ' 12:00:00 UTC' ), $utc );
			$sums[]   = 'SUM(occurred_at >= %s AND occurred_at < %s)';
			$values[] = $bounds[ $i ];
			$values[] = $bounds[ $i + 1 ];
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- the SUM list is one fixed template per bucket, a %s pair each; every value goes through prepare().
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT ' . implode( ', ', $sums ) . ' FROM %i WHERE event_type IN (' . implode( ',', array_fill( 0, count( (array) $eventTypes ), '%s' ) ) . ') AND occurred_at >= %s AND occurred_at < %s',
				...array_merge( $values, [ $table ], array_values( (array) $eventTypes ), [ $bounds[0], $bounds[ $days ] ] )
			),
			ARRAY_N
		);
		// phpcs:enable

		$out = [];
		foreach ( $labels as $i => $label ) {
			$out[] = [
				'day'   => $label,
				'count' => (int) ( $row[ $i ] ?? 0 ),
			];
		}
		return $out;
	}

	/**
	 * @return array<int, array{id:int, title:string, views:int}>
	 */
	public static function topContent( int $limit = 5 ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT object_id, COUNT(*) AS views
			   FROM %i
			  WHERE event_type = 'download' AND object_type = 'content'
			  GROUP BY object_id
			  ORDER BY views DESC
			  LIMIT %d",
				$table,
				$limit
			),
			ARRAY_A
		);

		$out = [];
		foreach ( $rows as $row ) {
			$id = (int) $row['object_id'];
			// Download rows outlive their content; a deleted item would
			// render as a nameless link in the report, so it is left out.
			if ( ! get_post( $id ) instanceof \WP_Post ) {
				continue;
			}
			$out[] = [
				'id'    => $id,
				'title' => (string) get_the_title( $id ),
				'views' => (int) $row['views'],
			];
		}
		return $out;
	}

	public static function activeMemberCount(): int {
		$users = get_users(
			[
				'role__in' => [ 'monstera_member', 'monstera_org_manager', 'monstera_member_standalone' ],
				'fields'   => 'ID',
				'number'   => -1,
			]
		);
		return count( (array) $users );
	}

	/**
	 * Engagement counts per sub-group.
	 *
	 * For each sub-group passed in (or all sub-groups if none given), returns:
	 *   - logins: login events from users who are members of the sub-group
	 *             in the last $days days
	 *   - views:  download events on content that's gated by the sub-group
	 *             in the last $days days
	 *
	 * Both metrics come from the activity log + join tables, so this is
	 * truthful "engagement" (real downloads + logins by real members of the
	 * group), not just post counts.
	 *
	 * @param array<int, int>|null $subgroupIds  Restrict to these IDs (default: all)
	 * @param int                  $days         Look-back window
	 * @return array<int, array{id:int, name:string, logins:int, views:int, member_count:int}>
	 */
	public static function subgroupEngagement( ?array $subgroupIds = null, int $days = 30 ): array {
		global $wpdb;
		$logTable     = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$membersTable = Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS );
		$contentTable = Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS );

		// Calendar-midnight aligned (via windowStart) so this window matches the
		// rest of the reporting module instead of a rolling per-second cutoff.
		$since = self::windowStart( $days );

		// Resolve which sub-groups to report on.
		$ids = $subgroupIds;
		if ( null === $ids ) {
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'monstera_subgroup' AND post_status = 'publish' ORDER BY post_title ASC LIMIT %d", self::ENGAGEMENT_SUBGROUP_CAP ) );
		}
		$ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		if ( ! $ids ) {
			return [];
		}

		$idPlaceholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// Logins per sub-group: count login events whose user_id is a
		// current member of the sub-group.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $idPlaceholders is a list of %d built from count( $ids ); every id goes through prepare() and the sniff cannot count them.
		$loginsRaw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT sm.subgroup_id AS sg, COUNT(*) AS c
				   FROM %i AS a
				   INNER JOIN %i AS sm
				     ON sm.member_id = a.user_id
				    AND sm.subgroup_id IN ({$idPlaceholders})
				  WHERE a.event_type = 'login' AND a.occurred_at >= %s
				  GROUP BY sm.subgroup_id",
				$logTable,
				$membersTable,
				...array_merge( $ids, [ $since ] )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$loginsBySg = [];
		foreach ( (array) $loginsRaw as $row ) {
			$loginsBySg[ (int) $row['sg'] ] = (int) $row['c'];
		}

		// Views per sub-group: count download events on content gated by the
		// sub-group.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $idPlaceholders is a list of %d built from count( $ids ); every id goes through prepare() and the sniff cannot count them.
		$viewsRaw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT cs.subgroup_id AS sg, COUNT(*) AS c
				   FROM %i AS a
				   INNER JOIN %i AS cs
				     ON cs.content_id = a.object_id
				    AND cs.subgroup_id IN ({$idPlaceholders})
				  WHERE a.event_type = 'download'
				    AND a.object_type = 'content'
				    AND a.occurred_at >= %s
				  GROUP BY cs.subgroup_id",
				$logTable,
				$contentTable,
				...array_merge( $ids, [ $since ] )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$viewsBySg = [];
		foreach ( (array) $viewsRaw as $row ) {
			$viewsBySg[ (int) $row['sg'] ] = (int) $row['c'];
		}

		// Member counts per sub-group (one round trip).
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $idPlaceholders is a list of %d built from count( $ids ); every id goes through prepare() and the sniff cannot count them.
		$memberCountsRaw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT subgroup_id, COUNT(DISTINCT member_id) AS c
				   FROM %i
				  WHERE subgroup_id IN ({$idPlaceholders})
				  GROUP BY subgroup_id",
				$membersTable,
				...$ids
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$membersBySg = [];
		foreach ( (array) $memberCountsRaw as $row ) {
			$membersBySg[ (int) $row['subgroup_id'] ] = (int) $row['c'];
		}

		$out = [];
		foreach ( $ids as $sgId ) {
			$out[] = [
				'id'           => $sgId,
				'name'         => (string) get_the_title( $sgId ),
				'logins'       => $loginsBySg[ $sgId ] ?? 0,
				'views'        => $viewsBySg[ $sgId ] ?? 0,
				'member_count' => $membersBySg[ $sgId ] ?? 0,
			];
		}
		// Most engaged first.
		usort( $out, static fn ( $a, $b ) => ( $b['views'] + $b['logins'] ) <=> ( $a['views'] + $a['logins'] ) );
		return $out;
	}
}
