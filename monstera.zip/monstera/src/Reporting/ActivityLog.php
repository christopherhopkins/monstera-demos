<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;

/**
 * Append-only activity log.
 *
 * Stored in wp_monstera_activity_log; auto-purged daily per retention setting.
 * IPs are hashed (SHA-256 + site salt) so the log is useful for audit and
 * unique-user counts without retaining raw IPs.
 */
final class ActivityLog {

	/**
	 * Display cap for the sub-group engagement report when no explicit list is
	 * passed — large installs see the first N sub-groups (by title). A named
	 * constant rather than an inline literal so the bound is explicit, not a
	 * silent magic number.
	 */
	private const ENGAGEMENT_SUBGROUP_CAP = 50;

	/**
	 * @param array<string, mixed> $context
	 */
	public static function record( string $event, string $objectType = '', int $objectId = 0, array $context = [] ): void {
		global $wpdb;

		$userId = (int) ( $context['user_id'] ?? get_current_user_id() );
		unset( $context['user_id'] );

		$ip    = (string) ( $_SERVER['REMOTE_ADDR'] ?? '' );
		$orgId = self::orgFor( $objectType, $objectId, $userId, $context );

		$wpdb->insert(
			Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
			[
				'user_id'     => $userId,
				'event_type'  => $event,
				'object_type' => $objectType,
				'object_id'   => $objectId ?: null,
				'org_id'      => $orgId ?: null,
				'occurred_at' => current_time( 'mysql', true ),
				'ip_hash'     => $ip ? hash( 'sha256', $ip . wp_salt( 'auth' ) ) : '',
				'context'     => $context ? wp_json_encode( $context ) : null,
			],
			[ '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s' ]
		);

		do_action( Hooks::ACTIVITY_LOGGED, $event, $objectType, $objectId, $userId );
	}

	/**
	 * The organization a row is filed under: one the context names (a move
	 * files under the destination), an organization row's own, a person's
	 * organization for a row about them, else the actor's.
	 *
	 * @param array<string, mixed> $context
	 */
	private static function orgFor( string $objectType, int $objectId, int $userId, array $context ): int {
		if ( array_key_exists( 'org_id', $context ) ) {
			return (int) $context['org_id'];
		}
		if ( 'org' === $objectType ) {
			return $objectId;
		}
		if ( 'user' === $objectType && $objectId ) {
			return UserMeta::associatedOrg( $objectId );
		}
		// A project's row is its organization's, whoever acted: an admin has
		// no organization, and their stage changes went missing from its
		// activity.
		if ( 'project' === $objectType && $objectId ) {
			$orgId = (int) get_post_meta( $objectId, \Monstera\Projects\Meta::KEY_ORG_ID, true );
			if ( $orgId > 0 ) {
				return $orgId;
			}
		}
		return $userId ? UserMeta::associatedOrg( $userId ) : 0;
	}

	/**
	 * A secure file was served: the one row for it (the access log reads it
	 * whether or not Reporting is on), then the hook for everything else.
	 */
	public static function recordDownload( int $contentId, int $userId, int $fileId ): void {
		self::record(
			'download',
			'content',
			$contentId,
			[
				'user_id' => $userId,
				'file_id' => $fileId,
			]
		);
		do_action( Hooks::CONTENT_DOWNLOADED, $contentId, $userId, $fileId );
	}

	/**
	 * A person's history, newest first: what they did and what was done to
	 * them (a welcome resent, a move to another organization).
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forUser( int $userId, int $limit = 10 ): array {
		global $wpdb;
		return self::rows(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE user_id = %d OR ( object_type = %s AND object_id = %d ) ORDER BY occurred_at DESC, id DESC LIMIT %d',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$userId,
				'user',
				$userId,
				max( 1, $limit )
			)
		);
	}

	/**
	 * Everything filed under an organization, newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forOrg( int $orgId, int $limit = 10 ): array {
		global $wpdb;
		return self::rows(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE org_id = %d ORDER BY occurred_at DESC, id DESC LIMIT %d',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$orgId,
				max( 1, $limit )
			)
		);
	}

	/**
	 * Everything about one object (a content item, a project), newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forObject( string $objectType, int $objectId, int $limit = 10 ): array {
		global $wpdb;
		return self::rows(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE object_type = %s AND object_id = %d ORDER BY occurred_at DESC, id DESC LIMIT %d',
				Schema::tableName( Schema::TABLE_ACTIVITY_LOG ),
				$objectType,
				$objectId,
				max( 1, $limit )
			)
		);
	}

	/**
	 * @param string $sql A prepared query.
	 * @return list<array<string, mixed>>
	 */
	private static function rows( string $sql ): array {
		global $wpdb;
		return array_values( (array) $wpdb->get_results( $sql, ARRAY_A ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared by the caller; the sidebars read live history.
	}

	/**
	 * Start of the calendar window (UTC midnight) used by both the weekly
	 * total and the daily buckets. Anchoring both to the same date boundary
	 * is what makes loginsThisWeek and loginsByDay agree — a sliding
	 * "7 × 86400 seconds ago" cutoff produces rows that fall on the partial
	 * day at the window's edge and never get bucketed.
	 */
	private static function windowStart( int $days ): string {
		$today = gmdate( 'Y-m-d' );
		// `today - (days - 1)` so that a 7-day window includes today + the
		// 6 preceding days = 7 calendar dates.
		$startDate = gmdate( 'Y-m-d', strtotime( $today . ' -' . max( 0, $days - 1 ) . ' days' ) );
		return $startDate . ' 00:00:00';
	}

	public static function loginsThisWeek(): int {
		return self::eventsInWindow( 'login', 7 );
	}

	public static function downloadsThisWeek(): int {
		return self::eventsInWindow( 'download', 7 );
	}

	/**
	 * Every event in the window, whatever its type (the activity export's
	 * row count).
	 */
	public static function eventsSince( int $days ): int {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE occurred_at >= %s', $table, self::windowStart( $days ) ) );
	}

	/**
	 * The seven days before this week's window, for the week-over-week word.
	 */
	public static function loginsLastWeek(): int {
		return max( 0, self::eventsInWindow( 'login', 14 ) - self::eventsInWindow( 'login', 7 ) );
	}

	public static function downloadsLastWeek(): int {
		return max( 0, self::eventsInWindow( 'download', 14 ) - self::eventsInWindow( 'download', 7 ) );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	public static function loginsByDay( int $days = 7 ): array {
		return self::eventsByDay( 'login', $days );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	public static function downloadsByDay( int $days = 7 ): array {
		return self::eventsByDay( 'download', $days );
	}

	private static function eventsInWindow( string $eventType, int $days ): int {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$since = self::windowStart( $days );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE event_type = %s AND occurred_at >= %s', $table, $eventType, $since ) );
	}

	/**
	 * @return array<int, array{day:string, count:int}>
	 */
	private static function eventsByDay( string $eventType, int $days ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$since = self::windowStart( $days );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT DATE(occurred_at) AS d, COUNT(*) AS c
			   FROM %i
			  WHERE event_type = %s AND occurred_at >= %s
			  GROUP BY DATE(occurred_at)
			  ORDER BY d ASC',
				$table,
				$eventType,
				$since
			),
			ARRAY_A
		);

		$by = [];
		foreach ( $rows as $row ) {
			$by[ $row['d'] ] = (int) $row['c'];
		}

		// Build $days entries ending today (i = 0) and reaching back to
		// $days - 1 days ago — same alignment as windowStart so every row
		// in the SQL window lands in exactly one bucket.
		$out = [];
		for ( $i = $days - 1; $i >= 0; --$i ) {
			$day   = gmdate( 'Y-m-d', strtotime( gmdate( 'Y-m-d' ) . ' -' . $i . ' days' ) );
			$out[] = [
				'day'   => gmdate( 'D', strtotime( $day ) ),
				'count' => $by[ $day ] ?? 0,
			];
		}
		return $out;
	}

	/**
	 * @return array<int, array{id:int, title:string, views:int}>
	 */
	public static function topContent( int $limit = 5 ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT object_id, COUNT(*) AS views
			   FROM %i
			  WHERE event_type = 'download' AND object_type = 'content'
			  GROUP BY object_id
			  ORDER BY views DESC
			  LIMIT %d",
				$table,
				$limit
			),
			ARRAY_A
		);

		$out = [];
		foreach ( $rows as $row ) {
			$id = (int) $row['object_id'];
			// Download rows outlive their content; a deleted item would
			// render as a nameless link in the report, so it is left out.
			if ( ! get_post( $id ) instanceof \WP_Post ) {
				continue;
			}
			$out[] = [
				'id'    => $id,
				'title' => (string) get_the_title( $id ),
				'views' => (int) $row['views'],
			];
		}
		return $out;
	}

	public static function activeMemberCount(): int {
		$users = get_users(
			[
				'role__in' => [ 'monstera_member', 'monstera_org_manager', 'monstera_member_standalone' ],
				'fields'   => 'ID',
				'number'   => -1,
			]
		);
		return count( (array) $users );
	}

	/**
	 * Engagement counts per sub-group.
	 *
	 * For each sub-group passed in (or all sub-groups if none given), returns:
	 *   - logins: login events from users who are members of the sub-group
	 *             in the last $days days
	 *   - views:  download events on content that's gated by the sub-group
	 *             in the last $days days
	 *
	 * Both metrics come from the activity log + join tables, so this is
	 * truthful "engagement" (real downloads + logins by real members of the
	 * group), not just post counts.
	 *
	 * @param array<int, int>|null $subgroupIds  Restrict to these IDs (default: all)
	 * @param int                  $days         Look-back window
	 * @return array<int, array{id:int, name:string, logins:int, views:int, member_count:int}>
	 */
	public static function subgroupEngagement( ?array $subgroupIds = null, int $days = 30 ): array {
		global $wpdb;
		$logTable     = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$membersTable = Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS );
		$contentTable = Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS );

		// Calendar-midnight aligned (via windowStart) so this window matches the
		// rest of the reporting module instead of a rolling per-second cutoff.
		$since = self::windowStart( $days );

		// Resolve which sub-groups to report on.
		$ids = $subgroupIds;
		if ( null === $ids ) {
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'monstera_subgroup' AND post_status = 'publish' ORDER BY post_title ASC LIMIT %d", self::ENGAGEMENT_SUBGROUP_CAP ) );
		}
		$ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		if ( ! $ids ) {
			return [];
		}

		$idPlaceholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// Logins per sub-group: count login events whose user_id is a
		// current member of the sub-group.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $idPlaceholders is a list of %d built from count( $ids ); every id goes through prepare() and the sniff cannot count them.
		$loginsRaw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT sm.subgroup_id AS sg, COUNT(*) AS c
				   FROM %i AS a
				   INNER JOIN %i AS sm
				     ON sm.member_id = a.user_id
				    AND sm.subgroup_id IN ({$idPlaceholders})
				  WHERE a.event_type = 'login' AND a.occurred_at >= %s
				  GROUP BY sm.subgroup_id",
				$logTable,
				$membersTable,
				...array_merge( $ids, [ $since ] )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$loginsBySg = [];
		foreach ( (array) $loginsRaw as $row ) {
			$loginsBySg[ (int) $row['sg'] ] = (int) $row['c'];
		}

		// Views per sub-group: count download events on content gated by the
		// sub-group.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $idPlaceholders is a list of %d built from count( $ids ); every id goes through prepare() and the sniff cannot count them.
		$viewsRaw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT cs.subgroup_id AS sg, COUNT(*) AS c
				   FROM %i AS a
				   INNER JOIN %i AS cs
				     ON cs.content_id = a.object_id
				    AND cs.subgroup_id IN ({$idPlaceholders})
				  WHERE a.event_type = 'download'
				    AND a.object_type = 'content'
				    AND a.occurred_at >= %s
				  GROUP BY cs.subgroup_id",
				$logTable,
				$contentTable,
				...array_merge( $ids, [ $since ] )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$viewsBySg = [];
		foreach ( (array) $viewsRaw as $row ) {
			$viewsBySg[ (int) $row['sg'] ] = (int) $row['c'];
		}

		// Member counts per sub-group (one round trip).
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $idPlaceholders is a list of %d built from count( $ids ); every id goes through prepare() and the sniff cannot count them.
		$memberCountsRaw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT subgroup_id, COUNT(DISTINCT member_id) AS c
				   FROM %i
				  WHERE subgroup_id IN ({$idPlaceholders})
				  GROUP BY subgroup_id",
				$membersTable,
				...$ids
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$membersBySg = [];
		foreach ( (array) $memberCountsRaw as $row ) {
			$membersBySg[ (int) $row['subgroup_id'] ] = (int) $row['c'];
		}

		$out = [];
		foreach ( $ids as $sgId ) {
			$out[] = [
				'id'           => $sgId,
				'name'         => (string) get_the_title( $sgId ),
				'logins'       => $loginsBySg[ $sgId ] ?? 0,
				'views'        => $viewsBySg[ $sgId ] ?? 0,
				'member_count' => $membersBySg[ $sgId ] ?? 0,
			];
		}
		// Most engaged first.
		usort( $out, static fn ( $a, $b ) => ( $b['views'] + $b['logins'] ) <=> ( $a['views'] + $a['logins'] ) );
		return $out;
	}
}
