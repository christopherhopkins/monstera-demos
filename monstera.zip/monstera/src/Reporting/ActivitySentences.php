<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Notifications\TemplateEngine;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Support\Repository as SupportRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Turns an activity log row into the sentence the admin dashboard shows
 * (comp 90): who did what to which named thing, with the named things as
 * links into the admin shell, plus the organization and a one-word kind for
 * the meta line.
 *
 * A sentence is returned as parts, each `{ text, url? }`, so the page can
 * render links without trusting HTML. Templates are translatable strings
 * with numbered placeholders, which a translation may reorder; every
 * placeholder becomes one part.
 *
 * The portal reads a person their own acts back ("Your recent activity" on
 * the dashboard), and those sentences are here too, each beside the admin's
 * for the same event: "You downloaded Q3 board pack" where the admin reads
 * "Sasha Lee downloaded Q3 board pack". describeOwn() asks for one.
 */
final class ActivitySentences {

	/**
	 * Every event the plugin records. A test reads the source for
	 * ActivityLog::record() calls and fails on an event missing here.
	 * member_org_changed is no longer recorded: adding someone to an
	 * organization moves them out of nothing, and the Roster's
	 * membership_added says who joined what. It stays so that a log written
	 * while it was still reads as sentences.
	 */
	public const KNOWN_EVENTS = [
		'login',
		'download',
		'content_downloaded',
		'publish',
		'notification',
		'welcome_resent',
		'member_org_changed',
		'membership_added',
		'membership_removed',
		'membership_tier_changed',
		'staff_assigned',
		'staff_unassigned',
		'team_added',
		'team_role_changed',
		'team_removed',
		'org_suspended',
		'org_tier_changed',
		'content_viewed',
		'form_opened',
		'project_stage_changed',
		'alert_ended',
		'intake_file_added',
		'intake_file_removed',
		'intake_file_downloaded',
		'support_file_opened',
		'support_request_opened',
		'support_replied',
		'support_status_changed',
		'support_priority_changed',
	];

	/**
	 * The events a person reads back as their own acts in the portal, each
	 * with a sentence in the second person: an item viewed, downloaded or
	 * published, a resource opened, a file added to a project's discovery, a
	 * support request opened or answered. A row per act worth telling: a
	 * sign-in begins every visit and would fill the list, opening an
	 * attachment of one's own is part of reading the thing it hangs on, and
	 * a change to a roster names another person, whose standing the portal
	 * tells on the roster alone.
	 */
	public const OWN_EVENTS = [
		'content_viewed',
		'download',
		'content_downloaded',
		'publish',
		'form_opened',
		'intake_file_added',
		'support_request_opened',
		'support_replied',
	];

	/**
	 * The same row as its actor reads it back in the portal: the sentence in
	 * the second person, around the thing it names. The caller says what
	 * that thing is to this reader, its name and its page in the portal,
	 * having found that they can still open it; the admin's sentence would
	 * link it into the admin, where a member cannot go. Only the events of
	 * OWN_EVENTS have such a sentence. Any other event answers with no
	 * parts, never with the admin's sentence in its place, so the caller has
	 * nothing to print for it.
	 *
	 * @param array<string, mixed>              $row   An activity log row (ARRAY_A) the reader is the actor of.
	 * @param array{text: string, url?: string} $thing The item, resource, project or request the row is about, as the reader reaches it.
	 * @return list<array{text: string, url?: string}> Empty for an event that is not one of OWN_EVENTS.
	 */
	public static function describeOwn( array $row, array $thing ): array {
		if ( ! in_array( (string) ( $row['event_type'] ?? '' ), self::OWN_EVENTS, true ) ) {
			return [];
		}
		return self::describe( $row, $thing )['parts'];
	}

	/**
	 * @param array<string, mixed>                   $row An activity log row (ARRAY_A).
	 * @param array{text: string, url?: string}|null $own The thing the row names, when the sentence is the actor's own (describeOwn()); null for the admin's sentence.
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	public static function describe( array $row, ?array $own = null ): array {
		$event    = (string) ( $row['event_type'] ?? '' );
		$actorId  = (int) ( $row['user_id'] ?? 0 );
		$objectId = (int) ( $row['object_id'] ?? 0 );
		$context  = json_decode( (string) ( $row['context'] ?? '' ), true );
		$context  = is_array( $context ) ? $context : [];
		$actor    = $actorId ? get_userdata( $actorId ) : false;
		$actorRef = $actor instanceof WP_User ? [ 'text' => UserMeta::fullName( $actor ) ] : null;

		switch ( $event ) {
			case 'login':
				$member = self::person( $objectId ?: $actorId );
				return self::result(
					/* translators: %1$s: a member's name */
					self::sentence( __( '%1$s signed in', 'monstera' ), [ $member ] ),
					__( 'Sign-in', 'monstera' ),
					self::orgOf( $row, $objectId ?: $actorId )
				);

			case 'download':
			case 'content_downloaded':
				if ( $own ) {
					/* translators: %1$s: a content item's title */
					return self::result( self::sentence( __( 'You downloaded %1$s', 'monstera' ), [ $own ] ), __( 'Download', 'monstera' ), '' );
				}
				$item = self::content( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: a member's name, 2: a content item's title */
						? self::sentence( __( '%1$s downloaded %2$s', 'monstera' ), [ $actorRef, $item ] )
						/* translators: %1$s: a content item's title */
						: self::sentence( __( '%1$s was downloaded', 'monstera' ), [ $item ] ),
					__( 'Download', 'monstera' ),
					self::orgOf( $row, $actorId )
				);

			case 'publish':
				if ( $own ) {
					/* translators: %1$s: a content item's title */
					return self::result( self::sentence( __( 'You published %1$s', 'monstera' ), [ $own ] ), __( 'Content', 'monstera' ), '' );
				}
				$item = self::content( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: a person's name, 2: a content item's title */
						? self::sentence( __( '%1$s published %2$s', 'monstera' ), [ $actorRef, $item ] )
						/* translators: %1$s: a content item's title */
						: self::sentence( __( '%1$s was published', 'monstera' ), [ $item ] ),
					__( 'Content', 'monstera' ),
					''
				);

			case 'notification':
				return self::result(
					self::sentence( self::emailTemplate( (string) ( $context['event'] ?? '' ) ), [ self::person( $objectId ) ] ),
					__( 'Email', 'monstera' ),
					self::orgOf( $row, $objectId )
				);

			case 'welcome_resent':
				$member = self::person( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: the admin's name, 2: the member's name */
						? self::sentence( __( '%1$s resent the welcome email to %2$s', 'monstera' ), [ $actorRef, $member ] )
						/* translators: %1$s: a member's name */
						: self::sentence( __( 'Welcome email resent to %1$s', 'monstera' ), [ $member ] ),
					__( 'Email', 'monstera' ),
					self::orgOf( $row, $objectId )
				);

			case 'member_org_changed':
				return self::describeMove( $actorRef, self::person( $objectId ), (int) ( $context['org_id'] ?? 0 ) );

			case 'membership_added':
			case 'membership_tier_changed':
				return self::describeMembership( $event, $actorRef, self::person( $objectId ), $context );

			case 'membership_removed':
				return self::describeMembership( $event, $actorRef, self::removed( $objectId, $context ), $context );

			// An assignment is about one of the team, as the three below are.
			case 'staff_assigned':
			case 'staff_unassigned':
				return self::describeMembership( $event, $actorRef, self::teammate( $objectId ), $context );

			case 'team_added':
			case 'team_role_changed':
			case 'team_removed':
				return self::describeTeam( $event, $actorRef, self::teammate( $objectId ), $context );

			case 'org_suspended':
				$org = self::org( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: the admin's name, 2: an organization's name */
						? self::sentence( __( '%1$s suspended %2$s', 'monstera' ), [ $actorRef, $org ] )
						/* translators: %1$s: an organization's name */
						: self::sentence( __( '%1$s was suspended', 'monstera' ), [ $org ] ),
					__( 'Organization', 'monstera' ),
					$org['text']
				);

			case 'org_tier_changed':
				return self::describeTier( $actorRef, self::org( $objectId ), trim( (string) ( $context['tier'] ?? '' ) ) );

			case 'content_viewed':
				if ( $own ) {
					/* translators: %1$s: a content item's title */
					return self::result( self::sentence( __( 'You viewed %1$s', 'monstera' ), [ $own ] ), __( 'View', 'monstera' ), '' );
				}
				$item = self::content( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: a member's name, 2: a content item's title */
						? self::sentence( __( '%1$s viewed %2$s', 'monstera' ), [ $actorRef, $item ] )
						/* translators: %1$s: a content item's title */
						: self::sentence( __( '%1$s was viewed', 'monstera' ), [ $item ] ),
					__( 'View', 'monstera' ),
					self::orgOf( $row, $actorId )
				);

			case 'form_opened':
				if ( $own ) {
					/* translators: %1$s: a form resource's title */
					return self::result( self::sentence( __( 'You opened %1$s', 'monstera' ), [ $own ] ), __( 'Resource', 'monstera' ), '' );
				}
				$form = self::post( $objectId, 'monstera-forms', __( 'a removed resource', 'monstera' ) );
				return self::result(
					$actorRef
						/* translators: 1: a member's name, 2: a form resource's title */
						? self::sentence( __( '%1$s opened %2$s', 'monstera' ), [ $actorRef, $form ] )
						/* translators: %1$s: a form resource's title */
						: self::sentence( __( '%1$s was opened', 'monstera' ), [ $form ] ),
					__( 'Resource', 'monstera' ),
					self::orgOf( $row, $actorId )
				);

			case 'project_stage_changed':
				$project = self::post( $objectId, 'monstera-projects', __( 'a removed project', 'monstera' ) );
				$stage   = [ 'text' => ProjectMeta::statusLabel( (string) ( $context['to'] ?? '' ) ) ];
				$orgId   = (int) get_post_meta( $objectId, ProjectMeta::KEY_ORG_ID, true );
				return self::result(
					$actorRef
						/* translators: 1: a person's name, 2: a project's name, 3: the stage, e.g. "In progress" */
						? self::sentence( __( '%1$s moved %2$s to %3$s', 'monstera' ), [ $actorRef, $project, $stage ] )
						/* translators: 1: a project's name, 2: the stage, e.g. "In progress" */
						: self::sentence( __( '%1$s moved to %2$s', 'monstera' ), [ $project, $stage ] ),
					__( 'Project', 'monstera' ),
					$orgId ? self::title( $orgId ) : ''
				);

			case 'intake_file_added':
			case 'intake_file_removed':
			case 'intake_file_downloaded':
				return self::describeIntakeFile( $event, $actorRef, $objectId, $context, $own );

			case 'support_file_opened':
				return self::describeSupportFile( $actorRef, $objectId, $context );

			case 'support_request_opened':
			case 'support_replied':
			case 'support_status_changed':
			case 'support_priority_changed':
				return self::describeSupport( $event, $actorRef, $objectId, $context, $own );

			case 'alert_ended':
				$alert = self::post( $objectId, 'monstera-alerts', __( 'a removed alert', 'monstera' ) );
				return self::result(
					$actorRef
						/* translators: 1: a person's name, 2: an alert's title */
						? self::sentence( __( '%1$s ended the alert %2$s', 'monstera' ), [ $actorRef, $alert ] )
						/* translators: %1$s: an alert's title */
						: self::sentence( __( 'The alert %1$s ended', 'monstera' ), [ $alert ] ),
					__( 'Alert', 'monstera' ),
					''
				);
		}

		return self::result(
			$actorRef
				/* translators: %1$s: a person's name */
				? self::sentence( __( '%1$s made a change', 'monstera' ), [ $actorRef ] )
				: [ [ 'text' => __( 'A change was made', 'monstera' ) ] ],
			__( 'Activity', 'monstera' ),
			''
		);
	}

	/**
	 * A file added to, removed from or downloaded from a project's discovery:
	 * who, the file by name (never a link: download links are signed for one
	 * reader and expire), the question as it was asked, the project as a link.
	 *
	 * To the person who added one (describeOwn()) the sentence is theirs and
	 * shorter: the file, then the project as they reach it in the portal.
	 *
	 * @param array{text: string}|null               $actor
	 * @param array<string, mixed>                   $context
	 * @param array{text: string, url?: string}|null $own     The project as the actor reaches it, for their own sentence.
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeIntakeFile( string $event, ?array $actor, int $projectId, array $context, ?array $own = null ): array {
		$file = [ 'text' => trim( (string) ( $context['name'] ?? '' ) ) ?: __( 'a file', 'monstera' ) ];
		if ( $own && 'intake_file_added' === $event ) {
			/* translators: 1: a file's name, 2: a project's name */
			return self::result( self::sentence( __( 'You added %1$s to %2$s', 'monstera' ), [ $file, $own ] ), __( 'Discovery', 'monstera' ), '' );
		}
		$project  = self::post( $projectId, 'monstera-projects', __( 'a removed project', 'monstera' ) );
		$question = [ 'text' => trim( (string) ( $context['label'] ?? '' ) ) ?: __( 'a discovery question', 'monstera' ) ];
		$someone  = $actor ?? [ 'text' => __( 'Someone', 'monstera' ) ];
		$orgId    = (int) get_post_meta( $projectId, ProjectMeta::KEY_ORG_ID, true );
		$parts    = match ( $event ) {
			/* translators: 1: a person's name, 2: a file's name, 3: a discovery question, 4: a project's name */
			'intake_file_added'   => self::sentence( __( '%1$s added %2$s to %3$s on %4$s', 'monstera' ), [ $someone, $file, $question, $project ] ),
			/* translators: 1: a person's name, 2: a file's name, 3: a discovery question, 4: a project's name */
			'intake_file_removed' => self::sentence( __( '%1$s removed %2$s from %3$s on %4$s', 'monstera' ), [ $someone, $file, $question, $project ] ),
			/* translators: 1: a person's name, 2: a file's name, 3: a project's name */
			default               => self::sentence( __( '%1$s downloaded %2$s from %3$s', 'monstera' ), [ $someone, $file, $project ] ),
		};
		return self::result(
			$parts,
			'intake_file_downloaded' === $event ? __( 'Download', 'monstera' ) : __( 'Discovery', 'monstera' ),
			$orgId ? self::title( $orgId ) : ''
		);
	}

	/**
	 * @param array{text: string}|null        $actor
	 * @param array{text: string, url?: string} $member
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeMove( ?array $actor, array $member, int $orgId ): array {
		if ( $orgId ) {
			$org   = self::org( $orgId );
			$parts = $actor
				/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
				? self::sentence( __( '%1$s moved %2$s to %3$s', 'monstera' ), [ $actor, $member, $org ] )
				/* translators: 1: the member's name, 2: an organization's name */
				: self::sentence( __( '%1$s moved to %2$s', 'monstera' ), [ $member, $org ] );
			return self::result( $parts, __( 'Roster', 'monstera' ), $org['text'] );
		}
		$parts = $actor
			/* translators: 1: the admin's name, 2: the member's name */
			? self::sentence( __( '%1$s made %2$s a standalone member', 'monstera' ), [ $actor, $member ] )
			/* translators: %1$s: the member's name */
			: self::sentence( __( '%1$s became a standalone member', 'monstera' ), [ $member ] );
		return self::result( $parts, __( 'Roster', 'monstera' ), '' );
	}

	/**
	 * A change to who belongs where (Organizations\Roster): who added,
	 * removed, re-tiered, assigned or unassigned whom, with the organization
	 * as a link where the sentence names it. A tier reads as the comps label
	 * it (Organization admin, Manager, Member); without an actor the sentence
	 * starts with the person.
	 *
	 * @param array{text: string}|null          $actor
	 * @param array{text: string, url?: string} $person
	 * @param array<string, mixed>              $context
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeMembership( string $event, ?array $actor, array $person, array $context ): array {
		$org  = self::org( (int) ( $context['org_id'] ?? 0 ) );
		$kind = str_starts_with( $event, 'staff_' ) ? __( 'Team', 'monstera' ) : __( 'Roster', 'monstera' );
		$refs = $actor ? [ $actor, $person, $org ] : [ $person, $org ];
		switch ( $event ) {
			case 'membership_added':
				$template = self::addedTemplate( (string) ( $context['tier'] ?? '' ), null !== $actor );
				break;
			case 'membership_tier_changed':
				$template = self::tierChangedTemplate( (string) ( $context['to'] ?? '' ), null !== $actor );
				break;
			case 'staff_assigned':
				$template = $actor
					/* translators: 1: a team manager's name, 2: a staff person's name, 3: an organization's name */
					? __( '%1$s assigned %2$s to %3$s', 'monstera' )
					/* translators: 1: a staff person's name, 2: an organization's name */
					: __( '%1$s was assigned to %2$s', 'monstera' );
				break;
			case 'staff_unassigned':
				$template = $actor
					/* translators: 1: a team manager's name, 2: a staff person's name, 3: an organization's name */
					? __( '%1$s unassigned %2$s from %3$s', 'monstera' )
					/* translators: 1: a staff person's name, 2: an organization's name */
					: __( '%1$s was unassigned from %2$s', 'monstera' );
				break;
			default:
				if ( ! $actor && ! empty( $context['account_removed'] ) && empty( $org['url'] ) ) {
					// The organization went first, deleted or swept after: the
					// invited account was removed with it, not from it, by nobody.
					$refs = [ $person ];
					/* translators: %1$s: the member's name */
					$template = __( '%1$s was removed when the organization that invited them was deleted', 'monstera' );
					break;
				}
				$template = $actor
					/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
					? __( '%1$s removed %2$s from %3$s', 'monstera' )
					/* translators: 1: the member's name, 2: an organization's name */
					: __( '%1$s was removed from %2$s', 'monstera' );
		}
		return self::result( self::sentence( $template, $refs ), $kind, $org['text'] );
	}

	/**
	 * A change to who is on the internal team (the Team routes): who added
	 * whom and as what, whose role moved to which, who was removed. The role
	 * is part of the sentence, as a tier is in addedTemplate(), and reads as
	 * the Team page labels it; a role the sentence does not know is left
	 * out. The team is nobody's organization, so the meta line names none.
	 *
	 * @param array{text: string}|null          $actor
	 * @param array{text: string, url?: string} $person
	 * @param array<string, mixed>              $context
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeTeam( string $event, ?array $actor, array $person, array $context ): array {
		$role     = (string) ( $context[ 'team_role_changed' === $event ? 'to' : 'role' ] ?? '' );
		$manager  = Capabilities::ROLE_ADMIN === $role;
		$member   = Capabilities::ROLE_TEAM_MEMBER === $role;
		$credited = null !== $actor;
		$template = match ( true ) {
			/* translators: 1: a team manager's name, 2: a person's name */
			'team_removed' === $event && $credited                   => __( '%1$s removed %2$s from the team', 'monstera' ),
			/* translators: %1$s: a person's name */
			'team_removed' === $event                                => __( '%1$s was removed from the team', 'monstera' ),
			/* translators: 1: a team manager's name, 2: a person's name */
			'team_role_changed' === $event && $credited && $manager  => __( '%1$s made %2$s a Team manager', 'monstera' ),
			/* translators: 1: a team manager's name, 2: a person's name */
			'team_role_changed' === $event && $credited && $member   => __( '%1$s made %2$s a Team member', 'monstera' ),
			/* translators: 1: a team manager's name, 2: a person's name */
			'team_role_changed' === $event && $credited              => __( '%1$s changed the team role of %2$s', 'monstera' ),
			/* translators: %1$s: a person's name */
			'team_role_changed' === $event && $manager               => __( '%1$s became a Team manager', 'monstera' ),
			/* translators: %1$s: a person's name */
			'team_role_changed' === $event && $member                => __( '%1$s became a Team member', 'monstera' ),
			/* translators: %1$s: a person's name */
			'team_role_changed' === $event                           => __( 'The team role of %1$s changed', 'monstera' ),
			/* translators: 1: a team manager's name, 2: a person's name */
			$credited && $manager                                    => __( '%1$s added %2$s to the team as a Team manager', 'monstera' ),
			/* translators: 1: a team manager's name, 2: a person's name */
			$credited && $member                                     => __( '%1$s added %2$s to the team as a Team member', 'monstera' ),
			/* translators: 1: a team manager's name, 2: a person's name */
			$credited                                                => __( '%1$s added %2$s to the team', 'monstera' ),
			/* translators: %1$s: a person's name */
			$manager                                                 => __( '%1$s was added to the team as a Team manager', 'monstera' ),
			/* translators: %1$s: a person's name */
			$member                                                  => __( '%1$s was added to the team as a Team member', 'monstera' ),
			/* translators: %1$s: a person's name */
			default                                                  => __( '%1$s was added to the team', 'monstera' ),
		};
		return self::result( self::sentence( $template, $actor ? [ $actor, $person ] : [ $person ] ), __( 'Team', 'monstera' ), '' );
	}

	/**
	 * "added X to Y as a member": the tier is part of the sentence rather
	 * than a placeholder, so each reads with its own article. A tier the
	 * sentence does not know is left out.
	 */
	private static function addedTemplate( string $tier, bool $withActor ): string {
		return match ( true ) {
			/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
			$withActor && Roster::TIER_ADMIN === $tier   => __( '%1$s added %2$s to %3$s as an organization admin', 'monstera' ),
			/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
			$withActor && Roster::TIER_MANAGER === $tier => __( '%1$s added %2$s to %3$s as a manager', 'monstera' ),
			/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
			$withActor && Roster::TIER_MEMBER === $tier  => __( '%1$s added %2$s to %3$s as a member', 'monstera' ),
			/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
			$withActor                                   => __( '%1$s added %2$s to %3$s', 'monstera' ),
			/* translators: 1: the member's name, 2: an organization's name */
			Roster::TIER_ADMIN === $tier                 => __( '%1$s was added to %2$s as an organization admin', 'monstera' ),
			/* translators: 1: the member's name, 2: an organization's name */
			Roster::TIER_MANAGER === $tier               => __( '%1$s was added to %2$s as a manager', 'monstera' ),
			/* translators: 1: the member's name, 2: an organization's name */
			Roster::TIER_MEMBER === $tier                => __( '%1$s was added to %2$s as a member', 'monstera' ),
			/* translators: 1: the member's name, 2: an organization's name */
			default                                      => __( '%1$s was added to %2$s', 'monstera' ),
		};
	}

	/**
	 * "made X a Manager", as the organization detail's recent activity
	 * reads (comp 120); the organization is the row's context, not part of
	 * the sentence.
	 */
	private static function tierChangedTemplate( string $tier, bool $withActor ): string {
		return match ( true ) {
			/* translators: 1: the admin's name, 2: the member's name */
			$withActor && Roster::TIER_ADMIN === $tier   => __( '%1$s made %2$s an Organization admin', 'monstera' ),
			/* translators: 1: the admin's name, 2: the member's name */
			$withActor && Roster::TIER_MANAGER === $tier => __( '%1$s made %2$s a Manager', 'monstera' ),
			/* translators: 1: the admin's name, 2: the member's name */
			$withActor && Roster::TIER_MEMBER === $tier  => __( '%1$s made %2$s a Member', 'monstera' ),
			/* translators: 1: the admin's name, 2: the member's name */
			$withActor                                   => __( '%1$s changed the tier of %2$s', 'monstera' ),
			/* translators: %1$s: the member's name */
			Roster::TIER_ADMIN === $tier                 => __( '%1$s became an Organization admin', 'monstera' ),
			/* translators: %1$s: the member's name */
			Roster::TIER_MANAGER === $tier               => __( '%1$s became a Manager', 'monstera' ),
			/* translators: %1$s: the member's name */
			Roster::TIER_MEMBER === $tier                => __( '%1$s became a Member', 'monstera' ),
			/* translators: %1$s: the member's name */
			default                                      => __( 'The tier of %1$s changed', 'monstera' ),
		};
	}

	/**
	 * @param array{text: string}|null        $actor
	 * @param array{text: string, url?: string} $org
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeTier( ?array $actor, array $org, string $tier ): array {
		$tierRef = [ 'text' => $tier ];
		if ( '' === $tier ) {
			$parts = $actor
				/* translators: 1: the admin's name, 2: an organization's name */
				? self::sentence( __( '%1$s cleared the tier on %2$s', 'monstera' ), [ $actor, $org ] )
				/* translators: %1$s: an organization's name */
				: self::sentence( __( 'The tier on %1$s was cleared', 'monstera' ), [ $org ] );
		} else {
			$parts = $actor
				/* translators: 1: the admin's name, 2: an organization's name, 3: the tier, e.g. "Partner" */
				? self::sentence( __( '%1$s moved %2$s to the %3$s tier', 'monstera' ), [ $actor, $org, $tierRef ] )
				/* translators: 1: an organization's name, 2: the tier, e.g. "Partner" */
				: self::sentence( __( '%1$s moved to the %2$s tier', 'monstera' ), [ $org, $tierRef ] );
		}
		return self::result( $parts, __( 'Organization', 'monstera' ), $org['text'] );
	}

	/** The notification's sentence by template, with %1$s for the recipient. */
	private static function emailTemplate( string $event ): string {
		return match ( $event ) {
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_WELCOME          => __( 'Welcome email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_ADDED_TO_ORG     => __( 'Organization welcome sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_TEAM_WELCOME     => __( 'Team welcome sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_NEW_CONTENT      => __( 'New content email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_UPDATED_CONTENT  => __( 'Update email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_CONTENT_UNLOCKED => __( 'Access email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_EXPIRY_WARNING   => __( 'Renewal reminder sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_EXPIRED          => __( 'Membership-ended email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_ORG_SUSPENDED    => __( 'Suspension notice sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_ALERT_POSTED     => __( 'Alert email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_SUPPORT_RECEIVED => __( 'Support request confirmation sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_SUPPORT_REPLIED  => __( 'Support reply sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_SUPPORT_RESOLVED => __( 'Support resolved notice sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_SUPPORT_CLOSED   => __( 'Support closed notice sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			default                                => __( 'Email sent to %1$s', 'monstera' ),
		};
	}

	/**
	 * Splits a template on its numbered placeholders (%1$s, %2$s, …) and
	 * puts each referenced part in its place.
	 *
	 * @param list<array{text: string, url?: string}> $refs
	 * @return list<array{text: string, url?: string}>
	 */
	private static function sentence( string $template, array $refs ): array {
		$parts  = [];
		$pieces = preg_split( '/(%\d+\$s)/', $template, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		foreach ( (array) $pieces as $piece ) {
			if ( preg_match( '/^%(\d+)\$s$/', $piece, $m ) ) {
				$ref = $refs[ (int) $m[1] - 1 ] ?? null;
				if ( $ref ) {
					$parts[] = $ref;
				}
				continue;
			}
			$parts[] = [ 'text' => $piece ];
		}
		return $parts;
	}

	/**
	 * @param list<array{text: string, url?: string}> $parts
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function result( array $parts, string $kind, string $org ): array {
		return [
			'parts' => $parts,
			'kind'  => $kind,
			'org'   => $org,
		];
	}

	/** @return array{text: string, url?: string} */
	private static function person( int $userId ): array {
		$user = $userId ? get_userdata( $userId ) : false;
		if ( ! $user instanceof WP_User ) {
			return [ 'text' => __( 'a former member', 'monstera' ) ];
		}
		return [
			'text' => UserMeta::fullName( $user ),
			'url'  => admin_url( 'admin.php?page=monstera-members&id=' . $userId ),
		];
	}

	/**
	 * The person a removal is about. A removal that ended an invitation took
	 * the account with it (Organizations\Roster::remove()), and its row says
	 * so and keeps the name the account had: that name is the sentence's, as
	 * plain words, there being no record to open. The account is not looked
	 * up by its id for such a row, which names nobody any more and could
	 * come to name somebody else. Any other removal is about a person who is
	 * still here, or who left some other way.
	 *
	 * @param array<string, mixed> $context
	 * @return array{text: string, url?: string}
	 */
	private static function removed( int $userId, array $context ): array {
		if ( empty( $context['account_removed'] ) ) {
			return self::person( $userId );
		}
		$name = trim( (string) ( $context['name'] ?? '' ) );
		return [ 'text' => '' !== $name ? $name : __( 'a former member', 'monstera' ) ];
	}

	/**
	 * The person a team sentence is about, their name a link to the page
	 * that answers for them as they are now. While they are on the team
	 * that is the staff detail, which answers for a WordPress administrator
	 * too, as the member detail does not. Off the team with a client role,
	 * it is the member detail. Someone removed from the team with nothing of
	 * Monstera's left keeps a WordPress account neither page answers for,
	 * and a link would be dead from the moment the sentence was written, so
	 * their name is plain text. An account that has since been deleted was
	 * on the team, so it is not "a former member".
	 *
	 * @return array{text: string, url?: string}
	 */
	private static function teammate( int $userId ): array {
		$user = $userId ? get_userdata( $userId ) : false;
		if ( ! $user instanceof WP_User ) {
			return [ 'text' => __( 'a deleted account', 'monstera' ) ];
		}
		if ( Capabilities::isStaff( $user ) ) {
			return [
				'text' => UserMeta::fullName( $user ),
				'url'  => admin_url( 'admin.php?page=monstera-team&id=' . $userId ),
			];
		}
		return array_filter( (array) $user->roles, [ Capabilities::class, 'isPortalRole' ] )
			? self::person( $userId )
			: [ 'text' => UserMeta::fullName( $user ) ];
	}

	/** @return array{text: string, url?: string} */
	private static function content( int $postId ): array {
		$title = $postId ? self::title( $postId ) : '';
		if ( '' === $title ) {
			return [ 'text' => __( 'a removed item', 'monstera' ) ];
		}
		return [
			'text' => $title,
			'url'  => admin_url( 'admin.php?page=monstera-content&id=' . $postId ),
		];
	}

	/**
	 * A file opened from a support request's thread: who, the file by name
	 * (never a link: download links are signed for one reader and expire),
	 * and the request by its reference as a link to its detail.
	 *
	 * @param array{text: string}|null $actor
	 * @param array<string, mixed>     $context
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeSupportFile( ?array $actor, int $requestId, array $context ): array {
		$file    = [ 'text' => trim( (string) ( $context['name'] ?? '' ) ) ?: __( 'a file', 'monstera' ) ];
		$someone = $actor ?? [ 'text' => __( 'Someone', 'monstera' ) ];
		$orgId   = (int) ( $context['org_id'] ?? 0 );
		return self::result(
			/* translators: 1: a person's name, 2: a file's name, 3: a support request, e.g. "request 7C3E19A2" */
			self::sentence( __( '%1$s opened %2$s on %3$s', 'monstera' ), [ $someone, $file, self::supportRequest( $requestId, (string) ( $context['ref'] ?? '' ) ) ] ),
			__( 'Support', 'monstera' ),
			$orgId ? self::title( $orgId ) : ''
		);
	}

	/**
	 * A turn of a support conversation: who opened the request, replied on
	 * it, chose its status or changed its priority, with the request by its
	 * reference as a link to its detail.
	 *
	 * To the member who opened or answered it (describeOwn()) the sentence
	 * is theirs, and names the request by its subject, which is how they
	 * know it, as a link to its page in the portal.
	 *
	 * @param array{text: string}|null               $actor
	 * @param array<string, mixed>                   $context
	 * @param array{text: string, url?: string}|null $own     The request as its member reaches it, for their own sentence.
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeSupport( string $event, ?array $actor, int $requestId, array $context, ?array $own = null ): array {
		if ( $own && 'support_request_opened' === $event ) {
			/* translators: %1$s: a support request's subject */
			return self::result( self::sentence( __( 'You opened a request: %1$s', 'monstera' ), [ $own ] ), __( 'Support', 'monstera' ), '' );
		}
		if ( $own && 'support_replied' === $event ) {
			/* translators: %1$s: a support request's subject */
			return self::result( self::sentence( __( 'You replied on a request: %1$s', 'monstera' ), [ $own ] ), __( 'Support', 'monstera' ), '' );
		}
		$someone = $actor ?? [ 'text' => __( 'Someone', 'monstera' ) ];
		$request = self::supportRequest( $requestId, (string) ( $context['ref'] ?? '' ) );
		$to      = (string) ( $context['to'] ?? '' );
		$orgId   = (int) ( $context['org_id'] ?? 0 );

		if ( 'support_priority_changed' === $event ) {
			$rank   = array_flip( SupportRepository::PRIORITIES );
			$from   = (string) ( $context['from'] ?? '' );
			$known  = isset( $rank[ $to ], $rank[ $from ] );
			$raised = $known && $rank[ $to ] > $rank[ $from ];
			$parts  = match ( true ) {
				/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
				! $known => self::sentence( __( '%1$s changed the priority of %2$s', 'monstera' ), [ $someone, $request ] ),
				/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2", 3: a priority, e.g. "Urgent" */
				$raised  => self::sentence( __( '%1$s raised the priority of %2$s to %3$s', 'monstera' ), [ $someone, $request, [ 'text' => SupportRepository::priorityLabel( $to ) ] ] ),
				/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2", 3: a priority, e.g. "Low" */
				default  => self::sentence( __( '%1$s lowered the priority of %2$s to %3$s', 'monstera' ), [ $someone, $request, [ 'text' => SupportRepository::priorityLabel( $to ) ] ] ),
			};
			return self::result( $parts, __( 'Support', 'monstera' ), $orgId ? self::title( $orgId ) : '' );
		}

		$template = match ( true ) {
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			'support_request_opened' === $event      => __( '%1$s opened %2$s', 'monstera' ),
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			'support_replied' === $event             => __( '%1$s replied on %2$s', 'monstera' ),
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			SupportRepository::STATUS_PENDING === $to  => __( '%1$s marked %2$s as awaiting its member', 'monstera' ),
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			SupportRepository::STATUS_RESOLVED === $to => __( '%1$s marked %2$s resolved', 'monstera' ),
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			SupportRepository::STATUS_CLOSED === $to   => __( '%1$s closed %2$s', 'monstera' ),
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			SupportRepository::STATUS_OPEN === $to     => __( '%1$s reopened %2$s', 'monstera' ),
			/* translators: 1: a person's name, 2: a support request, e.g. "request 7C3E19A2" */
			default                                    => __( '%1$s updated %2$s', 'monstera' ),
		};
		return self::result( self::sentence( $template, [ $someone, $request ] ), __( 'Support', 'monstera' ), $orgId ? self::title( $orgId ) : '' );
	}

	/**
	 * A support request by its reference as a link to its admin detail, or
	 * plain words when the row names none or it no longer exists.
	 *
	 * @return array{text: string, url?: string}
	 */
	private static function supportRequest( int $requestId, string $ref ): array {
		$ref = trim( $ref );
		if ( '' === $ref || ! ( new SupportRepository() )->find( $requestId ) ) {
			return [ 'text' => __( 'a support request', 'monstera' ) ];
		}
		return [
			/* translators: %s: a support request's reference, e.g. 7C3E19A2 */
			'text' => sprintf( __( 'request %s', 'monstera' ), $ref ),
			'url'  => admin_url( 'admin.php?page=monstera-support&id=' . $requestId ),
		];
	}

	/**
	 * A post as a link to its admin detail page, or the fallback text when
	 * it no longer exists.
	 *
	 * @return array{text: string, url?: string}
	 */
	private static function post( int $postId, string $page, string $fallback ): array {
		$title = $postId ? self::title( $postId ) : '';
		if ( '' === $title ) {
			return [ 'text' => $fallback ];
		}
		return [
			'text' => $title,
			'url'  => admin_url( 'admin.php?page=' . $page . '&id=' . $postId ),
		];
	}

	/** @return array{text: string, url?: string} */
	private static function org( int $orgId ): array {
		$title = $orgId ? self::title( $orgId ) : '';
		if ( '' === $title ) {
			return [ 'text' => __( 'a removed organization', 'monstera' ) ];
		}
		return [
			'text' => $title,
			'url'  => admin_url( 'admin.php?page=monstera-organizations&id=' . $orgId ),
		];
	}

	/**
	 * The organization on the meta line of a row about a person: the one
	 * the row is filed under, which is the event's own when the recorder
	 * knew it (a welcome resent from B names B, whatever the person's first
	 * organization is), and otherwise what orgOfUser() says of the person.
	 *
	 * @param array<string, mixed> $row An activity log row (ARRAY_A).
	 */
	private static function orgOf( array $row, int $userId ): string {
		$orgId = (int) ( $row['org_id'] ?? 0 );
		return $orgId > 0 ? self::title( $orgId ) : self::orgOfUser( $userId );
	}

	/**
	 * For a row filed under no organization: the primary organization (their
	 * first) of the person it is about, or, for someone without one, what
	 * kind of person they are ("Team", "Standalone member"), so every row
	 * about a person has a context on its meta line. Either team role reads
	 * "Team", the word a content item's readers list uses for staff: an
	 * admin is a tier in an organization (People-model track, Vocabulary).
	 */
	private static function orgOfUser( int $userId ): string {
		$user = $userId ? get_userdata( $userId ) : false;
		if ( ! $user instanceof WP_User ) {
			return '';
		}
		$orgId = Roster::primaryOrgOf( $userId );
		if ( $orgId ) {
			return self::title( $orgId );
		}
		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return __( 'Team', 'monstera' );
		}
		return Audience::isStandalone( $userId ) ? __( 'Standalone member', 'monstera' ) : '';
	}

	/** A post's title as plain text: the raw field, entities decoded. */
	private static function title( int $postId ): string {
		$raw = get_post_field( 'post_title', $postId );
		return is_string( $raw ) ? html_entity_decode( $raw, ENT_QUOTES, 'UTF-8' ) : '';
	}
}
