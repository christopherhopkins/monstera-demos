<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Notifications\TemplateEngine;
use Monstera\Portal\Audience;
use Monstera\Projects\Meta as ProjectMeta;
use WP_User;

/**
 * Turns an activity log row into the sentence the admin dashboard shows
 * (comp 90): who did what to which named thing, with the named things as
 * links into the admin shell, plus the organization and a one-word kind for
 * the meta line.
 *
 * A sentence is returned as parts, each `{ text, url? }`, so the page can
 * render links without trusting HTML. Templates are translatable strings
 * with numbered placeholders, which a translation may reorder; every
 * placeholder becomes one part.
 */
final class ActivitySentences {

	/**
	 * Every event the plugin records. A test reads the source for
	 * ActivityLog::record() calls and fails on an event missing here.
	 */
	public const KNOWN_EVENTS = [
		'login',
		'download',
		'content_downloaded',
		'publish',
		'notification',
		'welcome_resent',
		'member_org_changed',
		'org_suspended',
		'org_tier_changed',
		'content_viewed',
		'form_opened',
		'project_stage_changed',
		'alert_ended',
		'intake_file_added',
		'intake_file_removed',
		'intake_file_downloaded',
	];

	/**
	 * @param array<string, mixed> $row An activity log row (ARRAY_A).
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	public static function describe( array $row ): array {
		$event    = (string) ( $row['event_type'] ?? '' );
		$actorId  = (int) ( $row['user_id'] ?? 0 );
		$objectId = (int) ( $row['object_id'] ?? 0 );
		$context  = json_decode( (string) ( $row['context'] ?? '' ), true );
		$context  = is_array( $context ) ? $context : [];
		$actor    = $actorId ? get_userdata( $actorId ) : false;
		$actorRef = $actor instanceof WP_User ? [ 'text' => UserMeta::fullName( $actor ) ] : null;

		switch ( $event ) {
			case 'login':
				$member = self::person( $objectId ?: $actorId );
				return self::result(
					/* translators: %1$s: a member's name */
					self::sentence( __( '%1$s signed in', 'monstera' ), [ $member ] ),
					__( 'Sign-in', 'monstera' ),
					self::orgOfUser( $objectId ?: $actorId )
				);

			case 'download':
			case 'content_downloaded':
				$item = self::content( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: a member's name, 2: a content item's title */
						? self::sentence( __( '%1$s downloaded %2$s', 'monstera' ), [ $actorRef, $item ] )
						/* translators: %1$s: a content item's title */
						: self::sentence( __( '%1$s was downloaded', 'monstera' ), [ $item ] ),
					__( 'Download', 'monstera' ),
					self::orgOfUser( $actorId )
				);

			case 'publish':
				$item = self::content( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: a person's name, 2: a content item's title */
						? self::sentence( __( '%1$s published %2$s', 'monstera' ), [ $actorRef, $item ] )
						/* translators: %1$s: a content item's title */
						: self::sentence( __( '%1$s was published', 'monstera' ), [ $item ] ),
					__( 'Content', 'monstera' ),
					''
				);

			case 'notification':
				return self::result(
					self::sentence( self::emailTemplate( (string) ( $context['event'] ?? '' ) ), [ self::person( $objectId ) ] ),
					__( 'Email', 'monstera' ),
					self::orgOfUser( $objectId )
				);

			case 'welcome_resent':
				$member = self::person( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: the admin's name, 2: the member's name */
						? self::sentence( __( '%1$s resent the welcome email to %2$s', 'monstera' ), [ $actorRef, $member ] )
						/* translators: %1$s: a member's name */
						: self::sentence( __( 'Welcome email resent to %1$s', 'monstera' ), [ $member ] ),
					__( 'Email', 'monstera' ),
					self::orgOfUser( $objectId )
				);

			case 'member_org_changed':
				return self::describeMove( $actorRef, self::person( $objectId ), (int) ( $context['org_id'] ?? 0 ) );

			case 'org_suspended':
				$org = self::org( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: the admin's name, 2: an organization's name */
						? self::sentence( __( '%1$s suspended %2$s', 'monstera' ), [ $actorRef, $org ] )
						/* translators: %1$s: an organization's name */
						: self::sentence( __( '%1$s was suspended', 'monstera' ), [ $org ] ),
					__( 'Organization', 'monstera' ),
					$org['text']
				);

			case 'org_tier_changed':
				return self::describeTier( $actorRef, self::org( $objectId ), trim( (string) ( $context['tier'] ?? '' ) ) );

			case 'content_viewed':
				$item = self::content( $objectId );
				return self::result(
					$actorRef
						/* translators: 1: a member's name, 2: a content item's title */
						? self::sentence( __( '%1$s viewed %2$s', 'monstera' ), [ $actorRef, $item ] )
						/* translators: %1$s: a content item's title */
						: self::sentence( __( '%1$s was viewed', 'monstera' ), [ $item ] ),
					__( 'View', 'monstera' ),
					self::orgOfUser( $actorId )
				);

			case 'form_opened':
				$form = self::post( $objectId, 'monstera-forms', __( 'a removed resource', 'monstera' ) );
				return self::result(
					$actorRef
						/* translators: 1: a member's name, 2: a form resource's title */
						? self::sentence( __( '%1$s opened %2$s', 'monstera' ), [ $actorRef, $form ] )
						/* translators: %1$s: a form resource's title */
						: self::sentence( __( '%1$s was opened', 'monstera' ), [ $form ] ),
					__( 'Resource', 'monstera' ),
					self::orgOfUser( $actorId )
				);

			case 'project_stage_changed':
				$project = self::post( $objectId, 'monstera-projects', __( 'a removed project', 'monstera' ) );
				$stage   = [ 'text' => ProjectMeta::statusLabel( (string) ( $context['to'] ?? '' ) ) ];
				$orgId   = (int) get_post_meta( $objectId, ProjectMeta::KEY_ORG_ID, true );
				return self::result(
					$actorRef
						/* translators: 1: a person's name, 2: a project's name, 3: the stage, e.g. "In progress" */
						? self::sentence( __( '%1$s moved %2$s to %3$s', 'monstera' ), [ $actorRef, $project, $stage ] )
						/* translators: 1: a project's name, 2: the stage, e.g. "In progress" */
						: self::sentence( __( '%1$s moved to %2$s', 'monstera' ), [ $project, $stage ] ),
					__( 'Project', 'monstera' ),
					$orgId ? self::title( $orgId ) : ''
				);

			case 'intake_file_added':
			case 'intake_file_removed':
			case 'intake_file_downloaded':
				return self::describeIntakeFile( $event, $actorRef, $objectId, $context );

			case 'alert_ended':
				$alert = self::post( $objectId, 'monstera-alerts', __( 'a removed alert', 'monstera' ) );
				return self::result(
					$actorRef
						/* translators: 1: a person's name, 2: an alert's title */
						? self::sentence( __( '%1$s ended the alert %2$s', 'monstera' ), [ $actorRef, $alert ] )
						/* translators: %1$s: an alert's title */
						: self::sentence( __( 'The alert %1$s ended', 'monstera' ), [ $alert ] ),
					__( 'Alert', 'monstera' ),
					''
				);
		}

		return self::result(
			$actorRef
				/* translators: %1$s: a person's name */
				? self::sentence( __( '%1$s made a change', 'monstera' ), [ $actorRef ] )
				: [ [ 'text' => __( 'A change was made', 'monstera' ) ] ],
			__( 'Activity', 'monstera' ),
			''
		);
	}

	/**
	 * A file added to, removed from or downloaded from a project's discovery:
	 * who, the file by name (never a link: download links are signed for one
	 * reader and expire), the question as it was asked, the project as a link.
	 *
	 * @param array{text: string}|null $actor
	 * @param array<string, mixed>     $context
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeIntakeFile( string $event, ?array $actor, int $projectId, array $context ): array {
		$project  = self::post( $projectId, 'monstera-projects', __( 'a removed project', 'monstera' ) );
		$file     = [ 'text' => trim( (string) ( $context['name'] ?? '' ) ) ?: __( 'a file', 'monstera' ) ];
		$question = [ 'text' => trim( (string) ( $context['label'] ?? '' ) ) ?: __( 'a discovery question', 'monstera' ) ];
		$someone  = $actor ?? [ 'text' => __( 'Someone', 'monstera' ) ];
		$orgId    = (int) get_post_meta( $projectId, ProjectMeta::KEY_ORG_ID, true );
		$parts    = match ( $event ) {
			/* translators: 1: a person's name, 2: a file's name, 3: a discovery question, 4: a project's name */
			'intake_file_added'   => self::sentence( __( '%1$s added %2$s to %3$s on %4$s', 'monstera' ), [ $someone, $file, $question, $project ] ),
			/* translators: 1: a person's name, 2: a file's name, 3: a discovery question, 4: a project's name */
			'intake_file_removed' => self::sentence( __( '%1$s removed %2$s from %3$s on %4$s', 'monstera' ), [ $someone, $file, $question, $project ] ),
			/* translators: 1: a person's name, 2: a file's name, 3: a project's name */
			default               => self::sentence( __( '%1$s downloaded %2$s from %3$s', 'monstera' ), [ $someone, $file, $project ] ),
		};
		return self::result(
			$parts,
			'intake_file_downloaded' === $event ? __( 'Download', 'monstera' ) : __( 'Discovery', 'monstera' ),
			$orgId ? self::title( $orgId ) : ''
		);
	}

	/**
	 * @param array{text: string}|null        $actor
	 * @param array{text: string, url?: string} $member
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeMove( ?array $actor, array $member, int $orgId ): array {
		if ( $orgId ) {
			$org   = self::org( $orgId );
			$parts = $actor
				/* translators: 1: the admin's name, 2: the member's name, 3: an organization's name */
				? self::sentence( __( '%1$s moved %2$s to %3$s', 'monstera' ), [ $actor, $member, $org ] )
				/* translators: 1: the member's name, 2: an organization's name */
				: self::sentence( __( '%1$s moved to %2$s', 'monstera' ), [ $member, $org ] );
			return self::result( $parts, __( 'Roster', 'monstera' ), $org['text'] );
		}
		$parts = $actor
			/* translators: 1: the admin's name, 2: the member's name */
			? self::sentence( __( '%1$s made %2$s a standalone member', 'monstera' ), [ $actor, $member ] )
			/* translators: %1$s: the member's name */
			: self::sentence( __( '%1$s became a standalone member', 'monstera' ), [ $member ] );
		return self::result( $parts, __( 'Roster', 'monstera' ), '' );
	}

	/**
	 * @param array{text: string}|null        $actor
	 * @param array{text: string, url?: string} $org
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function describeTier( ?array $actor, array $org, string $tier ): array {
		$tierRef = [ 'text' => $tier ];
		if ( '' === $tier ) {
			$parts = $actor
				/* translators: 1: the admin's name, 2: an organization's name */
				? self::sentence( __( '%1$s cleared the tier on %2$s', 'monstera' ), [ $actor, $org ] )
				/* translators: %1$s: an organization's name */
				: self::sentence( __( 'The tier on %1$s was cleared', 'monstera' ), [ $org ] );
		} else {
			$parts = $actor
				/* translators: 1: the admin's name, 2: an organization's name, 3: the tier, e.g. "Partner" */
				? self::sentence( __( '%1$s moved %2$s to the %3$s tier', 'monstera' ), [ $actor, $org, $tierRef ] )
				/* translators: 1: an organization's name, 2: the tier, e.g. "Partner" */
				: self::sentence( __( '%1$s moved to the %2$s tier', 'monstera' ), [ $org, $tierRef ] );
		}
		return self::result( $parts, __( 'Organization', 'monstera' ), $org['text'] );
	}

	/** The notification's sentence by template, with %1$s for the recipient. */
	private static function emailTemplate( string $event ): string {
		return match ( $event ) {
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_WELCOME          => __( 'Welcome email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_NEW_CONTENT      => __( 'New content email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_UPDATED_CONTENT  => __( 'Update email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_CONTENT_UNLOCKED => __( 'Access email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_EXPIRY_WARNING   => __( 'Renewal reminder sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_EXPIRED          => __( 'Membership-ended email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_ORG_SUSPENDED    => __( 'Suspension notice sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			TemplateEngine::EVENT_ALERT_POSTED     => __( 'Alert email sent to %1$s', 'monstera' ),
			/* translators: %1$s: the recipient's name */
			default                                => __( 'Email sent to %1$s', 'monstera' ),
		};
	}

	/**
	 * Splits a template on its numbered placeholders (%1$s, %2$s, …) and
	 * puts each referenced part in its place.
	 *
	 * @param list<array{text: string, url?: string}> $refs
	 * @return list<array{text: string, url?: string}>
	 */
	private static function sentence( string $template, array $refs ): array {
		$parts  = [];
		$pieces = preg_split( '/(%\d+\$s)/', $template, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		foreach ( (array) $pieces as $piece ) {
			if ( preg_match( '/^%(\d+)\$s$/', $piece, $m ) ) {
				$ref = $refs[ (int) $m[1] - 1 ] ?? null;
				if ( $ref ) {
					$parts[] = $ref;
				}
				continue;
			}
			$parts[] = [ 'text' => $piece ];
		}
		return $parts;
	}

	/**
	 * @param list<array{text: string, url?: string}> $parts
	 * @return array{parts: list<array{text: string, url?: string}>, kind: string, org: string}
	 */
	private static function result( array $parts, string $kind, string $org ): array {
		return [
			'parts' => $parts,
			'kind'  => $kind,
			'org'   => $org,
		];
	}

	/** @return array{text: string, url?: string} */
	private static function person( int $userId ): array {
		$user = $userId ? get_userdata( $userId ) : false;
		if ( ! $user instanceof WP_User ) {
			return [ 'text' => __( 'a former member', 'monstera' ) ];
		}
		return [
			'text' => UserMeta::fullName( $user ),
			'url'  => admin_url( 'admin.php?page=monstera-members&id=' . $userId ),
		];
	}

	/** @return array{text: string, url?: string} */
	private static function content( int $postId ): array {
		$title = $postId ? self::title( $postId ) : '';
		if ( '' === $title ) {
			return [ 'text' => __( 'a removed item', 'monstera' ) ];
		}
		return [
			'text' => $title,
			'url'  => admin_url( 'admin.php?page=monstera-content&id=' . $postId ),
		];
	}

	/**
	 * A post as a link to its admin detail page, or the fallback text when
	 * it no longer exists.
	 *
	 * @return array{text: string, url?: string}
	 */
	private static function post( int $postId, string $page, string $fallback ): array {
		$title = $postId ? self::title( $postId ) : '';
		if ( '' === $title ) {
			return [ 'text' => $fallback ];
		}
		return [
			'text' => $title,
			'url'  => admin_url( 'admin.php?page=' . $page . '&id=' . $postId ),
		];
	}

	/** @return array{text: string, url?: string} */
	private static function org( int $orgId ): array {
		$title = $orgId ? self::title( $orgId ) : '';
		if ( '' === $title ) {
			return [ 'text' => __( 'a removed organization', 'monstera' ) ];
		}
		return [
			'text' => $title,
			'url'  => admin_url( 'admin.php?page=monstera-organizations&id=' . $orgId ),
		];
	}

	/**
	 * The person's organization, or, for someone without one, what kind of
	 * person they are ("Admin", "Standalone member"), so every row about a
	 * person has a context on its meta line.
	 */
	private static function orgOfUser( int $userId ): string {
		$user = $userId ? get_userdata( $userId ) : false;
		if ( ! $user instanceof WP_User ) {
			return '';
		}
		$orgId = UserMeta::associatedOrg( $userId );
		if ( $orgId ) {
			return self::title( $orgId );
		}
		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return __( 'Admin', 'monstera' );
		}
		return Audience::isStandalone( $userId ) ? __( 'Standalone member', 'monstera' ) : '';
	}

	/** A post's title as plain text: the raw field, entities decoded. */
	private static function title( int $postId ): string {
		$raw = get_post_field( 'post_title', $postId );
		return is_string( $raw ) ? html_entity_decode( $raw, ENT_QUOTES, 'UTF-8' ) : '';
	}
}
