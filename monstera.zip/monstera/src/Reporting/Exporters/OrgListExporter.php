<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Rest\BulkRequest;
use Monstera\Organizations\Repository as OrgRepository;

defined( 'ABSPATH' ) || exit;

/**
 * CSV export of the organizations directory — one row per org, with the
 * fields a finance/operations team typically wants at hand: slug, tier,
 * status, expires, member count, seat limit, location.
 */
final class OrgListExporter {

	/**
	 * @param array{status?: string, ids?: string|list<int>} $args `ids` limits the export to a selection (comma-separated or a list), at most BulkRequest::MAX_IDS.
	 * @return array<int, array<string, mixed>>
	 */
	public function rows( array $args = [] ): array {
		$repo  = new OrgRepository();
		$posts = $repo->all( [ 'posts_per_page' => -1 ] );

		$statusFilter = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : '';
		$idFilter     = self::idFilter( $args['ids'] ?? [] );

		$out = [];
		foreach ( $posts as $post ) {
			$id     = (int) $post->ID;
			$status = $repo->status( $id );
			if ( $statusFilter && $statusFilter !== $status ) {
				continue;
			}
			if ( $idFilter && ! in_array( $id, $idFilter, true ) ) {
				continue;
			}
			$tierTerms = wp_get_post_terms( $id, 'monstera_org_tier', [ 'fields' => 'names' ] );
			$tier      = is_array( $tierTerms ) ? ( $tierTerms[0] ?? '' ) : '';

			$out[] = [
				'id'         => $id,
				'name'       => get_the_title( $post ),
				'slug'       => $post->post_name,
				'status'     => $status,
				'tier'       => $tier,
				'expires'    => (string) get_post_meta( $id, OrgMeta::KEY_EXPIRES, true ),
				'location'   => (string) get_post_meta( $id, OrgMeta::KEY_LOCATION, true ),
				'seat_limit' => (int) get_post_meta( $id, OrgMeta::KEY_SEAT_LIMIT, true ),
				'members'    => $repo->memberCount( $id ),
				'created'    => (string) get_post_time( 'Y-m-d', true, $post ),
			];
		}
		return $out;
	}

	/**
	 * Distinct positive ids from a list or a comma-separated string, capped the
	 * same way the bulk routes cap a selection.
	 *
	 * @param string|array<int|string> $raw
	 * @return list<int>
	 */
	private static function idFilter( string|array $raw ): array {
		$values = is_string( $raw ) ? explode( ',', $raw ) : $raw;
		$ids    = [];
		foreach ( $values as $value ) {
			$value = is_string( $value ) ? trim( $value ) : $value;
			if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
				$id = (int) $value;
				if ( $id > 0 ) {
					$ids[ $id ] = $id;
				}
			}
		}
		return array_slice( array_values( $ids ), 0, BulkRequest::MAX_IDS );
	}

	/**
	 * @param array<string, mixed> $args
	 */
	public function streamCsv( array $args = [] ): void {
		$rows = $this->rows( $args );
		if ( ! $rows ) {
			$rows = [
				[
					'id'         => '',
					'name'       => '',
					'slug'       => '',
					'status'     => '',
					'tier'       => '',
					'expires'    => '',
					'location'   => '',
					'seat_limit' => '',
					'members'    => '',
					'created'    => '',
				],
			];
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="monstera-orgs-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$fh = fopen( 'php://output', 'w' );
		Csv::writeRow( $fh, array_keys( $rows[0] ) );
		foreach ( $rows as $row ) {
			Csv::writeRow( $fh, $row );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream; WP_Filesystem cannot write a response body.
		exit;
	}
}
