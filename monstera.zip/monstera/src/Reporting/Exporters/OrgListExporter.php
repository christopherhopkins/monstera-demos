<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

use Monstera\Core\Modules;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Rest\BulkRequest;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Projects\Repository as ProjectRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * CSV export of the organizations directory — one row per org, with the
 * fields a finance/operations team typically wants at hand: slug, tier,
 * status, expires, member count, seat limit, location.
 */
final class OrgListExporter {

	/** A row's columns in order, and the empty file's header. */
	public const COLUMNS = [ 'id', 'name', 'slug', 'status', 'tier', 'expires', 'location', 'seat_limit', 'members', 'created', 'projects', 'account_lead' ];

	/**
	 * @param array{status?: string, ids?: string|list<int>} $args `ids` limits the export to a selection (comma-separated or a list), at most BulkRequest::MAX_IDS.
	 * @return array<int, array<string, mixed>>
	 */
	public function rows( array $args = [] ): array {
		$repo  = new OrgRepository();
		$posts = $repo->all( [ 'posts_per_page' => -1 ] );

		$statusFilter = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : '';
		$idFilter     = self::idFilter( $args['ids'] ?? [] );

		$kept = [];
		foreach ( $posts as $post ) {
			$id     = (int) $post->ID;
			$status = $repo->status( $id );
			if ( $statusFilter && $statusFilter !== $status ) {
				continue;
			}
			if ( $idFilter && ! in_array( $id, $idFilter, true ) ) {
				continue;
			}
			$kept[ $id ] = [ $post, $status ];
		}
		// Every row counts its members: one read of the memberships, and only
		// for the organizations the file will hold. Its projects under way
		// come from one grouped read and its account lead's name from one
		// read of the leads' accounts (At-a-glance track, FR2).
		Roster::primeOrgs( array_keys( $kept ) );
		$projectsOn = Modules::isActive( Modules::PROJECTS );
		$underWay   = $projectsOn ? ( new ProjectRepository() )->inFlightCountsFor( array_keys( $kept ) ) : [];
		$leadOf     = [];
		foreach ( array_keys( $kept ) as $id ) {
			$leadId = $repo->accountLeadId( $id );
			if ( $leadId > 0 ) {
				$leadOf[ $id ] = $leadId;
			}
		}
		$leadName = [];
		if ( $leadOf ) {
			cache_users( array_values( array_unique( $leadOf ) ) );
			// One name per lead, however many organizations they lead; ''
			// for an account that is gone.
			foreach ( array_unique( $leadOf ) as $leadId ) {
				$lead                = get_userdata( $leadId );
				$leadName[ $leadId ] = $lead instanceof WP_User ? UserMeta::fullName( $lead ) : '';
			}
		}

		$out = [];
		foreach ( $kept as $id => [ $post, $status ] ) {
			// From the term cache the list query primed, never a read per row.
			$terms = get_the_terms( $id, 'monstera_org_tier' );
			$tier  = is_array( $terms ) && $terms ? (string) reset( $terms )->name : '';

			$out[] = [
				'id'           => $id,
				'name'         => get_the_title( $post ),
				'slug'         => $post->post_name,
				'status'       => $status,
				'tier'         => $tier,
				'expires'      => (string) get_post_meta( $id, OrgMeta::KEY_EXPIRES, true ),
				'location'     => (string) get_post_meta( $id, OrgMeta::KEY_LOCATION, true ),
				'seat_limit'   => (int) get_post_meta( $id, OrgMeta::KEY_SEAT_LIMIT, true ),
				'members'      => $repo->memberCount( $id ),
				'created'      => (string) get_post_time( 'Y-m-d', false, $post ),
				// The two at-a-glance columns last, so a sheet built on the
				// older columns keeps its places; '' for the count with
				// Projects off, as a fact the module does not feed.
				'projects'     => $projectsOn ? (string) ( $underWay[ $id ] ?? 0 ) : '',
				'account_lead' => $leadName[ $leadOf[ $id ] ?? 0 ] ?? '',
			];
		}
		return $out;
	}

	/**
	 * Distinct positive ids from a list or a comma-separated string, capped the
	 * same way the bulk routes cap a selection.
	 *
	 * @param string|array<int|string> $raw
	 * @return list<int>
	 */
	private static function idFilter( string|array $raw ): array {
		$values = is_string( $raw ) ? explode( ',', $raw ) : $raw;
		$ids    = [];
		foreach ( $values as $value ) {
			$value = is_string( $value ) ? trim( $value ) : $value;
			if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
				$id = (int) $value;
				if ( $id > 0 ) {
					$ids[ $id ] = $id;
				}
			}
		}
		return array_slice( array_values( $ids ), 0, BulkRequest::MAX_IDS );
	}

	/**
	 * @param array<string, mixed> $args
	 */
	public function streamCsv( array $args = [] ): void {
		$rows = $this->rows( $args );
		if ( ! $rows ) {
			$rows = [ array_fill_keys( self::COLUMNS, '' ) ];
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . Csv::fileName( 'orgs' ) . '"' );

		$fh = fopen( 'php://output', 'w' );
		Csv::writeRow( $fh, array_keys( $rows[0] ) );
		foreach ( $rows as $row ) {
			Csv::writeRow( $fh, $row );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream; WP_Filesystem cannot write a response body.
		exit;
	}
}
