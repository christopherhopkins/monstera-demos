<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Roster;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * CSV export of the people in the portal: one row per membership, so a
 * person in two organizations is two rows with the same id, name and email
 * and a different organization and tier on each, and a standalone member is
 * one row with an empty organization (People-model track, FR9).
 */
final class MembersExporter {

	/**
	 * The roles the export covers: the client roles of the Members list.
	 * Staff are not members, whatever they are assigned to.
	 *
	 * @var list<string>
	 */
	private const ROLES = [ Capabilities::ROLE_MEMBER, Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER_STANDALONE ];

	/**
	 * The columns in the order the file writes them: the header, every
	 * row's keys and the one blank row of an empty export all come from
	 * this list, and the WP-CLI export writes the same header, so no two
	 * places can disagree about the shape of the file.
	 *
	 * @var list<string>
	 */
	public const COLUMNS = [ 'id', 'name', 'email', 'org_id', 'org_name', 'tier', 'role', 'expires', 'last_login' ];

	/**
	 * A person's rows together, in membership order; people in the Members
	 * list's order. The 'org' argument limits the export to that
	 * organization's members, each with their row for it alone.
	 *
	 * @param array<string, mixed> $args
	 * @return array<int, array<string, mixed>>
	 */
	public function rows( array $args = [] ): array {
		$orgId = (int) ( $args['org'] ?? 0 );
		$query = [
			'role__in' => self::ROLES,
			'number'   => -1,
			'fields'   => 'all',
		];
		if ( $orgId > 0 ) {
			$ids = Roster::memberIds( $orgId );
			if ( ! $ids ) {
				return [];
			}
			$query['include'] = $ids;
		}
		$users = get_users( $query );
		// One query for every membership among them, instead of one per person.
		Roster::prime( wp_list_pluck( $users, 'ID' ) );

		$out = [];
		foreach ( $users as $user ) {
			$memberships = Roster::membershipsOf( (int) $user->ID );
			if ( $orgId > 0 ) {
				$memberships = array_values( array_filter( $memberships, static fn ( array $membership ): bool => $membership['org_id'] === $orgId ) );
			}
			if ( ! $memberships ) {
				$out[] = $this->row( $user, null );
				continue;
			}
			foreach ( $memberships as $membership ) {
				$out[] = $this->row( $user, $membership );
			}
		}
		return $out;
	}

	/**
	 * How many rows rows() writes, without building them: the Tools page's
	 * export card says "N rows" and must agree with the file. One query for
	 * the people and one for every membership among them, then each person
	 * counts once per membership, or once with none.
	 */
	public function rowCount(): int {
		$ids = array_map(
			'intval',
			get_users(
				[
					'role__in' => self::ROLES,
					'number'   => -1,
					'fields'   => 'ID',
				]
			)
		);
		Roster::prime( $ids );
		$count = 0;
		foreach ( $ids as $id ) {
			$count += max( 1, count( Roster::membershipsOf( $id ) ) );
		}
		return $count;
	}

	/**
	 * One row: the person's facts and, for a membership, its organization
	 * and tier; a standalone member's organization and tier are empty.
	 *
	 * @param array{org_id: int, tier: string, since: string}|null $membership Null for a standalone member.
	 * @return array<string, mixed>
	 */
	private function row( WP_User $user, ?array $membership ): array {
		$orgId = $membership ? $membership['org_id'] : 0;
		// Keyed over COLUMNS so the row's order is the header's whatever
		// order the facts are written in.
		return array_merge(
			array_fill_keys( self::COLUMNS, '' ),
			[
				'id'         => (int) $user->ID,
				'name'       => UserMeta::fullName( $user ),
				'email'      => $user->user_email,
				'org_id'     => $orgId ?: '',
				'org_name'   => $orgId ? get_the_title( $orgId ) : '',
				'tier'       => $membership ? self::tierLabel( $membership['tier'] ) : '',
				'role'       => implode( ',', (array) $user->roles ),
				'expires'    => (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ),
				'last_login' => (string) get_user_meta( $user->ID, UserMeta::KEY_LAST_LOGIN, true ),
			]
		);
	}

	/** A tier as the admin's roster labels it, in plain words rather than the stored key. */
	private static function tierLabel( string $tier ): string {
		return match ( $tier ) {
			Roster::TIER_ADMIN   => __( 'Organization admin', 'monstera' ),
			Roster::TIER_MANAGER => __( 'Manager', 'monstera' ),
			Roster::TIER_MEMBER  => __( 'Member', 'monstera' ),
			default              => $tier,
		};
	}

	/**
	 * @param array<string, mixed> $args
	 */
	public function streamCsv( array $args = [] ): void {
		$rows = $this->rows( $args );
		if ( ! $rows ) {
			$rows = [ array_fill_keys( self::COLUMNS, '' ) ];
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="monstera-members-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$fh = fopen( 'php://output', 'w' );
		Csv::writeRow( $fh, self::COLUMNS );
		foreach ( $rows as $row ) {
			Csv::writeRow( $fh, $row );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream; WP_Filesystem cannot write a response body.
		exit;
	}
}
