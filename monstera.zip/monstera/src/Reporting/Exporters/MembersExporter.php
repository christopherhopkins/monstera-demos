<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

final class MembersExporter {

	/**
	 * @param array<string, mixed> $args
	 * @return array<int, array<string, mixed>>
	 */
	public function rows( array $args = [] ): array {
		$query = [
			'role__in' => [ 'monstera_member', 'monstera_org_manager', 'monstera_member_standalone' ],
			'number'   => -1,
			'fields'   => 'all',
		];
		if ( ! empty( $args['org'] ) ) {
			$query['meta_key']   = UserMeta::KEY_ASSOCIATED_ORG; // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
			$query['meta_value'] = (string) (int) $args['org']; // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
		}
		$users = get_users( $query );

		$out = [];
		foreach ( $users as $user ) {
			$orgId = UserMeta::associatedOrg( $user->ID );
			$out[] = [
				'id'         => $user->ID,
				'name'       => trim( $user->first_name . ' ' . $user->last_name ) ?: $user->display_name,
				'email'      => $user->user_email,
				'org_id'     => $orgId,
				'org_name'   => $orgId ? get_the_title( $orgId ) : '',
				'role'       => implode( ',', (array) $user->roles ),
				'expires'    => (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ),
				'last_login' => (string) get_user_meta( $user->ID, UserMeta::KEY_LAST_LOGIN, true ),
			];
		}
		return $out;
	}

	/**
	 * @param array<string, mixed> $args
	 */
	public function streamCsv( array $args = [] ): void {
		$rows = $this->rows( $args );
		if ( ! $rows ) {
			$rows = [
				[
					'id'         => '',
					'name'       => '',
					'email'      => '',
					'org_id'     => '',
					'org_name'   => '',
					'role'       => '',
					'expires'    => '',
					'last_login' => '',
				],
			];
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="monstera-members-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$fh = fopen( 'php://output', 'w' );
		Csv::writeRow( $fh, array_keys( $rows[0] ) );
		foreach ( $rows as $row ) {
			Csv::writeRow( $fh, $row );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream; WP_Filesystem cannot write a response body.
		exit;
	}
}
