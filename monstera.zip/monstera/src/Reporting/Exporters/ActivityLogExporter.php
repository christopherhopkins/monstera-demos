<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

use Monstera\Core\Database\Schema;

/**
 * CSV export of `wp_monstera_activity_log` joined with user / object titles.
 *
 * Useful for the audit trail conversation an admin has with a member who
 * asks "did anyone download that file?" — flat CSV, one row per event.
 * Bounded by `since_days` to keep exports reasonable; defaults to 90.
 */
final class ActivityLogExporter {

	/**
	 * @param array{since_days?:int, event?:string} $args
	 * @return array<int, array<string, mixed>>
	 */
	public function rows( array $args = [] ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );

		$days  = isset( $args['since_days'] ) ? max( 1, (int) $args['since_days'] ) : 90;
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );

		$whereExtra = '';
		$params     = [ $since ];
		if ( ! empty( $args['event'] ) ) {
			$whereExtra = ' AND event_type = %s';
			$params[]   = (string) $args['event'];
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $whereExtra is empty or the literal ' AND event_type = %s'; the value goes through prepare().
		$raw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, user_id, event_type, object_type, object_id, occurred_at, context
				   FROM %i
				  WHERE occurred_at >= %s {$whereExtra}
				  ORDER BY occurred_at DESC
				  LIMIT 50000",
				$table,
				...$params
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$out = [];
		foreach ( (array) $raw as $row ) {
			$userId = (int) $row['user_id'];
			$user   = $userId ? get_userdata( $userId ) : null;
			$objId  = (int) $row['object_id'];
			$ctx    = $row['context'] ? json_decode( (string) $row['context'], true ) : [];

			// Resolve object title best-effort.
			$objTitle = '';
			if ( $objId ) {
				$objTitle = get_the_title( $objId );
				if ( ! $objTitle && ( 'user' === $row['object_type'] ) ) {
					$obj      = get_userdata( $objId );
					$objTitle = $obj ? $obj->display_name : '';
				}
			}

			$out[] = [
				'id'           => (int) $row['id'],
				'occurred_at'  => (string) $row['occurred_at'],
				'event_type'   => (string) $row['event_type'],
				'user_id'      => $userId,
				'user_name'    => $user ? ( trim( $user->first_name . ' ' . $user->last_name ) ?: $user->display_name ) : '',
				'user_email'   => $user ? $user->user_email : '',
				'object_type'  => (string) $row['object_type'],
				'object_id'    => $objId,
				'object_title' => $objTitle,
				'context'      => is_array( $ctx ) ? wp_json_encode( $ctx ) : (string) $row['context'],
			];
		}
		return $out;
	}

	/**
	 * @param array{since_days?: int, event?: string} $args
	 */
	public function streamCsv( array $args = [] ): void {
		$rows = $this->rows( $args );
		if ( ! $rows ) {
			$rows = [
				[
					'id'           => '',
					'occurred_at'  => '',
					'event_type'   => '',
					'user_id'      => '',
					'user_name'    => '',
					'user_email'   => '',
					'object_type'  => '',
					'object_id'    => '',
					'object_title' => '',
					'context'      => '',
				],
			];
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="monstera-activity-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$fh = fopen( 'php://output', 'w' );
		Csv::writeRow( $fh, array_keys( $rows[0] ) );
		foreach ( $rows as $row ) {
			Csv::writeRow( $fh, $row );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream; WP_Filesystem cannot write a response body.
		exit;
	}
}
