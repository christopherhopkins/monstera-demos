<?php
declare(strict_types=1);

namespace Monstera\Reporting\Exporters;

use Monstera\Forms\Meta;
use Monstera\Forms\Submissions;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

/**
 * CSV export of a form's submissions (Forms-and-resources track, FR8):
 * one row per submission, the sender and the organization it was sent
 * through, then one column per question as the form asks them now, in
 * order, and last the keys of removed questions that still have answers.
 * A file question's cell names its files. The file opens in a spreadsheet
 * as UTF-8 (a byte-order mark first), its cells neutralised as every
 * export's are (Csv).
 */
final class FormSubmissionsExporter {

	/** The columns before the questions, in order. */
	public const COLUMNS = [ 'id', 'submitted_at', 'member', 'email', 'organization' ];

	/**
	 * The header: the fixed columns, the current questions' labels, the
	 * removed keys these rows still answer.
	 *
	 * @param list<array<string, mixed>> $rows Submissions::find()'s shape.
	 * @return list<string>
	 */
	public function header( int $formId, array $rows ): array {
		return array_merge(
			self::COLUMNS,
			array_map( static fn ( array $q ): string => (string) $q['label'], Meta::fieldsOf( $formId ) ),
			Submissions::removedKeys( $formId, $rows )
		);
	}

	/**
	 * The submissions as rows, newest first as the table lists them: every
	 * one for staff, an organization's with `org`.
	 *
	 * @param array<string, mixed> $args
	 * @return list<array<string, mixed>>
	 */
	public function submissions( int $formId, array $args = [] ): array {
		$orgId = (int) ( $args['org'] ?? 0 );
		return $orgId > 0 ? Submissions::forFormAndOrg( $formId, $orgId ) : Submissions::forForm( $formId );
	}

	/**
	 * The file's rows, each in the header's order.
	 *
	 * @param list<array<string, mixed>> $rows
	 * @return list<list<string>>
	 */
	public function rows( int $formId, array $rows ): array {
		$keys = array_merge(
			array_map( static fn ( array $q ): string => (string) $q['key'], Meta::fieldsOf( $formId ) ),
			Submissions::removedKeys( $formId, $rows )
		);
		$out  = [];
		// Every row's files, senders and organizations, each read once.
		$filesOf = Submissions::filesOfMany( array_map( static fn ( array $row ): int => (int) $row['id'], $rows ) );
		cache_users( array_values( array_unique( array_map( static fn ( array $row ): int => (int) $row['user_id'], $rows ) ) ) );
		_prime_post_caches( array_values( array_unique( array_filter( array_map( static fn ( array $row ): int => (int) $row['org_id'], $rows ) ) ) ), false, false );
		foreach ( $rows as $row ) {
			$sender = get_userdata( (int) $row['user_id'] );
			$orgId  = (int) $row['org_id'];
			$files  = $filesOf[ (int) $row['id'] ] ?? [];
			$cells  = [
				(string) $row['id'],
				(string) $row['submitted_at'],
				$sender ? UserMeta::fullName( $sender ) : '',
				$sender ? (string) $sender->user_email : '',
				$orgId > 0 ? (string) get_the_title( $orgId ) : '',
			];
			foreach ( $keys as $key ) {
				$answer  = $row['answers'][ $key ] ?? '';
				$cells[] = is_array( $answer )
					// A file question, as the form asks it or as it was: its files by name.
					? implode( '; ', array_map( static fn ( array $file ): string => (string) $file['name'], $files[ $key ] ?? [] ) )
					// A long answer keeps safe HTML for the sheet; a spreadsheet reads text.
					: trim( html_entity_decode( wp_strip_all_tags( (string) $answer ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			}
			$out[] = $cells;
		}
		return $out;
	}

	/**
	 * The whole file as a string: the byte-order mark, the header, the
	 * rows (or one blank row, so the file is never headerless nothing).
	 *
	 * @param array<string, mixed> $args
	 */
	public function csv( int $formId, array $args = [] ): string {
		return $this->csvFor( $formId, $this->submissions( $formId, $args ) );
	}

	/**
	 * The file for submissions already read (the route counts them first).
	 *
	 * @param list<array<string, mixed>> $submissions
	 */
	public function csvFor( int $formId, array $submissions ): string {
		$header = $this->header( $formId, $submissions );
		$rows   = $this->rows( $formId, $submissions );
		if ( ! $rows ) {
			$rows = [ array_fill( 0, count( $header ), '' ) ];
		}
		$fh = fopen( 'php://temp', 'w+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- an in-memory stream; WP_Filesystem has no CSV writer.
		fwrite( $fh, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- an in-memory stream.
		Csv::writeRow( $fh, $header );
		foreach ( $rows as $row ) {
			Csv::writeRow( $fh, $row );
		}
		rewind( $fh );
		$csv = (string) stream_get_contents( $fh );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- an in-memory stream.
		return $csv;
	}

	/** The file's name: the form by slug, dated by the site's day. */
	public function fileName( int $formId ): string {
		$slug = sanitize_title( (string) get_the_title( $formId ) );
		return Csv::fileName( 'submissions-' . ( '' !== $slug ? $slug : (string) $formId ) );
	}
}
