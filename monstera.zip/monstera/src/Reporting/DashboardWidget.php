<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Capabilities;
use Monstera\Core\Icons;

defined( 'ABSPATH' ) || exit;

/**
 * WP dashboard widget — quick situational awareness on wp-admin/index.php.
 * Intentionally light: a single sentence and a link to the Monstera dashboard,
 * not a hero-metric splash (per DESIGN.md anti-patterns).
 */
final class DashboardWidget {

	public static function register(): void {
		if ( ! current_user_can( Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return;
		}
		wp_add_dashboard_widget( 'monstera_overview', __( 'Monstera', 'monstera' ), [ self::class, 'render' ] );
	}

	public static function render(): void {
		$logins = ActivityLog::loginsThisWeek();
		$active = ActivityLog::activeMemberCount();
		?>
		<div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
			<span style="color:#2f5e3e"><?php Icons::emit( 'leaf-mark', 22 ); ?></span>
			<strong style="font-family:Georgia, serif; font-size:16px">
				<?php
				printf(
					/* translators: 1: active member count, 2: logins this week */
					esc_html__( '%1$d members. %2$d logins in the last 7 days.', 'monstera' ),
					(int) $active,
					(int) $logins
				);
				?>
			</strong>
		</div>
		<p style="margin:0 0 4px;color:#5a5a5a">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=monstera' ) ); ?>"><?php esc_html_e( 'Open the Monstera dashboard →', 'monstera' ); ?></a>
		</p>
		<?php
	}
}
