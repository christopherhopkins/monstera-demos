<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Hooks;
use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class ReportingModule implements Module {

	public function slug(): string {
		return 'reporting';
	}

	public function boot(): void {
		// WordPress fires wp_login before it sets the current user, so the row
		// names the person itself rather than "whoever is signed in" (nobody).
		add_action( Hooks::MEMBER_LOGGED_IN, static fn ( int $u ) => ActivityLog::record( 'login', 'user', $u, [ 'user_id' => $u ] ) );
		// A download is logged once, by the downloader (ActivityLog::recordDownload).
		add_action( Hooks::PROJECT_STATUS_CHANGED, [ Tracking::class, 'projectStageChanged' ], 10, 3 );
		add_action( Hooks::CONTENT_PUBLISHED, static fn ( int $c ) => ActivityLog::record( 'publish', 'content', $c ) );
		add_action( Hooks::NOTIFICATION_SENT, static fn ( int $u, string $event ) => ActivityLog::record( 'notification', 'user', $u, [ 'event' => $event ] ), 10, 2 );

		add_action( 'wp_dashboard_setup', [ DashboardWidget::class, 'register' ] );
	}

	public function registerPostTypes(): void {}
}
