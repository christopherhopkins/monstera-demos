<?php
declare(strict_types=1);

namespace Monstera\Reporting;

use Monstera\Core\Hooks;
use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class ReportingModule implements Module {

	public function slug(): string {
		return 'reporting';
	}

	public function boot(): void {
		// WordPress fires wp_login before it sets the current user, so the row
		// names the person itself rather than "whoever is signed in" (nobody).
		add_action( Hooks::MEMBER_LOGGED_IN, static fn ( int $u ) => ActivityLog::record( 'login', 'user', $u, [ 'user_id' => $u ] ) );
		// A download is logged once, by the downloader (ActivityLog::recordDownload).
		add_action( Hooks::PROJECT_STATUS_CHANGED, [ Tracking::class, 'projectStageChanged' ], 10, 3 );
		add_action( Hooks::CONTENT_PUBLISHED, static fn ( int $c ) => ActivityLog::record( 'publish', 'content', $c ) );
		add_action( Hooks::NOTIFICATION_SENT, [ self::class, 'notificationSent' ], 10, 4 );

		add_action( 'wp_dashboard_setup', [ DashboardWidget::class, 'register' ] );
	}

	/**
	 * An email went: one row about its recipient, filed under the
	 * organization the sender says the email concerns (FR9). A sender that
	 * names none (an extension written before the hook carried it) leaves
	 * the row to the recipient's primary organization, as every such row
	 * was filed before.
	 *
	 * @param mixed    $rendered The subject and body sent; the row does not keep them.
	 * @param int|null $orgId    The organization the email concerns, 0 for none; null when the sender did not say.
	 */
	public static function notificationSent( int $userId, string $event, mixed $rendered = null, ?int $orgId = null ): void {
		unset( $rendered );
		$context = [ 'event' => $event ];
		if ( null !== $orgId ) {
			$context['org_id'] = $orgId;
		}
		ActivityLog::record( 'notification', 'user', $userId, $context );
	}

	public function registerPostTypes(): void {}
}
