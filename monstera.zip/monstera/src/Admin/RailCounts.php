<?php
declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Core\Database\Schema;
use Monstera\Core\Modules;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Support\Repository as SupportRepository;

/**
 * The counts beside two rail links (comp 90): projects in flight and open
 * support requests. Counted on the server each time the shell renders, so
 * the numbers are never older than the page.
 */
final class RailCounts {

	/** Project stages that count as in flight. */
	public const IN_FLIGHT = [
		ProjectMeta::STATUS_DISCOVERY,
		ProjectMeta::STATUS_IN_PROGRESS,
		ProjectMeta::STATUS_REVIEW,
	];

	/**
	 * The rail's counts keyed by page slug, for the active modules only.
	 *
	 * @return array<string, int>
	 */
	public static function forRail(): array {
		$counts = [];
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			$counts['monstera-projects'] = self::projectsInFlight();
		}
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			$counts['monstera-support'] = self::openRequests();
		}
		return $counts;
	}

	/** Published projects whose stage is Discovery, In progress or Review. */
	public static function projectsInFlight(): int {
		$query = new \WP_Query(
			[
				'post_type'      => ProjectPostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- one indexed key, counted once per shell render.
					[
						'key'     => ProjectMeta::KEY_STATUS,
						'value'   => self::IN_FLIGHT,
						'compare' => 'IN',
					],
				],
			]
		);
		return (int) $query->found_posts;
	}

	/** Support requests in the inbox's open status. */
	public static function openRequests(): int {
		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live count for the rail; the table is Monstera's own.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE status = %s',
				Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
				SupportRepository::STATUS_OPEN
			)
		);
	}
}
