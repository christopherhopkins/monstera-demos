<?php
/**
 * The columns a staff person chose to read on an admin list.
 *
 * A list may offer a Columns chooser (the organization list first,
 * At-a-glance track, FR2): the choice is the person's own, kept in their
 * user meta as a map of list key to the column keys turned off, written by
 * POST profile/me/columns (which takes and answers the columns left on) and
 * handed to the shell on every page, as the columns left on, so the list
 * renders the chosen set from its first paint. A column the list always
 * shows (the name, the open link) is not choosable and so never in the set;
 * a column it does not have is refused.
 */

declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

final class ColumnSets {

	/**
	 * The lists with a chooser and the columns each may hide, in the
	 * list's own order. The page's column definitions name the same keys.
	 *
	 * @var array<string, list<string>>
	 */
	public const LISTS = [
		'organizations' => [ 'tier', 'members', 'projects', 'account_lead', 'expires', 'status' ],
	];

	/**
	 * The choosable columns of a list, or null for a list with no chooser.
	 *
	 * @return list<string>|null
	 */
	public static function choosable( string $listKey ): ?array {
		return self::LISTS[ $listKey ] ?? null;
	}

	/**
	 * A set as it will be stored: the list's choosable columns the request
	 * named, each once, in the list's order; or null when one named is not a
	 * column of the list (the caller refuses the request on the field).
	 *
	 * @param array<int|string, mixed> $columns
	 * @return list<string>|null
	 */
	public static function sanitize( string $listKey, array $columns ): ?array {
		$choosable = self::choosable( $listKey );
		if ( null === $choosable ) {
			return null;
		}
		$named = [];
		foreach ( $columns as $column ) {
			if ( ! is_string( $column ) ) {
				return null;
			}
			$column = sanitize_key( $column );
			if ( ! in_array( $column, $choosable, true ) ) {
				return null;
			}
			$named[ $column ] = true;
		}
		return array_values( array_filter( $choosable, static fn ( string $column ): bool => isset( $named[ $column ] ) ) );
	}

	/**
	 * Every set the person chose, by list: the columns left on, in the
	 * list's order. What is stored is the columns the person turned off
	 * (hidden()), so a column the list gains later is on for everyone, and
	 * a column it loses drops out of the stored set alone; a list with no
	 * entry, or no chooser, shows every column and is not in the answer.
	 *
	 * @return array<string, list<string>>
	 */
	public static function forUser( int $userId ): array {
		$out = [];
		foreach ( self::hidden( $userId ) as $listKey => $hidden ) {
			$out[ $listKey ] = array_values( array_diff( (array) self::choosable( $listKey ), $hidden ) );
		}
		return $out;
	}

	/**
	 * Keep the person's set for one list, leaving the others as they are:
	 * the choosable columns the set leaves out are stored as hidden.
	 *
	 * @param list<string> $columns A set sanitize() answered: the columns left on.
	 */
	public static function save( int $userId, string $listKey, array $columns ): void {
		$sets             = self::hidden( $userId );
		$sets[ $listKey ] = array_values( array_diff( (array) self::choosable( $listKey ), $columns ) );
		update_user_meta( $userId, UserMeta::KEY_COLUMNS, $sets );
	}

	/**
	 * What is stored, cleaned: by list with a chooser, the choosable
	 * columns the person turned off, each once, in the list's order. A name
	 * the list no longer has is left out; a list this build has no chooser
	 * for is kept out of the answer (and so of the next save).
	 *
	 * @return array<string, list<string>>
	 */
	private static function hidden( int $userId ): array {
		$stored = $userId > 0 ? get_user_meta( $userId, UserMeta::KEY_COLUMNS, true ) : [];
		$out    = [];
		foreach ( is_array( $stored ) ? $stored : [] as $listKey => $hidden ) {
			if ( ! is_string( $listKey ) || ! is_array( $hidden ) ) {
				continue;
			}
			$choosable = self::choosable( $listKey );
			if ( null === $choosable ) {
				continue;
			}
			$named = [];
			foreach ( $hidden as $column ) {
				if ( is_string( $column ) ) {
					$named[ sanitize_key( $column ) ] = true;
				}
			}
			$out[ $listKey ] = array_values( array_filter( $choosable, static fn ( string $column ): bool => isset( $named[ $column ] ) ) );
		}
		return $out;
	}
}
