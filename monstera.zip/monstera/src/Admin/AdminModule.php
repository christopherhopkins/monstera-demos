<?php
declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class AdminModule implements Module {

	public function slug(): string {
		return 'admin';
	}

	public function boot(): void {
		add_action( 'admin_menu', [ Menu::class, 'register' ] );
		add_action( 'admin_init', [ Shell::class, 'maybeRender' ] );
		add_filter( 'admin_body_class', [ Shell::class, 'bodyClass' ] );
		add_action( 'admin_notices', [ Shell::class, 'integrationsNotice' ] );
		OutsideNotices::register();
	}

	public function registerPostTypes(): void {}
}
