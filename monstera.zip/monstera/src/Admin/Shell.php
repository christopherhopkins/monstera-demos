<?php
declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Core\Hooks;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Core\UseCase;
use Monstera\Members\UserMeta;
use Monstera\Organizations\PostType as OrgPostType;

/**
 * Mounts the React admin shell on every Monstera-owned admin page.
 *
 * PHP renders the rail + header + a single <div id="monstera-admin-root"> mount.
 * The React app reads window.monsteraAdmin (localized in Core\Assets) to know
 * which page to route to and which REST endpoints to hit.
 */
final class Shell {

	public static function maybeRender(): void {
		// Reserved for future server-side preflight (e.g. capability redirects).
	}

	/** Whether the request is for a Monstera admin page, the ones this shell renders. */
	public static function isPage(): bool {
		$page = (string) ( $_GET['page'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
		return '' !== $page && str_starts_with( $page, 'monstera' );
	}

	public static function bodyClass( string $classes ): string {
		if ( ! self::isPage() ) {
			return $classes;
		}
		// The Monstera rail is the navigation here, so WordPress's menu folds
		// to icons (comp 90). The class is the page's; the user's own fold
		// preference, stored by WordPress, is never written.
		return trim( $classes . ' monstera-admin-page folded' );
	}

	public static function integrationsNotice(): void {
		// Reserved for one-shot post-activation banner with deploy/cron tips.
	}

	public static function render(): void {
		$page    = (string) ( $_GET['page'] ?? Menu::SLUG ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
		$pages   = Menu::pages();
		$current = $pages[ $page ] ?? [ 'title' => __( 'Dashboard', 'monstera' ) ];
		// A detail page (an id or a new record) carries its own title line;
		// the page lead belongs to the list.
		$isDetail = isset( $_GET['id'] ) || 'new' === (string) ( $_GET['action'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameters; nothing is written.
		$counts   = RailCounts::forRail();
		// First run: the dashboard asks what the site is running, and the
		// rail leaves out the pages a preset may switch off (comp 92).
		$onboarding = Menu::SLUG === $page && Onboarding::isPending();
		if ( $onboarding ) {
			$pages            = array_diff_key( $pages, array_flip( self::GATED ) );
			$current['title'] = __( 'Set up', 'monstera' );
		}
		// A program of individuals with no organizations is not offered pages
		// for organizations and sub-groups. They stay reachable by address and
		// come back as soon as an organization exists, so nothing is hidden.
		if ( self::hidesOrganizationPages() ) {
			$pages = array_diff_key( $pages, array_flip( self::ORGANIZATION_PAGES ) );
		}
		?>
		<div class="monstera-admin-shell" data-page="<?php echo esc_attr( $page ); ?>">
			<aside class="m-rail" aria-label="<?php esc_attr_e( 'Monstera', 'monstera' ); ?>">
				<a class="m-rail__brand" href="<?php echo esc_url( admin_url( 'admin.php?page=' . Menu::SLUG ) ); ?>">
					<?php Icons::emit( 'leaf-mark', 24 ); ?>
					<span class="m-rail__label"><?php esc_html_e( 'Monstera', 'monstera' ); ?></span>
				</a>
				<nav class="m-rail__nav" aria-label="<?php esc_attr_e( 'Monstera pages', 'monstera' ); ?>">
					<?php self::renderRailLinks( $page, $pages, $counts ); ?>
				</nav>
				<div class="m-rail__foot">
					<a class="m-rail__link" href="<?php echo esc_url( Routing::url( Routing::ROUTE_DASHBOARD ) ); ?>">
						<span class="m-rail__icon"><?php Icons::emit( 'rail-portal', 20 ); ?></span>
						<span class="m-rail__label"><?php esc_html_e( 'Portal', 'monstera' ); ?><span aria-hidden="true"> ↗</span></span>
					</a>
				</div>
			</aside>

			<div class="monstera-admin-shell__main m-app">
				<header class="m-app__bar">
					<button class="m-app__menu" type="button" aria-controls="monstera-admin-drawer" aria-expanded="false">
						<span class="m-sr-only"><?php esc_html_e( 'Open Monstera menu', 'monstera' ); ?></span>
						<?php Icons::emit( 'menu', 22 ); ?>
					</button>
					<?php self::renderCrumb( $page, $current['title'], $isDetail ); ?>
					<span class="m-app__spacer"></span>
					<?php self::renderTray(); ?>
					<?php self::renderThemeGroup(); ?>
				</header>
				<?php
				/**
				 * Between the app bar and the page, on every Monstera admin screen.
				 * Rendered on the server with the shell, so nothing moves after paint.
				 *
				 * @param string $page The Monstera page slug being rendered.
				 */
				do_action( Hooks::ADMIN_SHELL_BEFORE_ROOT, $page );
				?>

				<main class="monstera-admin-shell__body" id="monstera-main">
					<?php // A detail page's own head carries its h1, badges and actions. ?>
					<?php if ( $onboarding ) : ?>
						<header class="m-page__head">
							<div>
								<h1><?php esc_html_e( 'Welcome to Monstera.', 'monstera' ); ?></h1>
								<p><?php esc_html_e( "One question, then you're in. Everything here can be changed later in Settings.", 'monstera' ); ?></p>
							</div>
						</header>
					<?php elseif ( Menu::SLUG === $page ) : ?>
						<?php self::renderDashboardHead(); ?>
					<?php elseif ( ! $isDetail ) : ?>
						<header class="m-page__head">
							<div>
								<h1><?php echo esc_html( $current['title'] ); ?></h1>
								<?php if ( ! empty( $current['lead'] ) ) : ?>
									<p><?php echo esc_html( $current['lead'] ); ?></p>
								<?php endif; ?>
							</div>
							<div class="m-page__actions" id="monstera-admin-header-actions"></div>
						</header>
					<?php endif; ?>

					<div id="monstera-admin-root" data-page="<?php echo esc_attr( $page ); ?>"<?php echo $onboarding ? ' data-onboarding="1"' : ''; ?>>
						<?php self::renderInitialFallback( $isDetail ); ?>
					</div>
				</main>
			</div>

			<?php // Below 1024 the rail's links live here, opened from the app bar (resources/js/admin/shell.js). ?>
			<div class="m-drawer" id="monstera-admin-drawer" hidden>
				<button class="m-drawer__scrim" type="button" tabindex="-1" data-drawer-close>
					<span class="m-sr-only"><?php esc_html_e( 'Close menu', 'monstera' ); ?></span>
				</button>
				<div class="m-drawer__panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Monstera menu', 'monstera' ); ?>">
					<div class="m-drawer__head">
						<span class="m-drawer__title"><?php esc_html_e( 'Monstera', 'monstera' ); ?></span>
						<button class="m-drawer__close" type="button" data-drawer-close aria-label="<?php esc_attr_e( 'Close menu', 'monstera' ); ?>">
							<?php Icons::emit( 'x', 20 ); ?>
						</button>
					</div>
					<nav class="m-rail__nav" data-in-drawer aria-label="<?php esc_attr_e( 'Monstera pages', 'monstera' ); ?>">
						<?php self::renderRailLinks( $page, $pages, $counts ); ?>
					</nav>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * The dashboard's head (comp 90): the greeting and the date, the counts
	 * as a line of links beneath, then the two page actions ("Post an alert" only with Alerts on).
	 */
	private static function renderDashboardHead(): void {
		?>
		<header class="m-page__head">
			<div>
				<h1><?php echo esc_html( DashboardHead::greeting( wp_get_current_user() ) ); ?></h1>
				<p><?php echo esc_html( DashboardHead::date() ); ?></p>
				<ul class="m-page__facts" aria-label="<?php esc_attr_e( 'At a glance', 'monstera' ); ?>">
					<?php foreach ( DashboardHead::facts() as $fact ) : ?>
						<li><a href="<?php echo esc_url( $fact['url'] ); ?>"><?php echo esc_html( $fact['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<div class="m-page__actions" id="monstera-admin-header-actions">
				<?php if ( Modules::isActive( Modules::ALERTS ) ) : ?>
					<a class="m-btn" data-intent="secondary" data-size="sm" href="<?php echo esc_url( admin_url( 'admin.php?page=monstera-alerts&action=new' ) ); ?>"><?php esc_html_e( 'Post an alert', 'monstera' ); ?></a>
				<?php endif; ?>
				<a class="m-btn" data-intent="primary" data-size="sm" href="<?php echo esc_url( admin_url( 'admin.php?page=monstera-content&action=new' ) ); ?>"><?php esc_html_e( 'New content', 'monstera' ); ?></a>
			</div>
		</header>
		<?php
	}

	/**
	 * The outside-notices tray (comp 93): what WordPress and other plugins
	 * printed above this page (Admin\OutsideNotices) goes here, as printed,
	 * behind a Notices button, so nothing sits above the shell. Hidden when
	 * nothing printed is a notice; it is still rendered, since a script may
	 * add one later and whatever scripts and styles were printed must still
	 * run. The markup waits in a holder; the shell script
	 * (resources/js/admin/tray.js) counts it, sets the button's tone and
	 * moves each notice into a row of the list.
	 */
	private static function renderTray(): void {
		?>
		<div class="m-tray" data-tray<?php echo OutsideNotices::hasNotices() ? '' : ' hidden'; ?>>
			<button class="m-tray__button" type="button" data-tone="info" aria-controls="monstera-admin-tray" aria-expanded="false">
				<span class="m-tray__count" aria-hidden="true"></span>
				<span class="m-tray__label"><?php esc_html_e( 'Notices', 'monstera' ); ?></span>
				<span class="m-sr-only" data-tray-name></span>
			</button>
			<section class="m-tray__panel" id="monstera-admin-tray" aria-labelledby="monstera-admin-tray-title" hidden>
				<div class="m-tray__head">
					<div>
						<h2 id="monstera-admin-tray-title"><?php esc_html_e( 'Notices', 'monstera' ); ?></h2>
						<p><?php esc_html_e( 'From WordPress and other plugins. Monstera keeps them here so the page stays put.', 'monstera' ); ?></p>
					</div>
					<button class="m-tray__close" type="button" data-tray-close aria-label="<?php esc_attr_e( 'Close notices', 'monstera' ); ?>">
						<?php Icons::emit( 'x', 20 ); ?>
					</button>
				</div>
				<ol class="m-tray__list" data-tray-list></ol>
				<div class="m-tray__source" data-tray-source>
					<?php
					// Other plugins' own markup, exactly as they printed it on the
					// notice hooks: escaping it here would break the notices.
					echo OutsideNotices::html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see above.
					?>
				</div>
			</section>
		</div>
		<?php // Always in the bar, outside the tray (which may be hidden), so a notice that arrives after the page loaded is announced. ?>
		<span class="m-sr-only" role="status" data-tray-status></span>
		<?php
	}

	/**
	 * The segmented light/dark group (comp 90's app bar): the same
	 * monstera_theme preference as the portal, applied at once and saved by
	 * resources/js/admin/shell.js through POST profile/me/theme.
	 */
	private static function renderThemeGroup(): void {
		$theme = 'dark' === (string) get_user_meta( get_current_user_id(), UserMeta::KEY_THEME, true ) ? 'dark' : 'light';
		$modes = [
			'light' => [ 'sun', __( 'Light theme', 'monstera' ) ],
			'dark'  => [ 'moon', __( 'Dark theme', 'monstera' ) ],
		];
		?>
		<div class="m-theme" role="group" aria-label="<?php esc_attr_e( 'Theme', 'monstera' ); ?>">
			<?php foreach ( $modes as $mode => [ $icon, $label ] ) : ?>
				<button type="button" data-theme-set="<?php echo esc_attr( $mode ); ?>" aria-pressed="<?php echo $mode === $theme ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( $label ); ?>">
					<?php Icons::emit( $icon, 16 ); ?>
				</button>
			<?php endforeach; ?>
		</div>
		<?php // Always in the bar, so what arrives in it is announced: a theme that could not be saved. ?>
		<span class="m-sr-only" role="status" data-theme-status data-failed="<?php esc_attr_e( 'The theme could not be saved, so the page is back on the one you had.', 'monstera' ); ?>"></span>
		<?php
	}

	/** The module-gated pages, which the rail leaves out while onboarding asks. */
	private const GATED = [ 'monstera-projects', 'monstera-forms', 'monstera-alerts', 'monstera-support', 'monstera-reports' ];

	/** The pages a standalone program has no use for until it has an organization. */
	private const ORGANIZATION_PAGES = [ 'monstera-organizations', 'monstera-subgroups' ];

	/**
	 * Whether the rail leaves out Organizations and Sub-groups: the site runs
	 * the standalone preset and holds no organization in any state but trash.
	 */
	private static function hidesOrganizationPages(): bool {
		if ( UseCase::STANDALONE !== UseCase::current() ) {
			return false;
		}
		$counts = (array) wp_count_posts( OrgPostType::SLUG );
		unset( $counts['trash'], $counts['auto-draft'] );
		return 0 === array_sum( array_map( 'intval', $counts ) );
	}

	/** The rail's pages in the comp's order; module-gated pages drop out of Menu::pages(). */
	private const RAIL_ORDER = [
		Menu::SLUG,
		'monstera-organizations',
		'monstera-members',
		'monstera-content',
		'monstera-subgroups',
		'monstera-projects',
		'monstera-forms',
		'monstera-alerts',
		'monstera-support',
		'monstera-reports',
		'monstera-settings',
		'monstera-tools',
		'monstera-help',
	];

	/**
	 * The rail's links, shared by the rail and (below 1024) the drawer. A
	 * count sits in the visible badge and, with its meaning, in the link's
	 * accessible name ("Projects (7 in flight)").
	 *
	 * @param string                                        $page   The current page slug.
	 * @param array<string, array{title:string, icon:string}> $pages  Menu::pages().
	 * @param array<string, int>                            $counts RailCounts::forRail().
	 */
	private static function renderRailLinks( string $page, array $pages, array $counts ): void {
		foreach ( self::RAIL_ORDER as $slug ) {
			if ( ! isset( $pages[ $slug ] ) ) {
				continue;
			}
			$icon = 'rail-' . ( Menu::SLUG === $slug ? 'dashboard' : substr( $slug, strlen( 'monstera-' ) ) );
			?>
			<a class="m-rail__link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . $slug ) ); ?>"<?php echo $slug === $page ? ' aria-current="page"' : ''; ?>>
				<span class="m-rail__icon"><?php Icons::emit( $icon, 20 ); ?></span>
				<span class="m-rail__label"><?php echo esc_html( $pages[ $slug ]['title'] ); ?></span>
				<?php if ( isset( $counts[ $slug ] ) ) : ?>
					<span class="m-rail__count"><?php self::renderCount( $slug, $counts[ $slug ] ); ?></span>
				<?php endif; ?>
			</a>
			<?php
		}
	}

	/** The number, with what it counts for assistive technology only. */
	private static function renderCount( string $slug, int $count ): void {
		$sentence = 'monstera-projects' === $slug
			/* translators: %d: number of projects in Discovery, In progress or Review */
			? sprintf( _n( '%d in flight', '%d in flight', $count, 'monstera' ), $count )
			/* translators: %d: number of open support requests */
			: sprintf( _n( '%d open', '%d open', $count, 'monstera' ), $count );
		?>
		<span aria-hidden="true"><?php echo esc_html( number_format_i18n( $count ) ); ?></span>
		<span class="m-sr-only"> (<?php echo esc_html( $sentence ); ?>)</span>
		<?php
	}

	/**
	 * The app bar's crumb: "Monstera / <page>" on a list, "<page> / <record>"
	 * on a detail, where the record's name is filled in by the detail page
	 * (DetailLayout portals its title into the current slot) once it loads.
	 */
	private static function renderCrumb( string $page, string $title, bool $isDetail ): void {
		$parentHref  = $isDetail ? admin_url( 'admin.php?page=' . $page ) : admin_url( 'admin.php?page=' . Menu::SLUG );
		$parentLabel = $isDetail ? $title : __( 'Monstera', 'monstera' );
		$isHome      = ! $isDetail && Menu::SLUG === $page;
		?>
		<nav class="m-app__crumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'monstera' ); ?>">
			<?php if ( $isHome ) : ?>
				<span><?php echo esc_html( $parentLabel ); ?></span>
			<?php else : ?>
				<a href="<?php echo esc_url( $parentHref ); ?>"><?php echo esc_html( $parentLabel ); ?></a>
			<?php endif; ?>
			<span class="m-app__crumb-sep" aria-hidden="true">/</span>
			<?php if ( $isDetail ) : ?>
				<span aria-current="page" id="monstera-admin-crumb-current"></span>
			<?php else : ?>
				<span aria-current="page"><?php echo esc_html( $title ); ?></span>
			<?php endif; ?>
		</nav>
		<?php
	}

	/**
	 * Server-side fallback shown until the React app hydrates, so the page
	 * is not blank even if JS fails to load. A list page shows the leaf
	 * loader; a detail page shows the skeleton in its shape, the same markup
	 * as DetailLayout.js's DetailSkeleton, which stands in while the page's
	 * chunk and its record load, so a slow load shows one skeleton from
	 * first paint until the fields arrive.
	 */
	private static function renderInitialFallback( bool $isDetail ): void {
		if ( $isDetail ) {
			self::renderDetailSkeleton();
			return;
		}
		?>
		<div class="monstera-admin-shell__fallback" aria-hidden="true">
			<div class="m-leaf-loader">
				<?php Icons::emit( 'leaf-mark', 56 ); ?>
				<p><?php esc_html_e( 'Loading…', 'monstera' ); ?></p>
			</div>
		</div>
		<?php
	}

	/** The detail skeleton: keep in step with DetailSkeleton in DetailLayout.js. */
	private static function renderDetailSkeleton(): void {
		$bar = static function ( string $shape ): void {
			echo '<span class="m-skeleton" data-shape="' . esc_attr( $shape ) . '"></span>';
		};
		?>
		<div class="m-detail m-detail-skeleton" aria-busy="true">
			<span class="m-sr-only"><?php esc_html_e( 'Loading…', 'monstera' ); ?></span>
			<div class="m-detail__head">
				<?php
				$bar( 'back' );
				$bar( 'eyebrow' );
				$bar( 'title' );
				$bar( 'meta' );
				?>
			</div>
			<div class="m-detail__main">
				<div class="m-dsection">
					<div class="m-dsection__head"><?php $bar( 'heading' ); ?><?php $bar( 'line' ); ?></div>
					<div class="m-dsection__grid">
						<?php for ( $i = 0; $i < 6; $i++ ) : ?>
							<span class="m-detail-skeleton__field"><?php $bar( 'label' ); ?><?php $bar( 'control' ); ?></span>
						<?php endfor; ?>
					</div>
				</div>
			</div>
			<div class="m-detail__side">
				<?php
				$bar( 'heading' );
				for ( $i = 0; $i < 3; $i++ ) {
					$bar( 'stat' );
				}
				?>
			</div>
		</div>
		<?php
	}
}
