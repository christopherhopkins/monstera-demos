<?php
declare(strict_types=1);

namespace Monstera\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * What WordPress and other plugins print above a Monstera page.
 *
 * wp-admin fires in_admin_header before the page body, then admin_notices
 * and all_admin_notices inside it, ahead of the page's own callback. Whatever
 * is printed there sits above the shell and pushes the rail and the app bar
 * down. On a Monstera page this class buffers each of those two stretches,
 * from the hook's first callback to its last, and keeps the markup as it was
 * printed; Shell renders it inside the tray in the app bar (comp 93). Every
 * other screen is left alone, and so is WordPress's admin bar.
 *
 * The buffer has an output handler, so the markup is kept however the buffer
 * comes to be flushed, by this class or by a callback that closes a buffer
 * it did not open. A callback that takes the buffer's contents for itself
 * (ob_get_clean) has taken responsibility for them, and they are not kept.
 */
final class OutsideNotices {

	/**
	 * The markup captured so far, in printed order.
	 *
	 * @var list<string>
	 */
	private static array $captured = [];

	/** The buffer level of the capture in progress, or null between captures. */
	private static ?int $level = null;

	/** True while stop() is closing the capture's own buffer. */
	private static bool $closing = false;

	public static function register(): void {
		add_action( 'in_admin_header', [ self::class, 'start' ], PHP_INT_MIN );
		add_action( 'in_admin_header', [ self::class, 'stop' ], PHP_INT_MAX );
		add_action( 'admin_notices', [ self::class, 'start' ], PHP_INT_MIN );
		add_action( 'all_admin_notices', [ self::class, 'stop' ], PHP_INT_MAX );
	}

	/**
	 * Opens a capture, on a Monstera page only.
	 *
	 * WordPress renders its own admin bar on in_admin_header (priority 0),
	 * inside the stretch this captures. The bar is WordPress's chrome, not a
	 * notice, so it is printed here first; it renders once per request, and
	 * WordPress's own call then does nothing.
	 */
	public static function start(): void {
		if ( null !== self::$level || ! Shell::isPage() ) {
			return;
		}
		if ( doing_action( 'in_admin_header' ) ) {
			wp_admin_bar_render();
		}
		ob_start( [ self::class, 'keep' ] );
		self::$level = ob_get_level();
	}

	/**
	 * Closes the capture. Buffers a callback opened and left open are flushed
	 * into it first, so their markup is kept and the level is the one the
	 * capture found; if a callback already closed the capture itself, there
	 * is nothing left to close. A buffer PHP will not let this class close
	 * (one opened without the removable flag, which PHP refuses for as long
	 * as the script runs) is left to its owner, and the capture under it is
	 * disarmed: when it finally flushes, everything in it reaches the page.
	 */
	public static function stop(): void {
		if ( null === self::$level ) {
			return;
		}
		while ( ob_get_level() > self::$level ) {
			if ( ! self::closable( ob_get_status() ) ) {
				self::$level = null;
				return;
			}
			ob_end_flush();
		}
		if ( ob_get_level() === self::$level ) {
			self::$closing = true;
			ob_end_flush();
			self::$closing = false;
		}
		self::$level = null;
	}

	/**
	 * Whether a buffer above the capture can be closed from here. PHP refuses
	 * to close one opened without the removable flag, and would refuse on
	 * every try, so stop() must not loop on it.
	 *
	 * @param array<string, mixed> $status One buffer's ob_get_status() row.
	 */
	public static function closable( array $status ): bool {
		return (bool) ( ( (int) ( $status['flags'] ?? 0 ) ) & PHP_OUTPUT_HANDLER_REMOVABLE );
	}

	/**
	 * The capture's output handler: keeps what is flushed and prints nothing.
	 * A final flush that is not stop()'s own (a fatal error, an exit, a
	 * callback closing a buffer it did not open, or shutdown) passes the
	 * buffer through instead, so an error message printed inside it is never
	 * lost to a blank page.
	 *
	 * @param string $buffer The buffer's contents.
	 * @param int    $phase  PHP_OUTPUT_HANDLER_* flags.
	 */
	public static function keep( string $buffer, int $phase ): string {
		if ( $phase & PHP_OUTPUT_HANDLER_CLEAN ) {
			return '';
		}
		if ( ( $phase & PHP_OUTPUT_HANDLER_FINAL ) && ! self::$closing ) {
			return $buffer;
		}
		if ( '' !== $buffer ) {
			self::$captured[] = $buffer;
		}
		return '';
	}

	/** Everything captured on this page load, as it was printed. */
	public static function html(): string {
		return implode( '', self::$captured );
	}

	/**
	 * Whether anything captured is a notice to show: an element that is not
	 * a script or a style, or bare text. It decides whether the tray's
	 * button is there on first paint; the shell script then settles it for
	 * what only a browser can tell (a notice its plugin is hiding).
	 */
	public static function hasNotices(): bool {
		$html = self::html();
		if ( '' === trim( $html ) ) {
			return false;
		}
		$tags = new \WP_HTML_Tag_Processor( $html );
		while ( $tags->next_tag() ) {
			if ( ! in_array( $tags->get_tag(), self::NOT_NOTICES, true ) ) {
				return true;
			}
		}
		return '' !== trim( wp_strip_all_tags( $html ) );
	}

	/** Tags a plugin prints beside its notices; keep in step with NOT_NOTICES in resources/js/admin/tray.js. */
	private const NOT_NOTICES = [ 'SCRIPT', 'STYLE', 'LINK', 'META', 'NOSCRIPT', 'TEMPLATE', 'BR', 'HR' ];

	/** Forgets what was captured (tests fire the hooks more than once per process). */
	public static function reset(): void {
		self::$captured = [];
		self::$level    = null;
		self::$closing  = false;
	}
}
