<?php
declare(strict_types=1);

namespace Monstera\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * First-run onboarding (comp 92): the Monstera dashboard asks what the site
 * is running until a use case is stored or the admin skips. A skip is
 * remembered, so the question never returns; Settings keeps the presets.
 */
final class Onboarding {

	/** When the admin chose "Skip for now" (a timestamp). */
	public const SKIP_OPTION = 'monstera_onboarding_skipped';

	/** Whether the dashboard should render the onboarding question. */
	public static function isPending(): bool {
		return '' === (string) get_option( 'monstera_use_case', '' ) && ! get_option( self::SKIP_OPTION );
	}

	public static function skip(): void {
		update_option( self::SKIP_OPTION, time(), false );
	}
}
