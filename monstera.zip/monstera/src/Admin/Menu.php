<?php
declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Capabilities;
use Monstera\Core\Icons;
use Monstera\Core\Modules;
use Monstera\Portal\Audience;

defined( 'ABSPATH' ) || exit;

final class Menu {

	public const SLUG = 'monstera';

	/**
	 * The pages only a Team manager and a WordPress administrator open
	 * (People-model track, FR2). Each is registered under
	 * monstera_manage_settings, so WordPress keeps it out of a Team member's
	 * menu and refuses them its address, and pages() keeps it out of their
	 * rail.
	 */
	private const MANAGER_PAGES = [ 'monstera-settings', 'monstera-tools' ];

	/**
	 * The rail's groups in their order (At-a-glance track, FR1): People,
	 * Work, then the tail at the rail's foot. The Dashboard stands alone
	 * before them and carries none. Every other page names its group.
	 */
	public const GROUPS = [ 'people', 'work', 'tail' ];

	/** A group's heading in the rail; the tail's is read by screen readers alone (headingHidden()). */
	public static function groupLabel( string $group ): string {
		return match ( $group ) {
			'people' => __( 'People', 'monstera' ),
			'work'   => __( 'Work', 'monstera' ),
			'tail'   => __( 'More', 'monstera' ),
			default  => '',
		};
	}

	/**
	 * Whether a group's heading is read by screen readers alone: the tail's,
	 * which the rail draws apart at its foot with no name on the page. Without
	 * one, a heading outline put Reports, Settings, Tools and Help under Work
	 * (the owner, 2026-10-18, on the Phase 5 review).
	 */
	public static function headingHidden( string $group ): bool {
		return 'tail' === $group;
	}

	/** The capability a page is registered under: what opening it takes. */
	public static function capability( string $slug ): string {
		return in_array( $slug, self::MANAGER_PAGES, true )
			? Capabilities::CAP_MANAGE_SETTINGS
			: Capabilities::CAP_MANAGE_MONSTERA;
	}

	/**
	 * The shell pages the signed-in account is offered: each one's title,
	 * rail icon and, for a list, the one-line lead the page head shows
	 * beneath the title. The rail is drawn from this, so it never links to a
	 * page WordPress would refuse.
	 *
	 * @param bool $every List every page there is: those of modules that are off
	 *                    and those this account may not open. For a check that
	 *                    must hold whatever is switched on later and whoever asks.
	 * @return array<string, array{title:string, icon:string, lead?:string, group?:string}>
	 */
	public static function pages( bool $every = false ): array {
		$pages = self::all( $every );
		if ( ! $every && ! current_user_can( Capabilities::CAP_MANAGE_SETTINGS ) ) {
			$pages = array_diff_key( $pages, array_flip( self::MANAGER_PAGES ) );
		}
		return $pages;
	}

	/**
	 * Every shell page, whoever is looking, in the rail's order: the
	 * Dashboard, then each group's pages (GROUPS). WordPress's submenu is
	 * registered in this order too, so the folded menu and the rail agree.
	 *
	 * @param bool $includeInactive Also list the pages of modules that are off.
	 * @return array<string, array{title:string, icon:string, lead?:string, group?:string}>
	 */
	private static function all( bool $includeInactive ): array {
		$on = static fn ( string $module ): bool => $includeInactive || Modules::isActive( $module );
		// People: the always-on pages about who is in the program.
		$pages = [
			self::SLUG               => [
				'title' => __( 'Dashboard', 'monstera' ),
				'icon'  => 'home',
			],
			// The whole team reads it (People-model track, FR3); its writes are
			// a Team manager's, which the Team routes hold, not this list.
			'monstera-team'          => [
				'title' => __( 'Team', 'monstera' ),
				'icon'  => 'people',
				'lead'  => sprintf(
					/* translators: %s: the site's name */
					__( 'The people at %s who run the program, their role, and the organizations each one knows.', 'monstera' ),
					Audience::siteName()
				),
				'group' => 'people',
			],
			'monstera-organizations' => [
				'title' => __( 'Organizations', 'monstera' ),
				'icon'  => 'organization',
				'lead'  => __( 'Every client or member org, its tier, seats and renewal. Open one to manage its people and content.', 'monstera' ),
				'group' => 'people',
			],
			'monstera-members'       => [
				'title' => __( 'Members', 'monstera' ),
				'icon'  => 'people',
				'lead'  => __( 'Everyone with a portal login, the organizations they belong to, and when they were last here.', 'monstera' ),
				'group' => 'people',
			],
			'monstera-subgroups'     => [
				'title' => __( 'Sub-groups', 'monstera' ),
				'icon'  => 'subgroup',
				'lead'  => __( 'Committees, circles and teams inside an organization. A leader can publish to their group from the portal.', 'monstera' ),
				'group' => 'people',
			],
			// Work: what the program publishes and runs, Content always, the
			// rest with their modules.
			'monstera-content'       => [
				'title' => ContentPostType::label(),
				'icon'  => 'content',
				'lead'  => __( 'Documents, reports and files, and who can see each one. "Test visibility" answers "why can\'t they see this?" in one click.', 'monstera' ),
				'group' => 'work',
			],
		];
		if ( $on( Modules::PROJECTS ) ) {
			$pages['monstera-projects'] = [
				'title' => __( 'Projects', 'monstera' ),
				'icon'  => 'reports',
				'lead'  => __( 'Every project with a client, its stage and what\'s due. The stage is the pipeline clients see.', 'monstera' ),
				'group' => 'work',
			];
		}
		if ( $on( Modules::RESOURCES ) ) {
			$pages['monstera-resources'] = [
				'title' => __( 'Resources', 'monstera' ),
				'icon'  => 'resources',
				'lead'  => sprintf(
					/* translators: %s: what this site calls its content, e.g. "Content" or "Deliverables" */
					__( 'Links, files and guides members can pass around. Nothing here is confidential: a file is a Media Library upload, and a guide is a page. Anything gated belongs in %s.', 'monstera' ),
					ContentPostType::label()
				),
				'group' => 'work',
			];
		}
		if ( $on( Modules::FORMS ) ) {
			$pages['monstera-forms'] = [
				'title' => __( 'Forms', 'monstera' ),
				'icon'  => 'forms',
				'lead'  => __( 'Forms members fill in, built here or embedded from another plugin. Each submission is kept, emailed to the people you name, and readable by the organization\'s leads when the form is theirs.', 'monstera' ),
				'group' => 'work',
			];
		}
		if ( $on( Modules::ALERTS ) ) {
			$pages['monstera-alerts'] = [
				'title' => __( 'Alerts', 'monstera' ),
				'icon'  => 'bell',
				'lead'  => __( 'Banners at the top of every portal they\'re scoped to, with a severity and an expiry. Dismissing one posts a single note to activity.', 'monstera' ),
				'group' => 'work',
			];
		}
		if ( $on( Modules::SUPPORT ) ) {
			$pages['monstera-support'] = [
				'title' => __( 'Support', 'monstera' ),
				'icon'  => 'help',
				'lead'  => __( 'Requests from members, latest activity first. Reply from a request: the member gets it by email and on their request page.', 'monstera' ),
				'group' => 'work',
			];
		}

		// The tail, at the rail's foot: Reports with its module, then the
		// always-on pages.
		if ( $on( Modules::REPORTING ) ) {
			$pages['monstera-reports'] = [
				'title' => __( 'Reports', 'monstera' ),
				'icon'  => 'reports',
				'lead'  => __( 'The last seven days across every portal. Numbers count signed-in members only.', 'monstera' ),
				'group' => 'tail',
			];
		}
		$pages['monstera-settings'] = [
			'title' => __( 'Settings', 'monstera' ),
			'icon'  => 'settings',
			'group' => 'tail',
		];
		$pages['monstera-tools']    = [
			'title' => __( 'Tools', 'monstera' ),
			'icon'  => 'tools',
			'lead'  => __( 'Maintenance you might run by hand. Everything here also runs on a schedule.', 'monstera' ),
			'group' => 'tail',
		];
		$pages['monstera-help']     = [
			'title' => __( 'Help', 'monstera' ),
			'icon'  => 'help',
			'lead'  => __( 'Short answers to the questions that come up.', 'monstera' ),
			'group' => 'tail',
		];

		return $pages;
	}

	public static function register(): void {
		add_menu_page(
			__( 'Monstera', 'monstera' ),
			__( 'Monstera', 'monstera' ),
			Capabilities::CAP_MANAGE_MONSTERA,
			self::SLUG,
			[ self::class, 'renderShell' ],
			Icons::adminMenuDataUri(),
			26
		);

		// Every page is registered, each under its own capability, whoever is
		// signed in: WordPress then leaves out of the menu what the account
		// may not open and answers its address with its own refusal.
		foreach ( self::all( false ) as $slug => $page ) {
			add_submenu_page(
				self::SLUG,
				$page['title'],
				$page['title'],
				self::capability( $slug ),
				$slug,
				[ self::class, 'renderShell' ]
			);
		}

		// Drop the duplicate "Monstera" submenu link WP auto-creates.
		global $submenu;
		if ( isset( $submenu[ self::SLUG ] ) ) {
			foreach ( $submenu[ self::SLUG ] as $i => $row ) {
				if ( self::SLUG === ( $row[2] ?? '' ) && __( 'Monstera', 'monstera' ) === ( $row[0] ?? '' ) ) {
					unset( $submenu[ self::SLUG ][ $i ] );
					break;
				}
			}
			$submenu[ self::SLUG ] = array_values( $submenu[ self::SLUG ] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- re-indexing WordPress's own submenu registry is how entries are reordered.
		}
	}

	public static function renderShell(): void {
		Shell::render();
	}
}
