<?php
declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Content\PostType as ContentPostType;
use Monstera\Core\Capabilities;
use Monstera\Core\Icons;
use Monstera\Core\Modules;

final class Menu {

	public const SLUG = 'monstera';

	/**
	 * Every shell page: its title, rail icon and, for a list, the one-line
	 * lead the page head shows beneath the title.
	 *
	 * @param bool $includeInactive Also list the pages of modules that are off,
	 *                              for a check that must hold whatever is switched on later.
	 * @return array<string, array{title:string, icon:string, lead?:string, position?:int}>
	 */
	public static function pages( bool $includeInactive = false ): array {
		$on = static fn ( string $module ): bool => $includeInactive || Modules::isActive( $module );
		// Always-on items: dashboard, orgs, members, content, sub-groups.
		// These map to the always-loaded core modules.
		$pages = [
			self::SLUG               => [
				'title' => __( 'Dashboard', 'monstera' ),
				'icon'  => 'home',
			],
			'monstera-organizations' => [
				'title' => __( 'Organizations', 'monstera' ),
				'icon'  => 'organization',
				'lead'  => __( 'Every client or member org, its tier, seats and renewal. Open one to manage its people and content.', 'monstera' ),
			],
			'monstera-members'       => [
				'title' => __( 'Members', 'monstera' ),
				'icon'  => 'people',
				'lead'  => __( 'Everyone with a portal login, the organization they belong to, and when they were last here.', 'monstera' ),
			],
			'monstera-content'       => [
				'title' => ContentPostType::label(),
				'icon'  => 'content',
				'lead'  => __( 'Documents, reports and files, and who can see each one. "Test visibility" answers "why can\'t they see this?" in one click.', 'monstera' ),
			],
			'monstera-subgroups'     => [
				'title' => __( 'Sub-groups', 'monstera' ),
				'icon'  => 'subgroup',
				'lead'  => __( 'Committees, circles and teams inside an organization. A leader can publish to their group from the portal.', 'monstera' ),
			],
		];

		// Module-gated items.
		if ( $on( Modules::PROJECTS ) ) {
			$pages['monstera-projects'] = [
				'title' => __( 'Projects', 'monstera' ),
				'icon'  => 'reports',
				'lead'  => __( 'Every project with a client, its stage and what\'s due. The stage is the pipeline clients see.', 'monstera' ),
			];
		}
		if ( $on( Modules::FORMS ) ) {
			$pages['monstera-forms'] = [
				'title' => __( 'Forms', 'monstera' ),
				'icon'  => 'forms',
				'lead'  => sprintf(
					/* translators: %s: what this site calls its content, e.g. "Content" or "Deliverables" */
					__( 'Low-sensitivity links and PDFs that members can pass around. Anything confidential belongs in %s instead.', 'monstera' ),
					ContentPostType::label()
				),
			];
		}
		if ( $on( Modules::ALERTS ) ) {
			$pages['monstera-alerts'] = [
				'title' => __( 'Alerts', 'monstera' ),
				'icon'  => 'bell',
				'lead'  => __( 'Banners at the top of every portal they\'re scoped to, with a severity and an expiry. Dismissing one posts a single note to activity.', 'monstera' ),
			];
		}
		if ( $on( Modules::SUPPORT ) ) {
			$pages['monstera-support'] = [
				'title' => __( 'Support', 'monstera' ),
				'icon'  => 'help',
				'lead'  => __( 'Requests from members, newest first. Replies go by email and appear in the member\'s portal under the reference.', 'monstera' ),
			];
		}
		if ( $on( Modules::REPORTING ) ) {
			$pages['monstera-reports'] = [
				'title' => __( 'Reports', 'monstera' ),
				'icon'  => 'reports',
				'lead'  => __( 'The last seven days across every portal. Numbers count signed-in members only.', 'monstera' ),
			];
		}

		// Always-on tail.
		$pages['monstera-settings'] = [
			'title' => __( 'Settings', 'monstera' ),
			'icon'  => 'settings',
		];
		$pages['monstera-tools']    = [
			'title' => __( 'Tools', 'monstera' ),
			'icon'  => 'tools',
			'lead'  => __( 'Maintenance you might run by hand. Everything here also runs on a schedule.', 'monstera' ),
		];
		$pages['monstera-help']     = [
			'title' => __( 'Help', 'monstera' ),
			'icon'  => 'help',
			'lead'  => __( 'Short answers to the questions that come up.', 'monstera' ),
		];

		return $pages;
	}

	public static function register(): void {
		add_menu_page(
			__( 'Monstera', 'monstera' ),
			__( 'Monstera', 'monstera' ),
			Capabilities::CAP_MANAGE_MONSTERA,
			self::SLUG,
			[ self::class, 'renderShell' ],
			Icons::adminMenuDataUri(),
			26
		);

		foreach ( self::pages() as $slug => $page ) {
			add_submenu_page(
				self::SLUG,
				$page['title'],
				$page['title'],
				Capabilities::CAP_MANAGE_MONSTERA,
				$slug,
				[ self::class, 'renderShell' ]
			);
		}

		// Drop the duplicate "Monstera" submenu link WP auto-creates.
		global $submenu;
		if ( isset( $submenu[ self::SLUG ] ) ) {
			foreach ( $submenu[ self::SLUG ] as $i => $row ) {
				if ( self::SLUG === ( $row[2] ?? '' ) && __( 'Monstera', 'monstera' ) === ( $row[0] ?? '' ) ) {
					unset( $submenu[ self::SLUG ][ $i ] );
					break;
				}
			}
			$submenu[ self::SLUG ] = array_values( $submenu[ self::SLUG ] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- re-indexing WordPress's own submenu registry is how entries are reordered.
		}
	}

	public static function renderShell(): void {
		Shell::render();
	}
}
