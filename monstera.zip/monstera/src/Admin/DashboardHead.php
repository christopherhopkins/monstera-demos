<?php
declare(strict_types=1);

namespace Monstera\Admin;

use Monstera\Core\Capabilities;
use Monstera\Core\Modules;
use Monstera\Organizations\PostType as OrgPostType;
use WP_User;
use WP_User_Query;

defined( 'ABSPATH' ) || exit;

/**
 * The dashboard's head (comp 90): a greeting by the time of day with the
 * date beneath it, then the program's counts as a line of links, rendered by
 * the shell above the page so it is there before the app loads.
 */
final class DashboardHead {

	/** "Good morning, Avery." in the site's timezone. */
	public static function greeting( WP_User $user, ?int $now = null ): string {
		$hour = (int) wp_date( 'G', $now ?? time() );
		$name = '' !== trim( (string) $user->first_name ) ? trim( (string) $user->first_name ) : (string) $user->display_name;
		return match ( true ) {
			/* translators: %s: the admin's first name */
			$hour < 12 => sprintf( __( 'Good morning, %s.', 'monstera' ), $name ),
			/* translators: %s: the admin's first name */
			$hour < 18 => sprintf( __( 'Good afternoon, %s.', 'monstera' ), $name ),
			/* translators: %s: the admin's first name */
			default    => sprintf( __( 'Good evening, %s.', 'monstera' ), $name ),
		};
	}

	/**
	 * Published organizations, people with a portal role, and projects in
	 * flight (null while the Projects module is off).
	 *
	 * @return array{organizations: int, members: int, projects: int|null}
	 */
	public static function counts(): array {
		$members = new WP_User_Query(
			[
				'role__in'    => [ Capabilities::ROLE_MEMBER, Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER_STANDALONE ],
				'fields'      => 'ID',
				'number'      => 1,
				'count_total' => true,
			]
		);
		return [
			'organizations' => (int) ( wp_count_posts( OrgPostType::SLUG )->publish ?? 0 ),
			'members'       => (int) $members->get_total(),
			'projects'      => Modules::isActive( Modules::PROJECTS ) ? RailCounts::projectsInFlight() : null,
		];
	}

	/** "Monday, September 21." in the site's timezone. */
	public static function date( ?int $now = null ): string {
		return sprintf(
			/* translators: %s: today's date, e.g. "Monday, September 21" */
			__( '%s.', 'monstera' ),
			wp_date( __( 'l, F j', 'monstera' ), $now ?? time() )
		);
	}

	/**
	 * The program at a glance, each count a link to its list: organizations,
	 * members and, with the module on, projects in flight. A line of its own
	 * beneath the date, so it never reads as part of the greeting.
	 *
	 * @return array<string, array{label: string, url: string}>
	 */
	public static function facts(): array {
		$counts = self::counts();
		$facts  = [
			'organizations' => [
				/* translators: %d: number of organizations */
				'label' => sprintf( _n( '%d organization', '%d organizations', $counts['organizations'], 'monstera' ), $counts['organizations'] ),
				'url'   => admin_url( 'admin.php?page=monstera-organizations' ),
			],
			'members'       => [
				/* translators: %d: number of members */
				'label' => sprintf( _n( '%d member', '%d members', $counts['members'], 'monstera' ), $counts['members'] ),
				'url'   => admin_url( 'admin.php?page=monstera-members' ),
			],
		];
		if ( null !== $counts['projects'] ) {
			$facts['projects'] = [
				/* translators: %d: number of projects in Discovery, In progress or Review */
				'label' => sprintf( _n( '%d project in flight', '%d projects in flight', $counts['projects'], 'monstera' ), $counts['projects'] ),
				'url'   => admin_url( 'admin.php?page=monstera-projects' ),
			];
		}
		return $facts;
	}
}
