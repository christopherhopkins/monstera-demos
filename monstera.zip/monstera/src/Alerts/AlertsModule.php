<?php
declare(strict_types=1);

namespace Monstera\Alerts;

use Monstera\BackgroundSync\Cron;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Module;

final class AlertsModule implements Module {

	public function slug(): string {
		return 'alerts';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		add_action( 'transition_post_status', [ $this, 'onTransition' ], 10, 3 );

		// Daily housekeeping: auto-archive expired alerts.
		add_action( Cron::DAILY_PURGE, [ self::class, 'archiveExpired' ] );
	}

	public function registerPostTypes(): void {
		PostType::register();
	}

	public function onTransition( string $newStatus, string $oldStatus, \WP_Post $post ): void {
		if ( PostType::SLUG !== $post->post_type ) {
			return;
		}
		if ( 'publish' !== $newStatus || 'publish' === $oldStatus ) {
			return;
		}
		// The first post is remembered: it is the one that emails, and the
		// composer says when it happened and who did it. Posting an ended
		// alert again brings it back.
		$first = '' === (string) get_post_meta( $post->ID, Meta::KEY_POSTED_AT, true );
		if ( $first ) {
			update_post_meta( $post->ID, Meta::KEY_POSTED_AT, current_time( 'mysql', true ) );
			update_post_meta( $post->ID, Meta::KEY_POSTED_BY, get_current_user_id() ?: (int) $post->post_author );
		}
		delete_post_meta( $post->ID, Meta::KEY_ENDED_AT );
		if ( ! $first ) {
			// Posted again: it returns for the members who dismissed it before.
			global $wpdb;
			$wpdb->delete( Schema::tableName( Schema::TABLE_ALERT_DISMISSALS ), [ 'alert_id' => $post->ID ], [ '%d' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Monstera's own table.
		}
		do_action( Hooks::ALERT_POSTED, $post->ID, $first );
	}

	/**
	 * Takes down live alerts whose expiry, in the site's timezone, has passed.
	 */
	public static function archiveExpired(): void {
		$query = new \WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- live alerts with an expiry, a handful.
					[
						'key'     => Meta::KEY_EXPIRES_AT,
						'value'   => '',
						'compare' => '!=',
					],
				],
			]
		);
		foreach ( $query->posts as $id ) {
			if ( ! Expiry::hasPassed( (string) get_post_meta( (int) $id, Meta::KEY_EXPIRES_AT, true ) ) ) {
				continue;
			}
			wp_update_post(
				[
					'ID'          => $id,
					'post_status' => 'draft',
				]
			);
			do_action( Hooks::ALERT_EXPIRED, (int) $id );
		}
	}
}
