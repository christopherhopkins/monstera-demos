<?php
declare(strict_types=1);

namespace Monstera\Alerts;

use Monstera\Core\Capabilities;

final class PostType {

	public const SLUG = 'monstera_alert';

	public static function register(): void {
		register_post_type(
			self::SLUG,
			[
				'labels'          => [
					'name'          => __( 'Alerts', 'monstera' ),
					'singular_name' => __( 'Alert', 'monstera' ),
					'add_new'       => __( 'Post alert', 'monstera' ),
					'add_new_item'  => __( 'Post alert', 'monstera' ),
					'edit_item'     => __( 'Edit alert', 'monstera' ),
					'search_items'  => __( 'Search alerts', 'monstera' ),
					'not_found'     => __( 'No alerts. Quiet day.', 'monstera' ),
				],
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				'show_in_rest'    => true,
				'rest_base'       => 'alerts',
				'supports'        => [ 'title', 'editor', 'excerpt' ],
				'has_archive'     => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'capabilities'    => [
					'edit_posts'         => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'  => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}
}
