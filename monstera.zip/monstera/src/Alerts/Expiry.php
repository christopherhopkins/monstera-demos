<?php
declare(strict_types=1);

namespace Monstera\Alerts;

use DateTimeImmutable;

/**
 * An alert's expiry, kept as the site's local time ('Y-m-d H:i:s').
 *
 * The composer's date field has no timezone, and the person filling it in
 * means the site's clock, so the value is read and stored in the site's
 * timezone. Every reader goes through here, so none compares it as UTC.
 */
final class Expiry {

	/**
	 * A date field's value ('2026-10-01T09:00') as stored, or '' when it is
	 * empty or not a date. A value that names its own offset is converted.
	 */
	public static function fromInput( string $value ): string {
		$at = self::parse( $value );
		return $at ? $at->format( 'Y-m-d H:i:s' ) : '';
	}

	/** The stored value for a datetime-local field ('Y-m-d\TH:i'), or ''. */
	public static function forInput( string $stored ): string {
		$at = self::parse( $stored );
		return $at ? $at->format( 'Y-m-d\TH:i' ) : '';
	}

	/** The stored value as a Unix timestamp, or null when there is none. */
	public static function timestamp( string $stored ): ?int {
		$at = self::parse( $stored );
		return $at ? $at->getTimestamp() : null;
	}

	/** Whether the expiry has passed. An alert without one never expires. */
	public static function hasPassed( string $stored ): bool {
		$at = self::timestamp( $stored );
		return null !== $at && $at <= time();
	}

	private static function parse( string $value ): ?DateTimeImmutable {
		$value = trim( $value );
		if ( '' === $value ) {
			return null;
		}
		try {
			$at = new DateTimeImmutable( $value, wp_timezone() );
		} catch ( \Exception ) {
			return null;
		}
		return $at->setTimezone( wp_timezone() );
	}
}
