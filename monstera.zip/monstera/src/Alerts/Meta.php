<?php
declare(strict_types=1);

namespace Monstera\Alerts;

defined( 'ABSPATH' ) || exit;

final class Meta {

	public const SEVERITY_INFO     = 'info';
	public const SEVERITY_WARNING  = 'warning';
	public const SEVERITY_CRITICAL = 'critical';

	public const SCOPE_ALL     = 'all';
	public const SCOPE_ORG     = 'org';
	public const SCOPE_PROJECT = 'project';

	public const KEY_SEVERITY              = 'monstera_alert_severity';
	public const KEY_SCOPE                 = 'monstera_alert_scope';
	public const KEY_SCOPE_IDS             = 'monstera_alert_scope_ids';
	public const KEY_AUDIENCE_ALL          = 'monstera_alert_audience_all';
	public const KEY_ORG_IDS               = 'monstera_alert_audience_org_ids';
	public const KEY_STANDALONE_MEMBER_IDS = 'monstera_alert_audience_standalone_ids';
	public const KEY_SUBGROUP_IDS          = 'monstera_alert_audience_subgroup_ids';
	public const KEY_EXPIRES_AT            = 'monstera_alert_expires_at';
	public const KEY_LINK_URL              = 'monstera_alert_link_url';
	public const KEY_LINK_LABEL            = 'monstera_alert_link_label';
	public const KEY_DISMISSIBLE           = 'monstera_alert_dismissible';
	public const KEY_NOTIFY_BY_EMAIL       = 'monstera_alert_notify_email';

	// Written by the plugin, never by the composer: when and by whom the alert
	// was first posted (UTC), how many emails that post sent, and when it was
	// ended for everyone (UTC).
	public const KEY_POSTED_AT  = 'monstera_alert_posted_at';
	public const KEY_POSTED_BY  = 'monstera_alert_posted_by';
	public const KEY_EMAIL_SENT = 'monstera_alert_email_sent';
	public const KEY_ENDED_AT   = 'monstera_alert_ended_at';

	public static function severityLabel( string $severity ): string {
		return match ( $severity ) {
			self::SEVERITY_INFO     => __( 'Info', 'monstera' ),
			self::SEVERITY_WARNING  => __( 'Warning', 'monstera' ),
			self::SEVERITY_CRITICAL => __( 'Critical', 'monstera' ),
			default                 => ucfirst( $severity ),
		};
	}

	/** Where a severity sorts for members: critical first, info last. */
	public static function severityRank( string $severity ): int {
		return match ( $severity ) {
			self::SEVERITY_CRITICAL => 0,
			self::SEVERITY_WARNING  => 1,
			default                 => 2,
		};
	}

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_SEVERITY,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::SEVERITY_INFO,
				'show_in_rest'      => [
					'schema' => [ 'enum' => [ self::SEVERITY_INFO, self::SEVERITY_WARNING, self::SEVERITY_CRITICAL ] ],
				],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ self::SEVERITY_INFO, self::SEVERITY_WARNING, self::SEVERITY_CRITICAL ], true ) ? $v : self::SEVERITY_INFO,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SCOPE,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::SCOPE_ALL,
				'show_in_rest'      => [ 'schema' => [ 'enum' => [ self::SCOPE_ALL, self::SCOPE_ORG, self::SCOPE_PROJECT ] ] ],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ self::SCOPE_ALL, self::SCOPE_ORG, self::SCOPE_PROJECT ], true ) ? $v : self::SCOPE_ALL,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SCOPE_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_AUDIENCE_ALL,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => true,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ORG_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBER_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SUBGROUP_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_EXPIRES_AT,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_LINK_URL,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'esc_url_raw',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_LINK_LABEL,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_DISMISSIBLE,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => true,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_NOTIFY_BY_EMAIL,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => false,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);
	}
}
