<?php
declare(strict_types=1);

namespace Monstera\Alerts;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;
use WP_Query;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Repository {

	/** The roles "everyone" reaches. */
	private const MEMBER_ROLES = [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ];

	/**
	 * Active, non-dismissed alerts visible to a user: critical first, then
	 * warnings, then info, newest first within each. Every live alert is
	 * read (they are few, and expired ones are archived daily), so an older
	 * critical one is never cut for a newer notice.
	 *
	 * An ended membership gives way beside one still running (People-model
	 * track, FR5; the Phase 5 task), as it does on the dashboard: an alert
	 * that reaches the person through ended organizations alone is not in
	 * front of them, so the band leaves it out on every page and the
	 * dismiss route does not know it. One that a running organization of
	 * theirs is named in too, one for everyone and one that names the
	 * person stay. Organizations\Reach says which organizations are held
	 * back (a person in one organization's as much as a person in several's;
	 * none for staff).
	 *
	 * An alert reaches a person through the organizations of theirs it
	 * names and through the sub-groups it names that they are in. A
	 * sub-group they are not in brings them nothing, so an alert for an
	 * ended organization's group and a running one's is left out for
	 * someone who sits in the ended one's alone.
	 *
	 * None for an account the portal is not for (the site's subscriber, an
	 * invitation that was ended before it was ever used:
	 * AccessControl\PortalGuard::isPortalAccount()). The band sits above
	 * every page, the one that turns such an account away included, and an
	 * alert "for everyone" is for every member, which it is not.
	 *
	 * @return WP_Post[]
	 */
	public function visibleTo( WP_User $user ): array {
		if ( ! PortalGuard::isPortalAccount( $user ) ) {
			return [];
		}
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => [ 'date' => 'DESC' ],
				'no_found_rows'  => true,
			]
		);

		// An organization in the trash grants nothing (OrgRepository::onSite()).
		$out             = [];
		$orgIds          = OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		$dismissedIds    = $this->dismissedIdsFor( $user->ID );
		$memberProjects  = ProjectRepository::ofOrgsOnSite( ( new ProjectRepository() )->projectsForMember( $user->ID ) );
		$memberSubgroups = ( new SubgroupRepository() )->publishedSubgroupsForMember( $user->ID );
		$heldBack        = Reach::heldBackFor( $user );
		if ( $heldBack ) {
			// Each alert is about to be asked which organizations bring it, its
			// sub-groups' parents among them: those are read together, the
			// band being on every page.
			Reach::primeParents( $query->posts, Meta::KEY_SUBGROUP_IDS, $memberSubgroups );
		}

		foreach ( $query->posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			if ( in_array( $post->ID, $dismissedIds, true ) ) {
				continue;
			}
			if ( Expiry::hasPassed( (string) get_post_meta( $post->ID, Meta::KEY_EXPIRES_AT, true ) ) ) {
				continue;
			}

			if ( $this->reaches( (int) $post->ID, $user, $orgIds, $memberSubgroups, $heldBack, $memberProjects ) ) {
				$out[] = $post;
			}
		}
		// usort is stable, so each severity keeps the query's newest-first order.
		usort(
			$out,
			static fn ( WP_Post $a, WP_Post $b ): int => Meta::severityRank( (string) get_post_meta( $a->ID, Meta::KEY_SEVERITY, true ) )
				<=> Meta::severityRank( (string) get_post_meta( $b->ID, Meta::KEY_SEVERITY, true ) )
		);
		return $out;
	}

	/**
	 * Whether one alert reaches one person: the decision the band
	 * (visibleTo()), the "Resolved" notes (endedFor()) and the alert's email
	 * (reachesPerson()) share, so none of them can say an alert is in front
	 * of someone another keeps it from. Whether it was dismissed or has
	 * expired is the band's own to ask.
	 *
	 * New audience model: explicit "everyone" flag, or org/standalone-member
	 * lists. Whether the keys were ever written decides it, not what they
	 * hold: "everyone" stored as off with nothing chosen reaches nobody.
	 * Only an alert that never had them falls back to the legacy scope.
	 * Either way an ended membership then holds back what reaches the
	 * person through it alone (Organizations\Reach::heldBackFor()). A
	 * standalone member reaches every alert through their own membership,
	 * the one for everyone as much as one that names them, so once it has
	 * ended (AccessControl\PortalGuard::ownMembershipExpired()) none does.
	 *
	 * @param int[]      $orgIds          The person's organizations.
	 * @param int[]      $memberSubgroups The sub-groups they are in; those among the alert's are enough.
	 * @param list<int>  $heldBack        What Organizations\Reach::heldBackFor() answered for them.
	 * @param int[]|null $memberProjects  The projects they are on, which only a legacy scope asks about; read here when null and needed.
	 */
	private function reaches( int $alertId, WP_User $user, array $orgIds, array $memberSubgroups, array $heldBack, ?array $memberProjects = null ): bool {
		if ( PortalGuard::ownMembershipExpired( $user ) ) {
			return false;
		}
		$userId = (int) $user->ID;
		// Every organization of theirs is in the trash: a member of none on
		// the site, an alert reaches them by name alone (the fix's review, 2026-10-19).
		if ( ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) && OrgRepository::belongsToNoneOnSite( $userId ) ) {
			return self::hasAudience( $alertId ) && in_array( $userId, self::audienceOf( $alertId )['member_ids'], true );
		}
		if ( self::hasAudience( $alertId ) ) {
			$stored = self::audienceOf( $alertId );
			return self::includes( $stored, $userId, $orgIds, $memberSubgroups ) && ! self::onlyThroughEnded( $stored, $userId, $heldBack, $memberSubgroups );
		}

		$memberProjects ??= ProjectRepository::ofOrgsOnSite( ( new ProjectRepository() )->projectsForMember( $userId ) );
		$scope            = (string) ( get_post_meta( $alertId, Meta::KEY_SCOPE, true ) ?: Meta::SCOPE_ALL );
		$scopeIds         = array_map( 'intval', (array) get_post_meta( $alertId, Meta::KEY_SCOPE_IDS, true ) );

		$audience = apply_filters(
			Hooks::FILTER_ALERT_AUDIENCE,
			[
				'scope'         => $scope,
				'scope_ids'     => $scopeIds,
				'user_id'       => $userId,
				'user_orgs'     => $orgIds,
				// For filters written when a person had one organization: their
				// primary one, of those on the site as user_orgs are.
				'user_org'      => OrgRepository::primaryOnSite( $userId ),
				'user_projects' => $memberProjects,
			],
			$alertId
		);

		$matches = match ( $audience['scope'] ) {
			Meta::SCOPE_ALL     => true,
			Meta::SCOPE_ORG     => [] !== array_intersect( $orgIds, $audience['scope_ids'] ),
			Meta::SCOPE_PROJECT => (bool) array_intersect( $memberProjects, $audience['scope_ids'] ),
			default             => false,
		};
		if ( ! $matches || ! $heldBack ) {
			return $matches;
		}
		// The old scopes are held back as the new lists are: one that names
		// organizations through those, and one that names projects through
		// the organizations of the projects the person is on, which the
		// projects list leaves out too.
		$through = match ( $audience['scope'] ) {
			Meta::SCOPE_ORG     => (array) $audience['scope_ids'],
			Meta::SCOPE_PROJECT => array_map(
				static fn ( $projectId ): int => (int) get_post_meta( (int) $projectId, ProjectMeta::KEY_ORG_ID, true ),
				array_intersect( $memberProjects, (array) $audience['scope_ids'] )
			),
			default             => [],
		};
		return ! Reach::onlyThrough( $userId, $through, $heldBack );
	}

	/**
	 * Whether an alert reaches this person as the band would show it,
	 * whatever they have dismissed: asked by the dispatcher before it
	 * writes to them, since the email says the alert is at the top of their
	 * portal. An alert an ended membership holds back is not, so its email
	 * does not go either.
	 *
	 * @param int[]|null $memberSubgroups The sub-groups the person is in, when the caller has them; those among the alert's are enough. Read here when null.
	 */
	public function reachesPerson( WP_User $user, int $alertId, ?array $memberSubgroups = null ): bool {
		$memberSubgroups ??= ( new SubgroupRepository() )->publishedSubgroupsForMember( (int) $user->ID );
		return $this->reaches( $alertId, $user, OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) ), $memberSubgroups, Reach::heldBackFor( $user ) );
	}

	/**
	 * The sub-groups an alert names that each of their members is in, by
	 * member: what reachesPerson() and Reach::ofAlert() need of a person's
	 * sub-groups, for everyone an email batch writes to, from one read per
	 * sub-group named and none per person.
	 *
	 * @return array<int, list<int>> Sub-group ids by user id; someone in none of them is absent.
	 */
	public static function namedSubgroupsByMember( int $alertId ): array {
		$subgroups = new SubgroupRepository();
		$out       = [];
		// Only a published sub-group lets its members through (the owner's
		// call, 2026-10-18), and none of an organization in the trash (the
		// fix's review, 2026-10-19).
		foreach ( SubgroupRepository::ofOrgsOnSite( SubgroupRepository::published( self::audienceOf( $alertId )['subgroup_ids'] ) ) as $subgroupId ) {
			foreach ( $subgroups->memberIds( (int) $subgroupId ) as $memberId ) {
				$out[ $memberId ][] = (int) $subgroupId;
			}
		}
		return $out;
	}

	/**
	 * Alerts ended for everyone in the last $days days whose audience
	 * included this member: the "Resolved" notes. The dashboard's rail
	 * prints them, in a block of their own since its first block became the
	 * reader's own acts (Portal\OwnActivity), which an alert's end is not.
	 * One an ended membership held back was never in front of them, so it
	 * is not resolved for them either. Whose audience it was is the band's
	 * own decision (reaches()), an alert still on the old scope included:
	 * an alert the band never showed someone is not "Resolved" for them.
	 *
	 * @return WP_Post[]
	 */
	public function endedFor( WP_User $user, int $days = 14 ): array {
		$query     = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'draft',
				// Every alert ended in the window (a handful): the member's own
				// must not be cut by others' before the audience is checked.
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'meta_key'       => Meta::KEY_ENDED_AT, // phpcs:ignore WordPress.DB.SlowDBQuery -- a handful of alerts, ordered by when they ended.
				'orderby'        => 'meta_value',
				'order'          => 'DESC',
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- as above.
					[
						'key'     => Meta::KEY_ENDED_AT,
						'value'   => gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ),
						'compare' => '>=',
						'type'    => 'DATETIME',
					],
				],
			]
		);
		$orgIds    = OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		$subgroups = ( new SubgroupRepository() )->publishedSubgroupsForMember( $user->ID );
		$heldBack  = Reach::heldBackFor( $user );
		if ( $heldBack ) {
			// As in visibleTo(): the sub-groups' parents are read together.
			Reach::primeParents( $query->posts, Meta::KEY_SUBGROUP_IDS, $subgroups );
		}
		// Asked only if an alert in the window is still on the old scope.
		$projects = null;
		return array_slice(
			array_values(
				array_filter(
					$query->posts,
					// What was never in front of them (visibleTo()) is not "Resolved" for them either.
					function ( $post ) use ( $user, $orgIds, $subgroups, $heldBack, &$projects ): bool {
						if ( ! $post instanceof WP_Post ) {
							return false;
						}
						if ( null === $projects && ! self::hasAudience( $post->ID ) ) {
							$projects = ProjectRepository::ofOrgsOnSite( ( new ProjectRepository() )->projectsForMember( (int) $user->ID ) );
						}
						return $this->reaches( (int) $post->ID, $user, $orgIds, $subgroups, $heldBack, $projects );
					}
				)
			),
			0,
			20
		);
	}

	/**
	 * Whether an audience reaches the person through ended organizations
	 * alone: those of theirs it names, and the parents of the sub-groups it
	 * names that they are in. An alert for everyone and one that names the
	 * person reach them through no organization, so no ended membership
	 * takes those away.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @param list<int>                                                                $heldBack        What Organizations\Reach::heldBackFor() answered.
	 * @param int[]                                                                    $memberSubgroups The sub-groups the person is in.
	 */
	private static function onlyThroughEnded( array $audience, int $userId, array $heldBack, array $memberSubgroups ): bool {
		if ( ! $heldBack || $audience['all'] || in_array( $userId, $audience['member_ids'], true ) ) {
			return false;
		}
		return Reach::onlyThrough( $userId, Reach::audienceOrgs( $audience, $memberSubgroups ), $heldBack );
	}

	/** Whether the alert carries the audience keys at all (see visibleTo()). */
	public static function hasAudience( int $alertId ): bool {
		foreach ( [ Meta::KEY_AUDIENCE_ALL, Meta::KEY_ORG_IDS, Meta::KEY_STANDALONE_MEMBER_IDS, Meta::KEY_SUBGROUP_IDS ] as $key ) {
			if ( metadata_exists( 'post', $alertId, $key ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether an audience names nobody: not everyone, and no organization,
	 * member or sub-group.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 */
	public static function isEmpty( array $audience ): bool {
		return ! $audience['all'] && ! $audience['org_ids'] && ! $audience['member_ids'] && ! $audience['subgroup_ids'];
	}

	/**
	 * An alert's audience as stored.
	 *
	 * @return array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]}
	 */
	public static function audienceOf( int $alertId ): array {
		$ids = static fn ( string $key ): array => array_values( array_filter( array_map( 'intval', (array) get_post_meta( $alertId, $key, true ) ) ) );
		return [
			// An alert that never had the keys predates them, and is for everyone.
			'all'          => ! self::hasAudience( $alertId ) || (bool) get_post_meta( $alertId, Meta::KEY_AUDIENCE_ALL, true ),
			'org_ids'      => $ids( Meta::KEY_ORG_IDS ),
			'member_ids'   => $ids( Meta::KEY_STANDALONE_MEMBER_IDS ),
			'subgroup_ids' => $ids( Meta::KEY_SUBGROUP_IDS ),
		];
	}

	/**
	 * Whether an audience includes one person, who may belong to several
	 * organizations: any of theirs in the audience is a match (People-model
	 * track, FR8). Sub-group scoping narrows an org match when both are
	 * named: a leader's alert targets [org] + [sub-group], so a member must
	 * be in both. When only sub-groups are named, the sub-group is itself
	 * the audience (rather than reaching nobody). The person's sub-groups are
	 * the published ones they are in (Subgroups\Repository::
	 * publishedSubgroupsForMember()): one deleted or in the trash lets
	 * nobody through.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @param int[]                                                                    $orgIds          The person's organizations.
	 * @param int[]                                                                    $memberSubgroups
	 */
	public static function includes( array $audience, int $userId, array $orgIds, array $memberSubgroups ): bool {
		if ( $audience['all'] ) {
			return true;
		}
		$orgMatch = [] !== array_intersect( $orgIds, $audience['org_ids'] );
		if ( $audience['subgroup_ids'] ) {
			$sgMatch  = (bool) array_intersect( $audience['subgroup_ids'], $memberSubgroups );
			$orgMatch = $audience['org_ids'] ? ( $orgMatch && $sgMatch ) : $sgMatch;
		}
		return $orgMatch || in_array( $userId, $audience['member_ids'], true );
	}

	/**
	 * The members an audience reaches, as user ids. Everyone means every
	 * member, in an organization or standalone; Monstera admins are staff,
	 * not the audience. The same rule as includes(), worked in sets so it
	 * costs a query per list, not one per person: with organizations and
	 * sub-groups both named a member must be in both; sub-groups alone are
	 * the audience; named members always are. An organization's people come
	 * from the memberships table, and a person in two of them is listed once.
	 * An organization in the trash, and its sub-groups, bring nobody, and
	 * everyone leaves out a person whose organizations are all there, as
	 * reaches() does.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @return int[]
	 */
	public function recipientIds( array $audience ): array {
		$ids = static fn ( array $args ): array => array_map(
			'intval',
			(array) get_users(
				$args + [
					'fields' => 'ID',
					'number' => -1,
				]
			)
		);
		if ( $audience['all'] ) {
			// Every member but one whose organizations are all in the trash: a
			// member of none on the site, whom an alert reaches by name alone
			// (reaches()), so one it names stays. Everyone's memberships, and
			// those organizations, are read together.
			$everyone = $ids( [ 'role__in' => self::MEMBER_ROLES ] );
			Roster::prime( $everyone );
			$memberships = [];
			foreach ( $everyone as $userId ) {
				$memberships[ $userId ] = Roster::orgIdsOf( $userId );
			}
			$onSite = array_flip( OrgRepository::onSite( array_merge( [], ...array_values( $memberships ) ) ) );
			$named  = array_flip( array_map( 'intval', $audience['member_ids'] ) );
			return array_values(
				array_filter(
					$everyone,
					static fn ( int $userId ): bool => [] === $memberships[ $userId ]
						|| [] !== array_intersect_key( array_flip( $memberships[ $userId ] ), $onSite )
						|| isset( $named[ $userId ] )
				)
			);
		}

		// Named members who still have an account.
		$named = $audience['member_ids'] ? $ids( [ 'include' => array_values( $audience['member_ids'] ) ] ) : [];

		// Only a published sub-group lets its members through: one deleted or
		// in the trash still narrows the audience, to nobody (the owner's
		// call, 2026-10-18), and so does one of an organization in the trash,
		// as an organization in the trash brings nobody (the review of the
		// At-a-glance track, 2026-10-19).
		$inGroups  = [];
		$subgroups = new SubgroupRepository();
		foreach ( SubgroupRepository::ofOrgsOnSite( SubgroupRepository::published( $audience['subgroup_ids'] ) ) as $subgroupId ) {
			$inGroups = array_merge( $inGroups, $subgroups->memberIds( (int) $subgroupId ) );
		}
		$reached = $inGroups;
		if ( $audience['org_ids'] ) {
			$inOrgs = [];
			$orgIds = OrgRepository::onSite( $audience['org_ids'] );
			Roster::primeOrgs( $orgIds );
			foreach ( $orgIds as $orgId ) {
				$inOrgs = array_merge( $inOrgs, Roster::memberIds( $orgId ) );
			}
			// One user query for the union: a membership whose account has gone
			// (RelationshipSync drops it daily) is not a recipient. An empty
			// include would answer with everyone, so none is asked.
			$inOrgs  = $inOrgs ? $ids( [ 'include' => array_values( array_unique( $inOrgs ) ) ] ) : [];
			$reached = $audience['subgroup_ids'] ? array_intersect( $inOrgs, $inGroups ) : $inOrgs;
		}
		return array_values( array_unique( array_map( 'intval', array_merge( $reached, $named ) ) ) );
	}

	/**
	 * How far an audience reaches, for the composer's save bar: the
	 * organizations it names (or every organization, or the sub-groups'
	 * organizations when only sub-groups are named) and the members it
	 * reaches. An organization in the trash is counted in neither
	 * (OrgRepository::onSite()).
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @return array{organizations: int, members: int}
	 */
	public function reach( array $audience ): array {
		if ( $audience['all'] ) {
			$organizations = OrgRepository::countOnSite();
		} elseif ( $audience['org_ids'] ) {
			$organizations = count( OrgRepository::onSite( $audience['org_ids'] ) );
		} else {
			$orgs          = array_map( static fn ( int $id ): int => (int) get_post_meta( $id, SubgroupMeta::KEY_ORG_ID, true ), $audience['subgroup_ids'] );
			$organizations = count( OrgRepository::onSite( $orgs ) );
		}
		return [
			'organizations' => $organizations,
			'members'       => count( $this->recipientIds( $audience ) ),
		];
	}

	public function dismiss( int $alertId, int $memberId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_ALERT_DISMISSALS ),
			[
				'alert_id'     => $alertId,
				'member_id'    => $memberId,
				'dismissed_at' => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s' ]
		);
		do_action( Hooks::ALERT_DISMISSED, $alertId, $memberId );
	}

	/**
	 * @return int[]
	 */
	private function dismissedIdsFor( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ALERT_DISMISSALS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT alert_id FROM %i WHERE member_id = %d', $table, $memberId ) );
		return array_map( 'intval', $rows );
	}
}
