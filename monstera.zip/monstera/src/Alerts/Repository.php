<?php
declare(strict_types=1);

namespace Monstera\Alerts;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;
use WP_Query;
use WP_User;

final class Repository {

	/** The roles "everyone" reaches. */
	private const MEMBER_ROLES = [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ];

	/**
	 * Active, non-dismissed alerts visible to a user: critical first, then
	 * warnings, then info, newest first within each. Every live alert is
	 * read (they are few, and expired ones are archived daily), so an older
	 * critical one is never cut for a newer notice.
	 *
	 * @return WP_Post[]
	 */
	public function visibleTo( WP_User $user ): array {
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => [ 'date' => 'DESC' ],
				'no_found_rows'  => true,
			]
		);

		$out             = [];
		$orgId           = UserMeta::associatedOrg( $user->ID );
		$dismissedIds    = $this->dismissedIdsFor( $user->ID );
		$memberProjects  = ( new ProjectRepository() )->projectsForMember( $user->ID );
		$memberSubgroups = ( new SubgroupRepository() )->subgroupsForMember( $user->ID );

		foreach ( $query->posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			if ( in_array( $post->ID, $dismissedIds, true ) ) {
				continue;
			}
			if ( Expiry::hasPassed( (string) get_post_meta( $post->ID, Meta::KEY_EXPIRES_AT, true ) ) ) {
				continue;
			}

			// New audience model: explicit "everyone" flag, or org/standalone-member
			// lists. Whether the keys were ever written decides it, not what they
			// hold: "everyone" stored as off with nothing chosen reaches nobody.
			// Only an alert that never had them falls back to the legacy scope.
			$hasNewModel = self::hasAudience( $post->ID );

			if ( $hasNewModel ) {
				$matches = self::includes( self::audienceOf( $post->ID ), (int) $user->ID, $orgId, $memberSubgroups );
			} else {
				$scope    = (string) ( get_post_meta( $post->ID, Meta::KEY_SCOPE, true ) ?: Meta::SCOPE_ALL );
				$scopeIds = array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_SCOPE_IDS, true ) );

				$audience = apply_filters(
					Hooks::FILTER_ALERT_AUDIENCE,
					[
						'scope'         => $scope,
						'scope_ids'     => $scopeIds,
						'user_id'       => $user->ID,
						'user_org'      => $orgId,
						'user_projects' => $memberProjects,
					],
					$post->ID
				);

				$matches = match ( $audience['scope'] ) {
					Meta::SCOPE_ALL     => true,
					Meta::SCOPE_ORG     => $orgId > 0 && in_array( $orgId, $audience['scope_ids'], true ),
					Meta::SCOPE_PROJECT => (bool) array_intersect( $memberProjects, $audience['scope_ids'] ),
					default             => false,
				};
			}

			if ( $matches ) {
				$out[] = $post;
			}
		}
		// usort is stable, so each severity keeps the query's newest-first order.
		usort(
			$out,
			static fn ( WP_Post $a, WP_Post $b ): int => Meta::severityRank( (string) get_post_meta( $a->ID, Meta::KEY_SEVERITY, true ) )
				<=> Meta::severityRank( (string) get_post_meta( $b->ID, Meta::KEY_SEVERITY, true ) )
		);
		return $out;
	}

	/**
	 * Alerts ended for everyone in the last $days days whose audience
	 * included this member: the "Resolved" notes in their activity.
	 *
	 * @return WP_Post[]
	 */
	public function endedFor( WP_User $user, int $days = 14 ): array {
		$query     = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'draft',
				// Every alert ended in the window (a handful): the member's own
				// must not be cut by others' before the audience is checked.
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'meta_key'       => Meta::KEY_ENDED_AT, // phpcs:ignore WordPress.DB.SlowDBQuery -- a handful of alerts, ordered by when they ended.
				'orderby'        => 'meta_value',
				'order'          => 'DESC',
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- as above.
					[
						'key'     => Meta::KEY_ENDED_AT,
						'value'   => gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ),
						'compare' => '>=',
						'type'    => 'DATETIME',
					],
				],
			]
		);
		$orgId     = UserMeta::associatedOrg( $user->ID );
		$subgroups = ( new SubgroupRepository() )->subgroupsForMember( $user->ID );
		return array_slice(
			array_values(
				array_filter(
					$query->posts,
					static fn ( $post ) => $post instanceof WP_Post && self::includes( self::audienceOf( $post->ID ), (int) $user->ID, $orgId, $subgroups )
				)
			),
			0,
			20
		);
	}

	/** Whether the alert carries the audience keys at all (see visibleTo()). */
	public static function hasAudience( int $alertId ): bool {
		foreach ( [ Meta::KEY_AUDIENCE_ALL, Meta::KEY_ORG_IDS, Meta::KEY_STANDALONE_MEMBER_IDS, Meta::KEY_SUBGROUP_IDS ] as $key ) {
			if ( metadata_exists( 'post', $alertId, $key ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether an audience names nobody: not everyone, and no organization,
	 * member or sub-group.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 */
	public static function isEmpty( array $audience ): bool {
		return ! $audience['all'] && ! $audience['org_ids'] && ! $audience['member_ids'] && ! $audience['subgroup_ids'];
	}

	/**
	 * An alert's audience as stored.
	 *
	 * @return array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]}
	 */
	public static function audienceOf( int $alertId ): array {
		$ids = static fn ( string $key ): array => array_values( array_filter( array_map( 'intval', (array) get_post_meta( $alertId, $key, true ) ) ) );
		return [
			// An alert that never had the keys predates them, and is for everyone.
			'all'          => ! self::hasAudience( $alertId ) || (bool) get_post_meta( $alertId, Meta::KEY_AUDIENCE_ALL, true ),
			'org_ids'      => $ids( Meta::KEY_ORG_IDS ),
			'member_ids'   => $ids( Meta::KEY_STANDALONE_MEMBER_IDS ),
			'subgroup_ids' => $ids( Meta::KEY_SUBGROUP_IDS ),
		];
	}

	/**
	 * Whether an audience includes one person. Sub-group scoping narrows an
	 * org match when both are named: a leader's alert targets [org] +
	 * [sub-group], so a member must be in both. When only sub-groups are
	 * named, the sub-group is itself the audience (rather than reaching
	 * nobody).
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @param int[]                                                                    $memberSubgroups
	 */
	public static function includes( array $audience, int $userId, int $orgId, array $memberSubgroups ): bool {
		if ( $audience['all'] ) {
			return true;
		}
		$orgMatch = $orgId > 0 && in_array( $orgId, $audience['org_ids'], true );
		if ( $audience['subgroup_ids'] ) {
			$sgMatch  = (bool) array_intersect( $audience['subgroup_ids'], $memberSubgroups );
			$orgMatch = $audience['org_ids'] ? ( $orgMatch && $sgMatch ) : $sgMatch;
		}
		return $orgMatch || in_array( $userId, $audience['member_ids'], true );
	}

	/**
	 * The members an audience reaches, as user ids. Everyone means every
	 * member, in an organization or standalone; Monstera admins are staff,
	 * not the audience. The same rule as includes(), worked in sets so it
	 * costs a query per list, not one per person: with organizations and
	 * sub-groups both named a member must be in both; sub-groups alone are
	 * the audience; named members always are.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @return int[]
	 */
	public function recipientIds( array $audience ): array {
		$ids = static fn ( array $args ): array => array_map(
			'intval',
			(array) get_users(
				$args + [
					'fields' => 'ID',
					'number' => -1,
				]
			)
		);
		if ( $audience['all'] ) {
			return $ids( [ 'role__in' => self::MEMBER_ROLES ] );
		}

		$inGroups  = [];
		$subgroups = new SubgroupRepository();
		foreach ( $audience['subgroup_ids'] as $subgroupId ) {
			$inGroups = array_merge( $inGroups, $subgroups->memberIds( (int) $subgroupId ) );
		}
		$reached = $inGroups;
		if ( $audience['org_ids'] ) {
			$inOrgs  = $ids(
				[
					'meta_key'     => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
					'meta_value'   => array_map( 'strval', $audience['org_ids'] ), // phpcs:ignore WordPress.DB.SlowDBQuery -- as above.
					'meta_compare' => 'IN',
				]
			);
			$reached = $audience['subgroup_ids'] ? array_intersect( $inOrgs, $inGroups ) : $inOrgs;
		}
		// Named members who still have an account.
		$named = $audience['member_ids'] ? $ids( [ 'include' => array_values( $audience['member_ids'] ) ] ) : [];
		return array_values( array_unique( array_map( 'intval', array_merge( $reached, $named ) ) ) );
	}

	/**
	 * How far an audience reaches, for the composer's save bar: the
	 * organizations it names (or every organization, or the sub-groups'
	 * organizations when only sub-groups are named) and the members it
	 * reaches.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience
	 * @return array{organizations: int, members: int}
	 */
	public function reach( array $audience ): array {
		if ( $audience['all'] ) {
			$organizations = (int) ( wp_count_posts( OrgPostType::SLUG )->publish ?? 0 );
		} elseif ( $audience['org_ids'] ) {
			$organizations = count( array_unique( $audience['org_ids'] ) );
		} else {
			$orgs          = array_map( static fn ( int $id ): int => (int) get_post_meta( $id, SubgroupMeta::KEY_ORG_ID, true ), $audience['subgroup_ids'] );
			$organizations = count( array_unique( array_filter( $orgs ) ) );
		}
		return [
			'organizations' => $organizations,
			'members'       => count( $this->recipientIds( $audience ) ),
		];
	}

	public function dismiss( int $alertId, int $memberId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_ALERT_DISMISSALS ),
			[
				'alert_id'     => $alertId,
				'member_id'    => $memberId,
				'dismissed_at' => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s' ]
		);
		do_action( Hooks::ALERT_DISMISSED, $alertId, $memberId );
	}

	/**
	 * @return int[]
	 */
	private function dismissedIdsFor( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_ALERT_DISMISSALS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT alert_id FROM %i WHERE member_id = %d', $table, $memberId ) );
		return array_map( 'intval', $rows );
	}
}
