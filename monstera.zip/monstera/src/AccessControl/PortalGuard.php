<?php
declare(strict_types=1);

namespace Monstera\AccessControl;

use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\Context;
use Monstera\Portal\SupportPages;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

final class PortalGuard {

	public const BLOCKED_NO_ORG    = 'no-org';
	public const BLOCKED_NO_ACCESS = 'no-access';
	public const BLOCKED_EXPIRED   = 'expired';

	/** Why the current request is blocked, set by enforce() for the router. */
	private static ?string $blocked = null;

	/** The blocked reason for the current request, if any (see enforce()). */
	public static function blocked(): ?string {
		return self::$blocked;
	}

	/**
	 * Why a signed-in member may not see a route, or null when the page may
	 * render (states track, FR1; People-model track, FR5). Staff are never
	 * blocked, except from a support request that is not their own.
	 * `no-org`: a client person with no memberships on their dashboard
	 * (standalone members are not blocked), and on every page an account
	 * the portal is not for (isPortalAccount()). `no-access`: the hub of an
	 * organization they do not belong to, an item the visibility engine
	 * denies, a project the member is not on. `expired`: the context
	 * organization's membership date has passed, on its hub and on a content
	 * item or project reached through it; on the dashboard and the projects
	 * list only when every one of the person's memberships has ended, so a
	 * person with one live organization among ended ones still sees them.
	 */
	public static function blockedReason( \WP_User $user, string $route ): ?string {
		// A support request's page is its member's alone. Staff read and
		// answer it in the admin, so not even they pass; and a reference
		// that names no request reads the same as someone else's.
		if ( Routing::ROUTE_SUPPORT_REQUEST === $route ) {
			return SupportPages::ownRequest( (int) $user->ID, (string) get_query_var( Routing::PARAM_REF ) ) ? null : self::BLOCKED_NO_ACCESS;
		}

		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return null;
		}

		if ( ! self::isPortalAccount( $user ) ) {
			return self::BLOCKED_NO_ORG;
		}

		if ( Routing::ROUTE_ORG === $route ) {
			$slug = (string) get_query_var( Routing::PARAM_ORG );
			if ( $slug && ! self::canViewOrg( $user, $slug ) ) {
				return self::BLOCKED_NO_ACCESS;
			}
		}

		if ( Routing::ROUTE_CONTENT === $route ) {
			$contentId = (int) get_query_var( Routing::PARAM_ID );
			if ( $contentId && ! self::canViewContent( $user, $contentId ) ) {
				return self::BLOCKED_NO_ACCESS;
			}
		}

		if ( Routing::ROUTE_PROJECT === $route ) {
			$projectId = (int) get_query_var( Routing::PARAM_ID );
			if ( $projectId && ! ( new ProjectRepository() )->userCanAccess( (int) $user->ID, $projectId ) ) {
				return self::BLOCKED_NO_ACCESS;
			}
		}

		// A page about one organization is judged by that organization alone.
		if ( in_array( $route, [ Routing::ROUTE_ORG, Routing::ROUTE_CONTENT, Routing::ROUTE_PROJECT ], true ) ) {
			$contextOrgId = Context::orgFor( $user, $route );
			if ( $contextOrgId > 0 && self::membershipExpired( $contextOrgId ) ) {
				return self::BLOCKED_EXPIRED;
			}
		}

		// The pages that span every organization stay open while one is live.
		$orgIds = Roster::orgIdsOf( (int) $user->ID );
		if ( $orgIds && in_array( $route, [ Routing::ROUTE_DASHBOARD, Routing::ROUTE_PROJECTS ], true ) && self::everyMembershipExpired( $orgIds ) ) {
			return self::BLOCKED_EXPIRED;
		}

		$standalone = in_array( Capabilities::ROLE_MEMBER_STANDALONE, (array) $user->roles, true );
		if ( ! $orgIds && ! $standalone && Routing::ROUTE_DASHBOARD === $route ) {
			return self::BLOCKED_NO_ORG;
		}

		return null;
	}

	/**
	 * Whether the portal is for this account at all: it is staff, or it
	 * holds one of the client roles, or it belongs to an organization. Any
	 * other account that signs in (the site's subscriber, a shop's
	 * customer, someone whose invitation was ended before they ever signed
	 * in, Organizations\Roster::remove()) is nobody's member: nothing is
	 * shared with it, and it is told so on every page, where it used to be
	 * told only on the dashboard and read the pages for every member
	 * beside it. The capabilities already kept such an account out of the
	 * directory, the projects and the downloads; this closes the rest.
	 *
	 * A membership counts whatever the role, so an account the Roster left
	 * without a client role on purpose is judged as before.
	 */
	public static function isPortalAccount( \WP_User $user ): bool {
		if ( Capabilities::isStaff( $user ) || user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return true;
		}
		foreach ( (array) $user->roles as $role ) {
			if ( Capabilities::isPortalRole( (string) $role ) ) {
				return true;
			}
		}
		return [] !== Roster::orgIdsOf( (int) $user->ID );
	}

	/**
	 * Whether none of the organizations is still running. Each one's end date
	 * is post meta, and this runs before the shell has read anything, so the
	 * organizations and the meta of all of them are read at once, as the
	 * dashboard reads its own: a person in six organizations costs the guard
	 * what a person in two does, and the shell and the page, which ask the
	 * same organizations for their names, their dates and their status, find
	 * them in hand.
	 *
	 * An organization in the trash or still a draft does not count as
	 * running: its hub is closed to its own people
	 * (Organizations\Repository::findPublished()), so a membership of it
	 * keeps nothing open, and a person whose other memberships have all
	 * ended is blocked as one whose every membership has. Nor does it count
	 * as ended: with no published organization among them there is nothing
	 * that has ended, and the page renders.
	 *
	 * @param list<int> $orgIds
	 */
	private static function everyMembershipExpired( array $orgIds ): bool {
		_prime_post_caches( $orgIds, false, true );
		$orgs  = new OrgRepository();
		$ended = false;
		foreach ( $orgIds as $orgId ) {
			if ( null === $orgs->findPublished( $orgId ) ) {
				continue;
			}
			if ( ! self::membershipExpired( $orgId ) ) {
				return false;
			}
			$ended = true;
		}
		return $ended;
	}

	/** Whether an organization's membership date lies in the past. */
	public static function membershipExpired( int $orgId ): bool {
		return self::dateHasPassed( (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ) );
	}

	/**
	 * Whether a membership's end date lies in the past: the day itself is
	 * its last, and still counts as running. An organization's date is
	 * asked through membershipExpired(); a standalone member's own date is
	 * read the same way where a page words it (the profile), so "ended"
	 * begins on one day for both.
	 */
	public static function dateHasPassed( string $date ): bool {
		$ts = '' !== $date ? strtotime( $date ) : false;
		return false !== $ts && $ts < strtotime( 'today' );
	}

	public static function enforce(): void {
		$route = (string) get_query_var( Routing::QUERY_VAR );
		if ( ! $route ) {
			return;
		}

		// Download endpoint has its own auth flow that returns 403 directly.
		// The accessibility statement is public by design (EAA): anyone must be
		// able to read it before signing in; so is the sign-in page itself.
		if ( in_array( $route, [ Routing::ROUTE_DOWNLOAD, Routing::ROUTE_ACCESSIBILITY, Routing::ROUTE_SIGN_IN ], true ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( self::currentUrl() ) );
			exit;
		}

		$user = wp_get_current_user();

		// A blocked member sees the reason on the page they asked for (the
		// router renders blocked.php and sets the status: 403 for every
		// reason but no-org) instead of being bounced home.
		self::$blocked = self::blockedReason( $user, $route );
	}

	/**
	 * Reuses the canonical 6-rule visibility engine so the guard can never
	 * drift from what content.php renders. "Can see" is allowed-to-view
	 * (suspended-org soft blocks still render with an overlay, so they pass).
	 */
	private static function canViewContent( \WP_User $user, int $contentId ): bool {
		$visibility = new Visibility( new SubgroupRepository(), new ProjectRepository() );
		return $visibility->userCanSee( $user, $contentId );
	}

	private static function currentUrl(): string {
		$scheme = is_ssl() ? 'https://' : 'http://';
		$host   = (string) ( $_SERVER['HTTP_HOST'] ?? '' );
		$uri    = (string) ( $_SERVER['REQUEST_URI'] ?? '/' );
		return $scheme . $host . $uri;
	}

	/** Whether the hub is one of the viewer's: any membership there, or staff, who read every hub. */
	private static function canViewOrg( \WP_User $user, string $slug ): bool {
		if ( Capabilities::isStaff( $user ) ) {
			return true;
		}
		$post = ( new OrgRepository() )->findBySlug( $slug );
		return null !== $post && Roster::isMemberOf( (int) $user->ID, (int) $post->ID );
	}
}
