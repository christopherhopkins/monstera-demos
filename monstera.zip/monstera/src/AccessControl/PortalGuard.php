<?php
declare(strict_types=1);

namespace Monstera\AccessControl;

use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Portal\SupportPages;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;

defined( 'ABSPATH' ) || exit;

final class PortalGuard {

	public const BLOCKED_NO_ORG    = 'no-org';
	public const BLOCKED_NO_ACCESS = 'no-access';
	public const BLOCKED_EXPIRED   = 'expired';

	/** Why the current request is blocked, set by enforce() for the router. */
	private static ?string $blocked = null;

	/** The blocked reason for the current request, if any (see enforce()). */
	public static function blocked(): ?string {
		return self::$blocked;
	}

	/**
	 * Why a signed-in member may not see a route, or null when the page may
	 * render (states track, FR1). Admins are never blocked, except from a
	 * support request that is not their own. `no-org`: a
	 * member with no organization on their dashboard (standalone members are
	 * not blocked). `no-access`: another organization's hub, an item the
	 * visibility engine denies, a project the member is not on. `expired`:
	 * the member's organization's membership date has passed, on the
	 * dashboard and every org-scoped route.
	 */
	public static function blockedReason( \WP_User $user, string $route ): ?string {
		// A support request's page is its member's alone. Staff read and
		// answer it in the admin, so not even they pass; and a reference
		// that names no request reads the same as someone else's.
		if ( Routing::ROUTE_SUPPORT_REQUEST === $route ) {
			return SupportPages::ownRequest( (int) $user->ID, (string) get_query_var( Routing::PARAM_REF ) ) ? null : self::BLOCKED_NO_ACCESS;
		}

		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return null;
		}

		if ( Routing::ROUTE_ORG === $route ) {
			$slug = (string) get_query_var( Routing::PARAM_ORG );
			if ( $slug && ! self::canViewOrg( $user, $slug ) ) {
				return self::BLOCKED_NO_ACCESS;
			}
		}

		if ( Routing::ROUTE_CONTENT === $route ) {
			$contentId = (int) get_query_var( Routing::PARAM_ID );
			if ( $contentId && ! self::canViewContent( $user, $contentId ) ) {
				return self::BLOCKED_NO_ACCESS;
			}
		}

		if ( Routing::ROUTE_PROJECT === $route ) {
			$projectId = (int) get_query_var( Routing::PARAM_ID );
			if ( $projectId && ! ( new ProjectRepository() )->userCanAccess( (int) $user->ID, $projectId ) ) {
				return self::BLOCKED_NO_ACCESS;
			}
		}

		$orgId    = UserMeta::associatedOrg( (int) $user->ID );
		$orgRoute = in_array(
			$route,
			[ Routing::ROUTE_DASHBOARD, Routing::ROUTE_ORG, Routing::ROUTE_CONTENT, Routing::ROUTE_PROJECT, Routing::ROUTE_PROJECTS ],
			true
		);

		if ( $orgId && $orgRoute && self::membershipExpired( $orgId ) ) {
			return self::BLOCKED_EXPIRED;
		}

		$standalone = in_array( Capabilities::ROLE_MEMBER_STANDALONE, (array) $user->roles, true );
		if ( ! $orgId && ! $standalone && Routing::ROUTE_DASHBOARD === $route ) {
			return self::BLOCKED_NO_ORG;
		}

		return null;
	}

	/** Whether an organization's membership date lies in the past. */
	public static function membershipExpired( int $orgId ): bool {
		$expires = (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true );
		$ts      = $expires ? strtotime( $expires ) : false;
		return false !== $ts && $ts < strtotime( 'today' );
	}

	public static function enforce(): void {
		$route = (string) get_query_var( Routing::QUERY_VAR );
		if ( ! $route ) {
			return;
		}

		// Download endpoint has its own auth flow that returns 403 directly.
		// The accessibility statement is public by design (EAA): anyone must be
		// able to read it before signing in; so is the sign-in page itself.
		if ( in_array( $route, [ Routing::ROUTE_DOWNLOAD, Routing::ROUTE_ACCESSIBILITY, Routing::ROUTE_SIGN_IN ], true ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( self::currentUrl() ) );
			exit;
		}

		$user = wp_get_current_user();

		// A blocked member sees the reason on the page they asked for (the
		// router renders blocked.php and sets the status: 403 for every
		// reason but no-org) instead of being bounced home.
		self::$blocked = self::blockedReason( $user, $route );
	}

	/**
	 * Reuses the canonical 6-rule visibility engine so the guard can never
	 * drift from what content.php renders. "Can see" is allowed-to-view
	 * (suspended-org soft blocks still render with an overlay, so they pass).
	 */
	private static function canViewContent( \WP_User $user, int $contentId ): bool {
		$visibility = new Visibility( new SubgroupRepository(), new ProjectRepository() );
		return $visibility->userCanSee( $user, $contentId );
	}

	private static function currentUrl(): string {
		$scheme = is_ssl() ? 'https://' : 'http://';
		$host   = (string) ( $_SERVER['HTTP_HOST'] ?? '' );
		$uri    = (string) ( $_SERVER['REQUEST_URI'] ?? '/' );
		return $scheme . $host . $uri;
	}

	private static function canViewOrg( \WP_User $user, string $slug ): bool {
		if ( user_can( $user, 'manage_monstera' ) ) {
			return true;
		}
		$repo = new OrgRepository();
		$post = $repo->findBySlug( $slug );
		if ( ! $post ) {
			return false;
		}
		$ownOrgId = UserMeta::associatedOrg( $user->ID );
		return $ownOrgId === $post->ID;
	}
}
