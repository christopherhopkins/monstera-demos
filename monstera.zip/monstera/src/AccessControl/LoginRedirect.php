<?php
/**
 * Post-login and post-logout destinations.
 *
 * Hooked on WordPress' `login_redirect` filter rather than the `wp_login`
 * action: the stock login form always posts a `redirect_to` (defaulting to
 * admin_url()), so an action-based handler cannot tell "no destination" from
 * "explicit destination". The filter receives both the requested URL and the
 * raw request value, which lets the resolver honour genuine destinations and
 * replace the admin default for portal roles.
 */

declare(strict_types=1);

namespace Monstera\AccessControl;

use Monstera\Core\Capabilities;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use WP_Error;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class LoginRedirect {

	/**
	 * `login_redirect` filter callback. WordPress passes a WP_Error instead of
	 * a user when authentication failed; those requests are left alone.
	 *
	 * @param string             $redirectTo Destination after any earlier filters.
	 * @param string             $requested  The raw redirect_to request value ('' when absent).
	 * @param WP_User|WP_Error   $user       Authenticated user, or an error.
	 * @return string
	 */
	public static function filterLoginRedirect( $redirectTo, $requested, $user ): string {
		$redirectTo = (string) $redirectTo;
		if ( ! $user instanceof WP_User || ! $user->exists() ) {
			return $redirectTo;
		}
		return self::resolve( $redirectTo, (string) $requested, $user );
	}

	/**
	 * Decide where a freshly authenticated user lands. Pure: no redirect, no exit.
	 *
	 * Rules (see the track spec):
	 * - Admins (monstera_admin or manage_options) keep WordPress behaviour.
	 * - Non-portal roles keep WordPress behaviour.
	 * - Portal roles: an explicit front-end/portal destination is honoured; the
	 *   admin default, an empty request, or any other wp-admin URL (except the
	 *   user's own profile page) resolves to their portal landing.
	 *
	 * @param string  $requested    The destination WordPress would use.
	 * @param string  $rawRequested The raw redirect_to request value.
	 * @param WP_User $user         The authenticated user.
	 */
	public static function resolve( string $requested, string $rawRequested, WP_User $user ): string {
		if ( self::isAdmin( $user ) || ! self::hasPortalRole( $user ) ) {
			return $requested;
		}

		$explicit = '' !== $rawRequested && ! self::isAdminDefault( $rawRequested );

		if ( $explicit && ( ! self::isWpAdminUrl( $rawRequested ) || self::isOwnProfileUrl( $rawRequested ) ) ) {
			return $requested;
		}

		return self::portalLanding( $user );
	}

	public static function afterLogout(): void {
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	/**
	 * The portal page for a portal-role user: org hub when they belong to an
	 * org, portal home for standalone members, profile as the fallback.
	 */
	public static function portalLanding( WP_User $user ): string {
		$roles = (array) $user->roles;

		if ( in_array( Capabilities::ROLE_MEMBER_STANDALONE, $roles, true ) ) {
			return Routing::url( Routing::ROUTE_DASHBOARD );
		}

		$orgId = UserMeta::associatedOrg( $user->ID );
		if ( $orgId ) {
			$slug = (string) get_post_field( 'post_name', $orgId );
			if ( '' !== $slug ) {
				return Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] );
			}
		}

		return Routing::url( Routing::ROUTE_PROFILE );
	}

	private static function isAdmin( WP_User $user ): bool {
		return in_array( Capabilities::ROLE_ADMIN, (array) $user->roles, true )
			|| user_can( $user, 'manage_options' )
			|| user_can( $user, Capabilities::CAP_MANAGE_MONSTERA );
	}

	private static function hasPortalRole( WP_User $user ): bool {
		foreach ( (array) $user->roles as $role ) {
			if ( Capabilities::isPortalRole( (string) $role ) ) {
				return true;
			}
		}
		return false;
	}

	/** wp-login.php's default when no redirect_to was supplied. */
	private static function isAdminDefault( string $url ): bool {
		return untrailingslashit( $url ) === untrailingslashit( admin_url() );
	}

	private static function isWpAdminUrl( string $url ): bool {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return str_starts_with( $path, (string) wp_parse_url( admin_url(), PHP_URL_PATH ) );
	}

	private static function isOwnProfileUrl( string $url ): bool {
		$path    = untrailingslashit( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		$profile = untrailingslashit( (string) wp_parse_url( admin_url( 'profile.php' ), PHP_URL_PATH ) );
		return $path === $profile;
	}
}
