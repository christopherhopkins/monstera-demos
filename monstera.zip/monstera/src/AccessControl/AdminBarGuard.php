<?php
declare(strict_types=1);

namespace Monstera\AccessControl;

use Monstera\Core\Capabilities;
use Monstera\Core\Routing;

final class AdminBarGuard {

	public static function maybeHide( bool $show ): bool {
		$user = wp_get_current_user();
		if ( ! $user->ID ) {
			return $show;
		}
		foreach ( $user->roles as $role ) {
			if ( Capabilities::isPortalRole( $role ) ) {
				return false;
			}
		}
		return $show;
	}

	public static function blockAdminAccess(): void {
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		$user = wp_get_current_user();
		if ( ! $user->ID ) {
			return;
		}
		$isPortalRole = false;
		foreach ( $user->roles as $role ) {
			if ( Capabilities::isPortalRole( $role ) ) {
				$isPortalRole = true;
				break;
			}
		}
		if ( ! $isPortalRole ) {
			return;
		}

		// Allow only profile.php (their own profile).
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( wp_unslash( (string) $_SERVER['SCRIPT_NAME'] ) ) : '';
		if ( in_array( $script, [ 'profile.php', 'admin-ajax.php' ], true ) ) {
			return;
		}

		wp_safe_redirect( Routing::url( Routing::ROUTE_DASHBOARD ) );
		exit;
	}
}
