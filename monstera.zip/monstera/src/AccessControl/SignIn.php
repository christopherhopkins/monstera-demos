<?php
declare(strict_types=1);

namespace Monstera\AccessControl;

use Monstera\Core\Routing;

defined( 'ABSPATH' ) || exit;

/**
 * The portal-served sign-in page (2026-09 design review, comp 30).
 *
 * /portal/sign-in/ renders the portal's own form, which posts to
 * wp-login.php with a marker field. Three hooks make it the front door for
 * portal destinations while wp-admin and the reset flows keep the stock
 * wp-login.php:
 *
 *  - `login_url`: wp_login_url() points at the page whenever the requested
 *    redirect is a portal URL (PortalGuard, the public shell's Sign in).
 *  - `wp_login_failed`: a failed attempt that came from the page returns to
 *    it with ?failed=1 and the redirect, so the error renders inline.
 *  - `template_redirect`: a signed-in visitor to the page goes to their
 *    landing.
 *
 * The URL decisions are pure functions so the unit suite covers them
 * without WordPress.
 */
final class SignIn {

	public const FIELD_MARKER = 'monstera_portal_login';

	public static function register(): void {
		add_filter( 'login_url', [ self::class, 'filterLoginUrl' ], 10, 2 );
		add_action( 'wp_login_failed', [ self::class, 'onLoginFailed' ], 10, 2 );
	}

	/**
	 * @param string $loginUrl The wp-login.php URL WordPress built.
	 * @param string $redirect The requested destination (may be empty).
	 */
	public static function filterLoginUrl( $loginUrl, $redirect ): string {
		return self::resolveLoginUrl(
			(string) $loginUrl,
			(string) $redirect,
			Routing::url( Routing::ROUTE_DASHBOARD ),
			Routing::url( Routing::ROUTE_SIGN_IN )
		);
	}

	/**
	 * The page whenever the destination is inside the portal, otherwise the
	 * URL WordPress built (wp-admin, reset flows, other plugins).
	 */
	public static function resolveLoginUrl( string $loginUrl, string $redirect, string $portalBase, string $signInUrl ): string {
		if ( '' === $redirect || ! self::isPortalUrl( $redirect, $portalBase ) ) {
			return $loginUrl;
		}
		return self::withRedirect( $signInUrl, $redirect );
	}

	/**
	 * @param string          $username The login that failed.
	 * @param \WP_Error|mixed $error    Why (unused; the page shows one line).
	 */
	public static function onLoginFailed( $username, $error = null ): void {
		unset( $username, $error );
		if ( ! self::isPortalRequest( $_POST ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- wp-login.php's own form; only a marker field is read, nothing is written.
			return;
		}
		$redirect = isset( $_POST['redirect_to'] ) ? (string) wp_unslash( $_POST['redirect_to'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- rawurlencoded into our own page's query string; sign-in.php runs it through esc_url_raw and wp_safe_redirect validates it on success.
		wp_safe_redirect( self::bounceUrl( Routing::url( Routing::ROUTE_SIGN_IN ), $redirect ) );
		exit;
	}

	/**
	 * @param array<string, mixed> $post The request body.
	 */
	public static function isPortalRequest( array $post ): bool {
		return '1' === (string) ( $post[ self::FIELD_MARKER ] ?? '' );
	}

	/**
	 * Where a failed attempt from the page lands: the page, failed=1, the
	 * redirect kept.
	 */
	public static function bounceUrl( string $signInUrl, string $redirect ): string {
		$url = self::withQuery( $signInUrl, 'failed', '1' );
		return '' === $redirect ? $url : self::withRedirect( $url, $redirect );
	}

	/**
	 * A signed-in visitor has no business on the page: send them to their
	 * landing (or the redirect they carried).
	 */
	public static function redirectSignedIn(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$requested = isset( $_GET['redirect_to'] ) ? (string) wp_unslash( $_GET['redirect_to'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only routing parameter, validated by wp_safe_redirect's host allow-list.
		$landing   = LoginRedirect::portalLanding( wp_get_current_user() );
		wp_safe_redirect( '' !== $requested ? $requested : $landing );
		exit;
	}

	public static function isPortalUrl( string $url, string $portalBase ): bool {
		$base = rtrim( $portalBase, '/' );
		return '' !== $base && ( $url === $base || str_starts_with( $url, $base . '/' ) || str_starts_with( $url, $base . '?' ) );
	}

	private static function withRedirect( string $url, string $redirect ): string {
		return self::withQuery( $url, 'redirect_to', $redirect );
	}

	private static function withQuery( string $url, string $key, string $value ): string {
		$sep = str_contains( $url, '?' ) ? '&' : '?';
		return $url . $sep . $key . '=' . rawurlencode( $value );
	}
}
