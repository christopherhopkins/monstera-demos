<?php
declare(strict_types=1);

namespace Monstera\AccessControl;

use Monstera\Core\Capabilities;
use Monstera\Core\Module;
use Monstera\Core\Routing;

final class AccessControlModule implements Module {

	public function slug(): string {
		return 'access-control';
	}

	public function boot(): void {
		add_filter( 'login_redirect', [ LoginRedirect::class, 'filterLoginRedirect' ], 10, 3 );
		SignIn::register();
		add_action( 'wp_logout', [ LoginRedirect::class, 'afterLogout' ] );
		add_filter( 'show_admin_bar', [ AdminBarGuard::class, 'maybeHide' ] );
		add_action( 'admin_init', [ AdminBarGuard::class, 'blockAdminAccess' ] );
		add_action( 'template_redirect', [ PortalGuard::class, 'enforce' ], 1 );
		// Grant the portal authoring cap to sub-group leaders dynamically.
		add_filter( 'user_has_cap', [ Capabilities::class, 'grantLeaderCap' ], 10, 4 );
	}

	public function registerPostTypes(): void {}
}
