<?php
declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public const STATUS_OPEN     = 'open';
	public const STATUS_PENDING  = 'pending';
	public const STATUS_RESOLVED = 'resolved';
	public const STATUS_CLOSED   = 'closed';

	public const PRIORITY_LOW    = 'low';
	public const PRIORITY_NORMAL = 'normal';
	public const PRIORITY_HIGH   = 'high';
	public const PRIORITY_URGENT = 'urgent';

	public const STATUSES   = [ self::STATUS_OPEN, self::STATUS_PENDING, self::STATUS_RESOLVED, self::STATUS_CLOSED ];
	public const PRIORITIES = [ self::PRIORITY_LOW, self::PRIORITY_NORMAL, self::PRIORITY_HIGH, self::PRIORITY_URGENT ];

	/**
	 * Open a request. Files sent with it are its opening message's: every
	 * one is checked before anything is written, and a request whose files
	 * cannot all be kept is not opened.
	 *
	 * @param array<int, array{name: string, tmp_name: string, size: int, type?: string, error?: int}> $uploads As Files::normalise() lists them.
	 * @return array<string, mixed>
	 * @throws FilesRefused      When a file cannot be sent; the message names it.
	 * @throws \RuntimeException When a file could not be stored.
	 */
	public function create( int $memberId, string $subject, string $body, string $priority = self::PRIORITY_NORMAL, ?int $projectId = null, array $uploads = [] ): array {
		global $wpdb;
		self::refuseFiles( $uploads );

		$priority = in_array( $priority, self::PRIORITIES, true )
			? $priority
			: self::PRIORITY_NORMAL;

		$ref = strtoupper( substr( bin2hex( random_bytes( 4 ) ), 0, 8 ) );
		$now = current_time( 'mysql', true );

		$wpdb->insert(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[
				'ref'              => $ref,
				'member_id'        => $memberId,
				'org_id'           => UserMeta::associatedOrg( $memberId ) ?: null,
				'project_id'       => $projectId,
				'subject'          => $subject,
				'body'             => $body,
				'priority'         => $priority,
				'status'           => self::STATUS_OPEN,
				'created_at'       => $now,
				// A new request last moved when its member sent it.
				'last_activity_at' => $now,
				'last_side'        => Thread::SIDE_MEMBER,
			],
			[ '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
		);

		$id  = (int) $wpdb->insert_id;
		$row = $this->find( $id );

		if ( $row && $uploads ) {
			try {
				( new Files() )->store( $row, null, $uploads, $memberId );
			} catch ( \RuntimeException $failure ) {
				// No files, no request: the member sends it again whole.
				$wpdb->delete( Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ), [ 'id' => $id ], [ '%d' ] );
				throw $failure;
			}
		}

		do_action( Hooks::SUPPORT_REQUEST_CREATED, $id, $row );

		return $row ?? [];
	}

	/** A priority as people read it. */
	public static function priorityLabel( string $priority ): string {
		return match ( $priority ) {
			self::PRIORITY_LOW    => __( 'Low', 'monstera' ),
			self::PRIORITY_HIGH   => __( 'High', 'monstera' ),
			self::PRIORITY_URGENT => __( 'Urgent', 'monstera' ),
			default               => __( 'Normal', 'monstera' ),
		};
	}

	/**
	 * A request's page in the portal, as its member's emails link it.
	 *
	 * @param array<string, mixed> $row
	 */
	public static function portalUrl( array $row ): string {
		return Routing::url( Routing::ROUTE_SUPPORT_REQUEST, [ 'ref' => (string) $row['ref'] ] );
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public function find( int $id ): ?array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		$row   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table, $id ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * The request a reference names, however its letters are cased.
	 *
	 * @return array<string, mixed>|null
	 */
	public function findByRef( string $ref ): ?array {
		$ref = strtoupper( trim( $ref ) );
		if ( '' === $ref ) {
			return null;
		}
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE ref = %s', Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ), $ref ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * A member's requests, latest activity first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public function listForMember( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE member_id = %d ORDER BY COALESCE(last_activity_at, created_at) DESC, id DESC', $table, $memberId ), ARRAY_A );
	}

	/**
	 * @param array{status?: string, project_id?: int} $args
	 * @return array<int, array<string, mixed>>
	 */
	public function inbox( array $args = [] ): array {
		global $wpdb;
		$table  = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		$status = isset( $args['status'] ) ? (string) $args['status'] : '';
		// One project's requests (the project detail's sidebar count).
		$project = isset( $args['project_id'] ) ? (int) $args['project_id'] : 0;
		if ( $project > 0 ) {
			return $status
				? (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE project_id = %d AND status = %s ORDER BY COALESCE(last_activity_at, created_at) DESC, id DESC LIMIT 200', $table, $project, $status ), ARRAY_A )
				: (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE project_id = %d ORDER BY COALESCE(last_activity_at, created_at) DESC, id DESC LIMIT 200', $table, $project ), ARRAY_A );
		}
		if ( $status ) {
			return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE status = %s ORDER BY COALESCE(last_activity_at, created_at) DESC, id DESC LIMIT 200', $table, $status ), ARRAY_A );
		}
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY COALESCE(last_activity_at, created_at) DESC, id DESC LIMIT 200', $table ), ARRAY_A );
	}

	/**
	 * What came after the opening message, oldest first.
	 *
	 * @return list<array{id: int, kind: string, author_id: int, side: string, body: string, event: array{type: string, from: string, to: string, cause: string}|null, created_at: string}>
	 */
	public function thread( int $id ): array {
		return ( new Thread() )->entries( $id );
	}

	/**
	 * Add a side's reply to the thread. The reply moves the request by
	 * itself: staff leave it waiting on its member, the member's opens it
	 * again, from resolved or closed alike, so a request that comes back
	 * keeps its history. Files sent with it are checked before anything is
	 * written, and a reply whose files cannot all be kept is taken back.
	 *
	 * @param array<int, array{name: string, tmp_name: string, size: int, type?: string, error?: int}> $uploads As Files::normalise() lists them.
	 * @return int|null The message's id; null when the request does not exist or the reply is empty.
	 * @throws FilesRefused      When a file cannot be sent; the message names it.
	 * @throws \RuntimeException When a file could not be stored.
	 */
	public function reply( int $id, int $authorId, string $side, string $body, array $uploads = [] ): ?int {
		$row  = $this->find( $id );
		$body = trim( $body );
		if ( ! $row || '' === $body ) {
			return null;
		}
		$side = Thread::SIDE_STAFF === $side ? Thread::SIDE_STAFF : Thread::SIDE_MEMBER;
		self::refuseFiles( $uploads );

		$thread    = new Thread();
		$messageId = $thread->addMessage( $id, $authorId, $side, $body );
		if ( $messageId <= 0 ) {
			return null;
		}
		if ( $uploads ) {
			try {
				( new Files() )->store( $row, $messageId, $uploads, $authorId );
			} catch ( \RuntimeException $failure ) {
				// No files, no message: nothing moved, nobody is told.
				$thread->remove( $messageId );
				throw $failure;
			}
		}
		$this->touch( $id, $side );
		do_action( Hooks::SUPPORT_MESSAGE_ADDED, $id, $messageId, $side );

		$this->move(
			$row,
			Thread::SIDE_STAFF === $side ? self::STATUS_PENDING : self::STATUS_OPEN,
			$authorId,
			$side,
			Thread::CAUSE_REPLY
		);
		return $messageId;
	}

	/**
	 * Mark a request resolved. Returns false when the row does not exist, so
	 * the REST layer can answer 404 instead of a misleading {ok:true}.
	 */
	public function resolve( int $id, int $resolverId ): bool {
		return $this->setStatus( $id, self::STATUS_RESOLVED, $resolverId );
	}

	/**
	 * Move a request to a status someone chose. Staff may choose any; the
	 * member who opened it may only say it is resolved. The change is an
	 * event in the thread; a change to the status it already has writes
	 * nothing. resolved_at is stamped on entering resolved and cleared on
	 * leaving it.
	 *
	 * @return bool False when the request does not exist, the status is not one, or the side may not choose it.
	 * @throws ClosedRequest When a member tries to move a closed request.
	 */
	public function setStatus( int $id, string $status, int $actorId, string $side = Thread::SIDE_STAFF ): bool {
		$row = $this->find( $id );
		if ( ! $row || ! in_array( $status, self::STATUSES, true ) ) {
			return false;
		}
		if ( Thread::SIDE_STAFF !== $side ) {
			$side = Thread::SIDE_MEMBER;
			self::refuseIfClosed( $row, $side );
			if ( self::STATUS_RESOLVED !== $status ) {
				return false;
			}
		}
		$this->move( $row, $status, $actorId, $side, Thread::CAUSE_MANUAL );
		return true;
	}

	/**
	 * The member changes how urgent their request is. The change is an event
	 * in the thread; the same priority again writes nothing.
	 *
	 * @return bool False when the request does not exist or the priority is not one.
	 * @throws ClosedRequest When the request is closed.
	 */
	public function setPriority( int $id, string $priority, int $actorId ): bool {
		$row = $this->find( $id );
		if ( ! $row || ! in_array( $priority, self::PRIORITIES, true ) ) {
			return false;
		}
		self::refuseIfClosed( $row, Thread::SIDE_MEMBER );
		$from = (string) $row['priority'];
		if ( $from === $priority ) {
			return true;
		}
		global $wpdb;
		$wpdb->update(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[ 'priority' => $priority ],
			[ 'id' => $id ],
			[ '%s' ],
			[ '%d' ]
		);
		$this->touch( $id, Thread::SIDE_MEMBER );
		( new Thread() )->addEvent( $id, $actorId, Thread::SIDE_MEMBER, Thread::EVENT_PRIORITY, $from, $priority );
		do_action( Hooks::SUPPORT_PRIORITY_CHANGED, $id, $from, $priority, $actorId );
		return true;
	}

	/**
	 * One change of status: the row, its event in the thread and the hooks.
	 *
	 * @param array<string, mixed> $row The request as it was.
	 */
	private function move( array $row, string $to, int $actorId, string $side, string $cause ): void {
		$id   = (int) $row['id'];
		$from = (string) $row['status'];
		if ( $from === $to ) {
			return;
		}
		global $wpdb;
		$wpdb->update(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[
				'status'      => $to,
				'resolved_at' => self::STATUS_RESOLVED === $to ? current_time( 'mysql', true ) : null,
			],
			[ 'id' => $id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
		$this->touch( $id, $side );
		( new Thread() )->addEvent( $id, $actorId, $side, Thread::EVENT_STATUS, $from, $to, $cause );
		do_action( Hooks::SUPPORT_STATUS_CHANGED, $id, $from, $to, $actorId, $side, $cause );
		if ( self::STATUS_RESOLVED === $to ) {
			do_action( Hooks::SUPPORT_REQUEST_RESOLVED, $id, $actorId );
		}
	}

	/** The request last moved now, and this side moved it. */
	private function touch( int $id, string $side ): void {
		global $wpdb;
		$wpdb->update(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[
				'last_activity_at' => current_time( 'mysql', true ),
				'last_side'        => $side,
			],
			[ 'id' => $id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

	/**
	 * @param array<int, array<string, mixed>> $uploads
	 * @throws FilesRefused When one of them cannot be sent.
	 */
	private static function refuseFiles( array $uploads ): void {
		$refusal = $uploads ? Files::refusal( $uploads ) : null;
		if ( null !== $refusal ) {
			throw FilesRefused::because( $refusal ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- because() escapes the exception's message and keeps the plain words for a JSON answer.
		}
	}

	/**
	 * @param array<string, mixed> $row
	 * @throws ClosedRequest When a member changes a closed request without reopening it.
	 */
	private static function refuseIfClosed( array $row, string $side ): void {
		if ( Thread::SIDE_MEMBER === $side && self::STATUS_CLOSED === $row['status'] ) {
			throw new ClosedRequest( 'This request is closed.' );
		}
	}
}
