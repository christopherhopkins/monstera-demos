<?php
declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;

final class Repository {

	public const STATUS_OPEN     = 'open';
	public const STATUS_PENDING  = 'pending';
	public const STATUS_RESOLVED = 'resolved';
	public const STATUS_CLOSED   = 'closed';

	public const PRIORITY_LOW    = 'low';
	public const PRIORITY_NORMAL = 'normal';
	public const PRIORITY_HIGH   = 'high';
	public const PRIORITY_URGENT = 'urgent';

	/**
	 * @return array<string, mixed>
	 */
	public function create( int $memberId, string $subject, string $body, string $priority = self::PRIORITY_NORMAL, ?int $projectId = null, ?int $attachmentId = null ): array {
		global $wpdb;

		$priority = in_array( $priority, [ self::PRIORITY_LOW, self::PRIORITY_NORMAL, self::PRIORITY_HIGH, self::PRIORITY_URGENT ], true )
			? $priority
			: self::PRIORITY_NORMAL;

		$ref = strtoupper( substr( bin2hex( random_bytes( 4 ) ), 0, 8 ) );

		$wpdb->insert(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[
				'ref'           => $ref,
				'member_id'     => $memberId,
				'org_id'        => UserMeta::associatedOrg( $memberId ) ?: null,
				'project_id'    => $projectId,
				'subject'       => $subject,
				'body'          => $body,
				'priority'      => $priority,
				'status'        => self::STATUS_OPEN,
				'attachment_id' => $attachmentId,
				'created_at'    => current_time( 'mysql', true ),
			],
			[ '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s' ]
		);

		$id  = (int) $wpdb->insert_id;
		$row = $this->find( $id );

		do_action( Hooks::SUPPORT_REQUEST_CREATED, $id, $row );
		$this->notifyAgency( $row );

		return $row ?? [];
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public function find( int $id ): ?array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		$row   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table, $id ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public function listForMember( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE member_id = %d ORDER BY created_at DESC', $table, $memberId ), ARRAY_A );
	}

	/**
	 * @param array{status?: string, project_id?: int} $args
	 * @return array<int, array<string, mixed>>
	 */
	public function inbox( array $args = [] ): array {
		global $wpdb;
		$table  = Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS );
		$status = isset( $args['status'] ) ? (string) $args['status'] : '';
		// One project's requests (the project detail's sidebar count).
		$project = isset( $args['project_id'] ) ? (int) $args['project_id'] : 0;
		if ( $project > 0 ) {
			return $status
				? (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE project_id = %d AND status = %s ORDER BY created_at DESC LIMIT 200', $table, $project, $status ), ARRAY_A )
				: (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE project_id = %d ORDER BY created_at DESC LIMIT 200', $table, $project ), ARRAY_A );
		}
		if ( $status ) {
			return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE status = %s ORDER BY created_at DESC LIMIT 200', $table, $status ), ARRAY_A );
		}
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY created_at DESC LIMIT 200', $table ), ARRAY_A );
	}

	/**
	 * Mark a request resolved. Returns false when the row does not exist, so
	 * the REST layer can answer 404 instead of a misleading {ok:true}.
	 */
	public function resolve( int $id, int $resolverId ): bool {
		if ( ! $this->find( $id ) ) {
			return false;
		}
		global $wpdb;
		$wpdb->update(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[
				'status'      => self::STATUS_RESOLVED,
				'resolved_at' => current_time( 'mysql', true ),
			],
			[ 'id' => $id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
		do_action( Hooks::SUPPORT_REQUEST_RESOLVED, $id, $resolverId );
		return true;
	}

	/**
	 * Transition a request to an arbitrary status (open/pending/resolved/closed).
	 * Stamps resolved_at when entering resolved, clears it otherwise. Returns
	 * false when the row does not exist or the status is not recognised.
	 */
	public function setStatus( int $id, string $status, int $actorId ): bool {
		$allowed = [ self::STATUS_OPEN, self::STATUS_PENDING, self::STATUS_RESOLVED, self::STATUS_CLOSED ];
		if ( ! in_array( $status, $allowed, true ) || ! $this->find( $id ) ) {
			return false;
		}
		global $wpdb;
		$wpdb->update(
			Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ),
			[
				'status'      => $status,
				'resolved_at' => self::STATUS_RESOLVED === $status ? current_time( 'mysql', true ) : null,
			],
			[ 'id' => $id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
		if ( self::STATUS_RESOLVED === $status ) {
			do_action( Hooks::SUPPORT_REQUEST_RESOLVED, $id, $actorId );
		}
		return true;
	}

	/**
	 * @param array<string, mixed>|null $row
	 */
	private function notifyAgency( ?array $row ): void {
		if ( ! $row ) {
			return;
		}
		$recipients = apply_filters( Hooks::FILTER_SUPPORT_RECIPIENTS, [ get_option( 'admin_email' ) ], $row );
		if ( ! $recipients ) {
			return;
		}

		$member  = get_userdata( (int) $row['member_id'] );
		$subject = sprintf( '[Monstera Support · %s] %s', $row['ref'], $row['subject'] );
		$body    = "A support request was just submitted.\n\n";
		$body   .= "Reference: {$row['ref']}\n";
		$body   .= "Priority:  {$row['priority']}\n";
		$body   .= 'From:      ' . ( $member ? $member->display_name . ' <' . $member->user_email . '>' : 'unknown' ) . "\n";
		if ( $row['org_id'] ) {
			$body .= 'Org:       ' . get_the_title( (int) $row['org_id'] ) . "\n";
		}
		if ( $row['project_id'] ) {
			$body .= 'Project:   ' . get_the_title( (int) $row['project_id'] ) . "\n";
		}
		$body .= "\n----\n\n" . $row['body'] . "\n";

		wp_mail( $recipients, $subject, $body );
	}
}
