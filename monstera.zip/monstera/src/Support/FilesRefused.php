<?php
/**
 * A message's files cannot be kept, so the message was not written.
 *
 * reason() is Support\Files::refusal()'s sentence as written: words the
 * sender can act on that name the file. Nothing was stored.
 */

declare(strict_types=1);

namespace Monstera\Support;

defined( 'ABSPATH' ) || exit;

final class FilesRefused extends \InvalidArgumentException {

	private string $reason = '';

	public static function because( string $reason ): self {
		$refused         = new self( esc_html( $reason ) );
		$refused->reason = $reason;
		return $refused;
	}

	/** The refusal in plain words, for a response that is not HTML. */
	public function reason(): string {
		return $this->reason;
	}
}
