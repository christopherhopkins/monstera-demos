<?php
/**
 * The files a side sends with a support message.
 *
 * A screenshot of a client's system is as confidential as a deliverable, so
 * a support file is a secure file, never a Media Library attachment: stored
 * under mp-secure/support/<ref>/, recorded in the secure-file registry with
 * its request as owner (and the message it came with; none for the opening
 * message) and who sent it, and served only through the Downloader. A
 * message takes at most maxCount() files of at most maxBytes() each, of the
 * types secure files may be.
 *
 * Files travel with their message: Repository::create() and reply() check
 * every upload with refusal() before anything is written, and take the
 * message back if store() cannot keep them all.
 */

declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Content\SecureFiles;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\SecureStorage;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

final class Files {

	/** 10 MB, or the server's upload limit when that is lower. */
	private const DEFAULT_MAX_BYTES = 10485760;

	private const DEFAULT_MAX_COUNT = 5;

	/**
	 * What a request's words may weigh beside its files: the room left for
	 * the subject, the message and the form's own framing when the files are
	 * measured against the server's body limit.
	 */
	public const BODY_HEADROOM = 65536;

	/**
	 * The types a thread shows as a thumbnail and the Downloader sends
	 * inline: raster images a browser only paints. Never SVG, which it runs.
	 */
	private const IMAGES = [ 'image/png', 'image/jpeg', 'image/gif', 'image/webp' ];

	public static function isImage( string $mimeType ): bool {
		return in_array( $mimeType, self::IMAGES, true );
	}

	/**
	 * The largest file a message takes: the filter's value, never more than
	 * the server's upload limit, since PHP refuses a larger file before the
	 * plugin sees it.
	 */
	public static function maxBytes(): int {
		$wanted = max( 1, (int) apply_filters( Hooks::FILTER_SUPPORT_FILE_MAX_BYTES, self::DEFAULT_MAX_BYTES ) );
		$server = (int) wp_max_upload_size();
		return $server > 0 ? min( $wanted, $server ) : $wanted;
	}

	public static function maxCount(): int {
		return max( 1, (int) apply_filters( Hooks::FILTER_SUPPORT_FILE_MAX_COUNT, self::DEFAULT_MAX_COUNT ) );
	}

	/**
	 * How many bytes of files one message can carry: the server's limit on a
	 * request's body, less room for the words. A message and its files are
	 * one request, so a set over this is refused by PHP whole, words and
	 * all; the picker checks it first. 0 when the server sets no limit.
	 *
	 * @param string|null $postMaxSize post_max_size as php.ini writes it; the server's own when null.
	 */
	public static function maxTotal( ?string $postMaxSize = null ): int {
		$limit = (int) wp_convert_hr_to_bytes( $postMaxSize ?? (string) ini_get( 'post_max_size' ) );
		return $limit > 0 ? max( 1, $limit - self::BODY_HEADROOM ) : 0;
	}

	/** The refusal for a file over the limit. */
	public static function sayTooBig(): string {
		/* translators: %s: the largest file allowed, e.g. "10 MB" */
		return sprintf( __( 'That file is over %s.', 'monstera' ), size_format( self::maxBytes() ) );
	}

	/** The refusal for a type off the allowlist. */
	public static function sayWrongType(): string {
		return __( "That kind of file can't be added. Use a PDF, an Office document, a CSV or text file, a zip or an image.", 'monstera' );
	}

	/** The refusal for more files than a message takes. */
	public static function sayTooMany(): string {
		return sprintf(
			/* translators: %d: how many files a message takes at most */
			_n( 'A message takes %d file at most. Remove the others and send again.', 'A message takes up to %d files. Remove some and send again.', self::maxCount(), 'monstera' ),
			self::maxCount()
		);
	}

	/** The limits in words, under the picker. */
	public static function limitsLine(): string {
		return sprintf(
			/* translators: 1: the largest file allowed, e.g. "10 MB", 2: how many files a message takes */
			__( 'PDF, Office, CSV, zip or images · %1$s each · up to %2$d', 'monstera' ),
			size_format( self::maxBytes() ),
			self::maxCount()
		);
	}

	/**
	 * The uploads of one file field as a list. PHP hands a field named
	 * files[] over transposed (every name, then every type, …) and counts a
	 * field left empty as a file that did not come; both are put right here.
	 *
	 * @param mixed $posted One entry of the request's files.
	 * @return list<array{name: string, type: string, tmp_name: string, error: int, size: int}>
	 */
	public static function normalise( $posted ): array {
		if ( ! is_array( $posted ) || ! isset( $posted['name'] ) ) {
			return [];
		}
		$slots = is_array( $posted['name'] ) ? array_keys( $posted['name'] ) : [ null ];
		$list  = [];
		foreach ( $slots as $slot ) {
			$pick   = static fn ( string $key ) => null === $slot ? ( $posted[ $key ] ?? null ) : ( $posted[ $key ][ $slot ] ?? null );
			$upload = [
				'name'     => (string) $pick( 'name' ),
				'type'     => (string) $pick( 'type' ),
				'tmp_name' => (string) $pick( 'tmp_name' ),
				'error'    => (int) ( $pick( 'error' ) ?? UPLOAD_ERR_NO_FILE ),
				'size'     => (int) $pick( 'size' ),
			];
			if ( UPLOAD_ERR_NO_FILE !== $upload['error'] ) {
				$list[] = $upload;
			}
		}
		return $list;
	}

	/**
	 * Why these uploads cannot go with a message, in words a member can act
	 * on that name the file, or null. Nothing is kept from a refused set.
	 *
	 * @param array<int, array<string, mixed>> $uploads As normalise() lists them.
	 */
	public static function refusal( array $uploads ): ?string {
		if ( count( $uploads ) > self::maxCount() ) {
			return self::sayTooMany();
		}
		foreach ( $uploads as $upload ) {
			$reason = self::refusalOf( $upload );
			if ( null !== $reason ) {
				/* translators: 1: a file's name, 2: why it cannot be sent, a full sentence */
				return sprintf( __( '%1$s: %2$s', 'monstera' ), SecureFiles::displayName( (string) ( $upload['name'] ?? '' ) ), $reason );
			}
		}
		return null;
	}

	/**
	 * @param array<string, mixed> $upload
	 */
	private static function refusalOf( array $upload ): ?string {
		$error = (int) ( $upload['error'] ?? UPLOAD_ERR_NO_FILE );
		// PHP refused the size before WordPress saw the file.
		if ( in_array( $error, [ UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ], true ) || (int) ( $upload['size'] ?? 0 ) > self::maxBytes() ) {
			return self::sayTooBig();
		}
		if ( UPLOAD_ERR_OK !== $error || empty( $upload['tmp_name'] ) || ! is_file( (string) $upload['tmp_name'] ) ) {
			return __( 'That file did not arrive. Choose it again.', 'monstera' );
		}
		if ( '' === SecureFiles::checkedType( $upload ) ) {
			return self::sayWrongType();
		}
		return null;
	}

	/**
	 * Keep the uploads refusal() let through as one message's files. All of
	 * them or none: when one cannot be stored, the ones before it are taken
	 * back and the failure is thrown on.
	 *
	 * @param array<string, mixed>                                                          $request   The request's row.
	 * @param int|null                                                                      $messageId The thread message they came with; null for the opening message.
	 * @param array<int, array{name: string, tmp_name: string, size: int, type?: string}> $uploads
	 * @return list<int> The file ids, in the order sent.
	 * @throws \RuntimeException When a file could not be moved or recorded.
	 */
	public function store( array $request, ?int $messageId, array $uploads, int $userId ): array {
		$files  = new SecureFiles();
		$folder = (string) preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $request['ref'] ?? '' ) );
		$dir    = SecureStorage::rootPath() . '/support/' . ( '' !== $folder ? $folder : 'request-' . (int) $request['id'] );
		$kept   = [];
		try {
			foreach ( $uploads as $upload ) {
				$kept[] = $files->put(
					$dir,
					$upload,
					[
						'content_id'         => 0,
						'support_request_id' => (int) $request['id'],
						'support_message_id' => $messageId,
						'uploaded_by'        => $userId,
						'original_name'      => SecureFiles::displayName( (string) $upload['name'] ),
						'mime_type'          => SecureFiles::checkedType( $upload ),
					]
				);
			}
		} catch ( \RuntimeException $failure ) {
			foreach ( $kept as $fileId ) {
				$files->delete( $fileId );
			}
			throw $failure;
		}
		return $kept;
	}

	/**
	 * A request's files by the message they came with (0 for the opening
	 * message), each list oldest first.
	 *
	 * @return array<int, list<array{id: int, name: string, size: int, type: string, is_image: bool, uploaded_by: string, uploaded_by_id: int, uploaded_at: string, message_id: int}>>
	 */
	public function forRequest( int $requestId ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE content_id = 0 AND support_request_id = %d ORDER BY created_at ASC, id ASC',
				Schema::tableName( Schema::TABLE_SECURE_FILES ),
				$requestId
			),
			ARRAY_A
		);
		$out  = [];
		foreach ( $rows as $row ) {
			$file                         = self::describe( $row );
			$out[ $file['message_id'] ][] = $file;
		}
		return $out;
	}

	/**
	 * One support file as callers see it with the request it belongs to, or
	 * null when the id is not a support file.
	 *
	 * @return array{id: int, name: string, size: int, type: string, is_image: bool, uploaded_by: string, uploaded_by_id: int, uploaded_at: string, message_id: int, request_id: int}|null
	 */
	public function find( int $fileId ): ?array {
		$row = ( new SecureFiles() )->findById( $fileId );
		if ( ! $row || 0 !== (int) $row['content_id'] || (int) ( $row['support_request_id'] ?? 0 ) <= 0 ) {
			return null;
		}
		return self::describe( $row ) + [ 'request_id' => (int) $row['support_request_id'] ];
	}

	/**
	 * A registry row as callers see it: never its path or storage name.
	 *
	 * @param array<string, mixed> $row
	 * @return array{id: int, name: string, size: int, type: string, is_image: bool, uploaded_by: string, uploaded_by_id: int, uploaded_at: string, message_id: int}
	 */
	private static function describe( array $row ): array {
		$userId = (int) ( $row['uploaded_by'] ?? 0 );
		$user   = $userId ? get_userdata( $userId ) : false;
		$type   = (string) $row['mime_type'];
		return [
			'id'             => (int) $row['id'],
			'name'           => (string) $row['original_name'],
			'size'           => (int) $row['filesize'],
			'type'           => $type,
			'is_image'       => self::isImage( $type ),
			'uploaded_by'    => $user ? UserMeta::fullName( $user ) : '',
			'uploaded_by_id' => $userId,
			'uploaded_at'    => $row['created_at'] ? gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['created_at'] . ' UTC' ) ) : '',
			'message_id'     => (int) ( $row['support_message_id'] ?? 0 ),
		];
	}
}
