<?php
/**
 * A support conversation's turns in the activity log.
 *
 * Opening a request, each reply, each status someone chose and each change
 * of priority is one row against the request, filed under the requester's
 * organization whoever acted, so the organization's feed, the member's and
 * the request's own all tell it. A status a reply moved by itself is not a
 * row: the reply's is. (A file opened from the thread is logged where it is
 * served, by the Downloader.)
 */

declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Hooks;
use Monstera\Reporting\ActivityLog;

defined( 'ABSPATH' ) || exit;

final class Activity {

	public const OBJECT = 'support_request';

	public static function register(): void {
		add_action( Hooks::SUPPORT_REQUEST_CREATED, [ self::class, 'onCreated' ], 10, 2 );
		add_action( Hooks::SUPPORT_MESSAGE_ADDED, [ self::class, 'onMessage' ], 10, 3 );
		add_action( Hooks::SUPPORT_STATUS_CHANGED, [ self::class, 'onStatus' ], 10, 6 );
		add_action( Hooks::SUPPORT_PRIORITY_CHANGED, [ self::class, 'onPriority' ], 10, 4 );
	}

	/**
	 * @param array<string, mixed>|null $row The request, as the hook passes it.
	 */
	public static function onCreated( int $id, ?array $row = null ): void {
		$row = $row ?: ( new Repository() )->find( $id );
		if ( $row ) {
			ActivityLog::record( 'support_request_opened', self::OBJECT, $id, self::context( $row, (int) $row['member_id'] ) );
		}
	}

	public static function onMessage( int $requestId, int $messageId, string $side ): void {
		$row     = ( new Repository() )->find( $requestId );
		$message = ( new Thread() )->find( $messageId );
		if ( $row && $message ) {
			ActivityLog::record( 'support_replied', self::OBJECT, $requestId, self::context( $row, $message['author_id'] ) + [ 'side' => $side ] );
		}
	}

	public static function onStatus( int $requestId, string $from, string $to, int $actorId, string $side, string $cause ): void {
		// A reply moved it: the reply is already a row.
		if ( Thread::CAUSE_MANUAL !== $cause ) {
			return;
		}
		$row = ( new Repository() )->find( $requestId );
		if ( $row ) {
			ActivityLog::record(
				'support_status_changed',
				self::OBJECT,
				$requestId,
				self::context( $row, $actorId ) + [
					'from' => $from,
					'to'   => $to,
					'side' => $side,
				]
			);
		}
	}

	public static function onPriority( int $requestId, string $from, string $to, int $actorId ): void {
		$row = ( new Repository() )->find( $requestId );
		if ( $row ) {
			ActivityLog::record(
				'support_priority_changed',
				self::OBJECT,
				$requestId,
				self::context( $row, $actorId ) + [
					'from' => $from,
					'to'   => $to,
				]
			);
		}
	}

	/**
	 * What every row about a request records: who acted, the requester's
	 * organization (none for a member on their own) and the reference, so a
	 * sentence can still name the request after it is gone.
	 *
	 * @param array<string, mixed> $row
	 * @return array{user_id: int, org_id: int, ref: string}
	 */
	private static function context( array $row, int $actorId ): array {
		return [
			'user_id' => $actorId,
			'org_id'  => (int) ( $row['org_id'] ?? 0 ),
			'ref'     => (string) $row['ref'],
		];
	}
}
