<?php
declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class SupportModule implements Module {

	public function slug(): string {
		return 'support';
	}

	public function boot(): void {
		// Requests are opened, read and answered through the REST controller
		// and the portal templates; each turn is also a row of activity.
		Activity::register();
	}

	public function registerPostTypes(): void {}
}
