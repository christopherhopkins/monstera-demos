<?php
declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Module;

final class SupportModule implements Module {

	public function slug(): string {
		return 'support';
	}

	public function boot(): void {
		// Submission and listing handled via REST controller + portal template.
	}

	public function registerPostTypes(): void {}
}
