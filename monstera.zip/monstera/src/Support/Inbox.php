<?php
/**
 * Where support reaches staff by email.
 *
 * One address, the Support email setting (the site's admin email until an
 * admin sets it): the default recipient of what members send, the Reply-To
 * on what members receive, and the address the portal shows under "Prefer
 * email?". The monstera/support_recipients filter can name other recipients
 * for a request.
 */

declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

final class Inbox {

	public const EMAIL_OPTION = 'monstera_support_email';

	/** The Support email setting, or the site's admin email. */
	public static function email(): string {
		$set = sanitize_email( (string) get_option( self::EMAIL_OPTION, '' ) );
		return '' !== $set && is_email( $set ) ? $set : (string) get_option( 'admin_email' );
	}

	/**
	 * Save the setting. An empty address puts the admin email back.
	 *
	 * @return bool False when the address is not one; nothing is changed.
	 */
	public static function setEmail( string $address ): bool {
		$address = trim( $address );
		if ( '' === $address ) {
			delete_option( self::EMAIL_OPTION );
			return true;
		}
		$clean = sanitize_email( $address );
		if ( '' === $clean || ! is_email( $clean ) ) {
			return false;
		}
		update_option( self::EMAIL_OPTION, $clean );
		return true;
	}

	/**
	 * Who hears about a request's news: the Support email, unless the
	 * filter names others. Only addresses, each once.
	 *
	 * @param array<string, mixed> $request The request's row.
	 * @return list<string>
	 */
	public static function recipients( array $request ): array {
		$list = (array) apply_filters( Hooks::FILTER_SUPPORT_RECIPIENTS, [ self::email() ], $request );
		$list = array_filter( array_map( 'sanitize_email', array_map( 'strval', $list ) ), 'is_email' );
		return array_values( array_unique( $list ) );
	}
}
