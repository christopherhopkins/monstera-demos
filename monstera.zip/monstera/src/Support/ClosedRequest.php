<?php
/**
 * A member tried to change a request that is closed.
 *
 * A closed request takes no priority change and no "resolved" from its
 * member until it is open again: by their reply, or by staff. The
 * repository throws this so a caller can tell "closed" from "not found".
 */

declare(strict_types=1);

namespace Monstera\Support;

defined( 'ABSPATH' ) || exit;

final class ClosedRequest extends \DomainException {
}
