<?php
/**
 * A support request's thread: what came after its opening message.
 *
 * An entry is a message (what a side wrote) or an event (a change of status
 * or priority: who made it, the old and new value, and whether a reply
 * caused it or someone chose it). Entries are read oldest first. The
 * opening message is the request's own row, so a request nobody has
 * answered has an empty thread.
 */

declare(strict_types=1);

namespace Monstera\Support;

use Monstera\Core\Database\Schema;

defined( 'ABSPATH' ) || exit;

final class Thread {

	public const KIND_MESSAGE = 'message';
	public const KIND_EVENT   = 'event';

	public const SIDE_MEMBER = 'member';
	public const SIDE_STAFF  = 'staff';

	public const EVENT_STATUS   = 'status';
	public const EVENT_PRIORITY = 'priority';

	public const CAUSE_REPLY  = 'reply';
	public const CAUSE_MANUAL = 'manual';

	/**
	 * @return int The entry's id, or 0 when it could not be written.
	 */
	public function addMessage( int $requestId, int $authorId, string $side, string $body ): int {
		return $this->insert(
			[
				'request_id' => $requestId,
				'kind'       => self::KIND_MESSAGE,
				'author_id'  => $authorId,
				'side'       => $side,
				'body'       => $body,
			]
		);
	}

	/**
	 * @return int The entry's id, or 0 when it could not be written.
	 */
	public function addEvent( int $requestId, int $actorId, string $side, string $type, string $from, string $to, string $cause = self::CAUSE_MANUAL ): int {
		return $this->insert(
			[
				'request_id' => $requestId,
				'kind'       => self::KIND_EVENT,
				'author_id'  => $actorId,
				'side'       => $side,
				'event_data' => (string) wp_json_encode(
					[
						'type'  => $type,
						'from'  => $from,
						'to'    => $to,
						'cause' => $cause,
					]
				),
			]
		);
	}

	/** Take an entry back: a message whose files could not be kept. */
	public function remove( int $entryId ): void {
		global $wpdb;
		$wpdb->delete( Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ), [ 'id' => $entryId ], [ '%d' ] );
	}

	/**
	 * One entry, or null when there is none by that id.
	 *
	 * @return array{id: int, kind: string, author_id: int, side: string, body: string, event: array{type: string, from: string, to: string, cause: string}|null, created_at: string}|null
	 */
	public function find( int $entryId ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ), $entryId ), ARRAY_A );
		return $row ? self::describe( $row ) : null;
	}

	/**
	 * A request's entries, oldest first.
	 *
	 * @return list<array{id: int, kind: string, author_id: int, side: string, body: string, event: array{type: string, from: string, to: string, cause: string}|null, created_at: string}>
	 */
	public function entries( int $requestId ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE request_id = %d ORDER BY created_at ASC, id ASC',
				Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ),
				$requestId
			),
			ARRAY_A
		);
		return array_map( [ self::class, 'describe' ], $rows );
	}

	/**
	 * Who wrote or changed something last in each request's thread. A
	 * request nobody has answered is not in the answer: its member acted
	 * last, by sending it.
	 *
	 * @param list<int> $requestIds
	 * @return array<int, int> Request id => user id.
	 */
	public function lastActors( array $requestIds ): array {
		return array_map( static fn ( array $entry ): int => $entry['author_id'], $this->lastEntries( $requestIds ) );
	}

	/**
	 * The latest entry of each request's thread. A request nobody has
	 * answered is not in the answer.
	 *
	 * @param list<int> $requestIds
	 * @return array<int, array{id: int, kind: string, author_id: int, side: string, body: string, event: array{type: string, from: string, to: string, cause: string}|null, created_at: string}> By request id.
	 */
	public function lastEntries( array $requestIds ): array {
		$requestIds = array_values( array_unique( array_filter( array_map( 'intval', $requestIds ) ) ) );
		if ( ! $requestIds ) {
			return [];
		}
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES );
		$marks = implode( ',', array_fill( 0, count( $requestIds ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $requestIds ); every id goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT m.* FROM %i AS m JOIN ( SELECT MAX(id) AS id FROM %i WHERE request_id IN ($marks) GROUP BY request_id ) AS latest ON latest.id = m.id",
				$table,
				$table,
				...$requestIds
			),
			ARRAY_A
		);
		// phpcs:enable
		$out = [];
		foreach ( $rows as $row ) {
			$out[ (int) $row['request_id'] ] = self::describe( $row );
		}
		return $out;
	}

	/**
	 * @param array<string, int|string> $columns
	 */
	private function insert( array $columns ): int {
		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ),
			// UTC, as every reader takes it: the column's default is the
			// database's own clock.
			$columns + [ 'created_at' => current_time( 'mysql', true ) ]
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * @param array<string, mixed> $row
	 * @return array{id: int, kind: string, author_id: int, side: string, body: string, event: array{type: string, from: string, to: string, cause: string}|null, created_at: string}
	 */
	private static function describe( array $row ): array {
		$event = null;
		if ( self::KIND_EVENT === $row['kind'] ) {
			$data  = json_decode( (string) ( $row['event_data'] ?? '' ), true );
			$data  = is_array( $data ) ? $data : [];
			$event = [
				'type'  => (string) ( $data['type'] ?? '' ),
				'from'  => (string) ( $data['from'] ?? '' ),
				'to'    => (string) ( $data['to'] ?? '' ),
				'cause' => (string) ( $data['cause'] ?? self::CAUSE_MANUAL ),
			];
		}
		return [
			'id'         => (int) $row['id'],
			'kind'       => (string) $row['kind'],
			'author_id'  => (int) ( $row['author_id'] ?? 0 ),
			'side'       => (string) $row['side'],
			'body'       => (string) ( $row['body'] ?? '' ),
			'event'      => $event,
			'created_at' => gmdate( 'Y-m-d\TH:i:s\Z', (int) strtotime( $row['created_at'] . ' UTC' ) ),
		];
	}
}
