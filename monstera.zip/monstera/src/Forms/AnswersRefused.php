<?php
declare(strict_types=1);

namespace Monstera\Forms;

defined( 'ABSPATH' ) || exit;

/**
 * A submission refused for its answers: a required question left empty, a
 * number that is not one, a choice outside the options, a date that is no
 * date. Every field's complaint comes at once, by question key, so the form
 * page can place each beside its field; nothing is stored.
 */
final class AnswersRefused extends \InvalidArgumentException {

	/** @var array<string, string> By question key, one sentence each. */
	public array $errors;

	/** @param array<string, string> $errors */
	public function __construct( array $errors ) {
		parent::__construct( esc_html( (string) reset( $errors ) ) );
		$this->errors = $errors;
	}
}
