<?php
/**
 * A submission's answers as text (Forms-and-resources track, FR5, FR6):
 * what the form's page and Manage › Submissions say of one, the same way.
 *
 * @package Monstera
 */

declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Portal\CalendarDay;

defined( 'ABSPATH' ) || exit;

final class Answers {

	/**
	 * A question's answer as text: a date on the calendar, anything else as
	 * sent; a file question's files are listed by the caller.
	 *
	 * @param array<string, mixed> $question One of Meta::fieldsOf().
	 * @param array<string, mixed> $answers  The submission's, by key.
	 */
	public static function text( array $question, array $answers ): string {
		$value = $answers[ (string) $question['key'] ] ?? '';
		if ( is_array( $value ) ) {
			return '';
		}
		$value = (string) $value;
		if ( '' === $value ) {
			return '';
		}
		if ( 'date' === $question['type'] ) {
			return CalendarDay::format( $value, 'M j, Y' ) ?: $value;
		}
		return $value;
	}

	/**
	 * One line for a submission: its first two short answers, then how many
	 * files it carries; "Sent" when it says nothing short.
	 *
	 * @param list<array<string, mixed>>               $fields  Meta::fieldsOf().
	 * @param array<string, mixed>                     $row     Submissions::find()'s shape.
	 * @param array<string, list<array<string, mixed>>> $files   Submissions::filesOf() for the row.
	 */
	public static function summary( array $fields, array $row, array $files ): string {
		$parts = [];
		$count = 0;
		foreach ( $fields as $question ) {
			if ( 'file' === $question['type'] ) {
				$count += count( $files[ (string) $question['key'] ] ?? [] );
				continue;
			}
			if ( count( $parts ) >= 2 || 'textarea' === $question['type'] ) {
				continue;
			}
			$text = self::text( $question, (array) $row['answers'] );
			if ( '' !== $text ) {
				$parts[] = $text;
			}
		}
		if ( $count > 0 ) {
			/* translators: %d: how many files */
			$parts[] = sprintf( _n( '%d file', '%d files', $count, 'monstera' ), $count );
		}
		return $parts ? implode( ' · ', $parts ) : __( 'Sent', 'monstera' );
	}
}
