<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Routing;
use Monstera\Reporting\Tracking;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * The portal's form links go through /portal/forms/{id}/open/, which logs
 * the open and sends the member on to the PDF or the external page, so the
 * admin can see how often a resource is used. A form the member cannot see
 * is refused, never revealed, and so is a file that is waiting on an
 * organization: the page prints no link to it, and an old link of this
 * kind does not open it.
 *
 * That is as far as the wait reaches. A resource's PDF is a Media Library
 * file (Repository::renderAction() says why), and this route redirects to
 * the file's own address in the uploads folder, which WordPress serves to
 * anyone who has it, signed in or not. Someone who opened the file once
 * (their browser's history, a forwarded link) opens it again whatever the
 * portal says of their organization since. A content item's file is the
 * one that is streamed behind a check (Content\Downloader).
 */
final class Opener {

	/**
	 * Where the member goes for this form, or null when they cannot see it,
	 * its file waits (Repository::fileWaits()) or it has nowhere to go (an
	 * embedded form renders on the Resources page instead). Records the open.
	 */
	public static function target( WP_User $user, int $formId ): ?string {
		// A link from the Resources page opens for whoever that page opens
		// for: the guard answers for the pages the router renders, and this
		// route is not one of them.
		if ( null !== PortalGuard::blockedReason( $user, Routing::ROUTE_FORMS ) ) {
			return null;
		}
		$forms   = new Repository();
		$visible = array_map( static fn ( $post ) => (int) $post->ID, $forms->visibleTo( $user ) );
		if ( ! in_array( $formId, $visible, true ) || $forms->fileWaits( $user, $formId ) ) {
			return null;
		}
		$type = (string) get_post_meta( $formId, Meta::KEY_FORM_TYPE, true ) ?: Meta::TYPE_PDF;
		$url  = match ( $type ) {
			Meta::TYPE_PDF      => (string) wp_get_attachment_url( (int) get_post_meta( $formId, Meta::KEY_PDF_FILE_ID, true ) ),
			Meta::TYPE_EXTERNAL => (string) get_post_meta( $formId, Meta::KEY_EXTERNAL_URL, true ),
			default             => '',
		};
		if ( '' === $url ) {
			return null;
		}
		Tracking::formOpened( $formId, $user->ID );
		return $url;
	}

	/** The route's handler: redirect, or a 404 that says nothing about the form. */
	public static function handle( int $formId ): void {
		$user = wp_get_current_user();
		$url  = $user->exists() ? self::target( $user, $formId ) : null;
		if ( null === $url ) {
			wp_die(
				esc_html__( 'This resource is not available to you.', 'monstera' ),
				esc_html__( 'Not available', 'monstera' ),
				[ 'response' => 404 ]
			);
		}
		// External links are the admin's own configured URLs, so wp_redirect
		// rather than the same-host-only wp_safe_redirect.
		wp_redirect( esc_url_raw( $url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- the destination is the form's own saved PDF or external URL.
		exit;
	}
}
