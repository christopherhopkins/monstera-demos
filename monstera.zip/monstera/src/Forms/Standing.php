<?php
declare(strict_types=1);

namespace Monstera\Forms;

use WP_Post;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Where a form stands for one person, for the rows that list it (the Forms
 * page, a hub's Forms tab; Forms-and-resources track, FR5): the group it
 * falls in and the one action it offers, by the rule the send is judged by
 * (Accepts::reasonFor()).
 *
 *  - Due: a built form with a due day ahead that still accepts and that
 *    they have not sent.
 *  - Open: the rest that accept, an embedded form always (Monstera does
 *    not see the other plugin's submissions, so it is never Sent).
 *  - Sent: a once-only form they have sent, and a form that no longer
 *    accepts (closed, or its due day passed) that they sent at least once.
 *
 * A form that no longer accepts and that they never sent stands nowhere:
 * it is not listed. Whether the form reaches them at all is the
 * repository's question, asked before this one.
 *
 * A suspended organization's forms stand as any other's: the send is not
 * refused for a suspension (Accepts), so the row offers it (the Task 3
 * review, 2026-10-28; the owner may decide otherwise at the form page,
 * where the send is built).
 *
 * @phpstan-type FormStanding array{group: string, action: string, due_on: string, closed_on: string, sent_at: string, sent: int}
 */
final class Standing {

	public const GROUP_DUE  = 'due';
	public const GROUP_OPEN = 'open';
	public const GROUP_SENT = 'sent';

	public const ACTION_FILL   = 'fill';
	public const ACTION_VIEW   = 'view';
	public const ACTION_CLOSED = 'closed';

	/**
	 * Where each of these forms stands for the person, in one read of what
	 * they have sent (Submissions::mineAcross()).
	 *
	 * @param WP_Post[] $forms
	 * @return array<int, FormStanding> By form id; a form that stands nowhere is left out. `sent_at` is the newest submission's time (UTC, MySQL) or ''; `closed_on` the day it closed when its due day is what closed it, else ''.
	 */
	public static function ofEach( WP_User $user, array $forms ): array {
		$mine = Submissions::mineAcross( array_map( static fn ( WP_Post $form ): int => (int) $form->ID, $forms ), (int) $user->ID );
		$out  = [];
		foreach ( $forms as $form ) {
			$formId   = (int) $form->ID;
			$standing = self::from(
				$formId,
				$mine[ $formId ] ?? [
					'sent'    => 0,
					'sent_at' => '',
				]
			);
			if ( null !== $standing ) {
				$out[ $formId ] = $standing;
			}
		}
		return $out;
	}

	/**
	 * Where one form stands for the person, or null when it stands nowhere.
	 *
	 * @return FormStanding|null
	 */
	public static function of( WP_User $user, int $formId ): ?array {
		$form = get_post( $formId );
		return $form instanceof WP_Post ? ( self::ofEach( $user, [ $form ] )[ $formId ] ?? null ) : null;
	}

	/**
	 * @param array{sent: int, sent_at: string} $mine
	 * @return FormStanding|null
	 */
	private static function from( int $formId, array $mine ): ?array {
		$row = [
			'group'     => self::GROUP_OPEN,
			'action'    => self::ACTION_FILL,
			'due_on'    => '',
			'closed_on' => '',
			'sent_at'   => '',
			'sent'      => 0,
		];
		if ( Meta::KIND_BUILT !== Meta::kindOf( $formId ) ) {
			return $row;
		}
		$row['due_on']  = Meta::dueOn( $formId );
		$row['sent_at'] = $mine['sent'] > 0 ? $mine['sent_at'] : '';
		$row['sent']    = $mine['sent'];
		switch ( Accepts::reasonFor( $formId, $mine['sent'] > 0 ) ) {
			case Accepts::CLOSED:
			case Accepts::DUE_PASSED:
				if ( 0 === $mine['sent'] ) {
					return null;
				}
				$row['group']     = self::GROUP_SENT;
				$row['action']    = self::ACTION_CLOSED;
				$row['closed_on'] = Meta::accepting( $formId ) ? $row['due_on'] : '';
				return $row;
			case Accepts::ALREADY_SENT:
				$row['group']  = self::GROUP_SENT;
				$row['action'] = self::ACTION_VIEW;
				return $row;
			default:
				if ( '' !== $row['due_on'] && 0 === $mine['sent'] ) {
					$row['group'] = self::GROUP_DUE;
				}
				return $row;
		}
	}
}
