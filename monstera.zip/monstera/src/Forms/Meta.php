<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Core\Capabilities;
use Monstera\Core\SiteDay;
use WP_Post;

defined( 'ABSPATH' ) || exit;

/**
 * A form's meta (Forms-and-resources track, FR3). A form is built in
 * Monstera from the discovery question model, or embeds another plugin's
 * shortcode. A built form has a sub-line, an intro (the post content, block
 * markup), its questions, the people each submission is emailed to, and
 * its settings: accepting or closed with a closed message, a confirmation
 * sentence, once-only, a due day (a day on the site's calendar that closes
 * the form at its end) and whether to remind. The audience keys are the
 * library's four, kept by name; with nothing chosen a form reaches every
 * member. Until 2026-10-26 this meta was the library's (a PDF, a link or
 * a shortcode), which Resources\Meta carries now.
 */
final class Meta {

	public const KIND_BUILT = 'built';
	public const KIND_EMBED = 'embed';
	public const KINDS      = [ self::KIND_BUILT, self::KIND_EMBED ];

	public const KEY_KIND               = 'monstera_form_kind';
	public const KEY_DESCRIPTION        = 'monstera_form_description';
	public const KEY_FIELDS             = 'monstera_form_fields';
	public const KEY_SHORTCODE          = 'monstera_form_shortcode';
	public const KEY_RECIPIENTS         = 'monstera_form_recipients';
	public const KEY_ACCEPTING          = 'monstera_form_accepting';
	public const KEY_CLOSED_MESSAGE     = 'monstera_form_closed_message';
	public const KEY_CONFIRMATION       = 'monstera_form_confirmation';
	public const KEY_ONCE_ONLY          = 'monstera_form_once_only';
	public const KEY_DUE_ON             = 'monstera_form_due_on';
	public const KEY_REMIND             = 'monstera_form_remind';
	public const KEY_ROLES              = 'monstera_form_allowed_roles';
	public const KEY_ORGS               = 'monstera_form_allowed_orgs';
	public const KEY_STANDALONE_MEMBERS = 'monstera_form_allowed_standalone_members';
	public const KEY_SUBGROUPS          = 'monstera_form_allowed_subgroups';
	public const KEY_BUILT_BY           = 'monstera_form_built_by';

	/** The most addresses a form emails (its leads aside, who have their own switch). */
	public const MAX_EMAILS = 10;

	public const BUILT_BY_TEAM         = 'team';
	public const BUILT_BY_ORGANIZATION = 'organization';

	/**
	 * Whose form it is, settled once when it is first saved: the team's
	 * when its author could manage Monstera then, else the organization's
	 * (stampBuiltBy()). A role changed later moves nothing.
	 */
	public static function builtByTeam( int $formId ): bool {
		return self::BUILT_BY_ORGANIZATION !== get_post_meta( $formId, self::KEY_BUILT_BY, true );
	}

	/**
	 * Whether the leads of the organizations a form reaches read what their
	 * members sent to it: only for one their organization built (FR6). A
	 * form with no stamp reads as the team's, the closed side.
	 */
	public static function openToLeads( int $formId ): bool {
		return ! self::builtByTeam( $formId );
	}

	/**
	 * `wp_insert_post`: stamps a new form with whose it is, by its author's
	 * role at that moment. Every path that makes a form passes here.
	 */
	public static function stampBuiltBy( int $postId, WP_Post $post, bool $update ): void {
		if ( $update || PostType::SLUG !== $post->post_type || '' !== (string) get_post_meta( $postId, self::KEY_BUILT_BY, true ) ) {
			return;
		}
		$author = (int) $post->post_author;
		$team   = $author <= 0 || user_can( $author, Capabilities::CAP_MANAGE_MONSTERA );
		update_post_meta( $postId, self::KEY_BUILT_BY, $team ? self::BUILT_BY_TEAM : self::BUILT_BY_ORGANIZATION );
	}

	/** The form's kind, built when none was ever written. */
	public static function kindOf( int $formId ): string {
		$kind = (string) get_post_meta( $formId, self::KEY_KIND, true );
		return in_array( $kind, self::KINDS, true ) ? $kind : self::KIND_BUILT;
	}

	/**
	 * The questions, in order, tidied as Fields::tidy() has them.
	 *
	 * @return list<array{key: string, label: string, type: string, options: list<string>, required: bool, help: string}>
	 */
	public static function fieldsOf( int $formId ): array {
		$raw = (string) get_post_meta( $formId, self::KEY_FIELDS, true );
		return '' === $raw ? [] : Fields::tidy( json_decode( $raw, true ) );
	}

	/**
	 * Stores a validated question list (Fields::validate()).
	 *
	 * @param list<array<string, mixed>> $fields
	 */
	public static function saveFields( int $formId, array $fields ): void {
		update_post_meta( $formId, self::KEY_FIELDS, wp_slash( (string) wp_json_encode( array_values( $fields ) ) ) );
	}

	/**
	 * Who is emailed each submission: addresses, and whether the admins and
	 * managers of the organization the member sent it through are too.
	 *
	 * @return array{emails: list<string>, org_leads: bool}
	 */
	public static function recipientsOf( int $formId ): array {
		return self::tidyRecipients( get_post_meta( $formId, self::KEY_RECIPIENTS, true ) );
	}

	/**
	 * @param mixed $value As stored or as sent.
	 * @return array{emails: list<string>, org_leads: bool}
	 */
	public static function tidyRecipients( mixed $value ): array {
		$value  = is_array( $value ) ? $value : [];
		$emails = [];
		foreach ( (array) ( $value['emails'] ?? [] ) as $email ) {
			$email = strtolower( trim( sanitize_email( (string) $email ) ) );
			if ( '' !== $email && is_email( $email ) && ! in_array( $email, $emails, true ) ) {
				$emails[] = $email;
			}
		}
		// The routes refuse more (FormsController::refusal()); never more are kept.
		$emails = array_slice( $emails, 0, self::MAX_EMAILS );
		return [
			'emails'    => $emails,
			'org_leads' => self::truthy( $value['org_leads'] ?? false ),
		];
	}

	/** Accepting until the author closes it. */
	public static function accepting( int $formId ): bool {
		$raw = get_post_meta( $formId, self::KEY_ACCEPTING, true );
		return '' === $raw || null === $raw ? true : self::truthy( $raw );
	}

	public static function onceOnly( int $formId ): bool {
		return self::truthy( get_post_meta( $formId, self::KEY_ONCE_ONLY, true ) );
	}

	/** The due day as Y-m-d on the site's calendar, or '' for none. */
	public static function dueOn( int $formId ): string {
		$raw = (string) get_post_meta( $formId, self::KEY_DUE_ON, true );
		return SiteDay::isDay( $raw ) ? $raw : '';
	}

	/** Reminders go while a due day is set, unless turned off. */
	public static function remind( int $formId ): bool {
		return '' !== self::dueOn( $formId ) && self::remindWanted( $formId );
	}

	/** Whether the author wants reminders: on unless turned off, due day or none. */
	public static function remindWanted( int $formId ): bool {
		$raw = get_post_meta( $formId, self::KEY_REMIND, true );
		return '' === $raw || null === $raw ? true : self::truthy( $raw );
	}

	/** The sentence shown and emailed after sending. */
	public static function confirmationOf( int $formId ): string {
		$own = trim( (string) get_post_meta( $formId, self::KEY_CONFIRMATION, true ) );
		return '' !== $own ? $own : __( 'Thanks, we have your answers.', 'monstera' );
	}

	/** What a closed form says in place of Send. */
	public static function closedMessageOf( int $formId ): string {
		$own = trim( (string) get_post_meta( $formId, self::KEY_CLOSED_MESSAGE, true ) );
		return '' !== $own ? $own : __( 'This form is closed.', 'monstera' );
	}

	/** A stored or sent flag: '1', 1, true, 'true' and 'on' are on. */
	public static function truthy( mixed $value ): bool {
		return is_bool( $value ) ? $value : in_array( strtolower( trim( (string) $value ) ), [ '1', 'true', 'on', 'yes' ], true );
	}

	public static function register(): void {
		$string = static fn ( string $key, callable $sanitize ) => register_post_meta(
			PostType::SLUG,
			$key,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => $sanitize,
			]
		);
		$list   = static fn ( string $key, callable $each ) => register_post_meta(
			PostType::SLUG,
			$key,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => array_map( $each, (array) $v ),
			]
		);

		$string( self::KEY_KIND, static fn ( $v ): string => in_array( $v, self::KINDS, true ) ? (string) $v : self::KIND_BUILT );
		$string( self::KEY_DESCRIPTION, static fn ( $v ): string => sanitize_text_field( (string) $v ) );
		$string( self::KEY_FIELDS, static fn ( $v ): string => (string) wp_json_encode( Fields::tidy( json_decode( (string) $v, true ) ) ) );
		$string( self::KEY_SHORTCODE, static fn ( $v ): string => wp_kses_post( (string) $v ) );
		register_post_meta(
			PostType::SLUG,
			self::KEY_RECIPIENTS,
			[
				'type'              => 'object',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ): array => self::tidyRecipients( $v ),
			]
		);
		$string( self::KEY_ACCEPTING, static fn ( $v ): string => self::truthy( $v ) ? '1' : '0' );
		$string( self::KEY_CLOSED_MESSAGE, static fn ( $v ): string => sanitize_text_field( (string) $v ) );
		$string( self::KEY_CONFIRMATION, static fn ( $v ): string => sanitize_text_field( (string) $v ) );
		$string( self::KEY_ONCE_ONLY, static fn ( $v ): string => self::truthy( $v ) ? '1' : '0' );
		$string( self::KEY_DUE_ON, static fn ( $v ): string => SiteDay::isDay( trim( (string) $v ) ) ? trim( (string) $v ) : '' );
		$string( self::KEY_REMIND, static fn ( $v ): string => self::truthy( $v ) ? '1' : '0' );
		$string( self::KEY_BUILT_BY, static fn ( $v ): string => self::BUILT_BY_ORGANIZATION === $v ? self::BUILT_BY_ORGANIZATION : self::BUILT_BY_TEAM );
		$list( self::KEY_ROLES, 'sanitize_key' );
		$list( self::KEY_ORGS, 'absint' );
		$list( self::KEY_STANDALONE_MEMBERS, 'absint' );
		$list( self::KEY_SUBGROUPS, 'absint' );
	}
}
