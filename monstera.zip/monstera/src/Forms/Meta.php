<?php
declare(strict_types=1);

namespace Monstera\Forms;

final class Meta {

	public const TYPE_PDF       = 'pdf';
	public const TYPE_SHORTCODE = 'shortcode';
	public const TYPE_EXTERNAL  = 'external';

	public const KEY_FORM_TYPE          = 'monstera_form_type';
	public const KEY_DESCRIPTION        = 'monstera_form_description';
	public const KEY_PDF_FILE_ID        = 'monstera_form_pdf_id';
	public const KEY_SHORTCODE          = 'monstera_form_shortcode';
	public const KEY_EXTERNAL_URL       = 'monstera_form_external_url';
	public const KEY_ROLES              = 'monstera_form_allowed_roles';
	public const KEY_ORGS               = 'monstera_form_allowed_orgs';
	public const KEY_STANDALONE_MEMBERS = 'monstera_form_allowed_standalone_members';
	public const KEY_SUBGROUPS          = 'monstera_form_allowed_subgroups';

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_FORM_TYPE,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::TYPE_PDF,
				'show_in_rest'      => [ 'schema' => [ 'enum' => [ self::TYPE_PDF, self::TYPE_SHORTCODE, self::TYPE_EXTERNAL ] ] ],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ self::TYPE_PDF, self::TYPE_SHORTCODE, self::TYPE_EXTERNAL ], true ) ? $v : self::TYPE_PDF,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_DESCRIPTION,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'wp_kses_post',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_PDF_FILE_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SHORTCODE,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'wp_kses_post',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_EXTERNAL_URL,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'esc_url_raw',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ROLES,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'string' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'sanitize_key', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ORGS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBERS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SUBGROUPS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);
	}
}
