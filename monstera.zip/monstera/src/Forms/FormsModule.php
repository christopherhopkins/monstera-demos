<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Core\Module;

final class FormsModule implements Module {

	public function slug(): string {
		return 'forms';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
	}

	public function registerPostTypes(): void {
		PostType::register();
	}
}
