<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\BackgroundSync\Cron;
use Monstera\BackgroundSync\Tasks\FormReminders;
use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class FormsModule implements Module {

	public function slug(): string {
		return 'forms';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		// Whose form it is, settled when it is first saved (Meta::builtByTeam()).
		add_action( 'wp_insert_post', [ Meta::class, 'stampBuiltBy' ], 10, 3 );
		// The due reminders go from their own daily event (Forms-and-resources track, FR9).
		add_action( Cron::DAILY_FORM_REMINDERS, [ FormReminders::class, 'dispatch' ] );
	}

	public function registerPostTypes(): void {
		PostType::register();
	}
}
