<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Core\Capabilities;

final class PostType {

	public const SLUG = 'monstera_form';

	public static function register(): void {
		register_post_type(
			self::SLUG,
			[
				'labels'          => [
					'name'          => __( 'Form Resources', 'monstera' ),
					'singular_name' => __( 'Form Resource', 'monstera' ),
					'add_new'       => __( 'Add resource', 'monstera' ),
					'add_new_item'  => __( 'Add resource', 'monstera' ),
					'edit_item'     => __( 'Edit resource', 'monstera' ),
					'search_items'  => __( 'Search resources', 'monstera' ),
					'not_found'     => __( 'No resources yet.', 'monstera' ),
				],
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				'show_in_rest'    => true,
				'rest_base'       => 'forms',
				'supports'        => [ 'title', 'editor' ],
				'has_archive'     => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'capabilities'    => [
					'edit_posts'         => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'  => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}
}
