<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Core\SiteDay;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Whether a form takes a submission from a person, and why not when it
 * does not (Forms-and-resources track, FR3): the form page says which, and
 * the submit route answers 409 with the same word. In order: a form that
 * does not reach the person (unpublished, out of their audience, or an
 * embedded form, which takes nothing through Monstera) is simply not
 * reached; one closed by its author is closed; one whose due day has
 * passed, the day ending at the end of that site day, is past due; one
 * that takes one submission a person and has theirs is already sent.
 */
final class Accepts {

	public const OK           = 'ok';
	public const NOT_REACHED  = 'not_reached';
	public const CLOSED       = 'closed';
	public const DUE_PASSED   = 'due_passed';
	public const ALREADY_SENT = 'already_sent';

	public static function for( WP_User $user, int $formId ): string {
		$visible = array_map( static fn ( $post ): int => (int) $post->ID, ( new Repository() )->visibleTo( $user ) );
		if ( ! in_array( $formId, $visible, true ) || Meta::KIND_BUILT !== Meta::kindOf( $formId ) ) {
			return self::NOT_REACHED;
		}
		return self::reasonFor( $formId, self::hasSent( $formId, (int) $user->ID ) );
	}

	/**
	 * Why a built form that reaches a person takes nothing from them, or OK:
	 * the one rule, read here for the send and by Forms\Standing for the
	 * rows that list the form, so the two never drift. Whether they have
	 * sent it before is the caller's to know.
	 */
	public static function reasonFor( int $formId, bool $hasSent ): string {
		if ( ! Meta::accepting( $formId ) ) {
			return self::CLOSED;
		}
		$due = Meta::dueOn( $formId );
		if ( '' !== $due && SiteDay::hasPassed( $due ) ) {
			return self::DUE_PASSED;
		}
		if ( $hasSent && Meta::onceOnly( $formId ) ) {
			return self::ALREADY_SENT;
		}
		return self::OK;
	}

	/** Whether the person has sent this form before. */
	private static function hasSent( int $formId, int $userId ): bool {
		return Submissions::hasSent( $formId, $userId );
	}
}
