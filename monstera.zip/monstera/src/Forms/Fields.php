<?php
declare(strict_types=1);

namespace Monstera\Forms;

defined( 'ABSPATH' ) || exit;

/**
 * The questions a form asks, in the discovery intake's shape: a key, a
 * label, a type, the options of a choice, whether it is required, a help
 * line. One rule validates both a form's questions and a project's intake
 * (Projects\Discovery delegates here), so the builder the two share saves
 * the same thing to each (Forms-and-resources track, FR3).
 */
final class Fields {

	/** The kinds of question; `select` is the one with options, `file` is answered by files. */
	public const TYPES = [ 'text', 'textarea', 'number', 'select', 'date', 'file' ];

	/** The most questions a form asks. */
	public const MAX = 50;

	/**
	 * A question list checked and tidied for saving, or why it cannot be
	 * saved, in words that name the question ("Question 2, “Budget band”:
	 * …"). Each question needs a label and a known type; a choice (select)
	 * needs at least one option; required is true or false; keys are unique,
	 * and a new question without one gets one from its label.
	 *
	 * @param mixed $schema The list as the request sent it.
	 * @param int   $max    The most questions allowed; a form's cap by default, none for an intake.
	 * @param list<string> $reserved Keys stored answers or files are held under (Submissions::answerCounts()):
	 *                               a new question never takes one, or the old answers would read as its.
	 * @return list<array{key: string, label: string, type: string, options: list<string>, required: bool, help: string}>|string
	 */
	public static function validate( mixed $schema, int $max = self::MAX, array $reserved = [] ): array|string {
		if ( ! is_array( $schema ) || ! $schema ) {
			return __( 'A form needs at least one question.', 'monstera' );
		}
		if ( count( $schema ) > $max ) {
			/* translators: %d: the most questions a form asks */
			return sprintf( __( 'A form asks at most %d questions.', 'monstera' ), $max );
		}
		$out   = [];
		$seen  = [];
		$taken = array_fill_keys( $reserved, true );
		foreach ( array_values( $schema ) as $index => $question ) {
			$number = $index + 1;
			$label  = is_array( $question ) ? trim( sanitize_text_field( (string) ( $question['label'] ?? '' ) ) ) : '';
			$named  = '' !== $label
				/* translators: 1: the question's number, 2: its text */
				? sprintf( __( 'Question %1$d, “%2$s”', 'monstera' ), $number, $label )
				/* translators: %d: the question's number */
				: sprintf( __( 'Question %d', 'monstera' ), $number );
			if ( '' === $label ) {
				/* translators: %s: which question, e.g. "Question 3" */
				return sprintf( __( '%s: write the question.', 'monstera' ), $named );
			}
			$type = (string) ( $question['type'] ?? 'text' );
			if ( ! in_array( $type, self::TYPES, true ) ) {
				/* translators: %s: which question, e.g. "Question 3, “Budget”" */
				return sprintf( __( '%s: choose a type from the list.', 'monstera' ), $named );
			}
			$required = $question['required'] ?? false;
			if ( ! is_bool( $required ) ) {
				/* translators: %s: which question */
				return sprintf( __( '%s: required must be on or off.', 'monstera' ), $named );
			}
			$options = [];
			if ( 'select' === $type ) {
				foreach ( (array) ( $question['options'] ?? [] ) as $option ) {
					$option = trim( sanitize_text_field( (string) $option ) );
					if ( '' !== $option ) {
						$options[] = $option;
					}
				}
				$options = array_values( array_unique( $options ) );
				if ( ! $options ) {
					/* translators: %s: which question */
					return sprintf( __( '%s: give a choice at least one option.', 'monstera' ), $named );
				}
			}
			// At most 128 characters, the width of the answers' key column.
			$key = substr( sanitize_key( (string) ( $question['key'] ?? '' ) ), 0, 128 );
			if ( '' === $key ) {
				// A new question: a key from its label, numbered past any clash.
				$base = substr( str_replace( '-', '_', sanitize_title( $label ) ), 0, 120 ) ?: 'question';
				$key  = $base;
				for ( $n = 2; isset( $seen[ $key ] ) || isset( $taken[ $key ] ); $n++ ) {
					$key = $base . '_' . $n;
				}
			} elseif ( isset( $seen[ $key ] ) ) {
				/* translators: %s: which question */
				return sprintf( __( '%s: another question already uses its key.', 'monstera' ), $named );
			}
			$seen[ $key ] = true;
			$out[]        = [
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'options'  => $options,
				'required' => $required,
				'help'     => sanitize_text_field( (string) ( $question['help'] ?? '' ) ),
			];
		}
		return $out;
	}

	/**
	 * A stored list, tidied: each question held to the shape and a known
	 * type, as the meta sanitizer stores it. Not a list, no questions.
	 *
	 * @param mixed $decoded What json_decode() gave for the stored value.
	 * @return list<array{key: string, label: string, type: string, options: list<string>, required: bool, help: string}>
	 */
	public static function tidy( mixed $decoded ): array {
		if ( ! is_array( $decoded ) || array_keys( $decoded ) !== range( 0, count( $decoded ) - 1 ) ) {
			return [];
		}
		$out = [];
		foreach ( $decoded as $field ) {
			if ( ! is_array( $field ) || empty( $field['key'] ) ) {
				continue;
			}
			$out[] = [
				'key'      => sanitize_key( (string) $field['key'] ),
				'label'    => sanitize_text_field( (string) ( $field['label'] ?? $field['key'] ) ),
				'type'     => in_array( $field['type'] ?? 'text', self::TYPES, true ) ? (string) $field['type'] : 'text',
				'options'  => array_values( array_map( 'sanitize_text_field', (array) ( $field['options'] ?? [] ) ) ),
				'required' => ! empty( $field['required'] ),
				'help'     => sanitize_text_field( (string) ( $field['help'] ?? '' ) ),
			];
		}
		return $out;
	}

	/**
	 * The keys of the file questions, whose answers are files rather than values.
	 *
	 * @param list<array{key: string, type: string}> $fields
	 * @return list<string>
	 */
	public static function fileKeys( array $fields ): array {
		$keys = [];
		foreach ( $fields as $question ) {
			if ( 'file' === $question['type'] ) {
				$keys[] = (string) $question['key'];
			}
		}
		return $keys;
	}
}
