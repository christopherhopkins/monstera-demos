<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Organizations\AudienceList;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use WP_Post;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Which forms reach a person (Forms-and-resources track, FR3), by the one
 * rule the library follows (Organizations\AudienceList): published, past
 * the role, audience and sub-group gates, and not held back by an ended
 * membership. The Forms page, a hub's Forms tab and the submit route all
 * read this list, so none of them can offer what another refuses.
 *
 * @phpstan-import-type FormStanding from Standing
 */
final class Repository {

	private const KEYS = [
		'roles'     => Meta::KEY_ROLES,
		'orgs'      => Meta::KEY_ORGS,
		'members'   => Meta::KEY_STANDALONE_MEMBERS,
		'subgroups' => Meta::KEY_SUBGROUPS,
	];

	/**
	 * The published forms a person can open, by title.
	 *
	 * @return WP_Post[]
	 */
	public function visibleTo( WP_User $user ): array {
		return $this->listedFor( $user )[0];
	}

	/**
	 * What visibleTo() lists, and the ended organizations whose forms it left out.
	 *
	 * @return array{0: WP_Post[], 1: list<int>}
	 */
	public function listedFor( WP_User $user ): array {
		return AudienceList::listedFor( $user, PostType::SLUG, self::KEYS, [ Reach::class, 'formOrgs' ] );
	}

	/**
	 * The form this person may open at /portal/forms/{id}/, or null: one the
	 * library lists for them (visibleTo(): published, reaching them, not
	 * held back by an ended membership), of either kind. A draft, a form
	 * out of reach and no form at all are alike null, so the router's 404
	 * and the page's blocked pattern tell nothing apart (Forms-and-resources
	 * track, FR5).
	 */
	public function openable( WP_User $user, int $formId ): ?WP_Post {
		if ( $formId <= 0 ) {
			return null;
		}
		foreach ( $this->visibleTo( $user ) as $form ) {
			if ( (int) $form->ID === $formId ) {
				return $form;
			}
		}
		return null;
	}

	/**
	 * The forms particular to one organization that this person can open,
	 * for its hub's Forms tab (AudienceList::forOrg() has the rule).
	 *
	 * @return WP_Post[]
	 */
	public function forOrg( WP_User $user, int $orgId ): array {
		return AudienceList::forOrg( $user, $orgId, $this->visibleTo( $user ), self::KEYS, [ Reach::class, 'formOrgs' ] );
	}

	/**
	 * The forms that reach the person, where each stands for them, in the
	 * Forms page's three groups (Forms-and-resources track, FR5; comp 130):
	 * Due soonest first, Open by title, Sent newest sent first; a form that
	 * stands nowhere (closed, never sent) is in none. With them the ended
	 * organizations whose forms were left out, for the line that says whose
	 * wait, and the organization each listed form reaches the person
	 * through, for a row of a person in several to name.
	 *
	 * @return array{groups: array{due: list<array{0: WP_Post, 1: FormStanding}>, open: list<array{0: WP_Post, 1: FormStanding}>, sent: list<array{0: WP_Post, 1: FormStanding}>}, waiting: list<int>, through: array<int, int>} `through` names an organization only for a person in several.
	 */
	public function grouped( WP_User $user ): array {
		[ $forms, $waiting ] = $this->listedFor( $user );
		$standings           = Standing::ofEach( $user, $forms );
		$groups              = [
			Standing::GROUP_DUE  => [],
			Standing::GROUP_OPEN => [],
			Standing::GROUP_SENT => [],
		];
		foreach ( $forms as $form ) {
			$standing = $standings[ (int) $form->ID ] ?? null;
			if ( null !== $standing ) {
				$groups[ $standing['group'] ][] = [ $form, $standing ];
			}
		}
		// A stable sort keeps the list's own order, by title under the
		// database's collation, among forms due or sent on the same day.
		usort( $groups[ Standing::GROUP_DUE ], static fn ( array $a, array $b ): int => strcmp( $a[1]['due_on'], $b[1]['due_on'] ) );
		usort( $groups[ Standing::GROUP_SENT ], static fn ( array $a, array $b ): int => strcmp( $b[1]['sent_at'], $a[1]['sent_at'] ) );
		// A row names the organization only for a person in several, as the
		// Resources page's rows do (People-model track, FR5).
		$several = count( OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) ) ) > 1;
		return [
			'groups'  => $groups,
			'waiting' => $waiting,
			'through' => $several ? $this->reachedThrough( $user, $forms ) : [],
		];
	}

	/**
	 * The organization each of these forms reaches the person through, by
	 * the reading a resource's row names it with
	 * (Organizations\AudienceList::reachedThrough()): the one of theirs it
	 * names, counting a sub-group only when they are in it, never one held
	 * back by an ended membership; 0 for a form for everyone or one that
	 * reaches them by name alone. For a person in any number of
	 * organizations: whether a row names it is the page's to decide.
	 *
	 * @param WP_Post[] $forms Forms listed for the person (visibleTo()).
	 * @return array<int, int> By form id.
	 */
	public function reachedThrough( WP_User $user, array $forms ): array {
		return AudienceList::reachedThrough( $user, $forms, Meta::KEY_SUBGROUPS, [ Reach::class, 'formOrgs' ] );
	}
}
