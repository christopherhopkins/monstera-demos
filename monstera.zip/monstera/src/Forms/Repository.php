<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\AccessControl\PortalGuard;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;
use WP_Query;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Repository {

	/**
	 * The published resources a person can open, by title: past the role,
	 * audience and sub-group gates, and not held back by an ended
	 * membership (listedFor() has the rule). The Resources page, a hub's
	 * tab and the logging redirect all read this list, so none of them can
	 * offer what another refuses.
	 *
	 * @return WP_Post[]
	 */
	public function visibleTo( WP_User $user ): array {
		return $this->listedFor( $user )[0];
	}

	/**
	 * What visibleTo() lists, and whose resources it left out.
	 *
	 * An ended membership gives way (People-model track, FR5; the Phase 5
	 * task), as it does on the dashboard and the projects list: a resource
	 * that reaches the person through ended organizations alone is left out,
	 * and the second answer names those organizations, so the page can say
	 * whose resources are waiting, having no band to say it. One that a
	 * running organization of theirs shares too stays, and so does one for
	 * every member and one that names the person, which no organization can
	 * take back. Which organizations are held back (a person in one
	 * organization's as much as a person in several's), and that staff are
	 * held back from nothing, is Organizations\Reach's to say.
	 *
	 * A resource reaches a person through the organizations of theirs it
	 * names and through the sub-groups it names that they are in. A
	 * sub-group they are not in brings them nothing, so a resource for an
	 * ended organization's group and a running one's is left out for someone
	 * who sits in the ended one's alone.
	 *
	 * A standalone member reaches every resource through their own
	 * membership, one for every member as much as one that names them, so
	 * once it has ended (AccessControl\PortalGuard::ownMembershipExpired())
	 * none is listed; the page says why, having no organization to name.
	 *
	 * @return array{0: WP_Post[], 1: list<int>} The resources, then the ended organizations whose resources were left out, in the person's membership order.
	 */
	public function listedFor( WP_User $user ): array {
		if ( PortalGuard::ownMembershipExpired( $user ) ) {
			return [ [], [] ];
		}
		$q = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'orderby'        => 'title',
				'order'          => 'ASC',
			]
		);

		// An organization in the trash grants nothing (OrgRepository::onSite()).
		$out       = [];
		$waiting   = [];
		$userOrgs  = OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		$userSubs  = ( new SubgroupRepository() )->publishedSubgroupsForMember( $user->ID );
		$isAdmin   = user_can( $user, 'manage_monstera' );
		$userRoles = (array) $user->roles;
		$heldBack  = Reach::heldBackFor( $user );
		if ( $heldBack ) {
			// Each resource is about to be asked which organizations bring it,
			// its sub-groups' parents among them: those are read together.
			Reach::primeParents( $q->posts, Meta::KEY_SUBGROUPS, $userSubs );
		}

		// Every organization of theirs in the trash: a member of none on the
		// site, a resource reaches them by name alone (the fix's review, 2026-10-19).
		$noneOnSite = OrgRepository::belongsToNoneOnSite( (int) $user->ID );

		foreach ( $q->posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			if ( $isAdmin ) {
				$out[] = $post;
				continue;
			}

			// Unset meta reads back as '' and casts to [''] — a truthy list
			// that matches nobody — so every list is filtered to real values
			// before it is allowed to gate.
			$allowedRoles = array_filter( array_map( 'strval', (array) get_post_meta( $post->ID, Meta::KEY_ROLES, true ) ) );
			if ( $allowedRoles && ! array_intersect( $userRoles, $allowedRoles ) ) {
				continue;
			}

			// Org + standalone-member targeting form a single "audience": when
			// either list is set, the member must match at least one of them —
			// any of their organizations is listed OR they are named
			// individually (People-model track, FR8). Mirrors the Content
			// visibility engine's audience rule (see Content\Visibility Rule 2)
			// so a form aimed only at standalone members actually gates here
			// instead of falling through to "all". Each form is judged once,
			// so a person in two of its organizations sees it once.
			$allowedOrgs    = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_ORGS, true ) ) );
			$allowedMembers = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBERS, true ) ) );
			$memberMatch    = in_array( (int) $user->ID, $allowedMembers, true );
			if ( $noneOnSite && ! $memberMatch ) {
				continue;
			}
			if ( $allowedOrgs || $allowedMembers ) {
				$orgMatch = [] !== array_intersect( $userOrgs, $allowedOrgs );
				if ( ! $orgMatch && ! $memberMatch ) {
					continue;
				}
			}

			// The person's published sub-groups: one deleted or in the trash
			// lets nobody through (the owner's call, 2026-10-18).
			$allowedSubs = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_SUBGROUPS, true ) ) );
			if ( $allowedSubs && ! array_intersect( $allowedSubs, $userSubs ) ) {
				continue;
			}

			// Theirs to open, unless only an ended membership brings it. One
			// that names the person is asked nothing: it reaches them by name.
			if ( $heldBack && ! $memberMatch ) {
				$named = Reach::formOrgs( (int) $post->ID, $userSubs );
				if ( Reach::onlyThrough( (int) $user->ID, $named, $heldBack ) ) {
					$waiting = array_merge( $waiting, $named );
					continue;
				}
			}

			$out[] = $post;
		}
		// array_intersect keeps the first array's order: the person's memberships, oldest first.
		return [ $out, array_values( array_intersect( $heldBack, $waiting ) ) ];
	}

	/**
	 * What a row says beside each of these resources to a person in several
	 * organizations (People-model track, FR5): the organization the resource
	 * reaches them through, for the row to name, and whether its file waits.
	 * The Resources page and a hub's tab ask here for all their rows at
	 * once, and the logging redirect for its one (fileWaits()), so the list,
	 * its labels and the gate are worked out in one class from one reading
	 * of what brings a resource to a person: the organizations of theirs it
	 * names, and the parents of the sub-groups it names that they are in
	 * (listedFor() says why a sub-group they are not in counts for nothing).
	 *
	 * The organization is the one Organizations\Reach picks among those: a
	 * live one before a suspended one before an ended one, never the
	 * resource's own first. It is said of every row, whichever list the row
	 * sits in: a resource narrowed to one organization's sub-group names no
	 * organization itself and is that organization's all the same, and a
	 * reader told that its download is paused has to be told whose. There is
	 * none to name (0) for a resource for every member, for one that reaches
	 * them by name alone, and for one whose organization is held back, which
	 * is listed only because it names them.
	 *
	 * The file waits when it is a PDF that reaches them through
	 * organizations of theirs none of which is live, each being suspended
	 * or its membership ended. It is the rule a content file follows
	 * (Content\Downloader), for the same reason: on the pages that span
	 * every organization the shell's suspended block stands back for a
	 * person with another live one, so the row is where a suspended
	 * organization's download is said to wait, and the dashboard's band has
	 * already promised that it does. The row prints no link then and the
	 * logging redirect refuses the file (Opener). A link or an embedded form
	 * is not a download and never waits; nor does a file for every member
	 * or one that names the person, which no organization shares and so
	 * none can pause; nor does staff's.
	 *
	 * A person in one organization is paused by the same rule (decided at the
	 * Phase 6 task, for the owner at its checkpoint): the shell's soft block above their
	 * pages says that downloads are paused while the organization is
	 * suspended, and a resource's PDF, a Media Library file, used to open
	 * from under it all the same. Their rows name no organization, the
	 * heading naming it, so only the wait is said of them.
	 *
	 * The person's sub-groups are one read and the parents of the
	 * sub-groups named another, however many rows are asked about.
	 *
	 * @param WP_Post[] $forms Resources listed for the person (visibleTo()).
	 * @return array<int, array{org: int, waits: bool}> By resource id; `org` is 0 for a person in fewer than two organizations.
	 */
	public function besideEach( WP_User $user, array $forms ): array {
		$userOrgs = OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		if ( ! $forms || ! $userOrgs ) {
			return [];
		}
		$several  = count( $userOrgs ) > 1;
		$userSubs = ( new SubgroupRepository() )->publishedSubgroupsForMember( (int) $user->ID );
		Reach::primeParents( $forms, Meta::KEY_SUBGROUPS, $userSubs );
		$heldBack = Reach::heldBackFor( $user );
		$isStaff  = user_can( $user, 'manage_monstera' );
		$beside   = [];
		foreach ( $forms as $form ) {
			$formId = (int) $form->ID;
			$named  = Reach::formOrgs( $formId, $userSubs );
			$org    = Reach::among( (int) $user->ID, $named );
			// Those of theirs that bring it; only whether one of them is live is asked.
			$through = array_intersect( $userOrgs, $named );
			$waits   = ! $isStaff && $through && self::isPausable( $formId, (int) $user->ID ) && ! array_filter( $through, [ Reach::class, 'isLive' ] );

			$beside[ $formId ] = [
				'org'   => $several && ! in_array( $org, $heldBack, true ) ? $org : 0,
				'waits' => $waits,
			];
		}
		return $beside;
	}

	/**
	 * Whether one resource's file waits for this person (besideEach() has
	 * the rule), for the logging redirect, which is asked about one.
	 */
	public function fileWaits( WP_User $user, int $formId ): bool {
		$form = get_post( $formId );
		return $form instanceof WP_Post && ( $this->besideEach( $user, [ $form ] )[ $formId ]['waits'] ?? false );
	}

	/**
	 * Whether a resource is a file an organization could pause for this
	 * person at all: a PDF, and not one that names them, which reaches them
	 * through no organization.
	 */
	private static function isPausable( int $formId, int $userId ): bool {
		return Meta::TYPE_PDF === ( (string) get_post_meta( $formId, Meta::KEY_FORM_TYPE, true ) ?: Meta::TYPE_PDF )
			&& ! in_array( $userId, array_map( 'intval', (array) get_post_meta( $formId, Meta::KEY_STANDALONE_MEMBERS, true ) ), true );
	}

	/**
	 * The resources particular to one organization that this person can
	 * open: what `visibleTo()` allows them, narrowed to two shapes. One names
	 * the organization. The other names no organization but is narrowed to
	 * one of its sub-groups: the admin UI saves "for Acme's Leadership Team"
	 * that way (`FormsController::applyAudience` lets any sub-group narrow an
	 * audience of everyone), and a sub-group has one parent, so the resource
	 * is this organization's as surely as one that names it. One sent to
	 * every member names nobody and narrows nothing, so it is on the
	 * Resources page and not here.
	 *
	 * A resource of the second shape may be narrowed to a sub-group of each
	 * of several organizations. It is on this hub when this organization is
	 * one it reaches the reader through: a group of theirs under it is
	 * among those named, which is the reading the Resources page, the row's
	 * label and the pause all share (besideEach()). A group of this
	 * organization they are not in brings them nothing, so the resource is
	 * another hub's, the one whose group they are in; listed here it would
	 * sit under an organization that does not share it with them and wait
	 * by the standing of the one that does. Staff sit in no sub-group and
	 * read every resource, so for them any sub-group of this organization
	 * places it here, as it always has.
	 *
	 * @return WP_Post[]
	 */
	public function forOrg( WP_User $user, int $orgId ): array {
		if ( $orgId <= 0 ) {
			return [];
		}
		$visible = $this->visibleTo( $user );
		if ( ! $visible ) {
			return [];
		}
		// The sub-groups that place a resource here: the reader's own, or
		// for staff every one this organization has.
		$placing = user_can( $user, 'manage_monstera' )
			? array_map( static fn ( WP_Post $group ): int => (int) $group->ID, ( new SubgroupRepository() )->forOrg( $orgId ) )
			: ( new SubgroupRepository() )->publishedSubgroupsForMember( (int) $user->ID );
		Reach::primeParents( $visible, Meta::KEY_SUBGROUPS, $placing );
		return array_values(
			array_filter(
				$visible,
				static function ( WP_Post $form ) use ( $orgId, $placing ): bool {
					// Filtered as in visibleTo(): unset meta reads back as [''].
					$orgs = array_filter( array_map( 'intval', (array) get_post_meta( $form->ID, Meta::KEY_ORGS, true ) ) );
					if ( $orgs ) {
						return in_array( $orgId, $orgs, true );
					}
					return in_array( $orgId, Reach::formOrgs( (int) $form->ID, $placing ), true );
				}
			)
		);
	}

	public function renderAction( WP_Post $form ): string {
		$type = (string) get_post_meta( $form->ID, Meta::KEY_FORM_TYPE, true );

		switch ( $type ) {
			case Meta::TYPE_PDF:
				$fileId = (int) get_post_meta( $form->ID, Meta::KEY_PDF_FILE_ID, true );
				if ( $fileId ) {
					// Forms PDFs are library templates — blank application
					// forms, signing templates, checklists — not the
					// per-member gated deliverables the secure-files flow is
					// designed for. They live in the standard Media Library,
					// so resolve a direct attachment URL. Access is gated at
					// the LIST level (visibleTo() drops forms the user
					// shouldn't see); the URL itself is unguessable enough
					// for a template library.
					$url      = (string) wp_get_attachment_url( $fileId );
					$filename = (string) get_post_meta( $fileId, '_wp_attached_file', true );
					$basename = $filename ? basename( $filename ) : 'form.pdf';
					if ( $url ) {
						// Bare `download` signals save intent; the filename
						// attribute pins the saved name to the original.
						return sprintf(
							'<a class="m-btn" data-intent="primary" data-size="md" href="%s" download="%s">%s</a>',
							esc_url( $url ),
							esc_attr( $basename ),
							esc_html__( 'Download PDF', 'monstera' )
						);
					}
				}
				// Soft fallback: a PDF that hasn't been uploaded yet. Show a
				// muted "awaiting upload" pill rather than rendering an
				// empty card with no affordance.
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Awaiting upload', 'monstera' )
				);
			case Meta::TYPE_SHORTCODE:
				$sc = (string) get_post_meta( $form->ID, Meta::KEY_SHORTCODE, true );
				if ( $sc ) {
					return do_shortcode( $sc );
				}
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Awaiting setup', 'monstera' )
				);
			case Meta::TYPE_EXTERNAL:
				$url = (string) get_post_meta( $form->ID, Meta::KEY_EXTERNAL_URL, true );
				if ( $url ) {
					return sprintf(
						'<a class="m-btn" data-intent="secondary" data-size="md" href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
						esc_url( $url ),
						esc_html__( 'Open link', 'monstera' )
					);
				}
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Coming soon', 'monstera' )
				);
			default:
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Not configured', 'monstera' )
				);
		}
	}
}
