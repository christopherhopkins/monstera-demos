<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Members\UserMeta;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;
use WP_Query;
use WP_User;

final class Repository {

	/**
	 * @return WP_Post[]
	 */
	public function visibleTo( WP_User $user ): array {
		$q = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'orderby'        => 'title',
				'order'          => 'ASC',
			]
		);

		$out       = [];
		$userOrg   = UserMeta::associatedOrg( $user->ID );
		$userSubs  = ( new SubgroupRepository() )->subgroupsForMember( $user->ID );
		$isAdmin   = user_can( $user, 'manage_monstera' );
		$userRoles = (array) $user->roles;

		foreach ( $q->posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			if ( $isAdmin ) {
				$out[] = $post;
				continue;
			}

			// Unset meta reads back as '' and casts to [''] — a truthy list
			// that matches nobody — so every list is filtered to real values
			// before it is allowed to gate.
			$allowedRoles = array_filter( array_map( 'strval', (array) get_post_meta( $post->ID, Meta::KEY_ROLES, true ) ) );
			if ( $allowedRoles && ! array_intersect( $userRoles, $allowedRoles ) ) {
				continue;
			}

			// Org + standalone-member targeting form a single "audience": when
			// either list is set, the member must match at least one of them —
			// their organization is listed OR they are named individually.
			// Mirrors the Content visibility engine's audience rule (see
			// Content\Visibility Rule 2) so a form aimed only at standalone
			// members actually gates here instead of falling through to "all".
			$allowedOrgs    = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_ORGS, true ) ) );
			$allowedMembers = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_STANDALONE_MEMBERS, true ) ) );
			if ( $allowedOrgs || $allowedMembers ) {
				$orgMatch    = $userOrg && in_array( $userOrg, $allowedOrgs, true );
				$memberMatch = in_array( (int) $user->ID, $allowedMembers, true );
				if ( ! $orgMatch && ! $memberMatch ) {
					continue;
				}
			}

			$allowedSubs = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, Meta::KEY_SUBGROUPS, true ) ) );
			if ( $allowedSubs && ! array_intersect( $allowedSubs, $userSubs ) ) {
				continue;
			}

			$out[] = $post;
		}
		return $out;
	}

	/**
	 * The resources particular to one organization that this person can
	 * open: what `visibleTo()` allows them, narrowed to two shapes. One names
	 * the organization. The other names no organization but is narrowed to
	 * one of its sub-groups: the admin UI saves "for Acme's Leadership Team"
	 * that way (`FormsController::applyAudience` lets any sub-group narrow an
	 * audience of everyone), and a sub-group has one parent, so the resource
	 * is this organization's as surely as one that names it. One sent to
	 * every member names nobody and narrows nothing, so it is on the
	 * Resources page and not here.
	 *
	 * @return WP_Post[]
	 */
	public function forOrg( WP_User $user, int $orgId ): array {
		if ( $orgId <= 0 ) {
			return [];
		}
		$visible = $this->visibleTo( $user );
		if ( ! $visible ) {
			return [];
		}
		$orgSubgroups = array_map(
			static fn ( WP_Post $group ): int => (int) $group->ID,
			( new SubgroupRepository() )->forOrg( $orgId )
		);
		return array_values(
			array_filter(
				$visible,
				static function ( WP_Post $form ) use ( $orgId, $orgSubgroups ): bool {
					// Filtered as in visibleTo(): unset meta reads back as [''].
					$orgs = array_filter( array_map( 'intval', (array) get_post_meta( $form->ID, Meta::KEY_ORGS, true ) ) );
					if ( $orgs ) {
						return in_array( $orgId, $orgs, true );
					}
					$subs = array_filter( array_map( 'intval', (array) get_post_meta( $form->ID, Meta::KEY_SUBGROUPS, true ) ) );
					return [] !== array_intersect( $subs, $orgSubgroups );
				}
			)
		);
	}

	public function renderAction( WP_Post $form ): string {
		$type = (string) get_post_meta( $form->ID, Meta::KEY_FORM_TYPE, true );

		switch ( $type ) {
			case Meta::TYPE_PDF:
				$fileId = (int) get_post_meta( $form->ID, Meta::KEY_PDF_FILE_ID, true );
				if ( $fileId ) {
					// Forms PDFs are library templates — blank application
					// forms, signing templates, checklists — not the
					// per-member gated deliverables the secure-files flow is
					// designed for. They live in the standard Media Library,
					// so resolve a direct attachment URL. Access is gated at
					// the LIST level (visibleTo() drops forms the user
					// shouldn't see); the URL itself is unguessable enough
					// for a template library.
					$url      = (string) wp_get_attachment_url( $fileId );
					$filename = (string) get_post_meta( $fileId, '_wp_attached_file', true );
					$basename = $filename ? basename( $filename ) : 'form.pdf';
					if ( $url ) {
						// Bare `download` signals save intent; the filename
						// attribute pins the saved name to the original.
						return sprintf(
							'<a class="m-btn" data-intent="primary" data-size="md" href="%s" download="%s">%s</a>',
							esc_url( $url ),
							esc_attr( $basename ),
							esc_html__( 'Download PDF', 'monstera' )
						);
					}
				}
				// Soft fallback: a PDF that hasn't been uploaded yet. Show a
				// muted "awaiting upload" pill rather than rendering an
				// empty card with no affordance.
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Awaiting upload', 'monstera' )
				);
			case Meta::TYPE_SHORTCODE:
				$sc = (string) get_post_meta( $form->ID, Meta::KEY_SHORTCODE, true );
				if ( $sc ) {
					return do_shortcode( $sc );
				}
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Awaiting setup', 'monstera' )
				);
			case Meta::TYPE_EXTERNAL:
				$url = (string) get_post_meta( $form->ID, Meta::KEY_EXTERNAL_URL, true );
				if ( $url ) {
					return sprintf(
						'<a class="m-btn" data-intent="secondary" data-size="md" href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
						esc_url( $url ),
						esc_html__( 'Open link', 'monstera' )
					);
				}
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Coming soon', 'monstera' )
				);
			default:
				return sprintf(
					'<span class="m-form-card__notice" data-tone="pending">%s</span>',
					esc_html__( 'Not configured', 'monstera' )
				);
		}
	}
}
