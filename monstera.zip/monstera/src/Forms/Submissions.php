<?php
declare(strict_types=1);

namespace Monstera\Forms;

use Monstera\Content\SecureFiles;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\RateLimit;
use Monstera\Core\SecureStorage;
use Monstera\Core\SiteDay;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Reach;
use Monstera\Projects\IntakeFiles;
use Monstera\Reporting\Tracking;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * What a member sent a built form (Forms-and-resources track, FR3): a row
 * of monstera_form_submissions holding the answers as JSON by question
 * key, under the organization the form reached them through, and for each
 * file question its files in secure storage under mp-secure/forms/{form}/,
 * the registry's fourth owner. A submission and its files are one write:
 * every answer and every file is checked before anything is stored, and a
 * file that fails part way takes the ones before it and the row back.
 * Removed or retyped questions keep their answers under the old key.
 */
final class Submissions {

	/** The limits a file question shares with a discovery file question. */
	public static function maxBytes(): int {
		return IntakeFiles::maxBytes();
	}

	public static function maxCount(): int {
		return IntakeFiles::maxCount();
	}

	/**
	 * Whether a member has made the ten sends a person may make in ten
	 * minutes: each send emails the form's addresses, so a member's are
	 * held to ten (the team's are not). Only a send that was stored counts
	 * (recordSend()), so fixing a refused one is never held back.
	 */
	public static function sendLimitReached( WP_User $user ): bool {
		return ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA )
			&& RateLimit::reached( 'form_send', (int) $user->ID, 10 );
	}

	/** Counts a stored send towards the member's ten. */
	public static function recordSend( WP_User $user ): void {
		if ( ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			RateLimit::record( 'form_send', (int) $user->ID, 10 * MINUTE_IN_SECONDS );
		}
	}

	public static function saySendLimit(): string {
		return __( 'That is several sends in a few minutes. Wait ten minutes, then send again.', 'monstera' );
	}

	/**
	 * When PHP kept nothing of a send for its size (over post_max_size
	 * neither fields nor files arrive, only the length the browser
	 * declared): the refusal by question key, under the form's first file
	 * question, as the page's own total check says it; else null.
	 *
	 * @param list<array<string, mixed>> $fields   The form's questions.
	 * @param bool                       $arrived  Whether any field or file arrived.
	 * @param int                        $declared The request's Content-Length.
	 * @return array<string, string>|null
	 */
	public static function droppedForSize( array $fields, bool $arrived, int $declared ): ?array {
		if ( $arrived || ! IntakeFiles::bodyTooLarge( $declared, (string) ini_get( 'post_max_size' ) ) ) {
			return null;
		}
		return [ Fields::fileKeys( $fields )[0] ?? '_form' => __( 'Together these files are more than one send can carry. Remove some.', 'monstera' ) ];
	}

	/**
	 * Store what a member sent. The values are keyed by question key as the
	 * request sent them; the uploads too, each a list as
	 * Support\Files::normalise() gives one.
	 *
	 * @param array<int|string, mixed>                       $values
	 * @param array<string, list<array<string, mixed>>>      $uploads
	 * @return array<string, mixed> The row, find() has its shape.
	 * @throws AnswersRefused    When an answer does not do (every field's complaint at once).
	 * @throws AlreadySent       When a once-only form took another send meanwhile.
	 * @throws FilesRefused      When a file cannot be sent; the message names it.
	 * @throws \RuntimeException When a file could not be stored.
	 */
	public static function create( int $formId, WP_User $user, array $values, array $uploads = [] ): array {
		$fields  = Meta::fieldsOf( $formId );
		$answers = [];
		$errors  = [];
		$files   = [];
		foreach ( $fields as $field ) {
			$key   = (string) $field['key'];
			$label = (string) $field['label'];
			if ( 'file' === $field['type'] ) {
				$list = array_values( array_filter( (array) ( $uploads[ $key ] ?? [] ), 'is_array' ) );
				if ( $field['required'] && ! $list ) {
					/* translators: %s: the question */
					$errors[ $key ] = sprintf( __( '%s needs a file.', 'monstera' ), $label );
				}
				$answers[ $key ] = [];
				$files[ $key ]   = $list;
				continue;
			}
			$raw   = $values[ $key ] ?? '';
			$value = is_scalar( $raw ) ? trim( (string) $raw ) : '';
			if ( '' === $value ) {
				if ( $field['required'] ) {
					/* translators: %s: the question */
					$errors[ $key ] = sprintf( __( '%s needs an answer.', 'monstera' ), $label );
				}
				$answers[ $key ] = '';
				continue;
			}
			switch ( $field['type'] ) {
				case 'textarea':
					$answers[ $key ] = wp_kses_post( $value );
					break;
				case 'number':
					if ( ! is_numeric( $value ) ) {
						/* translators: %s: the question */
						$errors[ $key ] = sprintf( __( '%s needs a number.', 'monstera' ), $label );
					}
					$answers[ $key ] = is_numeric( $value ) ? $value : '';
					break;
				case 'select':
					$option = sanitize_text_field( $value );
					if ( ! in_array( $option, (array) $field['options'], true ) ) {
						/* translators: %s: the question */
						$errors[ $key ] = sprintf( __( '%s: choose one of the options.', 'monstera' ), $label );
					}
					$answers[ $key ] = $option;
					break;
				case 'date':
					if ( ! SiteDay::isDay( $value ) ) {
						/* translators: %s: the question */
						$errors[ $key ] = sprintf( __( '%s: write the date as a date.', 'monstera' ), $label );
					}
					$answers[ $key ] = $value;
					break;
				default:
					$answers[ $key ] = sanitize_text_field( $value );
			}
		}
		if ( $errors ) {
			throw new AnswersRefused( $errors ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- each sentence is escaped where the page or the route prints it.
		}
		foreach ( $files as $key => $list ) {
			self::refuseFiles( (string) $key, $list );
		}

		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS );
		// Staff belong to no organization: 0, as for a member of none.
		$orgId = user_can( $user, 'manage_monstera' ) ? 0 : Reach::ofForm( (int) $user->ID, $formId );
		$wpdb->insert(
			$table,
			[
				'form_id'      => $formId,
				'user_id'      => (int) $user->ID,
				'org_id'       => $orgId,
				'answers'      => (string) wp_json_encode( $answers ),
				'submitted_at' => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%d', '%s', '%s' ]
		);
		$id = (int) $wpdb->insert_id;
		if ( $id <= 0 ) {
			throw new \RuntimeException( 'Failed to record the submission.' );
		}
		// A once-only form takes one: a second send that passed the check
		// while the first was being written (a double click) is taken back.
		if ( Meta::onceOnly( $formId ) && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE form_id = %d AND user_id = %d AND id < %d', $table, $formId, (int) $user->ID, $id ) ) > 0 ) {
			$wpdb->delete( $table, [ 'id' => $id ], [ '%d' ] );
			throw new AlreadySent( 'This form was already sent.' );
		}

		$registry = new SecureFiles();
		$kept     = [];
		try {
			foreach ( $files as $key => $list ) {
				foreach ( $list as $upload ) {
					$fileId            = $registry->put(
						SecureStorage::rootPath() . '/forms/' . $formId,
						$upload,
						[
							'content_id'    => 0,
							'submission_id' => $id,
							'field_key'     => $key,
							'uploaded_by'   => (int) $user->ID,
							'original_name' => SecureFiles::displayName( (string) $upload['name'] ),
							'mime_type'     => SecureFiles::checkedType( $upload ),
						]
					);
					$kept[]            = $fileId;
					$answers[ $key ][] = $fileId;
				}
			}
		} catch ( \RuntimeException $failure ) {
			// No files, no submission: the member sends it again whole.
			foreach ( $kept as $fileId ) {
				$registry->delete( $fileId );
			}
			$wpdb->delete( $table, [ 'id' => $id ], [ '%d' ] );
			throw $failure;
		}
		if ( $kept ) {
			$wpdb->update( $table, [ 'answers' => (string) wp_json_encode( $answers ) ], [ 'id' => $id ], [ '%s' ], [ '%d' ] );
		}
		// The submission is whole, files and all, before anyone hears of it.
		Tracking::formSubmitted( $formId, (int) $user->ID, $id, $orgId );
		do_action( Hooks::FORM_SUBMITTED, $id, $formId, (int) $user->ID );
		$row = self::find( $id );
		return $row ?? [];
	}

	/**
	 * Why these uploads cannot go with a submission, thrown; nothing when
	 * they can. Intake's limits, the registry's types.
	 *
	 * @param string                     $key     The file question's key, for the refusal to name.
	 * @param list<array<string, mixed>> $uploads
	 * @throws FilesRefused
	 */
	private static function refuseFiles( string $key, array $uploads ): void {
		$reason = count( $uploads ) > self::maxCount()
			/* translators: %d: how many files a question takes */
			? sprintf( __( 'A question takes up to %d files.', 'monstera' ), self::maxCount() )
			: null;
		foreach ( $uploads as $upload ) {
			if ( null !== $reason ) {
				break;
			}
			$why = self::refusalOf( $upload );
			if ( null !== $why ) {
				/* translators: 1: a file's name, 2: why it cannot be sent, a full sentence */
				$reason = sprintf( __( '%1$s: %2$s', 'monstera' ), SecureFiles::displayName( (string) ( $upload['name'] ?? '' ) ), $why );
			}
		}
		if ( null !== $reason ) {
			throw FilesRefused::because( $reason, $key ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- because() escapes the message; reason() keeps the words for a JSON response.
		}
	}

	/**
	 * @param array<string, mixed> $upload
	 */
	private static function refusalOf( array $upload ): ?string {
		$error = (int) ( $upload['error'] ?? UPLOAD_ERR_NO_FILE );
		if ( in_array( $error, [ UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ], true ) || (int) ( $upload['size'] ?? 0 ) > self::maxBytes() ) {
			/* translators: %s: the largest file allowed, e.g. "50 MB" */
			return sprintf( __( 'That file is over %s.', 'monstera' ), size_format( self::maxBytes() ) );
		}
		if ( UPLOAD_ERR_OK !== $error || empty( $upload['tmp_name'] ) || ! is_file( (string) $upload['tmp_name'] ) ) {
			return __( 'That file did not arrive. Choose it again.', 'monstera' );
		}
		if ( '' === SecureFiles::checkedType( $upload ) ) {
			return __( 'That kind of file cannot be sent. Use a PDF, an Office document, a CSV or text file, a zip or an image.', 'monstera' );
		}
		return null;
	}

	/** Whether the person has sent this form before. */
	public static function hasSent( int $formId, int $userId ): bool {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE form_id = %d AND user_id = %d', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $formId, $userId ) ) > 0;
	}

	/**
	 * How many of these forms one person has sent, and when they last did,
	 * in one read (for the rows that list the forms; Forms\Standing): by
	 * form id, only the forms they have sent.
	 *
	 * @param int[] $formIds
	 * @return array<int, array{sent: int, sent_at: string}> `sent_at` is UTC, MySQL.
	 */
	public static function mineAcross( array $formIds, int $userId ): array {
		$formIds = array_values( array_filter( array_map( 'intval', $formIds ) ) );
		if ( ! $formIds || $userId <= 0 ) {
			return [];
		}
		global $wpdb;
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the placeholders are built for the ids, the rest is prepared.
			$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per id, spread in below.
				'SELECT form_id, COUNT(*) AS sent, MAX(submitted_at) AS sent_at FROM %i WHERE user_id = %d AND form_id IN (' . implode( ',', array_fill( 0, count( $formIds ), '%d' ) ) . ') GROUP BY form_id',
				Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ),
				$userId,
				...$formIds
			),
			ARRAY_A
		);
		$out  = [];
		foreach ( $rows as $row ) {
			$out[ (int) $row['form_id'] ] = [
				'sent'    => (int) $row['sent'],
				'sent_at' => (string) $row['sent_at'],
			];
		}
		return $out;
	}

	/**
	 * Every submission to a form, newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forForm( int $formId ): array {
		global $wpdb;
		return self::rows( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE form_id = %d ORDER BY submitted_at DESC, id DESC', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $formId ), ARRAY_A ) );
	}

	/**
	 * The submissions to a form sent through one organization (0: through
	 * none), newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function forFormAndOrg( int $formId, int $orgId ): array {
		global $wpdb;
		return self::rows( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE form_id = %d AND org_id = %d ORDER BY submitted_at DESC, id DESC', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $formId, $orgId ), ARRAY_A ) );
	}

	/**
	 * One person's submissions to a form, newest first.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function mine( int $formId, int $userId ): array {
		global $wpdb;
		return self::rows( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE form_id = %d AND user_id = %d ORDER BY submitted_at DESC, id DESC', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $formId, $userId ), ARRAY_A ) );
	}

	/**
	 * @return array{id: int, form_id: int, user_id: int, org_id: int, answers: array<string, mixed>, submitted_at: string}|null
	 */
	public static function find( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $id ), ARRAY_A );
		return $row ? self::row( (array) $row ) : null;
	}

	/**
	 * How many submissions a form has and when the last came: all of them,
	 * or those sent through the organizations given.
	 *
	 * @param list<int>|null $orgIds Null for every one.
	 * @return array{count: int, last_at: string|null}
	 */
	public static function countFor( int $formId, ?array $orgIds = null ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS );
		if ( null === $orgIds ) {
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) AS count, MAX(submitted_at) AS last_at FROM %i WHERE form_id = %d', $table, $formId ), ARRAY_A );
		} else {
			$ids = array_values( array_unique( array_filter( array_map( 'intval', $orgIds ) ) ) );
			if ( ! $ids ) {
				return [
					'count'   => 0,
					'last_at' => null,
				];
			}
			$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the placeholders are built for the ids, the rest is prepared.
				$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per organization, spread in below.
					'SELECT COUNT(*) AS count, MAX(submitted_at) AS last_at FROM %i WHERE form_id = %d AND org_id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')', // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- as above.
					$table,
					$formId,
					...$ids
				),
				ARRAY_A
			);
		}
		return [
			'count'   => (int) ( $row['count'] ?? 0 ),
			'last_at' => isset( $row['last_at'] ) && '' !== (string) $row['last_at'] ? (string) $row['last_at'] : null,
		];
	}

	/**
	 * countFor() for many forms in one grouped read: by form id, each with
	 * its count and its last, a form with none at 0 and null.
	 *
	 * @param list<int>      $formIds
	 * @param list<int>|null $orgIds Null for every one.
	 * @return array<int, array{count: int, last_at: string|null}>
	 */
	public static function countsFor( array $formIds, ?array $orgIds = null ): array {
		global $wpdb;
		$formIds = array_values( array_unique( array_filter( array_map( 'intval', $formIds ) ) ) );
		$out     = array_fill_keys(
			$formIds,
			[
				'count'   => 0,
				'last_at' => null,
			]
		);
		$orgIds  = null === $orgIds ? null : array_values( array_unique( array_filter( array_map( 'intval', $orgIds ) ) ) );
		if ( ! $formIds || [] === $orgIds ) {
			return $out;
		}
		$byForm = implode( ',', array_fill( 0, count( $formIds ), '%d' ) );
		$byOrg  = null === $orgIds ? '' : ' AND org_id IN (' . implode( ',', array_fill( 0, count( $orgIds ), '%d' ) ) . ')';
		$rows   = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the placeholders are built for the ids, the rest is prepared.
			$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per form and organization, spread in below.
				"SELECT form_id, COUNT(*) AS count, MAX(submitted_at) AS last_at FROM %i WHERE form_id IN ($byForm)$byOrg GROUP BY form_id", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- as above.
				Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ),
				...array_merge( $formIds, $orgIds ?? [] )
			),
			ARRAY_A
		);
		foreach ( $rows as $row ) {
			$out[ (int) $row['form_id'] ] = [
				'count'   => (int) $row['count'],
				'last_at' => '' !== (string) ( $row['last_at'] ?? '' ) ? (string) $row['last_at'] : null,
			];
		}
		return $out;
	}

	/**
	 * How many of an organization's people have sent each of these forms
	 * through it, in one grouped read: by form id, 0 for none (Manage's
	 * list of the team's forms; the Phase 6 review).
	 *
	 * @param list<int> $formIds
	 * @return array<int, int>
	 */
	public static function sendersFor( array $formIds, int $orgId ): array {
		global $wpdb;
		$formIds = array_values( array_unique( array_filter( array_map( 'intval', $formIds ) ) ) );
		$out     = array_fill_keys( $formIds, 0 );
		if ( ! $formIds ) {
			return $out;
		}
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the placeholders are built for the ids, the rest is prepared.
			$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per form, spread in below.
				'SELECT form_id, COUNT(DISTINCT user_id) AS n FROM %i WHERE org_id = %d AND form_id IN (' . implode( ',', array_fill( 0, count( $formIds ), '%d' ) ) . ') GROUP BY form_id', // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- as above.
				Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ),
				$orgId,
				...$formIds
			),
			ARRAY_A
		);
		foreach ( $rows as $row ) {
			$out[ (int) $row['form_id'] ] = (int) $row['n'];
		}
		return $out;
	}

	/**
	 * How many answers and files each question of a form holds, by key: a
	 * written answer counts once a submission, a file question by its files
	 * and their bytes. Read once for the builder (FR8; comp 125).
	 *
	 * @return array<string, array{answers: int, files: int, bytes: int}>
	 */
	public static function answerCounts( int $formId ): array {
		$out   = [];
		$blank = [
			'answers' => 0,
			'files'   => 0,
			'bytes'   => 0,
		];
		global $wpdb;
		$stored = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT answers FROM %i WHERE form_id = %d', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $formId ) );
		foreach ( $stored as $json ) {
			$answers = json_decode( (string) $json, true );
			foreach ( is_array( $answers ) ? $answers : [] as $key => $value ) {
				if ( is_array( $value ) || '' === trim( (string) $value ) ) {
					continue;
				}
				$out[ (string) $key ]             = $out[ (string) $key ] ?? $blank;
				$out[ (string) $key ]['answers'] += 1;
			}
		}
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT f.field_key, COUNT(*) AS files, SUM(f.filesize) AS bytes FROM %i f INNER JOIN %i s ON s.id = f.submission_id WHERE f.content_id = 0 AND s.form_id = %d GROUP BY f.field_key',
				Schema::tableName( Schema::TABLE_SECURE_FILES ),
				Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ),
				$formId
			),
			ARRAY_A
		);
		foreach ( $rows as $row ) {
			$key                  = (string) $row['field_key'];
			$out[ $key ]          = $out[ $key ] ?? $blank;
			$out[ $key ]['files'] = (int) $row['files'];
			$out[ $key ]['bytes'] = (int) $row['bytes'];
		}
		return $out;
	}

	/**
	 * The files of several submissions in one read, by submission and then
	 * by question key, each list in the order sent (the admin's list).
	 *
	 * @param array<int, int> $submissionIds
	 * @return array<int, array<string, list<array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}>>>
	 */
	public static function filesOfMany( array $submissionIds ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $submissionIds ) ) ) );
		if ( ! $ids ) {
			return [];
		}
		global $wpdb;
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the placeholders are built for the ids, the rest is prepared.
			$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- one %d per id, spread in below.
				'SELECT * FROM %i WHERE content_id = 0 AND submission_id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ') ORDER BY id ASC', // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- as above.
				Schema::tableName( Schema::TABLE_SECURE_FILES ),
				...$ids
			),
			ARRAY_A
		);
		$out  = [];
		foreach ( $rows as $file ) {
			$out[ (int) $file['submission_id'] ][ (string) $file['field_key'] ][] = self::fileRow( $file );
		}
		return $out;
	}

	/**
	 * A submission's files by question key, each list in the order sent.
	 *
	 * @return array<string, list<array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}>>
	 */
	public static function filesOf( int $submissionId ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE content_id = 0 AND submission_id = %d ORDER BY id ASC', Schema::tableName( Schema::TABLE_SECURE_FILES ), $submissionId ), ARRAY_A );
		$out  = [];
		foreach ( $rows as $file ) {
			$out[ (string) $file['field_key'] ][] = self::fileRow( $file );
		}
		return $out;
	}

	/**
	 * A registry row as a submission's file.
	 *
	 * @param array<string, mixed> $file
	 * @return array{id: int, name: string, size: int, type: string, uploaded_by: string, uploaded_by_id: int, uploaded_at: string}
	 */
	private static function fileRow( array $file ): array {
		$by = get_userdata( (int) $file['uploaded_by'] );
		return [
			'id'             => (int) $file['id'],
			'name'           => (string) $file['original_name'],
			'size'           => (int) $file['filesize'],
			'type'           => (string) $file['mime_type'],
			'uploaded_by'    => $by ? UserMeta::fullName( $by ) : '',
			'uploaded_by_id' => (int) $file['uploaded_by'],
			'uploaded_at'    => (string) $file['created_at'],
		];
	}

	/**
	 * The keys these submissions answered that are no question of the form
	 * now and were answered, in the order met: a removed question keeps
	 * its answers, which the admin shows last, under its old key.
	 *
	 * @param list<array<string, mixed>> $rows Submissions, find()'s shape.
	 * @return list<string>
	 */
	public static function removedKeys( int $formId, array $rows ): array {
		$current = array_map( 'strval', array_column( Meta::fieldsOf( $formId ), 'key' ) );
		$removed = [];
		foreach ( $rows as $row ) {
			foreach ( (array) ( $row['answers'] ?? [] ) as $key => $answer ) {
				$key = (string) $key;
				// A question left empty, removed since, has nothing to show.
				if ( '' === $answer || [] === $answer || in_array( $key, $current, true ) || in_array( $key, $removed, true ) ) {
					continue;
				}
				$removed[] = $key;
			}
		}
		return $removed;
	}

	/** A submission, its files from disk and the registry with it. */
	public static function delete( int $id ): void {
		global $wpdb;
		$registry = new SecureFiles();
		$fileIds  = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE content_id = 0 AND submission_id = %d', Schema::tableName( Schema::TABLE_SECURE_FILES ), $id ) );
		foreach ( array_map( 'intval', $fileIds ) as $fileId ) {
			$registry->delete( $fileId );
		}
		$wpdb->delete( Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), [ 'id' => $id ], [ '%d' ] );
	}

	/** Every submission to a form, with their files: the form is gone. */
	public static function deleteForForm( int $formId ): void {
		global $wpdb;
		foreach ( array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE form_id = %d', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $formId ) ) ) as $id ) {
			self::delete( $id );
		}
	}

	/** Every submission a person sent, with their files: the account is gone. */
	public static function deleteForUser( int $userId ): void {
		global $wpdb;
		foreach ( array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE user_id = %d', Schema::tableName( Schema::TABLE_FORM_SUBMISSIONS ), $userId ) ) ) as $id ) {
			self::delete( $id );
		}
	}

	/**
	 * @param list<array<string, mixed>> $rows
	 * @return list<array<string, mixed>>
	 */
	private static function rows( array $rows ): array {
		return array_values( array_map( [ self::class, 'row' ], $rows ) );
	}

	/**
	 * @param array<string, mixed> $row
	 * @return array{id: int, form_id: int, user_id: int, org_id: int, answers: array<string, mixed>, submitted_at: string}
	 */
	private static function row( array $row ): array {
		$answers = json_decode( (string) $row['answers'], true );
		return [
			'id'           => (int) $row['id'],
			'form_id'      => (int) $row['form_id'],
			'user_id'      => (int) $row['user_id'],
			'org_id'       => (int) $row['org_id'],
			'answers'      => is_array( $answers ) ? $answers : [],
			'submitted_at' => (string) $row['submitted_at'],
		];
	}
}
