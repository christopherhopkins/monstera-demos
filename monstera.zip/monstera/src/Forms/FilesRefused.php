<?php
declare(strict_types=1);

namespace Monstera\Forms;

defined( 'ABSPATH' ) || exit;

/**
 * A submission refused for its files: too many for a question, one too
 * large, one of a kind the registry does not keep, one that did not
 * arrive. The message names the file and the rule, and the refusal the
 * question it was for, so the form page places it there; nothing is stored.
 */
final class FilesRefused extends \InvalidArgumentException {

	private string $reason = '';

	private string $field = '';

	public static function because( string $reason, string $field = '' ): self {
		$refused         = new self( esc_html( $reason ) );
		$refused->reason = $reason;
		$refused->field  = $field;
		return $refused;
	}

	/** The refusal in plain words, for a response that is not HTML. */
	public function reason(): string {
		return $this->reason;
	}

	/** The key of the file question the refused files were for. */
	public function field(): string {
		return $this->field;
	}
}
