<?php
declare(strict_types=1);

namespace Monstera\Forms;

defined( 'ABSPATH' ) || exit;

/**
 * A once-only form refused a second submission that arrived while the
 * first was being stored (a double click, two tabs): the row written
 * second is taken back, and the route answers as the form page would
 * have, "already sent".
 */
final class AlreadySent extends \RuntimeException {
}
