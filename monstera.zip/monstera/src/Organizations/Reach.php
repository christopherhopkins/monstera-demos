<?php
/**
 * The organization an item reaches a person through (People-model track,
 * FR8 and FR9). A person may belong to several organizations, so an email
 * about an item, the activity row for what they did with it and the page
 * that shows it each have to name one of them: the one the item is shared
 * with, never simply their first. The dispatcher, the activity log and the
 * portal's context all ask here, so the email, the row and the page cannot
 * name different organizations for the same person and item.
 *
 * It also says which of a person's organizations hold back what they alone
 * share, their membership having ended (heldBackFor()). The resources, the
 * notices and the directory all ask, so the three leave out by one rule,
 * the one the dashboard and the projects list follow.
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\AccessControl\PortalGuard;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertRepository;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Core\Capabilities;
use Monstera\Forms\Meta as FormMeta;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Reach {

	/**
	 * Of the person's organizations, the one among those an audience names
	 * that speaks for the item, in three tiers: a live one first, neither
	 * ended nor suspended nor archived (the visibility engine lets an active
	 * organization carry an item past a suspended or an archived one, so the
	 * live one is how they hold it); then one that is merely unended, so an
	 * ended membership never outranks a suspended one; then the first in
	 * their membership order. 0 when none of theirs is among them: the
	 * caller decides what stands in.
	 *
	 * @param array<int, mixed> $orgIds The organizations the audience names.
	 */
	public static function among( int $userId, array $orgIds ): int {
		// array_intersect keeps the first array's order: the person's memberships, oldest first.
		// One in the trash grants nothing, so it is never the one named (the fix's review, 2026-10-19).
		$mine = array_values( array_intersect( Repository::onSite( Roster::orgIdsOf( $userId ) ), array_map( 'intval', $orgIds ) ) );
		if ( count( $mine ) < 2 ) {
			// One organization of theirs holds the item: that one, whatever its standing.
			return $mine[0] ?? 0;
		}
		foreach ( $mine as $orgId ) {
			if ( self::isLive( $orgId ) ) {
				return $orgId;
			}
		}
		foreach ( $mine as $orgId ) {
			if ( ! PortalGuard::membershipExpired( $orgId ) ) {
				return $orgId;
			}
		}
		return $mine[0];
	}

	/**
	 * The organizations a content item names as its audience. None for an
	 * item for everyone: the flag is its audience then, and a list the editor
	 * kept from before the flag was set names nobody, as the visibility
	 * engine reads it. The item's page (Portal\Context) and its rows and
	 * emails (ofContent()) both ask here, so they hold to one rule.
	 *
	 * @return list<int>
	 */
	public static function contentOrgs( int $contentId ): array {
		if ( (bool) get_post_meta( $contentId, ContentMeta::KEY_AUDIENCE_EVERYONE, true ) ) {
			return [];
		}
		return array_values( array_filter( array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true ) ) ) );
	}

	/**
	 * The organization a content item reaches the person through: the one
	 * of theirs in its audience. Content for everyone is no one
	 * organization's, and a person the item names on its standalone list
	 * reaches it through none, so for both their first organization on the
	 * site stands in (Repository::primaryOnSite(): never one in the trash),
	 * which is 0 for a standalone member. A sub-group that
	 * narrows an item for everyone does not make the item its organization's
	 * (Content\Repository::forOrgs() still files it under every
	 * organization), so the primary one stands in there too, where an alert
	 * or a resource aimed at a sub-group alone is its parent organization's.
	 */
	public static function ofContent( int $userId, int $contentId ): int {
		return self::among( $userId, self::contentOrgs( $contentId ) ) ?: Repository::primaryOnSite( $userId );
	}

	/**
	 * The organization an alert reaches the person through: an alert still
	 * on the legacy project scope names its project's organization; any
	 * other, the one of theirs in its audience, as for content. An alert
	 * narrowed to sub-groups reaches them through the groups they are in
	 * (amongReached()), which is how the notices band reads it.
	 *
	 * @param int[]|null $memberSubgroups The sub-groups the person is in, when the caller has them (a batch of emails reads them together); read here when null.
	 */
	public static function ofAlert( int $userId, int $alertId, ?array $memberSubgroups = null ): int {
		if ( ! AlertRepository::hasAudience( $alertId ) && AlertMeta::SCOPE_PROJECT === (string) get_post_meta( $alertId, AlertMeta::KEY_SCOPE, true ) ) {
			foreach ( (array) get_post_meta( $alertId, AlertMeta::KEY_SCOPE_IDS, true ) as $projectId ) {
				$orgId = (int) get_post_meta( (int) $projectId, ProjectMeta::KEY_ORG_ID, true );
				if ( $orgId > 0 ) {
					return $orgId;
				}
			}
		}
		$audience = AlertRepository::audienceOf( $alertId );
		$reached  = self::amongReached(
			$userId,
			[] !== $audience['subgroup_ids'],
			$memberSubgroups,
			static fn ( ?array $subgroups ): array => self::audienceOrgs( $audience, $subgroups )
		);
		return $reached ?: Repository::primaryOnSite( $userId );
	}

	/**
	 * The organizations an alert's audience names: its own list, and the
	 * parents of the sub-groups it is narrowed to. An alert aimed at
	 * sub-groups alone names no organization of its own, so the groups'
	 * parents stand in, and a person in two organizations is written to as
	 * the one whose group it is. An alert for everyone names none by its
	 * list: the flag is its audience then, whatever list it kept.
	 *
	 * Asked with the sub-groups one person is in, only those groups' parents
	 * are counted: a sub-group they are not in brings them nothing, so its
	 * organization is not one the alert reaches them through. Whether an
	 * ended membership holds the alert back is asked that way, or an alert
	 * for an ended organization's group and a running one's would stay in
	 * front of someone who sits in the ended one's alone.
	 *
	 * @param array{all: bool, org_ids: int[], member_ids: int[], subgroup_ids: int[]} $audience        As Alerts\Repository::audienceOf() gives it.
	 * @param int[]|null                                                               $memberSubgroups The sub-groups one person is in, to count those alone; null counts every sub-group named.
	 * @return list<int>
	 */
	public static function audienceOrgs( array $audience, ?array $memberSubgroups = null ): array {
		$orgIds = $audience['all'] ? [] : array_map( 'intval', $audience['org_ids'] );
		$groups = array_map( 'intval', $audience['subgroup_ids'] );
		foreach ( null === $memberSubgroups ? $groups : array_intersect( $groups, $memberSubgroups ) as $groupId ) {
			$orgIds[] = self::parentOf( $groupId );
		}
		return array_values( array_unique( array_filter( $orgIds ) ) );
	}

	/**
	 * The organization a resource reaches the person through: the one of
	 * theirs it names (formOrgs()), and when it is narrowed to sub-groups,
	 * the one whose group they are in (amongReached()), which is the
	 * organization its row names (Forms\Repository::besideEach()). A
	 * resource for every member names nobody, and their first organization
	 * on the site stands in.
	 *
	 * @param int[]|null $memberSubgroups The sub-groups the person is in, when the caller has them; read here when null.
	 */
	public static function ofForm( int $userId, int $formId, ?array $memberSubgroups = null ): int {
		$narrowed = [] !== array_filter( array_map( 'intval', (array) get_post_meta( $formId, FormMeta::KEY_SUBGROUPS, true ) ) );
		$reached  = self::amongReached(
			$userId,
			$narrowed,
			$memberSubgroups,
			static fn ( ?array $subgroups ): array => self::formOrgs( $formId, $subgroups )
		);
		return $reached ?: Repository::primaryOnSite( $userId );
	}

	/**
	 * Of the person's organizations, the one an alert or a resource reaches
	 * them through, by the one rule its row and the hold-back follow: the
	 * organizations of theirs it names, and the parents of the sub-groups
	 * it names that they are in. The parent of a group they are not in is
	 * not counted. Counting it would file the activity row and address the
	 * email as a member of an organization where no group of theirs
	 * receives the item, while the row beside it names another.
	 *
	 * Someone the item reaches through none of them that way still did
	 * something with it: an organization's manager who posts for a group
	 * they do not sit in, one of the team, a person the item names. For
	 * them every sub-group named is counted, as it was for everyone, so
	 * what they did is filed under the organization of theirs the item is
	 * about and not simply under their first.
	 *
	 * The person's sub-groups are read only when the item names any.
	 *
	 * @param int[]|null                       $memberSubgroups The sub-groups the person is in; read here when null.
	 * @param callable(int[]|null): list<int> $orgs            The item's organizations, counting the sub-groups given or every one named for null: formOrgs() or audienceOrgs().
	 */
	private static function amongReached( int $userId, bool $narrowed, ?array $memberSubgroups, callable $orgs ): int {
		if ( ! $narrowed ) {
			return self::among( $userId, $orgs( null ) );
		}
		$memberSubgroups ??= ( new SubgroupRepository() )->publishedSubgroupsForMember( $userId );
		return self::among( $userId, $orgs( $memberSubgroups ) ) ?: self::among( $userId, $orgs( null ) );
	}

	/**
	 * The organizations a resource names: its own list, and the parent of
	 * each sub-group it is narrowed to, since a resource for one
	 * organization's sub-group is that organization's
	 * (Forms\Repository::forOrg() reads it the same way). None for a
	 * resource for every member.
	 *
	 * Asked with the sub-groups one person is in, only those groups' parents
	 * are counted, as for an alert (audienceOrgs()): the organizations the
	 * resource reaches that person through, which is what holds it back,
	 * pauses its file and is named on its row.
	 *
	 * @param int[]|null $memberSubgroups The sub-groups one person is in, to count those alone; null counts every sub-group named.
	 * @return list<int>
	 */
	public static function formOrgs( int $formId, ?array $memberSubgroups = null ): array {
		$orgIds = array_map( 'intval', (array) get_post_meta( $formId, FormMeta::KEY_ORGS, true ) );
		$groups = array_filter( array_map( 'intval', (array) get_post_meta( $formId, FormMeta::KEY_SUBGROUPS, true ) ) );
		foreach ( null === $memberSubgroups ? $groups : array_intersect( $groups, $memberSubgroups ) as $groupId ) {
			$orgIds[] = self::parentOf( $groupId );
		}
		return array_values( array_unique( array_filter( $orgIds ) ) );
	}

	/**
	 * Read together whose the sub-groups are that a list of resources or
	 * alerts names and one person is in, before each item is asked which
	 * organizations it reaches them through (formOrgs() and audienceOrgs()
	 * with their sub-groups): one read however many sub-groups, where asking
	 * them in turn is a read apiece, on lists every portal page prints. The
	 * items' own meta came with the query that listed them, so finding the
	 * sub-groups reads nothing, and nothing is read when none is named or
	 * when all of them were read already.
	 *
	 * @param array<int, mixed> $posts           The items, as a query gives them.
	 * @param string            $key             The meta key they keep their sub-groups under.
	 * @param int[]             $memberSubgroups The sub-groups the person is in.
	 */
	public static function primeParents( array $posts, string $key, array $memberSubgroups ): void {
		$named = [];
		foreach ( $posts as $post ) {
			if ( $post instanceof WP_Post ) {
				$named = array_merge( $named, array_map( 'intval', (array) get_post_meta( $post->ID, $key, true ) ) );
			}
		}
		update_postmeta_cache( array_values( array_unique( array_intersect( $named, $memberSubgroups ) ) ) );
	}

	/**
	 * The person's organizations whose ended membership holds back what
	 * they alone share (People-model track, FR5; the Phase 5 task): those
	 * whose membership date has passed. It is the rule the dashboard's feed
	 * and the projects list follow, here for the surfaces no page guard
	 * stands in front of, the resources, the notices and the directory. A
	 * suspended organization has not ended, so it is never among them: what
	 * it shares stays, as its content stays readable.
	 *
	 * A person in one organization is held back as a person in several is,
	 * and so is one none of whose memberships is still running (decided at
	 * the Phase 6 task after the Phase 5 checkpoint, for the owner at Phase
	 * 6's; spec FR5 as built). The guard closes the dashboard, the projects and each hub
	 * to those people, and the pages it leaves open leave out what the ended
	 * organizations alone grant, saying whose resources are waiting as they
	 * say it beside a running organization.
	 *
	 * None for staff, who read every resource and alert whatever the
	 * standing of an organization they also belong to. That is said here
	 * and nowhere else, so the lists and the rows that label them cannot
	 * come to answer it differently.
	 *
	 * The end dates are read together, so six organizations cost what two
	 * do, and nothing at all once the shell has read them.
	 *
	 * @return list<int>
	 */
	public static function heldBackFor( WP_User $user ): array {
		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return [];
		}
		// One in the trash grants nothing, so nothing is held back for it, nor
		// does it carry what an ended one shares (the fix's review, 2026-10-19).
		$mine = Repository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		if ( ! $mine ) {
			return [];
		}
		// The organizations and their meta: whether each is live reads its
		// post status too (Repository::statusOf()).
		_prime_post_caches( $mine, false, false );
		update_postmeta_cache( $mine );
		return array_values( array_filter( $mine, [ PortalGuard::class, 'membershipExpired' ] ) );
	}

	/**
	 * Whether something that names these organizations reaches the person
	 * through held-back ones alone: at least one of theirs is among them,
	 * and every one that is has ended beside a running one. What a running
	 * organization of theirs shares too is not held back; nor is what names
	 * none of theirs, which reaches them some other way (it is for everyone,
	 * or it names them), and the caller keeps.
	 *
	 * @param array<int, mixed> $orgIds   The organizations the item names.
	 * @param list<int>         $heldBack What heldBackFor() answered for the person.
	 */
	public static function onlyThrough( int $userId, array $orgIds, array $heldBack ): bool {
		if ( ! $heldBack ) {
			return false;
		}
		$through = array_intersect( Repository::onSite( Roster::orgIdsOf( $userId ) ), array_map( 'intval', $orgIds ) );
		return $through && ! array_diff( $through, $heldBack );
	}

	/**
	 * Whether an organization is live: its membership has not ended and its
	 * status is active, which is to say it is published (Repository::statusOf()).
	 * One in the trash is not, whatever status it went with (the fix's review, 2026-10-19).
	 */
	public static function isLive( int $orgId ): bool {
		return Repository::isOnSite( $orgId )
			&& ! PortalGuard::membershipExpired( $orgId )
			&& Meta::STATUS_ACTIVE === Repository::statusOf( $orgId );
	}

	/** The organization a sub-group sits under. */
	private static function parentOf( int $subgroupId ): int {
		return (int) get_post_meta( $subgroupId, SubgroupMeta::KEY_ORG_ID, true );
	}
}
