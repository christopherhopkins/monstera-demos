<?php
/**
 * Who may do what to an organization's roster, decided once (People-model
 * track, FR2's table and FR7). The roster's routes refuse by it
 * (Rest\Controllers\OrgMembersController) and the hub's Members tab offers
 * by it (Portal/Templates/partials/_org-members.php), so a control the page
 * shows is one the route honours, and the table is written in one place.
 *
 * The answer is for one person in one organization: the team
 * (manage_monstera: both staff roles and a WordPress administrator) does
 * everything in any organization; anyone else is whatever their tier is
 * there, under the capability their role gives. An organization admin
 * invites at any tier, changes tiers and removes anyone; a manager invites
 * and removes plain members and changes no tier; a member does nothing. The
 * one thing an organization admin may not do is leave the organization
 * without an admin by stepping down or leaving while they are its only one,
 * which the team may.
 *
 * Each refusal is the route's own answer: a 403 with the sentence that says
 * who may, a 409 for what the roster's present state does not allow, a 422
 * for an invitation there is none of to send again. The page never shows
 * them at rest, because it offers only what would not be refused; it shows
 * them when the roster has changed behind it.
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Capabilities;
use Monstera\Members\UserMeta;
use WP_Error;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class RosterPolicy {

	/**
	 * The tiers in the order a tier control lists them (comps 43, 120 and
	 * 121): the least first.
	 *
	 * @var list<string>
	 */
	public const CONTROL_ORDER = [ Roster::TIER_MEMBER, Roster::TIER_MANAGER, Roster::TIER_ADMIN ];

	private function __construct(
		private readonly int $actorId,
		private readonly int $orgId,
		private readonly bool $onTeam,
		private readonly ?string $tier,
		private readonly bool $manages,
		private readonly bool $invites
	) {}

	/**
	 * The policy for one person in one organization. The capabilities are
	 * the ceiling the routes ask for before anything else
	 * (monstera_manage_own_org for the roster, monstera_invite_members for
	 * an invitation) and the tier held here is the answer: a manager of
	 * another organization is a plain member of this one.
	 */
	public static function of( WP_User $actor, int $orgId ): self {
		$onTeam    = user_can( $actor, Capabilities::CAP_MANAGE_MONSTERA );
		$tier      = Roster::roleOf( (int) $actor->ID, $orgId );
		$leadsHere = in_array( $tier, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true );
		return new self(
			(int) $actor->ID,
			$orgId,
			$onTeam,
			$tier,
			$onTeam || ( $leadsHere && user_can( $actor, Capabilities::CAP_MANAGE_OWN_ORG ) ),
			$onTeam || ( $leadsHere && user_can( $actor, Capabilities::CAP_INVITE_MEMBERS ) )
		);
	}

	/** Whether the roster is theirs to work on at all: the team, and the organization's admins and managers. */
	public function manages(): bool {
		return $this->manages;
	}

	/**
	 * Whether they hold an organization admin's powers here: the team in
	 * any organization, anyone else only where their tier is admin. The line
	 * between an organization's admins and its managers.
	 */
	public function actsAsAdmin(): bool {
		return $this->manages && ( $this->onTeam || Roster::TIER_ADMIN === $this->tier );
	}

	/**
	 * Whether the last-admin rule binds them. The team is not held to it: an
	 * organization may be left with no admin by the people who can name the
	 * next one.
	 */
	public function keepsAnAdmin(): bool {
		return ! $this->onTeam;
	}

	/** Whether the person is the organization's only admin. */
	public function isOnlyAdmin( int $memberId ): bool {
		return Roster::memberIds( $this->orgId, [ Roster::TIER_ADMIN ] ) === [ $memberId ];
	}

	// ---- What a route refuses --------------------------------------------------

	/**
	 * Why they may not invite at this tier, or null when they may. Who
	 * manages the organization is its admins' to say, so a manager invites
	 * plain members.
	 *
	 * Of the two refusals only the second is about the tier asked for, and
	 * it says so: the invite form shows it on its Tier field. The first is
	 * about who the caller is here, whatever tier they ask for, and is the
	 * form's own to say.
	 */
	public function inviteRefusal( string $tier ): ?WP_Error {
		if ( ! $this->invites ) {
			return self::notTheirs();
		}
		if ( Roster::TIER_MEMBER !== $tier && ! $this->actsAsAdmin() ) {
			return self::refused( __( 'Only an organization admin can invite a manager or an organization admin.', 'monstera' ), 'tier' );
		}
		return null;
	}

	/**
	 * Why they may change no tier here, or null when they may. Asked before
	 * the tier and the person are looked at, so a manager is told who may
	 * whatever they name.
	 */
	public function tiersRefusal(): ?WP_Error {
		if ( ! $this->manages ) {
			return self::notTheirs();
		}
		if ( ! $this->actsAsAdmin() ) {
			return self::refused( __( 'Only an organization admin can change tiers.', 'monstera' ) );
		}
		return null;
	}

	/**
	 * Why they may not move this person to that tier, or null when they
	 * may: the table first, then the organization's only admin stepping
	 * down. Staying an admin steps down from nothing.
	 */
	public function tierRefusal( int $memberId, string $to ): ?WP_Error {
		$refusal = $this->tiersRefusal();
		if ( $refusal ) {
			return $refusal;
		}
		if ( Roster::TIER_ADMIN !== $to && $this->isOnlyAdminThemselves( $memberId ) ) {
			return self::lastAdmin();
		}
		return null;
	}

	/**
	 * Why they may not remove this person, or null when they may. A manager
	 * removes plain members; anyone above is the admins' to remove, and the
	 * organization's only admin does not leave it.
	 */
	public function removalRefusal( int $memberId ): ?WP_Error {
		if ( ! $this->manages ) {
			return self::notTheirs();
		}
		if ( Roster::TIER_MEMBER !== Roster::roleOf( $memberId, $this->orgId ) && ! $this->actsAsAdmin() ) {
			return self::refused( __( 'Only an organization admin can remove a manager or an organization admin.', 'monstera' ) );
		}
		if ( $this->isOnlyAdminThemselves( $memberId ) ) {
			return self::lastAdmin();
		}
		return null;
	}

	/**
	 * Why this person's invitation cannot be sent again, or null when it
	 * can. Someone who has signed in has nothing to resend: they have a
	 * password, and the email that told an attached person they were added
	 * is a notice, not a link that lapses.
	 */
	public function resendRefusal( int $memberId ): ?WP_Error {
		if ( ! $this->manages ) {
			return self::notTheirs();
		}
		if ( UserMeta::hasSignedIn( $memberId ) ) {
			return new WP_Error( 'monstera_already_signed_in', __( 'That member has already signed in, so there is no invitation to resend.', 'monstera' ), [ 'status' => 422 ] );
		}
		return null;
	}

	// ---- What the page offers --------------------------------------------------

	/**
	 * The tiers the invite form offers, in the order its select lists
	 * them: none for someone who may not invite, Member alone for a manager
	 * (the form then shows no tier at all), all three for an organization
	 * admin and the team.
	 *
	 * @return list<string>
	 */
	public function inviteTiers(): array {
		return array_values(
			array_filter(
				self::CONTROL_ORDER,
				fn ( string $tier ): bool => null === $this->inviteRefusal( $tier )
			)
		);
	}

	/**
	 * What the roster offers on one person's row: the tiers they may be
	 * moved to (none means no tier control), Remove, and Resend. Each is
	 * what the route would not refuse, with one line drawn tighter: nobody
	 * is offered a control on their own row (comps 43 and 44). For an
	 * organization's only admin the route would refuse both anyway; an
	 * admin among several may step down or leave by the route, and asks
	 * another admin to do it from here.
	 *
	 * @return array{tiers: list<string>, remove: bool, resend: bool}
	 */
	public function rowOffer( int $memberId ): array {
		if ( $memberId === $this->actorId ) {
			return [
				'tiers'  => [],
				'remove' => false,
				'resend' => false,
			];
		}
		$held = Roster::roleOf( $memberId, $this->orgId );
		return [
			'tiers'  => array_values(
				array_filter(
					self::CONTROL_ORDER,
					fn ( string $tier ): bool => $tier !== $held && null === $this->tierRefusal( $memberId, $tier )
				)
			),
			'remove' => null === $this->removalRefusal( $memberId ),
			'resend' => null === $this->resendRefusal( $memberId ),
		];
	}

	/**
	 * A row's offer as three plain answers, for a reader that only tells
	 * whether a row offers a thing: the roster route's rows (`can`) and the
	 * mark each row of the page carries (`data-can`). The portal's store
	 * holds the one against the other when it reads the roster again, so
	 * both are made here, of the one offer.
	 *
	 * @param array{tiers: list<string>, remove: bool, resend: bool} $offer What rowOffer() answered.
	 * @return array{tier: bool, remove: bool, resend: bool}
	 */
	public static function rowCan( array $offer ): array {
		return [
			'tier'   => [] !== $offer['tiers'],
			'remove' => $offer['remove'],
			'resend' => $offer['resend'],
		];
	}

	// ---- The refusals ----------------------------------------------------------

	/**
	 * Whether the request is an organization admin acting on themselves
	 * while they are its only admin. They may not step down or leave until
	 * there is another, or the organization would have nobody who can
	 * change a tier; acting on anyone else always leaves the actor.
	 */
	private function isOnlyAdminThemselves( int $memberId ): bool {
		return $this->keepsAnAdmin() && $this->actorId === $memberId && $this->isOnlyAdmin( $memberId );
	}

	/**
	 * The refusal for it: 409, as for any change the record's present state
	 * does not allow (a closed request, an alert that is not live).
	 */
	private static function lastAdmin(): WP_Error {
		return new WP_Error(
			'monstera_last_admin',
			__( 'You are this organization\'s only admin. Make someone else an organization admin first.', 'monstera' ),
			[ 'status' => 409 ]
		);
	}

	/** The answer to someone the roster is not theirs to work on. */
	public static function notTheirs(): WP_Error {
		return self::refused( __( 'You can only manage an organization you are an admin or manager of.', 'monstera' ) );
	}

	/**
	 * A refusal by FR2's table: 403, and the sentence that says who may.
	 * Most are about who the caller is and name no field. One that is about
	 * a field of the form that asked names it in the error data, as the 422s
	 * of these routes do, so the page shows the sentence on that field and
	 * not on whichever one it guesses.
	 *
	 * @param string|null $field The request parameter the refusal is about, when it is about one.
	 */
	private static function refused( string $sentence, ?string $field = null ): WP_Error {
		$data = [ 'status' => 403 ];
		if ( null !== $field ) {
			$data['field'] = $field;
		}
		return new WP_Error( 'monstera_forbidden', $sentence, $data );
	}
}
