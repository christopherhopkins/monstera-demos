<?php
/**
 * Membership renewal mechanics.
 *
 * The renewal *rule* lives here; the renewal *payment* does not. The Payments
 * module (a separate effort) fires Hooks::PAYMENT_COMPLETED after a successful
 * charge; onPaymentCompleted() maps a renewal payment to applyRenewal(). This
 * is the seam that keeps billing out of the membership core, so the rule —
 * expiry = payment date + 1 year, no pro-rating on early renewal — is testable
 * without Stripe (e.g. `wp monstera renew <orgId>`).
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use DateTimeImmutable;
use DateTimeZone;
use Monstera\Core\Hooks;
use Monstera\Core\SiteDay;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

final class Membership {

	/**
	 * Per-window expiry-reminder dedupe flags set by Notifications\Expiration.
	 * They belong to a term: any change of the organization's expiry clears
	 * them (onExpiryWritten()), so the new term's reminders go out.
	 *
	 * @var string[]
	 */
	private const NOTICE_FLAGS = [
		'_monstera_notice_warning_30',
		'_monstera_notice_warning_14',
		'_monstera_notice_warning_7',
		'_monstera_notice_warning_1',
		'_monstera_notice_expired',
	];

	/** Standalone-member auto-suspend flag (ExpiredMembersSync). */
	private const MEMBER_SUSPENDED = 'monstera_member_suspended';

	public static function register(): void {
		add_action( Hooks::PAYMENT_COMPLETED, [ self::class, 'onPaymentCompleted' ] );
		// An organization's expiry written by any door starts a new term.
		add_action( 'added_post_meta', [ self::class, 'onExpiryWritten' ], 10, 3 );
		add_action( 'updated_post_meta', [ self::class, 'onExpiryWritten' ], 10, 3 );
	}

	/**
	 * A new expiry is a new term, and the reminders the old one had are not
	 * the new one's: an organization's expiry written by any door (a
	 * renewal, the admin's "Renews on", the new-organization form, `wp post
	 * meta update` on the command line) clears the reminder flags, so the
	 * new term's reminders go out on their days (Notifications\Expiration).
	 * WordPress says a value was written only when it changed, so a save
	 * that leaves the date as it was clears nothing. A date blanked by a
	 * save is a write, and clears them; one deleted outright
	 * (delete_post_meta()) leaves them, as with no date there is nothing to
	 * remind of, and the next date written clears them. A write straight to
	 * the database is not heard.
	 *
	 * @param mixed $metaId The row written; unused.
	 */
	public static function onExpiryWritten( mixed $metaId, int $objectId, string $metaKey ): void {
		if ( Meta::KEY_EXPIRES !== $metaKey || PostType::SLUG !== get_post_type( $objectId ) ) {
			return;
		}
		foreach ( self::NOTICE_FLAGS as $flag ) {
			delete_post_meta( $objectId, $flag );
		}
	}

	/**
	 * The standard membership term is one year, so a freshly created org with no
	 * explicit renewal date starts on that cycle — one year from today. Mirrors
	 * the +1-year rule applyRenewal() uses, keeping the term length in one place.
	 * Returns a Y-m-d date string.
	 */
	public static function defaultExpiry(): string {
		return SiteDay::yearAfter( time() );
	}

	/**
	 * Whether the self-serve "Renew" CTA should be offered for an org: within
	 * renewal_window days of expiry, or already expired (or no expiry set yet).
	 * Admins bypass this elsewhere; this is the member-facing availability gate.
	 */
	public static function renewalOpen( int $orgId ): bool {
		return self::expiryWithinWindow( (string) get_post_meta( $orgId, Meta::KEY_EXPIRES, true ) );
	}

	public static function memberRenewalOpen( int $userId ): bool {
		return self::expiryWithinWindow( (string) get_user_meta( $userId, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ) );
	}

	private static function expiryWithinWindow( string $expires ): bool {
		if ( '' === $expires ) {
			return true; // no expiry yet — allow a renewal to establish one
		}
		// The site's days to its last (Core\SiteDay).
		$since = SiteDay::daysSince( $expires );
		if ( null === $since ) {
			return true;
		}
		return -$since <= max( 0, (int) get_option( 'monstera_renewal_window', 60 ) );
	}

	/**
	 * Apply a completed org renewal: set expiry = paidAt + 1 year (no pro-rating
	 * of any remaining time on an early renewal), reactivate an org
	 * auto-suspended purely for expiry, and fire Hooks::MEMBERSHIP_RENEWED. The
	 * new expiry clears the expiry-reminder dedupe flags, as any new expiry does
	 * (onExpiryWritten()). Returns the new expiry date (Y-m-d).
	 *
	 * @param string $paidAtMysqlUtc UTC mysql datetime of the payment.
	 */
	public static function applyRenewal( int $orgId, string $paidAtMysqlUtc ): string {
		// A year from the site's day it was paid (Core\SiteDay).
		$newDate = SiteDay::yearAfter( self::paidAt( $paidAtMysqlUtc ) );

		update_post_meta( $orgId, Meta::KEY_EXPIRES, $newDate );

		// Reactivate an org that StatusSync auto-suspended for expiry; an
		// archived org stays archived.
		$repo = new Repository();
		if ( Meta::STATUS_SUSPENDED === $repo->status( $orgId ) ) {
			$repo->setStatus( $orgId, Meta::STATUS_ACTIVE );
		}

		do_action( Hooks::MEMBERSHIP_RENEWED, $orgId, $newDate, $paidAtMysqlUtc );
		return $newDate;
	}

	/**
	 * The payment's moment: a UTC datetime as the seam sends it, or one that
	 * names its own zone, read in it whatever PHP's default zone (the Phase
	 * 5 review); now for one that names no moment.
	 */
	private static function paidAt( string $paidAt ): int {
		try {
			return ( new DateTimeImmutable( $paidAt, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
		} catch ( \Exception ) {
			return time();
		}
	}

	/**
	 * Apply a completed standalone-member renewal (orgId 0 in the renewed
	 * hook): the same rule as an organization's, and the same clearing of
	 * the expiry reminders sent (one record on the member,
	 * UserMeta::KEY_EXPIRY_NOTICES), so the new term's go out on their days
	 * (Notifications\Expiration).
	 */
	public static function applyMemberRenewal( int $userId, string $paidAtMysqlUtc ): string {
		$newDate = SiteDay::yearAfter( self::paidAt( $paidAtMysqlUtc ) );

		update_user_meta( $userId, UserMeta::KEY_MEMBERSHIP_EXPIRES, $newDate );
		delete_user_meta( $userId, UserMeta::KEY_EXPIRY_NOTICES );
		delete_user_meta( $userId, self::MEMBER_SUSPENDED );

		do_action( Hooks::MEMBERSHIP_RENEWED, 0, $newDate, $paidAtMysqlUtc );
		return $newDate;
	}

	/**
	 * Payment seam: a renewal-type completed payment applies the renewal. Org
	 * renewals carry org_id; standalone renewals carry user_id.
	 *
	 * @param mixed $context
	 */
	public static function onPaymentCompleted( $context ): void {
		$context = (array) $context;
		if ( 'renewal' !== ( $context['type'] ?? '' ) ) {
			return;
		}
		$paidAt = (string) ( $context['paid_at'] ?? current_time( 'mysql', true ) );
		$orgId  = (int) ( $context['org_id'] ?? 0 );
		$userId = (int) ( $context['user_id'] ?? 0 );

		if ( $orgId > 0 ) {
			self::applyRenewal( $orgId, $paidAt );
		} elseif ( $userId > 0 ) {
			self::applyMemberRenewal( $userId, $paidAt );
		}
	}
}
