<?php
/**
 * Membership renewal mechanics.
 *
 * The renewal *rule* lives here; the renewal *payment* does not. The Payments
 * module (a separate effort) fires Hooks::PAYMENT_COMPLETED after a successful
 * charge; onPaymentCompleted() maps a renewal payment to applyRenewal(). This
 * is the seam that keeps billing out of the membership core, so the rule —
 * expiry = payment date + 1 year, no pro-rating on early renewal — is testable
 * without Stripe (e.g. `wp monstera renew <orgId>`).
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

final class Membership {

	/**
	 * Per-window expiry-reminder dedupe flags set by Notifications\Expiration.
	 * Cleared on renewal so the warning sequence fires again next cycle.
	 *
	 * @var string[]
	 */
	private const NOTICE_FLAGS = [
		'_monstera_notice_warning_30',
		'_monstera_notice_warning_14',
		'_monstera_notice_warning_7',
		'_monstera_notice_warning_1',
		'_monstera_notice_expired',
	];

	/** Standalone-member auto-suspend flag (ExpiredMembersSync). */
	private const MEMBER_SUSPENDED = 'monstera_member_suspended';

	public static function register(): void {
		add_action( Hooks::PAYMENT_COMPLETED, [ self::class, 'onPaymentCompleted' ] );
	}

	/**
	 * The standard membership term is one year, so a freshly created org with no
	 * explicit renewal date starts on that cycle — one year from today. Mirrors
	 * the +1-year rule applyRenewal() uses, keeping the term length in one place.
	 * Returns a Y-m-d date string.
	 */
	public static function defaultExpiry(): string {
		return gmdate( 'Y-m-d', (int) strtotime( '+1 year' ) );
	}

	/**
	 * Whether the self-serve "Renew" CTA should be offered for an org: within
	 * renewal_window days of expiry, or already expired (or no expiry set yet).
	 * Admins bypass this elsewhere; this is the member-facing availability gate.
	 */
	public static function renewalOpen( int $orgId ): bool {
		return self::expiryWithinWindow( (string) get_post_meta( $orgId, Meta::KEY_EXPIRES, true ) );
	}

	public static function memberRenewalOpen( int $userId ): bool {
		return self::expiryWithinWindow( (string) get_user_meta( $userId, UserMeta::KEY_MEMBERSHIP_EXPIRES, true ) );
	}

	private static function expiryWithinWindow( string $expires ): bool {
		if ( '' === $expires ) {
			return true; // no expiry yet — allow a renewal to establish one
		}
		$ts = strtotime( $expires );
		if ( ! $ts ) {
			return true;
		}
		$window = max( 0, (int) get_option( 'monstera_renewal_window', 60 ) );
		return time() >= ( $ts - $window * DAY_IN_SECONDS );
	}

	/**
	 * Apply a completed org renewal: expiry = paidAt + 1 year (no pro-rating of
	 * any remaining time on an early renewal), clear the expiry-reminder dedupe
	 * flags, reactivate an org auto-suspended purely for expiry, and fire
	 * Hooks::MEMBERSHIP_RENEWED. Returns the new expiry date (Y-m-d).
	 *
	 * @param string $paidAtMysqlUtc UTC mysql datetime of the payment.
	 */
	public static function applyRenewal( int $orgId, string $paidAtMysqlUtc ): string {
		$paidTs  = strtotime( $paidAtMysqlUtc ) ?: time();
		$newDate = gmdate( 'Y-m-d', (int) strtotime( '+1 year', $paidTs ) );

		update_post_meta( $orgId, Meta::KEY_EXPIRES, $newDate );

		foreach ( self::NOTICE_FLAGS as $flag ) {
			delete_post_meta( $orgId, $flag );
		}

		// Reactivate an org that StatusSync auto-suspended for expiry; an
		// archived org stays archived.
		$repo = new Repository();
		if ( Meta::STATUS_SUSPENDED === $repo->status( $orgId ) ) {
			$repo->setStatus( $orgId, Meta::STATUS_ACTIVE );
		}

		do_action( Hooks::MEMBERSHIP_RENEWED, $orgId, $newDate, $paidAtMysqlUtc );
		return $newDate;
	}

	/**
	 * Apply a completed standalone-member renewal (orgId 0 in the renewed hook).
	 */
	public static function applyMemberRenewal( int $userId, string $paidAtMysqlUtc ): string {
		$paidTs  = strtotime( $paidAtMysqlUtc ) ?: time();
		$newDate = gmdate( 'Y-m-d', (int) strtotime( '+1 year', $paidTs ) );

		update_user_meta( $userId, UserMeta::KEY_MEMBERSHIP_EXPIRES, $newDate );
		delete_user_meta( $userId, self::MEMBER_SUSPENDED );

		do_action( Hooks::MEMBERSHIP_RENEWED, 0, $newDate, $paidAtMysqlUtc );
		return $newDate;
	}

	/**
	 * Payment seam: a renewal-type completed payment applies the renewal. Org
	 * renewals carry org_id; standalone renewals carry user_id.
	 *
	 * @param mixed $context
	 */
	public static function onPaymentCompleted( $context ): void {
		$context = (array) $context;
		if ( 'renewal' !== ( $context['type'] ?? '' ) ) {
			return;
		}
		$paidAt = (string) ( $context['paid_at'] ?? current_time( 'mysql', true ) );
		$orgId  = (int) ( $context['org_id'] ?? 0 );
		$userId = (int) ( $context['user_id'] ?? 0 );

		if ( $orgId > 0 ) {
			self::applyRenewal( $orgId, $paidAt );
		} elseif ( $userId > 0 ) {
			self::applyMemberRenewal( $userId, $paidAt );
		}
	}
}
