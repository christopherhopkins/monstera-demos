<?php
declare(strict_types=1);

namespace Monstera\Organizations;

final class Meta {

	public const STATUS_ACTIVE    = 'active';
	public const STATUS_SUSPENDED = 'suspended';
	public const STATUS_ARCHIVED  = 'archived';

	public const KEY_STATUS      = 'monstera_status';
	public const KEY_SEAT_LIMIT  = 'monstera_seat_limit';
	public const KEY_EXPIRES     = 'monstera_membership_expires';
	public const KEY_LOCATION    = 'monstera_location';
	public const KEY_DESCRIPTION = 'monstera_description';

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_STATUS,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::STATUS_ACTIVE,
				'show_in_rest'      => [
					'schema' => [
						'enum' => [ self::STATUS_ACTIVE, self::STATUS_SUSPENDED, self::STATUS_ARCHIVED ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ self::STATUS_ACTIVE, self::STATUS_SUSPENDED, self::STATUS_ARCHIVED ], true ) ? $v : self::STATUS_ACTIVE,
				'auth_callback'     => static fn () => current_user_can( 'manage_monstera' ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SEAT_LIMIT,
			[
				'type'              => 'integer',
				'single'            => true,
				'default'           => 0,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_EXPIRES,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => sanitize_text_field( (string) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_LOCATION,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_DESCRIPTION,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'wp_kses_post',
			]
		);
	}
}
