<?php
declare(strict_types=1);

namespace Monstera\Organizations;

final class TierTaxonomy {

	public const SLUG = 'monstera_org_tier';

	public static function register(): void {
		register_taxonomy(
			self::SLUG,
			[ PostType::SLUG ],
			[
				'labels'            => [
					'name'          => __( 'Tiers', 'monstera' ),
					'singular_name' => __( 'Tier', 'monstera' ),
					'add_new_item'  => __( 'Add tier', 'monstera' ),
					'edit_item'     => __( 'Edit tier', 'monstera' ),
					'search_items'  => __( 'Search tiers', 'monstera' ),
				],
				'public'            => false,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'rest_base'         => 'tiers',
				'hierarchical'      => false,
				'show_admin_column' => true,
			]
		);

		register_term_meta(
			self::SLUG,
			'min_seats',
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);
		register_term_meta(
			self::SLUG,
			'max_seats',
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);
		register_term_meta(
			self::SLUG,
			'annual_rate',
			[
				'type'              => 'number',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (float) $v,
			]
		);
	}
}
