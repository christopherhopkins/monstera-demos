<?php
/**
 * Who belongs to an organization, and the one path people join and leave
 * by. The admin's organization detail and the portal roster both come
 * through here (Admin-rail track, FR5): the seat limit applies whenever a
 * roster grows, and a person who leaves an organization, removed or moved
 * to another, leaves its sub-groups and project teams and fires the
 * removal hook.
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Portal\AuthorScope;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\PostType as SubgroupPostType;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Error;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Roster {

	/**
	 * The roles a roster can hold: the Members list's. A WordPress
	 * administrator is never one (manage_monstera is not edit_users).
	 *
	 * @var list<string>
	 */
	public const ROLES = [
		Capabilities::ROLE_ADMIN,
		Capabilities::ROLE_ORG_MANAGER,
		Capabilities::ROLE_MEMBER,
		Capabilities::ROLE_MEMBER_STANDALONE,
	];

	/**
	 * @return list<int>
	 */
	public static function memberIds( int $orgId ): array {
		if ( $orgId <= 0 ) {
			return [];
		}
		return array_values(
			array_map(
				'intval',
				(array) get_users(
					[
						'meta_key'   => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
						'meta_value' => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
						'fields'     => 'ID',
						'number'     => -1,
					]
				)
			)
		);
	}

	public static function seatLimit( int $orgId ): int {
		return $orgId > 0 ? (int) get_post_meta( $orgId, Meta::KEY_SEAT_LIMIT, true ) : 0;
	}

	/**
	 * Whether a roster of $size fits the limit. 0 means no limit, and a
	 * roster that does not grow always fits, so one already over a lowered
	 * limit can still lose people.
	 *
	 * @param int|null $limit The limit to test against; the stored one when null.
	 */
	public static function fits( int $orgId, int $size, ?int $limit = null ): bool {
		$limit ??= self::seatLimit( $orgId );
		return $limit <= 0 || $size <= $limit || $size <= count( self::memberIds( $orgId ) );
	}

	/**
	 * Why a proposed roster cannot be saved, or null when it can. Checked
	 * before anything is written: people newly added must hold a roster
	 * role, each invite must be a free email address, and the whole roster
	 * must fit the limit.
	 *
	 * @param list<int>    $ids     The people the roster should hold.
	 * @param list<string> $invites Email addresses to invite.
	 * @param int|null     $limit   The seat limit the save will leave; the stored one when null.
	 */
	public static function refusal( int $orgId, array $ids, array $invites, ?int $limit = null ): ?string {
		$ids     = self::cleanIds( $ids );
		$current = self::memberIds( $orgId );
		foreach ( array_diff( $ids, $current ) as $userId ) {
			$user = get_user_by( 'id', $userId );
			if ( ! $user instanceof WP_User || ! array_intersect( $user->roles, self::ROLES ) || in_array( 'administrator', $user->roles, true ) ) {
				return __( 'Only Monstera members can join an organization.', 'monstera' );
			}
		}
		foreach ( self::cleanInvites( $invites ) as $email ) {
			if ( ! is_email( $email ) ) {
				/* translators: %s: what was typed as an email address */
				return sprintf( __( '%s is not an email address.', 'monstera' ), $email );
			}
			if ( email_exists( $email ) ) {
				/* translators: %s: an email address */
				return sprintf( __( '%s already has an account. Find them by name instead.', 'monstera' ), $email );
			}
		}
		return self::seatRefusal( $orgId, count( $ids ) + count( self::cleanInvites( $invites ) ), $limit );
	}

	/** Why a roster of $size does not fit, or null when it does. */
	private static function seatRefusal( int $orgId, int $size, ?int $limit = null ): ?string {
		$limit ??= self::seatLimit( $orgId );
		if ( self::fits( $orgId, $size, $limit ) ) {
			return null;
		}
		return sprintf(
			/* translators: %d: the organization's seat limit */
			_n( 'This organization has %d seat. Remove someone or raise the seat limit first.', 'This organization has %d seats. Remove someone or raise the seat limit first.', $limit, 'monstera' ),
			$limit
		);
	}

	/**
	 * Make the roster exactly $ids, then invite each address. Callers check
	 * refusal() first.
	 *
	 * @param list<int>    $ids
	 * @param list<string> $invites
	 */
	public static function sync( int $orgId, array $ids, array $invites = [] ): void {
		$ids = self::cleanIds( $ids );
		foreach ( array_diff( self::memberIds( $orgId ), $ids ) as $userId ) {
			self::remove( $orgId, (int) $userId );
		}
		foreach ( $ids as $userId ) {
			self::add( $orgId, $userId );
		}
		foreach ( self::cleanInvites( $invites ) as $email ) {
			self::invite( $orgId, [ 'email' => $email ] );
		}
	}

	/**
	 * Put someone in the organization. Moving them from another one is
	 * leaving that one: its groups and teams let go of them.
	 */
	public static function add( int $orgId, int $userId ): void {
		$previous = UserMeta::associatedOrg( $userId );
		if ( $previous === $orgId ) {
			return;
		}
		update_user_meta( $userId, UserMeta::KEY_ASSOCIATED_ORG, $orgId );
		if ( $previous > 0 ) {
			self::leave( $previous, $userId );
		}
	}

	/**
	 * Take someone out. The account stays; they become standalone.
	 */
	public static function remove( int $orgId, int $userId ): void {
		if ( UserMeta::associatedOrg( $userId ) !== $orgId ) {
			return;
		}
		delete_user_meta( $userId, UserMeta::KEY_ASSOCIATED_ORG );
		self::leave( $orgId, $userId );
	}

	/**
	 * A new member of the organization, who gets the welcome email (the
	 * invitation) as every new member does. The caller checks the limit.
	 *
	 * @param array{email?:string, first_name?:string, last_name?:string} $data
	 */
	public static function invite( int $orgId, array $data ): WP_User|WP_Error {
		$user = Provisioning::createMember(
			[
				'email'      => (string) ( $data['email'] ?? '' ),
				'first_name' => (string) ( $data['first_name'] ?? '' ),
				'last_name'  => (string) ( $data['last_name'] ?? '' ),
				'role'       => Capabilities::ROLE_MEMBER,
				'org_id'     => $orgId,
			]
		);
		return $user;
	}

	/**
	 * Why one more person cannot join, or null when they can: the person
	 * must hold a roster role and the roster must fit the limit. $userId 0
	 * asks about the seat alone, for an account not made yet.
	 */
	public static function joinRefusal( int $orgId, int $userId = 0 ): ?string {
		if ( $orgId <= 0 || ( $userId > 0 && UserMeta::associatedOrg( $userId ) === $orgId ) ) {
			return null;
		}
		$roster = self::memberIds( $orgId );
		return $userId > 0
			? self::refusal( $orgId, array_merge( $roster, [ $userId ] ), [] )
			: self::seatRefusal( $orgId, count( $roster ) + 1 );
	}

	/**
	 * Drop someone from this organization's sub-groups and project teams
	 * (org-scoped memberships do not outlive the membership), end what they
	 * led or stood for there, then say so. Other organizations' groups are
	 * left alone.
	 */
	private static function leave( int $orgId, int $userId ): void {
		$subgroups = new SubgroupRepository();
		foreach ( $subgroups->subgroupsForMember( $userId ) as $groupId ) {
			if ( (int) get_post_meta( (int) $groupId, SubgroupMeta::KEY_ORG_ID, true ) === $orgId ) {
				$subgroups->removeMember( (int) $groupId, $userId );
			}
		}
		$projects = new ProjectRepository();
		foreach ( $projects->projectsForMember( $userId ) as $projectId ) {
			if ( (int) get_post_meta( (int) $projectId, ProjectMeta::KEY_ORG_ID, true ) === $orgId ) {
				$projects->removeMember( (int) $projectId, $userId );
			}
		}
		// A leadership carries the right to author for the organization, and a
		// client contact speaks for it; neither outlives the membership.
		self::forget( SubgroupPostType::SLUG, SubgroupMeta::KEY_ORG_ID, $orgId, SubgroupMeta::KEY_LEADER, $userId );
		self::forget( ProjectPostType::SLUG, ProjectMeta::KEY_ORG_ID, $orgId, ProjectMeta::KEY_PRIMARY_CONTACT, $userId );
		SubgroupRepository::flushCache();
		AuthorScope::flushCache();
		do_action( Hooks::MEMBER_REMOVED_FROM_ORG, $userId, $orgId );
	}

	/**
	 * Clear a meta key naming this person on the organization's posts of one
	 * type (the sub-groups they lead, the projects they are the contact of).
	 */
	private static function forget( string $postType, string $orgKey, int $orgId, string $personKey, int $userId ): void {
		$ids = get_posts(
			[
				'post_type'      => $postType,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- one organization's sub-groups or projects, when someone leaves it.
					[
						'key'   => $orgKey,
						'value' => (string) $orgId,
					],
					[
						'key'   => $personKey,
						'value' => (string) $userId,
					],
				],
			]
		);
		foreach ( $ids as $id ) {
			delete_post_meta( (int) $id, $personKey );
		}
	}

	/**
	 * @param array<int, mixed> $ids
	 * @return list<int>
	 */
	private static function cleanIds( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	/**
	 * @param array<int, mixed> $invites
	 * @return list<string>
	 */
	private static function cleanInvites( array $invites ): array {
		$out = [];
		foreach ( $invites as $invite ) {
			$email = strtolower( trim( sanitize_text_field( (string) $invite ) ) );
			if ( '' !== $email ) {
				$out[] = $email;
			}
		}
		return array_values( array_unique( $out ) );
	}
}
