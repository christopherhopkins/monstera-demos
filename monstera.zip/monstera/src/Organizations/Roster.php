<?php
/**
 * Who belongs to which organization, and the one path people join and
 * leave by. Every person-to-organization relationship is a row of the
 * memberships table (People-model track, FR1): a membership with a tier
 * (organization admin, manager or member) or a staff assignment, one row per
 * person and organization, never both. A person may belong to any number of
 * organizations, so adding them to one never takes them out of another;
 * removing one membership makes that organization's sub-groups and project
 * teams let go of them and fires the removal hook, and they are standalone
 * only when no membership remains. Someone who never signed in was only
 * invited, and what ends with their last membership is the invitation: the
 * account itself when the invitation made it and nothing shows it in use,
 * and otherwise its link and the client role it gave (endInvitation()). The
 * roster's routes (the admin's organization detail and the portal alike),
 * the Members routes and a new organization's first members all come
 * through here, and the seat limit applies whenever a roster grows. A
 * deleted organization and the daily sweep come through here too, because
 * a row that goes takes the role it gave with it (syncRole()) and, for
 * someone who was only invited, the account (rederive()); only a deleted
 * person's rows go without the Roster, there being no role left to derive.
 * A staff assignment lasts while the person is on the team: when their last
 * team role goes, by any door, the Roster hears it and ends what they held
 * (onRoleRemoved()), and the daily sweep ends what a role that went unheard
 * left behind.
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use InvalidArgumentException;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Members\Provisioning;
use Monstera\Members\UserMeta;
use Monstera\Portal\Audience;
use Monstera\Portal\AuthorScope;
use Monstera\Portal\Context;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Reporting\ActivityLog;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\PostType as SubgroupPostType;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Error;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Roster {

	// The tiers a membership can hold, and the row role of a staff
	// assignment, which is never a membership: not for seats, rosters, the
	// directory or the visibility engine.
	public const TIER_ADMIN   = 'admin';
	public const TIER_MANAGER = 'manager';
	public const TIER_MEMBER  = 'member';
	public const ROLE_STAFF   = 'staff';

	/** @var list<string> Every membership tier, highest first. */
	public const TIERS = [ self::TIER_ADMIN, self::TIER_MANAGER, self::TIER_MEMBER ];

	// What is left of an invitation for someone who belongs to an
	// organization (invitationOf()), which is what the end of their last
	// membership takes (remove()): nothing once they have signed in; the
	// link alone for an account that was a member in its own right before;
	// the link and the client role for an account the invitation gave its
	// role to, which stays without one; and the account itself when the
	// invitation made it and nothing shows it in use.
	public const INVITATION_NONE    = '';
	public const INVITATION_PENDING = 'pending';
	public const INVITATION_ONLY    = 'only';
	public const INVITATION_ACCOUNT = 'account';

	/**
	 * The WordPress roles a roster can hold: the Members list's, both staff
	 * roles among them. A WordPress administrator is never one
	 * (manage_monstera is not edit_users).
	 *
	 * @var list<string>
	 */
	public const ROLES = [
		Capabilities::ROLE_ADMIN,
		Capabilities::ROLE_TEAM_MEMBER,
		Capabilities::ROLE_ORG_MANAGER,
		Capabilities::ROLE_MEMBER,
		Capabilities::ROLE_MEMBER_STANDALONE,
	];

	/**
	 * Per-request memos: templates and the visibility engine ask who belongs
	 * where many times per page. Every row of a person (memberships and
	 * assignments alike, oldest first) by user id, and every row of an
	 * organization by organization id. Every write clears both.
	 *
	 * @var array<int, list<array{org_id: int, role: string, since: string}>>
	 */
	private static array $byUser = [];

	/** @var array<int, list<array{user_id: int, role: string}>> */
	private static array $byOrg = [];

	/**
	 * Forget the memos: after every write here, and in tests, where ids are
	 * reused across rolled-back transactions. The memos built on what was
	 * read here go with them: who the portal's copy is for (Portal\Audience),
	 * what a page is about (Portal\Context), what someone may author
	 * (Portal\AuthorScope) and whether they have a project
	 * (Projects\Repository) are each answered from a person's memberships,
	 * and a request that writes one and then reads must see the new state.
	 */
	public static function flushCache(): void {
		self::$byUser = [];
		self::$byOrg  = [];
		Audience::flushCache();
		Context::flushCache();
		AuthorScope::flushCache();
		ProjectRepository::flushCache();
	}

	// ---- Reads ---------------------------------------------------------------

	/**
	 * The organizations a person belongs to, oldest membership first.
	 *
	 * @return list<int>
	 */
	public static function orgIdsOf( int $userId ): array {
		return array_values( array_column( self::membershipsOf( $userId ), 'org_id' ) );
	}

	/**
	 * A person's memberships, oldest first: the organization, the tier and
	 * when it began (UTC). Assignments are not among them.
	 *
	 * @return list<array{org_id: int, tier: string, since: string}>
	 */
	public static function membershipsOf( int $userId ): array {
		$out = [];
		foreach ( self::rowsOfUser( $userId ) as $row ) {
			if ( self::ROLE_STAFF !== $row['role'] ) {
				$out[] = [
					'org_id' => $row['org_id'],
					'tier'   => $row['role'],
					'since'  => $row['since'],
				];
			}
		}
		return $out;
	}

	/** The person's tier in the organization, or null when they are not a member of it (an assignment answers null too). */
	public static function roleOf( int $userId, int $orgId ): ?string {
		$row = self::rowOf( $userId, $orgId );
		return null !== $row && self::ROLE_STAFF !== $row['role'] ? $row['role'] : null;
	}

	/** When the person's membership of the organization began (UTC, as the table stores it), or null when they are not a member of it. */
	public static function sinceOf( int $userId, int $orgId ): ?string {
		$row = self::rowOf( $userId, $orgId );
		return null !== $row && self::ROLE_STAFF !== $row['role'] ? $row['since'] : null;
	}

	/** The person's first membership by date, then id; 0 for someone with none. */
	public static function primaryOrgOf( int $userId ): int {
		$memberships = self::membershipsOf( $userId );
		return $memberships ? $memberships[0]['org_id'] : 0;
	}

	/**
	 * The organization's members, oldest membership first: those of the
	 * given tiers, or of every tier. Staff assignments are never among them.
	 *
	 * @param list<string>|null $tiers
	 * @return list<int>
	 */
	public static function memberIds( int $orgId, ?array $tiers = null ): array {
		$tiers ??= self::TIERS;
		foreach ( $tiers as $tier ) {
			self::assertTier( $tier );
		}
		$out = [];
		foreach ( self::rowsOfOrg( $orgId ) as $row ) {
			if ( in_array( $row['role'], $tiers, true ) ) {
				$out[] = $row['user_id'];
			}
		}
		return $out;
	}

	/**
	 * The staff assigned to the organization, oldest assignment first.
	 *
	 * @return list<int>
	 */
	public static function staffIds( int $orgId ): array {
		$out = [];
		foreach ( self::rowsOfOrg( $orgId ) as $row ) {
			if ( self::ROLE_STAFF === $row['role'] ) {
				$out[] = $row['user_id'];
			}
		}
		return $out;
	}

	/**
	 * The organizations a staff person is assigned to, oldest assignment
	 * first: the other side of staffIds(). Memberships are never among them.
	 * It reads the per-person memo, so a list of the team fills it for
	 * everyone first (prime()) and then asks here once per row.
	 *
	 * @return list<int>
	 */
	public static function assignedOrgIdsOf( int $userId ): array {
		return array_values( array_column( self::assignmentsOf( $userId ), 'org_id' ) );
	}

	/**
	 * A staff person's assignments, oldest first: the organization and when
	 * the assignment began (UTC), as membershipsOf() gives a membership. The
	 * staff detail shows both.
	 *
	 * @return list<array{org_id: int, since: string}>
	 */
	public static function assignmentsOf( int $userId ): array {
		$out = [];
		foreach ( self::rowsOfUser( $userId ) as $row ) {
			if ( self::ROLE_STAFF === $row['role'] ) {
				$out[] = [
					'org_id' => $row['org_id'],
					'since'  => $row['since'],
				];
			}
		}
		return $out;
	}

	public static function isMemberOf( int $userId, int $orgId ): bool {
		return null !== self::roleOf( $userId, $orgId );
	}

	public static function isAssignedTo( int $userId, int $orgId ): bool {
		$row = self::rowOf( $userId, $orgId );
		return null !== $row && self::ROLE_STAFF === $row['role'];
	}

	/**
	 * Fill the per-person memo for many people from one query, before a
	 * loop that asks about each of them: an audience's recipients and "Who
	 * can see this" put every candidate through the visibility engine, which
	 * asks orgIdsOf() per person, and a thousand candidates would be a
	 * thousand queries. People already in the memo are not asked for again,
	 * and a primed person with no rows is remembered as having none, so the
	 * loop costs no query at all until something is written.
	 *
	 * @param array<int, mixed> $userIds
	 */
	public static function prime( array $userIds ): void {
		$wanted = [];
		foreach ( array_unique( array_map( 'intval', $userIds ) ) as $userId ) {
			if ( $userId > 0 && ! array_key_exists( $userId, self::$byUser ) ) {
				$wanted[] = $userId;
			}
		}
		if ( ! $wanted ) {
			return;
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $wanted ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $wanted ); every id goes through prepare().
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- memoised for the request; the table is this class's own.
			$wpdb->prepare( "SELECT user_id, org_id, role, created_at FROM %i WHERE user_id IN ($marks) ORDER BY created_at ASC, id ASC", self::table(), ...$wanted ),
			ARRAY_A
		);
		// phpcs:enable
		foreach ( $wanted as $userId ) {
			self::$byUser[ $userId ] = [];
		}
		foreach ( $rows as $row ) {
			self::$byUser[ (int) $row['user_id'] ][] = [
				'org_id' => (int) $row['org_id'],
				'role'   => (string) $row['role'],
				'since'  => (string) $row['created_at'],
			];
		}
	}

	/**
	 * The same for organizations: fill the per-organization memo for many of
	 * them from one query, before a loop that asks who belongs to each. The
	 * organizations list counts every roster, and an audience that names
	 * several organizations gathers each one's people. Organizations already
	 * in the memo are not asked for again, and a primed organization with
	 * nobody is remembered as having nobody.
	 *
	 * @param array<int, mixed> $orgIds
	 */
	public static function primeOrgs( array $orgIds ): void {
		$wanted = [];
		foreach ( array_unique( array_map( 'intval', $orgIds ) ) as $orgId ) {
			if ( $orgId > 0 && ! array_key_exists( $orgId, self::$byOrg ) ) {
				$wanted[] = $orgId;
			}
		}
		if ( ! $wanted ) {
			return;
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $wanted ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $wanted ); every id goes through prepare().
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- memoised for the request; the table is this class's own.
			$wpdb->prepare( "SELECT user_id, org_id, role FROM %i WHERE org_id IN ($marks) ORDER BY created_at ASC, id ASC", self::table(), ...$wanted ),
			ARRAY_A
		);
		// phpcs:enable
		foreach ( $wanted as $orgId ) {
			self::$byOrg[ $orgId ] = [];
		}
		foreach ( $rows as $row ) {
			self::$byOrg[ (int) $row['org_id'] ][] = [
				'user_id' => (int) $row['user_id'],
				'role'    => (string) $row['role'],
			];
		}
	}

	// ---- Seats ---------------------------------------------------------------

	public static function seatLimit( int $orgId ): int {
		return $orgId > 0 ? (int) get_post_meta( $orgId, Meta::KEY_SEAT_LIMIT, true ) : 0;
	}

	/**
	 * Whether a roster of $size fits the limit. 0 means no limit. Only
	 * memberships hold seats. Every caller asks about a roster one person
	 * larger, or about a new organization's first members: losing people is
	 * never asked here, so a roster already over a lowered limit can still
	 * lose them.
	 *
	 * @param int|null $limit The limit to test against; the stored one when null.
	 */
	public static function fits( int $orgId, int $size, ?int $limit = null ): bool {
		$limit ??= self::seatLimit( $orgId );
		return $limit <= 0 || $size <= $limit;
	}

	/**
	 * Why a proposed roster cannot be saved, or null when it can. Checked
	 * before anything is written: people newly added must hold a roster
	 * role, each invite must be an email address the form's picker cannot
	 * offer, and the whole roster must fit the limit.
	 *
	 * An address that has an account is refused in favour of the picker,
	 * which adds the person without writing to them. That holds only for an
	 * account the picker lists, one with a roster role. An account with none
	 * (an address whose invitation ended with a removal, endInvitation(), or
	 * one from outside Monstera) is in no list, so "find them by name" would
	 * send the team nowhere: it is invited, and attached as an
	 * organization's own roster attaches it
	 * (Provisioning::attachMember()), when that would take it.
	 *
	 * @param list<int>    $ids     The people the roster should hold.
	 * @param list<string> $invites Email addresses to invite.
	 * @param int|null     $limit   The seat limit the save will leave; the stored one when null.
	 */
	public static function refusal( int $orgId, array $ids, array $invites, ?int $limit = null ): ?string {
		$ids     = self::cleanIds( $ids );
		$current = self::memberIds( $orgId );
		foreach ( array_diff( $ids, $current ) as $userId ) {
			$user = get_user_by( 'id', $userId );
			if ( ! $user instanceof WP_User || ! array_intersect( $user->roles, self::ROLES ) || in_array( 'administrator', $user->roles, true ) ) {
				return __( 'Only Monstera members can join an organization.', 'monstera' );
			}
		}
		foreach ( self::cleanInvites( $invites ) as $email ) {
			if ( ! is_email( $email ) ) {
				/* translators: %s: what was typed as an email address */
				return sprintf( __( '%s is not an email address.', 'monstera' ), $email );
			}
			$holder = get_user_by( 'email', $email );
			if ( $holder instanceof WP_User && ( array_intersect( $holder->roles, self::ROLES ) || null !== Provisioning::attachRefusal( $orgId, $holder ) ) ) {
				/* translators: %s: an email address */
				return sprintf( __( '%s already has an account. Find them by name instead.', 'monstera' ), $email );
			}
		}
		return self::seatRefusal( $orgId, count( $ids ) + count( self::cleanInvites( $invites ) ), $limit );
	}

	/** Why a roster of $size does not fit, or null when it does. */
	private static function seatRefusal( int $orgId, int $size, ?int $limit = null ): ?string {
		$limit ??= self::seatLimit( $orgId );
		if ( self::fits( $orgId, $size, $limit ) ) {
			return null;
		}
		return sprintf(
			/* translators: %d: the organization's seat limit */
			_n( 'This organization has %d seat. Remove someone or raise the seat limit first.', 'This organization has %d seats. Remove someone or raise the seat limit first.', $limit, 'monstera' ),
			$limit
		);
	}

	/**
	 * Why one more person cannot join, or null when they can: the person
	 * must hold a roster role and the roster must fit the limit. Someone
	 * already a member has nothing to be refused. $userId 0 asks about the
	 * seat alone, for an account not made yet.
	 */
	public static function joinRefusal( int $orgId, int $userId = 0 ): ?string {
		if ( $orgId <= 0 || ( $userId > 0 && self::isMemberOf( $userId, $orgId ) ) ) {
			return null;
		}
		$roster = self::memberIds( $orgId );
		return $userId > 0
			? self::refusal( $orgId, array_merge( $roster, [ $userId ] ), [] )
			: self::seatRefusal( $orgId, count( $roster ) + 1 );
	}

	// ---- Writes --------------------------------------------------------------

	/**
	 * Add each of $ids who is not on the roster yet, then invite each
	 * address. Callers check refusal() first. Nobody is taken off: a
	 * membership ends through remove(), one at a time, and a list that
	 * leaves someone out says nothing about them. The people already on the
	 * roster are nothing to ask the database about. A list of people names
	 * no tiers, so a newcomer joins at the tier
	 * Provisioning::tierImpliedByUser() gives: a manager made by role joins
	 * their first organization as its manager, and someone who already
	 * belongs somewhere joins as a member. Its one caller over REST is a new
	 * organization's first members (OrganizationsController::create()): the
	 * organization detail's roster names a tier with each person, through
	 * the roster's own routes.
	 *
	 * @param list<int>    $ids
	 * @param list<string> $invites
	 */
	public static function addMany( int $orgId, array $ids, array $invites = [] ): void {
		$ids = self::cleanIds( $ids );
		foreach ( array_diff( $ids, self::memberIds( $orgId ) ) as $userId ) {
			self::keepStanding( (int) $userId );
			self::add( $orgId, (int) $userId, Provisioning::tierImpliedByUser( (int) $userId ) );
		}
		foreach ( self::cleanInvites( $invites ) as $email ) {
			self::invite( $orgId, [ 'email' => $email ] );
		}
	}

	/**
	 * Put someone in the organization with a tier. Their other memberships
	 * are untouched: a second organization never takes them out of the
	 * first. An existing row for this person and organization is left as it
	 * is, tier included, whether a membership or a staff assignment.
	 *
	 * Here and in every writer below, the hook fires and the sentence is
	 * filed only for a change the database made: two requests adding or
	 * removing the same person at once leave the second with nothing to say.
	 *
	 * The answer is whether this call wrote the membership. False is not a
	 * failure to a caller that only wants the person there, but a caller
	 * that goes on to say "added", or to send the email that says so, asks:
	 * a row that was already there (a membership at another tier, an
	 * assignment, one another request wrote a moment before) and an insert
	 * the database refused both leave it with nothing to announce.
	 *
	 * A first membership also settles whose the account is. One that exists
	 * and joins its first organization was there before this membership,
	 * whatever made it once, so it is not this invitation's to remove: the
	 * mark of an invitation that made it (UserMeta::KEY_INVITED_ACCOUNT)
	 * goes as the row is written. It is taken here, and by no caller, so no
	 * door that adds someone can forget to: the end of a last membership
	 * removes an account that carries the mark (remove()). Only an account
	 * made for the organization carries it into a first membership, written
	 * once this has answered (Provisioning::insertUser()).
	 *
	 * @param int $actorId Who did it; the current user when 0.
	 * @return bool Whether the membership was written.
	 * @throws InvalidArgumentException For a tier that is not one of TIERS.
	 */
	public static function add( int $orgId, int $userId, string $tier = self::TIER_MEMBER, int $actorId = 0 ): bool {
		self::assertTier( $tier );
		if ( $orgId <= 0 || $userId <= 0 || null !== self::rowOf( $userId, $orgId ) ) {
			return false;
		}
		$actorId = self::actor( $actorId );
		$first   = ! self::orgIdsOf( $userId );
		if ( ! self::insert( $orgId, $userId, $tier, $actorId ) ) {
			return false;
		}
		self::syncRole( $userId );
		if ( $first && Provisioning::madeByInvitation( $userId ) ) {
			delete_user_meta( $userId, UserMeta::KEY_INVITED_ACCOUNT );
		}
		do_action( Hooks::MEMBERSHIP_ADDED, $userId, $orgId, $tier, $actorId );
		ActivityLog::record(
			'membership_added',
			'user',
			$userId,
			[
				'org_id'  => $orgId,
				'tier'    => $tier,
				'user_id' => $actorId,
			]
		);
		return true;
	}

	/**
	 * Move a member to another tier of the same organization. The same tier
	 * again writes nothing, and someone who is not a member there is left
	 * alone.
	 *
	 * @param int $actorId Who did it; the current user when 0.
	 * @throws InvalidArgumentException For a tier that is not one of TIERS.
	 */
	public static function setRole( int $orgId, int $userId, string $tier, int $actorId = 0 ): void {
		self::assertTier( $tier );
		$from = self::roleOf( $userId, $orgId );
		if ( null === $from || $from === $tier ) {
			return;
		}
		global $wpdb;
		$actorId = self::actor( $actorId );
		$changed = $wpdb->update(
			self::table(),
			[ 'role' => $tier ],
			[
				'user_id' => $userId,
				'org_id'  => $orgId,
			],
			[ '%s' ],
			[ '%d', '%d' ]
		);
		self::flushCache();
		if ( (int) $changed < 1 ) {
			return;
		}
		self::syncRole( $userId );
		do_action( Hooks::MEMBERSHIP_TIER_CHANGED, $userId, $orgId, $from, $tier, $actorId );
		ActivityLog::record(
			'membership_tier_changed',
			'user',
			$userId,
			[
				'org_id'  => $orgId,
				'from'    => $from,
				'to'      => $tier,
				'user_id' => $actorId,
			]
		);
	}

	/**
	 * Take someone out of one organization. The account stays, as do their
	 * other memberships; this organization's sub-groups and project teams
	 * let go of them, and they are standalone only when no membership
	 * remains.
	 *
	 * Someone who never signed in was only ever invited, and taking them
	 * off their last roster ends the invitation instead (endInvitation()).
	 * When the invitation is what made their account, the account goes with
	 * it (the owner's decision at the Phase 5 checkpoint: "Ending an
	 * invitation for someone who has not signed in should just remove their
	 * user altogether"), so the link they were sent leads nowhere and the
	 * address can be invited afresh. An account that was there before the
	 * invitation is never removed: its link stops working, and it is left
	 * with what it held before. Every route that removes a membership comes
	 * through here (the roster's, the member detail's, the bulk action), so
	 * the rule is one.
	 *
	 * The account goes last. The hooks fire while the person can still be
	 * read, and the row keeps their name as words, read before the account
	 * goes, because the account its id names will not be there to give one:
	 * the log goes on saying who was removed (Reporting\ActivitySentences).
	 * The row itself is filed once the account has gone or stayed, with
	 * whether it went: on a network the account is taken off the site and
	 * never deleted, and a site may refuse the deletion, and a row written
	 * beforehand would claim an account went that is still there.
	 *
	 * The answer is what ended beside the membership, which the routes pass
	 * on to the screens that say it: INVITATION_ACCOUNT when the account
	 * went, and nothing for someone who was not a member here, who has
	 * signed in or who belongs somewhere else still.
	 *
	 * @param int $actorId Who did it; the current user when 0.
	 * @return self::INVITATION_* What ended beside the membership.
	 */
	public static function remove( int $orgId, int $userId, int $actorId = 0 ): string {
		if ( ! self::isMemberOf( $userId, $orgId ) ) {
			return self::INVITATION_NONE;
		}
		$actorId = self::actor( $actorId );
		if ( ! self::delete( $orgId, $userId ) ) {
			return self::INVITATION_NONE;
		}
		$ended = self::endInvitation( $userId, $orgId );
		if ( self::INVITATION_NONE === $ended || self::INVITATION_PENDING === $ended ) {
			self::syncRole( $userId );
		}
		self::leave( $orgId, $userId );
		do_action( Hooks::MEMBERSHIP_REMOVED, $userId, $orgId, $actorId );
		$context = [
			'org_id'  => $orgId,
			'user_id' => $actorId,
		];
		if ( self::INVITATION_ACCOUNT === $ended ) {
			// The name first: it is the sentence's once the account is gone.
			$user            = get_user_by( 'id', $userId );
			$context['name'] = $user instanceof WP_User ? UserMeta::fullName( $user ) : '';
			// An account WordPress would not delete is left as any ended
			// invitation leaves one, with a dead link and no role, and the
			// answer and the row say that and not that it went.
			$removed                    = Provisioning::removeAccount( $userId );
			$ended                      = $removed ? $ended : self::INVITATION_ONLY;
			$context['account_removed'] = $removed;
			self::flushCache();
		}
		ActivityLog::record( 'membership_removed', 'user', $userId, $context );
		return $ended;
	}

	/**
	 * End the invitation of someone who has just been taken off their last
	 * roster without ever having signed in, and say what ended with it
	 * (invitationHeld() decides which). The roster asks "The invitation
	 * link stops working." before it removes such a person, and the usual
	 * case is an address typed wrong: whoever holds it was never anybody's
	 * member.
	 *
	 * The usual end is the account's: the invitation made it, nobody signed
	 * in to it and nothing shows it in use, so it is removed altogether
	 * (INVITATION_ACCOUNT). remove() does that as its last step, once the
	 * hooks have fired and the sentence is filed; what is done here first
	 * is what every ended invitation gets, so a listener that stops the
	 * request leaves a dead link and no role, never a member of nowhere
	 * with a link that still sets a password.
	 *
	 * That is two things. The pending set-password key is cleared, so the
	 * link in the welcome no longer opens WordPress's "set your password"
	 * screen. And every client role goes, the standalone member's with
	 * them: WordPress will still send the address a new password if it asks,
	 * while the account is kept, and a standalone member lands on the portal
	 * and reads its directory. With no Monstera role the portal turns the
	 * account away (AccessControl\PortalGuard). For an account that is kept
	 * (INVITATION_ONLY: one that was on the site before the invitation, or
	 * that is in use) that is the whole of it: the account stays, with every
	 * role on it that is not Monstera's, and inviting the address again
	 * gives it a role and a link again (Members\Provisioning::attachMember()).
	 *
	 * What ends is what the invitation gave. An account that was a member in
	 * its own right before its first organization (keepStanding()) loses the
	 * link, which is the organization's by now, and keeps a role
	 * (INVITATION_PENDING): remove() derives the standalone member's as it
	 * does for anyone left with no organization.
	 *
	 * Nothing ends while a membership remains, because that organization's
	 * invitation is still good and its link is this same key; nor for
	 * someone who has signed in, who becomes a standalone member as before;
	 * nor for one of the team, whose link is the team's welcome.
	 *
	 * @param int $leavingOrgId The organization the membership that has just gone was in.
	 * @return self::INVITATION_*
	 */
	private static function endInvitation( int $userId, int $leavingOrgId ): string {
		if ( self::orgIdsOf( $userId ) ) {
			return self::INVITATION_NONE;
		}
		$user       = get_user_by( 'id', $userId );
		$invitation = $user instanceof WP_User ? self::invitationHeld( $user, $leavingOrgId ) : self::INVITATION_NONE;
		// Both notes spoke of the invitation that has just ended. The next
		// first membership writes its own (keepStanding()), and an account
		// that outlives the invitation that made it is not the next one's
		// to remove.
		delete_user_meta( $userId, UserMeta::KEY_STOOD_ALONE );
		delete_user_meta( $userId, UserMeta::KEY_INVITED_ACCOUNT );
		if ( ! $user instanceof WP_User || self::INVITATION_NONE === $invitation ) {
			return self::INVITATION_NONE;
		}
		if ( self::INVITATION_PENDING !== $invitation ) {
			foreach ( self::clientRolesOf( $user ) as $role ) {
				$user->remove_role( $role );
			}
		}
		global $wpdb;
		// As wp_set_password() clears it: the column has no API of its own.
		$wpdb->update( $wpdb->users, [ 'user_activation_key' => '' ], [ 'ID' => $userId ], [ '%s' ], [ '%d' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one column of one account, and the cache is cleared on the next line.
		clean_user_cache( $user );
		return $invitation;
	}

	/**
	 * Note, before an account that exists joins its first organization,
	 * whether it is somebody's already: one that holds a client role of its
	 * own and has not signed in, a standalone member the team made and
	 * whose welcome is still unread. endInvitation() reads the note, so that
	 * taking such a person off the roster again ends what the organization
	 * gave them and nothing they had before. Without it an organization's
	 * manager, who invites and removes plain members for any address they
	 * know, could invite such an address and remove it, and leave another
	 * client's pending account with no role and no row in the Members list.
	 *
	 * Every door that adds an account that exists asks here first: an
	 * invitation that attaches (Members\Provisioning::attachMember(), before
	 * it gives an account from outside Monstera its role), the team's
	 * memberships routes and a new organization's first members. An account
	 * made for an organization is never noted, having held nothing before
	 * it, and a door that forgets to ask leaves the same reading: the
	 * invitation is all the account holds, which closes more than it should
	 * and never less.
	 *
	 * Only a first membership is a first: with one already held the note
	 * stands as it was written. With none it is written afresh, so a note
	 * left by an organization that was deleted says nothing of the next.
	 *
	 * The other note, that an invitation made the account
	 * (UserMeta::KEY_INVITED_ACCOUNT), is not settled here. Whether an
	 * account may be removed cannot rest on a door remembering to ask, so
	 * add() takes that mark itself from any account that joins a first
	 * organization.
	 */
	public static function keepStanding( int $userId ): void {
		if ( self::orgIdsOf( $userId ) ) {
			return;
		}
		$user = get_user_by( 'id', $userId );
		if ( $user instanceof WP_User && ! Capabilities::isStaff( $user ) && ! UserMeta::hasSignedIn( $userId ) && self::clientRolesOf( $user ) ) {
			update_user_meta( $userId, UserMeta::KEY_STOOD_ALONE, 1 );
			return;
		}
		delete_user_meta( $userId, UserMeta::KEY_STOOD_ALONE );
	}

	/**
	 * What is left of an invitation for someone who belongs to an
	 * organization, which is what taking them off their last roster would
	 * end (endInvitation()). Nothing for a person who has signed in, who is
	 * a member like any other, nor for one of the team; the link alone
	 * (INVITATION_PENDING) for an account that was a member in its own right
	 * before its first organization, which is left a standalone member; the
	 * link and the role (INVITATION_ONLY) for an account the invitation gave
	 * its client role to, which stays with none; and the account itself
	 * (INVITATION_ACCOUNT) when the invitation made it and nothing shows it
	 * in use. Nothing either for a person in no organization: there is no
	 * invitation to end.
	 *
	 * The member detail asks before it removes someone and says what
	 * follows, so the record carries this answer
	 * (Rest\Controllers\MembersController), and the question and the removal
	 * read one rule. With several organizations nothing ends until the last
	 * goes, and the page reads this together with how many are left.
	 *
	 * @return self::INVITATION_*
	 */
	public static function invitationOf( WP_User $user ): string {
		return self::orgIdsOf( (int) $user->ID ) ? self::invitationHeld( $user ) : self::INVITATION_NONE;
	}

	/**
	 * Which of an organization's members would lose their account with
	 * their membership of it: it is their only organization, the invitation
	 * made the account, nobody signed in to it and nothing shows it in use.
	 * The organization detail's roster asks for all its rows at once, so its
	 * question can say before the click what a removal takes; a row knows a
	 * person's tier here and nothing else about them. Who qualifies is read
	 * from the accounts and the memberships, each loaded together, and the
	 * signs of use are asked once for whoever is left
	 * (Provisioning::usedBeyondInvitation()), so a roster of thirty
	 * invitations costs what a roster of three does.
	 *
	 * @param list<int> $userIds The organization's members that are asked about.
	 * @return list<int>
	 */
	public static function accountsEndingWith( int $orgId, array $userIds ): array {
		self::prime( $userIds );
		cache_users( $userIds );
		$asked = [];
		foreach ( $userIds as $userId ) {
			// Their only organization is this one.
			$held = self::orgIdsOf( $userId );
			if ( 1 !== count( $held ) || $held[0] !== $orgId ) {
				continue;
			}
			$user = get_user_by( 'id', $userId );
			if ( $user instanceof WP_User && self::INVITATION_ACCOUNT === self::invitationMarked( $user ) ) {
				$asked[] = $userId;
			}
		}
		return self::unused( $asked );
	}

	/**
	 * Those of the accounts an invitation made that nothing shows in use,
	 * asked about together.
	 *
	 * @param list<int> $asked
	 * @param int       $leavingOrgId The organization whose membership has just ended; none when 0.
	 * @return list<int>
	 */
	private static function unused( array $asked, int $leavingOrgId = 0 ): array {
		return $asked ? array_values( array_diff( $asked, array_keys( Provisioning::usedBeyondInvitation( $asked, $leavingOrgId ) ) ) ) : [];
	}

	/**
	 * invitationOf() without asking whether a membership is held:
	 * endInvitation() asks once the last one has gone.
	 *
	 * The account goes only when two things hold, and the first is known,
	 * never worked out: the invitation made it (invitationMarked()). The
	 * second is that nothing shows it in use beyond that invitation
	 * (Provisioning::usedBeyondInvitation() lists what would). An account
	 * that fails either is kept, and ends as an invitation that did not make
	 * its account ends.
	 *
	 * @param int $leavingOrgId The organization whose membership has just ended, whose own projects are no sign of use; none when 0.
	 * @return self::INVITATION_*
	 */
	private static function invitationHeld( WP_User $user, int $leavingOrgId = 0 ): string {
		$held = self::invitationMarked( $user );
		if ( self::INVITATION_ACCOUNT === $held && ! self::unused( [ (int) $user->ID ], $leavingOrgId ) ) {
			return self::INVITATION_ONLY;
		}
		return $held;
	}

	/**
	 * What the account itself says of its invitation, before anyone asks
	 * whether it is in use: read from the account and its notes alone, so a
	 * sweep asks it of everyone without a query each (rederive()).
	 * INVITATION_ACCOUNT here means the invitation made the account
	 * (Provisioning::madeByInvitation()), no more: an account without that
	 * mark is never removed, whatever else is true of it.
	 *
	 * @return self::INVITATION_*
	 */
	private static function invitationMarked( WP_User $user ): string {
		$userId = (int) $user->ID;
		if ( Capabilities::isStaff( $user ) || UserMeta::hasSignedIn( $userId ) ) {
			return self::INVITATION_NONE;
		}
		if ( get_user_meta( $userId, UserMeta::KEY_STOOD_ALONE, true ) ) {
			return self::INVITATION_PENDING;
		}
		return Provisioning::madeByInvitation( $userId ) ? self::INVITATION_ACCOUNT : self::INVITATION_ONLY;
	}

	/**
	 * Note that a staff person knows the organization. The row is never a
	 * membership, so it counts nowhere a membership counts. An existing row
	 * for this person and organization is left as it is.
	 *
	 * @param int $actorId Who did it; the current user when 0.
	 */
	public static function assign( int $orgId, int $userId, int $actorId = 0 ): void {
		if ( $orgId <= 0 || $userId <= 0 || null !== self::rowOf( $userId, $orgId ) ) {
			return;
		}
		$actorId = self::actor( $actorId );
		if ( ! self::insert( $orgId, $userId, self::ROLE_STAFF, $actorId ) ) {
			return;
		}
		do_action( Hooks::STAFF_ASSIGNED, $userId, $orgId, $actorId );
		ActivityLog::record(
			'staff_assigned',
			'user',
			$userId,
			[
				'org_id'  => $orgId,
				'user_id' => $actorId,
			]
		);
	}

	/**
	 * End a staff assignment. A membership is not one, so it is not touched.
	 *
	 * @param int $actorId Who did it; the current user when 0.
	 */
	public static function unassign( int $orgId, int $userId, int $actorId = 0 ): void {
		if ( ! self::isAssignedTo( $userId, $orgId ) ) {
			return;
		}
		$actorId = self::actor( $actorId );
		if ( ! self::delete( $orgId, $userId ) ) {
			return;
		}
		do_action( Hooks::STAFF_UNASSIGNED, $userId, $orgId, $actorId );
		ActivityLog::record(
			'staff_unassigned',
			'user',
			$userId,
			[
				'org_id'  => $orgId,
				'user_id' => $actorId,
			]
		);
	}

	/**
	 * WordPress took a role from an account (remove_user_role, which
	 * set_role() also fires for each role it replaces). When it was a team
	 * role, or the administrator's, and the account is on the team no
	 * longer, what it held as one of the team ends here: every assignment,
	 * each as unassign() ends one, with its hook and its sentence credited
	 * to whoever took the role, and its place on projects (leaveProjects()).
	 *
	 * So it does not matter by which door someone leaves. The Team routes,
	 * WordPress's Users screen and the command line all take the role, and
	 * none of them can leave a row that says someone who is not staff is
	 * assigned to an organization: such a row is listed nowhere, and an
	 * invitation of that person into the organization would be refused as
	 * the team's (Provisioning::attachRefusal()). An account that still holds
	 * another team role keeps everything, and a membership is not the team's
	 * and is never touched: the person is given back the client role its
	 * tier implies (leaveTeam()).
	 *
	 * A role that goes without WordPress saying so (a write straight to the
	 * database, an import, a change made while the plugin was off) is not
	 * heard here; the daily sweep finds what it left (sweepFormerStaff()).
	 */
	public static function onRoleRemoved( int $userId, string $role ): void {
		if ( 'administrator' !== $role && ! Capabilities::isStaffRole( $role ) ) {
			return;
		}
		$user = get_user_by( 'id', $userId );
		if ( ! $user instanceof WP_User || Capabilities::isStaff( $user ) ) {
			return;
		}
		self::leaveTeam( $user );
	}

	/**
	 * End what an account held as one of the team, now that it is staff no
	 * longer: every assignment, each as unassign() ends one, and its place
	 * on projects (leaveProjects()). The one path for it, whichever way the
	 * role went: the Team route takes the role and WordPress tells the
	 * listener above, as it does for a role changed in its Users screen, and
	 * the daily sweep comes here for a role that went unheard.
	 *
	 * Someone who also belongs to a client organization keeps that
	 * membership, and is given the client role its tier implies: while they
	 * were staff that role was withheld, the staff role winning, and
	 * syncRole() derives one only for an account that already holds one, so
	 * without it the membership would keep its seat and its tier with no
	 * capability behind them, and the Members list would not show the
	 * person. The member role is given for syncRole() to derive from only
	 * when the account holds no client role: one whose new role is already
	 * a client's (a Team member made an Organization Manager in WordPress's
	 * Users screen) is derived from as it is, or every listener to a role
	 * given or taken would hear the member role come and go, which nobody
	 * meant. Nor is it given to an account that still works in wp-admin by
	 * another role, the site's editor say (Provisioning::worksInAdminOnly()):
	 * a client role would turn it away from every wp-admin screen and send
	 * its sign-in to the portal, so it is given none and its membership is
	 * left as it is, opening no portal.
	 *
	 * Someone who belongs to no organization has no tier to derive a role
	 * from, so nothing is derived: whatever role WordPress left them stands,
	 * as it stands for any account given a role there. A Team member made an
	 * Organization Manager in the Users screen is then a manager by role,
	 * who joins their first organization as its manager
	 * (Provisioning::tierImpliedByUser()); deriving here would make them
	 * standalone inside the very set_role() that chose otherwise.
	 */
	private static function leaveTeam( WP_User $user ): void {
		$userId = (int) $user->ID;
		foreach ( self::assignedOrgIdsOf( $userId ) as $orgId ) {
			self::unassign( $orgId, $userId );
		}
		self::leaveProjects( $userId );
		if ( ! self::orgIdsOf( $userId ) ) {
			return;
		}
		if ( ! self::clientRolesOf( $user ) && ! Provisioning::worksInAdminOnly( $user ) ) {
			$user->add_role( Capabilities::ROLE_MEMBER );
		}
		self::syncRole( $userId );
	}

	/**
	 * What someone who has left the team leaves behind on projects. A lead
	 * is one of the team (FR4), so no project keeps them as its lead,
	 * whether or not they are among its members: the lead is named in the
	 * project's own meta, not by a row there. They also come off the
	 * members of every project they were on as staff, one of an
	 * organization they do not belong to: a row there would still open the
	 * project to them in the portal (Projects\Repository::userCanAccess()),
	 * and an account that is no longer staff has no business there. On a
	 * project of an organization they belong to, they stay as its member.
	 */
	private static function leaveProjects( int $userId ): void {
		$projects = new ProjectRepository();
		$projects->forgetLead( $userId );
		foreach ( $projects->projectsForMember( $userId ) as $projectId ) {
			$orgId = (int) get_post_meta( $projectId, ProjectMeta::KEY_ORG_ID, true );
			if ( $orgId > 0 && self::isMemberOf( $userId, $orgId ) ) {
				continue;
			}
			$projects->removeMember( $projectId, $userId );
			if ( (int) get_post_meta( $projectId, ProjectMeta::KEY_PRIMARY_CONTACT, true ) === $userId ) {
				delete_post_meta( $projectId, ProjectMeta::KEY_PRIMARY_CONTACT );
			}
		}
		ProjectRepository::flushCache();
	}

	/**
	 * Keep a client person's WordPress role in step with their memberships
	 * (People-model track, FR2), after every write above. The role is a
	 * ceiling: the highest tier they hold anywhere, so the existing
	 * capability gates (manage_own_org, invite_members, author_portal,
	 * renew_own) keep working as they are. It is never the whole answer,
	 * because a manager of one organization is a plain member of another:
	 * every org-scoped action also checks roleOf() for the organization in
	 * question. Any admin or manager tier gives the manager role, member
	 * tiers alone the member role and no membership the standalone role,
	 * written only when it differs from what they hold. Only Monstera's
	 * client roles are swapped, one for another, so the person is left with
	 * one of them and keeps every role that is not Monstera's: the account
	 * may also be the site's editor, a shop's customer or a forum's
	 * moderator, and none of that is the Roster's to take. A staff account
	 * (a Team manager, a Team member, a WordPress administrator) keeps its
	 * role whatever its memberships, and an account with no Monstera role at
	 * all (an editor, a subscriber) is left alone.
	 */
	public static function syncRole( int $userId ): void {
		$user = get_user_by( 'id', $userId );
		if ( ! $user instanceof WP_User || Capabilities::isStaff( $user ) ) {
			return;
		}
		$held = self::clientRolesOf( $user );
		if ( ! $held ) {
			return;
		}
		$derived = Capabilities::ROLE_MEMBER_STANDALONE;
		foreach ( self::membershipsOf( $userId ) as $membership ) {
			if ( self::TIER_MEMBER !== $membership['tier'] ) {
				$derived = Capabilities::ROLE_ORG_MANAGER;
				break;
			}
			$derived = Capabilities::ROLE_MEMBER;
		}
		self::swapClientRole( $user, $derived );
	}

	/**
	 * Leave an account with this client role and no other of Monstera's.
	 * Every role that is not a client role stays, which is why no writer of
	 * a client role calls set_role(): that replaces the whole list, the
	 * site's editor role with it. The one swap for the ceiling above and for
	 * the Members route, which writes a role named for someone who belongs
	 * to no organization (MembersController::update()).
	 *
	 * Given before the old one is taken, so the account holds both for a
	 * moment and never none: a listener that hands a default role to an
	 * account left without one has nothing to act on, and a request that
	 * dies between the two writes leaves two client roles for the next pass
	 * to settle, not an account syncRole() would pass over for good.
	 *
	 * @param string $role One of the three client roles (Capabilities::isPortalRole()).
	 */
	public static function swapClientRole( WP_User $user, string $role ): void {
		if ( ! Capabilities::isPortalRole( $role ) ) {
			return;
		}
		$held = self::clientRolesOf( $user );
		if ( ! in_array( $role, $held, true ) ) {
			$user->add_role( $role );
		}
		foreach ( array_diff( $held, [ $role ] ) as $other ) {
			$user->remove_role( $other );
		}
	}

	/**
	 * The client roles an account holds, as WordPress reads them.
	 *
	 * @return list<string>
	 */
	private static function clientRolesOf( WP_User $user ): array {
		$held = [];
		foreach ( (array) $user->roles as $role ) {
			if ( Capabilities::isPortalRole( (string) $role ) ) {
				$held[] = (string) $role;
			}
		}
		return $held;
	}

	/**
	 * Let go of an organization that has been permanently deleted: every
	 * row of it, memberships and assignments alike, and then the role each
	 * of its people is left with. The delete hook comes here instead of
	 * dropping the rows itself because a row is also what the role ceiling
	 * was derived from: a manager of the deleted organization would
	 * otherwise keep the manager role over member tiers, and a person whose
	 * only organization it was would keep a client role that says they
	 * belong somewhere and meet the portal's no-organization page. No
	 * removal hook fires, and the only sentence filed is for an invited
	 * account the pass removes (rederive()): nobody was taken out of
	 * anything that still exists.
	 *
	 * Someone who was only invited into it, and into nothing else, loses
	 * the invitation with the organization, and the account it made goes as
	 * remove() would have it go (rederive()). Trashing an organization
	 * comes nowhere near here: its rows stay, and its invitations with them.
	 *
	 * @return int Rows removed.
	 */
	public static function forgetOrganization( int $orgId ): int {
		if ( $orgId <= 0 ) {
			return 0;
		}
		global $wpdb;
		$userIds = array_map(
			'intval',
			(array) $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read once, to know whose role to derive after the rows go; the table is this class's own.
				$wpdb->prepare( 'SELECT DISTINCT user_id FROM %i WHERE org_id = %d', self::table(), $orgId )
			)
		);
		$removed = (int) $wpdb->delete( self::table(), [ 'org_id' => $orgId ], [ '%d' ] );
		self::flushCache();
		self::rederive( $userIds, array_fill_keys( $userIds, $orgId ) );
		return $removed;
	}

	/**
	 * The daily sweep's part for this table: drop every row whose person or
	 * whose organization no longer exists (a delete that went round the
	 * hooks, or one from before they were there), then re-derive the role of
	 * each person who lost a row and is still here, or remove the account of
	 * one who was only invited and has no invitation left (rederive()). A
	 * trashed organization still exists, so its rows stay. Then what an
	 * account still holds as one of the team after it stopped being staff
	 * (sweepFormerStaff()).
	 *
	 * @return int Rows removed.
	 */
	public static function sweepOrphans(): int {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a set-based sweep over this class's own table; no API covers it.
		// Whose rows go, and the organization of the first row of each: the
		// line the log keeps when an invited account goes with its rows names
		// the organization that is gone.
		$orgOf = [];
		foreach ( (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT t.user_id, t.org_id FROM %i AS t LEFT JOIN %i AS u ON u.ID = t.user_id LEFT JOIN %i AS p ON p.ID = t.org_id WHERE u.ID IS NULL OR p.ID IS NULL ORDER BY t.id ASC',
				self::table(),
				$wpdb->users,
				$wpdb->posts
			),
			ARRAY_A
		) as $row ) {
			$orgOf[ (int) $row['user_id'] ] ??= (int) $row['org_id'];
		}
		$userIds = array_keys( $orgOf );
		$removed = 0;
		if ( $userIds ) {
			$removed = max(
				0,
				(int) $wpdb->query(
					$wpdb->prepare(
						'DELETE t FROM %i AS t LEFT JOIN %i AS u ON u.ID = t.user_id LEFT JOIN %i AS p ON p.ID = t.org_id WHERE u.ID IS NULL OR p.ID IS NULL',
						self::table(),
						$wpdb->users,
						$wpdb->posts
					)
				)
			);
			self::flushCache();
			self::rederive( $userIds, $orgOf );
		}
		// phpcs:enable
		return $removed + self::sweepFormerStaff();
	}

	/**
	 * The sweep's second pass: end what an account still holds as one of
	 * the team when it is staff no longer. The Roster ends it as the role
	 * goes (onRoleRemoved()), but only hears a role WordPress takes; one
	 * that went by a write straight to the database, an import or a change
	 * made while the plugin was off leaves an assignment no screen lists and
	 * a project naming a lead who is not staff, which every save of it then
	 * refuses, and an invitation of the person into the organization is
	 * refused as the team's. Nothing else would ever clear them.
	 *
	 * Whoever holds an assignment is one read, whoever a project names as
	 * its lead another, and their accounts and roles are read together, so
	 * a team of thirty costs what a team of three does. Only an account
	 * found out of the team is then written to, by the path a role taken in
	 * WordPress goes (leaveTeam()). A lead whose account is gone altogether
	 * is cleared with them: no row of a table goes with a deleted account
	 * that a project's own meta names.
	 *
	 * The pass judges nobody while a role it reads or gives has no
	 * definition (rolesAreDefined()). "Staff no longer" is read from the
	 * roles WordPress reads for an account, and with a team role's
	 * definition gone everyone who holds that role reads as not staff. This
	 * is the one step that would act on that with nobody watching, and what
	 * it ends does not come back when the definition does: the whole team's
	 * assignments and leads, and a client role written beside a team role
	 * the account still names. Waiting loses nothing, because what is
	 * rightly the pass's to end is still there for the run that can tell.
	 *
	 * @return int Assignments ended.
	 */
	private static function sweepFormerStaff(): int {
		if ( ! self::rolesAreDefined() ) {
			return 0;
		}
		global $wpdb;
		$assigned = array_map(
			'intval',
			(array) $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one read of this class's own table, once per sweep.
				$wpdb->prepare( 'SELECT DISTINCT user_id FROM %i WHERE role = %s', self::table(), self::ROLE_STAFF )
			)
		);
		$projects = new ProjectRepository();
		$held     = array_values( array_unique( array_merge( $assigned, $projects->leadIds() ) ) );
		if ( ! $held ) {
			return 0;
		}
		cache_users( $held );
		$former = [];
		foreach ( $held as $userId ) {
			$user = get_user_by( 'id', $userId );
			if ( ! $user instanceof WP_User ) {
				$projects->forgetLead( $userId );
			} elseif ( ! Capabilities::isStaff( $user ) ) {
				$former[ $userId ] = $user;
			}
		}
		if ( ! $former ) {
			return 0;
		}
		self::prime( array_keys( $former ) );
		$ended = 0;
		foreach ( $former as $userId => $user ) {
			$ended += count( self::assignedOrgIdsOf( $userId ) );
			self::leaveTeam( $user );
		}
		return $ended;
	}

	/**
	 * Whether WordPress has a definition for every role the sweep's second
	 * pass reads or gives: the administrator's and the team's two, which say
	 * who is staff, and the client roles, one of which it gives and the
	 * ceiling then derives among. WordPress reads for an account only the
	 * roles it has a definition for (WP_User::get_role_caps()), and a
	 * definition can go while the accounts still name the role: a role
	 * editor's reset, `wp role delete`, a roles option overwritten by a
	 * migration or left behind by a change of table prefix. Nothing puts
	 * Monstera's back until the capabilities version moves or the plugin is
	 * activated again (Capabilities::maybeUpgrade()), so the gap can last
	 * for days of sweeps.
	 */
	private static function rolesAreDefined(): bool {
		$roles = wp_roles();
		foreach ( array_merge( [ 'administrator' ], array_keys( Capabilities::definitions() ) ) as $role ) {
			if ( ! $roles->is_role( $role ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Derive the role again for people whose rows went without a remove():
	 * their memberships read in one query and their accounts, with the meta
	 * that holds the roles, in two more, then syncRole() for each, which
	 * passes over anyone who no longer exists. Read one by one from a cold
	 * cache (cron, the command line, a bulk "Empty Trash"), an organization
	 * of three hundred people would be six hundred reads before any write.
	 *
	 * An organization that went took its invitations with it. Someone left
	 * with no row at all, who never signed in and whose account the
	 * invitation made, has the account removed as remove() removes it
	 * (uninvited() says who); no role is derived for an account that is
	 * going. Everyone else is left as before, a never-signed-in person the
	 * invitation did not make among them, who is a standalone member.
	 *
	 * The accounts go last, once every role is derived. WordPress tells its
	 * listeners as each account is deleted, and Core\Database\Cleanup
	 * forgets on the word what was read here of who belongs where: an
	 * account removed among the others would have everyone after it read
	 * again, a query each.
	 *
	 * Nobody left in no organization keeps the mark of the invitation that
	 * made their account (UserMeta::KEY_INVITED_ACCOUNT). The invitation
	 * went with the organization, and an account that outlived it, being in
	 * use or signed in to, is not a later invitation's to remove, as
	 * endInvitation() has it for a removal. An account WordPress would not
	 * delete is one of those, and is left as everyone else here is.
	 *
	 * An account that goes is written to Monstera's log as a roster route
	 * writes an invitation it ends (remove()): the same event, filed under
	 * the organization whose row went, naming the person as words since the
	 * account is not there to be read, and crediting nobody, since nobody did
	 * it. The deletion and the sweep are how an invited account goes with
	 * nobody's hand on it, and the log is where that is read afterwards.
	 *
	 * @param list<int>       $userIds
	 * @param array<int, int> $orgOf   The organization whose row went, by user; the deleted one for all of them, or the sweep's first row of each.
	 */
	private static function rederive( array $userIds, array $orgOf = [] ): void {
		self::prime( $userIds );
		cache_users( $userIds );
		$uninvited = self::uninvited( $userIds );
		$outlived  = [];
		foreach ( array_diff( $userIds, $uninvited ) as $userId ) {
			if ( ! self::orgIdsOf( $userId ) && Provisioning::madeByInvitation( $userId ) ) {
				$outlived[] = $userId;
			}
			self::syncRole( $userId );
		}
		self::forgetInvitations( $outlived );
		foreach ( $uninvited as $userId ) {
			// The name first: it is the sentence's once the account is gone.
			$user = get_user_by( 'id', $userId );
			$name = $user instanceof WP_User ? UserMeta::fullName( $user ) : '';
			if ( ! Provisioning::removeAccount( $userId ) ) {
				self::forgetInvitations( [ $userId ] );
				self::syncRole( $userId );
				continue;
			}
			ActivityLog::record(
				'membership_removed',
				'user',
				$userId,
				[
					'org_id'          => (int) ( $orgOf[ $userId ] ?? 0 ),
					'user_id'         => 0,
					'name'            => $name,
					'account_removed' => true,
				]
			);
		}
		if ( $uninvited ) {
			self::flushCache();
		}
	}

	/**
	 * Take the mark of an invitation from accounts that have outlived it,
	 * together: one write however many they are, where delete_user_meta()
	 * is a read and a write for each, and an organization that goes may
	 * leave hundreds of them.
	 *
	 * @param list<int> $userIds
	 */
	private static function forgetInvitations( array $userIds ): void {
		if ( ! $userIds ) {
			return;
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $userIds ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $userIds ); every id goes through prepare().
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one write for every account, and their cache is cleared after it.
			$wpdb->prepare( "DELETE FROM %i WHERE meta_key = %s AND user_id IN ($marks)", $wpdb->usermeta, UserMeta::KEY_INVITED_ACCOUNT, ...$userIds )
		);
		// phpcs:enable
		wp_cache_delete_multiple( $userIds, 'user_meta' );
	}

	/**
	 * Among people whose rows went with an organization, those whose
	 * account goes with them: no membership is left, the account says the
	 * invitation made it and that nobody signed in (invitationMarked()), and
	 * nothing shows it in use. The first three are read from what rederive()
	 * has loaded for everyone, so they cost nothing more; only who passes
	 * them is asked about, together, in the few reads
	 * usedBeyondInvitation() makes however many they are. The organization
	 * that went is named to nobody: its post is gone, which is how a place
	 * on one of its projects reads as part of the invitation.
	 *
	 * @param list<int> $userIds
	 * @return list<int>
	 */
	private static function uninvited( array $userIds ): array {
		$asked = [];
		foreach ( $userIds as $userId ) {
			$user = get_user_by( 'id', $userId );
			if ( ! self::orgIdsOf( $userId ) && $user instanceof WP_User && self::INVITATION_ACCOUNT === self::invitationMarked( $user ) ) {
				$asked[] = $userId;
			}
		}
		return self::unused( $asked );
	}

	/**
	 * Invite an email address into the organization at the given tier
	 * (member when none is given). A new address becomes a new account, which
	 * gets the welcome email (the invitation) as every new member does. An
	 * address that already has an account is attached instead: the person
	 * keeps every other membership and is welcomed to this organization
	 * alone (Provisioning::attachMember(), which also says whose address is
	 * refused). The caller checks the limit, and learns from the answer
	 * only who joined, never which of the two happened.
	 *
	 * @param array{email?: string, first_name?: string, last_name?: string, tier?: string} $data
	 * @throws InvalidArgumentException For a tier that is not one of TIERS.
	 */
	public static function invite( int $orgId, array $data ): WP_User|WP_Error {
		$tier = (string) ( $data['tier'] ?? self::TIER_MEMBER );
		self::assertTier( $tier );
		$email    = sanitize_email( (string) ( $data['email'] ?? '' ) );
		$existing = '' !== $email ? get_user_by( 'email', $email ) : false;
		if ( $existing instanceof WP_User ) {
			return Provisioning::attachMember( $orgId, $existing, $tier );
		}
		return Provisioning::createMember(
			[
				'email'      => (string) ( $data['email'] ?? '' ),
				'first_name' => (string) ( $data['first_name'] ?? '' ),
				'last_name'  => (string) ( $data['last_name'] ?? '' ),
				'role'       => Capabilities::ROLE_MEMBER,
				'org_id'     => $orgId,
				'tier'       => $tier,
			]
		);
	}

	// ---- The table -----------------------------------------------------------

	private static function table(): string {
		return Schema::tableName( Schema::TABLE_ORG_MEMBERS );
	}

	/**
	 * Every row of a person, oldest first, from the memo or one query.
	 *
	 * @return list<array{org_id: int, role: string, since: string}>
	 */
	private static function rowsOfUser( int $userId ): array {
		if ( $userId <= 0 ) {
			return [];
		}
		if ( ! array_key_exists( $userId, self::$byUser ) ) {
			global $wpdb;
			$rows                    = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- memoised above for the request; the table is this class's own.
				$wpdb->prepare( 'SELECT org_id, role, created_at FROM %i WHERE user_id = %d ORDER BY created_at ASC, id ASC', self::table(), $userId ),
				ARRAY_A
			);
			self::$byUser[ $userId ] = array_values(
				array_map(
					static fn ( array $row ): array => [
						'org_id' => (int) $row['org_id'],
						'role'   => (string) $row['role'],
						'since'  => (string) $row['created_at'],
					],
					$rows
				)
			);
		}
		return self::$byUser[ $userId ];
	}

	/**
	 * Every row of an organization, oldest first, from the memo or one query.
	 *
	 * @return list<array{user_id: int, role: string}>
	 */
	private static function rowsOfOrg( int $orgId ): array {
		if ( $orgId <= 0 ) {
			return [];
		}
		if ( ! array_key_exists( $orgId, self::$byOrg ) ) {
			global $wpdb;
			$rows                  = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- memoised above for the request; the table is this class's own.
				$wpdb->prepare( 'SELECT user_id, role FROM %i WHERE org_id = %d ORDER BY created_at ASC, id ASC', self::table(), $orgId ),
				ARRAY_A
			);
			self::$byOrg[ $orgId ] = array_values(
				array_map(
					static fn ( array $row ): array => [
						'user_id' => (int) $row['user_id'],
						'role'    => (string) $row['role'],
					],
					$rows
				)
			);
		}
		return self::$byOrg[ $orgId ];
	}

	/** @return array{org_id: int, role: string, since: string}|null The person's row for the organization, whatever its role. */
	private static function rowOf( int $userId, int $orgId ): ?array {
		foreach ( self::rowsOfUser( $userId ) as $row ) {
			if ( $row['org_id'] === $orgId ) {
				return $row;
			}
		}
		return null;
	}

	/** Write the row; false when the database refused it (another request wrote the same one first). */
	private static function insert( int $orgId, int $userId, string $role, int $actorId ): bool {
		global $wpdb;
		$written = $wpdb->insert(
			self::table(),
			[
				'user_id'    => $userId,
				'org_id'     => $orgId,
				'role'       => $role,
				'created_at' => current_time( 'mysql', true ),
				'created_by' => $actorId,
			],
			[ '%d', '%d', '%s', '%s', '%d' ]
		);
		self::flushCache();
		return (int) $written > 0;
	}

	/** Drop the row; false when none was there to drop (it went between the read and the write). */
	private static function delete( int $orgId, int $userId ): bool {
		global $wpdb;
		$dropped = $wpdb->delete(
			self::table(),
			[
				'user_id' => $userId,
				'org_id'  => $orgId,
			],
			[ '%d', '%d' ]
		);
		self::flushCache();
		return (int) $dropped > 0;
	}

	/** The actor a write is credited to: the one named, else whoever is signed in (0 from cron or the command line). */
	private static function actor( int $actorId ): int {
		return $actorId > 0 ? $actorId : get_current_user_id();
	}

	/** @throws InvalidArgumentException */
	private static function assertTier( string $tier ): void {
		if ( ! in_array( $tier, self::TIERS, true ) ) {
			throw new InvalidArgumentException( esc_html( sprintf( 'Unknown membership tier "%s".', $tier ) ) );
		}
	}

	/**
	 * Drop someone from this organization's sub-groups and project teams
	 * (org-scoped memberships do not outlive the membership), end what they
	 * led or stood for there, then say so. Other organizations' groups are
	 * left alone.
	 */
	private static function leave( int $orgId, int $userId ): void {
		$subgroups = new SubgroupRepository();
		foreach ( $subgroups->subgroupsForMember( $userId ) as $groupId ) {
			if ( (int) get_post_meta( (int) $groupId, SubgroupMeta::KEY_ORG_ID, true ) === $orgId ) {
				$subgroups->removeMember( (int) $groupId, $userId );
			}
		}
		$projects = new ProjectRepository();
		foreach ( $projects->projectsForMember( $userId ) as $projectId ) {
			if ( (int) get_post_meta( (int) $projectId, ProjectMeta::KEY_ORG_ID, true ) === $orgId ) {
				$projects->removeMember( (int) $projectId, $userId );
			}
		}
		// A leadership carries the right to author for the organization, and a
		// client contact speaks for it; neither outlives the membership.
		self::forget( SubgroupPostType::SLUG, SubgroupMeta::KEY_ORG_ID, $orgId, SubgroupMeta::KEY_LEADER, $userId );
		self::forget( ProjectPostType::SLUG, ProjectMeta::KEY_ORG_ID, $orgId, ProjectMeta::KEY_PRIMARY_CONTACT, $userId );
		SubgroupRepository::flushCache();
		AuthorScope::flushCache();
		do_action( Hooks::MEMBER_REMOVED_FROM_ORG, $userId, $orgId );
	}

	/**
	 * Clear a meta key naming this person on the organization's posts of one
	 * type (the sub-groups they lead, the projects they are the contact of).
	 */
	private static function forget( string $postType, string $orgKey, int $orgId, string $personKey, int $userId ): void {
		$ids = get_posts(
			[
				'post_type'      => $postType,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- one organization's sub-groups or projects, when someone leaves it.
					[
						'key'   => $orgKey,
						'value' => (string) $orgId,
					],
					[
						'key'   => $personKey,
						'value' => (string) $userId,
					],
				],
			]
		);
		foreach ( $ids as $id ) {
			delete_post_meta( (int) $id, $personKey );
		}
	}

	/**
	 * @param array<int, mixed> $ids
	 * @return list<int>
	 */
	private static function cleanIds( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	/**
	 * @param array<int, mixed> $invites
	 * @return list<string>
	 */
	private static function cleanInvites( array $invites ): array {
		$out = [];
		foreach ( $invites as $invite ) {
			$email = strtolower( trim( sanitize_text_field( (string) $invite ) ) );
			if ( '' !== $email ) {
				$out[] = $email;
			}
		}
		return array_values( array_unique( $out ) );
	}
}
