<?php
declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Hooks;
use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function findById( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/**
	 * An organization whose hub opens: one that exists and is published.
	 * An organization in the trash or set back to a draft keeps its
	 * memberships (Roster::sweepOrphans() says why), so a membership alone
	 * does not say there is a hub to send its member to. The hub's guard
	 * finds the organization by its slug among the published
	 * (findBySlug()); whatever offers a person their organizations to choose
	 * between asks here, so it offers none whose page would turn them away.
	 */
	public function findPublished( int $id ): ?WP_Post {
		$post = $this->findById( $id );
		return null !== $post && 'publish' === $post->post_status ? $post : null;
	}

	public function findBySlug( string $slug ): ?WP_Post {
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'name'           => sanitize_title( $slug ),
				'posts_per_page' => 1,
				'post_status'    => 'publish',
				'no_found_rows'  => true,
			]
		);
		$post  = $query->posts[0] ?? null;
		return $post instanceof WP_Post ? $post : null;
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function all( array $args = [] ): array {
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'post_status'    => [ 'publish', 'draft' ],
					'orderby'        => 'title',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	public function status( int $orgId ): string {
		return (string) ( get_post_meta( $orgId, Meta::KEY_STATUS, true ) ?: Meta::STATUS_ACTIVE );
	}

	public function isActive( int $orgId ): bool {
		return Meta::STATUS_ACTIVE === $this->status( $orgId );
	}

	/**
	 * The one writer for an organization's status. Writes the meta and fires
	 * Hooks::ORG_STATUS_CHANGED with the new and the previous status only when
	 * the value actually changes, so every caller (single-item REST, bulk,
	 * renewal, cron auto-suspend) notifies listeners the same way. An org with
	 * no status meta counts as active.
	 *
	 * @return bool True when the status changed; false for a no-op or an unknown status.
	 */
	public function setStatus( int $orgId, string $status ): bool {
		if ( ! in_array( $status, [ Meta::STATUS_ACTIVE, Meta::STATUS_SUSPENDED, Meta::STATUS_ARCHIVED ], true ) ) {
			return false;
		}
		$previous = $this->status( $orgId );
		if ( $previous === $status ) {
			return false;
		}
		update_post_meta( $orgId, Meta::KEY_STATUS, $status );
		do_action( Hooks::ORG_STATUS_CHANGED, $orgId, $status, $previous );
		return true;
	}

	/**
	 * How many people belong to the organization: its memberships of every
	 * tier, as the Roster holds them. Staff assignments are not among them.
	 */
	public function memberCount( int $orgId ): int {
		return count( Roster::memberIds( $orgId ) );
	}
}
