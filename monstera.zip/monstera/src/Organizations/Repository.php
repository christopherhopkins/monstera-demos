<?php
declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Hooks;
use Monstera\Reporting\ActivityLog;
use WP_Error;
use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	/**
	 * The post statuses of an organization on the site: every one but the
	 * trash. An organization's Active and Suspended are WordPress's Publish
	 * and Draft (the owner, 2026-10-18): published is active, and any other
	 * status here reads as suspended, or as archived when its status says so
	 * (statusOf()).
	 *
	 * @var list<string>
	 */
	public const ON_SITE = [ 'publish', 'draft', 'pending', 'private', 'future' ];

	/** Whether setStatus() is moving the post, so the transition it makes is not told again. */
	private static bool $moving = false;

	public function findById( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/**
	 * An organization whose hub opens: one that exists and is not in the
	 * trash, active, suspended or archived. One in the trash keeps its
	 * memberships (Roster::sweepOrphans() says why), so a membership alone
	 * does not say there is a hub to send its member to. The hub's guard
	 * finds the organization by its slug among these (findBySlug());
	 * whatever offers a person their organizations to choose between asks
	 * here, so it offers none whose page would turn them away.
	 */
	public function findOnSite( int $id ): ?WP_Post {
		$post = $this->findById( $id );
		return null !== $post && in_array( $post->post_status, self::ON_SITE, true ) ? $post : null;
	}

	/**
	 * The ones of these organizations on the site, each once, in the order
	 * given. An organization in the trash, or gone, grants its members
	 * nothing: not what is shared with it, not its projects, not its people
	 * (the review of the At-a-glance track, 2026-10-19), as its hub and its
	 * band already did not. It keeps their memberships for its return, so
	 * whatever a person's organizations grant asks here. Their posts are
	 * read together.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return list<int>
	 */
	public static function onSite( array $orgIds ): array {
		$orgIds = array_values( array_unique( array_filter( array_map( 'intval', $orgIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $orgIds ) {
			return [];
		}
		_prime_post_caches( $orgIds, false, false );
		return array_values(
			array_filter(
				$orgIds,
				static function ( int $id ): bool {
					$post = get_post( $id );
					return $post instanceof WP_Post && PostType::SLUG === $post->post_type && in_array( $post->post_status, self::ON_SITE, true );
				}
			)
		);
	}

	/** Whether the organization is on the site (onSite()). */
	public static function isOnSite( int $orgId ): bool {
		return [] !== self::onSite( [ $orgId ] );
	}

	/**
	 * The person's first organization on the site: their oldest membership
	 * whose organization is not in the trash, or 0. What falls to "their
	 * first" when nothing else names one (a row about an item for everyone,
	 * its email, a welcome, the shell's chip) asks here and never
	 * Roster::primaryOrgOf() alone, since one in the trash is named nowhere
	 * (the review of the At-a-glance track, 2026-10-19).
	 */
	public static function primaryOnSite( int $userId ): int {
		return self::onSite( Roster::orgIdsOf( $userId ) )[0] ?? 0;
	}

	/**
	 * Whether every organization of the person's is in the trash, or gone:
	 * then they are a member of none on the site, and what is for every
	 * member does not reach them either; only what names them does (the fix's review, 2026-10-19).
	 * A standalone member, who belongs to no organization at all, is not
	 * one of these.
	 */
	public static function belongsToNoneOnSite( int $userId ): bool {
		$memberships = Roster::orgIdsOf( $userId );
		return [] !== $memberships && [] === self::onSite( $memberships );
	}

	/**
	 * The organization at a hub's address, in any status but the trash. A
	 * slug is one organization's (uniqueSlug()), but one made before that
	 * held may share it with another: the published one is the hub, then
	 * the older.
	 */
	public function findBySlug( string $slug ): ?WP_Post {
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'name'           => sanitize_title( $slug ),
				'posts_per_page' => 5,
				'post_status'    => self::ON_SITE,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			]
		);
		$posts = array_values( array_filter( $query->posts, static fn ( $p ): bool => $p instanceof WP_Post ) );
		foreach ( $posts as $post ) {
			if ( 'publish' === $post->post_status ) {
				return $post;
			}
		}
		return $posts[0] ?? null;
	}

	/**
	 * `wp_insert_post_data` filter: an organization's slug is its own in any
	 * status. WordPress makes a slug unique only for a published post, and a
	 * suspended or archived organization is a draft (the owner, 2026-10-18)
	 * whose slug is still its hub's address, so a draft saved, restored from
	 * the trash or quick-edited takes the numbered suffix a published one
	 * would, rather than share its address with another organization.
	 *
	 * @param array<string, mixed> $data    The post row about to be written.
	 * @param array<string, mixed> $postarr What the write was asked for.
	 * @return array<string, mixed>
	 */
	public static function uniqueSlug( array $data, array $postarr ): array {
		$status = (string) ( $data['post_status'] ?? '' );
		$slug   = (string) ( $data['post_name'] ?? '' );
		if ( PostType::SLUG !== ( $data['post_type'] ?? '' ) || 'publish' === $status || '' === $slug || ! in_array( $status, self::ON_SITE, true ) ) {
			return $data;
		}
		$data['post_name'] = wp_unique_post_slug( $slug, (int) ( $postarr['ID'] ?? 0 ), 'publish', PostType::SLUG, 0 );
		return $data;
	}

	/** How many organizations are on the site, whatever their status: what the lists show. */
	public static function countOnSite(): int {
		$counts = (array) wp_count_posts( PostType::SLUG );
		return array_sum( array_map( static fn ( string $status ): int => (int) ( $counts[ $status ] ?? 0 ), self::ON_SITE ) );
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function all( array $args = [] ): array {
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'post_status'    => self::ON_SITE,
					'orderby'        => 'title',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	public function status( int $orgId ): string {
		return self::statusOf( $orgId );
	}

	/**
	 * An organization's status, read from its post (the owner, 2026-10-18):
	 * published is active; any other status on the site is suspended, or
	 * archived when the status meta says so, which is all the meta tells
	 * apart. One in the trash, or gone, is what the meta held when it went;
	 * one with nothing held is active. Every reader asks here, so a
	 * published organization is active whatever an older write left in its
	 * meta.
	 */
	public static function statusOf( int $orgId ): string {
		$postStatus = (string) get_post_status( $orgId );
		$held       = (string) get_post_meta( $orgId, Meta::KEY_STATUS, true );
		if ( 'publish' === $postStatus ) {
			return Meta::STATUS_ACTIVE;
		}
		if ( in_array( $postStatus, self::ON_SITE, true ) ) {
			return Meta::STATUS_ARCHIVED === $held ? Meta::STATUS_ARCHIVED : Meta::STATUS_SUSPENDED;
		}
		return in_array( $held, [ Meta::STATUS_SUSPENDED, Meta::STATUS_ARCHIVED ], true ) ? $held : Meta::STATUS_ACTIVE;
	}

	public function isActive( int $orgId ): bool {
		return Meta::STATUS_ACTIVE === $this->status( $orgId );
	}

	/**
	 * The one writer for an organization's status. Moves the post with it
	 * (active is published; suspended and archived are drafts) and keeps the
	 * status in its meta, which is what tells archived from suspended and
	 * what one in the trash comes back as (untrashStatus()); a status written
	 * while it is in the trash leaves it there. Fires
	 * Hooks::ORG_STATUS_CHANGED once, with the new and the previous status,
	 * only when the status actually changes, so every caller (single-item
	 * REST, bulk, renewal, cron auto-suspend) notifies listeners the same
	 * way; the post's own transition is not told again (followPostStatus()).
	 * Anything but an organization is left alone, and a move WordPress
	 * refuses puts the meta back and tells nobody: nothing changed.
	 *
	 * @return bool True when the status changed; false for a no-op, an unknown status, a post that is not an organization or a move refused.
	 */
	public function setStatus( int $orgId, string $status ): bool {
		if ( null === $this->findById( $orgId ) || ! in_array( $status, [ Meta::STATUS_ACTIVE, Meta::STATUS_SUSPENDED, Meta::STATUS_ARCHIVED ], true ) ) {
			return false;
		}
		$previous = $this->status( $orgId );
		if ( $previous === $status ) {
			return false;
		}
		$held = metadata_exists( 'post', $orgId, Meta::KEY_STATUS ) ? (string) get_post_meta( $orgId, Meta::KEY_STATUS, true ) : null;
		update_post_meta( $orgId, Meta::KEY_STATUS, $status );
		if ( ! $this->movePost( $orgId, $status ) ) {
			if ( null === $held ) {
				delete_post_meta( $orgId, Meta::KEY_STATUS );
			} else {
				update_post_meta( $orgId, Meta::KEY_STATUS, $held );
			}
			return false;
		}
		do_action( Hooks::ORG_STATUS_CHANGED, $orgId, $status, $previous );
		return true;
	}

	/**
	 * Moves the post to where the status puts it: published for active, a
	 * draft for the others. One in the trash stays there, and one already in
	 * place is not touched. Only the status moves, so WordPress's content
	 * filters, which would encode a title's ampersand on a run with no one
	 * signed in (the daily auto-suspend), stand aside while it is made: what
	 * is written back is what was stored.
	 *
	 * @return bool Whether the post is where the status puts it, or in the trash.
	 */
	private function movePost( int $orgId, string $status ): bool {
		$postStatus = (string) get_post_status( $orgId );
		$wanted     = Meta::STATUS_ACTIVE === $status ? 'publish' : 'draft';
		if ( ! in_array( $postStatus, self::ON_SITE, true ) || ( 'publish' === $postStatus ) === ( 'publish' === $wanted ) ) {
			return true;
		}
		$filtered = false !== has_filter( 'title_save_pre', 'wp_filter_kses' );
		if ( $filtered ) {
			kses_remove_filters();
		}
		self::$moving = true;
		try {
			$moved = wp_update_post(
				[
					'ID'          => $orgId,
					'post_status' => $wanted,
				],
				true
			);
		} finally {
			self::$moving = false;
			if ( $filtered ) {
				kses_init_filters();
			}
		}
		return ! is_wp_error( $moved );
	}

	/**
	 * A post status WordPress changed (its editor, Quick Edit, the command
	 * line) is a status change: published is active, and a published one set
	 * to any other status is suspended (the owner, 2026-10-18). The status in
	 * the meta follows, and the change is told once, in Monstera's words, so
	 * a suspension made in WordPress emails its people, and is filed in its
	 * activity, as one made here is. A new organization and one back from the
	 * trash are not changes, and neither is one going into the trash, which
	 * keeps its status for its return. setStatus()'s own move is told by
	 * setStatus().
	 */
	public static function followPostStatus( int $orgId, string $newStatus, string $oldStatus ): void {
		if ( self::$moving || $newStatus === $oldStatus || ! in_array( $newStatus, self::ON_SITE, true ) ) {
			return;
		}
		$held = (string) get_post_meta( $orgId, Meta::KEY_STATUS, true );
		$was  = 'publish' === $oldStatus ? Meta::STATUS_ACTIVE : ( Meta::STATUS_ARCHIVED === $held ? Meta::STATUS_ARCHIVED : Meta::STATUS_SUSPENDED );
		$now  = self::statusOf( $orgId );
		if ( $held !== $now ) {
			update_post_meta( $orgId, Meta::KEY_STATUS, $now );
		}
		if ( in_array( $oldStatus, [ 'new', 'auto-draft', 'trash' ], true ) || $was === $now ) {
			return;
		}
		do_action( Hooks::ORG_STATUS_CHANGED, $orgId, $now, $was );
		if ( Meta::STATUS_SUSPENDED === $now ) {
			ActivityLog::record( 'org_suspended', 'org', $orgId );
		}
	}

	/**
	 * What an organization back from the trash is restored as: what its
	 * status was when it went, published when active and a draft otherwise,
	 * where WordPress would make every one a draft, which is suspended.
	 */
	public static function untrashStatus( string $status, int $postId, string $previous ): string { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- WordPress passes the status it was trashed from; the organization's own status says what it comes back as.
		if ( PostType::SLUG !== get_post_type( $postId ) ) {
			return $status;
		}
		return Meta::STATUS_ACTIVE === self::statusOf( $postId ) ? 'publish' : 'draft';
	}

	/**
	 * The post status and the status a new organization is made with, for
	 * wp_insert_post(): active is published, suspended and archived are
	 * drafts, and the status is held from the first write, so the
	 * organization is made in it rather than changed into it. Its day is
	 * given too: WordPress gives a draft made without one a new day at every
	 * update, which would move its "Created" with each save (the review of
	 * the At-a-glance track, 2026-10-19).
	 *
	 * @return array{post_status: string, post_date_gmt: string, meta_input: array<string, string>}
	 */
	public static function madeAs( string $status ): array {
		$status = in_array( $status, [ Meta::STATUS_SUSPENDED, Meta::STATUS_ARCHIVED ], true ) ? $status : Meta::STATUS_ACTIVE;
		return [
			'post_status'   => Meta::STATUS_ACTIVE === $status ? 'publish' : 'draft',
			'post_date_gmt' => current_time( 'mysql', true ),
			'meta_input'    => [ Meta::KEY_STATUS => $status ],
		];
	}

	/**
	 * What the team is told when someone would be put in, or the team
	 * assigned to, an organization that is not active: it takes no one new
	 * and no team until it is reactivated (the owner, 2026-10-18).
	 */
	public static function reactivateFirst( int $orgId ): string {
		$name = html_entity_decode( get_the_title( $orgId ), ENT_QUOTES, 'UTF-8' );
		return Meta::STATUS_ARCHIVED === self::statusOf( $orgId )
			/* translators: %s: the organization's name */
			? sprintf( __( '%s is archived. Reactivate it to add people or assign the team.', 'monstera' ), $name )
			/* translators: %s: the organization's name */
			: sprintf( __( '%s is suspended. Reactivate it to add people or assign the team.', 'monstera' ), $name );
	}

	/**
	 * How many people belong to the organization: its memberships of every
	 * tier, as the Roster holds them. Staff assignments are not among them.
	 */
	public function memberCount( int $orgId ): int {
		return count( Roster::memberIds( $orgId ) );
	}

	// ---- The account lead (At-a-glance track, FR4) ---------------------------

	/**
	 * The one staff person the organization's people reach first, or 0.
	 * Kept in the organization's own meta, so a list that loaded its
	 * organizations with their meta reads it without another query.
	 */
	public function accountLeadId( int $orgId ): int {
		return $orgId > 0 ? (int) get_post_meta( $orgId, Meta::KEY_ACCOUNT_LEAD, true ) : 0;
	}

	/**
	 * The one writer for the account lead. The lead is one of the staff
	 * assigned to the organization (Roster::staffIds()): anyone else is
	 * refused, a client member and a stranger alike, so the admin's picker
	 * and the route need no rule of their own. 0 clears. The same value
	 * again writes nothing, fires nothing and files nothing.
	 *
	 * @param int $actorId Who did it; the current user when 0, which a
	 *                     sweep with no signed-in user leaves as nobody.
	 * @return bool|WP_Error True when the lead changed; false for a no-op;
	 *                       `monstera_not_assigned` for someone not assigned here.
	 */
	public function setAccountLead( int $orgId, int $userId, int $actorId = 0 ): bool|WP_Error {
		$userId = max( 0, $userId );
		if ( $userId > 0 && ! in_array( $userId, Roster::staffIds( $orgId ), true ) ) {
			return new WP_Error( 'monstera_not_assigned', __( 'Choose someone assigned to this organization.', 'monstera' ), [ 'status' => 422 ] );
		}
		$previous = $this->accountLeadId( $orgId );
		if ( $previous === $userId ) {
			return false;
		}
		// The hook and the sentence are for a change the database made.
		$written = $userId > 0
			? false !== update_post_meta( $orgId, Meta::KEY_ACCOUNT_LEAD, $userId )
			: delete_post_meta( $orgId, Meta::KEY_ACCOUNT_LEAD );
		if ( ! $written ) {
			return false;
		}
		$actorId = $actorId > 0 ? $actorId : get_current_user_id();
		do_action( Hooks::ORG_ACCOUNT_LEAD_CHANGED, $orgId, $userId, $previous, $actorId );
		ActivityLog::record(
			'org_account_lead_changed',
			'org',
			$orgId,
			[
				'lead_id'     => $userId,
				'previous_id' => $previous,
				'user_id'     => $actorId,
			]
		);
		return true;
	}

	/**
	 * The lead goes with the assignment: whatever ended it (Roster::unassign()
	 * by hand, a role leaving the team, the daily sweep) clears a lead the
	 * person held here, credited to the same actor. One of someone else is
	 * left alone.
	 */
	public function endAccountLeadOf( int $orgId, int $userId, int $actorId = 0 ): void {
		if ( $userId > 0 && $this->accountLeadId( $orgId ) === $userId ) {
			$this->setAccountLead( $orgId, 0, $actorId );
		}
	}

	/**
	 * Every organization with an account lead, and whom: for the daily
	 * sweep, which asks whether each is still an account and still assigned
	 * (Roster::sweepOrphans()). One read however many organizations.
	 *
	 * @return array<int, int> Organization id => lead's user id.
	 */
	public function accountLeads(): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT post_id, meta_value FROM %i WHERE meta_key = %s', $wpdb->postmeta, Meta::KEY_ACCOUNT_LEAD ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one read for the sweep; no API lists a meta key's posts without loading them.
		$out  = [];
		foreach ( $rows as $row ) {
			$leadId = (int) $row['meta_value'];
			if ( $leadId > 0 ) {
				$out[ (int) $row['post_id'] ] = $leadId;
			}
		}
		return $out;
	}

	/**
	 * The active organizations with no account lead, by title, for the
	 * dashboard's health row (At-a-glance track, FR4). A suspended or
	 * archived organization is not asked. One query however many there
	 * are, which WordPress answers from its cache when the dashboard's other
	 * rows listed them first.
	 *
	 * @return list<int> Organization ids.
	 */
	public function withoutAccountLead(): array {
		$out = [];
		foreach ( $this->all() as $org ) {
			if ( $this->isActive( (int) $org->ID ) && 0 === $this->accountLeadId( (int) $org->ID ) ) {
				$out[] = (int) $org->ID;
			}
		}
		return $out;
	}

	/**
	 * Leave no organization naming this person as its lead: for an account
	 * that no longer exists, whose assignments went with its rows and whose
	 * name no sentence could carry. One write for every organization, with
	 * no hook and no sentence: nobody did it, and nobody is named.
	 */
	public function forgetAccountLead( int $userId ): void {
		if ( $userId > 0 ) {
			delete_metadata( 'post', 0, Meta::KEY_ACCOUNT_LEAD, $userId, true );
		}
	}
}
