<?php
declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Hooks;
use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function findById( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	public function findBySlug( string $slug ): ?WP_Post {
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'name'           => sanitize_title( $slug ),
				'posts_per_page' => 1,
				'post_status'    => 'publish',
				'no_found_rows'  => true,
			]
		);
		$post  = $query->posts[0] ?? null;
		return $post instanceof WP_Post ? $post : null;
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function all( array $args = [] ): array {
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'posts_per_page' => -1,
					'post_status'    => [ 'publish', 'draft' ],
					'orderby'        => 'title',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	public function status( int $orgId ): string {
		return (string) ( get_post_meta( $orgId, Meta::KEY_STATUS, true ) ?: Meta::STATUS_ACTIVE );
	}

	public function isActive( int $orgId ): bool {
		return Meta::STATUS_ACTIVE === $this->status( $orgId );
	}

	/**
	 * The one writer for an organization's status. Writes the meta and fires
	 * Hooks::ORG_STATUS_CHANGED with the new and the previous status only when
	 * the value actually changes, so every caller (single-item REST, bulk,
	 * renewal, cron auto-suspend) notifies listeners the same way. An org with
	 * no status meta counts as active.
	 *
	 * @return bool True when the status changed; false for a no-op or an unknown status.
	 */
	public function setStatus( int $orgId, string $status ): bool {
		if ( ! in_array( $status, [ Meta::STATUS_ACTIVE, Meta::STATUS_SUSPENDED, Meta::STATUS_ARCHIVED ], true ) ) {
			return false;
		}
		$previous = $this->status( $orgId );
		if ( $previous === $status ) {
			return false;
		}
		update_post_meta( $orgId, Meta::KEY_STATUS, $status );
		do_action( Hooks::ORG_STATUS_CHANGED, $orgId, $status, $previous );
		return true;
	}

	public function memberCount( int $orgId ): int {
		$users = get_users(
			[
				'meta_key'   => 'monstera_associated_org', // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
				'meta_value' => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
				'fields'     => 'ID',
				'number'     => -1,
			]
		);
		return count( (array) $users );
	}
}
