<?php
declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

final class PostType {

	public const SLUG = 'monstera_org';

	public static function register(): void {
		register_post_type(
			self::SLUG,
			[
				'labels'                => [
					'name'               => __( 'Organizations', 'monstera' ),
					'singular_name'      => __( 'Organization', 'monstera' ),
					'menu_name'          => __( 'Organizations', 'monstera' ),
					'add_new'            => __( 'Add organization', 'monstera' ),
					'add_new_item'       => __( 'Add organization', 'monstera' ),
					'edit_item'          => __( 'Edit organization', 'monstera' ),
					'new_item'           => __( 'New organization', 'monstera' ),
					'view_item'          => __( 'View organization', 'monstera' ),
					'search_items'       => __( 'Search organizations', 'monstera' ),
					'not_found'          => __( 'No organizations yet.', 'monstera' ),
					'not_found_in_trash' => __( 'No organizations in trash.', 'monstera' ),
				],
				'public'                => false,
				'show_ui'               => true,
				'show_in_menu'          => false, // We render under our top-level Monstera menu.
				'show_in_rest'          => true,
				'rest_base'             => 'organizations',
				'rest_controller_class' => 'WP_REST_Posts_Controller',
				'supports'              => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
				'has_archive'           => false,
				'rewrite'               => false,
				'menu_position'         => 26,
				'capability_type'       => 'post',
				'map_meta_cap'          => true,
				'capabilities'          => [
					'edit_posts'         => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'  => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}
}
