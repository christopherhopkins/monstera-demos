<?php
declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class OrganizationsModule implements Module {

	public function slug(): string {
		return 'organizations';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ TierTaxonomy::class, 'register' ], 6 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		add_action( 'transition_post_status', [ $this, 'onStatusChange' ], 10, 3 );
		// A team role taken by any door (the Team routes, WordPress's Users
		// screen, the command line) ends the person's assignments and leads,
		// and gives back the client role a membership of theirs implies.
		add_action( 'remove_user_role', [ Roster::class, 'onRoleRemoved' ], 10, 2 );
		// Listen for completed renewal payments (fired by the Payments module).
		Membership::register();
	}

	public function registerPostTypes(): void {
		PostType::register();
	}

	public function onStatusChange( string $newStatus, string $oldStatus, \WP_Post $post ): void {
		if ( PostType::SLUG !== $post->post_type ) {
			return;
		}
		if ( $newStatus === $oldStatus ) {
			return;
		}
		do_action( \Monstera\Core\Hooks::ORG_STATUS_CHANGED, $post->ID, $newStatus, $oldStatus );
	}
}
