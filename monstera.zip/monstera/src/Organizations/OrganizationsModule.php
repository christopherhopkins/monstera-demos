<?php
declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class OrganizationsModule implements Module {

	public function slug(): string {
		return 'organizations';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ TierTaxonomy::class, 'register' ], 6 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		// Active is published and suspended a draft (the owner, 2026-10-18):
		// a post status WordPress changes is a status change, and one back from
		// the trash returns as its status was.
		add_action( 'transition_post_status', [ $this, 'onStatusChange' ], 10, 3 );
		add_filter( 'wp_untrash_post_status', [ Repository::class, 'untrashStatus' ], 10, 3 );
		// A suspended organization's slug is still its hub's address.
		add_filter( 'wp_insert_post_data', [ Repository::class, 'uniqueSlug' ], 10, 2 );
		// A team role taken by any door (the Team routes, WordPress's Users
		// screen, the command line) ends the person's assignments and leads,
		// and gives back the client role a membership of theirs implies.
		add_action( 'remove_user_role', [ Roster::class, 'onRoleRemoved' ], 10, 2 );
		// Listen for completed renewal payments (fired by the Payments module).
		Membership::register();
	}

	public function registerPostTypes(): void {
		PostType::register();
	}

	public function onStatusChange( string $newStatus, string $oldStatus, \WP_Post $post ): void {
		if ( PostType::SLUG !== $post->post_type ) {
			return;
		}
		Repository::followPostStatus( (int) $post->ID, $newStatus, $oldStatus );
	}
}
