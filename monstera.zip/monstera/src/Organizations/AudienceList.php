<?php
/**
 * The one rule by which a resource or a form reaches a person: published,
 * past the role gate, the audience (the organizations and the people it
 * names; nothing named reaches every member), the sub-group gate, and not
 * held back by an ended membership. Resources\Repository and
 * Forms\Repository ask here, so the Resources page, the Forms page, a hub's
 * two tabs and the logging redirect cannot disagree about what a person
 * may open (Forms-and-resources track, FR2 and FR3).
 */

declare(strict_types=1);

namespace Monstera\Organizations;

use Monstera\AccessControl\PortalGuard;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;
use WP_Query;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class AudienceList {

	/**
	 * The published items of a type a person can open, by title, and the
	 * ended organizations whose items were left out.
	 *
	 * An ended membership gives way (People-model track, FR5): an item that
	 * reaches the person through ended organizations alone is left out, and
	 * the second answer names those organizations, so a page can say whose
	 * items are waiting. One that a running organization of theirs shares
	 * too stays, and so does one for every member and one that names the
	 * person, which no organization can take back. Which organizations are
	 * held back, and that staff are held back from nothing, is
	 * Organizations\Reach's to say.
	 *
	 * An item reaches a person through the organizations of theirs it names
	 * and through the sub-groups it names that they are in. A sub-group they
	 * are not in brings them nothing.
	 *
	 * A standalone member reaches every item through their own membership,
	 * so once it has ended (PortalGuard::ownMembershipExpired()) none is
	 * listed.
	 *
	 * @param array{roles: string, orgs: string, members: string, subgroups: string} $keys   The item type's four audience meta keys.
	 * @param callable(int, int[]|null): list<int>                                   $orgsOf The organizations an item names, counting the sub-groups given (Reach::resourceOrgs(), Reach::formOrgs()).
	 * @return array{0: WP_Post[], 1: list<int>} The items, then the ended organizations whose items were left out, in the person's membership order.
	 */
	public static function listedFor( WP_User $user, string $postType, array $keys, callable $orgsOf ): array {
		// An account the portal is not for (a site subscriber, a shop's
		// customer, someone the Roster removed) is nobody's member: nothing
		// reaches it, so its routes answer as its pages do (Phase 5 review).
		if ( ! PortalGuard::isPortalAccount( $user ) || PortalGuard::ownMembershipExpired( $user ) ) {
			return [ [], [] ];
		}
		$q = new WP_Query(
			[
				'post_type'      => $postType,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'orderby'        => 'title',
				'order'          => 'ASC',
			]
		);

		// An organization in the trash grants nothing (Repository::onSite()).
		$out       = [];
		$waiting   = [];
		$userOrgs  = Repository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		$userSubs  = ( new SubgroupRepository() )->publishedSubgroupsForMember( $user->ID );
		$isAdmin   = user_can( $user, 'manage_monstera' );
		$userRoles = (array) $user->roles;
		$heldBack  = Reach::heldBackFor( $user );
		if ( $heldBack ) {
			// Each item is about to be asked which organizations bring it, its
			// sub-groups' parents among them: those are read together.
			Reach::primeParents( $q->posts, $keys['subgroups'], $userSubs );
		}

		// Every organization of theirs in the trash: a member of none on the
		// site, an item reaches them by name alone.
		$noneOnSite = Repository::belongsToNoneOnSite( (int) $user->ID );

		foreach ( $q->posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			if ( $isAdmin ) {
				$out[] = $post;
				continue;
			}

			// Unset meta reads back as '' and casts to [''], a truthy list that
			// matches nobody, so every list is filtered to real values before
			// it is allowed to gate.
			$allowedRoles = array_filter( array_map( 'strval', (array) get_post_meta( $post->ID, $keys['roles'], true ) ) );
			if ( $allowedRoles && ! array_intersect( $userRoles, $allowedRoles ) ) {
				continue;
			}

			// Organizations and named people form one audience: with either
			// list set the person must match one of them, any of their
			// organizations listed or themselves named (People-model track,
			// FR8), as the content engine's audience rule has it. Each item is
			// judged once, so a person in two of its organizations sees it once.
			$allowedOrgs    = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, $keys['orgs'], true ) ) );
			$allowedMembers = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, $keys['members'], true ) ) );
			$memberMatch    = in_array( (int) $user->ID, $allowedMembers, true );
			if ( $noneOnSite && ! $memberMatch ) {
				continue;
			}
			if ( $allowedOrgs || $allowedMembers ) {
				$orgMatch = [] !== array_intersect( $userOrgs, $allowedOrgs );
				if ( ! $orgMatch && ! $memberMatch ) {
					continue;
				}
			}

			// The person's published sub-groups: one deleted or in the trash
			// lets nobody through (the owner's call, 2026-10-18).
			$allowedSubs = array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, $keys['subgroups'], true ) ) );
			if ( $allowedSubs && ! array_intersect( $allowedSubs, $userSubs ) ) {
				continue;
			}

			// Theirs to open, unless only an ended membership brings it. One
			// that names the person is asked nothing: it reaches them by name.
			if ( $heldBack && ! $memberMatch ) {
				$named = $orgsOf( (int) $post->ID, $userSubs );
				if ( Reach::onlyThrough( (int) $user->ID, $named, $heldBack ) ) {
					$waiting = array_merge( $waiting, $named );
					continue;
				}
			}

			$out[] = $post;
		}
		// array_intersect keeps the first array's order: the person's memberships, oldest first.
		return [ $out, array_values( array_intersect( $heldBack, $waiting ) ) ];
	}

	/**
	 * Of the items a person can open (listedFor()), those particular to one
	 * organization, for its hub's tab: the ones that name it, and the ones
	 * that name no organization but are narrowed to one of its sub-groups
	 * (a sub-group has one parent, so the item is this organization's as
	 * surely as one that names it). One sent to every member names nobody
	 * and narrows nothing, so it is on the page and not here.
	 *
	 * An item of the second shape may be narrowed to a sub-group of each of
	 * several organizations. It is on this hub when this organization is
	 * one it reaches the reader through: a group of theirs under it is
	 * among those named. Staff sit in no sub-group and read every item, so
	 * for them any sub-group of this organization places it here.
	 *
	 * @param WP_Post[]                             $visible What listedFor() lists for the person.
	 * @param array{subgroups: string, orgs: string} $keys    The item type's meta keys.
	 * @param callable(int, int[]|null): list<int>  $orgsOf  The organizations an item names, counting the sub-groups given.
	 * @return WP_Post[]
	 */
	public static function forOrg( WP_User $user, int $orgId, array $visible, array $keys, callable $orgsOf ): array {
		if ( $orgId <= 0 || ! $visible ) {
			return [];
		}
		// The sub-groups that place an item here: the reader's own, or for
		// staff every one this organization has.
		$placing = user_can( $user, 'manage_monstera' )
			? array_map( static fn ( WP_Post $group ): int => (int) $group->ID, ( new SubgroupRepository() )->forOrg( $orgId ) )
			: ( new SubgroupRepository() )->publishedSubgroupsForMember( (int) $user->ID );
		Reach::primeParents( $visible, $keys['subgroups'], $placing );
		return array_values(
			array_filter(
				$visible,
				static function ( WP_Post $item ) use ( $orgId, $placing, $keys, $orgsOf ): bool {
					// Filtered as in listedFor(): unset meta reads back as [''].
					$orgs = array_filter( array_map( 'intval', (array) get_post_meta( $item->ID, $keys['orgs'], true ) ) );
					if ( $orgs ) {
						return in_array( $orgId, $orgs, true );
					}
					return in_array( $orgId, $orgsOf( (int) $item->ID, $placing ), true );
				}
			)
		);
	}

	/**
	 * One reading of what brings each of these items to the person, for the
	 * rows that name it and the pages that are about it: the organizations
	 * of theirs it names, counting a sub-group only when they are in it,
	 * and the one among those that speaks for it (Reach::among()), 0 when
	 * it is held back by an ended membership. The person's sub-groups and
	 * the parents of the sub-groups named are one read each, however many
	 * items. Nothing for a person in no organization on the site.
	 *
	 * @param WP_Post[]                              $posts    Items listed for the person.
	 * @param callable(int, int[]|null): list<int>   $orgsOf   The organizations an item names, counting the sub-groups given.
	 * @param int[]|null                             $userSubs The person's published sub-groups, when the caller has them.
	 * @return array<int, array{named: list<int>, org: int}> By item id.
	 */
	public static function reachOf( WP_User $user, array $posts, string $subgroupsKey, callable $orgsOf, ?array $userSubs = null ): array {
		if ( ! $posts || ! OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) ) ) {
			return [];
		}
		$userSubs ??= ( new SubgroupRepository() )->publishedSubgroupsForMember( (int) $user->ID );
		Reach::primeParents( $posts, $subgroupsKey, $userSubs );
		$heldBack = Reach::heldBackFor( $user );
		$out      = [];
		foreach ( $posts as $post ) {
			$named = $orgsOf( (int) $post->ID, $userSubs );
			$org   = Reach::among( (int) $user->ID, $named );

			$out[ (int) $post->ID ] = [
				'named' => $named,
				'org'   => in_array( $org, $heldBack, true ) ? 0 : $org,
			];
		}
		return $out;
	}

	/**
	 * The organization each of these items reaches the person through
	 * (reachOf()), for a person in any number of organizations: 0 for an
	 * item for everyone, one that reaches them by name alone, or one held
	 * back. Whether to name it is the page's to decide.
	 *
	 * @param WP_Post[]                            $posts
	 * @param callable(int, int[]|null): list<int> $orgsOf
	 * @param int[]|null                           $userSubs
	 * @return array<int, int> By item id.
	 */
	public static function reachedThrough( WP_User $user, array $posts, string $subgroupsKey, callable $orgsOf, ?array $userSubs = null ): array {
		return array_map( static fn ( array $reach ): int => $reach['org'], self::reachOf( $user, $posts, $subgroupsKey, $orgsOf, $userSubs ) );
	}
}
