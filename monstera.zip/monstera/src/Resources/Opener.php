<?php
declare(strict_types=1);

namespace Monstera\Resources;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Reporting\Tracking;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * The portal's links and files go through /portal/resources/{id}/open/,
 * which logs the open and sends the member on to the file or the external
 * page, so the admin can see how often a resource is used. A resource the
 * member cannot see is refused, never revealed, and so is a file that is
 * waiting on an organization: the page prints no link to it, and an old
 * link of this kind does not open it. A guide has a page of its own
 * (/portal/resources/{id}/) and is never opened this way.
 *
 * That is as far as the wait reaches. A resource's file is a Media Library
 * attachment (the sensitivity decision, product.md), and this route
 * redirects to the file's own address in the uploads folder, which
 * WordPress serves to anyone who has it, signed in or not. Someone who
 * opened the file once (their browser's history, a forwarded link) opens it
 * again whatever the portal says of their organization since. A content
 * item's file is the one that is streamed behind a check (Content\Downloader).
 */
final class Opener {

	/**
	 * Where the member goes for this resource, or null when they cannot see
	 * it, its file waits (Repository::fileWaits()) or it has nowhere to go
	 * (a guide). Records the open.
	 */
	public static function target( WP_User $user, int $resourceId ): ?string {
		// The module gates end to end (FR1): with Resources off an old link
		// goes nowhere, as the page and the routes do.
		if ( ! Modules::isActive( Modules::RESOURCES ) ) {
			return null;
		}
		// A link from the Resources page opens for whoever that page opens
		// for: the guard answers for the pages the router renders, and this
		// route is not one of them.
		if ( null !== PortalGuard::blockedReason( $user, Routing::ROUTE_RESOURCES ) ) {
			return null;
		}
		$resources = new Repository();
		$visible   = array_map( static fn ( $post ) => (int) $post->ID, $resources->visibleTo( $user ) );
		if ( ! in_array( $resourceId, $visible, true ) || $resources->fileWaits( $user, $resourceId ) ) {
			return null;
		}
		$url = match ( Meta::kindOf( $resourceId ) ) {
			Meta::KIND_FILE => (string) wp_get_attachment_url( (int) get_post_meta( $resourceId, Meta::KEY_FILE_ID, true ) ),
			Meta::KIND_LINK => (string) get_post_meta( $resourceId, Meta::KEY_EXTERNAL_URL, true ),
			default         => '',
		};
		if ( '' === $url ) {
			return null;
		}
		Tracking::resourceOpened( $resourceId, $user->ID );
		return $url;
	}

	/** The route's handler: redirect, or a 404 that says nothing about the resource. */
	public static function handle( int $resourceId ): void {
		$user = wp_get_current_user();
		$url  = $user->exists() ? self::target( $user, $resourceId ) : null;
		if ( null === $url ) {
			wp_die(
				esc_html__( 'This resource is not available to you.', 'monstera' ),
				esc_html__( 'Not available', 'monstera' ),
				[ 'response' => 404 ]
			);
		}
		// External links are the admin's own configured URLs, so wp_redirect
		// rather than the same-host-only wp_safe_redirect.
		wp_redirect( esc_url_raw( $url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- the destination is the resource's own saved file or external URL.
		exit;
	}
}
