<?php
declare(strict_types=1);

namespace Monstera\Resources;

use Monstera\Core\Hooks;
use Monstera\Core\Module;
use WP_Post;

defined( 'ABSPATH' ) || exit;

/**
 * The library: external links, files anyone on the site may hold, and
 * guides written with the block editor. Until 2026-10-26 the forms module
 * carried it (Forms-and-resources track, FR1); it is gated end to end by
 * `Core\Modules::RESOURCES`.
 */
final class ResourcesModule implements Module {

	public function slug(): string {
		return 'resources';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		add_action( 'transition_post_status', [ $this, 'onTransition' ], 10, 3 );
	}

	public function registerPostTypes(): void {
		PostType::register();
	}

	/**
	 * monstera/resource_published fires the first time a resource is
	 * published, as monstera/content_published does for an item: not for an
	 * edit while published, and not again for a resource taken back to a
	 * draft and published once more (the meta remembers).
	 */
	public function onTransition( string $newStatus, string $oldStatus, WP_Post $post ): void {
		if ( PostType::SLUG !== $post->post_type || 'publish' !== $newStatus || 'publish' === $oldStatus ) {
			return;
		}
		if ( (bool) get_post_meta( $post->ID, Meta::KEY_PUBLISHED_NOTIFIED, true ) ) {
			return;
		}
		update_post_meta( $post->ID, Meta::KEY_PUBLISHED_NOTIFIED, '1' );
		do_action( Hooks::RESOURCE_PUBLISHED, (int) $post->ID );
	}
}
