<?php
declare(strict_types=1);

namespace Monstera\Resources;

use Monstera\Organizations\AudienceList;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use WP_Post;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Repository {

	private const KEYS = [
		'roles'     => Meta::KEY_ROLES,
		'orgs'      => Meta::KEY_ORGS,
		'members'   => Meta::KEY_STANDALONE_MEMBERS,
		'subgroups' => Meta::KEY_SUBGROUPS,
	];

	/**
	 * The published resources a person can open, by title: past the role,
	 * audience and sub-group gates, and not held back by an ended
	 * membership (listedFor() has the rule). The Resources page, a hub's
	 * tab and the logging redirect all read this list, so none of them can
	 * offer what another refuses.
	 *
	 * @return WP_Post[]
	 */
	public function visibleTo( WP_User $user ): array {
		return $this->listedFor( $user )[0];
	}

	/**
	 * What visibleTo() lists, and the ended organizations whose resources it
	 * left out (Organizations\AudienceList has the rule, shared with forms).
	 *
	 * @return array{0: WP_Post[], 1: list<int>}
	 */
	public function listedFor( WP_User $user ): array {
		return AudienceList::listedFor( $user, PostType::SLUG, self::KEYS, [ Reach::class, 'resourceOrgs' ] );
	}

	/**
	 * What a row says beside each of these resources to a person in several
	 * organizations (People-model track, FR5): the organization the resource
	 * reaches them through, for the row to name, and whether its file waits.
	 * The Resources page and a hub's tab ask here for all their rows at
	 * once, and the logging redirect for its one (fileWaits()), so the list,
	 * its labels and the gate are worked out in one class from one reading
	 * of what brings a resource to a person: the organizations of theirs it
	 * names, and the parents of the sub-groups it names that they are in
	 * (listedFor() says why a sub-group they are not in counts for nothing).
	 *
	 * The organization is the one Organizations\Reach picks among those: a
	 * live one before a suspended one before an ended one, never the
	 * resource's own first. It is said of every row, whichever list the row
	 * sits in: a resource narrowed to one organization's sub-group names no
	 * organization itself and is that organization's all the same, and a
	 * reader told that its download is paused has to be told whose. There is
	 * none to name (0) for a resource for every member, for one that reaches
	 * them by name alone, and for one whose organization is held back, which
	 * is listed only because it names them.
	 *
	 * The file waits when it is a file that reaches them through
	 * organizations of theirs none of which is live, each being suspended
	 * or its membership ended. It is the rule a content file follows
	 * (Content\Downloader), for the same reason: on the pages that span
	 * every organization the shell's suspended block stands back for a
	 * person with another live one, so the row is where a suspended
	 * organization's download is said to wait, and the dashboard's band has
	 * already promised that it does. The row prints no link then and the
	 * logging redirect refuses the file (Opener). A link or a guide is not a
	 * download and never waits; nor does a file for every member
	 * or one that names the person, which no organization shares and so
	 * none can pause; nor does staff's.
	 *
	 * A person in one organization is paused by the same rule (decided at the
	 * Phase 6 task, for the owner at its checkpoint): the shell's soft block above their
	 * pages says that downloads are paused while the organization is
	 * suspended, and a resource's file, a Media Library upload, used to open
	 * from under it all the same. Their rows name no organization, the
	 * heading naming it, so only the wait is said of them.
	 *
	 * The person's sub-groups are one read and the parents of the
	 * sub-groups named another, however many rows are asked about; the file
	 * rows' attachments are read together too (Files::prime()).
	 *
	 * @param WP_Post[] $resources Resources listed for the person (visibleTo()).
	 * @return array<int, array{org: int, waits: bool}> By resource id; `org` is 0 for a person in fewer than two organizations.
	 */
	public function besideEach( WP_User $user, array $resources ): array {
		// Every page that prints rows asks this once for the whole list, so
		// the rows' files are read here, together, for whoever is reading.
		Files::prime( $resources );
		$userOrgs = OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) );
		if ( ! $resources || ! $userOrgs ) {
			return [];
		}
		$several = count( $userOrgs ) > 1;
		$isStaff = user_can( $user, 'manage_monstera' );
		$beside  = [];
		foreach ( $this->reach( $user, $resources ) as $resourceId => [ 'named' => $named, 'org' => $org ] ) {
			// Those of theirs that bring it; only whether one of them is live is asked.
			$through = array_intersect( $userOrgs, $named );
			$waits   = ! $isStaff && $through && self::isPausable( $resourceId, (int) $user->ID ) && ! array_filter( $through, [ Reach::class, 'isLive' ] );

			$beside[ $resourceId ] = [
				'org'   => $several ? $org : 0,
				'waits' => $waits,
			];
		}
		return $beside;
	}

	/**
	 * The organization each of these resources reaches the person through,
	 * by the reading a row names it with (besideEach()), for a person in
	 * any number of organizations: a guide's page is about it, and what
	 * else that page lists beside the guide is what comes through the same
	 * one (Forms-and-resources track, FR4). 0 for a resource that reaches
	 * them through none of theirs, or through one held back.
	 *
	 * @param WP_Post[] $resources Resources listed for the person (visibleTo()).
	 * @return array<int, int> By resource id.
	 */
	public function reachedThrough( WP_User $user, array $resources ): array {
		if ( ! $resources || ! OrgRepository::onSite( Roster::orgIdsOf( (int) $user->ID ) ) ) {
			return [];
		}
		return array_map( static fn ( array $reach ): int => $reach['org'], $this->reach( $user, $resources ) );
	}

	/**
	 * One reading of what brings each resource to the person
	 * (Organizations\AudienceList::reachOf(), shared with forms): the
	 * organizations of theirs it names and the one among those that speaks
	 * for it, 0 when held back.
	 *
	 * @param WP_Post[] $resources
	 * @return array<int, array{named: list<int>, org: int}> By resource id.
	 */
	private function reach( WP_User $user, array $resources ): array {
		return AudienceList::reachOf( $user, $resources, Meta::KEY_SUBGROUPS, [ Reach::class, 'resourceOrgs' ] );
	}

	/**
	 * The guide this person may open at /portal/resources/{id}/, or null:
	 * a resource the library lists for them (visibleTo(): published,
	 * reaching them, not held back by an ended membership) that is a guide.
	 * A draft, a guide out of reach, a link and a file are all null, so the
	 * router's 404 and the page's blocked pattern tell nothing apart
	 * (Forms-and-resources track, FR4).
	 */
	public function guideFor( WP_User $user, int $resourceId ): ?WP_Post {
		if ( $resourceId <= 0 || Meta::KIND_GUIDE !== Meta::kindOf( $resourceId ) ) {
			return null;
		}
		foreach ( $this->visibleTo( $user ) as $resource ) {
			if ( (int) $resource->ID === $resourceId ) {
				return $resource;
			}
		}
		return null;
	}

	/**
	 * Whether one resource's file waits for this person (besideEach() has
	 * the rule), for the logging redirect, which is asked about one.
	 */
	public function fileWaits( WP_User $user, int $resourceId ): bool {
		$resource = get_post( $resourceId );
		return $resource instanceof WP_Post && ( $this->besideEach( $user, [ $resource ] )[ $resourceId ]['waits'] ?? false );
	}

	/**
	 * Whether a resource is a file an organization could pause for this
	 * person at all: a file, and not one that names them, which reaches them
	 * through no organization.
	 */
	private static function isPausable( int $resourceId, int $userId ): bool {
		return Meta::KIND_FILE === Meta::kindOf( $resourceId )
			&& ! in_array( $userId, array_map( 'intval', (array) get_post_meta( $resourceId, Meta::KEY_STANDALONE_MEMBERS, true ) ), true );
	}

	/**
	 * The resources particular to one organization that this person can
	 * open, for its hub's Resources tab (AudienceList::forOrg() has the rule).
	 *
	 * @return WP_Post[]
	 */
	public function forOrg( WP_User $user, int $orgId ): array {
		return AudienceList::forOrg( $user, $orgId, $this->visibleTo( $user ), self::KEYS, [ Reach::class, 'resourceOrgs' ] );
	}
}
