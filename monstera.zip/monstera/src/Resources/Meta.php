<?php
declare(strict_types=1);

namespace Monstera\Resources;

defined( 'ABSPATH' ) || exit;

/**
 * A resource's meta: its kind, the one sentence under its title, where it
 * leads (a link's URL, a file's Media Library attachment; a guide's body is
 * the post content), and the audience it reaches. With nothing chosen a
 * resource reaches every member, the rule the forms library had
 * (product.md, Audience model).
 */
final class Meta {

	public const KIND_LINK  = 'link';
	public const KIND_FILE  = 'file';
	public const KIND_GUIDE = 'guide';
	public const KINDS      = [ self::KIND_LINK, self::KIND_FILE, self::KIND_GUIDE ];

	public const KEY_KIND               = 'monstera_resource_kind';
	public const KEY_DESCRIPTION        = 'monstera_resource_description';
	public const KEY_FILE_ID            = 'monstera_resource_file_id';
	public const KEY_EXTERNAL_URL       = 'monstera_resource_external_url';
	public const KEY_ROLES              = 'monstera_resource_allowed_roles';
	public const KEY_ORGS               = 'monstera_resource_allowed_orgs';
	public const KEY_STANDALONE_MEMBERS = 'monstera_resource_allowed_standalone_members';
	public const KEY_SUBGROUPS          = 'monstera_resource_allowed_subgroups';
	/** Set once monstera/resource_published has fired, so a second publish after a draft does not fire it again. */
	public const KEY_PUBLISHED_NOTIFIED = 'monstera_resource_published_notified';

	/** The resource's kind, a link when none was ever written. */
	public static function kindOf( int $resourceId ): string {
		$kind = (string) get_post_meta( $resourceId, self::KEY_KIND, true );
		return in_array( $kind, self::KINDS, true ) ? $kind : self::KIND_LINK;
	}

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_PUBLISHED_NOTIFIED,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => false,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_KIND,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::KIND_LINK,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => in_array( $v, self::KINDS, true ) ? $v : self::KIND_LINK,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_DESCRIPTION,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'wp_kses_post',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_FILE_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_EXTERNAL_URL,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'esc_url_raw',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ROLES,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => array_map( 'sanitize_key', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ORGS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBERS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SUBGROUPS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);
	}
}
