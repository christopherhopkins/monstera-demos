<?php
declare(strict_types=1);

namespace Monstera\Resources;

use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A resource's file: a Media Library upload (the sensitivity decision,
 * product.md), so what the site's uploader allows is what a resource may
 * hold, at the site's upload limit (Forms-and-resources track, FR2).
 * `monstera/resource_file_types` narrows the types to a map of extension
 * to mime, `monstera/resource_file_max_bytes` the size.
 */
final class Files {

	/** The site's upload limit, unless the filter lowers it. */
	public static function maxBytes(): int {
		$limit = (int) wp_max_upload_size();
		return max( 1, (int) apply_filters( Hooks::FILTER_RESOURCE_FILE_MAX_BYTES, $limit ) );
	}

	/**
	 * The types a resource may hold, as wp_get_mime_types() maps them, or
	 * null for the site's own: wp_check_filetype_and_ext() then decides.
	 *
	 * @return array<string, string>|null
	 */
	public static function types(): ?array {
		$types = apply_filters( Hooks::FILTER_RESOURCE_FILE_TYPES, null );
		return is_array( $types ) && $types ? $types : null;
	}

	/**
	 * The type an upload really is, checked against its name and contents
	 * and the site's (or the filter's) list, or '' when it is not one the
	 * site stores.
	 *
	 * @param array{name?:string, tmp_name?:string} $upload
	 */
	public static function checkedType( array $upload ): string {
		$check = wp_check_filetype_and_ext( (string) ( $upload['tmp_name'] ?? '' ), (string) ( $upload['name'] ?? '' ), self::types() );
		return ( $check['ext'] && $check['type'] ) ? (string) $check['type'] : '';
	}

	/**
	 * Why an upload cannot be the resource's file, in words for the form, or null.
	 *
	 * @param array<string, mixed>|null $upload One entry of the request's files.
	 */
	public static function refusal( ?array $upload ): ?string {
		if ( ! $upload || empty( $upload['tmp_name'] ) || ! empty( $upload['error'] ) || ! is_file( (string) $upload['tmp_name'] ) ) {
			return __( 'Choose a file to upload.', 'monstera' );
		}
		if ( (int) ( $upload['size'] ?? 0 ) > self::maxBytes() ) {
			/* translators: %s: the largest file allowed, e.g. "64 MB" */
			return sprintf( __( 'That file is over %s. Choose a smaller one.', 'monstera' ), size_format( self::maxBytes() ) );
		}
		if ( '' === self::checkedType( $upload ) ) {
			return __( 'That kind of file cannot be attached: it is not one this site allows.', 'monstera' );
		}
		return null;
	}

	/**
	 * The extensions a file picker offers, for its accept attribute: '' for
	 * any, when the site's own list applies.
	 */
	public static function accept(): string {
		$types = self::types();
		if ( null === $types ) {
			return '';
		}
		$extensions = [];
		foreach ( array_keys( $types ) as $pattern ) {
			foreach ( explode( '|', (string) $pattern ) as $extension ) {
				$extensions[] = '.' . $extension;
			}
		}
		return implode( ',', $extensions );
	}

	/**
	 * The attachments of the file resources among these, read together
	 * (their posts and their meta, two queries) before each row asks for its
	 * path and address, so a list of twelve files costs what one of six does
	 * (Forms-and-resources track, NFR Query cost).
	 *
	 * @param \WP_Post[] $resources
	 */
	public static function prime( array $resources ): void {
		$ids = [];
		foreach ( $resources as $resource ) {
			if ( Meta::KIND_FILE === Meta::kindOf( (int) $resource->ID ) ) {
				$ids[] = (int) get_post_meta( (int) $resource->ID, Meta::KEY_FILE_ID, true );
			}
		}
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		if ( $ids ) {
			_prime_post_caches( $ids, false, true );
		}
	}

	/**
	 * The attached file's facts for a row, a table cell or the detail: its
	 * name, its kind in capitals ("PDF", "XLSX"), its size, and the two as
	 * one label ("PDF · 420 KB"). Null with no file.
	 *
	 * @return array{id: int, name: string, ext: string, size: int, label: string}|null
	 */
	public static function facts( int $attachmentId ): ?array {
		$path = $attachmentId > 0 ? get_attached_file( $attachmentId ) : false;
		if ( ! $path ) {
			return null;
		}
		$ext  = strtoupper( (string) pathinfo( $path, PATHINFO_EXTENSION ) );
		$size = is_file( $path ) ? (int) filesize( $path ) : 0;
		return [
			'id'    => $attachmentId,
			'name'  => wp_basename( $path ),
			'ext'   => $ext,
			'size'  => $size,
			'label' => implode( ' · ', array_filter( [ $ext, $size ? (string) size_format( $size ) : '' ] ) ),
		];
	}
}
