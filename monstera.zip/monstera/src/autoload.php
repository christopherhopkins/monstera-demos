<?php
/**
 * PSR-4 autoloader for the Monstera plugin.
 *
 * Maps the Monstera\ namespace to the src/ directory.
 * A Composer-generated autoloader would replace this in production builds.
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

spl_autoload_register(
	static function ( string $className ): void {
		$prefix = 'Monstera\\';
		if ( ! str_starts_with( $className, $prefix ) ) {
			return;
		}

		$relative = substr( $className, strlen( $prefix ) );
		$path     = MONSTERA_DIR . 'src/' . str_replace( '\\', '/', $relative ) . '.php';

		if ( is_file( $path ) ) {
			require_once $path;
		}
	}
);

if ( is_file( MONSTERA_DIR . 'vendor/autoload.php' ) ) {
	require_once MONSTERA_DIR . 'vendor/autoload.php';
}
