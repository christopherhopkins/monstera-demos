<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

final class ActivityPurge {

	/**
	 * @return array<string, int>
	 */
	public static function run(): array {
		$days = (int) apply_filters( Hooks::FILTER_RETENTION_DAYS, (int) get_option( 'monstera_retention_days', 90 ) );
		$days = max( 7, $days );

		global $wpdb;
		$table  = Schema::tableName( Schema::TABLE_ACTIVITY_LOG );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		$removed = (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE occurred_at < %s', $table, $cutoff ) );

		do_action( Hooks::SYNC_TASK_COMPLETED, 'purge', compact( 'removed' ) );
		return compact( 'removed' );
	}
}
