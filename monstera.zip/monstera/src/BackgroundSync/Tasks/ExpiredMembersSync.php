<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Core\Hooks;
use Monstera\Core\SiteDay;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

/**
 * Flags standalone members whose individual `membership_expires` date has
 * passed (plus optional grace period) with the `monstera_member_suspended`
 * user meta, and fires Hooks::MEMBER_SUSPENDED, or Hooks::MEMBER_REACTIVATED
 * once the date has moved on again.
 *
 * Access does not wait for this run or read the flag: the guard, the
 * visibility engine and the downloader read the date itself, as they read
 * an organization's (AccessControl\PortalGuard::ownMembershipExpired()), so
 * a member is paused from the site's day after their last and restored the
 * moment a renewal or the team moves the date.
 *
 * Org members inherit their org's status — they are handled by StatusSync.
 * This task only targets `monstera_member_standalone` accounts.
 */
final class ExpiredMembersSync {

	public const META_KEY_SUSPENDED = 'monstera_member_suspended';

	/**
	 * @return array<string, int>
	 */
	public static function run(): array {
		$grace = (int) get_option( 'monstera_auto_suspend_grace_days', 0 );
		$today = SiteDay::today();

		$users = get_users(
			[
				'role__in' => [ 'monstera_member_standalone' ],
				'meta_key' => UserMeta::KEY_MEMBERSHIP_EXPIRES, // phpcs:ignore WordPress.DB.SlowDBQuery -- expiry lives in user meta by design; daily cron over a bounded member set.
			'fields'       => 'all',
			'number'       => -1,
			]
		);

		$suspended   = 0;
		$reactivated = 0;

		foreach ( $users as $user ) {
			$expiresRaw  = (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );
			$since       = SiteDay::daysSince( $expiresRaw, $today );
			$isSuspended = (bool) get_user_meta( $user->ID, self::META_KEY_SUSPENDED, true );

			// The site's days since their last, as the guard counts them (Core\SiteDay).
			if ( null !== $since && $since > $grace && ! $isSuspended ) {
				update_user_meta( $user->ID, self::META_KEY_SUSPENDED, 1 );
				do_action( Hooks::MEMBER_SUSPENDED, $user->ID, $expiresRaw );
				++$suspended;
			} elseif ( null !== $since && $since <= $grace && $isSuspended ) {
				// Renewal happened — clear the flag.
				delete_user_meta( $user->ID, self::META_KEY_SUSPENDED );
				do_action( Hooks::MEMBER_REACTIVATED, $user->ID );
				++$reactivated;
			}
		}

		do_action( Hooks::SYNC_TASK_COMPLETED, 'expired_members', compact( 'suspended', 'reactivated' ) );
		return compact( 'suspended', 'reactivated' );
	}
}
