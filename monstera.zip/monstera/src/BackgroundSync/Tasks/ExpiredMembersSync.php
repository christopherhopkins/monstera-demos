<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-suspends standalone members whose individual `membership_expires`
 * date has passed (plus optional grace period). Sets a `monstera_member_suspended`
 * user-meta flag the Visibility engine and the secure-file Downloader can use
 * to gate content and downloads.
 *
 * Org members inherit their org's status — they are handled by StatusSync.
 * This task only targets `monstera_member_standalone` accounts.
 */
final class ExpiredMembersSync {

	public const META_KEY_SUSPENDED = 'monstera_member_suspended';

	/**
	 * @return array<string, int>
	 */
	public static function run(): array {
		$grace  = (int) get_option( 'monstera_auto_suspend_grace_days', 0 );
		$cutoff = strtotime( 'today' ) - ( $grace * DAY_IN_SECONDS );

		$users = get_users(
			[
				'role__in' => [ 'monstera_member_standalone' ],
				'meta_key' => UserMeta::KEY_MEMBERSHIP_EXPIRES, // phpcs:ignore WordPress.DB.SlowDBQuery -- expiry lives in user meta by design; daily cron over a bounded member set.
			'fields'       => 'all',
			'number'       => -1,
			]
		);

		$suspended   = 0;
		$reactivated = 0;

		foreach ( $users as $user ) {
			$expiresRaw  = (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );
			$expiresTs   = $expiresRaw ? strtotime( $expiresRaw ) : 0;
			$isSuspended = (bool) get_user_meta( $user->ID, self::META_KEY_SUSPENDED, true );

			if ( $expiresTs && $expiresTs < $cutoff && ! $isSuspended ) {
				update_user_meta( $user->ID, self::META_KEY_SUSPENDED, 1 );
				do_action( Hooks::MEMBER_SUSPENDED, $user->ID, $expiresRaw );
				++$suspended;
			} elseif ( $expiresTs && $expiresTs >= $cutoff && $isSuspended ) {
				// Renewal happened — clear the flag.
				delete_user_meta( $user->ID, self::META_KEY_SUSPENDED );
				do_action( Hooks::MEMBER_REACTIVATED, $user->ID );
				++$reactivated;
			}
		}

		do_action( Hooks::SYNC_TASK_COMPLETED, 'expired_members', compact( 'suspended', 'reactivated' ) );
		return compact( 'suspended', 'reactivated' );
	}
}
