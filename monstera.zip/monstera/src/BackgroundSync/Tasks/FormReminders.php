<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Modules;
use Monstera\Core\SiteDay;
use Monstera\Forms\Meta;
use Monstera\Forms\PostType;
use Monstera\Forms\Repository;
use Monstera\Forms\Submissions;
use Monstera\Notifications\FormNotifier;
use Monstera\Notifications\TemplateEngine;
use Monstera\Organizations\Roster;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * The daily form reminders (Forms-and-resources track, FR9). Seven of the
 * site's days before a form's due day, and one, each member the form
 * reaches who has not sent one is emailed once, while the form accepts and
 * its reminders are on. Each reminder is a notification-log row naming its
 * window and the due day it was for, so a day the run skipped (Expiration
 * has the clock's reason) sends the day after and never twice, a due day
 * moved on gets its own reminders, a send wp_mail() refused is tried again
 * while the window lasts, and nothing goes once the due day has passed:
 * the form reads Closed then.
 */
final class FormReminders {

	/** The site's days before the due day on which a reminder goes. */
	public const WINDOWS = [ 7, 1 ];

	/** The cron callback: run() for its side, nothing for the hook. */
	public static function dispatch(): void {
		self::run();
	}

	/**
	 * @param string $today The site's today as Y-m-d; read from the clock when '' (a test walks the days).
	 * @return array{forms: int, sent: int}
	 */
	public static function run( string $today = '' ): array {
		$result = [
			'forms' => 0,
			'sent'  => 0,
		];
		if ( ! Modules::isActive( Modules::FORMS ) ) {
			return $result;
		}
		$today    = '' !== $today ? $today : SiteDay::today();
		$notifier = new FormNotifier( new TemplateEngine() );
		foreach ( self::dueForms() as $formId ) {
			$window = self::window( SiteDay::daysSince( Meta::dueOn( $formId ), $today ) );
			if ( 0 === $window ) {
				continue;
			}
			++$result['forms'];
			foreach ( self::awaiting( $formId ) as $user ) {
				if ( self::reminded( $formId, (int) $user->ID, $window ) ) {
					continue;
				}
				$delivered = $notifier->sendDueReminder( $user, $formId );
				if ( null === $delivered ) {
					continue;
				}
				self::record( $formId, (int) $user->ID, $window, $delivered );
				$result['sent'] += $delivered ? 1 : 0;
			}
		}
		do_action( Hooks::SYNC_TASK_COMPLETED, 'form_reminders', $result );
		return $result;
	}

	/**
	 * The window a day falls in, by the site's days since the due day
	 * (negative before it): 7 on the seventh day before or the sixth, 1 on
	 * the day before or the day itself, 0 for none. Nothing after the due
	 * day: a form past due accepts nothing.
	 */
	public static function window( ?int $since ): int {
		if ( null === $since || $since > 0 ) {
			return 0;
		}
		foreach ( self::WINDOWS as $days ) {
			if ( -$since === $days || -$since === $days - 1 ) {
				return $days;
			}
		}
		return 0;
	}

	/**
	 * The published built forms with a due day whose reminders are on and
	 * that still accept.
	 *
	 * @return list<int>
	 */
	private static function dueForms(): array {
		$ids = get_posts(
			[
				'post_type'      => PostType::SLUG,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => Meta::KEY_DUE_ON, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- a daily job over the forms with a due day.
				'meta_compare'   => '!=',
				'meta_value'     => '', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
			]
		);
		$out = [];
		foreach ( array_map( 'intval', (array) $ids ) as $formId ) {
			if ( Meta::KIND_BUILT === Meta::kindOf( $formId ) && '' !== Meta::dueOn( $formId ) && Meta::remind( $formId ) && Meta::accepting( $formId ) ) {
				$out[] = $formId;
			}
		}
		return $out;
	}

	/**
	 * The members the form reaches who have not sent it: its audience's
	 * candidates (the members of the organizations it names and the people
	 * it names, or every client account for a form for everyone), each
	 * asked of the one list the portal shows (Forms\Repository::visibleTo()),
	 * so nobody is reminded of a form they cannot open.
	 *
	 * @return list<WP_User>
	 */
	private static function awaiting( int $formId ): array {
		$roles  = [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ];
		$orgIds = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $formId, Meta::KEY_ORGS, true ) ) ) );
		$named  = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $formId, Meta::KEY_STANDALONE_MEMBERS, true ) ) ) );
		if ( ! $orgIds && ! $named ) {
			$candidates = get_users(
				[
					'role__in' => $roles,
					'fields'   => 'all',
					'number'   => -1,
				]
			);
		} else {
			$ids = $named;
			Roster::primeOrgs( $orgIds );
			foreach ( $orgIds as $orgId ) {
				$ids = array_merge( $ids, Roster::memberIds( $orgId ) );
			}
			$ids        = array_values( array_unique( array_map( 'intval', $ids ) ) );
			$candidates = $ids ? get_users(
				[
					'include'  => $ids,
					'role__in' => $roles,
					'fields'   => 'all',
					'number'   => -1,
				]
			) : [];
		}
		$repository = new Repository();
		$out        = [];
		foreach ( $candidates as $user ) {
			if ( ! $user instanceof WP_User || '' === $user->user_email || Submissions::hasSent( $formId, (int) $user->ID ) ) {
				continue;
			}
			foreach ( $repository->visibleTo( $user ) as $post ) {
				if ( (int) $post->ID === $formId ) {
					$out[] = $user;
					break;
				}
			}
		}
		return $out;
	}

	/** Whether this member was already sent this form's reminder for this window of this due day. */
	private static function reminded( int $formId, int $userId, int $window ): bool {
		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live check against the log it writes.
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE event_type = %s AND member_id = %d AND content_id = %d AND delivered = 1 AND meta = %s',
				Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
				TemplateEngine::EVENT_FORM_DUE_REMINDER,
				$userId,
				$formId,
				self::meta( $formId, $window )
			)
		) > 0;
	}

	/** One row per attempt, with wp_mail()'s answer; the window and the due day in the meta are the once-check's key. */
	private static function record( int $formId, int $userId, int $window, bool $delivered ): void {
		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
			[
				'member_id'  => $userId,
				'content_id' => $formId,
				'event_type' => TemplateEngine::EVENT_FORM_DUE_REMINDER,
				'channel'    => 'email',
				'delivered'  => $delivered ? 1 : 0,
				'sent_at'    => current_time( 'mysql', true ),
				'meta'       => self::meta( $formId, $window ),
			],
			[ '%d', '%d', '%s', '%s', '%d', '%s', '%s' ]
		);
	}

	/** The row's meta: `{"window":7,"due_on":"2027-03-31"}`, written and matched as one string. */
	private static function meta( int $formId, int $window ): string {
		return '{"window":' . $window . ',"due_on":' . wp_json_encode( Meta::dueOn( $formId ) ) . '}';
	}
}
