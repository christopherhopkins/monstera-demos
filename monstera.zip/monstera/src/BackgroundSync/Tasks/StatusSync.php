<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Core\Hooks;
use Monstera\Core\SiteDay;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-suspends orgs whose membership expired more than the grace period.
 * Default grace: 0 days (immediate). Configurable via the
 * monstera_auto_suspend_grace_days option.
 */
final class StatusSync {

	/**
	 * @return array<string, int>
	 */
	public static function run(): array {
		$grace     = (int) get_option( 'monstera_auto_suspend_grace_days', 0 );
		$repo      = new OrgRepository();
		$today     = SiteDay::today();
		$suspended = 0;

		foreach ( $repo->all() as $org ) {
			$status = $repo->status( $org->ID );
			// The site's days since its last, as the guard counts them (Core\SiteDay).
			$since = SiteDay::daysSince( (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true ), $today );
			if ( OrgMeta::STATUS_ACTIVE === $status && null !== $since && $since > $grace && $repo->setStatus( $org->ID, OrgMeta::STATUS_SUSPENDED ) ) {
				++$suspended;
			}
		}

		do_action( Hooks::SYNC_TASK_COMPLETED, 'status', compact( 'suspended' ) );
		return compact( 'suspended' );
	}
}
