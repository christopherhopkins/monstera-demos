<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Core\Hooks;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-suspends orgs whose membership expired more than the grace period.
 * Default grace: 0 days (immediate). Configurable via the
 * monstera_auto_suspend_grace_days option.
 */
final class StatusSync {

	/**
	 * @return array<string, int>
	 */
	public static function run(): array {
		$grace     = (int) get_option( 'monstera_auto_suspend_grace_days', 0 );
		$now       = strtotime( 'today' );
		$cutoff    = $now - ( $grace * DAY_IN_SECONDS );
		$repo      = new OrgRepository();
		$suspended = 0;

		foreach ( $repo->all() as $org ) {
			$status  = $repo->status( $org->ID );
			$expires = strtotime( (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true ) );
			if ( OrgMeta::STATUS_ACTIVE === $status && $expires && $expires < $cutoff && $repo->setStatus( $org->ID, OrgMeta::STATUS_SUSPENDED ) ) {
				++$suspended;
			}
		}

		do_action( Hooks::SYNC_TASK_COMPLETED, 'status', compact( 'suspended' ) );
		return compact( 'suspended' );
	}
}
