<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync\Tasks;

use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\SecureFiles;
use Monstera\Core\Database\Schema;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Organizations\Roster;
use Monstera\Core\Hooks;
use Monstera\Projects\Discovery;
use Monstera\Projects\PostType as ProjectPostType;
use WP_Query;

defined( 'ABSPATH' ) || exit;

/**
 * Reconciles content↔org bidirectional relationships and sweeps orphan rows
 * out of the custom tables.
 *
 * Walks every content item, ensures each referenced org still exists, and
 * removes references to deleted orgs. (We don't store a reverse-lookup on
 * the org side — counts are computed live — so "self-heal" here means
 * dropping dangling references and orphan content items.) Then every row in
 * the relationship tables that names a post or user which no longer exists
 * is removed; Core\Database\Cleanup does the same at delete time, and this
 * pass catches whatever predates it or bypassed the hooks. Trashed posts
 * still exist, so their rows stay. The memberships table is swept by the
 * Roster, which also derives again the role of each person who lost a row.
 * The Roster's sweep has a second pass, for an account that stopped being
 * staff without WordPress saying so: it ends each assignment the account
 * still holds (monstera/staff_unassigned fires and the sentence is filed,
 * with nobody to credit when cron runs it), clears the projects it leads
 * and gives back the client role a membership of its implies. Those
 * assignments are counted in rows_removed with the orphan rows.
 */
final class RelationshipSync {

	private const REF_POST = 'post';
	private const REF_USER = 'user';

	/**
	 * Which columns name a post or a user, per table. The memberships table
	 * is not here: a row of it is what a person's role was derived from, so
	 * the Roster sweeps it (Roster::sweepOrphans()), and a staff row of it
	 * can also outlive its person's place on the team, which no column here
	 * could say.
	 *
	 * @var array<string, array<string, string>>  table key => [ column => post|user ]
	 */
	private const REFERENCES = [
		Schema::TABLE_SUBGROUP_MEMBERS  => [
			'subgroup_id' => self::REF_POST,
			'member_id'   => self::REF_USER,
		],
		Schema::TABLE_CONTENT_SUBGROUPS => [
			'content_id'  => self::REF_POST,
			'subgroup_id' => self::REF_POST,
		],
		Schema::TABLE_PROJECT_MEMBERS   => [
			'project_id' => self::REF_POST,
			'member_id'  => self::REF_USER,
		],
		Schema::TABLE_CONTENT_PROJECTS  => [
			'content_id' => self::REF_POST,
			'project_id' => self::REF_POST,
		],
		Schema::TABLE_PROJECT_INTAKE    => [
			'project_id' => self::REF_POST,
		],
		Schema::TABLE_ALERT_DISMISSALS  => [
			'alert_id'  => self::REF_POST,
			'member_id' => self::REF_USER,
		],
	];

	/**
	 * @return array<string, int>
	 */
	public static function run(): array {
		$healed   = 0;
		$orphans  = 0;
		$existing = self::existingOrgIds();

		$q = new WP_Query(
			[
				'post_type'      => ContentPostType::SLUG,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);

		foreach ( $q->posts as $contentId ) {
			$current = (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true );
			$current = array_map( 'intval', $current );
			$cleaned = array_values( array_intersect( $current, $existing ) );

			if ( $cleaned !== $current ) {
				update_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, $cleaned );
				++$healed;
			}
			if ( ! $cleaned ) {
				++$orphans;
			}
		}

		// Memberships and staff assignments alike outlive neither their person
		// nor their organization, and an assignment does not outlive its
		// person's place on the team; the Roster ends them, counted with the rest.
		$rows_removed = self::sweepOrphanRows() + Roster::sweepOrphans() + self::sweepOrphanSecureFiles();

		do_action( Hooks::SYNC_TASK_COMPLETED, 'relationship', compact( 'healed', 'orphans', 'rows_removed' ) );
		return compact( 'healed', 'orphans', 'rows_removed' );
	}

	/**
	 * One DELETE per referencing column: rows whose post or user id has no
	 * row in wp_posts / wp_users any more.
	 *
	 * @return int Rows removed.
	 */
	private static function sweepOrphanRows(): int {
		global $wpdb;
		$removed = 0;
		foreach ( self::REFERENCES as $table => $columns ) {
			foreach ( $columns as $column => $kind ) {
				$parent   = self::REF_USER === $kind ? $wpdb->users : $wpdb->posts;
				$deleted  = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- set-based sweep over a custom table; no API covers it.
					$wpdb->prepare(
						'DELETE t FROM %i AS t LEFT JOIN %i AS p ON p.ID = t.%i WHERE p.ID IS NULL',
						Schema::tableName( $table ),
						$parent,
						$column
					)
				);
				$removed += max( 0, (int) $deleted );
			}
		}
		return $removed;
	}

	/**
	 * Secure files whose owner is gone go through SecureFiles::delete() so
	 * the file on disk is unlinked with its row: a content item's file once
	 * the item no longer exists, an intake file once its project no longer
	 * exists or no longer asks it as a file question, a support file once
	 * its request no longer exists. Neither an intake nor a support file has
	 * a content item (content_id 0), so neither is read as orphaned content,
	 * and a support file names no project, so it is not read as an intake
	 * file either. A file that names no owner at all goes.
	 *
	 * @return int Rows removed.
	 */
	private static function sweepOrphanSecureFiles(): int {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SECURE_FILES );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- finding orphan rows in a custom table.
		$ids     = array_map(
			'intval',
			(array) $wpdb->get_col(
				$wpdb->prepare(
					'SELECT f.id FROM %i AS f LEFT JOIN %i AS p ON p.ID = f.content_id WHERE f.content_id > 0 AND p.ID IS NULL',
					$table,
					$wpdb->posts
				)
			)
		);
		$intake  = (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT f.id, f.project_id, f.field_key, p.ID AS live FROM %i AS f LEFT JOIN %i AS p ON p.ID = f.project_id AND p.post_type = %s WHERE f.content_id = 0 AND f.support_request_id IS NULL',
				$table,
				$wpdb->posts,
				ProjectPostType::SLUG
			),
			ARRAY_A
		);
		$support = array_map(
			'intval',
			(array) $wpdb->get_col(
				$wpdb->prepare(
					'SELECT f.id FROM %i AS f LEFT JOIN %i AS r ON r.id = f.support_request_id WHERE f.content_id = 0 AND f.support_request_id IS NOT NULL AND r.id IS NULL',
					$table,
					Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS )
				)
			)
		);
		// phpcs:enable
		$ids   = array_merge( $ids, $support );
		$asked = [];
		foreach ( $intake as $row ) {
			$projectId = (int) $row['live'];
			if ( $projectId > 0 ) {
				$asked[ $projectId ] ??= Discovery::fileKeys( $projectId );
				if ( in_array( (string) $row['field_key'], $asked[ $projectId ], true ) ) {
					continue;
				}
			}
			$ids[] = (int) $row['id'];
		}
		$files = new SecureFiles();
		foreach ( $ids as $fileId ) {
			$files->delete( $fileId );
		}
		return count( $ids );
	}

	/**
	 * Every organization that exists, whatever its status. An organization
	 * in the trash still exists and comes back with everything that named
	 * it, so its references are not the sweep's to strip: with only the
	 * published, the drafts and the private listed here, a night in the
	 * trash took the organization off every item it was shared with, and
	 * restoring it brought nothing back. A pending or a scheduled
	 * organization is as much there as a draft.
	 *
	 * @return int[]
	 */
	private static function existingOrgIds(): array {
		$q = new WP_Query(
			[
				'post_type'      => OrgPostType::SLUG,
				'post_status'    => [ 'publish', 'draft', 'pending', 'future', 'private', 'trash' ],
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);
		return array_map( 'intval', $q->posts );
	}
}
