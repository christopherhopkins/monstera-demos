<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync;

/**
 * Single source of truth for Monstera's WP-Cron events.
 *
 * Activator schedules these; Deactivator and uninstall.php clear them. Keeping
 * the hook list in one place prevents drift — the kind of bug where a hook is
 * scheduled on activation but a separate, hand-maintained clear list misses it,
 * leaving the event in WP's cron array firing forever after the plugin is gone.
 *
 * Deliberately dependency-free (no WP bootstrap, no plugin constants) so
 * uninstall.php — which runs before the plugin's autoloader is registered —
 * can `require` this file directly and reuse the same list.
 */
final class Cron {

	// The cron hooks, named once for everything that schedules or listens.
	public const DAILY_SYNC              = 'monstera_daily_sync';
	public const DAILY_EXPIRATION        = 'monstera_daily_expiration';
	public const DAILY_MEMBER_EXPIRATION = 'monstera_daily_member_expiration';
	public const DAILY_STATUS            = 'monstera_daily_status';
	public const DAILY_PURGE             = 'monstera_daily_purge';

	/**
	 * Map of cron hook => recurrence. The recurrence string must be a key
	 * registered with WP (daily/hourly/twicedaily, or a custom schedule).
	 *
	 * @var array<string, string>
	 */
	public const EVENTS = [
		self::DAILY_SYNC              => 'daily',
		self::DAILY_EXPIRATION        => 'daily',
		self::DAILY_MEMBER_EXPIRATION => 'daily',
		self::DAILY_STATUS            => 'daily',
		self::DAILY_PURGE             => 'daily',
	];

	/**
	 * Schedule any events that aren't already scheduled. Idempotent — safe to
	 * call on every activation.
	 */
	public static function schedule(): void {
		foreach ( self::EVENTS as $hook => $recurrence ) {
			if ( ! wp_next_scheduled( $hook ) ) {
				wp_schedule_event( time() + 60, $recurrence, $hook );
			}
		}
	}

	/**
	 * Clear every scheduled occurrence of every Monstera cron event.
	 * `wp_clear_scheduled_hook` removes ALL occurrences, not just the next one.
	 */
	public static function clear(): void {
		foreach ( array_keys( self::EVENTS ) as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
		// The email queue's one-off events, whatever post each names
		// (Notifications\Dispatcher::QUEUE_HOOK; named here because uninstall
		// loads this file alone).
		wp_unschedule_hook( 'monstera_email_queue' );
	}
}
