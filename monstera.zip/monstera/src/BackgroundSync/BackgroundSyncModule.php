<?php
declare(strict_types=1);

namespace Monstera\BackgroundSync;

use Monstera\Core\Hooks;
use Monstera\Core\Module;
use Monstera\Core\SecureStorage;

defined( 'ABSPATH' ) || exit;

final class BackgroundSyncModule implements Module {

	public function slug(): string {
		return 'background-sync';
	}

	public function boot(): void {
		// Wrapped so the action callbacks return nothing; the result arrays feed runAll() and WP-CLI.
		add_action(
			Cron::DAILY_SYNC,
			static function (): void {
				Tasks\RelationshipSync::run();
				self::afterDailySync();
			}
		);
		add_action(
			Cron::DAILY_STATUS,
			static function (): void {
				Tasks\StatusSync::run();
			}
		);
		add_action(
			Cron::DAILY_MEMBER_EXPIRATION,
			static function (): void {
				Tasks\ExpiredMembersSync::run();
			}
		);
		add_action(
			Cron::DAILY_PURGE,
			static function (): void {
				Tasks\ActivityPurge::run();
			}
		);
	}

	public function registerPostTypes(): void {}

	/** The option holding the daily sync's last run (a timestamp). */
	public const LAST_RUN_OPTION = 'monstera_daily_sync_last';

	/**
	 * What the dashboard's health rows read: when the daily sync last ran,
	 * and how much the secure folder holds (measured here, once a day).
	 */
	public static function afterDailySync(): void {
		SecureStorage::measure();
		update_option( self::LAST_RUN_OPTION, time(), false );
	}

	/**
	 * @return array<string, array<string, int>>
	 */
	public static function runAll(): array {
		$results = [
			'relationship'    => Tasks\RelationshipSync::run(),
			'status'          => Tasks\StatusSync::run(),
			'expired_members' => Tasks\ExpiredMembersSync::run(),
			'purge'           => Tasks\ActivityPurge::run(),
		];
		self::afterDailySync();
		do_action( Hooks::SYNC_RUN, $results );
		return $results;
	}
}
