<?php
/**
 * Plugin orchestrator.
 *
 * Owns the container, registers every module, and triggers boot().
 * Modules are responsible for their own hooks; this class only wires
 * dependencies and decides what gets loaded.
 */

declare(strict_types=1);

namespace Monstera;

use Monstera\AccessControl\AccessControlModule;
use Monstera\Admin\AdminModule;
use Monstera\Alerts\AlertsModule;
use Monstera\BackgroundSync\BackgroundSyncModule;
use Monstera\Cli\CliModule;
use Monstera\Content\ContentModule;
use Monstera\Core\Assets;
use Monstera\Core\Hooks;
use Monstera\Core\Module;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\FormsModule;
use Monstera\Integrations\IntegrationsModule;
use Monstera\Members\MembersModule;
use Monstera\Notifications\NotificationsModule;
use Monstera\Organizations\OrganizationsModule;
use Monstera\Portal\PortalModule;
use Monstera\Projects\ProjectsModule;
use Monstera\Reporting\ReportingModule;
use Monstera\Rest\RestModule;
use Monstera\Subgroups\SubgroupsModule;
use Monstera\Support\SupportModule;

final class Plugin {

	private static ?Plugin $instance = null;
	private Container $container;
	private bool $booted = false;

	/** @var Module[] */
	private array $modules = [];

	private function __construct() {
		$this->container = new Container();
	}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->registerCoreServices();
		}
		return self::$instance;
	}

	public function container(): Container {
		return $this->container;
	}

	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		$this->loadTextdomain();
		$this->registerModules();

		foreach ( $this->modules as $module ) {
			$module->boot();
		}

		// Rows in the custom tables that reference a permanently deleted post or
		// user go with it (see Core\Database\Cleanup).
		Core\Database\Cleanup::register();

		// Catch a code update that bumped the DB version: on the first request
		// of any kind, since the portal writes to the tables too.
		add_action( 'init', [ Core\Database\Schema::class, 'maybeUpgrade' ], 1 );
		// Same self-heal for role capabilities (e.g. a new delegated-author cap).
		add_action( 'admin_init', [ Core\Capabilities::class, 'maybeUpgrade' ] );

		// Self-healing rewrite flush. The activation hook calls Routing::flush(),
		// but that doesn't always persist under wp-now's SQLite. We re-flush
		// once per plugin version on the first init after boot.
		add_action(
			'init',
			static function (): void {
				if ( get_option( 'monstera_rewrites_flushed_for' ) === Core\Routing::rewriteStamp() ) {
					return;
				}
				flush_rewrite_rules( false );
				update_option( 'monstera_rewrites_flushed_for', Core\Routing::rewriteStamp() );
			},
			999
		);

		// Dev-mode demo seeding. Triggered explicitly via ?monstera-seed=1
		// (admin only) or the `wp monstera seed` WP-CLI command. We deliberately
		// don't auto-run on init so a broken seed can never break the site —
		// you have to ask for it.
		if ( defined( 'MONSTERA_DEV_MODE' ) && MONSTERA_DEV_MODE ) {
			// The monstera-demo companion (demo/) carries the seed and the demo
			// brief. A demo site installs it as a plugin; a dev-mode site loads
			// it from here, before `monstera/booted` fires below.
			self::loadCompanion();
			add_action( 'init', [ self::class, 'maybeRunDevSeedViaQueryParam' ], 99 );
			// No-auth diagnostic endpoint, dev-mode only. Visit ?monstera-diag=1
			// to dump user/role/cap state for debugging access issues.
			add_action( 'init', [ self::class, 'maybeShowDiag' ], 0 );
			// Force-login bypass for wp-now / playground environments where
			// the standard wp-login.php cookie flow doesn't stick. Visit
			// ?monstera-login-as-admin=1 to authenticate as admin directly.
			add_action( 'init', [ self::class, 'maybeForceLogin' ], 0 );
			// Manual rewrite-rules flush. Visit ?monstera-flush=1 if pretty
			// permalinks aren't routing (e.g. /wp-json/* returning homepage).
			add_action( 'init', [ self::class, 'maybeFlushRewrites' ], 0 );
		}

		$this->booted = true;
		do_action( Hooks::BOOTED, $this );
	}

	/** Where the monstera-demo companion lives inside this plugin. */
	public static function companionDir(): string {
		return MONSTERA_DIR . 'demo/';
	}

	public static function companionFile(): string {
		return self::companionDir() . 'monstera-demo.php';
	}

	/**
	 * Whether Monstera should require the companion itself: only in dev mode,
	 * only when the file is there, and never when it is already loaded as a
	 * plugin of its own (which defines MONSTERA_DEMO_DIR first).
	 */
	public static function wantsCompanion( bool $devMode, bool $alreadyLoaded, bool $fileExists ): bool {
		return $devMode && ! $alreadyLoaded && $fileExists;
	}

	private static function loadCompanion(): void {
		$wanted = self::wantsCompanion(
			defined( 'MONSTERA_DEV_MODE' ) && MONSTERA_DEV_MODE,
			defined( 'MONSTERA_DEMO_DIR' ),
			is_file( self::companionFile() )
		);
		if ( $wanted ) {
			require_once self::companionFile();
		}
	}

	/**
	 * Triggers the dev seed when a logged-in admin visits `?monstera-seed=1`.
	 * Intentionally manual: keeps the seed completely off the request path
	 * until someone asks for it, so a broken seed can never WSOD the site.
	 */
	public static function maybeRunDevSeedViaQueryParam(): void {
		if ( ! self::seedFromQueryParam() ) {
			return;
		}

		// Bounce to the admin so the seed reload doesn't keep retriggering on refresh.
		wp_safe_redirect( admin_url( 'admin.php?page=monstera&seeded=1' ) );
		exit;
	}

	/**
	 * Seeds the development dataset when the request carries `monstera-seed=1`
	 * and the visitor may manage the site or Monstera. Returns whether it did.
	 */
	public static function seedFromQueryParam(): bool {
		if ( ! isset( $_GET['monstera-seed'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
			return false;
		}
		if ( '1' !== (string) $_GET['monstera-seed'] ) { // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
			return false;
		}
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_monstera' ) ) {
			return false;
		}
		self::runDevSeed();
		return true;
	}

	/**
	 * Runs the demo seed once, writing the outcome to dev/seed.last.log so the
	 * developer can read what happened without spelunking wp-content/debug.log.
	 * Idempotent via the monstera_demo_seeded option. Always wrapped in
	 * try/catch — a seed crash never propagates.
	 */
	public static function runDevSeed( string $program = 'all' ): void {
		$log_file = self::seedLogFile();

		// The seeder lives in the monstera-demo companion (demo/), which dev
		// mode loads and a demo site installs; without it there is nothing to run.
		if ( ! class_exists( Demo\Seeder::class ) ) {
			self::writeSeedLog( $log_file, 'SKIPPED: the monstera-demo companion is not loaded, so there is no seeder.' );
			return;
		}

		// Idempotent per row, so running it again is cheap and picks up
		// fixtures added since.
		try {
			Demo\Seeder::run( $program );
			$verdict = sprintf(
				'OK: seed completed (program=%s, legacy=%s, version=%s)',
				$program,
				wp_json_encode( get_option( 'monstera_demo_seeded' ) ),
				wp_json_encode( get_option( 'monstera_demo_seed_version' ) )
			);
			self::writeSeedLog( $log_file, $verdict );
		} catch ( \Throwable $e ) {
			$msg = sprintf(
				"FAILED: %s\nFile: %s:%d\nTrace:\n%s",
				$e->getMessage(),
				$e->getFile(),
				$e->getLine(),
				$e->getTraceAsString()
			);
			self::writeSeedLog( $log_file, $msg );
			update_option( 'monstera_demo_seeded', 'failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Where the seed writes its outcome: dev/seed.last.log on a development
	 * checkout, the system temporary directory on a site without dev/ (a demo),
	 * or nowhere ('') when that directory is inside the site.
	 *
	 * @param bool|null   $hasDevDir Whether the checkout has dev/; null looks.
	 * @param string|null $tempDir   The temporary directory; null asks get_temp_dir().
	 */
	public static function seedLogFile( ?bool $hasDevDir = null, ?string $tempDir = null ): string {
		if ( $hasDevDir ?? is_dir( MONSTERA_DIR . 'dev' ) ) {
			return MONSTERA_DIR . 'dev/seed.last.log';
		}
		// Never under the web root: a failed seed writes a trace. get_temp_dir()
		// can answer inside it (WP_TEMP_DIR in wp-content, or its last resort,
		// wp-content itself), and then no log is kept.
		$dir = trailingslashit( wp_normalize_path( $tempDir ?? get_temp_dir() ) );
		foreach ( [ ABSPATH, WP_CONTENT_DIR ] as $root ) {
			if ( str_starts_with( $dir, trailingslashit( wp_normalize_path( $root ) ) ) ) {
				return '';
			}
		}
		return $dir . 'monstera-seed.last.log';
	}

	/**
	 * Dev-mode browser diagnostic. Visit /?monstera-diag=1 to dump the state
	 * we need to understand auth / cap problems. Gated by MONSTERA_DEV_MODE so
	 * it can never run in production (and the hook isn't even registered
	 * without the constant).
	 */
	public static function maybeShowDiag(): void {
		if ( ! isset( $_GET['monstera-diag'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
			return;
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- text/plain diagnostics behind MONSTERA_DEV_MODE; escaping would mangle the report.
		$line = static fn ( string $s = '' ): bool => (bool) print( $s . "\n" );

		$line( '=== Plugin/constants ===' );
		$line( 'MONSTERA_VERSION:        ' . ( defined( 'MONSTERA_VERSION' ) ? MONSTERA_VERSION : '(undefined)' ) );
		$line( 'MONSTERA_DEV_MODE:       ' . ( defined( 'MONSTERA_DEV_MODE' ) ? wp_json_encode( MONSTERA_DEV_MODE ) : '(undefined)' ) );
		$line( 'WP_DEBUG:                ' . ( defined( 'WP_DEBUG' ) ? wp_json_encode( WP_DEBUG ) : '(undefined)' ) );
		$line( 'ABSPATH:                 ' . ABSPATH );
		$line( 'WPINC:                   ' . WPINC );

		$line( '' );
		$line( '=== Site URLs ===' );
		$line( 'siteurl:                 ' . get_option( 'siteurl' ) );
		$line( 'home:                    ' . get_option( 'home' ) );
		$line( 'admin_url:               ' . admin_url() );
		$line( 'COOKIE_DOMAIN:           ' . ( defined( 'COOKIE_DOMAIN' ) ? wp_json_encode( COOKIE_DOMAIN ) : '(undefined)' ) );
		$line( 'COOKIEPATH:              ' . ( defined( 'COOKIEPATH' ) ? COOKIEPATH : '(undefined)' ) );
		$line( 'AUTH_COOKIE name:        ' . AUTH_COOKIE );
		$line( 'LOGGED_IN_COOKIE name:   ' . LOGGED_IN_COOKIE );
		$line( 'request host:            ' . ( $_SERVER['HTTP_HOST'] ?? '(unknown)' ) );
		$line( 'cookies received:        ' . ( $_COOKIE ? implode( ', ', array_keys( $_COOKIE ) ) : '(none)' ) );

		$line( '' );
		$line( '=== Admin user ===' );
		$admin = get_user_by( 'login', 'admin' );
		if ( $admin ) {
			$line( 'ID:                      ' . $admin->ID );
			$line( 'Email:                   ' . $admin->user_email );
			$line( 'Roles:                   ' . ( $admin->roles ? implode( ',', $admin->roles ) : '(NONE)' ) );
			$line( 'allcaps count:           ' . count( $admin->allcaps ) );
			$line( 'caps count:              ' . count( $admin->caps ) );
			$line( 'user_can(read):          ' . ( user_can( $admin, 'read' ) ? 'YES' : 'NO' ) );
			$line( 'user_can(manage_options):  ' . ( user_can( $admin, 'manage_options' ) ? 'YES' : 'NO' ) );
			$line( 'user_can(manage_monstera): ' . ( user_can( $admin, 'manage_monstera' ) ? 'YES' : 'NO' ) );
			$line( 'allcaps keys (first 30): ' );
			$line( '  ' . implode( ', ', array_slice( array_keys( $admin->allcaps ), 0, 30 ) ) );
		} else {
			$line( 'admin user NOT FOUND in users table' );
		}

		$line( '' );
		$line( '=== Roles ===' );
		global $wp_roles;
		if ( $wp_roles && $wp_roles->roles ) {
			foreach ( $wp_roles->roles as $name => $details ) {
				$caps = (array) ( $details['capabilities'] ?? [] );
				$line( sprintf( '%-30s  %d caps', $name, count( $caps ) ) );
			}
		} else {
			$line( '(wp_roles empty or missing — this is the bug if so)' );
		}

		$line( '' );
		$line( '=== Current user (this request) ===' );
		$cu = wp_get_current_user();
		$line( 'ID:                      ' . $cu->ID );
		$line( 'Login:                   ' . $cu->user_login );
		$line( 'Roles:                   ' . ( $cu->roles ? implode( ',', $cu->roles ) : '(NONE)' ) );
		$line( 'is_user_logged_in:       ' . ( is_user_logged_in() ? 'YES' : 'NO' ) );

		$line( '' );
		$line( '=== Active plugins ===' );
		foreach ( (array) get_option( 'active_plugins', [] ) as $p ) {
			$line( '  ' . $p );
		}

		$line( '' );
		$line( '=== Monstera options ===' );
		$line( 'monstera_version:        ' . (string) get_option( 'monstera_version' ) );
		$line( 'monstera_db_version:     ' . (string) get_option( 'monstera_db_version' ) );
		$line( 'monstera_active_modules: ' . (string) wp_json_encode( get_option( 'monstera_active_modules' ) ) );
		$line( 'monstera_demo_seeded:    ' . wp_json_encode( get_option( 'monstera_demo_seeded' ) ) );

		$line( '' );
		$line( '=== All users (first 20) ===' );
		foreach ( get_users( [ 'number' => 20 ] ) as $u ) {
			$line( sprintf( '#%-4d %-20s  %-30s  %s', $u->ID, $u->user_login, $u->user_email, implode( ',', $u->roles ) ?: '(no role)' ) );
		}

		$line( '' );
		$line( '=== Admin menu state (after firing admin_menu) ===' );
		if ( ! function_exists( 'add_menu_page' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		// Fire admin_menu so our Menu::register runs and populates $menu / $submenu.
		do_action( '_admin_menu' );
		do_action( 'admin_menu' );

		global $menu, $submenu;

		$line( 'Top-level menu items:' );
		if ( $menu ) {
			foreach ( $menu as $i => $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$title = isset( $item[0] ) ? wp_strip_all_tags( (string) $item[0] ) : '';
				$cap   = (string) ( $item[1] ?? '' );
				$slug  = (string) ( $item[2] ?? '' );
				$line( sprintf( '  [%s] cap=%s slug=%s', $title ?: '(separator)', $cap, $slug ) );
			}
		} else {
			$line( '  (empty)' );
		}

		$line( '' );
		$line( 'Submenus under monstera:' );
		if ( ! empty( $submenu['monstera'] ) ) {
			foreach ( $submenu['monstera'] as $i => $row ) {
				$title = isset( $row[0] ) ? wp_strip_all_tags( (string) $row[0] ) : '';
				$cap   = (string) ( $row[1] ?? '' );
				$slug  = (string) ( $row[2] ?? '' );
				$line( sprintf( '  %d: [%s] cap=%s slug=%s', $i, $title, $cap, $slug ) );
			}
		} else {
			$line( '  (no monstera submenus — admin_menu hook may not have run)' );
		}

		$line( '' );
		$line( '=== Seed log (dev/seed.last.log) ===' );
		$seed_log = MONSTERA_DIR . 'dev/seed.last.log';
		if ( is_file( $seed_log ) ) {
			$line( (string) file_get_contents( $seed_log ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local dev-mode log file, not a URL.
		} else {
			$line( '(seed.last.log does not exist — runDevSeed has not been triggered)' );
		}

		$line( '' );
		$line( '=== Direct DB counts ===' );
		global $wpdb;
		foreach ( [ 'monstera_org', 'monstera_content', 'monstera_subgroup', 'monstera_project', 'monstera_form', 'monstera_alert' ] as $pt ) {
			$total     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s", $pt ) );
			$published = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = %s", $pt, 'publish' ) );
			$line( sprintf( '%-20s  total=%d  publish=%d', $pt, $total, $published ) );
		}

		$line( '' );
		$line( '=== Activity log ===' );
		$logTable  = $wpdb->prefix . 'monstera_activity_log';
		$logExists = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $logTable ) );
		$line( 'table exists:           ' . ( $logExists ? 'YES' : 'NO' ) );
		if ( $logExists ) {
			$line( 'total rows:             ' . (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $logTable ) ) );
			$line( 'rows by event_type:' );
			$byType = $wpdb->get_results( $wpdb->prepare( 'SELECT event_type, COUNT(*) AS c FROM %i GROUP BY event_type ORDER BY c DESC', $logTable ), ARRAY_A );
			foreach ( (array) $byType as $row ) {
				$line( sprintf( '  %-20s  %d', $row['event_type'], (int) $row['c'] ) );
			}
			$line( 'oldest row occurred_at: ' . (string) $wpdb->get_var( $wpdb->prepare( 'SELECT MIN(occurred_at) FROM %i', $logTable ) ) );
			$line( 'newest row occurred_at: ' . (string) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(occurred_at) FROM %i', $logTable ) ) );
			$weekAgo = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
			$line( '7-day cutoff (UTC):     ' . $weekAgo );
			$line( 'logins in last 7 days:  ' . (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE event_type='login' AND occurred_at >= %s", $logTable, $weekAgo ) ) );
			$line( 'downloads in last 7 days: ' . (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE event_type='download' AND occurred_at >= %s", $logTable, $weekAgo ) ) );
			$line( 'last 5 rows:' );
			$recent = $wpdb->get_results( $wpdb->prepare( 'SELECT id, user_id, event_type, object_type, object_id, occurred_at FROM %i ORDER BY id DESC LIMIT 5', $logTable ), ARRAY_A );
			foreach ( (array) $recent as $row ) {
				$line(
					sprintf(
						'  #%-5d u=%-4d %-12s obj=%s:%d  at=%s',
						(int) $row['id'],
						(int) $row['user_id'],
						(string) $row['event_type'],
						(string) ( $row['object_type'] ?: '-' ),
						(int) $row['object_id'],
						(string) $row['occurred_at']
					)
				);
			}
		}
		$line( 'monstera_demo_seed_version: ' . wp_json_encode( get_option( 'monstera_demo_seed_version' ) ) );
		$line( 'monstera_retention_days:    ' . (int) get_option( 'monstera_retention_days', 90 ) );

		$line( '' );
		$line( '=== Direct DB list of monstera_org rows ===' );
		$orgs = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_name, post_status, post_title FROM {$wpdb->posts} WHERE post_type = %s LIMIT 20", 'monstera_org' ), ARRAY_A );
		if ( $orgs ) {
			foreach ( $orgs as $row ) {
				$line( sprintf( '  #%-4d  status=%-10s  slug=%-25s  title=%s', $row['ID'], $row['post_status'], $row['post_name'], $row['post_title'] ) );
			}
		} else {
			$line( '  (no monstera_org rows in wp_posts)' );
		}

		$line( '' );
		$line( '=== Users with Monstera roles ===' );
		foreach ( [ 'monstera_admin', 'monstera_org_manager', 'monstera_member', 'monstera_member_standalone' ] as $role ) {
			$count = count(
				get_users(
					[
						'role'   => $role,
						'fields' => 'ID',
						'number' => -1,
					]
				)
			);
			$line( sprintf( '%-30s  %d users', $role, $count ) );
		}

		$line( '' );
		$line( '=== WP_Query test (what the admin Orgs list runs) ===' );
		$q = new \WP_Query(
			[
				'post_type'      => 'monstera_org',
				'posts_per_page' => -1,
				'post_status'    => [ 'publish', 'draft' ],
				'no_found_rows'  => true,
			]
		);
		$line( 'WP_Query found_posts: ' . (int) $q->found_posts );
		$line( 'WP_Query post_count:  ' . (int) $q->post_count );
		$line( 'WP_Query post IDs:    ' . implode( ',', wp_list_pluck( $q->posts, 'ID' ) ) );

		$line( '' );
		$line( '=== REST controller (server-side) test ===' );
		try {
			$controller = new \Monstera\Rest\Controllers\OrganizationsController( 'monstera/v1' );
			$request    = new \WP_REST_Request( 'GET', '/monstera/v1/organizations' );
			$request->set_query_params( [ 'per_page' => 500 ] );
			$result = $controller->index( $request );
			$line( 'items count:    ' . count( $result['items'] ) );
			if ( ! empty( $result['items'][0] ) ) {
				$line( 'first item:     ' . wp_json_encode( $result['items'][0] ) );
			}
		} catch ( \Throwable $e ) {
			$line( 'ERROR: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
		}

		$line( '' );
		$line( '=== Registered REST routes for monstera/v1 ===' );
		do_action( 'rest_api_init' );
		$server = rest_get_server();
		$routes = $server->get_routes();
		$found  = 0;
		foreach ( $routes as $route => $handlers ) {
			if ( str_starts_with( $route, '/monstera/v1' ) ) {
				$line( '  ' . $route );
				++$found;
			}
		}
		if ( ! $found ) {
			$line( '  (none — rest_api_init may not have fired yet or RestModule did not register)' );
		}

		$line( '' );
		$line( '=== Cap lookup for ?page=monstera ===' );
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		try {
			$_GET['page']  = 'monstera';
			$cap           = \function_exists( 'get_admin_page_capability' ) ? \get_admin_page_capability( 'monstera' ) : '';
			$plugin_page   = 'monstera';
			$page_hook     = \get_plugin_page_hook( $plugin_page, 'admin.php' );
			$page_hookname = \get_plugin_page_hookname( $plugin_page, '' );

			$line( 'get_admin_page_capability(monstera): ' . wp_json_encode( $cap ) );
			$line( 'get_plugin_page_hookname(monstera): ' . wp_json_encode( $page_hookname ) );
			$line( 'get_plugin_page_hook(monstera, admin.php): ' . wp_json_encode( $page_hook ) );
			$line( 'current_user_can($cap): ' . ( \current_user_can( $cap ) ? 'YES' : 'NO' ) );
			// phpcs:ignore WordPress.WP.Capabilities.Unknown -- diagnostics probe the menu hook name WordPress maps to the page cap.
			$line( 'current_user_can(toplevel_page_monstera): ' . ( \current_user_can( 'toplevel_page_monstera' ) ? 'YES' : 'NO' ) );
			$line( 'current_user_can(manage_monstera): ' . ( \current_user_can( 'manage_monstera' ) ? 'YES' : 'NO' ) );
		} catch ( \Throwable $e ) {
			$line( 'ERROR: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
		}

		exit;
	}

	/**
	 * Dev-only force-login. Sets the auth cookie for the admin user directly,
	 * bypassing wp-login.php entirely. Use when the standard login flow can't
	 * persist a session (cookie domain mismatch, PHP-WASM cookie quirks, etc).
	 * Gated by MONSTERA_DEV_MODE so production installs never expose this.
	 */
	public static function maybeForceLogin(): void {
		// Defense in depth: never authenticate unless dev mode is explicitly on,
		// even if this handler is somehow reached outside the gated registration.
		if ( ! ( defined( 'MONSTERA_DEV_MODE' ) && MONSTERA_DEV_MODE ) ) {
			return;
		}
		if ( ! isset( $_GET['monstera-login-as-admin'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
			return;
		}

		$login = (string) $_GET['monstera-login-as-admin']; // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
		// Default to 'admin'; allow ?monstera-login-as-admin=sasha after seeding.
		if ( '1' === $login || '' === $login ) {
			$login = 'admin';
		}
		$login = sanitize_user( $login, true );

		$user = get_user_by( 'login', $login );
		if ( ! $user ) {
			wp_die(
				esc_html( "Monstera dev: user '{$login}' not found." ),
				'Force login failed',
				[ 'response' => 404 ]
			);
		}

		wp_clear_auth_cookie();
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true, false );

		// Land on the stock WP dashboard by default so we can verify basic
		// admin access works. Pass ?to=monstera to land on the Monstera page,
		// or ?to=portal for the front-end portal.
		$to     = sanitize_key( (string) ( $_GET['to'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
		$target = match ( $to ) {
			'monstera' => admin_url( 'admin.php?page=monstera' ),
			'portal'   => home_url( '/portal/' ),
			default    => admin_url(),
		};
		wp_safe_redirect( $target );
		exit;
	}

	/**
	 * Dev-only manual rewrite-rule flush. Visit /?monstera-flush=1 if
	 * /wp-json/* URLs are returning the homepage (means rewrites haven't
	 * been flushed since permalink_structure was set).
	 */
	public static function maybeFlushRewrites(): void {
		if ( ! isset( $_GET['monstera-flush'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- dev-mode endpoint: MONSTERA_DEV_MODE plus a capability check gate it; never active in production.
			return;
		}
		flush_rewrite_rules( false );
		delete_option( 'monstera_rewrites_flushed_for' );
		update_option( 'monstera_rewrites_flushed_for', Core\Routing::rewriteStamp() );

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo "Rewrite rules flushed.\n";
		echo "Try /wp-json/monstera/v1/organizations now.\n";
		exit;
	}

	private static function writeSeedLog( string $path, string $message ): void {
		if ( '' === $path ) {
			return;
		}
		$line = sprintf( "[%s] %s\n", gmdate( 'c' ), $message );
		@file_put_contents( $path, $line ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- dev-mode seed log; a read-only plugin directory must not break seeding.
	}

	/**
	 * Activation runs before plugins_loaded fires, so it needs a stripped-down
	 * boot just to register CPTs/taxonomies for rewrite-rule generation.
	 */
	public function bootForActivation(): void {
		$this->registerModules();
		foreach ( $this->modules as $module ) {
			if ( $module instanceof Module && method_exists( $module, 'registerPostTypes' ) ) {
				$module->registerPostTypes();
			}
		}
	}

	private function registerCoreServices(): void {
		$this->container->set( Assets::class, static fn () => new Assets() );
	}

	private function registerModules(): void {
		if ( $this->modules ) {
			return;
		}

		// Core modules always present — they own data the rest of the
		// plugin treats as foundational (orgs, members, sub-groups,
		// content, access, notifications, sync, integrations, REST,
		// admin shell, portal, CLI).
		$this->modules[] = new OrganizationsModule();
		$this->modules[] = new MembersModule();
		$this->modules[] = new SubgroupsModule();
		$this->modules[] = new ContentModule();
		$this->modules[] = new AccessControlModule();
		$this->modules[] = new NotificationsModule();
		$this->modules[] = new BackgroundSyncModule();
		$this->modules[] = new IntegrationsModule();
		$this->modules[] = new RestModule();
		$this->modules[] = new AdminModule();
		$this->modules[] = new PortalModule();
		$this->modules[] = new CliModule();

		// Optional modules — load only when admin has them enabled in
		// Settings → Modules.
		if ( Modules::isActive( Modules::PROJECTS ) ) {
			$this->modules[] = new ProjectsModule();
		}
		if ( Modules::isActive( Modules::FORMS ) ) {
			$this->modules[] = new FormsModule();
		}
		if ( Modules::isActive( Modules::REPORTING ) ) {
			$this->modules[] = new ReportingModule();
		}
		if ( Modules::isActive( Modules::ALERTS ) ) {
			$this->modules[] = new AlertsModule();
		}
		if ( Modules::isActive( Modules::SUPPORT ) ) {
			$this->modules[] = new SupportModule();
		}

		// Rewrite rules need $wp_rewrite, which WordPress doesn't initialize
		// until the init action. Calling add_rewrite_rule() during
		// plugins_loaded fatals with "Call to a member function add_rule()
		// on null". Defer registration to init.
		add_action( 'init', [ Routing::class, 'register' ], 10 );

		// Assets registration only calls add_action() / wp_register_*, so it's
		// safe at plugins_loaded.
		$this->container->get( Assets::class )->register();
	}

	private function loadTextdomain(): void {
		load_plugin_textdomain( 'monstera', false, dirname( MONSTERA_BASENAME ) . '/languages' );
	}
}
