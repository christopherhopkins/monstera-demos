<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class SubgroupsModule implements Module {

	public function slug(): string {
		return 'subgroups';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
	}

	public function registerPostTypes(): void {
		PostType::register();
	}
}
