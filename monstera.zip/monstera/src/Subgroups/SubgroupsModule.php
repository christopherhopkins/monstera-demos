<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class SubgroupsModule implements Module {

	public function slug(): string {
		return 'subgroups';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		// A sub-group moved to another organization is judged by its new one
		// at once (Repository::ofOrgsOnSite()).
		foreach ( [ 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ] as $hook ) {
			add_action( $hook, [ Repository::class, 'forgetOrg' ], 10, 3 );
		}
	}

	public function registerPostTypes(): void {
		PostType::register();
	}
}
