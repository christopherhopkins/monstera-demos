<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

use Monstera\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

final class PostType {

	public const SLUG = 'monstera_subgroup';

	public static function register(): void {
		register_post_type(
			self::SLUG,
			[
				'labels'          => [
					'name'               => __( 'Sub-groups', 'monstera' ),
					'singular_name'      => __( 'Sub-group', 'monstera' ),
					'add_new'            => __( 'Add sub-group', 'monstera' ),
					'add_new_item'       => __( 'Add sub-group', 'monstera' ),
					'edit_item'          => __( 'Edit sub-group', 'monstera' ),
					'view_item'          => __( 'View sub-group', 'monstera' ),
					'search_items'       => __( 'Search sub-groups', 'monstera' ),
					'not_found'          => __( 'No sub-groups yet.', 'monstera' ),
					'not_found_in_trash' => __( 'No sub-groups in trash.', 'monstera' ),
				],
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				'show_in_rest'    => true,
				'rest_base'       => 'subgroups',
				'supports'        => [ 'title', 'editor' ],
				'has_archive'     => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'capabilities'    => [
					'edit_posts'         => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'  => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}
}
