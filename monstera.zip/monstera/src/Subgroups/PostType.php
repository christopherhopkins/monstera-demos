<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

use Monstera\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

final class PostType {

	public const SLUG = 'monstera_subgroup';

	public static function register(): void {
		add_filter( 'wp_untrash_post_status', [ self::class, 'untrashStatus' ], 10, 3 );
		register_post_type(
			self::SLUG,
			[
				'labels'          => [
					'name'               => __( 'Sub-groups', 'monstera' ),
					'singular_name'      => __( 'Sub-group', 'monstera' ),
					'add_new'            => __( 'Add sub-group', 'monstera' ),
					'add_new_item'       => __( 'Add sub-group', 'monstera' ),
					'edit_item'          => __( 'Edit sub-group', 'monstera' ),
					'view_item'          => __( 'View sub-group', 'monstera' ),
					'search_items'       => __( 'Search sub-groups', 'monstera' ),
					'not_found'          => __( 'No sub-groups yet.', 'monstera' ),
					'not_found_in_trash' => __( 'No sub-groups in trash.', 'monstera' ),
				],
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				// Out of core REST: /wp/v2 hands any published post of a type it
				// serves to anyone who asks, signed in or not, round the engine and
				// the Roster. The only way in is monstera/v1, which asks who is asking.
				'show_in_rest'    => false,
				'supports'        => [ 'title', 'editor' ],
				'has_archive'     => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				// The team may bring one back from WordPress's trash, which asks
				// the published and others' capabilities: one in the trash lets
				// nobody through (the owner's call, 2026-10-18).
				'capabilities'    => [
					'edit_posts'             => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_published_posts'   => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_private_posts'     => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'          => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts'     => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'           => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_others_posts'    => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_published_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_private_posts'   => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'           => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}

	/**
	 * A sub-group back from the trash takes the status it had, so its
	 * members are let through its gates again at once: one in the trash
	 * lets nobody through (the owner's call, 2026-10-18), and WordPress
	 * would restore it as a draft, which lets nobody through either. One
	 * trashed with no status remembered comes back published, as every
	 * sub-group a picker offers is.
	 */
	public static function untrashStatus( string $status, int $postId, string $previous ): string {
		if ( self::SLUG !== get_post_type( $postId ) ) {
			return $status;
		}
		return in_array( $previous, [ '', 'trash' ], true ) ? 'publish' : $previous;
	}
}
