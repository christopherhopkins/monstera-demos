<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

final class Meta {

	public const KEY_ORG_ID               = 'monstera_subgroup_org_id';
	public const KEY_STANDALONE_MEMBER_ID = 'monstera_subgroup_standalone_member_id';
	public const KEY_LEADER               = 'monstera_subgroup_leader_id';
	public const KEY_FORMED_ON            = 'monstera_subgroup_formed_on';
	public const KEY_IS_PRIVATE           = 'monstera_subgroup_is_private';
	public const KEY_MEETING_CADENCE      = 'monstera_subgroup_cadence';

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_ORG_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBER_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_LEADER,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_FORMED_ON,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_IS_PRIVATE,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => false,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);
		register_post_meta(
			PostType::SLUG,
			self::KEY_MEETING_CADENCE,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			]
		);
	}
}
