<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

use Monstera\Core\Database\Schema;
use WP_Post;
use WP_Query;

final class Repository {

	public function find( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/** @var array<int, int> Per-request memo for leaderSubgroupId(). */
	private static array $leaderCache = [];

	/** Forget the memo — only needed in tests, where user ids are reused across rolled-back transactions. */
	public static function flushCache(): void {
		self::$leaderCache = [];
	}

	/**
	 * The single sub-group this user leads, or 0. A user leads at most one
	 * sub-group (Meta::KEY_LEADER is a scalar). Result is memoised per request
	 * because the dynamic leader capability filter and AuthorScope both consult
	 * it, potentially many times per page load.
	 */
	public static function leaderSubgroupId( int $userId ): int {
		$cache = &self::$leaderCache;
		if ( $userId <= 0 ) {
			return 0;
		}
		if ( array_key_exists( $userId, $cache ) ) {
			return $cache[ $userId ];
		}
		// Seed the memo before querying: get_posts() runs cap checks internally,
		// and this method backs the user_has_cap leader-cap filter, so a naive
		// call could recurse. The sentinel makes re-entry return 0 immediately.
		$cache[ $userId ] = 0;
		$ids              = get_posts(
			[
				'post_type'   => PostType::SLUG,
				'post_status' => 'publish',
				'meta_key'    => Meta::KEY_LEADER, // phpcs:ignore WordPress.DB.SlowDBQuery -- the leader lives in post meta by design; a user leads at most one sub-group.
			'meta_value'      => (string) $userId, // phpcs:ignore WordPress.DB.SlowDBQuery -- the leader lives in post meta by design; a user leads at most one sub-group.
			'posts_per_page'  => 1,
			'fields'          => 'ids',
			'no_found_rows'   => true,
			]
		);
		$cache[ $userId ] = $ids ? (int) $ids[0] : 0;
		return $cache[ $userId ];
	}

	/**
	 * @return WP_Post[]
	 */
	public function forOrg( int $orgId ): array {
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'posts_per_page' => -1,
				'meta_query'     => [
					[
						'key'   => Meta::KEY_ORG_ID,
						'value' => $orgId,
					],
				],
				'no_found_rows'  => true,
			]
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @return int[]
	 */
	public function memberIds( int $subgroupId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT member_id FROM %i WHERE subgroup_id = %d', $table, $subgroupId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * @return int[] Sub-group IDs this member belongs to.
	 */
	public function subgroupsForMember( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT subgroup_id FROM %i WHERE member_id = %d', $table, $memberId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * @return int[] Sub-group IDs gating a given content item.
	 */
	public function subgroupsForContent( int $contentId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT subgroup_id FROM %i WHERE content_id = %d', $table, $contentId ) );
		return array_map( 'intval', $rows );
	}

	public function addMember( int $subgroupId, int $memberId, string $roleInGroup = '' ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS ),
			[
				'subgroup_id'   => $subgroupId,
				'member_id'     => $memberId,
				'role_in_group' => $roleInGroup,
				'joined_on'     => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s', '%s' ]
		);
	}

	public function removeMember( int $subgroupId, int $memberId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS ),
			[
				'subgroup_id' => $subgroupId,
				'member_id'   => $memberId,
			],
			[ '%d', '%d' ]
		);
	}

	public function assignContent( int $subgroupId, int $contentId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS ),
			[
				'subgroup_id' => $subgroupId,
				'content_id'  => $contentId,
			],
			[ '%d', '%d' ]
		);
	}

	public function unassignContent( int $subgroupId, int $contentId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS ),
			[
				'subgroup_id' => $subgroupId,
				'content_id'  => $contentId,
			],
			[ '%d', '%d' ]
		);
	}
}
