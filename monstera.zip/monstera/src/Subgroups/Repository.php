<?php
declare(strict_types=1);

namespace Monstera\Subgroups;

use Monstera\Core\Database\Schema;
use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function find( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/** @var array<int, array<int, list<int>>> Per-request memo for leaderSubgroupIds(): by person, then by the organization asked about (0 for any). */
	private static array $leaderCache = [];

	/** @var array<int, list<int>> Per-request memo for subgroupsForMembers(): each person's sub-groups, filled a list at a time. */
	private static array $memberCache = [];

	/** Forget the memos: after a write to the members table here, and in tests, where user ids are reused across rolled-back transactions. */
	public static function flushCache(): void {
		self::$leaderCache = [];
		self::$memberCache = [];
	}

	/**
	 * The sub-groups this person leads, newest first. Asked about an
	 * organization, those under it and none when they lead nothing there;
	 * asked about none, every one they lead anywhere. A person may lead a
	 * sub-group in each of their organizations, and two under one of them
	 * (People-model track, FR2): AuthorScope asks organization by
	 * organization and holds every group led there, so each hub's Manage tab
	 * is scoped to the groups led under it. Memoised per request, by person
	 * and organization, because the capability filter and AuthorScope both
	 * consult it, potentially many times per page load.
	 *
	 * @return list<int>
	 */
	public static function leaderSubgroupIds( int $userId, int $orgId = 0 ): array {
		if ( $userId <= 0 ) {
			return [];
		}
		$orgId = max( 0, $orgId );
		if ( isset( self::$leaderCache[ $userId ][ $orgId ] ) ) {
			return self::$leaderCache[ $userId ][ $orgId ];
		}
		// Seed the memo before querying: get_posts() runs cap checks internally,
		// and this method backs the user_has_cap leader-cap filter, so a naive
		// call could recurse. The sentinel makes re-entry answer none at once.
		self::$leaderCache[ $userId ][ $orgId ] = [];

		$args = [
			'post_type'      => PostType::SLUG,
			'post_status'    => 'publish',
			'meta_key'       => Meta::KEY_LEADER, // phpcs:ignore WordPress.DB.SlowDBQuery -- the leader lives in post meta by design.
			'meta_value'     => (string) $userId, // phpcs:ignore WordPress.DB.SlowDBQuery -- the leader lives in post meta by design.
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		];
		if ( $orgId > 0 ) {
			$args['meta_query'] = [ // phpcs:ignore WordPress.DB.SlowDBQuery -- the parent organization lives in post meta beside the leader.
				[
					'key'   => Meta::KEY_ORG_ID,
					'value' => (string) $orgId,
				],
			];
		}
		$ids = get_posts( $args );

		self::$leaderCache[ $userId ][ $orgId ] = array_values( array_map( 'intval', $ids ) );
		return self::$leaderCache[ $userId ][ $orgId ];
	}

	/**
	 * One sub-group this person leads, or 0: the newest of leaderSubgroupIds().
	 * What the dynamic leader capability asks (Core\Capabilities), which only
	 * needs to know whether there is one.
	 */
	public static function leaderSubgroupId( int $userId, int $orgId = 0 ): int {
		return self::leaderSubgroupIds( $userId, $orgId )[0] ?? 0;
	}

	/**
	 * @return WP_Post[]
	 */
	public function forOrg( int $orgId ): array {
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'posts_per_page' => -1,
				'meta_query'     => [
					[
						'key'   => Meta::KEY_ORG_ID,
						'value' => $orgId,
					],
				],
				'no_found_rows'  => true,
			]
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * The sub-groups of several organizations from one read, organization by
	 * organization in the order given and each one's as forOrg() lists
	 * them, so a page that spans a person's organizations (the directory's
	 * chips) costs the same for six as for two. One organization is asked
	 * as forOrg() asks it, so a page about one is what it was.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return WP_Post[]
	 */
	public function forOrgs( array $orgIds ): array {
		$orgIds = array_values( array_unique( array_filter( array_map( 'intval', $orgIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( count( $orgIds ) < 2 ) {
			return $orgIds ? $this->forOrg( $orgIds[0] ) : [];
		}
		$query = new WP_Query(
			[
				'post_type'      => PostType::SLUG,
				'posts_per_page' => -1,
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- the parent organization lives in post meta by design.
					[
						'key'     => Meta::KEY_ORG_ID,
						'value'   => $orgIds,
						'compare' => 'IN',
					],
				],
				'no_found_rows'  => true,
			]
		);
		// The query read each group's meta with it, so asking whose it is costs nothing.
		$byOrg = array_fill_keys( $orgIds, [] );
		foreach ( $query->posts as $post ) {
			$orgId = $post instanceof WP_Post ? (int) get_post_meta( $post->ID, Meta::KEY_ORG_ID, true ) : 0;
			if ( isset( $byOrg[ $orgId ] ) ) {
				$byOrg[ $orgId ][] = $post;
			}
		}
		return array_merge( ...array_values( $byOrg ) );
	}

	/**
	 * @return int[]
	 */
	public function memberIds( int $subgroupId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT member_id FROM %i WHERE subgroup_id = %d', $table, $subgroupId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * @return int[] Sub-group IDs this member belongs to.
	 */
	public function subgroupsForMember( int $memberId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT subgroup_id FROM %i WHERE member_id = %d', $table, $memberId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * The sub-groups each of many people belongs to, from one read: for a
	 * page that lists people and names their groups on each row (the
	 * directory), where asking person by person is a read apiece. Someone in
	 * no group is in the answer with none, so the caller knows they were
	 * asked. Memoised per request as leaderSubgroupIds() is, so a second
	 * list on the same page reads only the people the first did not; a
	 * write here forgets the memo.
	 *
	 * @param array<int, mixed> $memberIds
	 * @return array<int, list<int>> Sub-group ids by user id.
	 */
	public function subgroupsForMembers( array $memberIds ): array {
		$memberIds = array_values( array_unique( array_filter( array_map( 'intval', $memberIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		$missing   = array_values( array_filter( $memberIds, static fn ( int $id ): bool => ! isset( self::$memberCache[ $id ] ) ) );
		if ( $missing ) {
			global $wpdb;
			$marks = implode( ',', array_fill( 0, count( $missing ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $missing ); every id goes through prepare().
			$rows = (array) $wpdb->get_results(
				$wpdb->prepare( "SELECT member_id, subgroup_id FROM %i WHERE member_id IN ($marks)", Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS ), ...$missing ),
				ARRAY_A
			);
			// phpcs:enable
			foreach ( $missing as $id ) {
				self::$memberCache[ $id ] = [];
			}
			foreach ( $rows as $row ) {
				self::$memberCache[ (int) $row['member_id'] ][] = (int) $row['subgroup_id'];
			}
		}
		$out = [];
		foreach ( $memberIds as $id ) {
			$out[ $id ] = self::$memberCache[ $id ];
		}
		return $out;
	}

	/**
	 * @return int[] Sub-group IDs gating a given content item.
	 */
	public function subgroupsForContent( int $contentId ): array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS );
		$rows  = $wpdb->get_col( $wpdb->prepare( 'SELECT subgroup_id FROM %i WHERE content_id = %d', $table, $contentId ) );
		return array_map( 'intval', $rows );
	}

	/**
	 * The sub-groups gating each of many content items, from one read: for a
	 * page that judges a list of items (the dashboard's feed and its bands'
	 * counts), where asking item by item is a read apiece. An item with no
	 * gate is in the answer with none, so the caller knows it was asked.
	 *
	 * @param array<int, mixed> $contentIds
	 * @return array<int, int[]> Sub-group ids by content id.
	 */
	public function subgroupsForContents( array $contentIds ): array {
		$contentIds = array_values( array_unique( array_filter( array_map( 'intval', $contentIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		$out        = array_fill_keys( $contentIds, [] );
		if ( ! $contentIds ) {
			return $out;
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $contentIds ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $contentIds ); every id goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT content_id, subgroup_id FROM %i WHERE content_id IN ($marks)", Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS ), ...$contentIds ),
			ARRAY_A
		);
		// phpcs:enable
		foreach ( $rows as $row ) {
			$out[ (int) $row['content_id'] ][] = (int) $row['subgroup_id'];
		}
		return $out;
	}

	public function addMember( int $subgroupId, int $memberId, string $roleInGroup = '' ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS ),
			[
				'subgroup_id'   => $subgroupId,
				'member_id'     => $memberId,
				'role_in_group' => $roleInGroup,
				'joined_on'     => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s', '%s' ]
		);
		unset( self::$memberCache[ $memberId ] );
	}

	public function removeMember( int $subgroupId, int $memberId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_SUBGROUP_MEMBERS ),
			[
				'subgroup_id' => $subgroupId,
				'member_id'   => $memberId,
			],
			[ '%d', '%d' ]
		);
		unset( self::$memberCache[ $memberId ] );
	}

	public function assignContent( int $subgroupId, int $contentId ): void {
		global $wpdb;
		$wpdb->replace(
			Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS ),
			[
				'subgroup_id' => $subgroupId,
				'content_id'  => $contentId,
			],
			[ '%d', '%d' ]
		);
	}

	public function unassignContent( int $subgroupId, int $contentId ): void {
		global $wpdb;
		$wpdb->delete(
			Schema::tableName( Schema::TABLE_CONTENT_SUBGROUPS ),
			[
				'subgroup_id' => $subgroupId,
				'content_id'  => $contentId,
			],
			[ '%d', '%d' ]
		);
	}
}
