<?php
/**
 * Plugin deactivation handler.
 *
 * Flushes rewrites, unschedules cron. Does NOT drop tables, roles, or files —
 * those are uninstall.php concerns.
 */

declare(strict_types=1);

namespace Monstera;

use Monstera\BackgroundSync\Cron;
use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

final class Deactivator {

	public static function deactivate(): void {
		Cron::clear();

		flush_rewrite_rules( false );
		do_action( Hooks::DEACTIVATED );
	}
}
