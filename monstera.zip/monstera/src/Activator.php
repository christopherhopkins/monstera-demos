<?php
/**
 * Plugin activation handler.
 *
 * Runs once on plugin activation: creates DB tables, registers roles,
 * provisions the secure-storage directory, schedules cron, and flushes
 * rewrites. Idempotent — safe to call repeatedly.
 */

declare(strict_types=1);

namespace Monstera;

use Monstera\BackgroundSync\Cron;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Core\SecureStorage;

defined( 'ABSPATH' ) || exit;

final class Activator {

	public static function activate(): void {
		Schema::install();
		Capabilities::install();
		SecureStorage::install();

		Cron::schedule();
		self::seedOptions();

		// Register CPTs / taxonomies temporarily so rewrite rules know about them.
		Plugin::instance()->bootForActivation();
		Routing::flush();

		update_option( 'monstera_version', MONSTERA_VERSION, false );

		do_action( Hooks::ACTIVATED );
	}

	private static function seedOptions(): void {
		$defaults = [
			'monstera_portal_prefix'  => 'portal',
			'monstera_active_modules' => Modules::defaults(),
			'monstera_retention_days' => 90,
			'monstera_renewal_window' => 60,
		];
		foreach ( $defaults as $key => $value ) {
			if ( false === get_option( $key, false ) ) {
				add_option( $key, $value, '', false );
			}
		}
	}
}
