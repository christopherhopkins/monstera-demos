<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Core\Hooks;
use Monstera\Core\Routing;

defined( 'ABSPATH' ) || exit;

/**
 * Token-replaced email templates.
 *
 * Templates live in the monstera_notification_templates option as an
 * associative array of [event_key => ['subject' => ..., 'body' => ...]].
 * Built-in defaults below are used when an event has no override.
 */
final class TemplateEngine {

	public const EVENT_NEW_CONTENT      = 'new_content';
	public const EVENT_UPDATED_CONTENT  = 'updated_content';
	public const EVENT_CONTENT_UNLOCKED = 'content_unlocked';
	public const EVENT_WELCOME          = 'welcome';
	public const EVENT_ADDED_TO_ORG     = 'added_to_org';
	public const EVENT_TEAM_WELCOME     = 'team_welcome';
	public const EVENT_EXPIRY_WARNING   = 'expiry_warning';
	public const EVENT_EXPIRED          = 'expired';
	public const EVENT_ORG_SUSPENDED    = 'org_suspended';
	public const EVENT_ALERT_POSTED     = 'alert_posted';
	public const EVENT_INTAKE_SUBMITTED = 'intake_submitted';

	// A built form (Forms-and-resources track, FR9): what was sent, to its
	// recipients; that it arrived, to the member; that it is due, to those
	// who have not sent one.
	public const EVENT_FORM_SUBMITTED    = 'form_submitted';
	public const EVENT_FORM_CONFIRMATION = 'form_confirmation';
	public const EVENT_FORM_DUE_REMINDER = 'form_due_reminder';

	// A standalone member's own membership: its warnings and its end.
	public const EVENT_STANDALONE_EXPIRY_WARNING = 'standalone_expiry_warning';
	public const EVENT_STANDALONE_EXPIRED        = 'standalone_expired';

	// A support conversation: what its member hears…
	public const EVENT_SUPPORT_RECEIVED = 'support_received';
	public const EVENT_SUPPORT_REPLIED  = 'support_replied';
	public const EVENT_SUPPORT_RESOLVED = 'support_resolved';
	public const EVENT_SUPPORT_CLOSED   = 'support_closed';
	// …and what the support inbox hears.
	public const EVENT_SUPPORT_NEW             = 'support_new';
	public const EVENT_SUPPORT_MEMBER_REPLIED  = 'support_member_replied';
	public const EVENT_SUPPORT_MEMBER_RESOLVED = 'support_member_resolved';
	public const EVENT_SUPPORT_PRIORITY_RAISED = 'support_priority_raised';

	/**
	 * Events that go to the agency, not to a member: an inbox address reads
	 * them, so their tokens name a project and who sent what, never the
	 * reader. A form's submission is among them: its readers are the
	 * addresses the author listed and the organization's leads, and it is
	 * about someone else's send.
	 *
	 * @var string[]
	 */
	public const AGENCY_EVENTS = [
		self::EVENT_INTAKE_SUBMITTED,
		self::EVENT_FORM_SUBMITTED,
		self::EVENT_SUPPORT_NEW,
		self::EVENT_SUPPORT_MEMBER_REPLIED,
		self::EVENT_SUPPORT_MEMBER_RESOLVED,
		self::EVENT_SUPPORT_PRIORITY_RAISED,
	];

	/**
	 * Events that go to one person on the team by name. They are not agency
	 * events, which go to an inbox, and not a member's either: the reader has
	 * a role on the team and the admin to work in, never a portal or an
	 * organization. NotificationCopyTest renders them with those tokens.
	 *
	 * @var string[]
	 */
	public const TEAM_EVENTS = [ self::EVENT_TEAM_WELCOME ];

	/**
	 * Events that only ever reach members of an organization, so their
	 * templates may name one ({user_company}). Every other default must read
	 * correctly for a standalone member too; NotificationCopyTest holds the
	 * two lists to each other. The expiry reminders are among them: they run
	 * per organization and reach its admins and managers (Expiration), and
	 * the dispatcher fills the token with the organization that is expiring,
	 * so a person who answers for two reads which one each email is about,
	 * and nobody is told "your membership" has ended while another of theirs
	 * is live. So is the welcome to someone who already had an account and
	 * was invited into one more organization: it names the one they joined,
	 * and the dispatcher fills the token with that one alone. A standalone
	 * member is told of their own membership's end by events of their own
	 * (STANDALONE_EVENTS).
	 *
	 * @var string[]
	 */
	public const ORG_ONLY_EVENTS = [ self::EVENT_ORG_SUSPENDED, self::EVENT_EXPIRY_WARNING, self::EVENT_EXPIRED, self::EVENT_ADDED_TO_ORG ];

	/**
	 * Events that only ever reach a standalone member, about the membership
	 * of their own that their portal runs on
	 * (AccessControl\PortalGuard::runsOnOwnMembership()): its warnings and
	 * its end, on an organization's days (Expiration). The dispatcher gives
	 * their own date, and their templates name no organization;
	 * NotificationCopyTest renders them as it renders every member's email,
	 * and holds them to naming none.
	 *
	 * @var string[]
	 */
	public const STANDALONE_EVENTS = [ self::EVENT_STANDALONE_EXPIRY_WARNING, self::EVENT_STANDALONE_EXPIRED ];

	private const DEFAULTS = [
		self::EVENT_NEW_CONTENT               => [
			'subject' => '{site_name}: {content_title}',
			'body'    => "Hi {user_first_name},\n\n{content_title} is now available in your portal.\n\n{summary}\n\nOpen in the portal: {content_url}\n\n— {site_name}",
		],
		self::EVENT_UPDATED_CONTENT           => [
			'subject' => '{site_name}: {content_title} was updated',
			'body'    => "Hi {user_first_name},\n\nWe updated {content_title}.\n\n{summary}\n\nOpen in the portal: {content_url}\n\n— {site_name}",
		],
		self::EVENT_CONTENT_UNLOCKED          => [
			'subject' => '{site_name}: {content_title} is now available',
			'body'    => "Hi {user_first_name},\n\n{content_title} is unlocked and ready for you.\n\nOpen it: {content_url}\n\n— {site_name}",
		],
		self::EVENT_WELCOME                   => [
			'subject' => 'Welcome to {site_name}',
			'body'    => "Hi {user_first_name},\n\nWelcome to {site_name}. Your portal is at {portal_url}.\n\nSet your password to sign in: {set_password_url}\n\n— {site_name}",
		],
		self::EVENT_ADDED_TO_ORG              => [
			'subject' => 'You have been added to {user_company} on {site_name}',
			'body'    => "Hi {user_first_name},\n\nYou have been added to {user_company} on {site_name}. Sign in to see what it shares with you: {portal_url}\n\n— {site_name}",
		],
		self::EVENT_TEAM_WELCOME              => [
			'subject' => 'You have been added to the {site_name} team',
			'body'    => "Hi {user_first_name},\n\nYou have been added to the {site_name} team as a {team_role}.\n\nSet your password to sign in: {set_password_url}\n\nThen open the program: {admin_url}\n\n— {site_name}",
		],
		self::EVENT_EXPIRY_WARNING            => [
			'subject' => '{site_name}: the membership of {user_company} expires {expiry_date}',
			'body'    => "Hi {user_first_name},\n\nA reminder that the membership of {user_company} at {site_name} expires {expiry_date}.\n\nRenew at: {portal_url}\n\n— {site_name}",
		],
		self::EVENT_EXPIRED                   => [
			'subject' => '{site_name}: the membership of {user_company} has expired',
			'body'    => "Hi {user_first_name},\n\nThe membership of {user_company} at {site_name} expired on {expiry_date}. To restore access for its members, visit {portal_url}.\n\n— {site_name}",
		],
		self::EVENT_STANDALONE_EXPIRY_WARNING => [
			'subject' => '{site_name}: your membership expires {expiry_date}',
			'body'    => "Hi {user_first_name},\n\nA reminder that your membership at {site_name} expires {expiry_date}.\n\nRenew at: {profile_url}\n\n— {site_name}",
		],
		self::EVENT_STANDALONE_EXPIRED        => [
			'subject' => '{site_name}: your membership has expired',
			'body'    => "Hi {user_first_name},\n\nYour membership at {site_name} expired on {expiry_date}. Your content, downloads and projects are kept safe and come back the moment the membership is renewed.\n\nRenew at: {profile_url}\n\n— {site_name}",
		],
		self::EVENT_ORG_SUSPENDED             => [
			'subject' => '{site_name}: {user_company} access paused',
			'body'    => "Hi {user_first_name},\n\nAccess for {user_company} is temporarily paused. Members can still see what they had before; new downloads are unavailable until reactivation.\n\n— {site_name}",
		],
		self::EVENT_ALERT_POSTED              => [
			'subject' => '{site_name}: {alert_title}',
			'body'    => "Hi {user_first_name},\n\n{alert_title}\n\n{alert_body}\n\nIt is at the top of your portal: {portal_url}\n\n— {site_name}",
		],
		self::EVENT_INTAKE_SUBMITTED          => [
			'subject' => '{site_name}: discovery answers for {project_title}',
			'body'    => "{submitter_name} sent discovery answers for {project_title}.\n\n{changes}\n\nOpen the project: {project_url}\n\n— {site_name}",
		],
		self::EVENT_FORM_SUBMITTED            => [
			'subject' => '{site_name}: {form_title} from {submitter_name}',
			'body'    => "{submitter_name} sent {form_title}.\n\n{answers}\n\nOpen the submission: {submission_url}\n\n— {site_name}",
		],
		self::EVENT_FORM_CONFIRMATION         => [
			'subject' => '{site_name}: {form_title}',
			'body'    => "Hi {user_first_name},\n\n{confirmation}\n\nWhat you sent:\n{answers}\n\nOpen the form: {form_url}\n\n— {site_name}",
		],
		self::EVENT_FORM_DUE_REMINDER         => [
			'subject' => '{site_name}: {form_title} is due {due_date}',
			'body'    => "Hi {user_first_name},\n\n{form_title} is due {due_date}, and we do not have your answers yet.\n\nFill it in: {form_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_RECEIVED          => [
			'subject' => '{site_name}: we have your request {request_ref}',
			'body'    => "Hi {user_first_name},\n\nWe have your request {request_ref}: {request_subject}.\n\nWe will reply on its page and by email. You can add details or files there at any time:\n{request_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_REPLIED           => [
			'subject' => '{site_name}: a reply to your request {request_ref}',
			'body'    => "Hi {user_first_name},\n\n{staff_name} replied to your request {request_ref}, {request_subject}:\n\n{reply}\n\n{reply_files}\n\nAnswer on the request's page, where the whole conversation is. A reply to this email reaches us, but does not join it.\n{request_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_RESOLVED          => [
			'subject' => '{site_name}: your request {request_ref} is resolved',
			'body'    => "Hi {user_first_name},\n\n{staff_name} marked your request {request_ref}, {request_subject}, as resolved.\n\nIf it is not sorted, reply on its page and it opens again:\n{request_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_CLOSED            => [
			'subject' => '{site_name}: your request {request_ref} is closed',
			'body'    => "Hi {user_first_name},\n\nYour request {request_ref}, {request_subject}, is now closed. You can still read it here:\n{request_url}\n\nIf it comes back, reply on that page and it opens again. For something else, open a new request:\n{support_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_NEW               => [
			'subject' => '[{site_name} support {request_ref}] {request_subject}',
			'body'    => "{member_name} opened a support request.\n\nReference: {request_ref}\nPriority: {request_priority}\nFrom: {member_name} <{member_email}>\n{request_context}\n\n{message}\n\n{message_files}\n\nOpen the request: {admin_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_MEMBER_REPLIED    => [
			'subject' => '[{site_name} support {request_ref}] {member_name} replied',
			'body'    => "{member_name} replied on {request_ref}, {request_subject}:\n\n{message}\n\n{message_files}\n\nOpen the request: {admin_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_MEMBER_RESOLVED   => [
			'subject' => '[{site_name} support {request_ref}] Resolved by {member_name}',
			'body'    => "{member_name} marked {request_ref}, {request_subject}, as resolved.\n\nOpen the request: {admin_url}\n\n— {site_name}",
		],
		self::EVENT_SUPPORT_PRIORITY_RAISED   => [
			'subject' => '[{site_name} support {request_ref}] Priority raised to {request_priority}',
			'body'    => "{member_name} raised the priority of {request_ref}, {request_subject}, from {old_priority} to {request_priority}.\n\nOpen the request: {admin_url}\n\n— {site_name}",
		],
	];

	/**
	 * Exposes the built-in defaults so the Settings UI can show "Reset to
	 * default" without duplicating these strings. Returns a copy so callers
	 * can't mutate the constant.
	 *
	 * @return array<string, array{subject:string, body:string}>
	 */
	public static function defaults(): array {
		return self::DEFAULTS;
	}

	/**
	 * @param array<string, mixed> $tokens
	 * @return array{subject: string, body: string}
	 */
	public function render( string $event, array $tokens ): array {
		$templates = (array) get_option( 'monstera_notification_templates', [] );
		$tpl       = $templates[ $event ] ?? self::DEFAULTS[ $event ] ?? null;
		if ( ! $tpl ) {
			return [
				'subject' => '',
				'body'    => '',
			];
		}

		$tokens = $this->withDefaults( $tokens );
		$tokens = apply_filters( Hooks::FILTER_NOTIFICATION_TOKENS, $tokens, $event );

		$subject = $this->replace( (string) $tpl['subject'], $tokens );
		$body    = $this->replace( (string) $tpl['body'], $tokens );
		$body    = (string) apply_filters( Hooks::FILTER_NOTIFICATION_BODY, $body, $event, $tokens );

		return [
			'subject' => $subject,
			'body'    => $body,
		];
	}

	/**
	 * @param array<string, mixed> $tokens
	 */
	private function replace( string $template, array $tokens ): string {
		$keys = array_keys( $tokens );
		$find = array_map( static fn ( $k ) => '{' . $k . '}', $keys );
		return str_replace( $find, array_values( $tokens ), $template );
	}

	/**
	 * @param array<string, mixed> $tokens
	 * @return array<string, mixed>
	 */
	private function withDefaults( array $tokens ): array {
		return array_merge(
			[
				'site_name'        => get_bloginfo( 'name' ),
				'portal_url'       => Routing::url( Routing::ROUTE_DASHBOARD ),
				// Where a standalone member renews their own membership.
				'profile_url'      => Routing::url( Routing::ROUTE_PROFILE ),
				'login_url'        => wp_login_url(),
				// Defaults to empty so a stray {set_password_url} in a non-welcome
				// template never leaks as a raw token; the welcome path overrides
				// it with a real one-time link (caller tokens win on merge).
				'set_password_url' => '',
			],
			$tokens
		);
	}
}
