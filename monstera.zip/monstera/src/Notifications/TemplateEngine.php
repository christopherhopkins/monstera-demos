<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Core\Hooks;
use Monstera\Core\Routing;

/**
 * Token-replaced email templates.
 *
 * Templates live in the monstera_notification_templates option as an
 * associative array of [event_key => ['subject' => ..., 'body' => ...]].
 * Built-in defaults below are used when an event has no override.
 */
final class TemplateEngine {

	public const EVENT_NEW_CONTENT      = 'new_content';
	public const EVENT_UPDATED_CONTENT  = 'updated_content';
	public const EVENT_CONTENT_UNLOCKED = 'content_unlocked';
	public const EVENT_WELCOME          = 'welcome';
	public const EVENT_EXPIRY_WARNING   = 'expiry_warning';
	public const EVENT_EXPIRED          = 'expired';
	public const EVENT_ORG_SUSPENDED    = 'org_suspended';
	public const EVENT_ALERT_POSTED     = 'alert_posted';
	public const EVENT_INTAKE_SUBMITTED = 'intake_submitted';

	/**
	 * Events that go to the agency, not to a member: their tokens name a
	 * project and who sent what, never the reader.
	 *
	 * @var string[]
	 */
	public const AGENCY_EVENTS = [ self::EVENT_INTAKE_SUBMITTED ];

	/**
	 * Events that only ever reach members of an organization, so their
	 * templates may name one ({user_company}). Every other default must read
	 * correctly for a standalone member too; NotificationCopyTest holds the
	 * two lists to each other.
	 *
	 * @var string[]
	 */
	public const ORG_ONLY_EVENTS = [ self::EVENT_ORG_SUSPENDED ];

	private const DEFAULTS = [
		self::EVENT_NEW_CONTENT      => [
			'subject' => '{site_name}: {content_title}',
			'body'    => "Hi {user_first_name},\n\n{content_title} is now available in your portal.\n\n{summary}\n\nOpen in the portal: {content_url}\n\n— {site_name}",
		],
		self::EVENT_UPDATED_CONTENT  => [
			'subject' => '{site_name}: {content_title} was updated',
			'body'    => "Hi {user_first_name},\n\nWe updated {content_title}.\n\n{summary}\n\nOpen in the portal: {content_url}\n\n— {site_name}",
		],
		self::EVENT_CONTENT_UNLOCKED => [
			'subject' => '{site_name}: {content_title} is now available',
			'body'    => "Hi {user_first_name},\n\n{content_title} is unlocked and ready for you.\n\nOpen it: {content_url}\n\n— {site_name}",
		],
		self::EVENT_WELCOME          => [
			'subject' => 'Welcome to {site_name}',
			'body'    => "Hi {user_first_name},\n\nWelcome to {site_name}. Your portal is at {portal_url}.\n\nSet your password to sign in: {set_password_url}\n\n— {site_name}",
		],
		self::EVENT_EXPIRY_WARNING   => [
			'subject' => '{site_name}: your membership expires {expiry_date}',
			'body'    => "Hi {user_first_name},\n\nA reminder that your membership at {site_name} expires {expiry_date}.\n\nRenew at: {portal_url}\n\n— {site_name}",
		],
		self::EVENT_EXPIRED          => [
			'subject' => '{site_name}: your membership has expired',
			'body'    => "Hi {user_first_name},\n\nYour membership at {site_name} expired on {expiry_date}. To restore access, visit {portal_url}.\n\n— {site_name}",
		],
		self::EVENT_ORG_SUSPENDED    => [
			'subject' => '{site_name}: {user_company} access paused',
			'body'    => "Hi {user_first_name},\n\nAccess for {user_company} is temporarily paused. Members can still see what they had before; new downloads are unavailable until reactivation.\n\n— {site_name}",
		],
		self::EVENT_ALERT_POSTED     => [
			'subject' => '{site_name}: {alert_title}',
			'body'    => "Hi {user_first_name},\n\n{alert_title}\n\n{alert_body}\n\nIt is at the top of your portal: {portal_url}\n\n— {site_name}",
		],
		self::EVENT_INTAKE_SUBMITTED => [
			'subject' => '{site_name}: discovery answers for {project_title}',
			'body'    => "{submitter_name} sent discovery answers for {project_title}.\n\n{changes}\n\nOpen the project: {project_url}\n\n— {site_name}",
		],
	];

	/**
	 * Exposes the built-in defaults so the Settings UI can show "Reset to
	 * default" without duplicating these strings. Returns a copy so callers
	 * can't mutate the constant.
	 *
	 * @return array<string, array{subject:string, body:string}>
	 */
	public static function defaults(): array {
		return self::DEFAULTS;
	}

	/**
	 * @param array<string, mixed> $tokens
	 * @return array{subject: string, body: string}
	 */
	public function render( string $event, array $tokens ): array {
		$templates = (array) get_option( 'monstera_notification_templates', [] );
		$tpl       = $templates[ $event ] ?? self::DEFAULTS[ $event ] ?? null;
		if ( ! $tpl ) {
			return [
				'subject' => '',
				'body'    => '',
			];
		}

		$tokens = $this->withDefaults( $tokens );
		$tokens = apply_filters( Hooks::FILTER_NOTIFICATION_TOKENS, $tokens, $event );

		$subject = $this->replace( (string) $tpl['subject'], $tokens );
		$body    = $this->replace( (string) $tpl['body'], $tokens );
		$body    = (string) apply_filters( Hooks::FILTER_NOTIFICATION_BODY, $body, $event, $tokens );

		return [
			'subject' => $subject,
			'body'    => $body,
		];
	}

	/**
	 * @param array<string, mixed> $tokens
	 */
	private function replace( string $template, array $tokens ): string {
		$keys = array_keys( $tokens );
		$find = array_map( static fn ( $k ) => '{' . $k . '}', $keys );
		return str_replace( $find, array_values( $tokens ), $template );
	}

	/**
	 * @param array<string, mixed> $tokens
	 * @return array<string, mixed>
	 */
	private function withDefaults( array $tokens ): array {
		return array_merge(
			[
				'site_name'        => get_bloginfo( 'name' ),
				'portal_url'       => Routing::url( Routing::ROUTE_DASHBOARD ),
				'login_url'        => wp_login_url(),
				// Defaults to empty so a stray {set_password_url} in a non-welcome
				// template never leaks as a raw token; the welcome path overrides
				// it with a real one-time link (caller tokens win on merge).
				'set_password_url' => '',
			],
			$tokens
		);
	}
}
