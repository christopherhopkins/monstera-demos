<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\BackgroundSync\Cron;
use Monstera\Core\Hooks;
use Monstera\Core\Module;

final class NotificationsModule implements Module {

	public function slug(): string {
		return 'notifications';
	}

	public function boot(): void {
		$dispatcher = new Dispatcher( new TemplateEngine() );

		add_action( Hooks::CONTENT_PUBLISHED, [ $dispatcher, 'onContentPublished' ], 10, 1 );
		add_action( Hooks::CONTENT_UPDATED, [ $dispatcher, 'onContentUpdated' ], 10, 1 );
		add_action( Hooks::CONTENT_UNLOCKED, [ $dispatcher, 'onContentUnlocked' ], 10, 1 );
		add_action( Hooks::MEMBER_CREATED, [ $dispatcher, 'onMemberCreated' ], 10, 1 );
		add_action( Hooks::ORG_STATUS_CHANGED, [ $dispatcher, 'onOrgStatusChanged' ], 10, 2 );
		add_action( Hooks::ALERT_POSTED, [ $dispatcher, 'onAlertPosted' ], 10, 2 );
		add_action( Hooks::PROJECT_INTAKE_SUBMITTED, [ $dispatcher, 'onIntakeSubmitted' ], 10, 4 );
		add_action( Dispatcher::QUEUE_HOOK, [ $dispatcher, 'processQueue' ], 10, 1 );

		add_action( Cron::DAILY_EXPIRATION, [ Expiration::class, 'dispatch' ] );
	}

	public function registerPostTypes(): void {}
}
