<?php
/**
 * The emails a sent form sets off.
 *
 * A submission tells the form's recipients what was sent: each address
 * the author listed and, with the switch on, the admins and managers of
 * the organization the member sent it through, who hear through the
 * batch queue (Dispatcher) as an audience does. The member hears at once
 * that their answers arrived, in the form's own confirmation sentence.
 * Nobody is told of their own send twice: the sender is left off the
 * recipients, the confirmation being theirs, and a lead who is also a
 * listed address hears as the address. The leads read what the Downloader
 * lets them (mayReadSubmission(), FR6): the answers for a form their
 * organization built, who sent it and when for staff's. Each email is a
 * TemplateEngine template an admin can edit, and each attempt that
 * rendered is a notification-log row with what wp_mail() accepted.
 */

declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Content\Downloader;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Modules;
use Monstera\Core\Routing;
use Monstera\Forms\Meta;
use Monstera\Forms\Submissions;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Roster;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class FormNotifier {

	public function __construct( private TemplateEngine $templates ) {}

	/**
	 * A member sent a form (Hooks::FORM_SUBMITTED): the member hears it
	 * arrived, the recipients hear what was sent. Nothing with the module
	 * off, since nobody could open what the email points at.
	 */
	public function onSubmitted( int $submissionId, int $formId, int $userId ): void {
		if ( ! Modules::isActive( Modules::FORMS ) ) {
			return;
		}
		$submission = Submissions::find( $submissionId );
		if ( ! $submission || (int) $submission['form_id'] !== $formId ) {
			return;
		}
		$member = get_userdata( $userId );
		$tokens = $this->tokens( $submission );

		if ( $member instanceof WP_User && '' !== $member->user_email ) {
			$this->toMember( $member, $submission, $tokens );
		}

		$recipients = Meta::recipientsOf( $formId );
		$own        = $member ? strtolower( (string) $member->user_email ) : '';
		$orgId      = (int) $submission['org_id'];

		// The organization's leads (less the sender) by address: one listed
		// by address hears as a lead all the same, with the Manage link and
		// the checks the queue makes as it goes, whatever the switch says.
		// The team, who open wp-admin, hear by address as staff do.
		$leadByAddress = [];
		if ( $orgId > 0 ) {
			foreach ( array_diff( Roster::memberIds( $orgId, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ] ), [ $userId ] ) as $leadId ) {
				$lead = get_userdata( (int) $leadId );
				if ( $lead && '' !== $lead->user_email ) {
					$leadByAddress[ strtolower( (string) $lead->user_email ) ] = $lead;
				}
			}
		}

		$leads    = [];
		$heard    = [];
		$adminUrl = admin_url( 'admin.php?page=monstera-forms&id=' . $formId . '&submission=' . $submissionId );
		foreach ( $recipients['emails'] as $to ) {
			$to = strtolower( $to );
			if ( $to === $own ) {
				continue;
			}
			$heard[ $to ] = true;
			$lead         = $leadByAddress[ $to ] ?? null;
			if ( $lead && ! user_can( $lead, Capabilities::CAP_MANAGE_MONSTERA ) ) {
				$leads[] = (int) $lead->ID;
				continue;
			}
			$this->toAddress( $to, $submission, array_merge( $tokens, [ 'submission_url' => $adminUrl ] ) );
		}
		if ( $recipients['org_leads'] ) {
			foreach ( $leadByAddress as $address => $lead ) {
				if ( ! isset( $heard[ $address ] ) ) {
					$leads[] = (int) $lead->ID;
				}
			}
		}

		// Through the batch queue, each once.
		if ( $leads ) {
			( new Dispatcher( $this->templates ) )->queueFormSubmitted( $formId, $submissionId, array_values( array_unique( $leads ) ) );
		}
	}

	/**
	 * One batch of the leads' email (Dispatcher::processQueue()): each who
	 * still manages the organization the submission was sent through hears,
	 * with the Manage page as where to read it, and with the answers only
	 * where the Downloader would show them (a form their organization
	 * built; a staff form's answers are between the member and the site).
	 * A form no longer published sends nothing.
	 *
	 * @param int[] $userIds
	 * @return int How many wp_mail() accepted.
	 */
	public function sendToLeads( int $formId, int $submissionId, array $userIds ): int {
		$submission = Submissions::find( $submissionId );
		if ( ! $submission || (int) $submission['form_id'] !== $formId || ! Modules::isActive( Modules::FORMS ) || 'publish' !== get_post_status( $formId ) ) {
			return 0;
		}
		$orgId  = (int) $submission['org_id'];
		$tokens = array_merge( $this->tokens( $submission ), [ 'submission_url' => self::manageUrl( $orgId ) ] );
		$sent   = 0;
		foreach ( $userIds as $userId ) {
			$lead = get_userdata( (int) $userId );
			// Asked as the batch goes: a lead demoted or removed since is not told.
			if ( ! $lead instanceof WP_User || '' === $lead->user_email || ! in_array( Roster::roleOf( (int) $lead->ID, $orgId ), [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ], true ) ) {
				continue;
			}
			$theirs   = Downloader::mayReadSubmission( $lead, $submission ) ? $tokens : array_merge( $tokens, [ 'answers' => '' ] );
			$rendered = $this->render( TemplateEngine::EVENT_FORM_SUBMITTED, $theirs + [ 'user_first_name' => $lead->first_name ?: $lead->display_name ] );
			if ( ! $rendered ) {
				continue;
			}
			$delivered = (bool) wp_mail( $lead->user_email, $rendered['subject'], $rendered['body'], self::headers() );
			if ( $delivered ) {
				do_action( Hooks::NOTIFICATION_SENT, (int) $lead->ID, TemplateEngine::EVENT_FORM_SUBMITTED, $rendered, $orgId );
				++$sent;
			}
			$this->log( (int) $lead->ID, TemplateEngine::EVENT_FORM_SUBMITTED, $delivered, $submission, [] );
		}
		return $sent;
	}

	/**
	 * The due reminder (BackgroundSync\Tasks\FormReminders): the form, its
	 * due day and where to fill it in. Returns whether wp_mail() accepted
	 * it, or null when the template rendered empty and nothing was sent;
	 * the task keeps the log, which also tells it what went in which window.
	 */
	public function sendDueReminder( WP_User $user, int $formId ): ?bool {
		$rendered = $this->render(
			TemplateEngine::EVENT_FORM_DUE_REMINDER,
			[
				'user_first_name' => $user->first_name ?: $user->display_name,
				'form_title'      => self::plainTitle( $formId ),
				'due_date'        => Meta::dueOn( $formId ),
				'form_url'        => self::formUrl( $formId ),
			]
		);
		if ( ! $rendered ) {
			return null;
		}
		$delivered = (bool) wp_mail( $user->user_email, $rendered['subject'], $rendered['body'], self::headers() );
		if ( $delivered ) {
			do_action( Hooks::NOTIFICATION_SENT, (int) $user->ID, TemplateEngine::EVENT_FORM_DUE_REMINDER, $rendered, Reach::ofForm( (int) $user->ID, $formId ) );
		}
		return $delivered;
	}

	/**
	 * The confirmation, to the member who sent the form, at once.
	 *
	 * @param array<string, mixed>  $submission
	 * @param array<string, string> $tokens
	 */
	private function toMember( WP_User $member, array $submission, array $tokens ): void {
		$formId   = (int) $submission['form_id'];
		$rendered = $this->render(
			TemplateEngine::EVENT_FORM_CONFIRMATION,
			$tokens + [
				'user_first_name' => $member->first_name ?: $member->display_name,
				'confirmation'    => Meta::confirmationOf( $formId ),
			]
		);
		if ( ! $rendered ) {
			return;
		}
		$delivered = (bool) wp_mail( $member->user_email, $rendered['subject'], $rendered['body'], self::headers() );
		if ( $delivered ) {
			do_action( Hooks::NOTIFICATION_SENT, (int) $member->ID, TemplateEngine::EVENT_FORM_CONFIRMATION, $rendered, (int) $submission['org_id'] );
		}
		$this->log( (int) $member->ID, TemplateEngine::EVENT_FORM_CONFIRMATION, $delivered, $submission, [] );
	}

	/**
	 * One email to a recipient address the author listed.
	 *
	 * @param array<string, mixed>  $submission
	 * @param array<string, string> $tokens
	 */
	private function toAddress( string $to, array $submission, array $tokens ): void {
		$rendered = $this->render( TemplateEngine::EVENT_FORM_SUBMITTED, $tokens );
		if ( ! $rendered ) {
			return;
		}
		$delivered = (bool) wp_mail( $to, $rendered['subject'], $rendered['body'], self::headers() );
		$recipient = get_user_by( 'email', $to );
		if ( $delivered && $recipient ) {
			do_action( Hooks::NOTIFICATION_SENT, (int) $recipient->ID, TemplateEngine::EVENT_FORM_SUBMITTED, $rendered, (int) $submission['org_id'] );
		}
		$this->log( $recipient ? (int) $recipient->ID : 0, TemplateEngine::EVENT_FORM_SUBMITTED, $delivered, $submission, [ 'to' => $to ] );
	}

	/**
	 * The submission's tokens: the form, who sent it, the organization it
	 * was sent through, the answers one line per question.
	 *
	 * @param array<string, mixed> $submission
	 * @return array<string, string>
	 */
	private function tokens( array $submission ): array {
		$formId = (int) $submission['form_id'];
		$sender = get_userdata( (int) $submission['user_id'] );
		$orgId  = (int) $submission['org_id'];
		return [
			'form_title'     => self::plainTitle( $formId ),
			'submitter_name' => $sender ? UserMeta::fullName( $sender ) : __( 'A former member', 'monstera' ),
			'user_company'   => $orgId > 0 ? self::plainTitle( $orgId ) : '',
			'answers'        => self::answersText( $submission ),
			'form_url'       => self::formUrl( $formId ),
			'submission_url' => '',
			'due_date'       => Meta::dueOn( $formId ),
		];
	}

	/**
	 * The answers as the email prints them: "label: value", one per
	 * question in the form's order, a file question's files by name, and
	 * last the removed questions that were answered, under their keys.
	 *
	 * @param array<string, mixed> $submission
	 */
	public static function answersText( array $submission ): string {
		$formId = (int) $submission['form_id'];
		$files  = Submissions::filesOf( (int) $submission['id'] );
		$lines  = [];
		$keys   = [];
		foreach ( Meta::fieldsOf( $formId ) as $question ) {
			$key          = (string) $question['key'];
			$keys[ $key ] = true;
			$lines[]      = sprintf( '%s: %s', $question['label'], self::answerText( $submission['answers'][ $key ] ?? '', $files[ $key ] ?? [] ) );
		}
		foreach ( Submissions::removedKeys( $formId, [ $submission ] ) as $key ) {
			if ( ! isset( $keys[ $key ] ) ) {
				$lines[] = sprintf( '%s: %s', $key, self::answerText( $submission['answers'][ $key ] ?? '', $files[ $key ] ?? [] ) );
			}
		}
		return implode( "\n", $lines );
	}

	/**
	 * @param mixed                            $answer A value, or a file question's list of ids.
	 * @param list<array{name: string}>        $files  The question's files.
	 */
	private static function answerText( mixed $answer, array $files ): string {
		if ( is_array( $answer ) ) {
			return implode( ', ', array_map( static fn ( array $file ): string => (string) $file['name'], $files ) );
		}
		return trim( html_entity_decode( wp_strip_all_tags( (string) $answer ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	}

	/**
	 * Where a member opens the form: its own page (`/portal/forms/{id}/`).
	 */
	public static function formUrl( int $formId ): string {
		return Routing::url( Routing::ROUTE_FORM, [ 'id' => $formId ] );
	}

	/** Where an organization's lead reads a submission: the hub's Manage tab. */
	private static function manageUrl( int $orgId ): string {
		$slug = $orgId > 0 ? (string) get_post_field( 'post_name', $orgId ) : '';
		return '' !== $slug
			? add_query_arg( 'tab', 'manage', Routing::url( Routing::ROUTE_ORG, [ 'slug' => $slug ] ) )
			: Routing::url( Routing::ROUTE_DASHBOARD );
	}

	/**
	 * @param array<string, string> $tokens
	 * @return array{subject: string, body: string}|null Null when the template is empty: nothing is sent.
	 */
	private function render( string $event, array $tokens ): ?array {
		$rendered         = $this->templates->render( $event, $tokens );
		$rendered['body'] = trim( (string) preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $rendered['body'] ) ) );
		return '' !== $rendered['subject'] && '' !== $rendered['body'] ? $rendered : null;
	}

	/** @return list<string> */
	private static function headers(): array {
		return [
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', get_bloginfo( 'name' ), get_option( 'admin_email' ) ),
		];
	}

	/** A post's title as an email reads it: no entities. */
	private static function plainTitle( int $postId ): string {
		return trim( html_entity_decode( wp_strip_all_tags( (string) get_post_field( 'post_title', $postId, 'raw' ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	}

	/**
	 * One row per attempt, with wp_mail()'s answer.
	 *
	 * @param array<string, mixed>  $submission
	 * @param array<string, string> $meta What else the row should say (the address, for one that is nobody's account).
	 */
	private function log( int $userId, string $event, bool $delivered, array $submission, array $meta ): void {
		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
			[
				'member_id'  => $userId,
				'event_type' => $event,
				'channel'    => 'email',
				'delivered'  => $delivered ? 1 : 0,
				'sent_at'    => current_time( 'mysql', true ),
				'meta'       => (string) wp_json_encode(
					[
						'form_id'       => (int) $submission['form_id'],
						'submission_id' => (int) $submission['id'],
					] + $meta
				),
			],
			[ '%d', '%s', '%s', '%d', '%s', '%s' ]
		);
	}
}
