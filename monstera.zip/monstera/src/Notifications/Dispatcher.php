<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertRepository;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Projects\Discovery;
use Monstera\Projects\IntakeFiles;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_User;

final class Dispatcher {

	public function __construct( private TemplateEngine $templates ) {}

	/** The cron hook that sends the next batch of a post's queued email (its argument). */
	public const QUEUE_HOOK = 'monstera_email_queue';

	/** Post meta: the email still to go, a list of [ 'event' => string, 'ids' => int[] ]. */
	private const KEY_QUEUE = 'monstera_email_queue';

	/** How many go with one request, unless Hooks::FILTER_EMAIL_BATCH_SIZE says otherwise. */
	private const BATCH = 50;

	public function onContentPublished( int $contentId ): void {
		$this->queue( $contentId, TemplateEngine::EVENT_NEW_CONTENT, $this->recipientsForContent( $contentId ) );
	}

	public function onContentUpdated( int $contentId ): void {
		$this->queue( $contentId, TemplateEngine::EVENT_UPDATED_CONTENT, $this->recipientsForContent( $contentId ) );
	}

	public function onContentUnlocked( int $contentId ): void {
		$this->queue( $contentId, TemplateEngine::EVENT_CONTENT_UNLOCKED, $this->recipientsForContent( $contentId ) );
	}

	/**
	 * Email to an audience goes in batches: the first with the request that
	 * asked for it, the rest a minute apart from cron, so a save never waits
	 * on thousands of sends and a timeout cannot lose the remainder.
	 *
	 * @param int[] $ids Recipients' user ids.
	 */
	private function queue( int $postId, string $event, array $ids ): void {
		if ( ! $ids ) {
			return;
		}
		$jobs   = $this->jobs( $postId );
		$jobs[] = [
			'event' => $event,
			'ids'   => array_values( array_unique( array_map( 'intval', $ids ) ) ),
		];
		update_post_meta( $postId, self::KEY_QUEUE, $jobs );
		$this->processQueue( $postId );
	}

	/**
	 * Send the next batch of a post's queued email and schedule the one
	 * after it. The queue is saved before anything is sent, so a batch that
	 * dies partway is not sent twice.
	 */
	public function processQueue( int $postId ): void {
		$jobs = $this->jobs( $postId );
		if ( ! $jobs ) {
			wp_clear_scheduled_hook( self::QUEUE_HOOK, [ $postId ] );
			return;
		}
		$size  = max( 1, (int) apply_filters( Hooks::FILTER_EMAIL_BATCH_SIZE, self::BATCH ) );
		$job   = array_shift( $jobs );
		$batch = array_splice( $job['ids'], 0, $size );
		if ( $job['ids'] ) {
			array_unshift( $jobs, $job );
		}
		if ( $jobs ) {
			update_post_meta( $postId, self::KEY_QUEUE, $jobs );
		} else {
			delete_post_meta( $postId, self::KEY_QUEUE );
		}

		$isAlert   = TemplateEngine::EVENT_ALERT_POSTED === $job['event'];
		$delivered = 0;
		foreach ( $batch as $userId ) {
			$user = get_user_by( 'id', $userId );
			if ( ! $user instanceof WP_User ) {
				continue;
			}
			$sent = $this->send( $user, $job['event'], $this->tokensFor( $postId, $job['event'], $user ) );
			$this->log( $user->ID, $isAlert ? null : $postId, $job['event'], $sent );
			$delivered += $sent ? 1 : 0;
		}
		if ( $isAlert ) {
			// The composer's "Email sent to N members", counted as it goes.
			update_post_meta( $postId, AlertMeta::KEY_EMAIL_SENT, (int) get_post_meta( $postId, AlertMeta::KEY_EMAIL_SENT, true ) + $delivered );
		}

		if ( ! $jobs ) {
			wp_clear_scheduled_hook( self::QUEUE_HOOK, [ $postId ] );
		} elseif ( ! wp_next_scheduled( self::QUEUE_HOOK, [ $postId ] ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::QUEUE_HOOK, [ $postId ] );
		}
	}

	/**
	 * @return list<array{event: string, ids: int[]}>
	 */
	private function jobs( int $postId ): array {
		$jobs = get_post_meta( $postId, self::KEY_QUEUE, true );
		return is_array( $jobs )
			? array_values( array_filter( $jobs, static fn ( $job ): bool => is_array( $job ) && isset( $job['event'], $job['ids'] ) && is_array( $job['ids'] ) ) )
			: [];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function tokensFor( int $postId, string $event, WP_User $user ): array {
		if ( TemplateEngine::EVENT_ALERT_POSTED !== $event ) {
			return $this->contentTokens( $postId, $user );
		}
		return array_merge(
			$this->userTokens( $user ),
			[
				'alert_title' => self::plainTitle( $postId ),
				'alert_body'  => self::plain( (string) get_post_field( 'post_content', $postId, 'raw' ) ),
			]
		);
	}

	/** A title as it was written: the emails are plain text, so no entities. */
	private static function plainTitle( int $postId ): string {
		return self::plain( (string) get_post_field( 'post_title', $postId, 'raw' ) );
	}

	private static function plain( string $html ): string {
		return trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	}

	public function onMemberCreated( int $userId ): void {
		$this->sendWelcome( $userId );
	}

	/**
	 * Send the welcome email to one member. A member is created with a random
	 * password they never see, so the email carries a one-time set-password link
	 * instead of a plain login URL. Generated here (the single choke point) so
	 * every path — creation, org-admin invite, the admin's bulk resend — gets a
	 * working link without leaking the key past the email.
	 *
	 * @return bool False when the user does not exist or has no email address.
	 */
	public function sendWelcome( int $userId ): bool {
		$user = get_user_by( 'id', $userId );
		if ( ! $user || '' === $user->user_email ) {
			return false;
		}
		$tokens                     = $this->userTokens( $user );
		$tokens['set_password_url'] = $this->setPasswordUrl( $user );
		$delivered                  = $this->send( $user, TemplateEngine::EVENT_WELCOME, $tokens );
		$this->log( $userId, null, TemplateEngine::EVENT_WELCOME, $delivered );
		return true;
	}

	/**
	 * Build a one-time set-password link for a freshly created member, mirroring
	 * the URL core's retrieve_password() generates (wp-login.php?action=rp) so
	 * the recipient lands on WordPress's "set your password" screen rather than a
	 * login form they have no password for. Scoped to the welcome path only:
	 * get_password_reset_key() rotates the user activation key, so it must not run
	 * on every notification. Returns '' (the template's {login_url} still
	 * resolves) when password reset is disabled for the user.
	 */
	private function setPasswordUrl( WP_User $user ): string {
		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			return '';
		}
		return network_site_url(
			'wp-login.php?action=rp&key=' . rawurlencode( $key ) . '&login=' . rawurlencode( $user->user_login ),
			'login'
		);
	}

	/**
	 * Send a membership-expiry notice (warning or expired) to a user, with the
	 * org context so {expiry_date}/{user_company} resolve. Called by the daily
	 * Expiration cron.
	 */
	public function onMembershipExpiry( int $userId, int $orgId, string $event ): void {
		if ( ! in_array( $event, [ TemplateEngine::EVENT_EXPIRY_WARNING, TemplateEngine::EVENT_EXPIRED ], true ) ) {
			return;
		}
		$user = get_user_by( 'id', $userId );
		if ( ! $user ) {
			return;
		}
		$delivered = $this->send( $user, $event, $this->userTokens( $user, $orgId ) );
		$this->log( $userId, null, $event, $delivered );
	}

	public function onOrgStatusChanged( int $orgId, string $newStatus ): void {
		if ( 'suspended' !== $newStatus ) {
			return;
		}
		$repo    = new OrgRepository();
		$members = get_users(
			[
				'meta_key'   => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
				'meta_value' => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
				'fields'     => 'all',
				'number'     => -1,
			]
		);
		foreach ( $members as $member ) {
			$delivered = $this->send( $member, TemplateEngine::EVENT_ORG_SUSPENDED, $this->userTokens( $member, $orgId ) );
			$this->log( $member->ID, null, TemplateEngine::EVENT_ORG_SUSPENDED, $delivered );
		}
	}

	/**
	 * "Also send by email" on an alert: one email to each member it reaches,
	 * on its first post only, with the number sent stored for the composer.
	 * Later saves, and posting it again after it ended, send nothing.
	 */
	public function onAlertPosted( int $alertId, bool $first = true ): void {
		if ( ! $first
			|| ! (bool) get_post_meta( $alertId, AlertMeta::KEY_NOTIFY_BY_EMAIL, true )
			|| '' !== (string) get_post_meta( $alertId, AlertMeta::KEY_EMAIL_SENT, true )
		) {
			return;
		}
		// Written first: the first post's one chance is spent from here on.
		update_post_meta( $alertId, AlertMeta::KEY_EMAIL_SENT, 0 );
		$this->queue( $alertId, TemplateEngine::EVENT_ALERT_POSTED, ( new AlertRepository() )->recipientIds( AlertRepository::audienceOf( $alertId ) ) );
	}

	/**
	 * The members who can open the item: its audience (everyone, its
	 * organizations' members and the standalone members it names), less
	 * anyone the engine turns away. The sub-group gate, the project gate,
	 * the visibility setting and a suspended organization all count, so
	 * nobody is emailed a link that answers 403. Monstera admins are staff,
	 * not the audience.
	 *
	 * @return int[]
	 */
	private function recipientsForContent( int $contentId ): array {
		$roles = [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ];
		if ( (bool) get_post_meta( $contentId, ContentMeta::KEY_AUDIENCE_EVERYONE, true ) ) {
			$candidates = get_users(
				[
					'role__in' => $roles,
					'fields'   => 'all',
					'number'   => -1,
				]
			);
		} else {
			$candidates = [];
			$orgIds     = array_filter( array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true ) ) );
			$named      = array_filter( array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_STANDALONE_MEMBER_IDS, true ) ) );
			if ( $orgIds ) {
				$candidates = get_users(
					[
						'meta_key'     => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
						'meta_value'   => array_map( 'strval', $orgIds ), // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
						'meta_compare' => 'IN',
						'role__in'     => $roles,
						'fields'       => 'all',
						'number'       => -1,
					]
				);
			}
			if ( $named ) {
				$candidates = array_merge(
					$candidates,
					get_users(
						[
							'include' => array_values( $named ),
							'fields'  => 'all',
							'number'  => -1,
						]
					)
				);
			}
		}

		$visibility = new Visibility( new SubgroupRepository(), new ProjectRepository() );
		$out        = [];
		foreach ( $candidates as $user ) {
			if ( ! isset( $out[ $user->ID ] ) && $visibility->userCanSee( $user, $contentId ) ) {
				$out[ $user->ID ] = (int) $user->ID;
			}
		}
		return array_values( $out );
	}

	/**
	 * @return array<string, mixed>
	 */
	private function contentTokens( int $contentId, WP_User $user ): array {
		return array_merge(
			$this->userTokens( $user ),
			[
				'content_title' => self::plainTitle( $contentId ),
				'content_url'   => Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $contentId ] ),
				'summary'       => self::plain( (string) get_post_meta( $contentId, ContentMeta::KEY_SUMMARY, true ) ),
			]
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	private function userTokens( WP_User $user, ?int $orgIdOverride = null ): array {
		$orgId   = $orgIdOverride ?: UserMeta::associatedOrg( $user->ID );
		$expires = (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );
		if ( ! $expires && $orgId ) {
			$expires = (string) get_post_meta( $orgId, 'monstera_membership_expires', true );
		}

		return [
			'user_name'       => $user->display_name,
			'user_first_name' => $user->first_name ?: $user->display_name,
			'user_email'      => $user->user_email,
			'user_company'    => $orgId ? self::plainTitle( $orgId ) : '',
			'expiry_date'     => $expires ?: __( 'soon', 'monstera' ),
		];
	}

	/**
	 * Renders and sends one email. Returns whether wp_mail() accepted it, or
	 * null when the template rendered empty and nothing was sent.
	 *
	 * @param array<string, mixed> $tokens
	 */
	private function send( WP_User $user, string $event, array $tokens ): ?bool {
		$rendered = $this->templates->render( $event, $tokens );
		if ( ! $rendered['subject'] || ! $rendered['body'] ) {
			return null;
		}
		$headers   = [
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', get_bloginfo( 'name' ), get_option( 'admin_email' ) ),
		];
		$delivered = (bool) wp_mail( $user->user_email, $rendered['subject'], $rendered['body'], $headers );
		// "Sent" is what wp_mail() accepted: activity never says an email went
		// that did not. The notification log keeps the refusal.
		if ( $delivered ) {
			do_action( Hooks::NOTIFICATION_SENT, $user->ID, $event, $rendered );
		}
		return $delivered;
	}

	/**
	 * Post meta: the newest intake file the agency has been told about, by
	 * id. Ids, not times: a file stored in the same second as a submission
	 * is still told apart.
	 */
	public const KEY_INTAKE_REPORTED_FILE = '_monstera_intake_reported_file';

	/** @var array<int, bool> Whether this request's submit told the agency, by project. */
	private static array $intakeNotified = [];

	/**
	 * A client submitted discovery: tell the agency what is new, the
	 * questions whose answers changed and the files added since the
	 * previous submission, in one email to each address the
	 * monstera/intake_recipients filter gives (the site's admin email by
	 * default). Nothing new, nothing sent.
	 *
	 * @param list<string> $keys    The questions the submit carried.
	 * @param list<string> $changed The questions whose answers changed.
	 */
	public function onIntakeSubmitted( int $projectId, int $userId, array $keys = [], array $changed = [] ): void {
		unset( $keys );
		self::$intakeNotified[ $projectId ] = false;
		// Before the first submission every file is new.
		$reported = (int) get_post_meta( $projectId, self::KEY_INTAKE_REPORTED_FILE, true );
		$newest   = $reported;

		$labels  = array_column( Discovery::schema( $projectId ), 'label', 'key' );
		$answers = array_map( static fn ( $key ): string => (string) ( $labels[ $key ] ?? $key ), $changed );
		$added   = [];
		foreach ( ( new IntakeFiles() )->forProject( $projectId ) as $key => $files ) {
			foreach ( $files as $file ) {
				if ( $file['id'] > $reported ) {
					$added[] = sprintf( '%s: %s (%s)', $labels[ $key ] ?? $key, $file['name'], size_format( $file['size'] ) );
					$newest  = max( $newest, $file['id'] );
				}
			}
		}
		update_post_meta( $projectId, self::KEY_INTAKE_REPORTED_FILE, $newest );
		if ( ! $answers && ! $added ) {
			return;
		}

		$lines = [];
		if ( $answers ) {
			$lines[] = __( 'Answers changed:', 'monstera' );
			foreach ( $answers as $label ) {
				$lines[] = '- ' . $label;
			}
			$lines[] = '';
		}
		if ( $added ) {
			$lines[] = __( 'Files added:', 'monstera' );
			foreach ( $added as $line ) {
				$lines[] = '- ' . $line;
			}
		}
		$submitter = get_userdata( $userId );
		$rendered  = $this->templates->render(
			TemplateEngine::EVENT_INTAKE_SUBMITTED,
			[
				'project_title'  => self::plainTitle( $projectId ),
				'submitter_name' => $submitter ? UserMeta::fullName( $submitter ) : __( 'Someone', 'monstera' ),
				'changes'        => trim( implode( "\n", $lines ) ),
				'project_url'    => admin_url( 'admin.php?page=monstera-projects&id=' . $projectId ),
			]
		);
		if ( ! $rendered['subject'] || ! $rendered['body'] ) {
			return;
		}

		$recipients = (array) apply_filters( Hooks::FILTER_INTAKE_RECIPIENTS, [ get_option( 'admin_email' ) ], $projectId );
		$headers    = [
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', get_bloginfo( 'name' ), get_option( 'admin_email' ) ),
		];
		foreach ( array_unique( array_filter( array_map( 'sanitize_email', array_map( 'strval', $recipients ) ), 'is_email' ) ) as $to ) {
			$delivered = (bool) wp_mail( $to, $rendered['subject'], $rendered['body'], $headers );
			$recipient = get_user_by( 'email', $to );
			global $wpdb;
			$wpdb->insert(
				Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
				[
					'member_id'  => $recipient ? (int) $recipient->ID : 0,
					'event_type' => TemplateEngine::EVENT_INTAKE_SUBMITTED,
					'channel'    => 'email',
					'delivered'  => $delivered ? 1 : 0,
					'sent_at'    => current_time( 'mysql', true ),
					'meta'       => (string) wp_json_encode(
						[
							'project_id' => $projectId,
							'to'         => $to,
						]
					),
				],
				[ '%d', '%s', '%s', '%d', '%s', '%s' ]
			);
			self::$intakeNotified[ $projectId ] = self::$intakeNotified[ $projectId ] || $delivered;
		}
	}

	/**
	 * Whether this request's discovery submit told the agency, for the
	 * submit route's answer: the portal claims only a notification that went.
	 */
	public static function intakeNotified( int $projectId ): bool {
		return self::$intakeNotified[ $projectId ] ?? false;
	}

	/**
	 * One row per attempt, with wp_mail()'s answer (the dashboard's outgoing
	 * email health reads it). An empty render sent nothing and leaves no row.
	 */
	private function log( int $userId, ?int $contentId, string $event, ?bool $delivered ): void {
		if ( null === $delivered ) {
			return;
		}
		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
			[
				'member_id'  => $userId,
				'content_id' => $contentId,
				'event_type' => $event,
				'channel'    => 'email',
				'delivered'  => $delivered ? 1 : 0,
				'sent_at'    => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s', '%s', '%d', '%s' ]
		);
	}
}
