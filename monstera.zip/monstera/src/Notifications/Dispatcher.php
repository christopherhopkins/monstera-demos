<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\AccessControl\PortalGuard;
use Monstera\Alerts\Meta as AlertMeta;
use Monstera\Alerts\Repository as AlertRepository;
use Monstera\Content\Meta as ContentMeta;
use Monstera\Content\Visibility;
use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\AuthorScope;
use Monstera\Projects\Discovery;
use Monstera\Projects\IntakeFiles;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Dispatcher {

	public function __construct( private TemplateEngine $templates ) {}

	/** The cron hook that sends the next batch of a post's queued email (its argument). */
	public const QUEUE_HOOK = 'monstera_email_queue';

	/** Post meta: the email still to go, a list of [ 'event' => string, 'ids' => int[] ]. */
	private const KEY_QUEUE = 'monstera_email_queue';

	/** How many go with one request, unless Hooks::FILTER_EMAIL_BATCH_SIZE says otherwise. */
	private const BATCH = 50;

	public function onContentPublished( int $contentId ): void {
		$this->queue( $contentId, TemplateEngine::EVENT_NEW_CONTENT, self::actorsPart( $contentId, $this->recipientsForContent( $contentId ) ) );
	}

	public function onContentUpdated( int $contentId ): void {
		$this->queue( $contentId, TemplateEngine::EVENT_UPDATED_CONTENT, self::actorsPart( $contentId, $this->recipientsForContent( $contentId ) ) );
	}

	public function onContentUnlocked( int $contentId ): void {
		$this->queue( $contentId, TemplateEngine::EVENT_CONTENT_UNLOCKED, self::actorsPart( $contentId, $this->recipientsForContent( $contentId ) ) );
	}

	/**
	 * Who of an item's recipients its author's act emails (the owner,
	 * 2026-10-17): their own part of it, the members of each organization
	 * they author it in, or for a leader of the sub-groups they lead there.
	 * An item staff shared with another client, or with everyone, reaches
	 * more, but a client's publish, edit or post emails their own part
	 * alone. Anything else, an act of staff, of nobody signed in (a
	 * scheduled publish) or of someone not acting as its author (the request
	 * cron runs in), emails everyone the item reaches.
	 *
	 * @param int[] $ids
	 * @return int[]
	 */
	private static function actorsPart( int $postId, array $ids ): array {
		// A scheduled publish is WordPress's act, not the signed-in reader's,
		// even when the alternate cron runs it inside their request: it emails
		// everyone it reaches.
		if ( wp_doing_cron() ) {
			return $ids;
		}
		$actor = wp_get_current_user();
		if ( ! $actor->exists() || Capabilities::isStaff( $actor ) || user_can( $actor, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return $ids;
		}
		$theirs = [];
		$acting = false;
		foreach ( AuthorScope::orgIdsOfItem( $postId ) as $orgId ) {
			$scope = AuthorScope::forUser( (int) $actor->ID, $orgId );
			if ( ! $scope->canEdit( $postId ) ) {
				continue;
			}
			$acting  = true;
			$members = $scope->isLeader() ? [] : Roster::memberIds( $orgId );
			foreach ( $scope->isLeader() ? $scope->leaderSubgroupIds : [] as $sgId ) {
				$members = array_merge( $members, ( new SubgroupRepository() )->memberIds( $sgId ) );
			}
			$theirs += array_fill_keys( array_map( 'intval', $members ), true );
		}
		if ( ! $acting ) {
			return $ids;
		}
		return array_values( array_filter( array_map( 'intval', $ids ), static fn ( int $id ): bool => isset( $theirs[ $id ] ) ) );
	}

	/**
	 * Email to an audience goes in batches: the first with the request that
	 * asked for it, the rest a minute apart from cron, so a save never waits
	 * on thousands of sends and a timeout cannot lose the remainder.
	 *
	 * @param int[] $ids Recipients' user ids.
	 */
	private function queue( int $postId, string $event, array $ids ): void {
		if ( ! $ids ) {
			return;
		}
		$jobs   = $this->jobs( $postId );
		$jobs[] = [
			'event' => $event,
			'ids'   => array_values( array_unique( array_map( 'intval', $ids ) ) ),
		];
		update_post_meta( $postId, self::KEY_QUEUE, $jobs );
		$this->processQueue( $postId );
	}

	/**
	 * Send the next batch of a post's queued email and schedule the one
	 * after it. The queue is saved before anything is sent, so a batch that
	 * dies partway is not sent twice.
	 */
	public function processQueue( int $postId ): void {
		$jobs = $this->jobs( $postId );
		// A suspension lifted before its email finished sends no more of it:
		// the organization is not suspended, so the sentence is not true.
		$lifted = array_filter( $jobs, static fn ( array $job ): bool => TemplateEngine::EVENT_ORG_SUSPENDED === $job['event'] && OrgMeta::STATUS_SUSPENDED !== OrgRepository::statusOf( $postId ) );
		if ( $lifted ) {
			$jobs = array_values( array_diff_key( $jobs, $lifted ) );
			if ( $jobs ) {
				update_post_meta( $postId, self::KEY_QUEUE, $jobs );
			} else {
				delete_post_meta( $postId, self::KEY_QUEUE );
			}
		}
		if ( ! $jobs ) {
			wp_clear_scheduled_hook( self::QUEUE_HOOK, [ $postId ] );
			return;
		}
		$size  = max( 1, (int) apply_filters( Hooks::FILTER_EMAIL_BATCH_SIZE, self::BATCH ) );
		$job   = array_shift( $jobs );
		$batch = array_splice( $job['ids'], 0, $size );
		if ( $job['ids'] ) {
			array_unshift( $jobs, $job );
		}
		if ( $jobs ) {
			update_post_meta( $postId, self::KEY_QUEUE, $jobs );
		} else {
			delete_post_meta( $postId, self::KEY_QUEUE );
		}

		$isAlert      = TemplateEngine::EVENT_ALERT_POSTED === $job['event'];
		$isSuspension = TemplateEngine::EVENT_ORG_SUSPENDED === $job['event'];
		$delivered    = 0;
		// Each email names the organization the item reaches its reader
		// through: one read of the batch's memberships, not one per email.
		Roster::prime( $batch );
		// An alert narrowed to sub-groups reaches a person through the groups
		// they are in: who is in each one it names is read once for the batch.
		$alerts     = new AlertRepository();
		$subgroups  = $isAlert ? AlertRepository::namedSubgroupsByMember( $postId ) : [];
		$visibility = new Visibility( new SubgroupRepository(), new ProjectRepository() );
		foreach ( $batch as $userId ) {
			$user = get_user_by( 'id', $userId );
			if ( ! $user instanceof WP_User ) {
				continue;
			}
			$inGroups = $subgroups[ (int) $user->ID ] ?? [];
			// The email goes to the people the portal shows the item to: an
			// alert by the notices band's own decision, a content item by the
			// engine's, unless an ended membership holds it back. Asked as each
			// batch goes, not when the email was queued: a membership may have
			// ended between, or been removed, and the engine turns away
			// someone who was in the audience a minute ago and is not now.
			// A suspension goes to whoever still belongs to the organization,
			// which is the post the queue hangs on.
			if ( $isSuspension ) {
				$shown = Roster::isMemberOf( (int) $user->ID, $postId );
			} else {
				$shown = $isAlert
					? $alerts->reachesPerson( $user, $postId, $inGroups )
					: $visibility->userCanSee( $user, $postId ) && ! self::heldBack( $user, $postId );
			}
			if ( ! $shown ) {
				continue;
			}
			if ( $isSuspension ) {
				$sent = $this->send( $user, $job['event'], $this->userTokens( $user, $postId, $job['event'] ), $postId );
				$this->log( $user->ID, null, $job['event'], $sent );
				$delivered += $sent ? 1 : 0;
				continue;
			}
			// The organization the item reaches this person through: the email
			// names it and the hook passes it on, so its activity row is filed there.
			$orgId = $isAlert ? Reach::ofAlert( (int) $user->ID, $postId, $inGroups ) : Reach::ofContent( (int) $user->ID, $postId );
			$sent  = $this->send( $user, $job['event'], $this->tokensFor( $postId, $job['event'], $user, $orgId ), $orgId );
			$this->log( $user->ID, $isAlert ? null : $postId, $job['event'], $sent );
			$delivered += $sent ? 1 : 0;
		}
		if ( $isAlert ) {
			// The composer's "Email sent to N members", counted as it goes.
			update_post_meta( $postId, AlertMeta::KEY_EMAIL_SENT, (int) get_post_meta( $postId, AlertMeta::KEY_EMAIL_SENT, true ) + $delivered );
		}

		if ( ! $jobs ) {
			wp_clear_scheduled_hook( self::QUEUE_HOOK, [ $postId ] );
		} elseif ( ! wp_next_scheduled( self::QUEUE_HOOK, [ $postId ] ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::QUEUE_HOOK, [ $postId ] );
		}
	}

	/**
	 * Whether a content item is held back from this person by an ended
	 * membership: it reaches them through organizations of theirs whose
	 * membership has ended, and through none still running
	 * (Organizations\Reach::heldBackFor()). The dashboard's feed leaves
	 * such an item out and its page answers "Membership ended", so an email
	 * saying it "is now available in your portal" would lead there. The
	 * feed leaves out by the organization and so does this: an item that
	 * also names the person goes with the rest of that organization's. An
	 * item for everyone names no organization and is nobody's to hold back,
	 * and a person in one organization is held back as one in several is
	 * (the Phase 6 task), as is one none of whose memberships still runs.
	 * A standalone member whose own membership has ended is held back from
	 * everything: every item reaches them through it, and its page answers
	 * "Membership ended" (AccessControl\PortalGuard::ownMembershipExpired()).
	 *
	 * An alert asks the notices band's own decision instead
	 * (Alerts\Repository::reachesPerson()).
	 */
	private static function heldBack( WP_User $user, int $contentId ): bool {
		return PortalGuard::ownMembershipExpired( $user )
			|| Reach::onlyThrough( (int) $user->ID, Reach::contentOrgs( $contentId ), Reach::heldBackFor( $user ) );
	}

	/**
	 * @return list<array{event: string, ids: int[]}>
	 */
	private function jobs( int $postId ): array {
		return self::queued( $postId );
	}

	/**
	 * The email a post still has to send, as queue() stored it.
	 *
	 * @return list<array{event: string, ids: int[]}>
	 */
	private static function queued( int $postId ): array {
		$jobs = get_post_meta( $postId, self::KEY_QUEUE, true );
		return is_array( $jobs )
			? array_values( array_filter( $jobs, static fn ( $job ): bool => is_array( $job ) && isset( $job['event'], $job['ids'] ) && is_array( $job['ids'] ) ) )
			: [];
	}

	/**
	 * Take a person off every email that is still on its way, when their
	 * account is deleted (Core\Database\Cleanup). A batch already passes
	 * over an id that names nobody, so nothing would have been sent; but
	 * the queue would go on naming the id until its batch came round, and
	 * an id is only a number, which the next account made could be given.
	 * A job left with nobody is dropped, and a post left with no job gives
	 * up its place in cron. The queues are few, one per post with email
	 * still to go, so they are found in one read.
	 */
	public static function forgetRecipient( int $userId ): void {
		if ( $userId <= 0 ) {
			return;
		}
		global $wpdb;
		$postIds = array_map(
			'intval',
			(array) $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one read for every queue there is, when an account is deleted; each queue is then read and written through the meta API.
				$wpdb->prepare( 'SELECT post_id FROM %i WHERE meta_key = %s', $wpdb->postmeta, self::KEY_QUEUE )
			)
		);
		foreach ( $postIds as $postId ) {
			$jobs = self::queued( $postId );
			$left = [];
			foreach ( $jobs as $job ) {
				$job['ids'] = array_values( array_diff( array_map( 'intval', $job['ids'] ), [ $userId ] ) );
				if ( $job['ids'] ) {
					$left[] = $job;
				}
			}
			if ( $left === $jobs ) {
				continue;
			}
			if ( $left ) {
				update_post_meta( $postId, self::KEY_QUEUE, $left );
				continue;
			}
			delete_post_meta( $postId, self::KEY_QUEUE );
			wp_clear_scheduled_hook( self::QUEUE_HOOK, [ $postId ] );
		}
	}

	/**
	 * @param int $orgId The organization the item reaches the person through (Organizations\Reach).
	 * @return array<string, mixed>
	 */
	private function tokensFor( int $postId, string $event, WP_User $user, int $orgId ): array {
		if ( TemplateEngine::EVENT_ALERT_POSTED !== $event ) {
			return $this->contentTokens( $postId, $user, $orgId );
		}
		return array_merge(
			$this->userTokens( $user, $orgId, $event ),
			[
				'alert_title' => self::plainTitle( $postId ),
				'alert_body'  => self::plain( (string) get_post_field( 'post_content', $postId, 'raw' ) ),
			]
		);
	}

	/** A title as it was written: the emails are plain text, so no entities. */
	private static function plainTitle( int $postId ): string {
		return self::plain( (string) get_post_field( 'post_title', $postId, 'raw' ) );
	}

	private static function plain( string $html ): string {
		return trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	}

	public function onMemberCreated( int $userId ): void {
		$this->sendWelcome( $userId );
	}

	/**
	 * Send the welcome email to one member. A member is created with a random
	 * password they never see, so the email carries a one-time set-password link
	 * instead of a plain login URL. Generated here (the single choke point) so
	 * every path — creation, org-admin invite, the admin's bulk resend — gets a
	 * working link without leaking the key past the email.
	 *
	 * Someone on the team gets the team's welcome instead, however their
	 * account came to be and whoever asks for it again: the member's speaks
	 * of a portal, which is not where the team works.
	 *
	 * The welcome concerns one organization, as every email does (FR8): the
	 * one named, when the person belongs to it, which is how a roster's
	 * "Resend" speaks for the organization whose roster it is and not for
	 * whichever the person joined first. An organization they do not belong
	 * to is never named to them.
	 *
	 * @param int $orgId The organization the welcome is for; their first when 0.
	 * @return bool False when the user does not exist or has no email address.
	 */
	public function sendWelcome( int $userId, int $orgId = 0 ): bool {
		$user = get_user_by( 'id', $userId );
		if ( ! $user || '' === $user->user_email ) {
			return false;
		}
		if ( Capabilities::isStaff( $user ) ) {
			$this->sendTeamWelcome( $user );
			return true;
		}
		// With none named: the membership is written as the account is
		// registered (Provisioning::insertUser()), ahead of this, so the
		// organization the person was provisioned into is their primary one.
		// A resend falls to their first on the site, and so does one that
		// names an organization in the trash: it is named nowhere (the review
		// of the At-a-glance track, 2026-10-19).
		if ( $orgId <= 0 || ! Roster::isMemberOf( (int) $user->ID, $orgId ) || ! OrgRepository::isOnSite( $orgId ) ) {
			$orgId = OrgRepository::primaryOnSite( (int) $user->ID );
		}
		$tokens                     = $this->userTokens( $user, $orgId, TemplateEngine::EVENT_WELCOME );
		$tokens['set_password_url'] = $this->setPasswordUrl( $user );
		$delivered                  = $this->send( $user, TemplateEngine::EVENT_WELCOME, $tokens, $orgId );
		$this->log( $userId, null, TemplateEngine::EVENT_WELCOME, $delivered );
		return true;
	}

	/**
	 * The welcome for an account on the team (People-model track, FR3): the
	 * role they were given, the one-time link that sets their password and
	 * where the program is run. It concerns no organization, whatever the
	 * person is assigned to or belongs to, so its activity row is filed
	 * under none.
	 */
	private function sendTeamWelcome( WP_User $user ): void {
		$tokens    = array_merge(
			$this->userTokens( $user, 0, TemplateEngine::EVENT_TEAM_WELCOME ),
			[
				'team_role'        => Capabilities::roleLabel( Capabilities::teamRole( $user ) ),
				'admin_url'        => admin_url( 'admin.php?page=monstera' ),
				'set_password_url' => $this->setPasswordUrl( $user ),
			]
		);
		$delivered = $this->send( $user, TemplateEngine::EVENT_TEAM_WELCOME, $tokens, 0 );
		$this->log( (int) $user->ID, null, TemplateEngine::EVENT_TEAM_WELCOME, $delivered );
	}

	/**
	 * Tell someone who already had an account that they now belong to one
	 * more organization (People-model track, FR7): an invitation by email
	 * reached an address Monstera knew. The email names the organization
	 * they joined and no other, so every token about an organization is
	 * filled from that one, never from their first; and it carries no
	 * set-password link, because the account and its password are theirs
	 * already. Someone who has never signed in has no password, and is sent
	 * the welcome instead (Members\Provisioning::attachMember()).
	 *
	 * @return bool False when the user does not exist, has no email address, or no organization is named.
	 */
	public function sendAddedToOrganization( int $userId, int $orgId ): bool {
		$user = get_user_by( 'id', $userId );
		if ( ! $user || '' === $user->user_email || $orgId <= 0 ) {
			return false;
		}
		$delivered = $this->send( $user, TemplateEngine::EVENT_ADDED_TO_ORG, $this->userTokens( $user, $orgId, TemplateEngine::EVENT_ADDED_TO_ORG ), $orgId );
		$this->log( $userId, null, TemplateEngine::EVENT_ADDED_TO_ORG, $delivered );
		return true;
	}

	/**
	 * Build a one-time set-password link for a freshly created member, mirroring
	 * the URL core's retrieve_password() generates (wp-login.php?action=rp) so
	 * the recipient lands on WordPress's "set your password" screen rather than a
	 * login form they have no password for. Scoped to the welcome path only:
	 * get_password_reset_key() rotates the user activation key, so it must not run
	 * on every notification. Returns '' (the template's {login_url} still
	 * resolves) when password reset is disabled for the user.
	 */
	private function setPasswordUrl( WP_User $user ): string {
		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			return '';
		}
		return network_site_url(
			'wp-login.php?action=rp&key=' . rawurlencode( $key ) . '&login=' . rawurlencode( $user->user_login ),
			'login'
		);
	}

	/**
	 * Send a membership-expiry notice (warning or expired) to a user, with the
	 * org context so {expiry_date}/{user_company} resolve. Called by the daily
	 * Expiration cron.
	 *
	 * @return bool Whether an email went to the person: wp_mail() accepted it. False for an event that is not one of the two, for an account that is gone, and for a refused send; Expiration marks a window as sent only when this says one was.
	 */
	public function onMembershipExpiry( int $userId, int $orgId, string $event ): bool {
		if ( ! in_array( $event, [ TemplateEngine::EVENT_EXPIRY_WARNING, TemplateEngine::EVENT_EXPIRED ], true ) ) {
			return false;
		}
		$user = get_user_by( 'id', $userId );
		if ( ! $user ) {
			return false;
		}
		$delivered = $this->send( $user, $event, $this->userTokens( $user, $orgId, $event ), $orgId );
		$this->log( $userId, null, $event, $delivered );
		return true === $delivered;
	}

	/**
	 * Send a standalone member a notice about their own membership's end
	 * (a TemplateEngine::STANDALONE_EVENTS warning or the expired notice),
	 * with their own date. It concerns no organization, so it names none
	 * and its activity row is filed under none. It goes round the hold an
	 * ended membership puts on the content emails (heldBack()), as an
	 * organization's expired notice does: it is about the ending itself.
	 * Called by the daily Expiration cron.
	 *
	 * @return bool Whether an email went to the person: wp_mail() accepted it. False for an event that is not one of the two, for an account that is gone, and for a refused send; Expiration marks a window as sent only when this says one was.
	 */
	public function onOwnMembershipExpiry( int $userId, string $event ): bool {
		if ( ! in_array( $event, TemplateEngine::STANDALONE_EVENTS, true ) ) {
			return false;
		}
		$user = get_user_by( 'id', $userId );
		if ( ! $user ) {
			return false;
		}
		$delivered = $this->send( $user, $event, $this->userTokens( $user, 0, $event ), 0 );
		$this->log( $userId, null, $event, $delivered );
		return true === $delivered;
	}

	public function onOrgStatusChanged( int $orgId, string $newStatus ): void {
		// Whatever the change, the email of an earlier suspension still on its
		// way is dropped now, not when its next batch would have asked: a
		// reactivation ends it at once, cron or no cron, and a suspension
		// that follows a reactivation starts clean, so nobody hears of the
		// same suspension twice (the track's review, 2026-10-22).
		self::dropJobs( $orgId, TemplateEngine::EVENT_ORG_SUSPENDED );
		if ( 'suspended' !== $newStatus ) {
			return;
		}
		// Everyone who belongs to it, through whichever of their memberships;
		// staff are assigned to it, never members of it. In batches, as
		// audience email goes (Review-leftovers track, 2026-10-21): the first
		// with the request that suspended it, the rest from cron, each batch
		// asking again whether the person still belongs and the organization
		// is still suspended.
		$this->queue( $orgId, TemplateEngine::EVENT_ORG_SUSPENDED, Roster::memberIds( $orgId ) );
	}

	/**
	 * Drop a post's queued email of one event, leaving the rest of its
	 * queue; a post left with no job gives up its place in cron.
	 */
	private static function dropJobs( int $postId, string $event ): void {
		$jobs = self::queued( $postId );
		$left = array_values( array_filter( $jobs, static fn ( array $job ): bool => $event !== $job['event'] ) );
		if ( count( $left ) === count( $jobs ) ) {
			return;
		}
		if ( $left ) {
			update_post_meta( $postId, self::KEY_QUEUE, $left );
		} else {
			delete_post_meta( $postId, self::KEY_QUEUE );
			wp_clear_scheduled_hook( self::QUEUE_HOOK, [ $postId ] );
		}
	}

	/**
	 * "Also send by email" on an alert: one email to each member it reaches,
	 * on its first post only, with the number sent stored for the composer.
	 * Later saves, and posting it again after it ended, send nothing. The
	 * audience's members are queued here; someone the notices band holds
	 * the alert back from is passed over as their batch goes
	 * (processQueue()), so the number stored is of the emails that went.
	 */
	public function onAlertPosted( int $alertId, bool $first = true ): void {
		if ( ! $first
			|| ! (bool) get_post_meta( $alertId, AlertMeta::KEY_NOTIFY_BY_EMAIL, true )
			|| '' !== (string) get_post_meta( $alertId, AlertMeta::KEY_EMAIL_SENT, true )
		) {
			return;
		}
		// Written first: the first post's one chance is spent from here on.
		update_post_meta( $alertId, AlertMeta::KEY_EMAIL_SENT, 0 );
		$this->queue( $alertId, TemplateEngine::EVENT_ALERT_POSTED, self::actorsPart( $alertId, ( new AlertRepository() )->recipientIds( AlertRepository::audienceOf( $alertId ) ) ) );
	}

	/**
	 * The members who can open the item: its audience (everyone, its
	 * organizations' members and the standalone members it names), less
	 * anyone the engine turns away. The sub-group gate, the project gate,
	 * the visibility setting and a suspended organization all count, so
	 * nobody is emailed a link that answers 403. Monstera admins are staff,
	 * not the audience.
	 *
	 * @return int[]
	 */
	private function recipientsForContent( int $contentId ): array {
		$roles = [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ];
		if ( (bool) get_post_meta( $contentId, ContentMeta::KEY_AUDIENCE_EVERYONE, true ) ) {
			$candidates = get_users(
				[
					'role__in' => $roles,
					'fields'   => 'all',
					'number'   => -1,
				]
			);
		} else {
			// The audience organizations' members through the Roster, the
			// organizations read together and a person in two of them once, in
			// one user query; then the people named.
			$inOrgs = [];
			$orgIds = array_filter( array_map( 'intval', (array) get_post_meta( $contentId, ContentMeta::KEY_ORG_IDS, true ) ) );
			Roster::primeOrgs( $orgIds );
			foreach ( $orgIds as $orgId ) {
				$inOrgs = array_merge( $inOrgs, Roster::memberIds( $orgId ) );
			}
			$candidates = array_merge(
				self::users( $inOrgs, $roles ),
				self::users( (array) get_post_meta( $contentId, ContentMeta::KEY_STANDALONE_MEMBER_IDS, true ) )
			);
		}

		// The engine asks each candidate's organizations: one query for them all first.
		Roster::prime( array_map( static fn ( WP_User $user ): int => (int) $user->ID, $candidates ) );
		$visibility = new Visibility( new SubgroupRepository(), new ProjectRepository() );
		$out        = [];
		foreach ( $candidates as $user ) {
			if ( ! isset( $out[ $user->ID ] ) && $visibility->userCanSee( $user, $contentId ) ) {
				$out[ $user->ID ] = (int) $user->ID;
			}
		}
		return array_values( $out );
	}

	/**
	 * @return array<string, mixed>
	 */
	private function contentTokens( int $contentId, WP_User $user, int $orgId ): array {
		return array_merge(
			$this->userTokens( $user, $orgId, TemplateEngine::EVENT_NEW_CONTENT ),
			[
				'content_title' => self::plainTitle( $contentId ),
				'content_url'   => Routing::url( Routing::ROUTE_CONTENT, [ 'id' => $contentId ] ),
				'summary'       => self::plain( (string) get_post_meta( $contentId, ContentMeta::KEY_SUMMARY, true ) ),
			]
		);
	}

	/**
	 * The accounts behind a list of ids, in one query: none for an empty
	 * list, which get_users() would otherwise read as everyone.
	 *
	 * @param array<int, mixed> $ids
	 * @param list<string>      $roles Only accounts holding one of them, when given.
	 * @return list<WP_User>
	 */
	private static function users( array $ids, array $roles = [] ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( ! $ids ) {
			return [];
		}
		$args = [
			'include' => $ids,
			'fields'  => 'all',
			'number'  => -1,
		];
		if ( $roles ) {
			$args['role__in'] = $roles;
		}
		return array_values( get_users( $args ) );
	}

	/**
	 * The tokens about the person for the organization the event concerns,
	 * 0 when there is none (a standalone member). The caller resolves it
	 * from the event (the audience organization the item reaches them
	 * through, the project's, the one expiring or suspended), never from
	 * "the member's organization": a person belongs to any number of them.
	 *
	 * The expiry date is the event's. An event about an organization (its
	 * expiry warning, its expired notice, its suspension, the welcome into
	 * it: TemplateEngine::ORG_ONLY_EVENTS) says when that organization's
	 * membership ends, whatever date the person carries of their own: a
	 * manager with a standalone date of their own would otherwise be
	 * reminded of their organization's expiry with their own date. Every
	 * other event is about the person, and gives their own date, else the
	 * organization's.
	 *
	 * @param string $event The event the tokens are for; '' for one that is about the person.
	 * @return array<string, mixed>
	 */
	private function userTokens( WP_User $user, int $orgId, string $event = '' ): array {
		$own     = (string) get_user_meta( $user->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );
		$theirs  = $orgId > 0 ? (string) get_post_meta( $orgId, OrgMeta::KEY_EXPIRES, true ) : '';
		$expires = $orgId > 0 && in_array( $event, TemplateEngine::ORG_ONLY_EVENTS, true )
			? ( $theirs ?: $own )
			: ( $own ?: $theirs );

		return [
			'user_name'       => $user->display_name,
			'user_first_name' => $user->first_name ?: $user->display_name,
			'user_email'      => $user->user_email,
			'user_company'    => $orgId > 0 ? self::plainTitle( $orgId ) : '',
			'expiry_date'     => $expires ?: __( 'soon', 'monstera' ),
		];
	}

	/**
	 * Renders and sends one email. Returns whether wp_mail() accepted it, or
	 * null when the template rendered empty and nothing was sent.
	 *
	 * @param array<string, mixed> $tokens
	 * @param int                  $orgId  The organization the email concerns, 0 for none: the last argument of the sent hook.
	 */
	private function send( WP_User $user, string $event, array $tokens, int $orgId ): ?bool {
		$rendered = $this->templates->render( $event, $tokens );
		if ( ! $rendered['subject'] || ! $rendered['body'] ) {
			return null;
		}
		$headers   = [
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', get_bloginfo( 'name' ), get_option( 'admin_email' ) ),
		];
		$delivered = (bool) wp_mail( $user->user_email, $rendered['subject'], $rendered['body'], $headers );
		// "Sent" is what wp_mail() accepted: activity never says an email went
		// that did not. The notification log keeps the refusal.
		if ( $delivered ) {
			do_action( Hooks::NOTIFICATION_SENT, $user->ID, $event, $rendered, $orgId );
		}
		return $delivered;
	}

	/**
	 * Post meta: the newest intake file the agency has been told about, by
	 * id. Ids, not times: a file stored in the same second as a submission
	 * is still told apart.
	 */
	public const KEY_INTAKE_REPORTED_FILE = '_monstera_intake_reported_file';

	/** @var array<int, bool> Whether this request's submit told the agency, by project. */
	private static array $intakeNotified = [];

	/**
	 * A client submitted discovery: tell the agency what is new, the
	 * questions whose answers changed and the files added since the
	 * previous submission, in one email to each address the
	 * monstera/intake_recipients filter gives (the site's admin email by
	 * default). Nothing new, nothing sent.
	 *
	 * @param list<string> $keys    The questions the submit carried.
	 * @param list<string> $changed The questions whose answers changed.
	 */
	public function onIntakeSubmitted( int $projectId, int $userId, array $keys = [], array $changed = [] ): void {
		unset( $keys );
		self::$intakeNotified[ $projectId ] = false;
		// Before the first submission every file is new.
		$reported = (int) get_post_meta( $projectId, self::KEY_INTAKE_REPORTED_FILE, true );
		$newest   = $reported;

		$labels  = array_column( Discovery::schema( $projectId ), 'label', 'key' );
		$answers = array_map( static fn ( $key ): string => (string) ( $labels[ $key ] ?? $key ), $changed );
		$added   = [];
		foreach ( ( new IntakeFiles() )->forProject( $projectId ) as $key => $files ) {
			foreach ( $files as $file ) {
				if ( $file['id'] > $reported ) {
					$added[] = sprintf( '%s: %s (%s)', $labels[ $key ] ?? $key, $file['name'], size_format( $file['size'] ) );
					$newest  = max( $newest, $file['id'] );
				}
			}
		}
		update_post_meta( $projectId, self::KEY_INTAKE_REPORTED_FILE, $newest );
		if ( ! $answers && ! $added ) {
			return;
		}

		$lines = [];
		if ( $answers ) {
			$lines[] = __( 'Answers changed:', 'monstera' );
			foreach ( $answers as $label ) {
				$lines[] = '- ' . $label;
			}
			$lines[] = '';
		}
		if ( $added ) {
			$lines[] = __( 'Files added:', 'monstera' );
			foreach ( $added as $line ) {
				$lines[] = '- ' . $line;
			}
		}
		$submitter = get_userdata( $userId );
		$rendered  = $this->templates->render(
			TemplateEngine::EVENT_INTAKE_SUBMITTED,
			[
				'project_title'  => self::plainTitle( $projectId ),
				'submitter_name' => $submitter ? UserMeta::fullName( $submitter ) : __( 'Someone', 'monstera' ),
				'changes'        => trim( implode( "\n", $lines ) ),
				'project_url'    => admin_url( 'admin.php?page=monstera-projects&id=' . $projectId ),
			]
		);
		if ( ! $rendered['subject'] || ! $rendered['body'] ) {
			return;
		}

		$recipients = (array) apply_filters( Hooks::FILTER_INTAKE_RECIPIENTS, [ get_option( 'admin_email' ) ], $projectId );
		$headers    = [
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', get_bloginfo( 'name' ), get_option( 'admin_email' ) ),
		];
		foreach ( array_unique( array_filter( array_map( 'sanitize_email', array_map( 'strval', $recipients ) ), 'is_email' ) ) as $to ) {
			$delivered = (bool) wp_mail( $to, $rendered['subject'], $rendered['body'], $headers );
			$recipient = get_user_by( 'email', $to );
			global $wpdb;
			$wpdb->insert(
				Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
				[
					'member_id'  => $recipient ? (int) $recipient->ID : 0,
					'event_type' => TemplateEngine::EVENT_INTAKE_SUBMITTED,
					'channel'    => 'email',
					'delivered'  => $delivered ? 1 : 0,
					'sent_at'    => current_time( 'mysql', true ),
					'meta'       => (string) wp_json_encode(
						[
							'project_id' => $projectId,
							'to'         => $to,
						]
					),
				],
				[ '%d', '%s', '%s', '%d', '%s', '%s' ]
			);
			self::$intakeNotified[ $projectId ] = self::$intakeNotified[ $projectId ] || $delivered;
		}
	}

	/**
	 * Whether this request's discovery submit told the agency, for the
	 * submit route's answer: the portal claims only a notification that went.
	 */
	public static function intakeNotified( int $projectId ): bool {
		return self::$intakeNotified[ $projectId ] ?? false;
	}

	/**
	 * One row per attempt, with wp_mail()'s answer (the dashboard's outgoing
	 * email health reads it). An empty render sent nothing and leaves no row.
	 */
	private function log( int $userId, ?int $contentId, string $event, ?bool $delivered ): void {
		if ( null === $delivered ) {
			return;
		}
		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
			[
				'member_id'  => $userId,
				'content_id' => $contentId,
				'event_type' => $event,
				'channel'    => 'email',
				'delivered'  => $delivered ? 1 : 0,
				'sent_at'    => current_time( 'mysql', true ),
			],
			[ '%d', '%d', '%s', '%s', '%d', '%s' ]
		);
	}
}
