<?php
/**
 * The emails of a support conversation.
 *
 * Every turn tells the other side. The member hears that their request
 * arrived, each staff reply (its text and its files by name, never the
 * files) and that staff resolved or closed it. The support inbox hears of a
 * new request, each member reply, a member's "resolved" and a raised
 * priority. Nobody is told about their own change, and a status a reply
 * moved by itself is not news: the reply's email is.
 *
 * Each email is a TemplateEngine template an admin can edit, and each
 * attempt is a notification-log row with what wp_mail() accepted.
 */

declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Support\Files;
use Monstera\Support\Inbox;
use Monstera\Support\Repository;
use Monstera\Support\Thread;

defined( 'ABSPATH' ) || exit;

final class SupportNotifier {

	public function __construct( private TemplateEngine $templates ) {}

	/**
	 * A member opened a request: they hear it arrived, the inbox hears what
	 * was asked.
	 *
	 * @param array<string, mixed>|null $row The request, as the hook passes it.
	 */
	public function onRequestCreated( int $id, ?array $row = null ): void {
		$row = $row ?: ( new Repository() )->find( $id );
		if ( ! $row ) {
			return;
		}
		$memberId = (int) $row['member_id'];
		$tokens   = [
			'message'       => (string) $row['body'],
			'message_files' => self::filesLine( ( new Files() )->forRequest( $id )[0] ?? [] ),
		];
		// An acknowledgement is for the person who sent the request.
		$this->toMember( $row, TemplateEngine::EVENT_SUPPORT_RECEIVED, $tokens, 0 );
		$this->toInbox( $row, TemplateEngine::EVENT_SUPPORT_NEW, $tokens, $memberId );
	}

	/** A reply joined the thread: the other side reads it. */
	public function onMessageAdded( int $requestId, int $messageId, string $side ): void {
		$repo = new Repository();
		$row  = $repo->find( $requestId );
		if ( ! $row ) {
			return;
		}
		$message = null;
		foreach ( $repo->thread( $requestId ) as $entry ) {
			if ( $entry['id'] === $messageId ) {
				$message = $entry;
			}
		}
		if ( ! $message ) {
			return;
		}
		$files = self::filesLine( ( new Files() )->forRequest( $requestId )[ $messageId ] ?? [] );
		if ( Thread::SIDE_STAFF === $side ) {
			$this->toMember(
				$row,
				TemplateEngine::EVENT_SUPPORT_REPLIED,
				[
					'staff_name'  => self::nameOf( $message['author_id'] ),
					'reply'       => $message['body'],
					'reply_files' => $files,
				],
				$message['author_id']
			);
			return;
		}
		$this->toInbox(
			$row,
			TemplateEngine::EVENT_SUPPORT_MEMBER_REPLIED,
			[
				'message'       => $message['body'],
				'message_files' => $files,
			],
			$message['author_id']
		);
	}

	/**
	 * A status someone chose: staff resolving or closing tells the member,
	 * the member's "resolved" tells the inbox. A status a reply moved is
	 * already told by the reply.
	 */
	public function onStatusChanged( int $requestId, string $from, string $to, int $actorId, string $side, string $cause ): void {
		unset( $from );
		if ( Thread::CAUSE_MANUAL !== $cause ) {
			return;
		}
		$row = ( new Repository() )->find( $requestId );
		if ( ! $row ) {
			return;
		}
		if ( Thread::SIDE_STAFF !== $side ) {
			if ( Repository::STATUS_RESOLVED === $to ) {
				$this->toInbox( $row, TemplateEngine::EVENT_SUPPORT_MEMBER_RESOLVED, [], $actorId );
			}
			return;
		}
		$event = match ( $to ) {
			Repository::STATUS_RESOLVED => TemplateEngine::EVENT_SUPPORT_RESOLVED,
			Repository::STATUS_CLOSED   => TemplateEngine::EVENT_SUPPORT_CLOSED,
			default                     => null,
		};
		if ( $event ) {
			$this->toMember( $row, $event, [ 'staff_name' => self::nameOf( $actorId ) ], $actorId );
		}
	}

	/** The member made it more urgent: the inbox hears. Less urgent is not news. */
	public function onPriorityChanged( int $requestId, string $from, string $to, int $actorId ): void {
		$rank = array_flip( Repository::PRIORITIES );
		if ( ( $rank[ $to ] ?? 0 ) <= ( $rank[ $from ] ?? 0 ) ) {
			return;
		}
		$row = ( new Repository() )->find( $requestId );
		if ( $row ) {
			$this->toInbox( $row, TemplateEngine::EVENT_SUPPORT_PRIORITY_RAISED, [ 'old_priority' => Repository::priorityLabel( $from ) ], $actorId );
		}
	}

	/**
	 * One email to the member who opened the request, unless they made the
	 * change themselves or their account is gone.
	 *
	 * @param array<string, mixed>  $row
	 * @param array<string, string> $tokens
	 */
	private function toMember( array $row, string $event, array $tokens, int $actorId ): void {
		$member = get_userdata( (int) $row['member_id'] );
		if ( ! $member || (int) $member->ID === $actorId ) {
			return;
		}
		$rendered = $this->render( $event, $row, [ 'user_first_name' => $member->first_name ?: $member->display_name ] + $tokens );
		if ( ! $rendered ) {
			return;
		}
		$delivered = (bool) wp_mail( $member->user_email, $rendered['subject'], $rendered['body'], self::headers( true ) );
		if ( $delivered ) {
			do_action( Hooks::NOTIFICATION_SENT, $member->ID, $event, $rendered );
		}
		$this->log( (int) $member->ID, $event, $delivered, $row, [] );
	}

	/**
	 * One email to each address the inbox names, but never to whoever made
	 * the change.
	 *
	 * @param array<string, mixed>  $row
	 * @param array<string, string> $tokens
	 */
	private function toInbox( array $row, string $event, array $tokens, int $actorId ): void {
		$rendered = $this->render( $event, $row, $tokens );
		if ( ! $rendered ) {
			return;
		}
		$actor = $actorId ? get_userdata( $actorId ) : false;
		$own   = $actor ? strtolower( (string) $actor->user_email ) : '';
		foreach ( Inbox::recipients( $row ) as $to ) {
			if ( strtolower( $to ) === $own ) {
				continue;
			}
			$delivered = (bool) wp_mail( $to, $rendered['subject'], $rendered['body'], self::headers( false ) );
			$recipient = get_user_by( 'email', $to );
			$this->log( $recipient ? (int) $recipient->ID : 0, $event, $delivered, $row, [ 'to' => $to ] );
		}
	}

	/**
	 * The template with the request's own tokens beside the event's. A
	 * token that came to nothing (no files, no project) leaves no gap.
	 *
	 * @param array<string, mixed>  $row
	 * @param array<string, string> $tokens
	 * @return array{subject: string, body: string}|null Null when the template is empty: nothing is sent.
	 */
	private function render( string $event, array $row, array $tokens ): ?array {
		$member  = get_userdata( (int) $row['member_id'] );
		$context = [];
		if ( ! empty( $row['org_id'] ) ) {
			/* translators: %s: an organization's name */
			$context[] = sprintf( __( 'Organization: %s', 'monstera' ), self::plainTitle( (int) $row['org_id'] ) );
		}
		if ( ! empty( $row['project_id'] ) ) {
			/* translators: %s: a project's name */
			$context[] = sprintf( __( 'Project: %s', 'monstera' ), self::plainTitle( (int) $row['project_id'] ) );
		}
		$rendered         = $this->templates->render(
			$event,
			$tokens + [
				'request_ref'      => (string) $row['ref'],
				'request_subject'  => (string) $row['subject'],
				'request_priority' => Repository::priorityLabel( (string) $row['priority'] ),
				'request_context'  => implode( "\n", $context ),
				'request_url'      => Repository::portalUrl( $row ),
				'admin_url'        => admin_url( 'admin.php?page=monstera-support&id=' . (int) $row['id'] ),
				'support_url'      => Routing::url( Routing::ROUTE_SUPPORT ),
				'support_email'    => Inbox::email(),
				'member_name'      => $member ? UserMeta::fullName( $member ) : __( 'A former member', 'monstera' ),
				'member_email'     => $member ? (string) $member->user_email : '',
				'staff_name'       => '',
				'message'          => '',
				'message_files'    => '',
				'reply'            => '',
				'reply_files'      => '',
				'old_priority'     => '',
			]
		);
		$rendered['body'] = trim( (string) preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $rendered['body'] ) ) );
		return '' !== $rendered['subject'] && '' !== $rendered['body'] ? $rendered : null;
	}

	/**
	 * @param bool $toMember A member's email answers to the support inbox: a reply by email reaches staff, though not the thread.
	 * @return list<string>
	 */
	private static function headers( bool $toMember ): array {
		$headers = [
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', get_bloginfo( 'name' ), get_option( 'admin_email' ) ),
		];
		if ( $toMember ) {
			$headers[] = 'Reply-To: ' . Inbox::email();
		}
		return $headers;
	}

	/**
	 * A message's files in one line, by name and size; nothing when it has
	 * none. The files themselves stay behind signed links.
	 *
	 * @param list<array{name: string, size: int}> $files
	 */
	private static function filesLine( array $files ): string {
		if ( ! $files ) {
			return '';
		}
		$names = array_map( static fn ( array $file ): string => sprintf( '%s (%s)', $file['name'], size_format( $file['size'] ) ), $files );
		/* translators: %s: a list of file names with their sizes */
		return sprintf( __( 'Files: %s', 'monstera' ), implode( ', ', $names ) );
	}

	private static function nameOf( int $userId ): string {
		$user = $userId ? get_userdata( $userId ) : false;
		return $user ? UserMeta::fullName( $user ) : __( 'The support team', 'monstera' );
	}

	/** A post's title as an email reads it: no entities. */
	private static function plainTitle( int $postId ): string {
		$raw = get_post_field( 'post_title', $postId );
		return is_string( $raw ) ? html_entity_decode( $raw, ENT_QUOTES, 'UTF-8' ) : '';
	}

	/**
	 * One row per attempt, with wp_mail()'s answer.
	 *
	 * @param array<string, mixed>  $row  The request.
	 * @param array<string, string> $meta What else the row should say (the address, for the inbox).
	 */
	private function log( int $userId, string $event, bool $delivered, array $row, array $meta ): void {
		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_NOTIFICATION_LOG ),
			[
				'member_id'  => $userId,
				'event_type' => $event,
				'channel'    => 'email',
				'delivered'  => $delivered ? 1 : 0,
				'sent_at'    => current_time( 'mysql', true ),
				'meta'       => (string) wp_json_encode(
					[
						'request_id' => (int) $row['id'],
						'ref'        => (string) $row['ref'],
					] + $meta
				),
			],
			[ '%d', '%s', '%s', '%d', '%s', '%s' ]
		);
	}
}
