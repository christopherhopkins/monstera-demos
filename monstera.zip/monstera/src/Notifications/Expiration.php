<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Fired daily via WP-Cron. Walks orgs and standalone members,
 * sends warnings 30/14/7/1 day(s) before expiry, and an "expired"
 * notice the day after. Uses a meta flag per window to avoid dupes.
 */
final class Expiration {

	public static function dispatch(): void {
		$dispatcher = new Dispatcher( new TemplateEngine() );
		$now        = strtotime( 'today' );

		foreach ( ( new OrgRepository() )->all() as $org ) {
			$expiresStr = (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true );
			if ( ! $expiresStr ) {
				continue;
			}
			$expires = strtotime( $expiresStr );
			if ( ! $expires ) {
				continue;
			}
			$days = (int) floor( ( $expires - $now ) / DAY_IN_SECONDS );

			if ( in_array( $days, [ 30, 14, 7, 1 ], true ) ) {
				self::notifyOrgManager( $org->ID, 'warning_' . $days, $dispatcher );
			} elseif ( -1 === $days ) {
				self::notifyOrgManager( $org->ID, 'expired', $dispatcher );
			}
		}
	}

	private static function notifyOrgManager( int $orgId, string $key, Dispatcher $dispatcher ): void {
		$flag = '_monstera_notice_' . $key;
		if ( get_post_meta( $orgId, $flag, true ) ) {
			return;
		}

		$managers = get_users(
			[
				'role__in'   => [ 'monstera_org_manager' ],
				'meta_key'   => UserMeta::KEY_ASSOCIATED_ORG, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
				'meta_value' => (string) $orgId, // phpcs:ignore WordPress.DB.SlowDBQuery -- membership lives in user meta by design (single-org model); one org's members are a bounded set.
				'number'     => -1,
			]
		);
		foreach ( $managers as $manager ) {
			$event = str_starts_with( $key, 'warning_' )
				? TemplateEngine::EVENT_EXPIRY_WARNING
				: TemplateEngine::EVENT_EXPIRED;
			$dispatcher->onMembershipExpiry( $manager->ID, $orgId, $event );
		}

		update_post_meta( $orgId, $flag, '1' );
	}
}
