<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;

defined( 'ABSPATH' ) || exit;

/**
 * Fired daily via WP-Cron. Walks the organizations, sends each one's
 * admins and managers a warning 30/14/7/1 day(s) before its expiry and an
 * "expired" notice the day after. Uses a meta flag per window to avoid dupes.
 */
final class Expiration {

	public static function dispatch(): void {
		$dispatcher = new Dispatcher( new TemplateEngine() );
		$now        = strtotime( 'today' );

		foreach ( ( new OrgRepository() )->all() as $org ) {
			$expiresStr = (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true );
			if ( ! $expiresStr ) {
				continue;
			}
			$expires = strtotime( $expiresStr );
			if ( ! $expires ) {
				continue;
			}
			$days = (int) floor( ( $expires - $now ) / DAY_IN_SECONDS );

			if ( in_array( $days, [ 30, 14, 7, 1 ], true ) ) {
				self::notifyOrgManager( $org->ID, 'warning_' . $days, $dispatcher );
			} elseif ( -1 === $days ) {
				self::notifyOrgManager( $org->ID, 'expired', $dispatcher );
			}
		}
	}

	/**
	 * The organization's admins and managers hear, each once; a plain member
	 * there does not, whatever they are elsewhere. The flag is the
	 * organization's, so the reminders run per organization and a person in
	 * two expiring organizations hears about each. It is written only once
	 * somebody was written to: an organization with no admin or manager yet
	 * is not marked as told, so the admin it is given later in the window
	 * still hears, where a flag written over nobody would have silenced them.
	 */
	private static function notifyOrgManager( int $orgId, string $key, Dispatcher $dispatcher ): void {
		$flag = '_monstera_notice_' . $key;
		if ( get_post_meta( $orgId, $flag, true ) ) {
			return;
		}

		$event = str_starts_with( $key, 'warning_' )
			? TemplateEngine::EVENT_EXPIRY_WARNING
			: TemplateEngine::EVENT_EXPIRED;
		$sent  = false;
		foreach ( Roster::memberIds( $orgId, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ] ) as $userId ) {
			$sent = $dispatcher->onMembershipExpiry( $userId, $orgId, $event ) || $sent;
		}

		if ( $sent ) {
			update_post_meta( $orgId, $flag, '1' );
		}
	}
}
