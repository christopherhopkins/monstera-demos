<?php
declare(strict_types=1);

namespace Monstera\Notifications;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Capabilities;
use Monstera\Core\SiteDay;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Fired daily via WP-Cron. Walks the organizations, sends each one's
 * admins and managers a warning 30/14/7/1 day(s) before its expiry and an
 * "expired" notice the day after; then walks the standalone members whose
 * portal runs on a date of their own and sends each the same about their
 * own membership, which ends their portal as an organization's ends its
 * members' (AccessControl\PortalGuard::ownMembershipExpired()). Each
 * window goes once: a flag on the organization, a record on the member.
 */
final class Expiration {

	/** The site's days before the last on which a warning goes. */
	private const WARNINGS = [ 30, 14, 7, 1 ];

	public static function dispatch(): void {
		$dispatcher = new Dispatcher( new TemplateEngine() );
		$today      = SiteDay::today();

		foreach ( ( new OrgRepository() )->all() as $org ) {
			// The site's days to its last (Core\SiteDay), so a warning seven
			// days out is seven of the site's days, wherever it is.
			$window = self::window( SiteDay::daysSince( (string) get_post_meta( $org->ID, OrgMeta::KEY_EXPIRES, true ), $today ) );
			if ( '' !== $window ) {
				self::notifyOrgManager( $org->ID, $window, $dispatcher );
			}
		}

		foreach ( self::standaloneMembers() as $member ) {
			$expires = (string) get_user_meta( $member->ID, UserMeta::KEY_MEMBERSHIP_EXPIRES, true );
			$window  = self::window( SiteDay::daysSince( $expires, $today ) );
			if ( '' !== $window ) {
				self::notifyMember( $member, SiteDay::ymd( $expires ), $window, $dispatcher );
			}
		}
	}

	/**
	 * The notice a day calls for, by the site's days since the last
	 * (negative before it, null for a date that names no day):
	 * 'warning_30' to 'warning_1', 'expired', or '' for none.
	 *
	 * The daily run keeps its UTC hour, so where it falls in the hour
	 * before the site's midnight the spring clock change skips one of the
	 * site's days: each notice goes out on its day or the day after, once
	 * (its flag). The emails name the date, not a count.
	 */
	private static function window( ?int $since ): string {
		if ( null === $since ) {
			return '';
		}
		foreach ( self::WARNINGS as $threshold ) {
			if ( -$since === $threshold || -$since === $threshold - 1 ) {
				return 'warning_' . $threshold;
			}
		}
		return 1 === $since || 2 === $since ? 'expired' : '';
	}

	/**
	 * The organization's admins and managers hear, each once; a plain member
	 * there does not, whatever they are elsewhere. The flag is the
	 * organization's, so the reminders run per organization and a person in
	 * two expiring organizations hears about each. It is written only once
	 * somebody was written to: an organization with no admin or manager yet
	 * is not marked as told, so the admin it is given later in the window
	 * still hears, where a flag written over nobody would have silenced them.
	 */
	private static function notifyOrgManager( int $orgId, string $key, Dispatcher $dispatcher ): void {
		$flag = '_monstera_notice_' . $key;
		if ( get_post_meta( $orgId, $flag, true ) ) {
			return;
		}

		$event = str_starts_with( $key, 'warning_' )
			? TemplateEngine::EVENT_EXPIRY_WARNING
			: TemplateEngine::EVENT_EXPIRED;
		$sent  = false;
		foreach ( Roster::memberIds( $orgId, [ Roster::TIER_ADMIN, Roster::TIER_MANAGER ] ) as $userId ) {
			$sent = $dispatcher->onMembershipExpiry( $userId, $orgId, $event ) || $sent;
		}

		if ( $sent ) {
			update_post_meta( $orgId, $flag, '1' );
		}
	}

	/**
	 * The members whose portal runs on a date of their own
	 * (PortalGuard::runsOnOwnMembership()) and who hold one: the
	 * standalone role, read in one query with their memberships read
	 * together. A date of their own reminds nobody who belongs to an
	 * organization, as it pauses nobody there.
	 *
	 * @return list<WP_User>
	 */
	private static function standaloneMembers(): array {
		$users = get_users(
			[
				'role__in' => [ Capabilities::ROLE_MEMBER_STANDALONE ],
				'meta_key' => UserMeta::KEY_MEMBERSHIP_EXPIRES, // phpcs:ignore WordPress.DB.SlowDBQuery -- expiry lives in user meta by design; daily cron over a bounded member set.
				'fields'   => 'all',
				'number'   => -1,
			]
		);
		Roster::prime( array_map( static fn ( WP_User $user ): int => (int) $user->ID, $users ) );
		return array_values( array_filter( $users, [ PortalGuard::class, 'runsOnOwnMembership' ] ) );
	}

	/**
	 * A standalone member hears once a window, about their own date. What
	 * they were sent is recorded against the date it was about
	 * (UserMeta::KEY_EXPIRY_NOTICES): a record about another date is a
	 * term gone by, whether a renewal moved the date (and cleared the
	 * record) or the team did by hand, and the new date's notices go out on
	 * their days. A window is marked only once an email went, so a refused
	 * send is tried again by the next run, on the window's second day.
	 *
	 * @param string $expires Their date as Y-m-d.
	 */
	private static function notifyMember( WP_User $member, string $expires, string $window, Dispatcher $dispatcher ): void {
		$record = get_user_meta( $member->ID, UserMeta::KEY_EXPIRY_NOTICES, true );
		$sent   = is_array( $record ) && ( $record['for'] ?? null ) === $expires && is_array( $record['sent'] ?? null )
			? array_values( array_map( 'strval', $record['sent'] ) )
			: [];
		if ( in_array( $window, $sent, true ) ) {
			return;
		}

		$event = 'expired' === $window
			? TemplateEngine::EVENT_STANDALONE_EXPIRED
			: TemplateEngine::EVENT_STANDALONE_EXPIRY_WARNING;
		if ( ! $dispatcher->onOwnMembershipExpiry( (int) $member->ID, $event ) ) {
			return;
		}

		$sent[] = $window;
		update_user_meta(
			$member->ID,
			UserMeta::KEY_EXPIRY_NOTICES,
			[
				'for'  => $expires,
				'sent' => $sent,
			]
		);
	}
}
