<?php
/**
 * Minimal PSR-11-style service container.
 *
 * Constructor-injection style. Services register factory closures; resolved
 * instances are cached. Designed to be intentionally small (~80 LOC) so
 * its behavior is obvious from reading the file.
 */

declare(strict_types=1);

namespace Monstera;

use Closure;
use LogicException;
use RuntimeException;

final class Container {

	/** @var array<string, Closure> */
	private array $factories = [];

	/** @var array<string, object> */
	private array $instances = [];

	/**
	 * Register a service factory.
	 *
	 * @template T of object
	 * @param class-string<T> $id
	 * @param Closure(Container): T  $factory
	 */
	public function set( string $id, Closure $factory ): void {
		if ( isset( $this->instances[ $id ] ) ) {
			throw new LogicException( sprintf( 'Service %s is already resolved and cannot be redefined.', esc_html( $id ) ) );
		}
		$this->factories[ $id ] = $factory;
	}

	/**
	 * Register a pre-built instance (singleton).
	 *
	 * @template T of object
	 * @param class-string<T> $id
	 * @param T                      $instance
	 */
	public function share( string $id, object $instance ): void {
		$this->instances[ $id ] = $instance;
	}

	/**
	 * Resolve a service.
	 *
	 * @template T of object
	 * @param class-string<T> $id
	 * @return T
	 */
	public function get( string $id ): object {
		if ( isset( $this->instances[ $id ] ) ) {
			/** @var T */
			return $this->instances[ $id ];
		}

		if ( ! isset( $this->factories[ $id ] ) ) {
			throw new RuntimeException( sprintf( 'Service %s is not registered.', esc_html( $id ) ) );
		}

		$instance               = ( $this->factories[ $id ] )( $this );
		$this->instances[ $id ] = $instance;
		return $instance;
	}

	public function has( string $id ): bool {
		return isset( $this->factories[ $id ] ) || isset( $this->instances[ $id ] );
	}
}
