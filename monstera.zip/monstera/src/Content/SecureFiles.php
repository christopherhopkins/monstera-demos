<?php
/**
 * Secure file storage operations.
 *
 * Reads/writes the wp_monstera_secure_files table and resolves disk paths
 * inside /wp-content/uploads/mp-secure/{org-slug}/. Never exposes raw paths
 * to callers — they receive opaque file IDs and ask Downloader to stream.
 */

declare(strict_types=1);

namespace Monstera\Content;

use Monstera\Core\Database\Schema;
use Monstera\Core\Hooks;
use Monstera\Core\SecureStorage;

defined( 'ABSPATH' ) || exit;

final class SecureFiles {

	/**
	 * What an upload may be: documents, spreadsheets, slides, text, a zip
	 * and images, by extension and the type behind it (wp_check_filetype
	 * form). Hooks::FILTER_SECURE_FILE_TYPES narrows or widens it.
	 *
	 * @var array<string, string>
	 */
	public const TYPES = [
		'pdf'      => 'application/pdf',
		'doc'      => 'application/msword',
		'docx'     => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		'xls'      => 'application/vnd.ms-excel',
		'xlsx'     => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		'ppt'      => 'application/vnd.ms-powerpoint',
		'pptx'     => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
		'csv'      => 'text/csv',
		'txt'      => 'text/plain',
		'zip'      => 'application/zip',
		'png'      => 'image/png',
		'jpg|jpeg' => 'image/jpeg',
		'gif'      => 'image/gif',
		'webp'     => 'image/webp',
	];

	/**
	 * Folders under the secure root that are not an organization's: intake
	 * files (projects/<id>/), support files (support/<ref>/) and a form's
	 * submission files (forms/<id>/).
	 */
	public const RESERVED_FOLDERS = [ 'projects', 'support', 'forms' ];

	/** 100 MB, or the server's upload limit when that is lower. */
	private const DEFAULT_MAX_BYTES = 104857600;

	public static function maxBytes(): int {
		$limit = min( self::DEFAULT_MAX_BYTES, (int) wp_max_upload_size() ?: self::DEFAULT_MAX_BYTES );
		return max( 1, (int) apply_filters( Hooks::FILTER_SECURE_FILE_MAX_BYTES, $limit ) );
	}

	/**
	 * @return array<string, string>
	 */
	public static function types(): array {
		return (array) apply_filters( Hooks::FILTER_SECURE_FILE_TYPES, self::TYPES );
	}

	/**
	 * The type an upload really is, checked against its name and contents
	 * and the allowlist, or '' when it is not one Monstera stores.
	 *
	 * @param array{name?:string, tmp_name?:string} $upload
	 */
	public static function checkedType( array $upload ): string {
		$check = wp_check_filetype_and_ext( (string) ( $upload['tmp_name'] ?? '' ), (string) ( $upload['name'] ?? '' ), self::types() );
		return ( $check['ext'] && $check['type'] ) ? (string) $check['type'] : '';
	}

	/**
	 * Why an upload cannot be stored, in words for the save bar, or null.
	 *
	 * @param array<string, mixed>|null $upload One entry of the request's files.
	 */
	public static function refusal( ?array $upload ): ?string {
		if ( ! $upload || empty( $upload['tmp_name'] ) || ! empty( $upload['error'] ) || ! is_file( (string) $upload['tmp_name'] ) ) {
			return __( 'Choose a file to attach.', 'monstera' );
		}
		if ( (int) ( $upload['size'] ?? 0 ) > self::maxBytes() ) {
			/* translators: %s: the largest file allowed, e.g. "100 MB" */
			return sprintf( __( 'That file is over %s.', 'monstera' ), size_format( self::maxBytes() ) );
		}
		if ( '' === self::checkedType( $upload ) ) {
			return __( 'That kind of file cannot be attached. Use a PDF, an Office document, a CSV or text file, a zip or an image.', 'monstera' );
		}
		return null;
	}

	/** The extensions a file picker offers, for its accept attribute. */
	public static function accept(): string {
		$extensions = [];
		foreach ( array_keys( self::types() ) as $pattern ) {
			foreach ( explode( '|', (string) $pattern ) as $extension ) {
				$extensions[] = '.' . $extension;
			}
		}
		return implode( ',', $extensions );
	}

	/**
	 * size_format() of one of each unit, B to TB, for the sizes a browser
	 * writes while files are sent: the site's own unit words.
	 *
	 * @return list<string>
	 */
	public static function sizeUnits(): array {
		return array_map( static fn ( int $power ): string => (string) size_format( 1024 ** $power ), range( 0, 4 ) );
	}

	/**
	 * A file's name as people see it: its base name as sent, without control
	 * characters or line breaks. Every reader escapes it for where it goes,
	 * so a "%20" or a "<" stays as the sender wrote it.
	 */
	public static function displayName( string $name ): string {
		$name = (string) preg_replace( '/[\p{Cc}\s]+/u', ' ', wp_check_invalid_utf8( wp_basename( $name ), true ) );
		return mb_substr( trim( $name ), 0, 255 ) ?: 'file';
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public function findById( int $fileId ): ?array {
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SECURE_FILES );
		$row   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table, $fileId ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * Many files from one read, for a list that describes each of its rows'
	 * files (the hub's Content tab), where findById() is a read apiece.
	 *
	 * @param array<int, mixed> $fileIds
	 * @return array<int, array<string, mixed>> Rows by file id; a missing file is not in the answer.
	 */
	public function findByIds( array $fileIds ): array {
		$fileIds = array_values( array_unique( array_filter( array_map( 'intval', $fileIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $fileIds ) {
			return [];
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $fileIds ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $fileIds ); every id goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM %i WHERE id IN ($marks)", Schema::tableName( Schema::TABLE_SECURE_FILES ), ...$fileIds ),
			ARRAY_A
		);
		// phpcs:enable
		$out = [];
		foreach ( $rows as $row ) {
			$out[ (int) $row['id'] ] = $row;
		}
		return $out;
	}

	/**
	 * A content item's file. An intake file has no content item (its
	 * content_id is 0), so it is never one.
	 *
	 * @return array<string, mixed>|null
	 */
	public function findByContent( int $contentId ): ?array {
		if ( $contentId <= 0 ) {
			return null;
		}
		global $wpdb;
		$table = Schema::tableName( Schema::TABLE_SECURE_FILES );
		$row   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE content_id = %d ORDER BY id DESC LIMIT 1', $table, $contentId ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * Move an uploaded file into secure storage and create the registry row.
	 *
	 * @param array{name:string, tmp_name:string, size:int, type:string} $upload
	 */
	public function store( int $contentId, int $orgId, array $upload ): int {
		// Content for everyone or for standalone members has no organization
		// to file under.
		$orgSlug = $orgId > 0
			? sanitize_title( get_post_field( 'post_name', $orgId ) ?: 'org-' . $orgId )
			: 'shared';
		// An organization named for one of the registry's own folders files
		// under its id, clear of intake and support files.
		if ( in_array( $orgSlug, self::RESERVED_FOLDERS, true ) ) {
			$orgSlug = 'org-' . $orgId;
		}
		$fileId = $this->put(
			SecureStorage::orgPath( $orgSlug ),
			$upload,
			[
				'content_id'    => $contentId,
				'original_name' => $upload['name'],
				'mime_type'     => (string) $upload['type'],
			]
		);
		update_post_meta( $contentId, Meta::KEY_SECURE_FILE_ID, $fileId );
		return $fileId;
	}

	/**
	 * Move an upload into a folder under the secure root and record it with
	 * the owner the columns name: a content item (content_id), or a
	 * project's intake question (content_id 0, project_id, field_key,
	 * uploaded_by). The size, the stored path and the hash are measured
	 * here. With no row there is no file: a failure throws and leaves
	 * nothing behind.
	 *
	 * @param string                                                   $dir     An absolute folder under SecureStorage::rootPath().
	 * @param array{name:string, tmp_name:string, size:int, type?:string} $upload
	 * @param array<string, int|string|null>                           $columns The owner, the name to show and the type.
	 * @return int The file id.
	 */
	public function put( string $dir, array $upload, array $columns ): int {
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// A random prefix keeps two uploads of one name, arriving together,
		// from choosing the same free name, and keeps stored names unguessable.
		// People see the name in original_name.
		$target = $dir . '/' . wp_unique_filename( $dir, wp_generate_password( 12, false ) . '-' . $upload['name'] );

		$moved = self::move( $upload['tmp_name'], $target );
		// delete() removes a folder its file leaves empty: one deleted here a
		// moment ago may have taken the folder with it. Make it again, once.
		if ( ! $moved && ! is_dir( $dir ) && wp_mkdir_p( $dir ) ) {
			$moved = self::move( $upload['tmp_name'], $target );
		}
		if ( ! $moved ) {
			SecureStorage::removeIfEmpty( $dir );
			throw new \RuntimeException( 'Failed to move uploaded file into secure storage.' );
		}

		global $wpdb;
		$wpdb->insert(
			Schema::tableName( Schema::TABLE_SECURE_FILES ),
			array_merge(
				[ 'content_id' => 0 ],
				$columns,
				[
					'storage_path' => ltrim( str_replace( SecureStorage::rootPath(), '', $target ), '/' ),
					'filesize'     => (int) $upload['size'],
					'sha256'       => hash_file( 'sha256', $target ) ?: '',
					// UTC, as every reader takes it: the column's default is the
					// database's own clock.
					'created_at'   => current_time( 'mysql', true ),
				]
			)
		);

		$fileId = (int) $wpdb->insert_id;
		if ( $fileId <= 0 ) {
			// No row, no file: the caller keeps the one it had.
			wp_delete_file( $target );
			SecureStorage::removeIfEmpty( $dir );
			throw new \RuntimeException( 'Failed to record the file in secure storage.' );
		}
		return $fileId;
	}

	/** Moves an upload to its place in secure storage, through the filter that lets a caller move it its own way. */
	private static function move( string $from, string $to ): bool {
		$moved = apply_filters( Hooks::FILTER_SECURE_FILE_MOVE, null, $from, $to );
		return (bool) ( null === $moved ? move_uploaded_file( $from, $to ) : $moved );
	}

	/**
	 * @param array<string, mixed> $row
	 */
	public function absolutePath( array $row ): string {
		return SecureStorage::rootPath() . '/' . ltrim( (string) $row['storage_path'], '/' );
	}

	/**
	 * Removes a file from disk and the registry, and its folder when that
	 * leaves it empty (a support request's, an intake's, a form's).
	 */
	public function delete( int $fileId ): void {
		$row = $this->findById( $fileId );
		if ( ! $row ) {
			return;
		}
		$path = $this->absolutePath( $row );
		if ( is_file( $path ) ) {
			wp_delete_file( $path );
		}
		SecureStorage::removeIfEmpty( dirname( $path ) );
		global $wpdb;
		$wpdb->delete( Schema::tableName( Schema::TABLE_SECURE_FILES ), [ 'id' => $fileId ], [ '%d' ] );
	}
}
