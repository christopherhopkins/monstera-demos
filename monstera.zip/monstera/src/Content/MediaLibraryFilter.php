<?php
declare(strict_types=1);

namespace Monstera\Content;

final class MediaLibraryFilter {

	/**
	 * Hide secure-storage files from the Media Library AJAX query unless the
	 * editor is currently working on a monstera_content post.
	 * @param array<string, mixed> $args
	 * @return array<string, mixed>
	 */
	public static function hideSecure( array $args ): array {
		$post = isset( $args['post'] ) ? get_post( (int) $args['post'] ) : null;
		if ( $post && PostType::SLUG === $post->post_type ) {
			return $args;
		}

		// We don't register secure files as wp_posts attachments, so the default
		// behavior already hides them. This hook is kept for defensive coverage
		// if a future feature changes that decision.
		return $args;
	}
}
