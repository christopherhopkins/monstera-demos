<?php
declare(strict_types=1);

namespace Monstera\Content;

final class Meta {

	public const VISIBILITY_PUBLISHED = 'published';
	public const VISIBILITY_PENDING   = 'pending';
	public const VISIBILITY_HIDDEN    = 'hidden';

	public const CLICK_FILE = 'file';
	public const CLICK_POST = 'post';

	public const KEY_VISIBILITY            = 'monstera_visibility';
	public const KEY_CLICK_BEHAVIOR        = 'monstera_click_behavior';
	public const KEY_ORG_IDS               = 'monstera_associated_orgs';
	public const KEY_STANDALONE_MEMBER_IDS = 'monstera_associated_standalone_members';
	public const KEY_SECURE_FILE_ID        = 'monstera_secure_file_id';
	public const KEY_PUBLISHED_NOTIFIED    = 'monstera_first_publish_notified';
	public const KEY_SUMMARY               = 'monstera_summary';
	// "Send to everyone": every member may see the item, in an organization
	// or standalone. Off, the audience is the listed organizations and
	// members, and an empty list means nobody.
	public const KEY_AUDIENCE_EVERYONE = 'monstera_audience_everyone';

	public static function register(): void {
		register_post_meta(
			PostType::SLUG,
			self::KEY_VISIBILITY,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::VISIBILITY_PUBLISHED,
				'show_in_rest'      => [
					'schema' => [
						'enum' => [ self::VISIBILITY_PUBLISHED, self::VISIBILITY_PENDING, self::VISIBILITY_HIDDEN ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ self::VISIBILITY_PUBLISHED, self::VISIBILITY_PENDING, self::VISIBILITY_HIDDEN ], true ) ? $v : self::VISIBILITY_PUBLISHED,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_CLICK_BEHAVIOR,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => self::CLICK_FILE,
				'show_in_rest'      => [
					'schema' => [ 'enum' => [ self::CLICK_FILE, self::CLICK_POST ] ],
				],
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ self::CLICK_FILE, self::CLICK_POST ], true ) ? $v : self::CLICK_FILE,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_ORG_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_STANDALONE_MEMBER_IDS,
			[
				'type'              => 'array',
				'single'            => true,
				'default'           => [],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [ 'type' => 'integer' ],
					],
				],
				'sanitize_callback' => static fn ( $v ) => array_map( 'absint', (array) $v ),
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SECURE_FILE_ID,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_PUBLISHED_NOTIFIED,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => false,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_AUDIENCE_EVERYONE,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => false,
				'show_in_rest'      => true,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
			]
		);

		register_post_meta(
			PostType::SLUG,
			self::KEY_SUMMARY,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'wp_kses_post',
			]
		);
	}
}
