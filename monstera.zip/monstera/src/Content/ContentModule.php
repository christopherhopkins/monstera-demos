<?php
declare(strict_types=1);

namespace Monstera\Content;

use Monstera\Core\Hooks;
use Monstera\Core\Module;

final class ContentModule implements Module {

	public function slug(): string {
		return 'content';
	}

	public function boot(): void {
		add_action( 'init', [ $this, 'registerPostTypes' ], 5 );
		add_action( 'init', [ Meta::class, 'register' ], 7 );
		add_action( 'transition_post_status', [ $this, 'onTransition' ], 10, 3 );
		add_filter( 'ajax_query_attachments_args', [ MediaLibraryFilter::class, 'hideSecure' ] );
		add_filter( Hooks::FILTER_CONTENT_LABELS, [ $this, 'applyContentLabelOverride' ] );
	}

	/**
	 * Apply the per-site Content rename chosen during onboarding. setUseCase()
	 * stores ['name' => 'Publications' | 'Deliverables' | 'Content'] in the
	 * monstera_content_labels option (Settings › Content types writes any name);
	 * this folds it into the CPT labels via the FILTER_CONTENT_LABELS filter,
	 * which PostType::register() applies and PostType::label()/noun() read live
	 * for the portal's org page tab, the Manage section and the admin rail.
	 *
	 * @param array<string, string> $labels
	 * @return array<string, string>
	 */
	public function applyContentLabelOverride( array $labels ): array {
		$override = get_option( 'monstera_content_labels', [] );
		$name     = is_array( $override ) ? trim( (string) ( $override['name'] ?? '' ) ) : '';
		if ( '' === $name ) {
			return $labels;
		}
		$labels['name']          = $name;
		$labels['menu_name']     = $name;
		$labels['singular_name'] = PostType::singular( $name );
		return $labels;
	}

	public function registerPostTypes(): void {
		PostType::register();
	}

	public function onTransition( string $newStatus, string $oldStatus, \WP_Post $post ): void {
		if ( PostType::SLUG !== $post->post_type ) {
			return;
		}
		if ( 'publish' === $newStatus && 'publish' !== $oldStatus ) {
			// First publish.
			if ( ! (bool) get_post_meta( $post->ID, Meta::KEY_PUBLISHED_NOTIFIED, true ) ) {
				do_action( Hooks::CONTENT_PUBLISHED, $post->ID );
				update_post_meta( $post->ID, Meta::KEY_PUBLISHED_NOTIFIED, '1' );
				return;
			}
			// Re-publish from Pending → Published counts as "unlocked."
			if ( 'pending' === $oldStatus ) {
				do_action( Hooks::CONTENT_UNLOCKED, $post->ID );
				return;
			}
		}
		if ( 'publish' === $newStatus && 'publish' === $oldStatus ) {
			do_action( Hooks::CONTENT_UPDATED, $post->ID );
		}
	}
}
