<?php
declare(strict_types=1);

namespace Monstera\Content;

use Monstera\Core\Capabilities;
use Monstera\Organizations\Repository as OrgRepository;
use Monstera\Organizations\Roster;
use Monstera\Portal\AudienceShown;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Who can read a content item, as the visibility engine decides it, and how
 * many of them a reader is told of. The admin's "Who can see this" and its
 * head's "Visible to N members" read the whole audience; the portal's
 * download panel tells a reader who is not staff of their own part alone
 * (the owner, 2026-10-19): the members of their organizations on the site
 * that the item reaches who can read it, the reader among them, so another
 * client's headcount is never in it. Staff there read the whole count.
 *
 * The engine is primed for every candidate before it judges them: their
 * memberships in one read and their accounts in another, while the item's
 * gates and each sub-group's and project's people are read once and kept
 * (Visibility), so a count costs the same however many people it judges.
 */
final class Readers {

	/**
	 * Everyone who might read the item, before the engine decides: every
	 * member for content for everyone, otherwise the audience organizations'
	 * members and the standalone members listed; and the staff. A person is
	 * listed once, however many of the organizations they are in.
	 *
	 * @return list<WP_User>
	 */
	public static function candidates( int $contentId ): array {
		$admins = get_users(
			[
				'role__in' => [ 'administrator', Capabilities::ROLE_ADMIN, Capabilities::ROLE_TEAM_MEMBER ],
				'number'   => -1,
			]
		);
		if ( (bool) get_post_meta( $contentId, Meta::KEY_AUDIENCE_EVERYONE, true ) ) {
			$audience = get_users(
				[
					'role__in' => [ Capabilities::ROLE_ORG_MANAGER, Capabilities::ROLE_MEMBER, Capabilities::ROLE_MEMBER_STANDALONE ],
					'number'   => -1,
				]
			);
		} else {
			$orgIds = array_filter( array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_ORG_IDS, true ) ) );
			// The audience organizations' members through the Roster (a person
			// in two of them once, the organizations read together) and the
			// standalone members listed.
			$ids      = array_filter( array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_STANDALONE_MEMBER_IDS, true ) ) );
			$audience = self::accounts( array_merge( $ids, self::membersOf( $orgIds ) ) );
		}
		$byId = [];
		foreach ( array_merge( $audience, $admins ) as $user ) {
			$byId[ (int) $user->ID ] = $user;
		}
		// The engine asks each candidate's organizations: one query for them all first.
		Roster::prime( array_keys( $byId ) );
		return array_values( $byId );
	}

	/**
	 * The candidates the engine lets read the item, in the candidates' order.
	 *
	 * @return list<WP_User>
	 */
	public static function allowed( int $contentId, Visibility $visibility ): array {
		return array_values( array_filter( self::candidates( $contentId ), static fn ( WP_User $user ): bool => $visibility->userCanSee( $user, $contentId ) ) );
	}

	/**
	 * How many members, not the team, the engine lets read the item: the
	 * admin head's "Visible to N members".
	 */
	public static function memberCount( int $contentId, Visibility $visibility ): int {
		return count( array_filter( self::allowed( $contentId, $visibility ), static fn ( WP_User $user ): bool => ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) );
	}

	/**
	 * The figure the portal's download panel gives this reader: the whole
	 * audience's for staff (memberCount()); for anyone else the members of
	 * their own organizations on the site that the item reaches (every one
	 * of theirs for an item for everyone) who can read it, the reader among
	 * them, or 0 when it reaches them through none of their organizations:
	 * a standalone reader, or an item that names them. The panel leaves the
	 * line out at 0.
	 */
	public static function visibleTo( WP_User $reader, int $contentId, Visibility $visibility ): int {
		if ( AudienceShown::whole( $reader ) ) {
			return self::memberCount( $contentId, $visibility );
		}
		$own     = OrgRepository::onSite( Roster::orgIdsOf( (int) $reader->ID ) );
		$reached = (bool) get_post_meta( $contentId, Meta::KEY_AUDIENCE_EVERYONE, true )
			? $own
			: array_values( array_intersect( $own, array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_ORG_IDS, true ) ) ) );
		$people  = self::accounts( self::membersOf( $reached ) );
		Roster::prime( array_map( static fn ( WP_User $user ): int => (int) $user->ID, $people ) );
		return count( array_filter( $people, static fn ( WP_User $user ): bool => ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) && $visibility->userCanSee( $user, $contentId ) ) );
	}

	/**
	 * The members of these organizations, each once, their rosters read
	 * together.
	 *
	 * @param array<int, int> $orgIds
	 * @return list<int>
	 */
	private static function membersOf( array $orgIds ): array {
		if ( ! $orgIds ) {
			return [];
		}
		Roster::primeOrgs( $orgIds );
		$ids = [];
		foreach ( $orgIds as $orgId ) {
			$ids = array_merge( $ids, Roster::memberIds( (int) $orgId ) );
		}
		return array_values( array_unique( array_map( 'intval', $ids ) ) );
	}

	/**
	 * The accounts behind these ids, in one query; an id whose account has
	 * gone is not among them. An empty include would answer with everyone,
	 * so none is asked.
	 *
	 * @param array<int, int> $ids
	 * @return list<WP_User>
	 */
	private static function accounts( array $ids ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		return $ids
			? array_values(
				get_users(
					[
						'include' => $ids,
						'number'  => -1,
					]
				)
			)
			: [];
	}
}
