<?php
/**
 * The 6-rule content visibility engine.
 *
 * This is the single source of truth for "can member M see content C?" — used
 * by portal queries, the secure download handler, the REST API, and the
 * "Why can't my member see this?" admin wizard. Every rule is named and the
 * verdict is structured (which rule passed/failed and why) so admins can
 * inspect the answer end to end.
 */

declare(strict_types=1);

namespace Monstera\Content;

use Monstera\Core\Hooks;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_User;

final class Visibility {

	public const RULE_PUBLISHED_STATUS = 'published_status';
	public const RULE_ORG_ASSOCIATED   = 'org_associated';
	public const RULE_VISIBILITY_META  = 'visibility_meta';
	public const RULE_SUBGROUP_GATE    = 'subgroup_gate';
	public const RULE_PROJECT_GATE     = 'project_gate';
	public const RULE_ORG_ACTIVE       = 'org_active';

	/**
	 * What gates each content item, and who is in each gate, read once per
	 * instance: "who can see this" and the new-content email ask about one
	 * item for every candidate, and asked the same questions each time.
	 *
	 * @var array<string, array<int, int[]>>
	 */
	private array $memo = [
		'content_subgroups' => [],
		'content_projects'  => [],
		'subgroup_members'  => [],
		'project_members'   => [],
	];

	public function __construct(
		private SubgroupRepository $subgroups,
		private ?ProjectRepository $projects = null
	) {}

	/**
	 * @param callable(): int[] $read
	 * @return int[]
	 */
	private function once( string $what, int $id, callable $read ): array {
		if ( ! isset( $this->memo[ $what ][ $id ] ) ) {
			$this->memo[ $what ][ $id ] = array_map( 'intval', $read() );
		}
		return $this->memo[ $what ][ $id ];
	}

	/**
	 * Whether someone is in any of the groups (sub-groups or project teams).
	 *
	 * @param int[]                 $groupIds
	 * @param callable(int): int[] $members
	 */
	private function inAny( string $what, array $groupIds, int $userId, callable $members ): bool {
		foreach ( $groupIds as $groupId ) {
			if ( in_array( $userId, $this->once( $what, (int) $groupId, static fn (): array => $members( (int) $groupId ) ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Run the full check and return a structured verdict.
	 *
	 * @return Verdict
	 */
	public function evaluate( WP_User $user, int $contentId ): Verdict {
		$post = get_post( $contentId );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return Verdict::fail( self::RULE_PUBLISHED_STATUS, __( 'Content not found.', 'monstera' ) );
		}

		$rules = [];

		// Rule 1: post is published.
		$rules[ self::RULE_PUBLISHED_STATUS ] = 'publish' === $post->post_status
			? RuleResult::pass( __( 'Post status is Published.', 'monstera' ) )
			: RuleResult::fail(
				sprintf(
				/* translators: %s: WP post status */
					__( 'Post status is %s, not Published.', 'monstera' ),
					$post->post_status
				)
			);

		// Rule 2: member's org OR member's own ID is in the content's audience.
		$memberOrg      = UserMeta::associatedOrg( $user->ID );
		$contentOrgs    = array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_ORG_IDS, true ) );
		$contentMembers = array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_STANDALONE_MEMBER_IDS, true ) );
		$memberHasOrg   = $memberOrg > 0;
		$orgMatch       = $memberHasOrg && in_array( $memberOrg, $contentOrgs, true );
		$memberMatch    = in_array( (int) $user->ID, $contentMembers, true );

		// Admins always pass the org check.
		$isAdmin = user_can( $user, 'manage_monstera' );

		$everyone = (bool) get_post_meta( $contentId, Meta::KEY_AUDIENCE_EVERYONE, true );

		if ( $isAdmin ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'Admin override.', 'monstera' ) );
		} elseif ( $everyone ) {
			// "Send to everyone" is an explicit choice, not an empty list: every
			// member passes here, and the organization-active rule below still
			// pauses a suspended organization and hides from an archived one.
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'This content is for everyone.', 'monstera' ) );
		} elseif ( ! $contentOrgs && ! $contentMembers ) {
			// Fail closed: an empty audience means "unconfigured," NOT "visible
			// to everyone." Only admins (handled above) see such an item until
			// an explicit org or standalone-member audience is assigned. This
			// prevents accidental exposure when an item is published before its
			// audience is set. ("Visible to all" is the explicit everyone flag
			// above.)
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::fail( __( 'No audience has been assigned to this content yet.', 'monstera' ) );
		} elseif ( $memberMatch ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'Member is in the standalone audience list.', 'monstera' ) );
		} elseif ( $orgMatch ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'Member\'s organization is associated.', 'monstera' ) );
		} elseif ( ! $memberHasOrg ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::fail( __( 'Member is not associated with any organization and not in the standalone audience list.', 'monstera' ) );
		} else {
			$orgName                            = get_the_title( $memberOrg );
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::fail(
				sprintf(
				/* translators: %s: org name */
					__( 'Member\'s organization "%s" is not in this content\'s audience.', 'monstera' ),
					$orgName
				)
			);
		}

		// Rule 3: Visibility meta is "Published" (not Pending/Hidden).
		$visibility                          = (string) ( get_post_meta( $contentId, Meta::KEY_VISIBILITY, true ) ?: Meta::VISIBILITY_PUBLISHED );
		$rules[ self::RULE_VISIBILITY_META ] = Meta::VISIBILITY_PUBLISHED === $visibility
			? RuleResult::pass( __( 'Visibility is Published.', 'monstera' ) )
			: RuleResult::fail(
				sprintf(
				/* translators: %s: visibility status */
					__( 'Visibility is %s.', 'monstera' ),
					ucfirst( $visibility )
				)
			);

		// Rule 4: Sub-group gate (if any subgroups assigned to content, member must be in one).
		$contentSubgroups = $this->once( 'content_subgroups', $contentId, fn (): array => $this->subgroups->subgroupsForContent( $contentId ) );
		if ( ! $contentSubgroups ) {
			$rules[ self::RULE_SUBGROUP_GATE ] = RuleResult::pass( __( 'No sub-group restriction.', 'monstera' ), true );
		} else {
			$overlap                           = $this->inAny( 'subgroup_members', $contentSubgroups, (int) $user->ID, fn ( int $id ): array => $this->subgroups->memberIds( $id ) );
			$rules[ self::RULE_SUBGROUP_GATE ] = $overlap || $isAdmin
				? RuleResult::pass( __( 'Member belongs to a required sub-group.', 'monstera' ) )
				: RuleResult::fail( __( 'Member is not in any of the required sub-groups.', 'monstera' ) );
		}

		// Rule 5: Project gate (if any projects assigned to content, member must be on the project team).
		$contentProjects = $this->once( 'content_projects', $contentId, fn (): array => $this->projects?->projectsForContent( $contentId ) ?? [] );
		if ( ! $contentProjects ) {
			$rules[ self::RULE_PROJECT_GATE ] = RuleResult::pass( __( 'No project restriction.', 'monstera' ), true );
		} else {
			$overlap                          = $this->inAny( 'project_members', $contentProjects, (int) $user->ID, fn ( int $id ): array => $this->projects?->memberIds( $id ) ?? [] );
			$rules[ self::RULE_PROJECT_GATE ] = $overlap || $isAdmin
				? RuleResult::pass( __( 'Member is on a project team for this content.', 'monstera' ) )
				: RuleResult::fail( __( 'Member is not on any of the required project teams.', 'monstera' ) );
		}

		// Rule 6: Member's org is Active (Suspended → see-but-blocked; Archived → hidden).
		if ( $memberHasOrg ) {
			$orgStatus = (string) ( get_post_meta( $memberOrg, OrgMeta::KEY_STATUS, true ) ?: OrgMeta::STATUS_ACTIVE );
			if ( OrgMeta::STATUS_ACTIVE === $orgStatus || $isAdmin ) {
				$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::pass( __( 'Organization is Active.', 'monstera' ) );
			} elseif ( OrgMeta::STATUS_SUSPENDED === $orgStatus ) {
				$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::fail( __( 'Organization is Suspended — content is visible but blurred and not downloadable.', 'monstera' ), 'soft' );
			} else {
				$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::fail( __( 'Organization is Archived.', 'monstera' ) );
			}
		} else {
			$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::pass( __( 'Standalone member; org-active rule skipped.', 'monstera' ), true );
		}

		$verdict = Verdict::fromRules( $rules );

		return apply_filters( Hooks::FILTER_VISIBILITY_RESULT, $verdict, $user, $contentId, $post );
	}

	public function userCanSee( WP_User $user, int $contentId ): bool {
		return $this->evaluate( $user, $contentId )->allowed;
	}

	public function userCanDownload( WP_User $user, int $contentId ): bool {
		$verdict = $this->evaluate( $user, $contentId );
		if ( ! $verdict->allowed ) {
			return false;
		}
		// Suspended-org soft fail blocks downloads even though item is visible.
		$orgRule = $verdict->rules[ self::RULE_ORG_ACTIVE ] ?? null;
		return ! ( $orgRule && 'soft' === $orgRule->failureKind );
	}
}
