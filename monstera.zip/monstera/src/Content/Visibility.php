<?php
/**
 * The 6-rule content visibility engine.
 *
 * This is the single source of truth for "can member M see content C?" — used
 * by portal queries, the secure download handler, the REST API, and the
 * "Why can't my member see this?" admin wizard. Every rule is named and the
 * verdict is structured (which rule passed/failed and why) so admins can
 * inspect the answer end to end.
 *
 * An ended membership is not a seventh rule. The page guard answers an
 * ended organization's pages with "Membership ended", which it could not
 * do for an item the engine denied, so the item stays allowed and the
 * verdict carries `endedBlocked` beside the rules: the file waits on a
 * renewal. userCanDownload() reads it, and through it every template that
 * mints a link and the download route.
 */

declare(strict_types=1);

namespace Monstera\Content;

use Monstera\AccessControl\PortalGuard;
use Monstera\Core\Hooks;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Organizations\Reach;
use Monstera\Organizations\Roster;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Visibility {

	public const RULE_PUBLISHED_STATUS = 'published_status';
	public const RULE_ORG_ASSOCIATED   = 'org_associated';
	public const RULE_VISIBILITY_META  = 'visibility_meta';
	public const RULE_SUBGROUP_GATE    = 'subgroup_gate';
	public const RULE_PROJECT_GATE     = 'project_gate';
	public const RULE_ORG_ACTIVE       = 'org_active';

	/**
	 * What gates each content item, and who is in each gate, read once per
	 * instance: "who can see this" and the new-content email ask about one
	 * item for every candidate, and asked the same questions each time.
	 *
	 * @var array<string, array<int, int[]>>
	 */
	private array $memo = [
		'content_subgroups' => [],
		'content_projects'  => [],
		'subgroup_members'  => [],
		'project_members'   => [],
	];

	public function __construct(
		private SubgroupRepository $subgroups,
		private ?ProjectRepository $projects = null
	) {}

	/**
	 * @param callable(): int[] $read
	 * @return int[]
	 */
	private function once( string $what, int $id, callable $read ): array {
		if ( ! isset( $this->memo[ $what ][ $id ] ) ) {
			$this->memo[ $what ][ $id ] = array_map( 'intval', $read() );
		}
		return $this->memo[ $what ][ $id ];
	}

	/**
	 * Read what gates each of many items before a loop that judges them:
	 * their sub-groups in one read and their projects in another, however
	 * many items there are. evaluate() asks both of every item, a read each,
	 * so a page that counts what a reader can see of several organizations
	 * (the dashboard's bands) would otherwise pay two reads for every item
	 * any of them holds. An item with no gate is remembered as having none,
	 * and one already read is not asked for again.
	 *
	 * @param array<int, mixed> $contentIds
	 */
	public function prime( array $contentIds ): void {
		$wanted = [];
		foreach ( array_unique( array_map( 'intval', $contentIds ) ) as $contentId ) {
			if ( $contentId > 0 && ! isset( $this->memo['content_subgroups'][ $contentId ], $this->memo['content_projects'][ $contentId ] ) ) {
				$wanted[] = $contentId;
			}
		}
		if ( ! $wanted ) {
			return;
		}
		$this->memo['content_subgroups'] = $this->subgroups->subgroupsForContents( $wanted ) + $this->memo['content_subgroups'];
		$this->memo['content_projects']  = ( $this->projects?->projectsForContents( $wanted ) ?? array_fill_keys( $wanted, [] ) ) + $this->memo['content_projects'];
	}

	/**
	 * Whether someone is in any of the groups (sub-groups or project teams).
	 *
	 * @param int[]                 $groupIds
	 * @param callable(int): int[] $members
	 */
	private function inAny( string $what, array $groupIds, int $userId, callable $members ): bool {
		foreach ( $groupIds as $groupId ) {
			if ( in_array( $userId, $this->once( $what, (int) $groupId, static fn (): array => $members( (int) $groupId ) ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Run the full check and return a structured verdict.
	 *
	 * @return Verdict
	 */
	public function evaluate( WP_User $user, int $contentId ): Verdict {
		$post = get_post( $contentId );
		if ( ! $post || PostType::SLUG !== $post->post_type ) {
			return Verdict::fail( self::RULE_PUBLISHED_STATUS, __( 'Content not found.', 'monstera' ) );
		}

		$rules = [];

		// Rule 1: post is published.
		$rules[ self::RULE_PUBLISHED_STATUS ] = 'publish' === $post->post_status
			? RuleResult::pass( __( 'Post status is Published.', 'monstera' ) )
			: RuleResult::fail(
				sprintf(
				/* translators: %s: WP post status */
					__( 'Post status is %s, not Published.', 'monstera' ),
					$post->post_status
				)
			);

		// Rule 2: one of the member's organizations OR the member's own ID is in
		// the content's audience. A person may belong to several organizations
		// (People-model track, FR8), so the ones that grant the item are kept,
		// in membership order, for rule 6 to judge.
		$memberOrgs     = Roster::orgIdsOf( (int) $user->ID );
		$contentOrgs    = array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_ORG_IDS, true ) );
		$contentMembers = array_map( 'intval', (array) get_post_meta( $contentId, Meta::KEY_STANDALONE_MEMBER_IDS, true ) );
		$memberMatch    = in_array( (int) $user->ID, $contentMembers, true );

		// Admins always pass the org check.
		$isAdmin = user_can( $user, 'manage_monstera' );

		$everyone = (bool) get_post_meta( $contentId, Meta::KEY_AUDIENCE_EVERYONE, true );

		// The organizations the member reaches this item through: every one of
		// theirs for content for everyone, those in the audience otherwise
		// (array_intersect keeps the first array's order: membership order).
		// An admin override and a standalone-list match reach it through none.
		$granting = $everyone ? $memberOrgs : array_values( array_intersect( $memberOrgs, $contentOrgs ) );

		if ( $isAdmin ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'Admin override.', 'monstera' ) );
			$granting                           = [];
		} elseif ( $everyone ) {
			// "Send to everyone" is an explicit choice, not an empty list: every
			// member passes here, and the organization-active rule below still
			// pauses a suspended organization and hides from an archived one.
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'This content is for everyone.', 'monstera' ) );
		} elseif ( ! $contentOrgs && ! $contentMembers ) {
			// Fail closed: an empty audience means "unconfigured," NOT "visible
			// to everyone." Only admins (handled above) see such an item until
			// an explicit org or standalone-member audience is assigned. This
			// prevents accidental exposure when an item is published before its
			// audience is set. ("Visible to all" is the explicit everyone flag
			// above.)
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::fail( __( 'No audience has been assigned to this content yet.', 'monstera' ) );
		} elseif ( $memberMatch ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'Member is in the standalone audience list.', 'monstera' ) );
			$granting                           = [];
		} elseif ( $granting ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::pass( __( 'One of the member\'s organizations is associated.', 'monstera' ) );
		} elseif ( ! $memberOrgs ) {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::fail( __( 'Member is not associated with any organization and not in the standalone audience list.', 'monstera' ) );
		} else {
			$rules[ self::RULE_ORG_ASSOCIATED ] = RuleResult::fail(
				sprintf(
				/* translators: %s: the member's organizations' names, comma-separated */
					__( 'None of the member\'s organizations (%s) is in this content\'s audience.', 'monstera' ),
					$this->names( $memberOrgs )
				)
			);
		}

		// Rule 3: Visibility meta is "Published" (not Pending/Hidden).
		$visibility                          = (string) ( get_post_meta( $contentId, Meta::KEY_VISIBILITY, true ) ?: Meta::VISIBILITY_PUBLISHED );
		$rules[ self::RULE_VISIBILITY_META ] = Meta::VISIBILITY_PUBLISHED === $visibility
			? RuleResult::pass( __( 'Visibility is Published.', 'monstera' ) )
			: RuleResult::fail(
				sprintf(
				/* translators: %s: visibility status */
					__( 'Visibility is %s.', 'monstera' ),
					ucfirst( $visibility )
				)
			);

		// Rule 4: Sub-group gate (if any subgroups assigned to content, member must be in one).
		$contentSubgroups = $this->once( 'content_subgroups', $contentId, fn (): array => $this->subgroups->subgroupsForContent( $contentId ) );
		if ( ! $contentSubgroups ) {
			$rules[ self::RULE_SUBGROUP_GATE ] = RuleResult::pass( __( 'No sub-group restriction.', 'monstera' ), true );
		} else {
			$overlap                           = $this->inAny( 'subgroup_members', $contentSubgroups, (int) $user->ID, fn ( int $id ): array => $this->subgroups->memberIds( $id ) );
			$rules[ self::RULE_SUBGROUP_GATE ] = $overlap || $isAdmin
				? RuleResult::pass( __( 'Member belongs to a required sub-group.', 'monstera' ) )
				: RuleResult::fail( __( 'Member is not in any of the required sub-groups.', 'monstera' ) );
		}

		// Rule 5: Project gate (if any projects assigned to content, member must
		// be one of a project's members). The sentences say "members": the Test
		// visibility wizard prints them, and "team" is the internal team in
		// admin copy (People-model track, Vocabulary).
		$contentProjects = $this->once( 'content_projects', $contentId, fn (): array => $this->projects?->projectsForContent( $contentId ) ?? [] );
		if ( ! $contentProjects ) {
			$rules[ self::RULE_PROJECT_GATE ] = RuleResult::pass( __( 'No project restriction.', 'monstera' ), true );
		} else {
			$overlap                          = $this->inAny( 'project_members', $contentProjects, (int) $user->ID, fn ( int $id ): array => $this->projects?->memberIds( $id ) ?? [] );
			$rules[ self::RULE_PROJECT_GATE ] = $overlap || $isAdmin
				? RuleResult::pass( __( 'Member is one of a required project\'s members.', 'monstera' ) )
				: RuleResult::fail( __( 'Member is not one of the members of any required project.', 'monstera' ) );
		}

		// Rule 6: the organizations that grant the item are Active (Suspended →
		// see-but-blocked; Archived → hidden), judged across them: one active
		// organization carries the item, so a suspended one pauses a download
		// only when no other of theirs shares it, and an archived one hides it
		// only when every one of theirs that shares it is archived. When none
		// grants it because rule 2 failed on the member's organizations, the
		// rule is judged over all of theirs instead: the verdict is already no,
		// and the wizard reads their standing beside its "Add" fix. The rule
		// does not apply only where no organization is involved at all: the
		// admin override, the standalone list, a person with no memberships.
		$judged = $granting;
		if ( ! $judged && $memberOrgs && ! $isAdmin && ! $memberMatch ) {
			$judged = $memberOrgs;
		}
		if ( ! $judged ) {
			$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::pass(
				$memberOrgs
					? __( 'Reached without an organization; org-active rule skipped.', 'monstera' )
					: __( 'Standalone member; org-active rule skipped.', 'monstera' ),
				true
			);
		} else {
			$byStatus = [
				OrgMeta::STATUS_ACTIVE    => [],
				OrgMeta::STATUS_SUSPENDED => [],
				OrgMeta::STATUS_ARCHIVED  => [],
			];
			foreach ( $judged as $orgId ) {
				$status = $this->orgStatus( $orgId );
				// Anything that is neither active nor suspended hides as archived does.
				$byStatus[ isset( $byStatus[ $status ] ) ? $status : OrgMeta::STATUS_ARCHIVED ][] = $orgId;
			}
			$one = 1 === count( $judged );
			if ( $byStatus[ OrgMeta::STATUS_ACTIVE ] ) {
				$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::pass(
					$one ? __( 'Organization is Active.', 'monstera' ) : __( 'At least one of the member\'s organizations is active.', 'monstera' )
				);
			} elseif ( $byStatus[ OrgMeta::STATUS_SUSPENDED ] ) {
				$suspended                      = $byStatus[ OrgMeta::STATUS_SUSPENDED ];
				$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::fail(
					1 === count( $suspended )
						? sprintf(
							/* translators: %s: an organization's name */
							__( 'Organization "%s" is Suspended — content is visible but blurred and not downloadable.', 'monstera' ),
							get_the_title( $suspended[0] )
						)
						: sprintf(
							/* translators: %s: the suspended organizations' names, comma-separated */
							__( 'Every organization that shares this is suspended: %s. Content is visible but blurred and not downloadable.', 'monstera' ),
							$this->names( $suspended )
						),
					'soft'
				);
			} else {
				$rules[ self::RULE_ORG_ACTIVE ] = RuleResult::fail(
					$one
						? __( 'Organization is Archived.', 'monstera' )
						: sprintf(
							/* translators: %s: the archived organizations' names, comma-separated */
							__( 'Every organization that shares this is archived: %s.', 'monstera' ),
							$this->names( $byStatus[ OrgMeta::STATUS_ARCHIVED ] )
						)
				);
			}
		}

		// What the wizard shows: each of the member's organizations, whether
		// the audience holds it, its status, and whether its membership has
		// ended, read where the guard reads it for its expired reason. The
		// verdict builds the list when it is first asked for (see Verdict):
		// userCanSee() runs once for every candidate of an audience and
		// never looks at it.
		$organizations = function () use ( $memberOrgs, $contentOrgs, $everyone ): array {
			$considered = [];
			foreach ( $memberOrgs as $orgId ) {
				$considered[] = [
					'id'          => $orgId,
					'name'        => get_the_title( $orgId ),
					'in_audience' => $everyone || in_array( $orgId, $contentOrgs, true ),
					'status'      => $this->orgStatus( $orgId ),
					'ended'       => PortalGuard::membershipExpired( $orgId ),
				];
			}
			return $considered;
		};

		// An ended membership pauses what it granted. The item stays allowed,
		// since the guard answers its page with "Membership ended" and not
		// with "not shared", but its file waits until an organization the
		// member reaches the item through is live again: one of them has
		// ended, and no other carries it, a suspended one no more than an
		// ended one. These are the organizations rule 6 judges, so content
		// for everyone is read over every organization of theirs: it still
		// downloads beside one live organization and waits when none is,
		// where the guard has no organization to answer its page for. The
		// admin override and the standalone list reach an item through none,
		// so those always download.
		$endedBlocked = array_filter( $granting, [ PortalGuard::class, 'membershipExpired' ] )
			&& ! array_filter( $granting, [ Reach::class, 'isLive' ] );

		$verdict = Verdict::fromRules( $rules, $organizations, $endedBlocked );

		return apply_filters( Hooks::FILTER_VISIBILITY_RESULT, $verdict, $user, $contentId, $post );
	}

	/** An organization's status; one with none recorded is active. */
	private function orgStatus( int $orgId ): string {
		return (string) ( get_post_meta( $orgId, OrgMeta::KEY_STATUS, true ) ?: OrgMeta::STATUS_ACTIVE );
	}

	/**
	 * Organizations' names as one list, in the order given.
	 *
	 * @param list<int> $orgIds
	 */
	private function names( array $orgIds ): string {
		return implode(
			/* translators: used between list items; there is a space after the comma */
			__( ', ', 'monstera' ),
			array_map( static fn ( int $id ): string => get_the_title( $id ), $orgIds )
		);
	}

	public function userCanSee( WP_User $user, int $contentId ): bool {
		return $this->evaluate( $user, $contentId )->allowed;
	}

	public function userCanDownload( WP_User $user, int $contentId ): bool {
		$verdict = $this->evaluate( $user, $contentId );
		if ( ! $verdict->allowed ) {
			return false;
		}
		// The soft fail blocks downloads even though the item is visible: every
		// organization the member reaches it through is suspended.
		$orgRule = $verdict->rules[ self::RULE_ORG_ACTIVE ] ?? null;
		if ( $orgRule && 'soft' === $orgRule->failureKind ) {
			return false;
		}
		// So does an ended membership with no live organization beside it:
		// the pages that span every organization stay open for a person with
		// another live one, so this, not the page guard, is what keeps the
		// file back, here for every template that mints a link and for the
		// download route.
		return ! $verdict->endedBlocked;
	}
}
