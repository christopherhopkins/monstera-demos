<?php
declare(strict_types=1);

namespace Monstera\Content;

use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

final class PostType {

	public const SLUG = 'monstera_content';

	/**
	 * The labels before any per-site rename.
	 *
	 * @return array<string, string>
	 */
	private static function defaults(): array {
		return [
			'name'               => __( 'Content', 'monstera' ),
			'singular_name'      => __( 'Item', 'monstera' ),
			'menu_name'          => __( 'Content', 'monstera' ),
			'add_new'            => __( 'Add item', 'monstera' ),
			'add_new_item'       => __( 'Add content item', 'monstera' ),
			'edit_item'          => __( 'Edit content item', 'monstera' ),
			'view_item'          => __( 'View content item', 'monstera' ),
			'search_items'       => __( 'Search content', 'monstera' ),
			'not_found'          => __( 'No content items yet.', 'monstera' ),
			'not_found_in_trash' => __( 'No content items in trash.', 'monstera' ),
		];
	}

	/**
	 * The labels after the per-site rename (Settings › Content types), read
	 * live so a save shows on the next request without re-registering.
	 *
	 * @return array<string, string>
	 */
	private static function labels(): array {
		return (array) apply_filters( Hooks::FILTER_CONTENT_LABELS, self::defaults() );
	}

	/**
	 * What this site calls its content, as a heading or a tab: "Content",
	 * "Deliverables", "Briefings". The portal's org page tab, the Manage
	 * section and the admin rail all read this.
	 */
	public static function label(): string {
		$name = trim( (string) ( self::labels()['name'] ?? '' ) );
		return '' !== $name ? $name : __( 'Content', 'monstera' );
	}

	/**
	 * The same word in running text: "your content", "your deliverables".
	 */
	public static function noun(): string {
		return mb_strtolower( self::label() );
	}

	/**
	 * One of them, in running text: "new content", "new deliverable". The
	 * default stays "content"; a rename drops a trailing "s", as the labels do.
	 */
	public static function nounSingular(): string {
		if ( self::label() === self::defaults()['name'] ) {
			return __( 'content', 'monstera' );
		}
		return self::singular( self::noun() );
	}

	/**
	 * One of a plural label, naively: one trailing "s" comes off ("Reports",
	 * "Deliverables", "Releases"). A word ending in "ss" is not a plural
	 * ("Business"), and an "-es" plural after a doubled s or z, an x, "sh" or
	 * "ch" ("Classes", "Boxes", "Batches") does not become a word by losing
	 * one letter, so those are left as they are.
	 */
	public static function singular( string $plural ): string {
		if ( ! preg_match( '/[^s]s$/i', $plural ) || preg_match( '/(?:sses|zzes|xes|shes|ches)$/i', $plural ) ) {
			return $plural;
		}
		return substr( $plural, 0, -1 );
	}

	public static function register(): void {
		$labels = self::labels();

		register_post_type(
			self::SLUG,
			[
				'labels'          => $labels,
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				'show_in_rest'    => true,
				'rest_base'       => 'content-items',
				'supports'        => [ 'title', 'editor', 'excerpt', 'custom-fields', 'revisions' ],
				'has_archive'     => false,
				'rewrite'         => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'capabilities'    => [
					'edit_posts'         => Capabilities::CAP_MANAGE_MONSTERA,
					'edit_others_posts'  => Capabilities::CAP_MANAGE_MONSTERA,
					'publish_posts'      => Capabilities::CAP_MANAGE_MONSTERA,
					'read_private_posts' => Capabilities::CAP_MANAGE_MONSTERA,
					'delete_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
					'create_posts'       => Capabilities::CAP_MANAGE_MONSTERA,
				],
			]
		);
	}
}
