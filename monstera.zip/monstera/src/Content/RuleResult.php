<?php
declare(strict_types=1);

namespace Monstera\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Single visibility-rule outcome.
 *
 * `failureKind` distinguishes hard failures (don't show the item at all)
 * from soft failures (show but blurred — e.g. suspended org). `notApplicable`
 * flags rules that were structurally skipped.
 */
final class RuleResult {

	public function __construct(
		public readonly bool $passed,
		public readonly string $message,
		public readonly bool $notApplicable = false,
		public readonly string $failureKind = 'hard'
	) {}

	public static function pass( string $message, bool $notApplicable = false ): self {
		return new self( true, $message, $notApplicable );
	}

	public static function fail( string $message, string $kind = 'hard' ): self {
		return new self( false, $message, false, $kind );
	}

	/**
	 * @return array<string, mixed>
	 */
	public function toArray(): array {
		return [
			'passed'        => $this->passed,
			'message'       => $this->message,
			'notApplicable' => $this->notApplicable,
			'failureKind'   => $this->failureKind,
		];
	}
}
