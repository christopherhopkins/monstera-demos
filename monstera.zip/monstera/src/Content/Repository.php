<?php
declare(strict_types=1);

namespace Monstera\Content;

use WP_Post;
use WP_Query;

final class Repository {

	public function find( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/**
	 * Content items associated with at least one of the given org IDs, and
	 * the items for everyone.
	 *
	 * @param int[] $orgIds
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forOrgs( array $orgIds, array $args = [] ): array {
		if ( ! $orgIds ) {
			return [];
		}
		// Content for everyone belongs in every organization's list.
		$meta_query = [
			'relation' => 'OR',
			[
				'key'   => Meta::KEY_AUDIENCE_EVERYONE,
				'value' => '1',
			],
		];
		foreach ( $orgIds as $orgId ) {
			$meta_query[] = [
				'key'     => Meta::KEY_ORG_IDS,
				'value'   => sprintf( ':%d;', (int) $orgId ), // matches serialized integer in meta
				'compare' => 'LIKE',
			];
		}

		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'date',
					'order'          => 'DESC',
					'no_found_rows'  => true,
					'meta_query'     => $meta_query,
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * Content for someone with no organization: the items for everyone and
	 * the ones that name them. (forOrgs() has nothing to ask about, so their
	 * dashboard once listed nothing.)
	 *
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forStandalone( int $userId, array $args = [] ): array {
		if ( $userId <= 0 ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'date',
					'order'          => 'DESC',
					'no_found_rows'  => true,
					'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- the audience lives in post meta by design.
						'relation' => 'OR',
						[
							'key'   => Meta::KEY_AUDIENCE_EVERYONE,
							'value' => '1',
						],
						[
							'key'     => Meta::KEY_STANDALONE_MEMBER_IDS,
							'value'   => sprintf( ':%d;', $userId ), // matches serialized integer in meta
							'compare' => 'LIKE',
						],
					],
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @param array<int, \WP_Post> $posts
	 * @return array<int, array{id: int, title: string, summary: string, date: string, click: string, visibility: string, author: int}>
	 */
	public function summarize( array $posts ): array {
		$out = [];
		foreach ( $posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$out[ $post->ID ] = [
				'id'         => $post->ID,
				'title'      => get_the_title( $post ),
				'summary'    => (string) ( get_post_meta( $post->ID, Meta::KEY_SUMMARY, true ) ?: wp_strip_all_tags( $post->post_excerpt ) ),
				'date'       => get_post_time( 'c', true, $post ),
				'click'      => (string) ( get_post_meta( $post->ID, Meta::KEY_CLICK_BEHAVIOR, true ) ?: Meta::CLICK_FILE ),
				'visibility' => (string) ( get_post_meta( $post->ID, Meta::KEY_VISIBILITY, true ) ?: Meta::VISIBILITY_PUBLISHED ),
				'author'     => (int) $post->post_author,
			];
		}
		return $out;
	}
}
