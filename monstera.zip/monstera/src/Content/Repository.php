<?php
declare(strict_types=1);

namespace Monstera\Content;

use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function find( int $id ): ?WP_Post {
		$post = get_post( $id );
		return $post instanceof WP_Post && PostType::SLUG === $post->post_type ? $post : null;
	}

	/**
	 * Content items associated with at least one of the given org IDs, and
	 * the items for everyone.
	 *
	 * @param int[] $orgIds
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forOrgs( array $orgIds, array $args = [] ): array {
		if ( ! $orgIds ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'date',
					'order'          => 'DESC',
					'no_found_rows'  => true,
					'meta_query'     => self::audienceOf( $orgIds ),
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * Each organization's newest items, up to a limit apiece, as ids, for a
	 * page that counts what several organizations hold (the dashboard's
	 * bands). One organization is asked as forOrgs() asks it. Several are
	 * read together: the ids of everything that reaches any of them, newest
	 * first, are filed under each organization the item names, or under all
	 * of them when it is for everyone, as forOrgs() files it, until every
	 * organization holds its limit. Whose an item is comes from its two
	 * audience keys alone, so an item passed over costs two short rows and
	 * none of the rest of its meta (its summary, its file); only what is kept
	 * is loaded, post and meta, since whoever judges it next asks for both.
	 * So six organizations cost the reads two do (the ids, whose they are,
	 * the posts kept and their meta), and a site with thousands of items
	 * loads no more of them than the limit apiece.
	 *
	 * The first two reads are of every item that reaches any of the
	 * organizations: an id, and two short meta rows, for each. The walk
	 * below stops once every organization holds its limit, which saves the
	 * filing and none of the reading, since both reads are made before it
	 * starts. They are not read a slice at a time, on purpose. A slice can
	 * end the reading early only when every organization asked about has
	 * its limit of items, and an organization with fewer than the limit,
	 * which is most of them, never does: the walk would then read to the
	 * end slice by slice, two reads for each, and the page's reads would
	 * grow with the site where they are now the same few whatever it holds
	 * (QueryCostTest). Past some tens of thousands of items the ids and
	 * their audience rows are the cost, and what answers that is a count
	 * kept per organization, not a different way of walking.
	 *
	 * @param array<int, mixed> $orgIds
	 * @return array<int, list<int>> Content ids by organization id, newest first.
	 */
	public function newestIdsByOrg( array $orgIds, int $limit ): array {
		$orgIds = array_values( array_unique( array_filter( array_map( 'intval', $orgIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		$out    = array_fill_keys( $orgIds, [] );
		if ( count( $orgIds ) < 2 ) {
			foreach ( $orgIds as $orgId ) {
				$out[ $orgId ] = array_map( static fn ( WP_Post $post ): int => (int) $post->ID, $this->forOrgs( [ $orgId ], [ 'posts_per_page' => $limit ] ) );
			}
			return $out;
		}
		$ids       = $this->idsForOrgs( $orgIds );
		$audiences = $this->audiencesOf( $ids );
		// How many organizations are still short of their limit: the walk ends
		// with the last of them, not with the last item.
		$short = count( $orgIds );
		foreach ( $ids as $id ) {
			$everyone = '1' === ( $audiences[ $id ][ Meta::KEY_AUDIENCE_EVERYONE ] ?? '' );
			$named    = array_map( 'intval', (array) maybe_unserialize( $audiences[ $id ][ Meta::KEY_ORG_IDS ] ?? '' ) );
			foreach ( $everyone ? $orgIds : array_intersect( $orgIds, $named ) as $orgId ) {
				if ( count( $out[ $orgId ] ) < $limit ) {
					$out[ $orgId ][] = $id;
					$short          -= count( $out[ $orgId ] ) === $limit ? 1 : 0;
				}
			}
			if ( $short < 1 ) {
				break;
			}
		}
		_prime_post_caches( array_values( array_unique( array_merge( ...array_values( $out ) ) ) ), false, true );
		return $out;
	}

	/**
	 * Whose each of these items is: its two audience keys, the organizations
	 * it names and whether it is for everyone, from one read and with none of
	 * the rest of its meta. For a caller that walks many items to keep a few
	 * (newestIdsByOrg()); one that goes on to judge an item wants all of its
	 * meta and loads it the usual way. Where a key was written twice the
	 * first row answers, as get_post_meta() answers.
	 *
	 * @param list<int> $ids
	 * @return array<int, array<string, string>> The stored values by content id, then by meta key; a key the item never had is absent.
	 */
	private function audiencesOf( array $ids ): array {
		if ( ! $ids ) {
			return [];
		}
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $marks is a list of %d built from count( $ids ); every id goes through prepare().
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta}
				  WHERE meta_key IN (%s, %s) AND post_id IN ($marks)
				  ORDER BY meta_id",
				Meta::KEY_AUDIENCE_EVERYONE,
				Meta::KEY_ORG_IDS,
				...$ids
			),
			ARRAY_A
		);
		// phpcs:enable
		$out = [];
		foreach ( $rows as $row ) {
			$out[ (int) $row['post_id'] ][ (string) $row['meta_key'] ] ??= (string) $row['meta_value'];
		}
		return $out;
	}

	/**
	 * The ids of every published item that reaches any of the organizations,
	 * newest first: forOrgs()'s question, answered without the posts.
	 *
	 * @param list<int> $orgIds
	 * @return list<int>
	 */
	private function idsForOrgs( array $orgIds ): array {
		$query = new WP_Query(
			[
				'post_type'              => PostType::SLUG,
				'post_status'            => 'publish',
				'posts_per_page'         => -1,
				'orderby'                => 'date',
				'order'                  => 'DESC',
				'no_found_rows'          => true,
				'fields'                 => 'ids',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_query'             => self::audienceOf( $orgIds ),
			]
		);
		return array_values( array_map( 'intval', $query->posts ) );
	}

	/**
	 * The meta query that finds what reaches a list of organizations: the
	 * items that name one of them, and the items for everyone, which belong
	 * in every organization's list.
	 *
	 * @param int[] $orgIds
	 * @return array<int|string, mixed>
	 */
	private static function audienceOf( array $orgIds ): array {
		$meta_query = [
			'relation' => 'OR',
			[
				'key'   => Meta::KEY_AUDIENCE_EVERYONE,
				'value' => '1',
			],
		];
		foreach ( $orgIds as $orgId ) {
			$meta_query[] = [
				'key'     => Meta::KEY_ORG_IDS,
				'value'   => sprintf( ':%d;', (int) $orgId ), // matches serialized integer in meta
				'compare' => 'LIKE',
			];
		}
		return $meta_query;
	}

	/**
	 * Content for someone with no organization: the items for everyone and
	 * the ones that name them. (forOrgs() has nothing to ask about, so their
	 * dashboard once listed nothing.)
	 *
	 * @param array<string, mixed> $args
	 * @return WP_Post[]
	 */
	public function forStandalone( int $userId, array $args = [] ): array {
		if ( $userId <= 0 ) {
			return [];
		}
		$query = new WP_Query(
			array_merge(
				[
					'post_type'      => PostType::SLUG,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'date',
					'order'          => 'DESC',
					'no_found_rows'  => true,
					'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery -- the audience lives in post meta by design.
						'relation' => 'OR',
						[
							'key'   => Meta::KEY_AUDIENCE_EVERYONE,
							'value' => '1',
						],
						[
							'key'     => Meta::KEY_STANDALONE_MEMBER_IDS,
							'value'   => sprintf( ':%d;', $userId ), // matches serialized integer in meta
							'compare' => 'LIKE',
						],
					],
				],
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn ( $p ) => $p instanceof WP_Post ) );
	}

	/**
	 * @param array<int, \WP_Post> $posts
	 * @return array<int, array{id: int, title: string, summary: string, date: string, click: string, visibility: string, author: int}>
	 */
	public function summarize( array $posts ): array {
		$out = [];
		foreach ( $posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$out[ $post->ID ] = [
				'id'         => $post->ID,
				'title'      => get_the_title( $post ),
				'summary'    => (string) ( get_post_meta( $post->ID, Meta::KEY_SUMMARY, true ) ?: wp_strip_all_tags( $post->post_excerpt ) ),
				'date'       => get_post_time( 'c', true, $post ),
				'click'      => (string) ( get_post_meta( $post->ID, Meta::KEY_CLICK_BEHAVIOR, true ) ?: Meta::CLICK_FILE ),
				'visibility' => (string) ( get_post_meta( $post->ID, Meta::KEY_VISIBILITY, true ) ?: Meta::VISIBILITY_PUBLISHED ),
				'author'     => (int) $post->post_author,
			];
		}
		return $out;
	}
}
