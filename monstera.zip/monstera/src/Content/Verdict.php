<?php
declare(strict_types=1);

namespace Monstera\Content;

/**
 * Structured verdict from Visibility::evaluate().
 *
 * `allowed` is the practical answer. `rules` is the audit trail used by
 * the "Why can't my member see this?" wizard. `softBlocked` means the
 * member sees the item with a blurred/contact-us overlay (suspended org).
 */
final class Verdict {

	/**
	 * @param array<string, RuleResult> $rules
	 */
	public function __construct(
		public readonly bool $allowed,
		public readonly bool $softBlocked,
		public readonly array $rules
	) {}

	/**
	 * @param array<string, RuleResult> $rules
	 */
	public static function fromRules( array $rules ): self {
		$hardFail = false;
		$softFail = false;
		foreach ( $rules as $rule ) {
			if ( ! $rule->passed ) {
				if ( 'soft' === $rule->failureKind ) {
					$softFail = true;
				} else {
					$hardFail = true;
				}
			}
		}
		return new self(
			allowed: ! $hardFail,
			softBlocked: $softFail && ! $hardFail,
			rules: $rules
		);
	}

	public static function fail( string $ruleKey, string $message ): self {
		return new self( false, false, [ $ruleKey => RuleResult::fail( $message ) ] );
	}

	/**
	 * @return array<string, mixed>
	 */
	public function toArray(): array {
		return [
			'allowed'     => $this->allowed,
			'softBlocked' => $this->softBlocked,
			'rules'       => array_map( static fn ( RuleResult $r ) => $r->toArray(), $this->rules ),
		];
	}
}
