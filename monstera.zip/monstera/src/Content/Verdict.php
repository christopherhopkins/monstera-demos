<?php
declare(strict_types=1);

namespace Monstera\Content;

use Closure;

defined( 'ABSPATH' ) || exit;

/**
 * Structured verdict from Visibility::evaluate().
 *
 * `allowed` is the practical answer. `rules` is the audit trail used by
 * the "Why can't my member see this?" wizard. `softBlocked` means the
 * member sees the item with a blurred/contact-us overlay (suspended org).
 * `organizations()` is every organization the member belongs to as the
 * engine saw it (whether the audience holds it, its status and whether its
 * membership has ended), so the wizard can show which ones rules 2 and 6
 * were judged over now that a person may belong to several. The engine
 * hands over what builds the list and the verdict builds it on the first
 * read: only the wizard and the content page's paused note ask, while a
 * can-see check runs for every candidate of an audience and would read
 * each organization's title to throw it away.
 * `endedBlocked` means the item is still the member's but its file waits
 * on a renewal: an organization that grants it has ended its membership
 * and no other that grants it is live. The item stays allowed so the guard
 * can answer its page with "Membership ended" instead of "not shared".
 */
final class Verdict {

	/**
	 * @param array<string, RuleResult> $rules
	 * @param list<array{id: int, name: string, in_audience: bool, status: string, ended: bool}>|Closure(): list<array{id: int, name: string, in_audience: bool, status: string, ended: bool}> $organizations The list, or what builds it when it is first asked for.
	 */
	public function __construct(
		public readonly bool $allowed,
		public readonly bool $softBlocked,
		public readonly array $rules,
		private array|Closure $organizations = [],
		public readonly bool $endedBlocked = false
	) {}

	/**
	 * @param array<string, RuleResult> $rules
	 * @param list<array{id: int, name: string, in_audience: bool, status: string, ended: bool}>|Closure(): list<array{id: int, name: string, in_audience: bool, status: string, ended: bool}> $organizations The list, or what builds it when it is first asked for.
	 * @param bool $endedBlocked Whether an ended membership holds the download back; a hard fail overrides it, as it does a soft one.
	 */
	public static function fromRules( array $rules, array|Closure $organizations = [], bool $endedBlocked = false ): self {
		$hardFail = false;
		$softFail = false;
		foreach ( $rules as $rule ) {
			if ( ! $rule->passed ) {
				if ( 'soft' === $rule->failureKind ) {
					$softFail = true;
				} else {
					$hardFail = true;
				}
			}
		}
		return new self(
			allowed: ! $hardFail,
			softBlocked: $softFail && ! $hardFail,
			rules: $rules,
			organizations: $organizations,
			endedBlocked: $endedBlocked && ! $hardFail
		);
	}

	public static function fail( string $ruleKey, string $message ): self {
		return new self( false, false, [ $ruleKey => RuleResult::fail( $message ) ] );
	}

	/**
	 * The organizations the engine considered, built on the first read and
	 * kept, so every reader of one verdict gets the same list.
	 *
	 * @return list<array{id: int, name: string, in_audience: bool, status: string, ended: bool}>
	 */
	public function organizations(): array {
		if ( $this->organizations instanceof Closure ) {
			$this->organizations = ( $this->organizations )();
		}
		return $this->organizations;
	}

	/**
	 * @return array<string, mixed>
	 */
	public function toArray(): array {
		return [
			'allowed'       => $this->allowed,
			'softBlocked'   => $this->softBlocked,
			'endedBlocked'  => $this->endedBlocked,
			'rules'         => array_map( static fn ( RuleResult $r ) => $r->toArray(), $this->rules ),
			'organizations' => $this->organizations(),
		];
	}
}
