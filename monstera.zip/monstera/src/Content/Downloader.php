<?php
/**
 * Secure file streaming handler.
 *
 * Validates the session, re-runs the visibility check (defense in depth),
 * confirms the nonce, logs to activity, then streams the file with
 * Cache-Control: no-store and a content-disposition header.
 */

declare(strict_types=1);

namespace Monstera\Content;

use Monstera\Core\Capabilities;
use Monstera\Core\Hooks;
use Monstera\Core\Routing;
use Monstera\Members\UserMeta;
use Monstera\Organizations\Meta as OrgMeta;
use Monstera\Projects\IntakeFiles;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Reporting\ActivityLog;
use WP_User;

final class Downloader {

	public function __construct(
		private SecureFiles $files,
		private Visibility $visibility
	) {}

	public static function signedUrl( int $fileId, int $userId ): string {
		$nonce = self::createNonce( $fileId, $userId );
		return Routing::url(
			Routing::ROUTE_DOWNLOAD,
			[
				'id'    => $fileId,
				'nonce' => $nonce,
			]
		);
	}

	public function handle(): void {
		$fileId = (int) get_query_var( Routing::PARAM_ID );
		$nonce  = (string) get_query_var( 'monstera_nonce' );

		if ( ! is_user_logged_in() ) {
			$this->deny( 401, __( 'You must sign in to download this file.', 'monstera' ) );
		}

		$user = wp_get_current_user();

		if ( ! $this->verifyNonce( $nonce, $fileId, $user->ID ) ) {
			$this->deny( 403, __( 'This download link has expired. Go back to the page and try again.', 'monstera' ) );
		}

		$row = $this->files->findById( $fileId );
		if ( ! $row ) {
			$this->deny( 404, __( 'File not found.', 'monstera' ) );
		}

		$refusal = $this->refusal( $user, $row );
		if ( $refusal ) {
			$this->deny( ...$refusal );
		}

		$path = $this->files->absolutePath( $row );
		if ( ! is_file( $path ) || ! is_readable( $path ) ) {
			$this->deny( 410, __( 'The stored file is no longer available.', 'monstera' ) );
		}

		$this->logDownload( $user, $row );

		$this->stream( $path, (string) $row['original_name'], (string) $row['mime_type'], (int) $row['filesize'] );
	}

	/**
	 * Why a person may not have a stored file, as [status, message], or null.
	 * A content item's file follows the capability and the visibility engine
	 * (a suspended organization pauses it). An intake file belongs to its
	 * project's team and to admins; a team member whose organization is
	 * suspended is paused too, an admin never is.
	 *
	 * @param array<string, mixed> $row A registry row.
	 * @return array{0: int, 1: string}|null
	 */
	public function refusal( WP_User $user, array $row ): ?array {
		$denied = [ 403, __( 'You don\'t have permission to download this file.', 'monstera' ) ];

		$contentId = (int) $row['content_id'];
		if ( $contentId > 0 ) {
			// Only people granted download_content (or admins) pull files at
			// all, whatever the item's own rules say.
			if ( ! user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) && ! user_can( $user, Capabilities::CAP_DOWNLOAD_CONTENT ) ) {
				return [ 403, __( 'You don\'t have permission to download files.', 'monstera' ) ];
			}
			return $this->visibility->userCanDownload( $user, $contentId ) ? null : $denied;
		}

		$projectId = (int) ( $row['project_id'] ?? 0 );
		if ( $projectId <= 0 ) {
			return [ 404, __( 'File not found.', 'monstera' ) ];
		}
		return match ( self::intakeAccess( $user, $projectId ) ) {
			self::ACCESS_YES    => null,
			self::ACCESS_PAUSED => [ 403, __( 'Downloads are paused while your organization is suspended.', 'monstera' ) ],
			default             => $denied,
		};
	}

	public const ACCESS_YES    = 'yes';
	public const ACCESS_PAUSED = 'paused';
	public const ACCESS_NO     = 'no';

	/**
	 * Whether a person may download a project's intake files: an admin
	 * always; a team member while their organization is active, paused while
	 * it is suspended; anyone else never. The portal draws its links and its
	 * "Download paused" from the same answer.
	 */
	public static function intakeAccess( WP_User $user, int $projectId ): string {
		if ( user_can( $user, Capabilities::CAP_MANAGE_MONSTERA ) ) {
			return self::ACCESS_YES;
		}
		if ( ! in_array( (int) $user->ID, ( new ProjectRepository() )->memberIds( $projectId ), true ) ) {
			return self::ACCESS_NO;
		}
		$orgId  = UserMeta::associatedOrg( (int) $user->ID );
		$status = $orgId > 0 ? (string) ( get_post_meta( $orgId, OrgMeta::KEY_STATUS, true ) ?: OrgMeta::STATUS_ACTIVE ) : OrgMeta::STATUS_ACTIVE;
		return match ( $status ) {
			OrgMeta::STATUS_ACTIVE    => self::ACCESS_YES,
			OrgMeta::STATUS_SUSPENDED => self::ACCESS_PAUSED,
			default                   => self::ACCESS_NO,
		};
	}

	/**
	 * The one activity row for a served file: against its content item, or
	 * against the project whose intake it answers.
	 *
	 * @param array<string, mixed> $row A registry row.
	 */
	public function logDownload( WP_User $user, array $row ): void {
		$contentId = (int) $row['content_id'];
		if ( $contentId > 0 ) {
			ActivityLog::recordDownload( $contentId, (int) $user->ID, (int) $row['id'] );
			return;
		}
		$projectId = (int) $row['project_id'];
		ActivityLog::record(
			'intake_file_downloaded',
			'project',
			$projectId,
			[ 'user_id' => (int) $user->ID ] + IntakeFiles::activityContext(
				$projectId,
				[
					'id'   => (int) $row['id'],
					'name' => (string) $row['original_name'],
				],
				(string) $row['field_key']
			)
		);
	}

	private function stream( string $path, string $filename, string $mime, int $size ): void {
		nocache_headers();
		header( 'Cache-Control: no-store, no-cache, must-revalidate, private' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		header( 'Content-Type: ' . ( $mime ?: 'application/octet-stream' ) );
		header( 'Content-Length: ' . ( $size ?: filesize( $path ) ) );
		header( 'Content-Disposition: attachment; filename="' . rawurlencode( $filename ?: basename( $path ) ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex, nofollow' );

		while ( ob_get_level() ) {
			ob_end_clean();
		}
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile, WordPressVIPMinimum.Functions.RestrictedFunctions -- streams a secure file kept outside the Media Library by design (signed URL, no-store).
		exit;
	}

	private function deny( int $status, string $message ): never {
		status_header( $status );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo esc_html( $message );
		exit;
	}

	private static function lifetime(): int {
		$default = 300; // 5 minutes per spec.
		return (int) apply_filters( Hooks::FILTER_DOWNLOAD_LIFETIME, $default );
	}

	/**
	 * A token the download route's pattern accepts: the expiry in hex, then
	 * 32 hex characters of signature. (The two were once joined by a colon,
	 * which the route never matched, so no signed link reached handle().)
	 */
	public static function createNonce( int $fileId, int $userId ): string {
		$expires = time() + self::lifetime();
		return dechex( $expires ) . self::signature( $fileId, $userId, $expires );
	}

	public function verifyNonce( string $nonce, int $fileId, int $userId ): bool {
		if ( ! preg_match( '/^([a-f0-9]{1,16})([a-f0-9]{32})$/', $nonce, $m ) ) {
			return false;
		}
		$expires = (int) hexdec( $m[1] );
		if ( $expires < time() ) {
			return false;
		}
		return hash_equals( self::signature( $fileId, $userId, $expires ), $m[2] );
	}

	private static function signature( int $fileId, int $userId, int $expires ): string {
		return substr( hash_hmac( 'sha256', $fileId . '|' . $userId . '|' . $expires, wp_salt( 'nonce' ) ), 0, 32 );
	}
}
