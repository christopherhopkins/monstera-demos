<?php
/**
 * Shared member provisioning.
 *
 * Creating a portal member is needed from more than one place — the admin
 * Members REST controller and the org-admin self-service invite endpoint. Both
 * want the same behaviour: a unique email, a random password (the member never
 * sees it; the welcome email carries a one-time set-password link), and the
 * standard WordPress user_register hook firing so MembersModule can dispatch
 * monstera/member_created. This keeps that logic in one place.
 */

declare(strict_types=1);

namespace Monstera\Members;

use Monstera\Core\Capabilities;
use Monstera\Notifications\Dispatcher;
use Monstera\Notifications\TemplateEngine;
use Monstera\Reporting\ActivityLog;
use WP_Error;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Provisioning {

	/**
	 * Create a portal member. The role is taken as-is (callers are responsible
	 * for clamping it to an allowed set); the password is random.
	 *
	 * The organization, when there is one, is stored with the account
	 * (meta_input), so it is in place when user_register sends the welcome:
	 * the email can name it and its activity row is filed under it.
	 *
	 * @param array{email?:string, first_name?:string, last_name?:string, username?:string, role?:string, org_id?:int} $data
	 * @return WP_User|WP_Error The new user, or a WP_Error with an HTTP status.
	 */
	public static function createMember( array $data ): WP_User|WP_Error {
		$email = sanitize_email( (string) ( $data['email'] ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return new WP_Error( 'monstera_invalid_email', __( 'A valid email is required.', 'monstera' ), [ 'status' => 422 ] );
		}
		if ( email_exists( $email ) ) {
			return new WP_Error( 'monstera_email_taken', __( 'A user with that email already exists.', 'monstera' ), [ 'status' => 409 ] );
		}

		$id = wp_insert_user(
			[
				'user_login' => sanitize_user( (string) ( $data['username'] ?? $email ), true ),
				'user_email' => $email,
				'user_pass'  => wp_generate_password( 20, true, true ),
				'first_name' => sanitize_text_field( (string) ( $data['first_name'] ?? '' ) ),
				'last_name'  => sanitize_text_field( (string) ( $data['last_name'] ?? '' ) ),
				'role'       => (string) ( $data['role'] ?? Capabilities::ROLE_MEMBER ),
				'meta_input' => (int) ( $data['org_id'] ?? 0 ) > 0
					? [ \Monstera\Members\UserMeta::KEY_ASSOCIATED_ORG => (int) $data['org_id'] ]
					: [],
			]
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$user = get_user_by( 'id', (int) $id );
		return $user instanceof WP_User
			? $user
			: new WP_Error( 'monstera_create_failed', __( 'User created but could not be loaded.', 'monstera' ), [ 'status' => 500 ] );
	}

	/**
	 * Send the welcome email again and note who asked for it, for the admin's
	 * bulk action and the portal roster alike. False means the member has no
	 * email address to send to; each caller words that refusal for its screen.
	 *
	 * @param array<string, mixed> $context Extra facts for the activity row, such as the org it was sent from.
	 */
	public static function resendWelcome( int $userId, array $context = [] ): bool {
		if ( ! ( new Dispatcher( new TemplateEngine() ) )->sendWelcome( $userId ) ) {
			return false;
		}
		ActivityLog::record( 'welcome_resent', 'user', $userId, $context );
		return true;
	}
}
