<?php
/**
 * Shared member provisioning.
 *
 * Creating a portal member is needed from more than one place — the admin
 * Members REST controller and the org-admin self-service invite endpoint. Both
 * want the same behaviour: a unique email, a random password (the member never
 * sees it; the welcome email carries a one-time set-password link), and the
 * standard WordPress user_register hook firing so MembersModule can dispatch
 * monstera/member_created. This keeps that logic in one place.
 */

declare(strict_types=1);

namespace Monstera\Members;

use Monstera\Core\Capabilities;
use Monstera\Core\Database\Schema;
use Monstera\Notifications\Dispatcher;
use Monstera\Notifications\TemplateEngine;
use Monstera\Organizations\Roster;
use Monstera\Portal\Audience;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Reporting\ActivityLog;
use WP_Error;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Provisioning {

	// What attachRefusal() answers: the account is the team's, or the person
	// already belongs to the organization.
	public const REFUSED_TEAM    = 'team';
	public const REFUSED_ALREADY = 'already';

	// What usedBeyondInvitation() answers: the first sign it found that an
	// account an invitation made is somebody's by now.
	public const USED_ROLE      = 'role';
	public const USED_SIGNED_IN = 'signed_in';
	public const USED_POSTS     = 'posts';
	public const USED_SUPPORT   = 'support';
	public const USED_RESPONSES = 'responses';
	public const USED_PROJECTS  = 'projects';

	/**
	 * What an account can do in WordPress that is worth more to whoever
	 * holds its sign-in than manage_monstera, asked of it with its Monstera
	 * roles set aside (worksInAdminBesideMonstera()). edit_posts is where
	 * WordPress lets an account into wp-admin's own screens. The rest need
	 * no edit_posts beside them and reach further than an editor does: the
	 * Users screen's capabilities, by which one account reads, changes,
	 * makes or deletes another, so that holding one such account is the way
	 * into every account on the site, and the site's settings. A role built
	 * in a role editor to manage users holds those and nothing over content.
	 * A role that carries only a plugin's own capabilities is not known
	 * here by name and is not caught.
	 *
	 * @var list<string>
	 */
	private const BEYOND_MONSTERA = [ 'edit_posts', 'list_users', 'edit_users', 'promote_users', 'create_users', 'delete_users', 'manage_options' ];

	/**
	 * Create a portal member. The role is taken as-is (callers are responsible
	 * for clamping it to an allowed set); the password is random.
	 *
	 * The organization, when there is one, becomes a membership through the
	 * Roster at the given tier (the one the role implies when none is given,
	 * see tierImpliedBy()), written the moment WordPress registers the
	 * account (see insertUser()), so the welcome email can name it and its
	 * activity row is filed under it.
	 *
	 * Someone joining the team is created here too, with a staff role and no
	 * organization (the Team routes): the account is made the same way, and
	 * the dispatcher sends a staff account the team's welcome in place of
	 * the member's, with the same one-time link.
	 *
	 * @param array{email?:string, first_name?:string, last_name?:string, username?:string, role?:string, org_id?:int, tier?:string} $data
	 * @return WP_User|WP_Error The new user, or a WP_Error with an HTTP status.
	 */
	public static function createMember( array $data ): WP_User|WP_Error {
		$email = sanitize_email( (string) ( $data['email'] ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return new WP_Error( 'monstera_invalid_email', __( 'A valid email is required.', 'monstera' ), [ 'status' => 422 ] );
		}
		if ( email_exists( $email ) ) {
			return new WP_Error( 'monstera_email_taken', __( 'A user with that email already exists.', 'monstera' ), [ 'status' => 409 ] );
		}

		$id = self::insertUser(
			[
				'user_login' => sanitize_user( (string) ( $data['username'] ?? $email ), true ),
				'user_email' => $email,
				'user_pass'  => wp_generate_password( 20, true, true ),
				'first_name' => sanitize_text_field( (string) ( $data['first_name'] ?? '' ) ),
				'last_name'  => sanitize_text_field( (string) ( $data['last_name'] ?? '' ) ),
				'role'       => (string) ( $data['role'] ?? Capabilities::ROLE_MEMBER ),
			],
			(int) ( $data['org_id'] ?? 0 ),
			isset( $data['tier'] ) ? (string) $data['tier'] : null
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$user = get_user_by( 'id', (int) $id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'monstera_create_failed', __( 'User created but could not be loaded.', 'monstera' ), [ 'status' => 500 ] );
		}
		return $user;
	}

	/**
	 * Join an account that already exists to an organization, when an
	 * invitation by email reaches an address Monstera knows (People-model
	 * track, FR7). The person keeps their account, their name and every
	 * other membership, joins this organization at the tier asked, and is
	 * told so by an email that names this organization alone.
	 *
	 * Some addresses are turned away (attachRefusal() says which, and why).
	 * One the team's rule refuses is refused on the email field; someone
	 * already in this organization is refused as an address in use always
	 * was. No refusal tells the caller anything they could not already see,
	 * the team and their own roster; that the address belongs to another
	 * organization is never a reason to refuse, so it is never said.
	 *
	 * An account that holds none of Monstera's client roles and can only
	 * read (a subscriber, a shop's customer) is given the member role first.
	 * The Roster derives a client role from the tiers and leaves an account
	 * with none alone, so without it the membership would hold a seat and
	 * open no portal; and such an account has nothing in wp-admin for the
	 * role to take.
	 *
	 * Which email they get depends on whether they can sign in. Someone who
	 * has is told they were added, with no link, the account and its
	 * password being theirs already. Someone who never has (an address
	 * invited before that has not followed its link, or one whose
	 * invitation was ended by a removal, Roster::remove()) has no password
	 * to sign in with, so they get the welcome with a new set-password link,
	 * speaking for this organization: the link in any earlier welcome is
	 * replaced by it, as a Resend replaces it. The roster lists them as
	 * invited either way, and its Resend sends the same welcome. Neither
	 * asks who is sending (BaseController::signInRefusal() says why not).
	 *
	 * An account that is somebody's already and has not signed in, a
	 * standalone member the team made, is noted as such before it joins
	 * (Roster::keepStanding()): a removal then ends this invitation and
	 * leaves the person what they were.
	 *
	 * The email goes, and the person is answered as attached, only when the
	 * Roster says it wrote the membership. When it did not, nobody is told
	 * they were added: a row that another invitation, or an assignment,
	 * wrote between the check above and the write is answered as it would
	 * have been a moment later, and a write the database refused is an
	 * error. The member role given for a membership that then was not
	 * written is taken back (settleRole()).
	 *
	 * The caller checks the seat limit, as for createMember().
	 *
	 * @return WP_User|WP_Error The person attached, or a WP_Error with an HTTP status.
	 */
	public static function attachMember( int $orgId, WP_User $user, string $tier = Roster::TIER_MEMBER ): WP_User|WP_Error {
		$userId  = (int) $user->ID;
		$refused = self::attachRefused( self::attachRefusal( $orgId, $user ) );
		if ( $refused ) {
			return $refused;
		}
		// Before the role below is given: what the account holds now is its
		// own, and the Roster keeps note of it for the day the invitation ends.
		Roster::keepStanding( $userId );
		$outsider = ! self::holdsClientRole( $user );
		if ( $outsider ) {
			$user->add_role( Capabilities::ROLE_MEMBER );
		}
		if ( ! Roster::add( $orgId, $userId, $tier ) ) {
			if ( $outsider ) {
				self::settleRole( $userId );
			}
			return self::attachRefused( self::attachRefusal( $orgId, $user ) ) ?? self::notWritten();
		}
		$dispatcher = new Dispatcher( new TemplateEngine() );
		if ( UserMeta::hasSignedIn( $userId ) ) {
			$dispatcher->sendAddedToOrganization( $userId, $orgId );
		} else {
			$dispatcher->sendWelcome( $userId, $orgId );
		}
		return $user;
	}

	/**
	 * attachRefusal()'s answer as an invitation words it, about the address
	 * that was typed, or null when there is none.
	 *
	 * @param self::REFUSED_*|null $refusal
	 */
	private static function attachRefused( ?string $refusal ): ?WP_Error {
		if ( self::REFUSED_TEAM === $refusal ) {
			return new WP_Error(
				'monstera_invalid_field',
				/* translators: %s: the site's name */
				sprintf( __( 'That address belongs to the %s team.', 'monstera' ), Audience::siteName() ),
				[
					'status' => 422,
					'field'  => 'email',
				]
			);
		}
		if ( self::REFUSED_ALREADY === $refusal ) {
			return new WP_Error( 'monstera_email_taken', __( 'That address already belongs to a member of this organization.', 'monstera' ), [ 'status' => 409 ] );
		}
		return null;
	}

	/**
	 * The answer to a caller whose membership the database did not write:
	 * the person has not joined, and the request can be made again. One
	 * sentence for every route that adds someone who has an account (an
	 * invitation that attaches, the memberships route, the bulk action).
	 */
	public static function notWritten(): WP_Error {
		return new WP_Error( 'monstera_not_added', __( 'The membership could not be saved. Try again.', 'monstera' ), [ 'status' => 500 ] );
	}

	/**
	 * Put right the role of an account from outside Monstera that was given
	 * the member role for a membership this request then did not write.
	 * With no membership at all the role says something untrue, and the
	 * account would meet the portal's no-organization page, so every client
	 * role goes and the account is as it came. With one, written by the
	 * request that got there first, the role is that membership's and the
	 * Roster derives it. The account is read again for it: that request may
	 * have changed its roles since this one read them.
	 */
	private static function settleRole( int $userId ): void {
		if ( Roster::orgIdsOf( $userId ) ) {
			Roster::syncRole( $userId );
			return;
		}
		$fresh = get_user_by( 'id', $userId );
		if ( ! $fresh instanceof WP_User ) {
			return;
		}
		foreach ( (array) $fresh->roles as $role ) {
			if ( Capabilities::isPortalRole( (string) $role ) ) {
				$fresh->remove_role( (string) $role );
			}
		}
	}

	/**
	 * Why an account that exists may not be added to an organization, or
	 * null when it may. This is the rule apart from its words: an invitation
	 * (attachMember()) answers about the address that was typed, and the
	 * team's memberships routes, which name the person, word it their own
	 * way. Both ask here, so who may be added is decided once.
	 *
	 * One of the team's accounts is turned away: staff work in every
	 * organization and are assigned to one, never added to it. An account
	 * still assigned to this organization is turned away the same way,
	 * whatever role it holds now: the Roster leaves a row that exists alone,
	 * so nothing would be written and whatever said they had joined would
	 * lie. So is an account that works in wp-admin and is not one of
	 * Monstera's (see worksInAdminOnly()), which joining must not change.
	 * Someone already in this organization keeps the tier they hold: adding
	 * them again is not the way to change it.
	 *
	 * @return self::REFUSED_*|null
	 */
	public static function attachRefusal( int $orgId, WP_User $user ): ?string {
		$userId = (int) $user->ID;
		if ( Capabilities::isStaff( $user ) || Roster::isAssignedTo( $userId, $orgId ) || self::worksInAdminOnly( $user ) ) {
			return self::REFUSED_TEAM;
		}
		return Roster::isMemberOf( $userId, $orgId ) ? self::REFUSED_ALREADY : null;
	}

	/**
	 * Whether the account works in wp-admin and is not one of Monstera's:
	 * the site's editor, an author, a shop's manager, a course's instructor.
	 * An invitation is an organization manager's word, and a client role is
	 * not theirs to give such an account: holding one turns a person away
	 * from every wp-admin screen but their profile (AdminBarGuard) and sends
	 * their sign-in to the portal (LoginRedirect), and leaving the roster
	 * would not give that back, because the Roster swaps one client role for
	 * another and never takes the last. The team cannot enrol such an
	 * account by name either (Roster::refusal()).
	 *
	 * What the account can do is asked as worksInAdminBesideMonstera() asks
	 * it (BEYOND_MONSTERA): edit_posts, where WordPress itself lets an
	 * account into its own screens, and the Users screen's capabilities,
	 * which a role built in a role editor to manage users holds without
	 * edit_posts. Such an account would be locked out of wp-admin by a
	 * client role as surely as an editor would. The capability is asked,
	 * never a role's name, so a role another plugin added is judged by what
	 * it can do. An account that already holds a client role is passed over:
	 * the portal is where it lands already, and one more organization takes
	 * nothing from it.
	 *
	 * The Roster asks here too, of someone who has left the team, by any
	 * door, and holds a membership (Roster::onRoleRemoved()): a client role
	 * is theirs to be given only when this says it would take nothing from
	 * them.
	 */
	public static function worksInAdminOnly( WP_User $user ): bool {
		return ! self::holdsClientRole( $user ) && self::worksInAdminBesideMonstera( $user );
	}

	/**
	 * Whether the account can work in wp-admin by something that is not
	 * Monstera's: a role of the site's or of another plugin (an editor, an
	 * author, a shop's manager) or a capability given to it directly,
	 * whatever Monstera role it holds beside that. worksInAdminOnly() cannot
	 * answer this: it passes over an account that holds a client role,
	 * rightly for its own question, and the site's editor who is also a
	 * member is exactly who is asked about here. Nor can edit_posts alone:
	 * both team roles carry it.
	 *
	 * So the account is asked what it could do with its Monstera roles set
	 * aside, on a copy that is never saved. The capability is asked, not a
	 * role's name, as worksInAdminOnly() asks it and for the same reason.
	 *
	 * The routes that change an account's address or send it a set-password
	 * link ask here (BaseController::signInRefusal()): whoever holds the
	 * address of such an account holds what it can do in WordPress, which is
	 * more than manage_monstera gives. That question is wider than
	 * worksInAdminOnly()'s, so it asks about more than edit_posts
	 * (BEYOND_MONSTERA says what, and why).
	 */
	public static function worksInAdminBesideMonstera( WP_User $user ): bool {
		$beside = clone $user;
		foreach ( array_keys( $beside->caps ) as $held ) {
			if ( Capabilities::isStaffRole( (string) $held ) || Capabilities::isPortalRole( (string) $held ) ) {
				unset( $beside->caps[ $held ] );
			}
		}
		// Reads the roles and capabilities again from what is left; writes nothing.
		$beside->get_role_caps();
		foreach ( self::BEYOND_MONSTERA as $capability ) {
			if ( $beside->has_cap( $capability ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether the account is a client's: it holds one of Monstera's client
	 * roles, or it belongs to an organization whatever role it holds. Such
	 * an account is never given a team role by its address (the Team routes
	 * ask here): the staff role wins over every tier, so the person would
	 * stop being a client the moment someone typed their email.
	 */
	public static function isClientMember( WP_User $user ): bool {
		return self::holdsClientRole( $user ) || [] !== Roster::orgIdsOf( (int) $user->ID );
	}

	/** Whether the account holds one of Monstera's client roles, whatever else it holds. */
	private static function holdsClientRole( WP_User $user ): bool {
		foreach ( (array) $user->roles as $role ) {
			if ( Capabilities::isPortalRole( (string) $role ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * wp_insert_user() with the organization joined as the account is
	 * registered. user_register fires inside the insert and MembersModule
	 * dispatches the welcome email from it at priority 10, so the membership
	 * is written at priority 5, ahead of it: the email's {user_company} then
	 * names the organization and the "welcome sent" activity row files under
	 * it, as the organization's recent activity expects. The listener is for
	 * this one account and comes down again whether or not the insert went
	 * through, so a failed insert cannot hand the organization to the next
	 * account created in the request.
	 *
	 * Nor can a registration inside this one. Another plugin may make an
	 * account of its own on hearing of a new one, ahead of this listener,
	 * and that account is registered while the listener is up. WordPress
	 * hands every listener the data the insert was given, so the listener
	 * joins and marks only the registration that carries this insert's
	 * address. The address is compared as it was passed, never as WordPress
	 * stored it: a site may filter an address on its way in, and a
	 * comparison that failed for that would leave the new account in no
	 * organization. What the mark allows is an account's removal, so it is
	 * never written on a guess.
	 *
	 * An account made here for an organization is one the invitation made,
	 * and is marked so as its membership is written
	 * (UserMeta::KEY_INVITED_ACCOUNT): by an address typed into a roster,
	 * the portal's or the admin's, and by Members > Add member with a first
	 * organization, which sends the same welcome and reads "Invited" in the
	 * same lists. Nothing else writes the mark. Ending the invitation of
	 * someone who never signed in removes an account that carries it and no
	 * other (Roster::remove()), so an account that was on the site before
	 * anyone invited it is never one of those: it is attached
	 * (attachMember()), never made here.
	 *
	 * @param array<string, mixed> $userdata As wp_insert_user() takes it.
	 * @param int                  $orgId    The organization to join; none when 0.
	 * @param string|null          $tier     The membership's tier there; the one the role implies when null.
	 */
	public static function insertUser( array $userdata, int $orgId, ?string $tier = null ): int|WP_Error {
		$tier ??= self::tierImpliedBy( (string) ( $userdata['role'] ?? '' ) );
		$email = $userdata['user_email'] ?? null;
		$join  = static function ( int $userId, mixed $registered = null ) use ( $orgId, $tier, $email ): void {
			if ( ! is_array( $registered ) || ( $registered['user_email'] ?? null ) !== $email ) {
				return;
			}
			if ( Roster::add( $orgId, $userId, $tier ) ) {
				update_user_meta(
					$userId,
					UserMeta::KEY_INVITED_ACCOUNT,
					[
						'org_id' => $orgId,
						'at'     => gmdate( 'c' ),
					]
				);
			}
		};
		if ( $orgId > 0 ) {
			add_action( 'user_register', $join, 5, 2 );
		}
		$id = wp_insert_user( $userdata );
		if ( $orgId > 0 ) {
			remove_action( 'user_register', $join, 5 );
		}
		return $id;
	}

	/**
	 * The tier a WordPress role implies for an account's first organization,
	 * when a caller gives a role but no tier: a manager by role joins as a
	 * manager of it, anyone else as a member. The role is a ceiling the
	 * Roster derives from the tiers (Roster::syncRole()), so without this a
	 * manager made by role would be demoted the moment they joined. It says
	 * nothing about a second organization: see tierImpliedByUser().
	 */
	public static function tierImpliedBy( string $role ): string {
		return Capabilities::ROLE_ORG_MANAGER === $role ? Roster::TIER_MANAGER : Roster::TIER_MEMBER;
	}

	/**
	 * The tier an account that exists joins an organization at when the
	 * caller names none: manager only for a manager by role who belongs
	 * nowhere yet (their first organization, the case tierImpliedBy() is
	 * for), member for everyone else. Someone who already has a membership
	 * holds the manager role because of a tier in an organization they
	 * belong to, which is no word on the next one: managing one organization
	 * never makes a person a manager of another. Every writer that joins
	 * someone without a tier (the member detail's and the bulk action's
	 * memberships routes when a request names none, the organization
	 * detail's roster) reads it here, so they cannot disagree.
	 */
	public static function tierImpliedByUser( int $userId ): string {
		$user          = get_user_by( 'id', $userId );
		$managerByRole = $user instanceof WP_User && in_array( Capabilities::ROLE_ORG_MANAGER, (array) $user->roles, true );
		return $managerByRole && ! Roster::orgIdsOf( $userId ) ? Roster::TIER_MANAGER : Roster::TIER_MEMBER;
	}

	/**
	 * Whether the invitation is what made the account: it carries the mark
	 * insertUser() writes as an account is registered with its first
	 * organization, and nothing else writes. Anything but the mark as it is
	 * written answers no, an account from before the mark was kept among
	 * them: the Roster removes an account only on a yes, so every doubt
	 * leaves the account where it is.
	 */
	public static function madeByInvitation( int $userId ): bool {
		$mark = get_user_meta( $userId, UserMeta::KEY_INVITED_ACCOUNT, true );
		return is_array( $mark ) && (int) ( $mark['org_id'] ?? 0 ) > 0;
	}

	/**
	 * Which of these accounts show a use beyond the invitation that made
	 * them, each with the first sign of it found. The Roster asks before it
	 * removes the account of an invitation that has ended
	 * (Roster::remove()): an account nobody signed in to holds nothing but
	 * what its invitation gave it, and one that holds anything else is
	 * somebody's by now, whatever the sign-in stamp says, so it stays. The
	 * signs, in the order they are looked for:
	 *
	 * - a role or a capability that is not one of Monstera's client roles: a
	 *   subscriber's, an editor's, a team role, one given to the account
	 *   itself (USED_ROLE);
	 * - a sign-in: the stamp Monstera keeps, or a session WordPress holds
	 *   for the account, which a sign-in made while the plugin was off
	 *   leaves without the stamp (USED_SIGNED_IN);
	 * - a post of any type or status that names it as author, which
	 *   WordPress would delete with the account (USED_POSTS);
	 * - a support request it opened or a message it wrote on one
	 *   (USED_SUPPORT);
	 * - an answer to a project's discovery, or a file it uploaded
	 *   (USED_RESPONSES);
	 * - a place on a project of an organization the person does not belong
	 *   to, or on a project of none (USED_PROJECTS). A place on a project of
	 *   an organization of theirs came with that invitation and ends with
	 *   it; so does one on a project of the organization whose membership
	 *   has just ended, which the caller names because the row is gone by
	 *   then, and one on a project whose organization no longer exists,
	 *   which is how a deleted organization's projects read;
	 * - anything the activity log has the account doing, a sign-in the log
	 *   kept among it (USED_SIGNED_IN).
	 *
	 * Asked about everyone at once: the roles and the stamps are read from
	 * the accounts, loaded together, and each table is read once for
	 * whoever is still in question, so an organization of three hundred
	 * invited people costs the reads that one person does.
	 *
	 * @param array<int, mixed> $userIds
	 * @param int               $leavingOrgId The organization whose membership has just ended; none when 0 (no membership has ended yet, or the organization is gone).
	 * @return array<int, self::USED_*> The sign found, by user id. An account in no use, or one that no longer exists, is not among them.
	 */
	public static function usedBeyondInvitation( array $userIds, int $leavingOrgId = 0 ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $userIds ), static fn ( int $id ): bool => $id > 0 ) ) );
		if ( ! $ids ) {
			return [];
		}
		cache_users( $ids );
		$used = [];
		foreach ( $ids as $id ) {
			$user = get_user_by( 'id', $id );
			if ( ! $user instanceof WP_User ) {
				continue;
			}
			$beside = array_filter( array_keys( (array) $user->caps ), static fn ( $held ): bool => ! Capabilities::isPortalRole( (string) $held ) );
			if ( $beside ) {
				$used[ $id ] = self::USED_ROLE;
			} elseif ( UserMeta::hasSignedIn( $id ) || get_user_meta( $id, 'session_tokens', true ) ) {
				$used[ $id ] = self::USED_SIGNED_IN;
			}
		}

		global $wpdb;
		// Each of the other signs is one read: the ids it is true of, among
		// those still asked about ($asked), whose placeholders are $marks.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $marks is a list of %d built from count( $asked ); every table, key and id goes through prepare(). One read per sign, asked before an account is removed.
		$signs = [
			self::USED_POSTS     => static fn ( array $asked, string $marks ): array => (array) $wpdb->get_col(
				$wpdb->prepare( "SELECT DISTINCT post_author FROM %i WHERE post_author IN ($marks)", $wpdb->posts, ...$asked )
			),
			self::USED_SUPPORT   => static fn ( array $asked, string $marks ): array => (array) $wpdb->get_col(
				$wpdb->prepare(
					"SELECT member_id FROM %i WHERE member_id IN ($marks) UNION SELECT author_id FROM %i WHERE author_id IN ($marks)",
					...array_merge( [ Schema::tableName( Schema::TABLE_SUPPORT_REQUESTS ) ], $asked, [ Schema::tableName( Schema::TABLE_SUPPORT_MESSAGES ) ], $asked )
				)
			),
			self::USED_RESPONSES => static fn ( array $asked, string $marks ): array => (array) $wpdb->get_col(
				$wpdb->prepare(
					"SELECT submitted_by FROM %i WHERE submitted_by IN ($marks) UNION SELECT uploaded_by FROM %i WHERE uploaded_by IN ($marks)",
					...array_merge( [ Schema::tableName( Schema::TABLE_PROJECT_INTAKE ) ], $asked, [ Schema::tableName( Schema::TABLE_SECURE_FILES ) ], $asked )
				)
			),
			self::USED_PROJECTS  => static fn ( array $asked, string $marks ): array => (array) $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT pm.member_id FROM %i AS pm LEFT JOIN %i AS om ON om.post_id = pm.project_id AND om.meta_key = %s LEFT JOIN %i AS o ON o.ID = om.meta_value WHERE pm.member_id IN ($marks) AND ( om.meta_value IS NULL OR om.meta_value IN ( '', '0' ) OR ( o.ID IS NOT NULL AND o.ID <> %d AND NOT EXISTS ( SELECT 1 FROM %i AS m WHERE m.user_id = pm.member_id AND m.org_id = o.ID AND m.role <> %s ) ) )",
					...array_merge( [ Schema::tableName( Schema::TABLE_PROJECT_MEMBERS ), $wpdb->postmeta, ProjectMeta::KEY_ORG_ID, $wpdb->posts ], $asked, [ $leavingOrgId, Schema::tableName( Schema::TABLE_ORG_MEMBERS ), Roster::ROLE_STAFF ] )
				)
			),
			// Last, so a sign of its own is named before the log's row of it.
			self::USED_SIGNED_IN => static fn ( array $asked, string $marks ): array => (array) $wpdb->get_col(
				$wpdb->prepare( "SELECT DISTINCT user_id FROM %i WHERE user_id IN ($marks)", Schema::tableName( Schema::TABLE_ACTIVITY_LOG ), ...$asked )
			),
		];
		// phpcs:enable
		foreach ( $signs as $sign => $find ) {
			$asked = array_values( array_diff( $ids, array_keys( $used ) ) );
			if ( ! $asked ) {
				break;
			}
			$found = $find( $asked, implode( ',', array_fill( 0, count( $asked ), '%d' ) ) );
			foreach ( array_map( 'intval', $found ) as $id ) {
				if ( in_array( $id, $asked, true ) ) {
					$used[ $id ] = $sign;
				}
			}
		}
		return $used;
	}

	/**
	 * Remove the account of an invitation that has ended, altogether: the
	 * owner's decision for someone who never signed in ("just remove their
	 * user"). The Roster decides whose (Roster::remove(), and the same rule
	 * when an organization itself goes); this is only how. Nothing is
	 * reassigned, because an account that holds a post is never brought
	 * here (usedBeyondInvitation()).
	 *
	 * On a single site the WordPress user is deleted, and with it everything
	 * WordPress keeps on it; Core\Database\Cleanup hears the deletion and
	 * clears what Monstera holds about the person. On a network the account
	 * is the network's, and may be somebody's on another site of it: it is
	 * taken off this site and never deleted, and the note that this site's
	 * invitation made it goes, so it is not this rule's to remove again.
	 *
	 * @return bool Whether the account went; a caller that says so asks.
	 */
	public static function removeAccount( int $userId ): bool {
		if ( $userId <= 0 ) {
			return false;
		}
		if ( is_multisite() ) {
			delete_user_meta( $userId, UserMeta::KEY_INVITED_ACCOUNT );
			delete_user_meta( $userId, UserMeta::KEY_STOOD_ALONE );
			return true === remove_user_from_blog( $userId, get_current_blog_id() );
		}
		require_once ABSPATH . 'wp-admin/includes/user.php';
		return wp_delete_user( $userId );
	}

	/**
	 * Send the welcome email again and note who asked for it, for the admin's
	 * bulk action and the portal roster alike. False means the member has no
	 * email address to send to; each caller words that refusal for its screen.
	 *
	 * The organization the caller names is the one the resend is for: an
	 * organization's roster asked, and the person may belong to others. The
	 * email speaks for that organization and both rows of the record are
	 * filed under it, the email's and the resend's; with none named, they
	 * fall to the person's first, as a new account's welcome does.
	 *
	 * @param array<string, mixed> $context Extra facts for the activity row, such as the org it was sent from.
	 */
	public static function resendWelcome( int $userId, array $context = [] ): bool {
		if ( ! ( new Dispatcher( new TemplateEngine() ) )->sendWelcome( $userId, absint( $context['org_id'] ?? 0 ) ) ) {
			return false;
		}
		ActivityLog::record( 'welcome_resent', 'user', $userId, $context );
		return true;
	}
}
