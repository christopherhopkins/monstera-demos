<?php
declare(strict_types=1);

namespace Monstera\Members;

use Monstera\Core\Capabilities;
use Monstera\Organizations\Roster;
use WP_User;
use WP_User_Query;

defined( 'ABSPATH' ) || exit;

final class Repository {

	public function find( int $userId ): ?WP_User {
		$user = get_user_by( 'id', $userId );
		return $user instanceof WP_User ? $user : null;
	}

	/**
	 * The organization's members, as the Roster lists them. An empty
	 * `include` would make WP_User_Query answer with everyone, so an
	 * organization with nobody in it answers with nobody here.
	 *
	 * @param array<string, mixed> $args
	 * @return WP_User[]
	 */
	public function byOrg( int $orgId, array $args = [] ): array {
		$ids = Roster::memberIds( $orgId );
		if ( ! $ids ) {
			return [];
		}
		$query = new WP_User_Query(
			array_merge(
				[
					'include' => $ids,
					'fields'  => 'all',
					'number'  => -1,
				],
				$args
			)
		);
		return $query->get_results();
	}

	/**
	 * @param array<string, mixed> $args
	 * @return WP_User[]
	 */
	public function inDirectory( array $args = [] ): array {
		$args = array_merge(
			[
				'meta_query' => [
					'relation' => 'OR',
					[
						'key'     => UserMeta::KEY_SHOW_IN_DIRECTORY,
						'value'   => '1',
						'compare' => '=',
					],
					[
						'key'     => UserMeta::KEY_SHOW_IN_DIRECTORY,
						'compare' => 'NOT EXISTS',
					],
				],
				'role__in'   => [
					Capabilities::ROLE_MEMBER,
					Capabilities::ROLE_ORG_MANAGER,
					Capabilities::ROLE_MEMBER_STANDALONE,
				],
				'fields'     => 'all',
				'number'     => -1,
			],
			$args
		);

		$args  = apply_filters( \Monstera\Core\Hooks::FILTER_DIRECTORY_QUERY_ARGS, $args );
		$query = new WP_User_Query( $args );
		return $query->get_results();
	}

	public function hasPortalRole( int $userId ): bool {
		$user = $this->find( $userId );
		if ( ! $user ) {
			return false;
		}
		foreach ( $user->roles as $role ) {
			if ( Capabilities::isPortalRole( $role ) || Capabilities::isStaffRole( $role ) ) {
				return true;
			}
		}
		return false;
	}
}
