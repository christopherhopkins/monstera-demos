<?php
declare(strict_types=1);

namespace Monstera\Members;

use Monstera\Core\Hooks;
use Monstera\Core\Module;

defined( 'ABSPATH' ) || exit;

final class MembersModule implements Module {

	public function slug(): string {
		return 'members';
	}

	public function boot(): void {
		add_action( 'init', [ UserMeta::class, 'register' ], 5 );
		add_action( 'wp_login', [ $this, 'onLogin' ], 10, 2 );
		add_action( 'user_register', [ $this, 'onCreate' ], 10, 1 );
		add_action( 'delete_user', [ $this, 'onDelete' ], 10, 1 );
	}

	public function onLogin( string $userLogin, \WP_User $user ): void {
		update_user_meta( $user->ID, UserMeta::KEY_LAST_LOGIN, current_time( 'mysql', true ) );
		do_action( Hooks::MEMBER_LOGGED_IN, $user->ID );
	}

	public function onCreate( int $userId ): void {
		do_action( Hooks::MEMBER_CREATED, $userId );
	}

	public function onDelete( int $userId ): void {
		do_action( Hooks::MEMBER_DELETED, $userId );
	}

	public function registerPostTypes(): void {
		// Members are users, not posts — nothing to register.
	}
}
