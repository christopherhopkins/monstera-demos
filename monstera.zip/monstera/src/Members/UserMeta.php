<?php
declare(strict_types=1);

namespace Monstera\Members;

use Monstera\Core\Capabilities;
use Monstera\Organizations\Roster;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class UserMeta {

	public const KEY_POSITION           = 'monstera_position';
	public const KEY_BIO                = 'monstera_bio';
	public const KEY_PROFILE_PHOTO      = 'monstera_profile_photo';
	public const KEY_SHOW_IN_DIRECTORY  = 'monstera_show_in_directory';
	public const KEY_MEMBERSHIP_EXPIRES = 'monstera_membership_expires';
	public const KEY_LAST_LOGIN         = 'monstera_last_login';
	public const KEY_THEME              = 'monstera_theme';
	/** The columns a staff person turned off on each admin list, by list key (Admin\ColumnSets; At-a-glance track). */
	public const KEY_COLUMNS = 'monstera_columns';

	/**
	 * Register every user meta key with an explicit owner. No key is exposed
	 * through core REST (`/wp/v2/users`): nothing reads it there, the portal
	 * profile writes through `ProfileController` and the admin shell through
	 * `MembersController`, so exposure would only have handed a signed-in
	 * member a way to write their own expiry. The auth callbacks decide
	 * `edit_user_meta`: the membership keys (expiry, last login) belong to
	 * managers; the profile keys belong to the member on their own account
	 * as well. Who belongs to which organization is no key at all: it is a
	 * row of the memberships table, read and written through
	 * Organizations\Roster (People-model track, FR1).
	 */
	/** When the member was last saved from the admin and by whom: [ 'at' => ISO 8601, 'by' => user id ]. */
	public const KEY_SAVED = 'monstera_saved';

	/**
	 * Set on an account that held a client role of its own, and had not
	 * signed in, when its first organization took it in: a standalone member
	 * the team made, say. The Roster writes and reads it
	 * (Organizations\Roster::keepStanding()), so that ending the invitation
	 * leaves such a person what they were.
	 */
	public const KEY_STOOD_ALONE = 'monstera_stood_alone';

	/**
	 * Set on an account the moment an invitation makes it: the organization
	 * it was made for and when, [ 'org_id' => int, 'at' => ISO 8601 ].
	 * Members\Provisioning writes it as WordPress registers the account
	 * (insertUser()), and nothing else does. Ending the invitation of
	 * someone who never signed in removes the account, and only an account
	 * that carries this is ever removed (Organizations\Roster::remove()):
	 * that an invitation made an account is known, never worked out from
	 * what the account holds. An account from before the key was written
	 * lacks it, and stays. The Roster takes it from an account that outlives
	 * its invitation and from one that joins a first organization, so an
	 * account in no organization never carries it.
	 */
	public const KEY_INVITED_ACCOUNT = 'monstera_invited_account';

	/**
	 * The reminders a standalone member has been sent about their own
	 * membership's end: [ 'for' => the expiry date they were about, as
	 * Y-m-d, 'sent' => the windows sent, 'warning_30' … 'warning_1' and
	 * 'expired' ]. Notifications\Expiration adds each window as its email
	 * goes, so each goes once, as an organization's flags make its own go
	 * once; a renewal deletes it
	 * (Organizations\Membership::applyMemberRenewal()). A record about
	 * another date than the one the member holds now is a term gone by and
	 * counts for nothing, so a date the team moves by hand starts the
	 * reminders for the new one. Plain meta, as KEY_SAVED is: nothing else
	 * reads or writes it.
	 */
	public const KEY_EXPIRY_NOTICES = 'monstera_expiry_notices';

	public static function register(): void {
		$managers = static fn ( bool $allowed, string $key, int $objectId, int $userId ): bool => self::isManager( $userId );
		$self     = static fn ( bool $allowed, string $key, int $objectId, int $userId ): bool => ( $userId > 0 && $objectId === $userId ) || self::isManager( $userId );

		register_meta(
			'user',
			self::KEY_POSITION,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_BIO,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'wp_kses_post',
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_PROFILE_PHOTO,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_SHOW_IN_DIRECTORY,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_MEMBERSHIP_EXPIRES,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $managers,
			]
		);

		register_meta(
			'user',
			self::KEY_LAST_LOGIN,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $managers,
			]
		);

		register_meta(
			'user',
			self::KEY_THEME,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => 'light',
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ 'light', 'dark' ], true ) ? $v : 'light',
				'auth_callback'     => $self,
			]
		);

		// The column sets: a map of list key to the column keys turned off,
		// written only by POST profile/me/columns through Admin\ColumnSets,
		// which cleans it;
		// the auth callback refuses every other door, which update_user_meta()
		// does not consult.
		register_meta(
			'user',
			self::KEY_COLUMNS,
			[
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => is_array( $v ) ? $v : [],
				'auth_callback'     => '__return_false',
			]
		);
	}

	/**
	 * Who may write the membership keys: a Monstera admin (manage_monstera)
	 * or a WordPress administrator (edit_users). Never the member.
	 */
	private static function isManager( int $userId ): bool {
		return $userId > 0
			&& ( user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA ) || user_can( $userId, 'edit_users' ) );
	}

	/**
	 * A member's name as the admin screens print it: first and last name, or
	 * the display name when neither is set.
	 */
	public static function fullName( WP_User $user ): string {
		return trim( $user->first_name . ' ' . $user->last_name ) ?: (string) $user->display_name;
	}

	/**
	 * The photo the person uploaded (KEY_PROFILE_PHOTO) as the address an
	 * avatar shows, or null when they have none, or the attachment is gone:
	 * the admin lists (Avatar.js) and the portal templates then draw the
	 * leaf (docs/DESIGN.md, "Image / asset policy"). Never Gravatar's:
	 * get_avatar_url() answers a URL for everyone, its grey silhouette for
	 * someone with no Gravatar, so a list that passed it on never showed
	 * the leaf, and asking Gravatar sends a hash of the person's address
	 * off the site.
	 */
	public static function photoUrl( int $userId, string $size = 'thumbnail' ): ?string {
		$photoId = (int) get_user_meta( $userId, self::KEY_PROFILE_PHOTO, true );
		$url     = $photoId > 0 ? wp_get_attachment_image_url( $photoId, $size ) : false;
		return is_string( $url ) && '' !== $url ? $url : null;
	}

	/**
	 * Loads several people's photos at once (the attachments and their meta,
	 * which the address is made from), for a list that asks photoUrl() of
	 * each row: one read, not two per person with a photo.
	 *
	 * @param list<int> $userIds
	 */
	public static function primePhotos( array $userIds ): void {
		$photoIds = [];
		foreach ( $userIds as $userId ) {
			$photoId = (int) get_user_meta( $userId, self::KEY_PROFILE_PHOTO, true );
			if ( $photoId > 0 ) {
				$photoIds[ $photoId ] = $photoId;
			}
		}
		if ( $photoIds ) {
			_prime_post_caches( array_values( $photoIds ), false, true );
		}
	}

	/**
	 * Whether the account has ever signed in while Monstera was listening
	 * (MembersModule::onLogin() stamps the key). Someone who has not is
	 * still only invited: the roster lists them as "Invited" and offers
	 * Resend, their welcome carries the link that sets a password, and
	 * removing them ends the invitation and not a membership they ever used
	 * (Organizations\Roster::remove()). All of those ask here, so "invited"
	 * means one thing.
	 */
	public static function hasSignedIn( int $userId ): bool {
		return '' !== (string) get_user_meta( $userId, self::KEY_LAST_LOGIN, true );
	}

	public static function profileCompletionPct( int $userId ): int {
		$userdata = get_userdata( $userId );
		$signals  = [
			(bool) get_user_meta( $userId, self::KEY_PROFILE_PHOTO, true ),
			(bool) trim( (string) get_user_meta( $userId, self::KEY_BIO, true ) ),
			(bool) trim( (string) get_user_meta( $userId, self::KEY_POSITION, true ) ),
			[] !== Roster::orgIdsOf( $userId ),
			(bool) trim( (string) ( $userdata ? $userdata->first_name : '' ) ),
		];
		$weight   = count( $signals );
		$present  = count( array_filter( $signals ) );
		return (int) round( ( $present / $weight ) * 100 );
	}
}
