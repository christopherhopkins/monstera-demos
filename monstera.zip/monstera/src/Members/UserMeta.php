<?php
declare(strict_types=1);

namespace Monstera\Members;

use Monstera\Core\Capabilities;
use WP_User;

final class UserMeta {

	public const KEY_ASSOCIATED_ORG     = 'monstera_associated_org';
	public const KEY_POSITION           = 'monstera_position';
	public const KEY_BIO                = 'monstera_bio';
	public const KEY_PROFILE_PHOTO      = 'monstera_profile_photo';
	public const KEY_SHOW_IN_DIRECTORY  = 'monstera_show_in_directory';
	public const KEY_MEMBERSHIP_EXPIRES = 'monstera_membership_expires';
	public const KEY_LAST_LOGIN         = 'monstera_last_login';
	public const KEY_THEME              = 'monstera_theme';

	/**
	 * Register every user meta key with an explicit owner. No key is exposed
	 * through core REST (`/wp/v2/users`): nothing reads it there, the portal
	 * profile writes through `ProfileController` and the admin shell through
	 * `MembersController`, so exposure would only have handed a signed-in
	 * member a way to write their own organization and expiry. The auth
	 * callbacks decide `edit_user_meta`: the membership keys (organization,
	 * expiry, last login) belong to managers; the profile keys belong to the
	 * member on their own account as well.
	 */
	/** When the member was last saved from the admin and by whom: [ 'at' => ISO 8601, 'by' => user id ]. */
	public const KEY_SAVED = 'monstera_saved';

	public static function register(): void {
		$managers = static fn ( bool $allowed, string $key, int $objectId, int $userId ): bool => self::isManager( $userId );
		$self     = static fn ( bool $allowed, string $key, int $objectId, int $userId ): bool => ( $userId > 0 && $objectId === $userId ) || self::isManager( $userId );

		register_meta(
			'user',
			self::KEY_ASSOCIATED_ORG,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
				'auth_callback'     => $managers,
			]
		);

		register_meta(
			'user',
			self::KEY_POSITION,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_BIO,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'wp_kses_post',
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_PROFILE_PHOTO,
			[
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'absint',
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_SHOW_IN_DIRECTORY,
			[
				'type'              => 'boolean',
				'single'            => true,
				'default'           => true,
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => (bool) $v,
				'auth_callback'     => $self,
			]
		);

		register_meta(
			'user',
			self::KEY_MEMBERSHIP_EXPIRES,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $managers,
			]
		);

		register_meta(
			'user',
			self::KEY_LAST_LOGIN,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $managers,
			]
		);

		register_meta(
			'user',
			self::KEY_THEME,
			[
				'type'              => 'string',
				'single'            => true,
				'default'           => 'light',
				'show_in_rest'      => false,
				'sanitize_callback' => static fn ( $v ) => in_array( $v, [ 'light', 'dark' ], true ) ? $v : 'light',
				'auth_callback'     => $self,
			]
		);
	}

	/**
	 * Who may write the membership keys: a Monstera admin (manage_monstera)
	 * or a WordPress administrator (edit_users). Never the member.
	 */
	private static function isManager( int $userId ): bool {
		return $userId > 0
			&& ( user_can( $userId, Capabilities::CAP_MANAGE_MONSTERA ) || user_can( $userId, 'edit_users' ) );
	}

	public static function associatedOrg( int $userId ): int {
		return (int) get_user_meta( $userId, self::KEY_ASSOCIATED_ORG, true );
	}

	/**
	 * A member's name as the admin screens print it: first and last name, or
	 * the display name when neither is set.
	 */
	public static function fullName( WP_User $user ): string {
		return trim( $user->first_name . ' ' . $user->last_name ) ?: (string) $user->display_name;
	}

	public static function profileCompletionPct( int $userId ): int {
		$userdata = get_userdata( $userId );
		$signals  = [
			(bool) get_user_meta( $userId, self::KEY_PROFILE_PHOTO, true ),
			(bool) trim( (string) get_user_meta( $userId, self::KEY_BIO, true ) ),
			(bool) trim( (string) get_user_meta( $userId, self::KEY_POSITION, true ) ),
			(bool) get_user_meta( $userId, self::KEY_ASSOCIATED_ORG, true ),
			(bool) trim( (string) ( $userdata ? $userdata->first_name : '' ) ),
		];
		$weight   = count( $signals );
		$present  = count( array_filter( $signals ) );
		return (int) round( ( $present / $weight ) * 100 );
	}
}
