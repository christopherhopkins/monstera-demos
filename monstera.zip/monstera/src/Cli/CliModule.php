<?php
declare(strict_types=1);

namespace Monstera\Cli;

use Monstera\Core\Module;

final class CliModule implements Module {

	public function slug(): string {
		return 'cli';
	}

	public function boot(): void {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'monstera', Commands::class );
		}
	}

	public function registerPostTypes(): void {}
}
