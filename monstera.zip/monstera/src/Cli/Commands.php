<?php
declare(strict_types=1);

namespace Monstera\Cli;

use Monstera\BackgroundSync\BackgroundSyncModule;
use Monstera\Core\Hooks;
use Monstera\Demo\Seeder;
use Monstera\Plugin;
use Monstera\Reporting\Exporters\MembersExporter;
use WP_CLI;

/**
 * `wp monstera ...` command surface.
 */
final class Commands {

	/**
	 * Seed a demo program.
	 *
	 * Runs the monstera-demo companion's seeder (demo/), which dev mode
	 * loads and a demo site installs. Idempotent per row: running it again
	 * adds nothing and picks up fixtures added since. The outcome is written
	 * to dev/seed.last.log on a development checkout, or to the system
	 * temporary directory on a site without dev/.
	 *
	 * ## OPTIONS
	 *
	 * [--program=<program>]
	 * : Which program to seed. `all` is the local development dataset (every
	 * organization, the legacy "both" use case); `agency`, `association` and
	 * `standalone` each hold one use case's slice with its preset applied.
	 * ---
	 * default: all
	 * options:
	 *   - all
	 *   - agency
	 *   - association
	 *   - standalone
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp monstera seed
	 *     wp monstera seed --program=agency
	 * @param array<int, string> $args
	 * @param array<string, mixed> $assoc
	 */
	public function seed( array $args, array $assoc ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- WP-CLI passes ( $args, $assoc_args ) to every command.
		if ( ! class_exists( Seeder::class ) ) {
			WP_CLI::error( 'The monstera-demo companion is not loaded, so there is no seeder. Dev mode (MONSTERA_DEV_MODE) loads it from demo/; a demo site installs it as a plugin.' );
		}
		$program = (string) ( $assoc['program'] ?? Seeder::ALL );
		if ( ! in_array( $program, Seeder::PROGRAMS, true ) ) {
			WP_CLI::error( sprintf( 'Unknown program "%s". One of: %s.', $program, implode( ', ', Seeder::PROGRAMS ) ) );
		}

		Plugin::runDevSeed( $program );
		$log     = basename( Plugin::seedLogFile() );
		$details = '' !== $log ? sprintf( '%s has details.', $log ) : 'No log was kept: the only temporary folder is inside the site.';
		$state   = get_option( 'monstera_demo_seeded' );
		if ( '1' === $state ) {
			WP_CLI::success( sprintf( 'Seeded the "%s" program. %s', $program, $details ) );
			return;
		}
		WP_CLI::warning( sprintf( 'The "%s" program did not finish cleanly. %s State: %s', $program, $details, (string) $state ) );
	}

	/**
	 * Run all background sync tasks immediately.
	 *
	 * ## EXAMPLES
	 *
	 *     wp monstera sync
	 * @param array<int, string> $args
	 * @param array<string, mixed> $assoc
	 */
	public function sync( array $args, array $assoc ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- WP-CLI passes ( $args, $assoc_args ) to every command.
		$results = BackgroundSyncModule::runAll();
		foreach ( $results as $task => $detail ) {
			WP_CLI::log( sprintf( '%s: %s', $task, wp_json_encode( $detail ) ) );
		}
		WP_CLI::success( __( 'Sync complete.', 'monstera' ) );
	}

	/**
	 * Export members as CSV to stdout.
	 *
	 * ## OPTIONS
	 *
	 * [--org=<id>]
	 * : Restrict to a single organization.
	 *
	 * ## EXAMPLES
	 *
	 *     wp monstera export members > members.csv
	 *     wp monstera export members --org=42 > acme.csv
	 * @param array<int, string> $args
	 * @param array<string, mixed> $assoc
	 */
	public function export( array $args, array $assoc ): void {
		$what = $args[0] ?? '';
		switch ( $what ) {
			case 'members':
				$exporter = new MembersExporter();
				$rows     = $exporter->rows( [ 'org' => (int) ( $assoc['org'] ?? 0 ) ] );
				$fh       = fopen( 'php://output', 'w' );
				fputcsv(
					$fh,
					array_keys(
						reset( $rows ) ?: [
							'id'    => '',
							'name'  => '',
							'email' => '',
							'org'   => '',
							'role'  => '',
						]
					)
				);
				foreach ( $rows as $row ) {
					fputcsv( $fh, $row );
				}
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream; WP_Filesystem cannot write a response body.
				return;
			default:
				WP_CLI::error( sprintf( 'Unknown export target "%s". Try: members.', $what ) );
		}
	}

	/**
	 * Quickly create an organization. For dev/seeding only.
	 *
	 * ## OPTIONS
	 *
	 * <name>
	 * : The organization name.
	 *
	 * [--slug=<slug>]
	 * : Optional explicit slug.
	 * @param array<int, string> $args
	 * @param array<string, mixed> $assoc
	 */
	public function create_org( array $args, array $assoc ): void {
		$name = $args[0] ?? '';
		if ( ! $name ) {
			WP_CLI::error( 'Provide a name.' );
		}
		$slug = isset( $assoc['slug'] ) ? sanitize_title( $assoc['slug'] ) : sanitize_title( $name );
		$id   = wp_insert_post(
			[
				'post_type'   => \Monstera\Organizations\PostType::SLUG,
				'post_title'  => $name,
				'post_name'   => $slug,
				'post_status' => 'publish',
			],
			true
		);
		if ( is_wp_error( $id ) ) {
			WP_CLI::error( $id->get_error_message() );
		}
		WP_CLI::success( sprintf( 'Created org %s (#%d) at /portal/%s/', $name, $id, $slug ) );
	}

	/**
	 * Complete a membership renewal for an organization.
	 *
	 * Stands in for the Payments module while it doesn't exist yet: fires the
	 * monstera/payment_completed seam, which sets the org's expiry to one year
	 * from now (no pro-rating), clears expiry reminders, and reactivates an
	 * auto-suspended org. Use it to exercise the renewal mechanics end to end.
	 *
	 * ## OPTIONS
	 *
	 * <org_id>
	 * : The organization post ID to renew.
	 *
	 * ## EXAMPLES
	 *
	 *     wp monstera renew 42
	 * @param array<int, string> $args
	 * @param array<string, mixed> $assoc
	 */
	public function renew( array $args, array $assoc ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- WP-CLI passes ( $args, $assoc_args ) to every command.
		$orgId = (int) ( $args[0] ?? 0 );
		if ( $orgId <= 0 ) {
			WP_CLI::error( 'Provide an organization ID.' );
		}
		do_action(
			Hooks::PAYMENT_COMPLETED,
			[
				'type'    => 'renewal',
				'org_id'  => $orgId,
				'paid_at' => current_time( 'mysql', true ),
			]
		);
		$expires = (string) get_post_meta( $orgId, \Monstera\Organizations\Meta::KEY_EXPIRES, true );
		WP_CLI::success( sprintf( 'Renewed org #%d. New expiry: %s', $orgId, $expires ?: '(unchanged — check the org exists)' ) );
	}
}
