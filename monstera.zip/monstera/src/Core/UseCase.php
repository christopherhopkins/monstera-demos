<?php
/**
 * The three use-case presets an install chooses from (onboarding, Settings),
 * and the one way to apply one. The demo seeder applies a preset per program
 * through the same path, so a demo site is configured the way a real one is.
 */

declare(strict_types=1);

namespace Monstera\Core;

defined( 'ABSPATH' ) || exit;

final class UseCase {

	public const AGENCY      = 'agency';
	public const ASSOCIATION = 'association';
	public const STANDALONE  = 'standalone';

	public const OPTION = 'monstera_use_case';

	/**
	 * @return array<string, array{label: string, description: string, enables: string, modules: string[], content_label: string}>
	 */
	public static function presets(): array {
		return [
			self::AGENCY      => [
				'label'         => __( 'An agency with clients', 'monstera' ),
				'description'   => __( 'Each client is an organization with its own portal. Projects are the spine: discovery, deliverables, status.', 'monstera' ),
				'enables'       => __( 'Projects, Support, Alerts, Reports', 'monstera' ),
				'modules'       => [ Modules::PROJECTS, Modules::SUPPORT, Modules::ALERTS, Modules::REPORTING ],
				'content_label' => __( 'Deliverables', 'monstera' ),
			],
			self::ASSOCIATION => [
				'label'         => __( 'An association with member organizations', 'monstera' ),
				'description'   => __( 'Member orgs manage their own rosters and sub-groups. Content and resources reach the right people.', 'monstera' ),
				'enables'       => __( 'Sub-groups, Forms, Alerts, Reports', 'monstera' ),
				'modules'       => [ Modules::FORMS, Modules::ALERTS, Modules::REPORTING ],
				'content_label' => __( 'Publications', 'monstera' ),
			],
			self::STANDALONE  => [
				'label'         => __( 'Individual members, no organizations', 'monstera' ),
				'description'   => __( 'People sign up on their own. A simpler portal: content, resources, a directory if you want one.', 'monstera' ),
				'enables'       => __( 'Forms, Support', 'monstera' ),
				'modules'       => [ Modules::FORMS, Modules::SUPPORT ],
				'content_label' => __( 'Content', 'monstera' ),
			],
		];
	}

	/** @return string[] */
	public static function keys(): array {
		return array_keys( self::presets() );
	}

	public static function current(): string {
		return (string) get_option( self::OPTION, '' );
	}

	/**
	 * Applies a preset: the use case, its modules, its content label, and
	 * onboarding done. Refuses anything but the three presets.
	 *
	 * @return string[] The modules the preset turned on.
	 */
	public static function apply( string $useCase ): array {
		$presets = self::presets();
		if ( ! isset( $presets[ $useCase ] ) ) {
			throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown use case "%s".', $useCase ) ) );
		}
		$preset = $presets[ $useCase ];

		update_option( self::OPTION, $useCase );
		update_option( 'monstera_active_modules', $preset['modules'] );
		update_option( 'monstera_content_labels', [ 'name' => $preset['content_label'] ] );
		update_option( 'monstera_onboarding_complete', '1' );
		// Drop the per-request module cache so any isActive() read later in this
		// request reflects the new preset.
		Modules::invalidateCache();

		return $preset['modules'];
	}
}
