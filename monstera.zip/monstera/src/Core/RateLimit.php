<?php
declare(strict_types=1);

namespace Monstera\Core;

defined( 'ABSPATH' ) || exit;

/**
 * How often a person may do something that sends email on their word (a
 * support request, an invitation, a form's send): counted per person and
 * action in a transient that lapses $seconds after it was last set.
 */
final class RateLimit {

	/** The transient a person's count of an action is kept under. */
	public static function key( string $action, int $userId ): string {
		return 'monstera_rate_' . md5( $action . '|' . $userId );
	}

	/**
	 * Whether the person has used the action more than $limit times in the
	 * last $seconds, counting this use.
	 */
	public static function over( string $action, int $userId, int $limit, int $seconds ): bool {
		if ( self::reached( $action, $userId, $limit ) ) {
			return true;
		}
		self::record( $action, $userId, $seconds );
		return false;
	}

	/** Whether the person has used the action $limit times in the window, this use not counted. */
	public static function reached( string $action, int $userId, int $limit ): bool {
		return self::read( $action, $userId, 0 )['count'] >= $limit;
	}

	/**
	 * Counts one use. The window opens at the first use and stays put, so
	 * the limit is $limit in $seconds, not $limit with less than $seconds
	 * between any two.
	 */
	public static function record( string $action, int $userId, int $seconds ): void {
		$used = self::read( $action, $userId, $seconds );
		++$used['count'];
		set_transient( self::key( $action, $userId ), $used, max( 1, $used['until'] - time() ) );
	}

	/** @return array{count: int, until: int} */
	private static function read( string $action, int $userId, int $seconds ): array {
		$stored = get_transient( self::key( $action, $userId ) );
		if ( is_array( $stored ) && isset( $stored['count'], $stored['until'] ) && (int) $stored['until'] > time() ) {
			return [
				'count' => (int) $stored['count'],
				'until' => (int) $stored['until'],
			];
		}
		// A count from before the window was kept beside it, or none.
		return [
			'count' => is_numeric( $stored ) ? (int) $stored : 0,
			'until' => time() + $seconds,
		];
	}
}
