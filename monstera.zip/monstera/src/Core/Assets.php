<?php
/**
 * Enqueue strategy for both admin and portal surfaces.
 *
 * Admin styles + React shell load only on Monstera-owned admin pages.
 * Portal styles + Interactivity API modules load only on /portal/* routes.
 * Token CSS is shared and inlined as a critical sliver for first paint.
 */

declare(strict_types=1);

namespace Monstera\Core;

final class Assets {

	private string $version;

	public function __construct() {
		$this->version = defined( 'MONSTERA_DEV_MODE' ) && MONSTERA_DEV_MODE
			? (string) time()
			: MONSTERA_VERSION;
	}

	public function register(): void {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueueAdmin' ] );
		add_filter( 'pre_load_script_translations', [ $this, 'adminTranslations' ], 10, 4 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueuePortal' ] );
		add_action( 'wp_head', [ $this, 'inlineTokenSliver' ], 1 );
		add_action( 'admin_head', [ $this, 'inlineTokenSliver' ], 1 );
	}

	public function enqueueAdmin( string $hook ): void {
		if ( ! str_contains( $hook, 'monstera' ) && 'toplevel_page_monstera' !== $hook ) {
			// Still register the admin menu icon font/CSS lite for menu glyph.
			wp_register_style(
				'monstera-admin-chrome',
				MONSTERA_URL . 'build/css/admin-chrome.css',
				[],
				$this->version
			);
			wp_enqueue_style( 'monstera-admin-chrome' );
			return;
		}

		// The block editor lives on the content detail and nowhere else, so
		// its styles, its scripts and the media library load there alone; a
		// list or the dashboard does not carry them.
		$editor = self::hasEditor();
		$styles = [ 'wp-components' ];
		if ( $editor ) {
			// Block editor styles. ContentDetail mounts a real Gutenberg block
			// canvas; these stylesheets are required for blocks to render
			// correctly. Enqueued BEFORE our admin.css so our overrides win the
			// cascade, and declared as deps so they always load first.
			$styles = [ 'wp-edit-blocks', 'wp-block-library', 'wp-block-library-theme', 'wp-format-library', 'wp-components' ];
		}
		foreach ( $styles as $style ) {
			wp_enqueue_style( $style );
		}

		wp_enqueue_style(
			'monstera-admin',
			MONSTERA_URL . 'build/css/admin.css',
			$styles,
			$this->version
		);

		// Media library — required for block-editor image / file inserts.
		if ( $editor && function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}

		$asset_file    = MONSTERA_DIR . 'build/admin/index.asset.php';
		$deps          = [ 'wp-element', 'wp-api-fetch', 'wp-i18n', 'wp-components' ];
		$asset_version = $this->version;

		if ( is_file( $asset_file ) ) {
			$asset         = require $asset_file;
			$deps          = array_merge( $deps, $asset['dependencies'] ?? [] );
			$asset_version = $asset['version'] ?? $asset_version;
		}
		// The asset file lists what every chunk reads. The editor's packages
		// are read by the content detail's chunk alone: they load with it,
		// whatever the asset file lists, and with no other page.
		$deps = array_values(
			array_unique(
				$editor
					? array_merge( $deps, self::EDITOR_SCRIPTS )
					: array_diff( $deps, self::EDITOR_SCRIPTS )
			)
		);

		wp_enqueue_script(
			'monstera-admin',
			MONSTERA_URL . 'build/admin/index.js',
			$deps,
			$asset_version,
			true
		);

		wp_set_script_translations( 'monstera-admin', 'monstera' );

		wp_localize_script(
			'monstera-admin',
			'monsteraAdmin',
			[
				// ?rest_route= form rather than /wp-json/ — survives environments
				// (like wp-now) where pretty REST rewrites don't stick.
				'restUrl'   => esc_url_raw( Routing::restUrl( 'monstera/v1/' ) ),
				'restNonce' => wp_create_nonce( 'wp_rest' ),
				'adminUrl'  => esc_url_raw( admin_url() ),
				'portalUrl' => esc_url_raw( Routing::url( Routing::ROUTE_DASHBOARD ) ),
				'page'      => sanitize_key( $_GET['page'] ?? 'monstera' ), // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
				'version'   => MONSTERA_VERSION,
				'theme'     => (string) get_user_meta( get_current_user_id(), 'monstera_theme', true ) ?: 'light',
				// Where the lazy detail chunks load from (public-path.js).
				'buildUrl'  => esc_url_raw( MONSTERA_URL . 'build/' ),
				// The save bar's "Saved just now by <name>".
				'userName'  => \Monstera\Members\UserMeta::fullName( wp_get_current_user() ),
				// A control that belongs to a module shows only while it is on.
				'modules'   => array_values( Modules::active() ),
			]
		);

		// Pull the same block-editor settings the post editor uses (palette,
		// font sizes, gradients, spacing scale, border controls, theme.json
		// __experimentalFeatures, etc.) and expose them to BlockEditor.js.
		// Without these, the inspector only renders bare "Typography" /
		// "Advanced" panels — Color, Dimensions, Border, font-size presets
		// all gate on having these settings present.
		if ( $editor ) {
			$this->addBlockEditorSettingsInlineScript( 'monstera-admin' );
		}
	}

	/**
	 * The script packages only the block editor reads
	 * (scripts/__tests__/admin-bundle.test.mjs holds the chunks to it).
	 */
	private const EDITOR_SCRIPTS = [ 'wp-block-editor', 'wp-block-library', 'wp-blocks', 'wp-media-utils', 'wp-keyboard-shortcuts' ];

	/** Whether the page is the content detail, new or existing. */
	private static function hasEditor(): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only routing parameters; nothing is written.
		$page   = sanitize_key( (string) ( $_GET['page'] ?? '' ) );
		$detail = absint( $_GET['id'] ?? 0 ) > 0 || 'new' === sanitize_key( (string) ( $_GET['action'] ?? '' ) );
		// phpcs:enable
		return 'monstera-content' === $page && $detail;
	}

	/**
	 * The admin's translations: every Monstera script file's, merged.
	 * `wp i18n make-json` writes one JSON file per source file, and
	 * WordPress looks up only the file named for the script it is loading
	 * (build/admin/index.js), so the strings of a lazy chunk, which is most
	 * of each detail page, would stay untranslated.
	 *
	 * @param string|false|null $translations What an earlier filter returned.
	 * @param string|false      $file         The file WordPress would load.
	 * @param string            $handle       The script.
	 * @param string            $domain       The text domain.
	 * @return string|false|null
	 */
	public function adminTranslations( $translations, $file, $handle, $domain ) {
		if ( 'monstera' !== $domain || 'monstera-admin' !== $handle ) {
			return $translations;
		}
		$files = glob( MONSTERA_DIR . 'languages/monstera-' . determine_locale() . '-*.json' );
		if ( ! $files ) {
			return $translations;
		}
		$merged = null;
		foreach ( $files as $path ) {
			$data = json_decode( (string) file_get_contents( $path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local translation file shipped with the plugin.
			if ( ! is_array( $data ) || ! is_array( $data['locale_data']['messages'] ?? null ) ) {
				continue;
			}
			if ( null === $merged ) {
				$merged = $data;
				continue;
			}
			$merged['locale_data']['messages'] += $data['locale_data']['messages'];
		}
		return null === $merged ? $translations : (string) wp_json_encode( $merged );
	}

	/**
	 * Expose the server block-editor settings to BlockEditor.js as a global. Used
	 * by both the admin shell and the portal content editor island.
	 */
	private function addBlockEditorSettingsInlineScript( string $handle ): void {
		wp_add_inline_script(
			$handle,
			'window.monsteraBlockEditorSettings = ' . wp_json_encode( self::buildBlockEditorSettings() ) . ';',
			'before'
		);
	}

	/**
	 * Build the block-editor settings dict to hand to BlockEditorProvider.
	 * Mirrors what wp-admin/edit-form-blocks.php passes to the post editor,
	 * with a guard so a host without get_block_editor_settings() doesn't
	 * fatal — we fall back to a minimal but functional default.
	 *
	 * @return array<string, mixed>
	 */
	private static function buildBlockEditorSettings(): array {
		if ( ! function_exists( 'get_block_editor_settings' ) ) {
			return self::minimalBlockEditorSettings();
		}

		if ( ! class_exists( 'WP_Block_Editor_Context' ) ) {
			$ctx_file = ABSPATH . WPINC . '/class-wp-block-editor-context.php';
			if ( is_file( $ctx_file ) ) {
				require_once $ctx_file;
			}
		}

		if ( ! class_exists( 'WP_Block_Editor_Context' ) ) {
			return self::minimalBlockEditorSettings();
		}

		$context  = new \WP_Block_Editor_Context( [ 'name' => 'core/edit-post' ] );
		$settings = get_block_editor_settings( [], $context );

		// __unstableResolvedAssets configures Gutenberg's iframe-mode rendering.
		// We're not iframing the canvas; keeping this can cause the block list
		// to try to mount inside an iframe it can't reach. Strip it.
		unset( $settings['__unstableResolvedAssets'] );

		return $settings;
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function minimalBlockEditorSettings(): array {
		return [
			'disableCustomColors'    => false,
			'disableCustomFontSizes' => false,
			'disableCustomGradients' => false,
			'enableCustomLineHeight' => true,
			'enableCustomSpacing'    => true,
			'enableCustomUnits'      => true,
			'imageEditing'           => true,
			'colors'                 => [
				[
					'name'  => 'Leaf',
					'slug'  => 'leaf',
					'color' => '#3f6f47',
				],
				[
					'name'  => 'Clay',
					'slug'  => 'clay',
					'color' => '#b86838',
				],
				[
					'name'  => 'Bark',
					'slug'  => 'bark',
					'color' => '#3a312a',
				],
				[
					'name'  => 'Sun',
					'slug'  => 'sun',
					'color' => '#fbf9f3',
				],
				[
					'name'  => 'Shade',
					'slug'  => 'shade',
					'color' => '#e1e2dd',
				],
			],
			'fontSizes'              => [
				[
					'name' => 'Small',
					'slug' => 'small',
					'size' => '14px',
				],
				[
					'name' => 'Medium',
					'slug' => 'medium',
					'size' => '18px',
				],
				[
					'name' => 'Large',
					'slug' => 'large',
					'size' => '24px',
				],
				[
					'name' => 'XL',
					'slug' => 'x-large',
					'size' => '32px',
				],
				[
					'name' => 'XXL',
					'slug' => 'xx-large',
					'size' => '48px',
				],
			],
		];
	}

	public function enqueuePortal(): void {
		if ( ! self::isPortal() ) {
			return;
		}

		wp_enqueue_style(
			'monstera-portal',
			MONSTERA_URL . 'build/css/portal.css',
			[],
			$this->version
		);

		// Fraunces (display) + Inter (body), preload critical weights.
		add_action( 'wp_head', [ self::class, 'preloadFonts' ], 2 );

		// The portal store is a script module (webpack.config.js), so its
		// dependency is the module id, not the wp-interactivity script handle:
		// WordPress ships the Interactivity API only as a module.
		$asset_file    = MONSTERA_DIR . 'build/portal/index.asset.php';
		$deps          = [ '@wordpress/interactivity' ];
		$asset_version = $this->version;
		if ( is_file( $asset_file ) ) {
			$asset         = require $asset_file;
			$deps          = array_values( array_unique( array_merge( $deps, $asset['dependencies'] ?? [] ) ) );
			$asset_version = $asset['version'] ?? $asset_version;
		}

		wp_register_script_module(
			'monstera-portal',
			MONSTERA_URL . 'build/portal/index.js',
			$deps,
			$asset_version
		);
		wp_enqueue_script_module( 'monstera-portal' );

		// Content block-editor island: only on the org-hub Manage › Content
		// compose/edit view, and only for users who may author. Keeps the heavy
		// Gutenberg bundle off every other portal page.
		$tab       = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
		$section   = isset( $_GET['section'] ) ? sanitize_key( (string) $_GET['section'] ) : 'content'; // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
		$composing = ! empty( $_GET['compose'] ) || ! empty( $_GET['edit'] ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only routing parameter; nothing is written.
		if (
			Routing::ROUTE_ORG === get_query_var( Routing::QUERY_VAR )
			&& 'manage' === $tab
			&& 'content' === $section
			&& $composing
			&& current_user_can( Capabilities::CAP_AUTHOR_PORTAL )
		) {
			$this->enqueuePortalEditor();
		}
	}

	/**
	 * Enqueue the portal content editor island (reuses the admin BlockEditor
	 * component). Mirrors enqueueAdmin()'s block-editor wiring, but localizes a
	 * portal-specific config and the author's targetable sub-groups.
	 */
	private function enqueuePortalEditor(): void {
		wp_enqueue_style( 'wp-edit-blocks' );
		wp_enqueue_style( 'wp-block-library' );
		wp_enqueue_style( 'wp-block-library-theme' );
		wp_enqueue_style( 'wp-format-library' );
		wp_enqueue_style( 'wp-components' );

		wp_enqueue_style(
			'monstera-portal-editor',
			MONSTERA_URL . 'build/css/portal-editor.css',
			[ 'wp-edit-blocks', 'wp-block-library', 'wp-block-library-theme', 'wp-format-library', 'wp-components', 'monstera-portal' ],
			$this->version
		);

		if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}

		$asset_file    = MONSTERA_DIR . 'build/portal-editor/index.asset.php';
		$deps          = [ 'wp-element', 'wp-i18n', 'wp-components', 'wp-blocks', 'wp-block-editor', 'wp-block-library' ];
		$asset_version = $this->version;
		if ( is_file( $asset_file ) ) {
			$asset         = require $asset_file;
			$deps          = array_merge( $deps, $asset['dependencies'] ?? [] );
			$asset_version = $asset['version'] ?? $asset_version;
		}

		wp_enqueue_script(
			'monstera-portal-editor',
			MONSTERA_URL . 'build/portal-editor/index.js',
			$deps,
			$asset_version,
			true
		);
		wp_set_script_translations( 'monstera-portal-editor', 'monstera' );

		$scope     = \Monstera\Portal\AuthorScope::forCurrentUser();
		$subgroups = [];
		if ( ! $scope->isLeader() && $scope->orgId > 0 ) {
			foreach ( ( new \Monstera\Subgroups\Repository() )->forOrg( $scope->orgId ) as $sg ) {
				$subgroups[] = [
					'id'   => (int) $sg->ID,
					'name' => get_the_title( $sg ),
				];
			}
		}

		wp_localize_script(
			'monstera-portal-editor',
			'monsteraPortalEditor',
			[
				'apiBase'   => esc_url_raw( Routing::restUrl( 'monstera/v1/' ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'isLeader'  => $scope->isLeader(),
				'subgroups' => $subgroups,
			]
		);

		$this->addBlockEditorSettingsInlineScript( 'monstera-portal-editor' );
	}

	public function inlineTokenSliver(): void {
		// Inline the role tokens for first-paint stability. Full token sheet
		// lives in build/css/admin.css and build/css/portal.css.
		$user_theme = is_user_logged_in()
			? (string) get_user_meta( get_current_user_id(), 'monstera_theme', true )
			: '';
		$theme_attr = '' === $user_theme || 'light' === $user_theme
			? ''
			: ' data-monstera-theme="' . esc_attr( $user_theme ) . '"';

		// Inject the data attribute on <html> via tiny inline script (no FOUC).
		echo '<script>(function(){try{var t=document.documentElement;'
			. 't.dataset.monsteraTheme="' . esc_js( $user_theme ?: 'light' ) . '";}catch(e){}})();</script>';
	}

	public static function preloadFonts(): void {
		$base = MONSTERA_URL . 'assets/fonts/';
		echo '<link rel="preload" href="' . esc_url( $base . 'Fraunces-Variable.woff2' )
			. '" as="font" type="font/woff2" crossorigin>'
			. '<link rel="preload" href="' . esc_url( $base . 'Inter-Variable.woff2' )
			. '" as="font" type="font/woff2" crossorigin>';
	}

	public static function isPortal(): bool {
		$route = get_query_var( Routing::QUERY_VAR );
		return ! empty( $route );
	}
}
