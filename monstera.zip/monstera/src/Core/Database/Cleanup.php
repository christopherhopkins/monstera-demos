<?php
/**
 * Removes custom-table rows that reference a permanently deleted post or user.
 *
 * WordPress deletes post meta and user meta itself; the relationship tables
 * Monstera owns are cleaned here on the same hooks, so a deleted sub-group,
 * project, content item, alert, organization or member leaves no dangling
 * rows behind. An organization's memberships and assignments go through the
 * Roster, which also derives again the role each of its people is left with;
 * a deleted member's rows are dropped here, since no role is left to derive,
 * and so is their name wherever a post's own meta gives it: the lead or the
 * client contact of a project, the leader of a sub-group, a reader of an
 * email still on its way. The Roster removes the account of an invitation
 * that has ended (Roster::remove()), and this is what leaves nothing of the
 * person behind it.
 * The log tables (notification log, activity log, support requests) are
 * records and stay. Trashing a post fires neither hook, so trash stays
 * restorable.
 */

declare(strict_types=1);

namespace Monstera\Core\Database;

use Monstera\Alerts\PostType as AlertPostType;
use Monstera\Content\PostType as ContentPostType;
use Monstera\Content\SecureFiles;
use Monstera\Notifications\Dispatcher;
use Monstera\Organizations\PostType as OrgPostType;
use Monstera\Organizations\Roster;
use Monstera\Portal\AuthorScope;
use Monstera\Projects\Meta as ProjectMeta;
use Monstera\Projects\PostType as ProjectPostType;
use Monstera\Projects\Repository as ProjectRepository;
use Monstera\Subgroups\Meta as SubgroupMeta;
use Monstera\Subgroups\PostType as SubgroupPostType;
use Monstera\Subgroups\Repository as SubgroupRepository;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Cleanup {

	/**
	 * Which table column names a post of each type. The organization is not
	 * here: its rows are the Roster's to drop (see onPostDeleted()).
	 *
	 * @var array<string, array<string, string>>  post type => [ table key => column ]
	 */
	private const POST_REFERENCES = [
		SubgroupPostType::SLUG => [
			Schema::TABLE_SUBGROUP_MEMBERS  => 'subgroup_id',
			Schema::TABLE_CONTENT_SUBGROUPS => 'subgroup_id',
		],
		ProjectPostType::SLUG  => [
			Schema::TABLE_PROJECT_MEMBERS  => 'project_id',
			Schema::TABLE_CONTENT_PROJECTS => 'project_id',
			Schema::TABLE_PROJECT_INTAKE   => 'project_id',
		],
		ContentPostType::SLUG  => [
			Schema::TABLE_CONTENT_SUBGROUPS => 'content_id',
			Schema::TABLE_CONTENT_PROJECTS  => 'content_id',
		],
		AlertPostType::SLUG    => [
			Schema::TABLE_ALERT_DISMISSALS => 'alert_id',
		],
	];

	/**
	 * Which tables name a user.
	 *
	 * @var array<string, string>  table key => column
	 */
	private const USER_REFERENCES = [
		Schema::TABLE_SUBGROUP_MEMBERS => 'member_id',
		Schema::TABLE_PROJECT_MEMBERS  => 'member_id',
		Schema::TABLE_ALERT_DISMISSALS => 'member_id',
		Schema::TABLE_ORG_MEMBERS      => 'user_id',
	];

	public static function register(): void {
		add_action( 'deleted_post', [ self::class, 'onPostDeleted' ], 10, 2 );
		add_action( 'deleted_user', [ self::class, 'onUserDeleted' ], 10, 1 );
		// Multisite: leaving a site fires neither hook above, and a network-wide
		// delete removes the user from each site first; the action runs inside
		// switch_to_blog(), so the table prefix is that site's.
		add_action( 'remove_user_from_blog', [ self::class, 'onUserDeleted' ], 10, 1 );
	}

	/**
	 * Runs after WordPress has removed the post row itself.
	 */
	public static function onPostDeleted( int $postId, ?WP_Post $post = null ): void {
		$type = $post instanceof WP_Post ? $post->post_type : '';
		foreach ( self::POST_REFERENCES[ $type ] ?? [] as $table => $column ) {
			self::deleteWhere( $table, $column, $postId );
		}
		if ( OrgPostType::SLUG === $type ) {
			// A membership row is what a person's role was derived from, so the
			// Roster drops them and derives each role again: a bare DELETE here
			// left managers of nothing and members of nowhere.
			Roster::forgetOrganization( $postId );
		}
		if ( ContentPostType::SLUG === $type ) {
			self::deleteSecureFiles( $postId );
		}
		if ( ProjectPostType::SLUG === $type ) {
			self::deleteIntakeFiles( $postId );
		}
	}

	/**
	 * Runs after WordPress has removed the user row itself, or when a user is
	 * removed from the current site on multisite.
	 */
	public static function onUserDeleted( int $userId ): void {
		foreach ( self::USER_REFERENCES as $table => $column ) {
			self::deleteWhere( $table, $column, $userId );
		}
		// A project names its lead in its own meta, which no table above
		// holds and WordPress leaves alone: it deletes a post's meta with the
		// post, never with a user the meta names.
		( new ProjectRepository() )->forgetLead( $userId );
		// So it is with a project's client contact and a sub-group's leader.
		// The Roster clears both for the organization a person leaves; these
		// are the ones left by an organization that went before its people,
		// and by an account deleted from WordPress's own screen. One write
		// each, for every post that names the person.
		delete_metadata( 'post', 0, ProjectMeta::KEY_PRIMARY_CONTACT, $userId, true );
		delete_metadata( 'post', 0, SubgroupMeta::KEY_LEADER, $userId, true );
		// And with an email to an audience that is still going out in batches:
		// nobody is written to once their account is gone.
		Dispatcher::forgetRecipient( $userId );
		Roster::flushCache();
		SubgroupRepository::flushCache();
		AuthorScope::flushCache();
	}

	private static function deleteWhere( string $table, string $column, int $id ): void {
		global $wpdb;
		$wpdb->delete( Schema::tableName( $table ), [ $column => $id ], [ '%d' ] );
	}

	/**
	 * Secure files go through SecureFiles::delete() so the file on disk is
	 * unlinked with its row.
	 */
	private static function deleteSecureFiles( int $contentId ): void {
		global $wpdb;
		$files = new SecureFiles();
		$ids   = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE content_id = %d', Schema::tableName( Schema::TABLE_SECURE_FILES ), $contentId ) );
		foreach ( array_map( 'intval', (array) $ids ) as $fileId ) {
			$files->delete( $fileId );
		}
	}

	/**
	 * The files a deleted project's intake held, from disk and the registry.
	 */
	private static function deleteIntakeFiles( int $projectId ): void {
		global $wpdb;
		$files = new SecureFiles();
		$ids   = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE content_id = 0 AND project_id = %d', Schema::tableName( Schema::TABLE_SECURE_FILES ), $projectId ) );
		foreach ( array_map( 'intval', (array) $ids ) as $fileId ) {
			$files->delete( $fileId );
		}
	}
}
