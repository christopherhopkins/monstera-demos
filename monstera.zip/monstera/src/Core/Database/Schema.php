<?php
/**
 * dbDelta-driven schema migrations.
 *
 * Each migration is a versioned set of CREATE TABLE statements (dbDelta is
 * idempotent and will ALTER existing tables to match). The current DB version
 * is stored in the monstera_db_version option; missing migrations run on
 * activation and on plugins_loaded (defensively, when a code update raises
 * the version mid-flight).
 */

declare(strict_types=1);

namespace Monstera\Core\Database;

defined( 'ABSPATH' ) || exit;

final class Schema {

	public const TABLE_SUBGROUP_MEMBERS  = 'monstera_subgroup_members';
	public const TABLE_CONTENT_SUBGROUPS = 'monstera_content_subgroups';
	public const TABLE_SECURE_FILES      = 'monstera_secure_files';
	public const TABLE_NOTIFICATION_LOG  = 'monstera_notification_log';
	public const TABLE_ACTIVITY_LOG      = 'monstera_activity_log';
	public const TABLE_PROJECT_MEMBERS   = 'monstera_project_members';
	public const TABLE_CONTENT_PROJECTS  = 'monstera_content_projects';
	public const TABLE_PROJECT_INTAKE    = 'monstera_project_intake';
	public const TABLE_SUPPORT_REQUESTS  = 'monstera_support_requests';
	public const TABLE_SUPPORT_MESSAGES  = 'monstera_support_messages';
	public const TABLE_ALERT_DISMISSALS  = 'monstera_alert_dismissals';

	/** @var list<string> Every custom table key, in creation order. */
	public const TABLES = [
		self::TABLE_SUBGROUP_MEMBERS,
		self::TABLE_CONTENT_SUBGROUPS,
		self::TABLE_SECURE_FILES,
		self::TABLE_NOTIFICATION_LOG,
		self::TABLE_ACTIVITY_LOG,
		self::TABLE_PROJECT_MEMBERS,
		self::TABLE_CONTENT_PROJECTS,
		self::TABLE_PROJECT_INTAKE,
		self::TABLE_SUPPORT_REQUESTS,
		self::TABLE_SUPPORT_MESSAGES,
		self::TABLE_ALERT_DISMISSALS,
	];

	public static function tableName( string $key ): string {
		global $wpdb;
		return $wpdb->prefix . $key;
	}

	private static function createTables(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$statements = [
			"CREATE TABLE {$wpdb->prefix}monstera_subgroup_members (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				subgroup_id BIGINT(20) UNSIGNED NOT NULL,
				member_id BIGINT(20) UNSIGNED NOT NULL,
				role_in_group VARCHAR(64) NOT NULL DEFAULT '',
				joined_on DATE NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY subgroup_member (subgroup_id, member_id),
				KEY member_id (member_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_content_subgroups (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				content_id BIGINT(20) UNSIGNED NOT NULL,
				subgroup_id BIGINT(20) UNSIGNED NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY content_subgroup (content_id, subgroup_id),
				KEY subgroup_id (subgroup_id)
			) {$charset_collate};",

			// A file belongs to a content item (content_id > 0), or from
			// version 6 to a project's intake question (content_id 0 with
			// project_id and field_key), or from version 7 to a support
			// request (content_id 0 with support_request_id, and the message
			// it came with; none for the opening message). Never two of them.
			"CREATE TABLE {$wpdb->prefix}monstera_secure_files (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				content_id BIGINT(20) UNSIGNED NOT NULL,
				project_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				field_key VARCHAR(128) NULL DEFAULT NULL,
				uploaded_by BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				support_request_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				support_message_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				storage_path VARCHAR(512) NOT NULL,
				original_name VARCHAR(255) NOT NULL DEFAULT '',
				filesize BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
				mime_type VARCHAR(128) NOT NULL DEFAULT '',
				sha256 CHAR(64) NOT NULL DEFAULT '',
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY  (id),
				KEY content_id (content_id),
				KEY project_question (project_id, field_key),
				KEY support_request (support_request_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_notification_log (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				member_id BIGINT(20) UNSIGNED NOT NULL,
				content_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				event_type VARCHAR(64) NOT NULL,
				channel VARCHAR(32) NOT NULL DEFAULT 'email',
				delivered TINYINT(1) NULL DEFAULT NULL,
				sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				meta LONGTEXT NULL,
				PRIMARY KEY  (id),
				KEY member_id (member_id),
				KEY event_lookup (event_type, content_id, member_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_activity_log (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				event_type VARCHAR(64) NOT NULL,
				object_type VARCHAR(64) NOT NULL DEFAULT '',
				object_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				org_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				ip_hash CHAR(64) NOT NULL DEFAULT '',
				context LONGTEXT NULL,
				PRIMARY KEY  (id),
				KEY user_id (user_id),
				KEY org_id (org_id),
				KEY object_lookup (object_type, object_id),
				KEY occurred_at (occurred_at),
				KEY event_type (event_type)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_project_members (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				project_id BIGINT(20) UNSIGNED NOT NULL,
				member_id BIGINT(20) UNSIGNED NOT NULL,
				role_in_project VARCHAR(64) NOT NULL DEFAULT '',
				joined_on DATE NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY project_member (project_id, member_id),
				KEY member_id (member_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_content_projects (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				content_id BIGINT(20) UNSIGNED NOT NULL,
				project_id BIGINT(20) UNSIGNED NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY content_project (content_id, project_id),
				KEY project_id (project_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_project_intake (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				project_id BIGINT(20) UNSIGNED NOT NULL,
				field_key VARCHAR(128) NOT NULL,
				field_value LONGTEXT NULL,
				submitted_by BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY  (id),
				UNIQUE KEY project_field (project_id, field_key),
				KEY project_id (project_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_support_requests (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				ref CHAR(8) NOT NULL,
				member_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				org_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				project_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				subject VARCHAR(255) NOT NULL,
				body LONGTEXT NOT NULL,
				priority VARCHAR(16) NOT NULL DEFAULT 'normal',
				status VARCHAR(16) NOT NULL DEFAULT 'open',
				attachment_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				resolved_at DATETIME NULL DEFAULT NULL,
				last_activity_at DATETIME NULL DEFAULT NULL,
				last_side VARCHAR(16) NOT NULL DEFAULT 'member',
				PRIMARY KEY  (id),
				UNIQUE KEY ref_unique (ref),
				KEY member_id (member_id),
				KEY status (status),
				KEY last_activity (last_activity_at)
			) {$charset_collate};",

			// A request's thread after its opening message: what each side
			// wrote (kind message) and what changed (kind event, its type,
			// old and new value and cause as JSON in event_data).
			"CREATE TABLE {$wpdb->prefix}monstera_support_messages (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				request_id BIGINT(20) UNSIGNED NOT NULL,
				kind VARCHAR(16) NOT NULL DEFAULT 'message',
				author_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
				side VARCHAR(16) NOT NULL DEFAULT 'member',
				body LONGTEXT NULL,
				event_data TEXT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY  (id),
				KEY request_thread (request_id, created_at)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_alert_dismissals (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				alert_id BIGINT(20) UNSIGNED NOT NULL,
				member_id BIGINT(20) UNSIGNED NOT NULL,
				dismissed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY  (id),
				UNIQUE KEY alert_member (alert_id, member_id)
			) {$charset_collate};",
		];

		foreach ( $statements as $sql ) {
			dbDelta( $sql );
		}
	}

	/**
	 * Activation: the tables, then whatever the stored version still owes.
	 * It takes the upgrade's path, so a site reactivated on an older schema
	 * gets its backfills too (dbDelta is safe to repeat).
	 */
	public static function install(): void {
		$from = (string) get_option( 'monstera_db_version' );
		self::createTables();
		self::migrate( $from );
	}

	/**
	 * Hooked to init, so the first request after an update upgrades, a
	 * portal request as much as wp-admin (an insert into a table missing a
	 * new column fails silently until then). The version is autoloaded:
	 * the check costs no query.
	 */
	public static function maybeUpgrade(): void {
		$from = (string) get_option( 'monstera_db_version' );
		if ( MONSTERA_DB_VERSION !== $from ) {
			self::createTables();
			self::migrate( $from );
		}
	}

	/**
	 * The data each version owes the rows written before it, then the
	 * version: stored last, so a migration that did not finish runs again
	 * (each is safe to repeat).
	 */
	private static function migrate( string $from ): void {
		// Version 4 files each activity row under an organization; rows
		// written before it get one where it can be derived.
		if ( '' !== $from && version_compare( $from, '4', '<' ) ) {
			self::backfillActivityOrgs();
		}
		// Version 5 has no new column. Sign-ins were logged under nobody and
		// moves under where the person is now; both are put right.
		if ( '' !== $from && version_compare( $from, '5', '<' ) ) {
			self::healSignIns();
			self::refileMoves();
		}
		// Version 6 gives secure files a second owner, a project's intake
		// question. dbDelta adds the columns; every row before it is a
		// content file, so there is nothing to backfill.
		// Version 7 makes a support request a conversation: dbDelta adds the
		// thread table, the registry's support owner and a request's last
		// activity, which the requests written before it are given.
		if ( '' !== $from && version_compare( $from, '7', '<' ) ) {
			self::backfillSupportActivity();
		}
		update_option( 'monstera_db_version', MONSTERA_DB_VERSION, true );
	}

	/**
	 * A request written before version 7 last moved when staff resolved it,
	 * or else when its member sent it; staff moved it last unless it is
	 * still open, since only staff could change a status then.
	 */
	public static function backfillSupportActivity(): void {
		global $wpdb;
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
			$wpdb->prepare(
				'UPDATE %i SET last_activity_at = COALESCE(resolved_at, created_at), last_side = IF(status = %s, %s, %s) WHERE last_activity_at IS NULL',
				self::tableName( self::TABLE_SUPPORT_REQUESTS ),
				'open',
				'member',
				'staff'
			)
		);
	}

	/** Sign-ins logged before WordPress had set the current user name the person. */
	public static function healSignIns(): void {
		global $wpdb;
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
			$wpdb->prepare(
				'UPDATE %i SET user_id = object_id WHERE event_type = %s AND object_type = %s AND user_id = 0 AND object_id > 0',
				self::tableName( self::TABLE_ACTIVITY_LOG ),
				'login',
				'user'
			)
		);
	}

	/**
	 * A move is filed under the organization the person went to, which its
	 * context names; the version 4 backfill used where they are now.
	 */
	public static function refileMoves(): void {
		global $wpdb;
		$log = self::tableName( self::TABLE_ACTIVITY_LOG );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, org_id, context FROM %i WHERE event_type = %s AND context IS NOT NULL', $log, 'member_org_changed' ), ARRAY_A );
		foreach ( (array) $rows as $row ) {
			$context = json_decode( (string) $row['context'], true );
			$orgId   = is_array( $context ) ? (int) ( $context['org_id'] ?? 0 ) : 0;
			if ( $orgId > 0 && (int) $row['org_id'] !== $orgId ) {
				$wpdb->update( $log, [ 'org_id' => $orgId ], [ 'id' => (int) $row['id'] ], [ '%d' ], [ '%d' ] );
			}
		}
		// phpcs:enable
	}

	/**
	 * Fills activity_log.org_id where it is empty and derivable: an
	 * organization row is its own; a row about a person takes that person's
	 * organization; any other row takes the organization of whoever acted.
	 */
	public static function backfillActivityOrgs(): void {
		global $wpdb;
		$log  = self::tableName( self::TABLE_ACTIVITY_LOG );
		$meta = $wpdb->usermeta;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET org_id = object_id WHERE org_id IS NULL AND object_type = %s AND object_id > 0', $log, 'org' ) );
		$wpdb->query(
			$wpdb->prepare(
				'UPDATE %i a JOIN %i m ON m.user_id = a.object_id AND m.meta_key = %s SET a.org_id = m.meta_value WHERE a.org_id IS NULL AND a.object_type = %s AND a.object_id > 0 AND m.meta_value > 0',
				$log,
				$meta,
				'monstera_associated_org',
				'user'
			)
		);
		$wpdb->query(
			$wpdb->prepare(
				'UPDATE %i a JOIN %i m ON m.user_id = a.user_id AND m.meta_key = %s SET a.org_id = m.meta_value WHERE a.org_id IS NULL AND a.object_type NOT IN (%s, %s) AND a.user_id > 0 AND m.meta_value > 0',
				$log,
				$meta,
				'monstera_associated_org',
				'org',
				'user'
			)
		);
		// phpcs:enable
	}
}
