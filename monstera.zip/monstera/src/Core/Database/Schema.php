<?php
/**
 * dbDelta-driven schema migrations.
 *
 * Each migration is a versioned set of CREATE TABLE statements (dbDelta is
 * idempotent and will ALTER existing tables to match). The current DB version
 * is stored in the monstera_db_version option; missing migrations run on
 * activation and on plugins_loaded (defensively, when a code update raises
 * the version mid-flight).
 */

declare(strict_types=1);

namespace Monstera\Core\Database;

defined( 'ABSPATH' ) || exit;

final class Schema {

	public const TABLE_SUBGROUP_MEMBERS  = 'monstera_subgroup_members';
	public const TABLE_CONTENT_SUBGROUPS = 'monstera_content_subgroups';
	public const TABLE_SECURE_FILES      = 'monstera_secure_files';
	public const TABLE_NOTIFICATION_LOG  = 'monstera_notification_log';
	public const TABLE_ACTIVITY_LOG      = 'monstera_activity_log';
	public const TABLE_PROJECT_MEMBERS   = 'monstera_project_members';
	public const TABLE_CONTENT_PROJECTS  = 'monstera_content_projects';
	public const TABLE_PROJECT_INTAKE    = 'monstera_project_intake';
	public const TABLE_SUPPORT_REQUESTS  = 'monstera_support_requests';
	public const TABLE_SUPPORT_MESSAGES  = 'monstera_support_messages';
	public const TABLE_ALERT_DISMISSALS  = 'monstera_alert_dismissals';
	public const TABLE_ORG_MEMBERS       = 'monstera_org_members';
	public const TABLE_FORM_SUBMISSIONS  = 'monstera_form_submissions';

	/** @var list<string> Every custom table key, in creation order. */
	public const TABLES = [
		self::TABLE_SUBGROUP_MEMBERS,
		self::TABLE_CONTENT_SUBGROUPS,
		self::TABLE_SECURE_FILES,
		self::TABLE_NOTIFICATION_LOG,
		self::TABLE_ACTIVITY_LOG,
		self::TABLE_PROJECT_MEMBERS,
		self::TABLE_CONTENT_PROJECTS,
		self::TABLE_PROJECT_INTAKE,
		self::TABLE_SUPPORT_REQUESTS,
		self::TABLE_SUPPORT_MESSAGES,
		self::TABLE_ALERT_DISMISSALS,
		self::TABLE_ORG_MEMBERS,
		self::TABLE_FORM_SUBMISSIONS,
	];

	public static function tableName( string $key ): string {
		global $wpdb;
		return $wpdb->prefix . $key;
	}

	/**
	 * Every table brought to its statement: dbDelta creates what is missing
	 * and alters what differs. What it answers is what it changed, one line
	 * per column, key or table, so a sync of a site already at the current
	 * version answers nothing (SchemaDefaultsTest holds it to that). Until
	 * version 11 the column types were written in capitals, and dbDelta
	 * compares a type with what the server reports (`bigint(20) unsigned`)
	 * letter for letter, so every version change re-issued an ALTER for
	 * every column of every table; the types are lowercase now, as the
	 * dbDelta rules ask.
	 *
	 * @return array<string, string> dbDelta's report of what it changed.
	 */
	public static function sync(): array {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$changed = [];
		foreach ( self::statements() as $sql ) {
			$changed += (array) dbDelta( $sql );
		}
		return $changed;
	}

	/**
	 * The CREATE TABLE statement of every table, in creation order.
	 *
	 * Timestamp columns carry no default (version 11): every writer sets
	 * its own in UTC (`current_time( 'mysql', true )`), as every reader
	 * takes it (TimestampWritersGuardTest), so the database's clock, in
	 * whatever zone the server keeps, never stamps a row.
	 *
	 * @return list<string>
	 */
	public static function statements(): array {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		return [
			"CREATE TABLE {$wpdb->prefix}monstera_subgroup_members (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				subgroup_id bigint(20) unsigned NOT NULL,
				member_id bigint(20) unsigned NOT NULL,
				role_in_group varchar(64) NOT NULL DEFAULT '',
				joined_on date NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY subgroup_member (subgroup_id, member_id),
				KEY member_id (member_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_content_subgroups (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				content_id bigint(20) unsigned NOT NULL,
				subgroup_id bigint(20) unsigned NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY content_subgroup (content_id, subgroup_id),
				KEY subgroup_id (subgroup_id)
			) {$charset_collate};",

			// A file belongs to a content item (content_id > 0), or from
			// version 6 to a project's intake question (content_id 0 with
			// project_id and field_key), or from version 7 to a support
			// request (content_id 0 with support_request_id, and the message
			// it came with; none for the opening message), or from version
			// 12 to a form submission's file question (content_id 0 with
			// submission_id and field_key). Never two of them.
			"CREATE TABLE {$wpdb->prefix}monstera_secure_files (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				content_id bigint(20) unsigned NOT NULL,
				project_id bigint(20) unsigned NULL DEFAULT NULL,
				field_key varchar(128) NULL DEFAULT NULL,
				uploaded_by bigint(20) unsigned NULL DEFAULT NULL,
				support_request_id bigint(20) unsigned NULL DEFAULT NULL,
				support_message_id bigint(20) unsigned NULL DEFAULT NULL,
				submission_id bigint(20) unsigned NULL DEFAULT NULL,
				storage_path varchar(512) NOT NULL,
				original_name varchar(255) NOT NULL DEFAULT '',
				filesize bigint(20) unsigned NOT NULL DEFAULT 0,
				mime_type varchar(128) NOT NULL DEFAULT '',
				sha256 char(64) NOT NULL DEFAULT '',
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY content_id (content_id),
				KEY project_question (project_id, field_key),
				KEY support_request (support_request_id),
				KEY submission_question (submission_id, field_key),
				KEY uploaded_by (uploaded_by)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_notification_log (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				member_id bigint(20) unsigned NOT NULL,
				content_id bigint(20) unsigned NULL DEFAULT NULL,
				event_type varchar(64) NOT NULL,
				channel varchar(32) NOT NULL DEFAULT 'email',
				delivered tinyint(1) NULL DEFAULT NULL,
				sent_at datetime NOT NULL,
				meta longtext NULL,
				PRIMARY KEY  (id),
				KEY member_id (member_id),
				KEY event_lookup (event_type, content_id, member_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_activity_log (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NULL DEFAULT NULL,
				event_type varchar(64) NOT NULL,
				object_type varchar(64) NOT NULL DEFAULT '',
				object_id bigint(20) unsigned NULL DEFAULT NULL,
				org_id bigint(20) unsigned NULL DEFAULT NULL,
				occurred_at datetime NOT NULL,
				ip_hash char(64) NOT NULL DEFAULT '',
				context longtext NULL,
				PRIMARY KEY  (id),
				KEY user_id (user_id),
				KEY org_id (org_id),
				KEY object_lookup (object_type, object_id),
				KEY occurred_at (occurred_at),
				KEY event_type (event_type)
			) {$charset_collate};",

			// The client's people on a project. Its two named people, the lead
			// and the client contact, live in the project's meta (People-model
			// track, FR4); the role column that once sat here, which nothing
			// read, went in version 9.
			"CREATE TABLE {$wpdb->prefix}monstera_project_members (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				project_id bigint(20) unsigned NOT NULL,
				member_id bigint(20) unsigned NOT NULL,
				joined_on date NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY project_member (project_id, member_id),
				KEY member_id (member_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_content_projects (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				content_id bigint(20) unsigned NOT NULL,
				project_id bigint(20) unsigned NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY content_project (content_id, project_id),
				KEY project_id (project_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_project_intake (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				project_id bigint(20) unsigned NOT NULL,
				field_key varchar(128) NOT NULL,
				field_value longtext NULL,
				submitted_by bigint(20) unsigned NULL DEFAULT NULL,
				submitted_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY project_field (project_id, field_key),
				KEY project_id (project_id),
				KEY submitted_by (submitted_by)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_support_requests (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				ref char(8) NOT NULL,
				member_id bigint(20) unsigned NULL DEFAULT NULL,
				org_id bigint(20) unsigned NULL DEFAULT NULL,
				project_id bigint(20) unsigned NULL DEFAULT NULL,
				subject varchar(255) NOT NULL,
				body longtext NOT NULL,
				priority varchar(16) NOT NULL DEFAULT 'normal',
				status varchar(16) NOT NULL DEFAULT 'open',
				attachment_id bigint(20) unsigned NULL DEFAULT NULL,
				created_at datetime NOT NULL,
				resolved_at datetime NULL DEFAULT NULL,
				last_activity_at datetime NULL DEFAULT NULL,
				last_side varchar(16) NOT NULL DEFAULT 'member',
				PRIMARY KEY  (id),
				UNIQUE KEY ref_unique (ref),
				KEY member_id (member_id),
				KEY status (status),
				KEY last_activity (last_activity_at)
			) {$charset_collate};",

			// A request's thread after its opening message: what each side
			// wrote (kind message) and what changed (kind event, its type,
			// old and new value and cause as JSON in event_data).
			"CREATE TABLE {$wpdb->prefix}monstera_support_messages (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				request_id bigint(20) unsigned NOT NULL,
				kind varchar(16) NOT NULL DEFAULT 'message',
				author_id bigint(20) unsigned NULL DEFAULT NULL,
				side varchar(16) NOT NULL DEFAULT 'member',
				body longtext NULL,
				event_data text NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY request_thread (request_id, created_at),
				KEY author_id (author_id)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}monstera_alert_dismissals (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				alert_id bigint(20) unsigned NOT NULL,
				member_id bigint(20) unsigned NOT NULL,
				dismissed_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY alert_member (alert_id, member_id)
			) {$charset_collate};",

			// Who belongs where, from version 8. A row is a membership with a
			// tier (role admin, manager or member) or a staff assignment (role
			// staff), never both, one per person and organization. It replaces
			// the associated-org user meta key, which named a person's single
			// organization. Version 8 backfills nothing from that key: the
			// plugin is alpha, nothing runs it beyond the owner's sites, and a
			// site at an older version is reset instead.
			"CREATE TABLE {$wpdb->prefix}monstera_org_members (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				org_id bigint(20) unsigned NOT NULL,
				role varchar(16) NOT NULL DEFAULT 'member',
				created_at datetime NOT NULL,
				created_by bigint(20) unsigned NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY user_org (user_id, org_id),
				KEY org_role (org_id, role),
				KEY user_id (user_id)
			) {$charset_collate};",

			// Version 12 (Forms-and-resources track): what a member sent a
			// built form, the answers as JSON keyed by question key (a file
			// question's value is the list of its secure-file ids), under the
			// organization the form reached them through (0 for a member of
			// none), stamped by the writer in UTC. Version 13 (the track's
			// review) adds user_id alone, which an account's deletion asks by.
			"CREATE TABLE {$wpdb->prefix}monstera_form_submissions (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				form_id bigint(20) unsigned NOT NULL,
				user_id bigint(20) unsigned NOT NULL,
				org_id bigint(20) unsigned NOT NULL DEFAULT 0,
				answers longtext NOT NULL,
				submitted_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY form_id (form_id),
				KEY form_user (form_id, user_id),
				KEY user_id (user_id)
			) {$charset_collate};",
		];
	}

	/**
	 * Activation: the tables, then whatever the stored version still owes.
	 * It takes the upgrade's path, so a site reactivated on an older schema
	 * gets its backfills too (dbDelta is safe to repeat).
	 */
	public static function install(): void {
		$from = (string) get_option( 'monstera_db_version' );
		self::sync();
		self::migrate( $from );
	}

	/**
	 * Hooked to init, so the first request after an update upgrades, a
	 * portal request as much as wp-admin (an insert into a table missing a
	 * new column fails silently until then). The version is autoloaded:
	 * the check costs no query.
	 */
	public static function maybeUpgrade(): void {
		$from = (string) get_option( 'monstera_db_version' );
		if ( MONSTERA_DB_VERSION !== $from ) {
			self::sync();
			self::migrate( $from );
		}
	}

	/**
	 * The data each version owes the rows written before it, then the
	 * version: stored last, so a migration that did not finish runs again
	 * (each is safe to repeat).
	 */
	private static function migrate( string $from ): void {
		// Version 4 files each activity row under an organization; rows
		// written before it get one where it can be derived.
		if ( '' !== $from && version_compare( $from, '4', '<' ) ) {
			self::backfillActivityOrgs();
		}
		// Version 5 has no new column. Sign-ins were logged under nobody and
		// moves under where the person is now; both are put right.
		if ( '' !== $from && version_compare( $from, '5', '<' ) ) {
			self::healSignIns();
			self::refileMoves();
		}
		// Version 6 gives secure files a second owner, a project's intake
		// question. dbDelta adds the columns; every row before it is a
		// content file, so there is nothing to backfill.
		// Version 7 makes a support request a conversation: dbDelta adds the
		// thread table, the registry's support owner and a request's last
		// activity, which the requests written before it are given.
		if ( '' !== $from && version_compare( $from, '7', '<' ) ) {
			self::backfillSupportActivity();
		}
		// Version 8 moves who belongs where out of user meta into the
		// memberships table. dbDelta creates it; nothing is backfilled, since
		// the plugin is alpha and every site that runs it is built from
		// nothing (a site at 7 is reset, not upgraded).
		// Version 9 drops role_in_project from the project members table,
		// which nothing read. dbDelta adds columns and never drops one, so the
		// step is its own, and there is no data to carry. Not gated on the
		// version: a table left from an older site keeps the column though the
		// option is gone (the test library reinstalls WordPress and leaves the
		// tables it does not know), and a site built at 9 is left alone.
		// Version 10 indexes the three columns the invitation's use check
		// scans before an invited account is removed
		// (Members\Provisioning::usedBeyondInvitation()): who wrote a support
		// message, who answered a discovery question, who uploaded a secure
		// file. dbDelta adds a key it finds missing; there is no data to carry.
		// Version 11 (Review-leftovers track, 2026-10-22) changes no row: the
		// column types are written in lowercase, so dbDelta stops re-issuing
		// an ALTER for every column on every version change, and the eight
		// timestamp columns lose a default no writer used (dbDelta leaves an
		// existing default in place, which the alpha reset rule covers).
		// Version 12 (Forms-and-resources track, 2026-10-26) adds the form
		// submissions table and the registry's fourth owner, a submission's
		// file question. dbDelta adds both; no row before it is a submission,
		// so there is nothing to backfill (alpha: a site at 11 is reset).
		self::dropProjectMemberRole();
		update_option( 'monstera_db_version', MONSTERA_DB_VERSION, true );
	}

	/**
	 * Drops the project members table's role column where a site still has
	 * it. Safe to repeat: a table without the column is left alone.
	 */
	public static function dropProjectMemberRole(): void {
		global $wpdb;
		$table = self::tableName( self::TABLE_PROJECT_MEMBERS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- a one-off migration on Monstera's own table.
		// The columns are listed whole and searched here, not with LIKE: the
		// SQLite driver behind wp-now and the Playground demos answers SHOW
		// COLUMNS with every column whatever the LIKE says, which would make a
		// fresh table look as if it still had the one to drop.
		$columns = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $table ) );
		if ( in_array( 'role_in_project', $columns, true ) ) {
			$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i DROP COLUMN role_in_project', $table ) );
		}
		// phpcs:enable
	}

	/**
	 * A request written before version 7 last moved when staff resolved it,
	 * or else when its member sent it; staff moved it last unless it is
	 * still open, since only staff could change a status then.
	 */
	public static function backfillSupportActivity(): void {
		global $wpdb;
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
			$wpdb->prepare(
				'UPDATE %i SET last_activity_at = COALESCE(resolved_at, created_at), last_side = IF(status = %s, %s, %s) WHERE last_activity_at IS NULL',
				self::tableName( self::TABLE_SUPPORT_REQUESTS ),
				'open',
				'member',
				'staff'
			)
		);
	}

	/** Sign-ins logged before WordPress had set the current user name the person. */
	public static function healSignIns(): void {
		global $wpdb;
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
			$wpdb->prepare(
				'UPDATE %i SET user_id = object_id WHERE event_type = %s AND object_type = %s AND user_id = 0 AND object_id > 0',
				self::tableName( self::TABLE_ACTIVITY_LOG ),
				'login',
				'user'
			)
		);
	}

	/**
	 * A move is filed under the organization the person went to, which its
	 * context names; the version 4 backfill used where they are now.
	 */
	public static function refileMoves(): void {
		global $wpdb;
		$log = self::tableName( self::TABLE_ACTIVITY_LOG );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, org_id, context FROM %i WHERE event_type = %s AND context IS NOT NULL', $log, 'member_org_changed' ), ARRAY_A );
		foreach ( (array) $rows as $row ) {
			$context = json_decode( (string) $row['context'], true );
			$orgId   = is_array( $context ) ? (int) ( $context['org_id'] ?? 0 ) : 0;
			if ( $orgId > 0 && (int) $row['org_id'] !== $orgId ) {
				$wpdb->update( $log, [ 'org_id' => $orgId ], [ 'id' => (int) $row['id'] ], [ '%d' ], [ '%d' ] );
			}
		}
		// phpcs:enable
	}

	/**
	 * Fills activity_log.org_id where it is empty and derivable: an
	 * organization row is its own. Rows about people, and rows by whoever
	 * acted, could be filed by the person's associated-org meta key until
	 * version 8 removed it; those joins went with it, and such rows are
	 * left empty.
	 */
	public static function backfillActivityOrgs(): void {
		global $wpdb;
		$log = self::tableName( self::TABLE_ACTIVITY_LOG );
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a one-off migration on Monstera's own table.
			$wpdb->prepare( 'UPDATE %i SET org_id = object_id WHERE org_id IS NULL AND object_type = %s AND object_id > 0', $log, 'org' )
		);
	}
}
