<?php
/**
 * Renders Monstera's inline SVG icon set.
 *
 * Templates call Icons::render('leaf') instead of inlining SVG paths inline,
 * keeping markup readable and the icon catalog auditable. All icons use
 * currentColor and stroke-width 1.5 unless otherwise documented.
 */

declare(strict_types=1);

namespace Monstera\Core;

defined( 'ABSPATH' ) || exit;

final class Icons {

	/**
	 * Render an inline SVG icon.
	 *
	 * @param string $name   Icon name from the catalog.
	 * @param int    $size   Pixel size; defaults to 20.
	 * @param string $label  Accessible name; omit for decorative usage.
	 */
	public static function render( string $name, int $size = 20, string $label = '' ): string {
		$path = self::path( $name );
		if ( ! $path ) {
			return '';
		}
		$attrs  = sprintf(
			'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="%1$d" height="%1$d" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"',
			$size
		);
		$attrs .= '' === $label
			? ' aria-hidden="true"'
			: sprintf( ' role="img" aria-label="%s"', esc_attr( $label ) );

		return sprintf( '<svg %s>%s</svg>', $attrs, $path );
	}

	public static function emit( string $name, int $size = 20, string $label = '' ): void {
		echo self::render( $name, $size, $label ); // phpcs:ignore WordPress.Security.EscapeOutput -- render() escapes its attributes; the SVG body is a constant from the catalog.
	}

	/**
	 * Echo the empty-state sprig illustration, a static SVG bundled with the plugin.
	 */
	public static function sprig(): void {
		$path = MONSTERA_DIR . 'assets/images/monstera-sprig.svg';
		if ( is_file( $path ) ) {
			readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- bundled static asset echoed as-is.
		}
	}

	private static function path( string $name ): string {
		return match ( $name ) {
			// The admin rail's set (comp 90), one distinct mark per page.
			'rail-dashboard'     => '<path d="M3 3h6v6H3zM11 3h6v6h-6zM3 11h6v6H3zM11 11h6v6h-6z"/>',
			'rail-organizations' => '<path d="M3 17V5l7-2v14M10 17V9l7-2v10M6 8h1M6 11h1M13 11h1M13 14h1"/>',
			'rail-members'       => '<path d="M7 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM2 17c0-3 2-5 5-5s5 2 5 5M13 4a3 3 0 0 1 0 6M14 12c2.5 0 4 2 4 5"/>',
			'rail-content'       => '<path d="M5 3h7l3 3v11H5zM12 3v3h3M8 10h4M8 13h4"/>',
			'rail-subgroups'     => '<path d="M10 4v4M10 8 5 12M10 8l5 4M5 12v4M15 12v4M3 16h4M13 16h4M8 4h4"/>',
			'rail-projects'      => '<path d="M3 4h4v12H3zM8 4h4v8H8zM13 4h4v5h-4z"/>',
			'rail-forms'         => '<path d="M6 4h8v13H6zM8 3h4v2H8zM8 9h4M8 12h4"/>',
			'rail-alerts'        => '<path d="M5 14V9a5 5 0 0 1 10 0v5l1 2H4zM8 17a2 2 0 0 0 4 0"/>',
			'rail-support'       => '<path d="M4 4h12v9H9l-4 3v-3H4zM7 8h6M7 10.5h4"/>',
			'rail-reports'       => '<path d="M3 17h14M5 14V9M9 14V5M13 14v-3M17 14V7"/>',
			'rail-settings'      => '<path d="M4 6h12M4 10h12M4 14h12M7 4v4M13 8v4M9 12v4"/>',
			'rail-tools'         => '<path d="M13 3a4 4 0 0 0-4 5L3 14l3 3 6-6a4 4 0 0 0 5-4l-2 2-2-2 2-2z"/>',
			'rail-help'          => '<path d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM8 8a2 2 0 1 1 3 1.7c-.7.4-1 .8-1 1.3M10 14h0"/>',
			'rail-portal'        => '<path d="M10 3v3M10 14v3M3 10h3M14 10h3"/><circle cx="10" cy="10" r="3"/>',
			'leaf'      => '<path d="M10 1.5c4.6 0 8 3.4 8 8 0 3.1-1.6 5.7-4 7.1.9-.3 1.6-1 2.5-1.8L15.6 17c-1.2 1.5-3 2.4-5 2.4-2.2 0-4-1-5-3-.6-1.1-.6-2.3 0-3-2.5-.6-4-2.6-4-5C1.6 4.7 5 1.5 10 1.5Z"/>',

			'home'      => '<path d="M3 9.5 10 3l7 6.5V17a1 1 0 0 1-1 1h-3v-5h-6v5H4a1 1 0 0 1-1-1Z"/>',
			'organization' => '<path d="M3 17V5a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v12"/><path d="M13 9h3a1 1 0 0 1 1 1v7"/><path d="M3 17h14"/><path d="M6 7h3M6 10h3M6 13h3"/>',
			'people'    => '<circle cx="7" cy="7" r="3"/><circle cx="14" cy="8" r="2.2"/><path d="M2 17v-1.5C2 13.6 4.2 12 7 12s5 1.6 5 3.5V17"/><path d="M12 17v-1.2c0-1.4 1.4-2.5 3-2.5s3 1.1 3 2.5V17"/>',
			'content'   => '<rect x="3" y="2.5" width="14" height="15" rx="1.5"/><path d="M6 6h8M6 9.5h8M6 13h5"/>',
			'subgroup'  => '<circle cx="6" cy="6" r="2.5"/><circle cx="14" cy="6" r="2.5"/><circle cx="10" cy="14" r="2.5"/><path d="M7.6 7.7 9 12M12.4 7.7 11 12"/>',
			'forms'     => '<rect x="3" y="3" width="14" height="14" rx="1.5"/><path d="M6 7h8M6 10h8M6 13h5"/>',
			'reports'   => '<path d="M3 17V3M17 17H3"/><rect x="6" y="11" width="2.5" height="6"/><rect x="10" y="7" width="2.5" height="10"/><rect x="14" y="9" width="2.5" height="8"/>',
			'settings'  => '<circle cx="10" cy="10" r="2.5"/><path d="M10 2v2.5M10 15.5V18M3.5 6.5l2 1M14.5 12.5l2 1M3.5 13.5l2-1M14.5 7.5l2-1M2 10h2.5M15.5 10H18"/>',
			'tools'     => '<path d="M11.5 3 8 6.5 11 10l-3 3 4 4 6-6-4-4 1.5-1.5L13 3z"/>',
			'help'      => '<circle cx="10" cy="10" r="7.5"/><path d="M8 8a2 2 0 1 1 3 1.7c-.7.4-1 .8-1 1.5v.3"/><path d="M10 14v.5"/>',

			'search'    => '<circle cx="9" cy="9" r="5"/><path d="m13 13 4 4"/>',
			'plus'      => '<path d="M10 4v12M4 10h12"/>',
			'check'     => '<path d="m4 10 4 4 8-9"/>',
			'x'         => '<path d="M5 5l10 10M15 5 5 15"/>',
			'chevron-right' => '<path d="m8 5 5 5-5 5"/>',
			'chevron-down'  => '<path d="m5 8 5 5 5-5"/>',
			'download'  => '<path d="M10 3v10M5 9l5 5 5-5M3 17h14"/>',
			'eye'       => '<path d="M1.5 10S4 4.5 10 4.5 18.5 10 18.5 10 16 15.5 10 15.5 1.5 10 1.5 10Z"/><circle cx="10" cy="10" r="2.5"/>',
			'eye-off'   => '<path d="m3 3 14 14"/><path d="M6 6.2C3.6 7.7 1.5 10 1.5 10s2.5 5.5 8.5 5.5c1.4 0 2.6-.3 3.6-.8"/><path d="M9 5c2.7-.2 5.5.8 7.5 3 1.4 1.4 2 2 2 2s-.6.8-1.8 2"/>',
			'sun'       => '<circle cx="10" cy="10" r="3"/><path d="M10 2v2.5M10 15.5V18M3.5 3.5 5 5M15 15l1.5 1.5M2 10h2.5M15.5 10H18M3.5 16.5 5 15M15 5l1.5-1.5"/>',
			'moon'      => '<path d="M16.5 11.5A7 7 0 1 1 8.5 3.5a5.5 5.5 0 0 0 8 8Z"/>',
			'mail'      => '<rect x="2.5" y="4.5" width="15" height="11" rx="1.5"/><path d="m2.5 5.5 7.5 5.5 7.5-5.5"/>',
			'calendar'  => '<rect x="3" y="4" width="14" height="13" rx="1.5"/><path d="M3 8h14M7 3v3M13 3v3"/>',
			'bell'      => '<path d="M5 14V9a5 5 0 0 1 10 0v5l1.5 2h-13z"/><path d="M8 17a2 2 0 0 0 4 0"/>',
			'lock'      => '<rect x="4" y="9" width="12" height="9" rx="1.5"/><path d="M7 9V6a3 3 0 0 1 6 0v3"/>',
			'unlock'    => '<rect x="4" y="9" width="12" height="9" rx="1.5"/><path d="M7 9V6a3 3 0 0 1 5.5-1.5"/>',
			'sync'      => '<path d="M3 10a7 7 0 0 1 12-5l2 2"/><path d="M17 4v4h-4"/><path d="M17 10a7 7 0 0 1-12 5l-2-2"/><path d="M3 16v-4h4"/>',
			'upload'    => '<path d="M10 17V7m0 0L5 12m5-5 5 5M3 3h14"/>',
			'menu'      => '<path d="M3 6h14M3 10h14M3 14h14"/>',
			'filter'    => '<path d="M3 4h14l-5.5 7v5l-3 1.5V11Z"/>',
			'org-square' => '<rect x="3" y="3" width="14" height="14" rx="2"/><path d="M7 17v-4h6v4M7 7h2M7 10h2M11 7h2M11 10h2"/>',
			'member-circle' => '<circle cx="10" cy="10" r="7.5"/><circle cx="10" cy="8" r="2.8"/><path d="M4.5 16.5C5.5 13.7 7.5 12 10 12s4.5 1.7 5.5 4.5"/>',
			'leaf-mark' => '<path d="M10 2c4 0 7 3 7 7 0 2.5-1.3 4.6-3.3 5.8.7-.2 1.3-.7 1.8-1.3l-.5 1.5C13.9 16.4 12 17.5 10 17.5c-2 0-3.7-1-4.5-2.6-.5-.9-.5-1.9 0-2.5C3.3 11.7 2 9.8 2 7.5 2 4.5 5 2 10 2Zm-3 3.5C6.4 6.4 6.5 7.6 7 8.4c.8.6 1.9.4 2-.7 0-.9-1-1.7-2-1.2Zm4-.4c-.7.5-.7 1.6 0 2.1 1 0 1.5-1 .8-2-.3-.2-.5-.2-.8-.1Zm-1.6 5C8.3 10.1 8 11 8.4 11.7c.7.8 2.2.4 2.2-.7 0-.5-.7-1-1.2-1Z"/>',
			// Single-stroke sprout: the avatar placeholder (docs/comps/src/_leaf.html).
			'sprout'    => '<path d="M10 17c0-4 1-7 3-9M10 17c-2-3-5-4-6-8 3 0 5 1 6 3M13 8c2-2 4-2 5-1-1 3-3 5-6 5"/>',
			default     => '',
		};
	}

	/**
	 * Base64-encoded data URI for the admin menu icon, used by add_menu_page().
	 */
	public static function adminMenuDataUri(): string {
		$path = MONSTERA_DIR . 'assets/images/admin-menu-icon.svg';
		if ( ! is_file( $path ) ) {
			return '';
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- inlines a bundled SVG as a data URI; local file, not a URL.
		return 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( $path ) );
	}
}
