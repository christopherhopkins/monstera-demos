<?php
/**
 * Central catalogue of every do_action() and apply_filters() Monstera fires.
 *
 * Anything reading this list should be able to find every extension point
 * without grepping. Keep it terse; document parameter shape in HOOKS.md.
 */

declare(strict_types=1);

namespace Monstera\Core;

defined( 'ABSPATH' ) || exit;

final class Hooks {

	// --- Actions -----------------------------------------------------------

	public const ACTIVATED   = 'monstera/activated';
	public const DEACTIVATED = 'monstera/deactivated';
	public const BOOTED      = 'monstera/booted';

	// Render slots in the two shells, for an extension that has something to
	// say above every page (the demo companion's brief band uses both).
	public const ADMIN_SHELL_BEFORE_ROOT     = 'monstera/admin_shell_before_root';
	public const PORTAL_SHELL_BEFORE_NOTICES = 'monstera/portal_shell_before_notices';

	public const ORG_CREATED        = 'monstera/org_created';
	public const ORG_STATUS_CHANGED = 'monstera/org_status_changed';

	public const MEMBER_CREATED     = 'monstera/member_created';
	public const MEMBER_DELETED     = 'monstera/member_deleted';
	public const MEMBER_LOGGED_IN   = 'monstera/member_logged_in';
	public const MEMBER_SUSPENDED   = 'monstera/member_suspended';
	public const MEMBER_REACTIVATED = 'monstera/member_reactivated';

	public const CONTENT_PUBLISHED  = 'monstera/content_published';
	public const CONTENT_UPDATED    = 'monstera/content_updated';
	public const CONTENT_UNLOCKED   = 'monstera/content_unlocked';
	public const CONTENT_DOWNLOADED = 'monstera/content_downloaded';

	public const NOTIFICATION_SENT   = 'monstera/notification_sent';
	public const NOTIFICATION_QUEUED = 'monstera/notification_queued';

	public const SYNC_RUN            = 'monstera/sync_run';
	public const SYNC_TASK_COMPLETED = 'monstera/sync_task_completed';

	public const ACTIVITY_LOGGED = 'monstera/activity_logged';

	public const PROJECT_CREATED          = 'monstera/project_created';
	public const PROJECT_STATUS_CHANGED   = 'monstera/project_status_changed';
	public const PROJECT_INTAKE_SUBMITTED = 'monstera/project_intake_submitted';

	public const ALERT_POSTED    = 'monstera/alert_posted';
	public const ALERT_DISMISSED = 'monstera/alert_dismissed';
	public const ALERT_EXPIRED   = 'monstera/alert_expired';

	public const SUPPORT_REQUEST_CREATED  = 'monstera/support_request_created';
	public const SUPPORT_REQUEST_RESOLVED = 'monstera/support_request_resolved';
	// The conversation: a side's reply (request id, message id, side), a
	// change of status (request id, from, to, who, side, cause: a reply or a
	// choice) and the member's change of priority (request id, from, to, who).
	public const SUPPORT_MESSAGE_ADDED    = 'monstera/support_message_added';
	public const SUPPORT_STATUS_CHANGED   = 'monstera/support_status_changed';
	public const SUPPORT_PRIORITY_CHANGED = 'monstera/support_priority_changed';

	// Org self-service & billing.
	public const MEMBER_REMOVED_FROM_ORG = 'monstera/member_removed_from_org';
	public const MEMBERSHIP_RENEWED      = 'monstera/membership_renewed';
	// Fired by the (separate) Payments module after a successful charge. Context
	// array shape: [ 'type' => 'renewal', 'org_id' => int, 'user_id' => int,
	// 'paid_at' => mysql-utc ]. Organizations\Membership listens and applies the
	// renewal. This is the seam that keeps billing out of the membership core.
	public const PAYMENT_COMPLETED = 'monstera/payment_completed';

	// --- Filters -----------------------------------------------------------

	public const FILTER_CONTENT_LABELS      = 'monstera/content_labels';
	public const FILTER_VISIBILITY_RESULT   = 'monstera/visibility_result';
	public const FILTER_PORTAL_PREFIX       = 'monstera/portal_prefix';
	public const FILTER_DOWNLOAD_LIFETIME   = 'monstera/download_lifetime';
	public const FILTER_NOTIFICATION_TOKENS = 'monstera/notification_tokens';
	public const FILTER_NOTIFICATION_BODY   = 'monstera/notification_body';

	// Projects: whether an intake submission auto-advances the project (bool $advance, int $projectId).
	public const FILTER_AUTO_ADVANCE_AFTER_INTAKE = 'monstera/auto_advance_after_intake';
	// Billing: checkout URL for a renewal, '' when no payment integration is present (string $url, array $context).
	public const FILTER_RENEWAL_CHECKOUT_URL  = 'monstera/renewal_checkout_url';
	public const FILTER_ACTIVE_MODULES        = 'monstera/active_modules';
	public const FILTER_CAPABILITIES_FOR_ROLE = 'monstera/capabilities_for_role';
	public const FILTER_DIRECTORY_QUERY_ARGS  = 'monstera/directory_query_args';
	public const FILTER_REST_NAMESPACE        = 'monstera/rest_namespace';
	public const FILTER_RETENTION_DAYS        = 'monstera/retention_days';

	public const FILTER_USE_CASE           = 'monstera/use_case';
	public const FILTER_PROJECT_STAGES     = 'monstera/project_stages';
	public const FILTER_ALERT_AUDIENCE     = 'monstera/alert_audience';
	public const FILTER_SUPPORT_RECIPIENTS = 'monstera/support_recipients';
	// Who hears that a client submitted discovery (default: the site's
	// admin email); receives the list and the project id.
	public const FILTER_INTAKE_RECIPIENTS = 'monstera/intake_recipients';

	// Secure files (SecureFiles::store(), the content file upload). MOVE
	// returns true or false to handle the move itself (null leaves it to
	// move_uploaded_file(), as core's pre_move_uploaded_file does); MAX_BYTES
	// and TYPES narrow or widen what an upload may be.
	public const FILTER_SECURE_FILE_MOVE      = 'monstera/secure_file_move';
	public const FILTER_SECURE_FILE_MAX_BYTES = 'monstera/secure_file_max_bytes';
	public const FILTER_SECURE_FILE_TYPES     = 'monstera/secure_file_types';

	// Intake files (Projects\IntakeFiles): the largest file a discovery file
	// question takes (default 50 MB, or the server's limit when lower) and
	// how many files one question holds (default 10). Types follow
	// FILTER_SECURE_FILE_TYPES; the move follows FILTER_SECURE_FILE_MOVE.
	public const FILTER_INTAKE_FILE_MAX_BYTES = 'monstera/intake_file_max_bytes';
	public const FILTER_INTAKE_FILE_MAX_COUNT = 'monstera/intake_file_max_count';

	// Support files (Support\Files): the largest file a support message
	// takes (default 10 MB, or the server's limit when lower) and how many
	// files one message carries (default 5). Types and the move follow the
	// secure-file filters above.
	public const FILTER_SUPPORT_FILE_MAX_BYTES = 'monstera/support_file_max_bytes';
	public const FILTER_SUPPORT_FILE_MAX_COUNT = 'monstera/support_file_max_count';

	// How many emails to an audience go with one request (default 50); the
	// rest follow from cron, a minute apart (Notifications\Dispatcher).
	public const FILTER_EMAIL_BATCH_SIZE = 'monstera/email_batch_size';
}
