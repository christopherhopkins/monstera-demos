<?php
/**
 * Role and capability definitions for Monstera.
 *
 * Four roles map onto the four user archetypes from PRODUCT.md. Roles are
 * registered on activation via add_role() and removed on uninstall. CPT
 * capability_type mappings live alongside the relevant PostType registrar.
 */

declare(strict_types=1);

namespace Monstera\Core;

use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

final class Capabilities {

	public const ROLE_ADMIN             = 'monstera_admin';
	public const ROLE_ORG_MANAGER       = 'monstera_org_manager';
	public const ROLE_MEMBER            = 'monstera_member';
	public const ROLE_MEMBER_STANDALONE = 'monstera_member_standalone';

	/**
	 * Bump when the role→cap mapping changes so existing installs re-sync on the
	 * next admin load (see maybeUpgrade()). v2 added CAP_AUTHOR_PORTAL.
	 */
	public const CAPS_VERSION = '2';

	public const CAP_MANAGE_MONSTERA  = 'manage_monstera';
	public const CAP_MANAGE_OWN_ORG   = 'monstera_manage_own_org';
	public const CAP_AUTHOR_PORTAL    = 'monstera_author_portal';
	public const CAP_INVITE_MEMBERS   = 'monstera_invite_members';
	public const CAP_VIEW_DIRECTORY   = 'monstera_view_directory';
	public const CAP_DOWNLOAD_CONTENT = 'monstera_download_content';
	public const CAP_RENEW_OWN        = 'monstera_renew_own';
	public const CAP_VIEW_PROJECTS    = 'monstera_view_projects';
	public const CAP_SUBMIT_INTAKE    = 'monstera_submit_intake';
	public const CAP_SUBMIT_SUPPORT   = 'monstera_submit_support';

	/**
	 * @return array<string, array<string, bool>>
	 */
	public static function definitions(): array {
		return [
			self::ROLE_ADMIN             => [
				'read'                     => true,
				self::CAP_MANAGE_MONSTERA  => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_INVITE_MEMBERS   => true,
				self::CAP_MANAGE_OWN_ORG   => true,
				self::CAP_AUTHOR_PORTAL    => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_INTAKE    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
				'edit_posts'               => true,
				'edit_others_posts'        => true,
				'publish_posts'            => true,
				'delete_posts'             => true,
				'upload_files'             => true,
			],
			self::ROLE_ORG_MANAGER       => [
				'read'                     => true,
				self::CAP_MANAGE_OWN_ORG   => true,
				self::CAP_AUTHOR_PORTAL    => true,
				self::CAP_INVITE_MEMBERS   => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_RENEW_OWN        => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_INTAKE    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
			],
			self::ROLE_MEMBER            => [
				'read'                     => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_INTAKE    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
			],
			self::ROLE_MEMBER_STANDALONE => [
				'read'                     => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_RENEW_OWN        => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
			],
		];
	}

	public static function install(): void {
		foreach ( self::definitions() as $role => $caps ) {
			$caps     = apply_filters( Hooks::FILTER_CAPABILITIES_FOR_ROLE, $caps, $role );
			$existing = get_role( $role );
			if ( ! $existing ) {
				add_role( $role, self::roleLabel( $role ), $caps );
				continue;
			}
			foreach ( $caps as $cap => $grant ) {
				$existing->add_cap( $cap, $grant );
			}
		}

		// Mirror the manage capability onto the WP administrator role for convenience.
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( self::CAP_MANAGE_MONSTERA, true );
		}

		update_option( 'monstera_caps_version', self::CAPS_VERSION, false );
	}

	/**
	 * Re-sync role capabilities after a code update that changed the mapping,
	 * without requiring a deactivate/reactivate. Mirrors Schema::maybeUpgrade();
	 * hooked to admin_init. Roles are global, so the first admin page load after
	 * an update brings every install's org-manager role up to date.
	 */
	public static function maybeUpgrade(): void {
		if ( get_option( 'monstera_caps_version' ) !== self::CAPS_VERSION ) {
			self::install();
		}
	}

	public static function uninstall(): void {
		foreach ( array_keys( self::definitions() ) as $role ) {
			remove_role( $role );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->remove_cap( self::CAP_MANAGE_MONSTERA );
		}
	}

	/**
	 * Dynamic capability grant for sub-group leaders.
	 *
	 * A leader is a plain member appointed via Subgroups\Meta::KEY_LEADER, so the
	 * authoring cap can't be a static role grant. Rather than persist a per-user
	 * cap at appointment time (which would drift if the leader is reassigned from
	 * the admin shell), we resolve it live from the sub-group meta — the single
	 * source of truth — and lean on Repository::leaderSubgroupId()'s per-request
	 * memo to keep it cheap. Hooked to `user_has_cap`.
	 *
	 * @param array<string, bool> $allcaps
	 * @param string[]            $caps
	 * @param array<int, mixed>   $args
	 * @return array<string, bool>
	 */
	public static function grantLeaderCap( array $allcaps, array $caps, array $args, \WP_User $user ): array {
		if ( ! in_array( self::CAP_AUTHOR_PORTAL, $caps, true ) ) {
			return $allcaps;
		}
		if ( ! empty( $allcaps[ self::CAP_AUTHOR_PORTAL ] ) ) {
			return $allcaps; // already granted by role.
		}
		if ( $user->ID > 0 && \Monstera\Subgroups\Repository::leaderSubgroupId( (int) $user->ID ) > 0 ) {
			$allcaps[ self::CAP_AUTHOR_PORTAL ] = true;
		}
		return $allcaps;
	}

	public static function isPortalRole( string $role ): bool {
		return in_array(
			$role,
			[ self::ROLE_ORG_MANAGER, self::ROLE_MEMBER, self::ROLE_MEMBER_STANDALONE ],
			true
		);
	}

	private static function roleLabel( string $role ): string {
		return match ( $role ) {
			self::ROLE_ADMIN             => __( 'Monstera Admin', 'monstera' ),
			self::ROLE_ORG_MANAGER       => __( 'Organization Manager', 'monstera' ),
			self::ROLE_MEMBER            => __( 'Member', 'monstera' ),
			self::ROLE_MEMBER_STANDALONE => __( 'Standalone Member', 'monstera' ),
			default                      => $role,
		};
	}
}
