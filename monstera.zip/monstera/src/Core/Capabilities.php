<?php
/**
 * Role and capability definitions for Monstera.
 *
 * Five roles: the internal team's two (Team manager, Team member) and the
 * three client roles (organization manager, member, standalone member) of
 * product.md's archetypes. Roles are registered on activation via add_role()
 * and removed on uninstall. CPT capability_type mappings live alongside the
 * relevant PostType registrar.
 */

declare(strict_types=1);

namespace Monstera\Core;

use Monstera\Core\Hooks;

defined( 'ABSPATH' ) || exit;

final class Capabilities {

	// The internal team: the Team manager keeps the slug it had when it was
	// the only staff role (People-model track, FR3).
	public const ROLE_ADMIN       = 'monstera_admin';
	public const ROLE_TEAM_MEMBER = 'monstera_team_member';

	// The client roles: a ceiling derived from the person's memberships (see
	// Organizations\Roster::syncRole()).
	public const ROLE_ORG_MANAGER       = 'monstera_org_manager';
	public const ROLE_MEMBER            = 'monstera_member';
	public const ROLE_MEMBER_STANDALONE = 'monstera_member_standalone';

	/**
	 * Bump when the role→cap mapping changes so existing installs re-sync on the
	 * next admin load (see maybeUpgrade()). v2 added CAP_AUTHOR_PORTAL. v3 added
	 * the Team member role, CAP_MANAGE_TEAM and CAP_MANAGE_SETTINGS, and
	 * relabelled the Team manager.
	 */
	public const CAPS_VERSION = '3';

	public const CAP_MANAGE_MONSTERA  = 'manage_monstera';
	public const CAP_MANAGE_TEAM      = 'monstera_manage_team';
	public const CAP_MANAGE_SETTINGS  = 'monstera_manage_settings';
	public const CAP_MANAGE_OWN_ORG   = 'monstera_manage_own_org';
	public const CAP_AUTHOR_PORTAL    = 'monstera_author_portal';
	public const CAP_INVITE_MEMBERS   = 'monstera_invite_members';
	public const CAP_VIEW_DIRECTORY   = 'monstera_view_directory';
	public const CAP_DOWNLOAD_CONTENT = 'monstera_download_content';
	public const CAP_RENEW_OWN        = 'monstera_renew_own';
	public const CAP_VIEW_PROJECTS    = 'monstera_view_projects';
	public const CAP_SUBMIT_INTAKE    = 'monstera_submit_intake';
	public const CAP_SUBMIT_SUPPORT   = 'monstera_submit_support';

	/**
	 * The capabilities only the team's managers hold: the team itself, and
	 * Settings and Tools. A WordPress administrator is mirrored these, with the
	 * manage capability, so they are a Team manager for every purpose.
	 *
	 * @var list<string>
	 */
	private const TEAM_MANAGER_CAPS = [ self::CAP_MANAGE_TEAM, self::CAP_MANAGE_SETTINGS ];

	/** @var list<string> What the WordPress administrator role is given on install and loses on uninstall. */
	private const MIRRORED_CAPS = [ self::CAP_MANAGE_MONSTERA, self::CAP_MANAGE_TEAM, self::CAP_MANAGE_SETTINGS ];

	/**
	 * @return array<string, array<string, bool>>
	 */
	public static function definitions(): array {
		$teamManager = [
			'read'                     => true,
			self::CAP_MANAGE_MONSTERA  => true,
			self::CAP_MANAGE_TEAM      => true,
			self::CAP_MANAGE_SETTINGS  => true,
			self::CAP_VIEW_DIRECTORY   => true,
			self::CAP_DOWNLOAD_CONTENT => true,
			self::CAP_INVITE_MEMBERS   => true,
			self::CAP_MANAGE_OWN_ORG   => true,
			self::CAP_AUTHOR_PORTAL    => true,
			self::CAP_VIEW_PROJECTS    => true,
			self::CAP_SUBMIT_INTAKE    => true,
			self::CAP_SUBMIT_SUPPORT   => true,
			'edit_posts'               => true,
			'edit_others_posts'        => true,
			'publish_posts'            => true,
			'delete_posts'             => true,
			'upload_files'             => true,
		];
		return [
			self::ROLE_ADMIN             => $teamManager,
			// A Team member sees and works in every organization as a Team
			// manager does; only the team and the settings are the manager's.
			self::ROLE_TEAM_MEMBER       => array_diff_key( $teamManager, array_fill_keys( self::TEAM_MANAGER_CAPS, true ) ),
			self::ROLE_ORG_MANAGER       => [
				'read'                     => true,
				self::CAP_MANAGE_OWN_ORG   => true,
				self::CAP_AUTHOR_PORTAL    => true,
				self::CAP_INVITE_MEMBERS   => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_RENEW_OWN        => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_INTAKE    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
			],
			self::ROLE_MEMBER            => [
				'read'                     => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_INTAKE    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
			],
			self::ROLE_MEMBER_STANDALONE => [
				'read'                     => true,
				self::CAP_VIEW_DIRECTORY   => true,
				self::CAP_DOWNLOAD_CONTENT => true,
				self::CAP_RENEW_OWN        => true,
				self::CAP_VIEW_PROJECTS    => true,
				self::CAP_SUBMIT_SUPPORT   => true,
			],
		];
	}

	public static function install(): void {
		foreach ( self::definitions() as $role => $caps ) {
			$caps     = apply_filters( Hooks::FILTER_CAPABILITIES_FOR_ROLE, $caps, $role );
			$existing = get_role( $role );
			if ( ! $existing ) {
				add_role( $role, self::roleLabel( $role ), $caps );
				continue;
			}
			foreach ( $caps as $cap => $grant ) {
				$existing->add_cap( $cap, $grant );
			}
			self::relabel( $role );
		}

		// A WordPress administrator is a Team manager for every purpose.
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( self::MIRRORED_CAPS as $cap ) {
				$admin->add_cap( $cap, true );
			}
		}

		update_option( 'monstera_caps_version', self::CAPS_VERSION, false );

		// The account behind this request read its capabilities from the roles
		// as they were. It reads them again, so what was just granted holds for
		// the rest of the request: the menu is built straight after an upgrade.
		if ( get_current_user_id() > 0 ) {
			wp_get_current_user()->get_role_caps();
		}
	}

	/**
	 * Bring an existing role's display name up to date. add_role() only
	 * creates a role that is missing and WP_Roles has no rename, so the name
	 * is written where add_role() would have put it: the roles table, the
	 * names list and the saved option. Caps version 3 relabelled the Team
	 * manager this way.
	 */
	private static function relabel( string $role ): void {
		$label = self::roleLabel( $role );
		$roles = wp_roles();
		if ( ! isset( $roles->roles[ $role ] ) || ( $roles->roles[ $role ]['name'] ?? null ) === $label ) {
			return;
		}
		$roles->roles[ $role ]['name'] = $label;
		$roles->role_names[ $role ]    = $label;
		if ( $roles->use_db ) {
			update_option( $roles->role_key, $roles->roles );
		}
	}

	/**
	 * Re-sync role capabilities after a code update that changed the mapping,
	 * without requiring a deactivate/reactivate. Mirrors Schema::maybeUpgrade();
	 * hooked to admin_menu, ahead of the menu's own registration, and to
	 * admin_init (see Plugin::boot() for why both). Roles are global, so the
	 * first admin page load after an update brings every install's roles up
	 * to date, in time for that page's own menu.
	 */
	public static function maybeUpgrade(): void {
		if ( get_option( 'monstera_caps_version' ) !== self::CAPS_VERSION ) {
			self::install();
		}
	}

	/**
	 * Remove every role and take the mirrored capabilities back from the
	 * administrator. uninstall.php requires this file by path, with no
	 * autoloader behind it, so this method and definitions() must reach no
	 * other Monstera class (UninstallGuardTest holds uninstall.php to the
	 * call; the class's own lists keep the two from drifting).
	 */
	public static function uninstall(): void {
		foreach ( array_keys( self::definitions() ) as $role ) {
			remove_role( $role );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( self::MIRRORED_CAPS as $cap ) {
				$admin->remove_cap( $cap );
			}
		}
	}

	/**
	 * Dynamic capability grant for sub-group leaders.
	 *
	 * A leader is a plain member appointed via Subgroups\Meta::KEY_LEADER, so the
	 * authoring cap can't be a static role grant. Rather than persist a per-user
	 * cap at appointment time (which would drift if the leader is reassigned from
	 * the admin shell), we resolve it live from the sub-group meta — the single
	 * source of truth — and lean on Repository::leaderSubgroupId()'s per-request
	 * memo to keep it cheap. Hooked to `user_has_cap`.
	 *
	 * @param array<string, bool> $allcaps
	 * @param string[]            $caps
	 * @param array<int, mixed>   $args
	 * @return array<string, bool>
	 */
	public static function grantLeaderCap( array $allcaps, array $caps, array $args, \WP_User $user ): array {
		if ( ! in_array( self::CAP_AUTHOR_PORTAL, $caps, true ) ) {
			return $allcaps;
		}
		if ( ! empty( $allcaps[ self::CAP_AUTHOR_PORTAL ] ) ) {
			return $allcaps; // already granted by role.
		}
		if ( $user->ID > 0 && \Monstera\Subgroups\Repository::leaderSubgroupId( (int) $user->ID ) > 0 ) {
			$allcaps[ self::CAP_AUTHOR_PORTAL ] = true;
		}
		return $allcaps;
	}

	/** The client roles: the people the portal is for. Staff are not among them. */
	public static function isPortalRole( string $role ): bool {
		return in_array(
			$role,
			[ self::ROLE_ORG_MANAGER, self::ROLE_MEMBER, self::ROLE_MEMBER_STANDALONE ],
			true
		);
	}

	/** The internal team's roles: a Team manager or a Team member. */
	public static function isStaffRole( string $role ): bool {
		return in_array( $role, [ self::ROLE_ADMIN, self::ROLE_TEAM_MEMBER ], true );
	}

	/** Whether the account is staff: a staff role, or a WordPress administrator, who is a Team manager for every purpose. */
	public static function isStaff( \WP_User $user ): bool {
		foreach ( (array) $user->roles as $role ) {
			if ( 'administrator' === $role || self::isStaffRole( (string) $role ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The team role an account holds, by its slug: the Team manager's for a
	 * Team manager and for a WordPress administrator, who is one for every
	 * purpose, the Team member's for a Team member, and nothing for an
	 * account that is not staff. The Team page, its routes and the team's
	 * welcome email all name the role from here, so an administrator who
	 * also holds the Team member role reads as a manager everywhere.
	 */
	public static function teamRole( \WP_User $user ): string {
		$held = array_map( 'strval', (array) $user->roles );
		if ( in_array( 'administrator', $held, true ) || in_array( self::ROLE_ADMIN, $held, true ) ) {
			return self::ROLE_ADMIN;
		}
		return in_array( self::ROLE_TEAM_MEMBER, $held, true ) ? self::ROLE_TEAM_MEMBER : '';
	}

	/**
	 * The one role an account is listed under: what the Members list, the
	 * member detail and an organization's roster name. An account can hold
	 * roles that are not Monstera's beside its own (the site's editor, a
	 * shop's customer), and WordPress keeps them in the order they were
	 * given, so the first role is whichever came first, not the one that
	 * says who the person is here. A staff role comes before a client role,
	 * as it wins everywhere else, and a WordPress administrator, a Team
	 * manager for every purpose, before both. An account with none of these
	 * answers its first role, or nothing.
	 */
	public static function listedRole( \WP_User $user ): string {
		$held  = array_map( 'strval', array_values( (array) $user->roles ) );
		$known = array_intersect(
			[ 'administrator', self::ROLE_ADMIN, self::ROLE_TEAM_MEMBER, self::ROLE_ORG_MANAGER, self::ROLE_MEMBER, self::ROLE_MEMBER_STANDALONE ],
			$held
		);
		return (string) ( reset( $known ) ?: ( $held[0] ?? '' ) );
	}

	/** A Monstera role's display name; any other role's slug as it is. */
	public static function roleLabel( string $role ): string {
		return match ( $role ) {
			self::ROLE_ADMIN             => __( 'Team manager', 'monstera' ),
			self::ROLE_TEAM_MEMBER       => __( 'Team member', 'monstera' ),
			self::ROLE_ORG_MANAGER       => __( 'Organization Manager', 'monstera' ),
			self::ROLE_MEMBER            => __( 'Member', 'monstera' ),
			self::ROLE_MEMBER_STANDALONE => __( 'Standalone Member', 'monstera' ),
			default                      => $role,
		};
	}
}
