<?php
/**
 * Contract for every Monstera module (core or optional).
 *
 * Modules register their own hooks, CPTs, REST routes, and assets during
 * boot(). Modules that participate in activation (creating tables, roles,
 * rewrite rules) implement Activatable.
 */

declare(strict_types=1);

namespace Monstera\Core;

interface Module {

	public function slug(): string;

	public function boot(): void;
}
