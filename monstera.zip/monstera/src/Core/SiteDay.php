<?php
declare(strict_types=1);

namespace Monstera\Core;

use DateTimeImmutable;
use DateTimeZone;
use Exception;

defined( 'ABSPATH' ) || exit;

/**
 * Days as the site counts them (the owner, 2026-10-17). A date stored as a
 * day, an organization's or a standalone member's membership expiry above
 * all, is a day on the site's calendar: it is today from the site's
 * midnight to the next, so a membership's last day runs until midnight
 * where the site is, west of UTC as east of it, and a reminder thirty days
 * out is thirty of the site's days. The guard, the daily syncs, the renewal
 * window, the reminders and the admin's renewals count with it, as
 * Portal\CalendarDay prints such days.
 */
final class SiteDay {

	/**
	 * The site's today, as Y-m-d: read from the clock, not through
	 * wp_date(), whose filter a calendar plugin may turn to another
	 * calendar or another script's digits.
	 */
	public static function today(): string {
		return ( new DateTimeImmutable( 'now', wp_timezone() ) )->format( 'Y-m-d' );
	}

	/** Whether a value names a day on the calendar, written Y-m-d (\z: a $ would let a final newline through). */
	public static function isDay( string $value ): bool {
		return 1 === preg_match( '/^(\d{4})-(\d{2})-(\d{2})\z/', $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * A stored day as Y-m-d, or '' for a value that names no day. A day on
	 * the calendar is as written; anything else, an impossible day
	 * ("2026-04-31") included, is what strtotime() makes of it, as a day in
	 * UTC, as the repository reads a next step's date.
	 */
	public static function ymd( string $value ): string {
		$value = trim( $value );
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return $value;
		}
		$ts = '' !== $value ? strtotime( $value ) : false;
		return false === $ts ? '' : gmdate( 'Y-m-d', $ts );
	}

	/**
	 * How many of the site's days have gone by since the day: 0 on the day
	 * itself, 1 the day after, negative before it; null for a value that
	 * names no day. A run over many (the daily syncs) reads today once
	 * and passes it, so a run across the site's midnight counts one day.
	 *
	 * @param string $today The site's today as Y-m-d; read now when ''.
	 */
	public static function daysSince( string $value, string $today = '' ): ?int {
		$day = self::ymd( $value );
		if ( '' === $day ) {
			return null;
		}
		$utc = new DateTimeZone( 'UTC' );
		try {
			return (int) ( new DateTimeImmutable( $day, $utc ) )->diff( new DateTimeImmutable( '' !== $today ? $today : self::today(), $utc ) )->format( '%r%a' );
		} catch ( Exception ) {
			return null;
		}
	}

	/** Whether the day lies in the past on the site: it ended at the site's last midnight or before. */
	public static function hasPassed( string $value ): bool {
		$days = self::daysSince( $value );
		return null !== $days && $days > 0;
	}

	/** The site's day a year after a moment (a payment, now), as Y-m-d. */
	public static function yearAfter( int $timestamp ): string {
		return ( new DateTimeImmutable( '@' . $timestamp ) )->setTimezone( wp_timezone() )->modify( '+1 year' )->format( 'Y-m-d' );
	}
}
