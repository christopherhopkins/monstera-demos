<?php
/**
 * Manages the secure-file storage root at /wp-content/uploads/mp-secure/.
 *
 * - Creates the directory on activation
 * - Writes the .htaccess deny rule for Apache
 * - Detects nginx and surfaces a deploy notice pointing at docs/NGINX.md
 * - Writes a defensive index.html so directory listings 404 cleanly
 */

declare(strict_types=1);

namespace Monstera\Core;

final class SecureStorage {

	private const DIR_NAME = 'mp-secure';

	public static function rootPath(): string {
		$uploads = wp_upload_dir();
		return trailingslashit( $uploads['basedir'] ) . self::DIR_NAME;
	}

	/** The option the daily sync writes the folder's size into. */
	public const USAGE_OPTION = 'monstera_secure_usage';

	/**
	 * Measures the secure folder (every file beneath it) and caches the
	 * total, so the dashboard's health row never walks the disk on a page
	 * load. Run by the daily sync.
	 */
	public static function measure(): void {
		update_option(
			self::USAGE_OPTION,
			[
				'bytes' => self::bytesIn( self::rootPath() ),
				'at'    => time(),
			],
			false
		);
	}

	/**
	 * The size of every file beneath a folder. Each folder is listed whole
	 * before its sub-folders are entered: PHP's recursive iterator, which
	 * keeps the parent open while it descends, returned 1 of 14 files on a
	 * mounted uploads folder once it held many entries. A folder that
	 * cannot be read counts as empty, so the daily sync never stops here.
	 */
	private static function bytesIn( string $dir ): int {
		$entries = is_dir( $dir ) && is_readable( $dir ) ? scandir( $dir ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_readable -- the plugin's own folder under uploads; no WP_Filesystem credentials in a cron run.
		if ( false === $entries ) {
			return 0;
		}
		$bytes = 0;
		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}
			$path = $dir . '/' . $entry;
			if ( is_dir( $path ) ) {
				$bytes += is_link( $path ) ? 0 : self::bytesIn( $path );
			} elseif ( is_file( $path ) ) {
				$bytes += (int) filesize( $path );
			}
		}
		return $bytes;
	}

	/**
	 * The last measurement, or null before the first daily sync.
	 *
	 * @return array{bytes: int, at: int}|null
	 */
	public static function usage(): ?array {
		$usage = get_option( self::USAGE_OPTION );
		return is_array( $usage ) && isset( $usage['bytes'], $usage['at'] )
			? [
				'bytes' => (int) $usage['bytes'],
				'at'    => (int) $usage['at'],
			]
			: null;
	}

	/** The deny file install() writes is in place (Apache; nginx uses docs/NGINX.md). */
	public static function isProtected(): bool {
		return file_exists( self::rootPath() . '/.htaccess' );
	}

	public static function orgPath( string $orgSlug ): string {
		return self::rootPath() . '/' . sanitize_file_name( $orgSlug );
	}

	public static function install(): void {
		$root = self::rootPath();
		if ( ! file_exists( $root ) ) {
			// Suppress notices on read-only filesystems (e.g. wp-now WASM).
			@wp_mkdir_p( $root ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- best-effort directory creation; the health check reports a missing directory.
		}

		// If we can't write here, skip the optional defense-in-depth files.
		// Downloads still go through the signed-URL /portal/download/ handler,
		// which re-validates the session and re-runs the visibility rules.
		if ( ! is_dir( $root ) || ! is_writable( $root ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- local uploads dir; no WP_Filesystem credentials at activation.
			return;
		}

		// .htaccess deny — applies on Apache servers; nginx ignores it but harmless.
		$htaccess = $root . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			$rules = "# Monstera: deny direct access; files served via /portal/download/ handler.\n"
				. "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n"
				. "<IfModule !mod_authz_core.c>\n  Order deny,allow\n  Deny from all\n</IfModule>\n";
			@file_put_contents( $htaccess, $rules ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPressVIPMinimum.Functions.RestrictedFunctions -- best-effort hardening file; a read-only uploads dir must not fatal, the health check reports it.
		}

		$index = $root . '/index.html';
		if ( ! file_exists( $index ) ) {
			@file_put_contents( $index, '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPressVIPMinimum.Functions.RestrictedFunctions -- best-effort hardening file; a read-only uploads dir must not fatal, the health check reports it.
		}
	}
}
