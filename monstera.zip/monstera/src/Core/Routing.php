<?php
/**
 * Portal URL routing.
 *
 * Registers rewrite rules under /portal/* and exposes named routes for
 * template_redirect handling. The actual page rendering lives in Portal\Router.
 */

declare(strict_types=1);

namespace Monstera\Core;

final class Routing {

	public const QUERY_VAR = 'monstera_portal_route';
	public const PARAM_ORG = 'monstera_org_slug';
	public const PARAM_ID  = 'monstera_id';

	public const ROUTE_DASHBOARD = 'dashboard';
	public const ROUTE_ORG       = 'org';
	public const ROUTE_PROFILE   = 'profile';
	public const ROUTE_CONTENT   = 'content';
	public const ROUTE_DIRECTORY = 'directory';
	public const ROUTE_FORMS     = 'forms';
	public const ROUTE_FORM_OPEN = 'form-open';
	public const ROUTE_DOWNLOAD  = 'download';
	public const ROUTE_PROJECTS  = 'projects';
	public const ROUTE_PROJECT   = 'project';
	public const ROUTE_SUPPORT   = 'support';
	/** Public (no login) accessibility statement required by the EAA. */
	public const ROUTE_ACCESSIBILITY = 'accessibility';
	/** Public sign-in page: the portal's own form, posting to wp-login.php. */
	public const ROUTE_SIGN_IN = 'sign-in';

	/**
	 * Bumped whenever a rewrite rule is added or changed, so a site flushes
	 * its rules on the next load even though the plugin version is the same
	 * (Plugin's self-healing flush compares this stamp).
	 */
	private const REWRITE_REVISION = 2;

	/** What the rewrite flush records: the plugin version and the rules revision. */
	public static function rewriteStamp(): string {
		return MONSTERA_VERSION . '+r' . self::REWRITE_REVISION;
	}

	public static function portalPrefix(): string {
		$prefix = (string) apply_filters( Hooks::FILTER_PORTAL_PREFIX, get_option( 'monstera_portal_prefix', 'portal' ) );
		return trim( $prefix, '/' );
	}

	public static function register(): void {
		$prefix = self::portalPrefix();

		add_rewrite_rule(
			'^' . $prefix . '/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_DASHBOARD,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/profile/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_PROFILE,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/directory/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_DIRECTORY,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/forms/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_FORMS,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/projects/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_PROJECTS,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/projects/([0-9]+)/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_PROJECT . '&' . self::PARAM_ID . '=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/support/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_SUPPORT,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/accessibility/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_ACCESSIBILITY,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/sign-in/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_SIGN_IN,
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/forms/([0-9]+)/open/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_FORM_OPEN . '&' . self::PARAM_ID . '=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/content/([0-9]+)/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_CONTENT . '&' . self::PARAM_ID . '=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/download/([0-9]+)/([a-f0-9]+)/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_DOWNLOAD . '&' . self::PARAM_ID . '=$matches[1]&monstera_nonce=$matches[2]',
			'top'
		);
		add_rewrite_rule(
			'^' . $prefix . '/([a-z0-9-]+)/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::ROUTE_ORG . '&' . self::PARAM_ORG . '=$matches[1]',
			'top'
		);

		add_filter(
			'query_vars',
			static function ( array $vars ): array {
				$vars[] = self::QUERY_VAR;
				$vars[] = self::PARAM_ORG;
				$vars[] = self::PARAM_ID;
				$vars[] = 'monstera_nonce';
				return $vars;
			}
		);

		// Fallback parser for environments where rewrite rules don't persist
		// (notably wp-now / PHP-WASM with SQLite). When a /portal/* request
		// reaches parse_request without our query var set, we re-derive the
		// route from $wp->request and inject the query vars directly.
		add_action( 'parse_request', [ self::class, 'fallbackParseRequest' ] );
	}

	public static function fallbackParseRequest( \WP $wp ): void {
		// Rewrite already matched — nothing to do.
		if ( ! empty( $wp->query_vars[ self::QUERY_VAR ] ) ) {
			return;
		}

		// $wp->request is only populated when the rewrite_rules option is
		// non-empty. Under wp-now / PHP-WASM the option can be empty even
		// after a flush, in which case we parse REQUEST_URI directly.
		$request = trim( (string) $wp->request, '/' );
		if ( '' === $request ) {
			$uri  = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
			$qpos = strpos( $uri, '?' );
			if ( false !== $qpos ) {
				$uri = substr( $uri, 0, $qpos );
			}
			// Strip the site's sub-path if WP lives under one (e.g. /wp/).
			$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
			if ( '' !== $home_path && '/' !== $home_path && str_starts_with( $uri, $home_path ) ) {
				$uri = substr( $uri, strlen( $home_path ) );
			}
			$request = trim( $uri, '/' );
		}

		$prefix = self::portalPrefix();

		if ( $request !== $prefix && ! str_starts_with( $request, $prefix . '/' ) ) {
			return;
		}

		$rest = trim( substr( $request, strlen( $prefix ) ), '/' );

		// /portal or /portal/ → dashboard
		if ( '' === $rest ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::ROUTE_DASHBOARD;
			return;
		}

		$simple = [
			'profile'       => self::ROUTE_PROFILE,
			'directory'     => self::ROUTE_DIRECTORY,
			'forms'         => self::ROUTE_FORMS,
			'projects'      => self::ROUTE_PROJECTS,
			'support'       => self::ROUTE_SUPPORT,
			'accessibility' => self::ROUTE_ACCESSIBILITY,
			'sign-in'       => self::ROUTE_SIGN_IN,
		];
		if ( isset( $simple[ $rest ] ) ) {
			$wp->query_vars[ self::QUERY_VAR ] = $simple[ $rest ];
			return;
		}

		if ( preg_match( '#^projects/(\d+)$#', $rest, $m ) ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::ROUTE_PROJECT;
			$wp->query_vars[ self::PARAM_ID ]  = (int) $m[1];
			return;
		}

		if ( preg_match( '#^forms/(\d+)/open$#', $rest, $m ) ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::ROUTE_FORM_OPEN;
			$wp->query_vars[ self::PARAM_ID ]  = (int) $m[1];
			return;
		}

		if ( preg_match( '#^content/(\d+)$#', $rest, $m ) ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::ROUTE_CONTENT;
			$wp->query_vars[ self::PARAM_ID ]  = (int) $m[1];
			return;
		}

		if ( preg_match( '#^download/(\d+)/([a-f0-9]+)$#', $rest, $m ) ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::ROUTE_DOWNLOAD;
			$wp->query_vars[ self::PARAM_ID ]  = (int) $m[1];
			$wp->query_vars['monstera_nonce']  = $m[2];
			return;
		}

		// /portal/{org-slug} — must come last, matches anything alphanum+dash.
		if ( preg_match( '#^([a-z0-9-]+)$#', $rest, $m ) ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::ROUTE_ORG;
			$wp->query_vars[ self::PARAM_ORG ] = $m[1];
			return;
		}
	}

	public static function flush(): void {
		self::register();
		flush_rewrite_rules( false );
	}

	/**
	 * Like rest_url() but always uses the `?rest_route=` form. This works
	 * regardless of permalink / rewrite state — particularly important under
	 * wp-now and other PHP-WASM environments where the `/wp-json/*` rewrite
	 * rule doesn't reliably persist in the rewrite_rules option.
	 */
	public static function restUrl( string $path = '' ): string {
		$home = home_url( '/' );
		$sep  = str_contains( $home, '?' ) ? '&' : '?';
		return $home . $sep . 'rest_route=/' . ltrim( $path, '/' );
	}

	/**
	 * @param array<string, mixed> $args
	 */
	public static function url( string $route, array $args = [] ): string {
		$prefix = self::portalPrefix();
		$base   = home_url( '/' . $prefix . '/' );

		switch ( $route ) {
			case self::ROUTE_DASHBOARD:
				return $base;
			case self::ROUTE_PROFILE:
				return $base . 'profile/';
			case self::ROUTE_DIRECTORY:
				return $base . 'directory/';
			case self::ROUTE_FORMS:
				return $base . 'forms/';
			case self::ROUTE_FORM_OPEN:
				return $base . 'forms/' . (int) ( $args['id'] ?? 0 ) . '/open/';
			case self::ROUTE_PROJECTS:
				return $base . 'projects/';
			case self::ROUTE_PROJECT:
				return $base . 'projects/' . (int) ( $args['id'] ?? 0 ) . '/';
			case self::ROUTE_SUPPORT:
				return $base . 'support/';
			case self::ROUTE_ACCESSIBILITY:
				return $base . 'accessibility/';
			case self::ROUTE_SIGN_IN:
				return $base . 'sign-in/';
			case self::ROUTE_CONTENT:
				return $base . 'content/' . (int) ( $args['id'] ?? 0 ) . '/';
			case self::ROUTE_ORG:
				return $base . sanitize_title( (string) ( $args['slug'] ?? '' ) ) . '/';
			case self::ROUTE_DOWNLOAD:
				$id    = (int) ( $args['id'] ?? 0 );
				$nonce = (string) ( $args['nonce'] ?? '' );
				return $base . 'download/' . $id . '/' . $nonce . '/';
			default:
				return $base;
		}
	}
}
