<?php
declare(strict_types=1);

namespace Monstera\Core;

/**
 * The last run of each maintenance tool (a sync, each export, the
 * first-email reset), for the Tools page's "Last run" lines. One option,
 * one entry per tool.
 */
final class ToolRuns {

	public const OPTION = 'monstera_tool_runs';

	/**
	 * @return array<string, array{at: string, outcome: string, detail: string, user_id: int}>
	 */
	public static function all(): array {
		$runs = get_option( self::OPTION, [] );
		return is_array( $runs ) ? $runs : [];
	}

	/**
	 * @param string $tool    'sync', 'export_members', 'export_orgs', 'export_activity' or 'reset'.
	 * @param string $outcome 'ok' or 'failed'.
	 * @param string $detail  One short fact about the run ("0 rows removed").
	 */
	public static function record( string $tool, string $outcome, string $detail = '' ): void {
		$runs                          = self::all();
		$runs[ sanitize_key( $tool ) ] = [
			'at'      => gmdate( 'c' ),
			'outcome' => 'ok' === $outcome ? 'ok' : 'failed',
			'detail'  => sanitize_text_field( $detail ),
			'user_id' => get_current_user_id(),
		];
		update_option( self::OPTION, $runs, false );
	}
}
