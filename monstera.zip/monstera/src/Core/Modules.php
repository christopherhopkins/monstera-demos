<?php
/**
 * Module-active state helper.
 *
 * Single source of truth for the `monstera_active_modules` option so
 * every call site (Plugin boot, REST registration, admin menu, portal
 * templates) reads the same default set and respects the same filter.
 */

declare(strict_types=1);

namespace Monstera\Core;

defined( 'ABSPATH' ) || exit;

final class Modules {

	public const PROJECTS  = 'projects';
	public const ALERTS    = 'alerts';
	public const SUPPORT   = 'support';
	public const FORMS     = 'forms';
	public const REPORTING = 'reporting';

	private const DEFAULT_ACTIVE = [
		self::FORMS,
		self::REPORTING,
		self::PROJECTS,
		self::ALERTS,
		self::SUPPORT,
	];

	/** @var string[]|null */
	private static ?array $cached = null;

	/**
	 * The built-in default module set. Used both as the get_option() fallback
	 * below and as the seed value on activation (Activator::seedOptions) so the
	 * two can never drift — a divergence here silently turns a module on or off
	 * depending on whether the option was ever written.
	 *
	 * @return string[]
	 */
	public static function defaults(): array {
		return self::DEFAULT_ACTIVE;
	}

	/**
	 * @return string[]
	 */
	public static function active(): array {
		if ( null !== self::$cached ) {
			return self::$cached;
		}
		$raw = get_option( 'monstera_active_modules', self::DEFAULT_ACTIVE );
		$raw = is_array( $raw ) ? $raw : self::DEFAULT_ACTIVE;
		/** @var string[] $filtered */
		$filtered     = (array) apply_filters( Hooks::FILTER_ACTIVE_MODULES, $raw );
		self::$cached = array_values( array_filter( array_map( 'sanitize_key', $filtered ) ) );
		return self::$cached;
	}

	public static function isActive( string $slug ): bool {
		return in_array( $slug, self::active(), true );
	}

	/**
	 * Forget the per-request cache. Used by the Settings save handler so
	 * a toggle takes effect on the same request without page reload.
	 */
	public static function invalidateCache(): void {
		self::$cached = null;
	}
}
